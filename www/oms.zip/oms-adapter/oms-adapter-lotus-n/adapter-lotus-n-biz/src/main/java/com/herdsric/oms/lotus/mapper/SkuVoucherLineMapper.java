package com.herdsric.oms.lotus.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.herdsric.oms.lotus.entity.SkuVoucherLine;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author Herdsric
 * @description 针对表【os_sku_voucher_line】的数据库操作Mapper
 * @createDate 2022-11-02 14:43:16
 */
@Mapper
public interface SkuVoucherLineMapper extends BaseMapper<SkuVoucherLine> {

}
