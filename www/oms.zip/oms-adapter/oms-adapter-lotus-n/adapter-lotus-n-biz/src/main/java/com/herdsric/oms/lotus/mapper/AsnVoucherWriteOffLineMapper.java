package com.herdsric.oms.lotus.mapper;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Constants;
import com.herdsric.oms.common.mybatis.base.RootMapper;
import com.herdsric.oms.lotus.entity.AsnVoucherWriteOffLine;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * @author Herdsric
 * @description 针对表【lotus_asn_voucher_write_off_line】的数据库操作Mapper
 * @createDate 2022-12-13 11:20:25
 * @Entity com.herdsric.oms.adapter.entity.AsnVoucherWriteOffLine
 */
public interface AsnVoucherWriteOffLineMapper extends RootMapper<AsnVoucherWriteOffLine> {

	/**
	 * 获取已冲销行集合
	 * @param groupBy
	 * @return
	 */
	@Select("SELECT voucher_no,line_no,part_number,sum(write_off_qty) as writeOffQty  FROM lotus_asn_voucher_write_off_line ${ew.customSqlSegment}")
	List<AsnVoucherWriteOffLine> getAlreadyWrittenOffList(
			@Param(Constants.WRAPPER) LambdaQueryWrapper<AsnVoucherWriteOffLine> groupBy);

}
