package com.herdsric.oms.lotus.common;

import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.lang.Assert;
import cn.hutool.core.util.StrUtil;
import com.dtflys.forest.http.ForestResponse;
import com.herdsric.oms.common.client.enums.UnitEnum;
import com.herdsric.oms.common.client.masterdata.domain.SkuDm;
import com.herdsric.oms.lotus.dto.*;
import com.herdsric.oms.lotus.utils.LotusAndPortalBeanCovUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

/**
 * @Description: 主数据接口
 * @author: Dzx
 * @date: 2022.10.31
 */
@Slf4j
@Component
public class MastDataHandle {

	@Resource
	private SapMasterApi sapMasterApi;

	/**
	 * 发送请求获取主数据信息
	 * @param reqDto 请求参数
	 * @return
	 */
	public List<MasterDataResListDto> reqMasterData(MasterDataReqDto reqDto) {
		// 获取当前时间
		Date date = DateUtil.date();
		// 方便第一次全量查询
		if (StringUtils.isBlank(reqDto.getDate1())) {
			reqDto.setDate1(DateUtil.format(DateUtil.offsetDay(date, -1), DatePattern.PURE_DATE_FORMAT));
		}
		// 方便第一次全量查询
		if (StringUtils.isBlank(reqDto.getDate2())) {
			reqDto.setDate2(DateUtil.format(date, DatePattern.PURE_DATE_FORMAT));
		}
		ForestResponse<LotusCommonResDto<MasterDataResDto>> response = sapMasterApi
				.getMasterData(new LotusCommonReqDto<List<MasterDataReqDto>>().setRequestData(Arrays.asList(reqDto)));
		Assert.isTrue(LotusConstant.LOTUS_RES_STATUS_SUCCESS.equals(response.getResult().getResponseData().getStatus()),
				"调用lotus{getMasterData}接口返回结果:{}", response);
		return response.getResult().getResponseData().getList();
	}

	/**
	 * 主数据处理
	 * @param masterDataRes
	 * @return
	 */
	public List<SkuDm> getSyncSkuData(List<MasterDataResListDto> masterDataRes) {
		log.info("主数据开始实体转换处理。。。");
		List<SkuDm> skuDTOList = new ArrayList<SkuDm>(masterDataRes.size());
		for (MasterDataResListDto masterDataResListDto : masterDataRes) {
			// 判断PartNumber是否为空 todo util ea 先放这里
			if (ObjectUtils.isEmpty(masterDataResListDto) || StringUtils.isBlank(masterDataResListDto.getMatnr())
					|| StrUtil.isEmpty(masterDataResListDto.getMeins())) {
				continue;
			}
			if (StrUtil.equals(UnitEnum.EA.value, masterDataResListDto.getMeins())) {
				masterDataResListDto.setMeins(UnitEnum.PCS.value);
			}
			// 类型转换
			SkuDm syncSkuDto = LotusAndPortalBeanCovUtil.skuToOmsSku(masterDataResListDto);
			skuDTOList.add(syncSkuDto);
		}
		return skuDTOList;
	}

}
