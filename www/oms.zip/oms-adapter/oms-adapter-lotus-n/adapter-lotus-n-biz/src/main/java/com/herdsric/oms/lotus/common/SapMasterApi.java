package com.herdsric.oms.lotus.common;

import com.dtflys.forest.annotation.BaseRequest;
import com.dtflys.forest.annotation.JSONBody;
import com.dtflys.forest.annotation.Post;
import com.dtflys.forest.http.ForestResponse;
import com.herdsric.oms.lotus.common.interceptor.LoutsReqInterceptor;
import com.herdsric.oms.lotus.dto.LotusCommonReqDto;
import com.herdsric.oms.lotus.dto.LotusCommonResDto;
import com.herdsric.oms.lotus.dto.MasterDataReqDto;
import com.herdsric.oms.lotus.dto.MasterDataResDto;

import java.util.List;

/**
 * @Description: lotus请求接口
 * @author: Dzx
 * @date: 2022.10.31
 */

@BaseRequest(interceptor = LoutsReqInterceptor.class)
public interface SapMasterApi {

	/**
	 * 调用主数据接口
	 * @param reqDto
	 * @return
	 */
	@Post(value = "#{url.louts.getMasterData}", headers = { "serviceName:SAP&WMS00000018" })
	ForestResponse<LotusCommonResDto<MasterDataResDto>> getMasterData(
			@JSONBody LotusCommonReqDto<List<MasterDataReqDto>> reqDto);

}
