package com.herdsric.oms.lotus.common;

import com.dtflys.forest.annotation.Get;
import com.dtflys.forest.converter.json.FastjsonEncoder;
import com.herdsric.oms.lotus.dto.LotusAuthResDto;

/**
 * @Description: lotus认账授权请求接口国内sap
 * @author: Dzx
 * @date: 2022.10.31
 */

public interface SendLotusAuthApi {

	/**
	 * 获取请求公钥
	 * @return
	 */
	@Get("#{url.louts.getRsaPublicKey}")
	LotusAuthResDto getRsaPublicKey();

}
