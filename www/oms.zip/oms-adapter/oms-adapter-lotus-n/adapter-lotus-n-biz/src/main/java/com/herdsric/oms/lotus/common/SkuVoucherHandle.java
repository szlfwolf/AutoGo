package com.herdsric.oms.lotus.common;

import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.lang.Assert;
import cn.hutool.core.util.StrUtil;
import com.dtflys.forest.http.ForestResponse;
import com.herdsric.oms.common.client.enums.UnitEnum;
import com.herdsric.oms.common.core.constant.CommonConstants;
import com.herdsric.oms.common.core.constant.enums.ExtendPropsEnum;
import com.herdsric.oms.common.core.constant.enums.SkuVoucherOperateTypeEnum;
import com.herdsric.oms.common.core.constant.enums.SkuVoucherStatusEnum;
import com.herdsric.oms.common.core.exception.OmsBusinessException;
import com.herdsric.oms.common.core.util.JsonMapper;
import com.herdsric.oms.lotus.dto.DnOrderVo;
import com.herdsric.oms.lotus.dto.LotusCommonReqDto;
import com.herdsric.oms.lotus.dto.LotusCommonResDto;
import com.herdsric.oms.lotus.dto.SkuVoucherCreateResDto;
import com.herdsric.oms.lotus.dto.sap.*;
import com.herdsric.oms.lotus.entity.AsnVoucherWriteOff;
import com.herdsric.oms.lotus.entity.AsnVoucherWriteOffLine;
import com.herdsric.oms.lotus.entity.DnVoucherWriteOff;
import com.herdsric.oms.lotus.entity.SkuVoucher;
import com.herdsric.oms.lotus.enums.AsnVoucherWriteOffStatusEnum;
import com.herdsric.oms.lotus.utils.DateDealUtil;
import com.herdsric.oms.lotus.utils.TimeZoneUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.compress.utils.Lists;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @Description: 物料凭证处理
 * @author: Dzx
 * @date: 2022.11.04
 */
@Component
@Slf4j
public class SkuVoucherHandle {

	@Resource
	private SendLotusApi sendLotusApi;

	@Resource
	private WtsApi wtsApi;

	/**
	 * 发送物料凭证给lotus
	 * @param skuVoucherDto
	 * @return boolean
	 */
	public boolean skuVoucherCreateSendLotus(SkuVoucherDto skuVoucherDto) {
		DateTime createTime = DateUtil.parseDateTime(DateDealUtil.convertEUToCN(skuVoucherDto.getCreateTime()));
		SkuVoucherCreateReqDto reqDto = new SkuVoucherCreateReqDto();
		reqDto.setVoucherDate(DateUtil.format(createTime, DatePattern.PURE_DATE_FORMAT));
		reqDto.setVoucherTime(DateUtil.formatTime(createTime));
		reqDto.setPostingDate(TimeZoneUtils.getNowDateUtc8Str());
		reqDto.setOrderNo(skuVoucherDto.getOrderNo());
		List<SkuVoucherLineReqDto> skuVoucherLineList = Lists.newArrayList();
		for (SkuVoucherLineDto skuVoucherLineDto : skuVoucherDto.getSkuVoucherLineDtoList()) {
			SkuVoucherLineReqDto skuVoucherLine = new SkuVoucherLineReqDto();
			BeanUtils.copyProperties(skuVoucherLineDto, skuVoucherLine);
			if (StrUtil.equals(skuVoucherLine.getUnit(), UnitEnum.PCS.value)) {
				skuVoucherLine.setUnit(UnitEnum.EA.value);
			}
			else {
				skuVoucherLine.setUnit(UnitEnum.getUnitValue(skuVoucherLine.getUnit()));
			}
			skuVoucherLineList.add(skuVoucherLine);
		}
		reqDto.setSkuVoucherLineReqDtoList(skuVoucherLineList);
		ForestResponse<LotusCommonResDto<SkuVoucherCreateResDto>> response;
		skuVoucherDto.setSendTime(DateUtil.now());
		try {
			/**
			 * 迁移到新接口：SkuVoucherOperateTypeEnum.STOCK_ASN_RECEIPT SAP迁移到WTS<br/>
			 * 其他类型的凭证 还是调用SAP<br/>
			 */
			if (SkuVoucherOperateTypeEnum.STOCK_ASN_RECEIPT.getValue().equals(skuVoucherDto.getOperateType())) {
				response = wtsApi
						.inboundVoucherPushWts(new LotusCommonReqDto<SkuVoucherCreateReqDto>().setRequestData(reqDto));
			}
			else {
				response = sendLotusApi
						.skuVoucherCreate(new LotusCommonReqDto<SkuVoucherCreateReqDto>().setRequestData(reqDto));
			}
			SkuVoucherCreateResDto skuVoucherCreateResDto = response.getResult().getResponseData();
			Assert.isTrue(
					LotusConstant.LOTUS_RES_STATUS_SUCCESS.equals(response.getResult().getResponseData().getStatus()),
					"调用lotus{skuVoucherCreate}接口失败！！！ 返回结果:{}", skuVoucherCreateResDto.getMessage());
			if (!LotusConstant.LOTUS_RES_STATUS_SUCCESS.equals(skuVoucherCreateResDto.getStatus())) {
				skuVoucherDto.setStatus(SkuVoucherStatusEnum.FAIL_SEND.getValue());

				throw new OmsBusinessException("6005",
						StrUtil.format("向SAP同步物料凭证异常,异常信息:{}", skuVoucherCreateResDto.getMessage()));
			}
			skuVoucherDto.setStatus(SkuVoucherStatusEnum.ALREADY_SEND.getValue());
			skuVoucherDto.setSendCreate(CommonConstants.STATUS_DEL);
			skuVoucherDto.setSapStockOrderNo(skuVoucherCreateResDto.getSapStockOrderNo());
			return true;
		}
		catch (Exception e) {
			skuVoucherDto.setStatus(SkuVoucherStatusEnum.FAIL_SEND.getValue());
			log.error("Error sending skuVoucherCreate!!  error message:{}", e);
			throw new OmsBusinessException("6005", StrUtil.format("向SAP同步物料凭证异常,异常信息:{}", e.getMessage()));
		}
	}

	/**
	 * 组装物料凭证销毁参数
	 * @param
	 * @return boolean
	 */
	public boolean buildAsnVoucherWriteOffReq(List<AsnVoucherWriteOff> asnVoucherWriteOffList) {
		for (AsnVoucherWriteOff asnVoucherWriteOff : asnVoucherWriteOffList) {
			DateTime sendTime = DateUtil
					.parseDateTime(DateDealUtil.convertEUToCN(asnVoucherWriteOff.getSendCreateTime()));
			SkuVoucherWriteOffReqDto reqDto = new SkuVoucherWriteOffReqDto();
			reqDto.setYear(DateUtil.format(sendTime, DatePattern.NORM_YEAR_PATTERN));
			reqDto.setSapStockOrderNo(asnVoucherWriteOff.getSapStockOrderNo());
			reqDto.setPostingDate(DateUtil.format(sendTime, DatePattern.PURE_DATE_FORMAT));
			List<SkuVoucherWriteOffItemReqDto> itemReqs = new LinkedList<>();
			for (AsnVoucherWriteOffLine asnVoucherWriteOffLine : asnVoucherWriteOff.getLine()) {
				SkuVoucherWriteOffItemReqDto itemReq = new SkuVoucherWriteOffItemReqDto();
				itemReq.setLineNo(asnVoucherWriteOffLine.getLineNo());
				itemReq.setQty(asnVoucherWriteOffLine.getWriteOffQty());
				itemReqs.add(itemReq);
			}
			reqDto.setItem(itemReqs);
			boolean sendStatus = this
					.sendSkuVoucherWriteOffSendLotus(SkuVoucherOperateTypeEnum.STOCK_ASN_RECEIPT.getValue(), reqDto);
			asnVoucherWriteOff.setStatus(sendStatus ? AsnVoucherWriteOffStatusEnum.ALREADY_WRITE_OFF.getValue()
					: AsnVoucherWriteOffStatusEnum.FAIL_WRITE_OFF.getValue());
			asnVoucherWriteOff.setSendWriteOff(sendStatus ? CommonConstants.STATUS_DEL : CommonConstants.STATUS_NORMAL);
			asnVoucherWriteOff.setResponseContent(reqDto.getResponseContent());
		}
		return true;
	}

	/**
	 * SkuVoucherOperateTypeEnum.STOCK_ASN_RECEIPT
	 * @param reqDto 请求参数
	 * @return
	 */
	public boolean sendSkuVoucherWriteOffSendLotus(String operateType, SkuVoucherWriteOffReqDto reqDto) {
		ForestResponse<LotusCommonResDto<SkuVoucherWriteOffResDto>> response;
		try {
			if (SkuVoucherOperateTypeEnum.STOCK_ASN_RECEIPT.getValue().equals(operateType)) {
				response = wtsApi.inboundVoucherWriteOffPushWts(
						new LotusCommonReqDto<SkuVoucherWriteOffReqDto>().setRequestData(reqDto));
			}
			else {
				response = sendLotusApi
						.skuVoucherWriteOff(new LotusCommonReqDto<SkuVoucherWriteOffReqDto>().setRequestData(reqDto));
			}
			SkuVoucherWriteOffResDto writeOffResDtoResponse = response.getResult().getResponseData();
			if (!LotusConstant.LOTUS_RES_STATUS_SUCCESS.equals(writeOffResDtoResponse.getStatus())) {
				reqDto.setResponseContent(writeOffResDtoResponse.getMessage());
				return false;
			}
			reqDto.setResponseContent(writeOffResDtoResponse.getMessage());
			return true;
		}
		catch (Exception e) {
			reqDto.setResponseContent(e.getMessage());
			log.error("Error sending SkuVoucherWriteOff!!  error message:{}", e);
			return false;
		}
	}

	/**
	 * 组装物料凭证dn冲销参数
	 * @param dnVoucherWriteOffList
	 * @return boolean
	 */
	public boolean buildSkuVoucherDnWriteOffReq(List<DnVoucherWriteOff> dnVoucherWriteOffList,
			List<DnOrderVo> dnOrderVoList) {
		String currentTime = DateUtil.format(DateUtil.parseDateTime(DateDealUtil.convertEUToCN(DateUtil.now())),
				DatePattern.PURE_DATE_FORMAT);

		Map<String, DnOrderVo> dnOrderVoMap = dnOrderVoList.stream()
				.collect(Collectors.toMap(dnOrderVo -> dnOrderVo.getOrderNo(), Function.identity()));

		for (DnVoucherWriteOff dnVoucherWriteOff : dnVoucherWriteOffList) {
			LotusDnBackDTO lotusDnBackDTO = new LotusDnBackDTO();
			lotusDnBackDTO.setASNNO(dnVoucherWriteOff.getBzOutOrderNo());
			lotusDnBackDTO.setBLDAT(currentTime);
			lotusDnBackDTO.setBUDAT(currentTime);
			lotusDnBackDTO.setWMSNO(dnVoucherWriteOff.getDnNo());
			lotusDnBackDTO.setASNTYPE(LotusConstant.LOTUS_DN_BACK_WRITE_OFF);
			lotusDnBackDTO.setUSNAM(LotusConstant.LOTUS_SEND_USER_NAME);

			DnOrderVo dnOrderVo = dnOrderVoMap.get(dnVoucherWriteOff.getBzOutOrderNo());

			// 获取目标的交易类型
			Map map = JsonMapper.INSTANCE.fromJson(dnOrderVo.getExtendProp(), Map.class);
			Object zjylx = map.get(ExtendPropsEnum.LOTUS_TRADE_TYPE.getValue());

			lotusDnBackDTO.setZjylx(zjylx.toString());

			List<LotusDnLineBackDTO> items = dnVoucherWriteOff.getItems();
			// 业务类型为冲销时 还是传sto号
			if (lotusDnBackDTO.getASNTYPE().equals(LotusConstant.LOTUS_DN_BACK_WRITE_OFF)) {
				for (int i = 0; i < dnOrderVo.getOrderLineList().size(); i++) {
					Map lineMap = JsonMapper.INSTANCE.fromJson(dnOrderVo.getOrderLineList().get(i).getLineExtendProp(),
							Map.class);
					Object vg = lineMap.get(ExtendPropsEnum.LOTUS_LCMS_LINENO.getValue());
					items.get(i).setVGBEL(dnVoucherWriteOff.getBzOutOrderNo());
					items.get(i).setVGPOS(vg.toString());

				}
				dnVoucherWriteOff.setItems(items);
			}
			if (CommonConstants.STATUS_DEL.equals(dnVoucherWriteOff.getResendDn())) {
				lotusDnBackDTO.setRESEND("X");
			}
			lotusDnBackDTO.setITEM(dnVoucherWriteOff.getItems());
			boolean sendStatus = dnVoucherWriteOffSendLotus(dnVoucherWriteOff.getWarehouseCode(),
					dnVoucherWriteOff.getBzOutOrderNo(), lotusDnBackDTO);
			dnVoucherWriteOff.setResponseContent(lotusDnBackDTO.getResponseContent());
			if (sendStatus) {
				dnVoucherWriteOff.setStatus(AsnVoucherWriteOffStatusEnum.ALREADY_WRITE_OFF.getValue());
				dnVoucherWriteOff.setSendWriteOff(CommonConstants.STATUS_DEL);
			}
			else {
				dnVoucherWriteOff.setStatus(AsnVoucherWriteOffStatusEnum.FAIL_WRITE_OFF.getValue());
				dnVoucherWriteOff.setSendWriteOff(CommonConstants.STATUS_NORMAL);
			}
		}
		return true;
	}

	/**
	 * @param warehouseCode 仓库code
	 * @param orderNo 订单号
	 * @param reqDto 请求参数
	 * @return
	 */
	public boolean dnVoucherWriteOffSendLotus(String warehouseCode, String orderNo, LotusDnBackDTO reqDto) {
		ForestResponse<LotusCommonResDto<DnBackResDto>> response = null;
		try {
			response = sendLotusApi.sendDnBack(new LotusCommonReqDto().setRequestData(reqDto));
			if (null == response.getResult() || !LotusConstant.LOTUS_RES_STATUS_SUCCESS
					.equals(response.getResult().getResponseData().getStatus())) {
				reqDto.setResponseContent(response.getResult().getResponseData().getMessage());
				return false;
			}
			reqDto.setResponseContent(response.getResult().getResponseData().getMessage());
			return true;
		}
		catch (Exception e) {
			reqDto.setResponseContent(e.getMessage());
			log.error("Error sending   dnVoucherWriteOff!!  error message:{}", e);
			return false;
		}
	}

	/**
	 * 组装物料凭证asn冲销参数
	 * @param skuVoucher
	 * @return boolean
	 */
	public boolean buildSkuVoucherWriteOffReq(SkuVoucher skuVoucher) {
		DateTime sendTime = DateUtil.parseDateTime(DateDealUtil.convertEUToCN(skuVoucher.getSendTime()));
		SkuVoucherWriteOffReqDto reqDto = new SkuVoucherWriteOffReqDto();
		reqDto.setYear(DateUtil.format(sendTime, DatePattern.NORM_YEAR_PATTERN));
		reqDto.setSapStockOrderNo(skuVoucher.getSapStockOrderNo());
		reqDto.setPostingDate(DateUtil.format(sendTime, DatePattern.PURE_DATE_FORMAT));

		return sendSkuVoucherWriteOffSendLotus(skuVoucher.getOperateType(), reqDto);
	}

}
