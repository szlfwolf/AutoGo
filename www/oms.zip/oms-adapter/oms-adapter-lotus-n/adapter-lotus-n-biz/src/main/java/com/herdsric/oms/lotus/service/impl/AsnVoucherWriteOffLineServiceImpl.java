package com.herdsric.oms.lotus.service.impl;

import cn.hutool.core.collection.CollectionUtil;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.herdsric.oms.lotus.entity.AsnVoucherWriteOffLine;
import com.herdsric.oms.lotus.mapper.AsnVoucherWriteOffLineMapper;
import com.herdsric.oms.lotus.service.AsnVoucherWriteOffLineService;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author Herdsric
 * @description 针对表【lotus_asn_voucher_write_off_line】的数据库操作Service实现
 * @createDate 2022-12-13 11:20:25
 */
@Service
public class AsnVoucherWriteOffLineServiceImpl extends ServiceImpl<AsnVoucherWriteOffLineMapper, AsnVoucherWriteOffLine>
		implements AsnVoucherWriteOffLineService {

	@Override
	public Boolean saveBatch(List<AsnVoucherWriteOffLine> list) {
		if (CollectionUtil.isNotEmpty(list)) {
			int i = baseMapper.insertBatch(list);
			if (i > 0) {
				return true;
			}
		}
		return false;
	}

}
