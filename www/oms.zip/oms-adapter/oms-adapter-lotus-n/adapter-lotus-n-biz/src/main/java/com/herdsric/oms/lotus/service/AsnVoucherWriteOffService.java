package com.herdsric.oms.lotus.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.lotus.entity.AsnVoucherWriteOff;
import org.springframework.web.multipart.MultipartFile;

/**
 * @author Herdsric
 * @description 针对表【lotus_asn_voucher_write_off】的数据库操作Service
 * @createDate 2022-12-13 11:20:25
 */
public interface AsnVoucherWriteOffService extends IService<AsnVoucherWriteOff> {

	/**
	 * ans物料凭证冲销ByExcel
	 * @param file
	 * @param clientCode
	 * @return
	 */
	R uploadAsnWriteOffByExcel(MultipartFile file, String clientCode);

}
