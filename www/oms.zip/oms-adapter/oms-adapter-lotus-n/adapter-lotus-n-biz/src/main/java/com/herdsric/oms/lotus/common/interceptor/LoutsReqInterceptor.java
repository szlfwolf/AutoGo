package com.herdsric.oms.lotus.common.interceptor;

import cn.hutool.core.lang.Assert;
import cn.hutool.core.util.IdUtil;
import com.alibaba.fastjson.JSONObject;
import com.dtflys.forest.http.ForestRequest;
import com.dtflys.forest.interceptor.Interceptor;
import com.dtflys.forest.reflection.ForestMethod;
import com.herdsric.oms.lotus.common.LotusConstant;
import com.herdsric.oms.lotus.common.SendLotusAuthApi;
import com.herdsric.oms.lotus.dto.LotusAuthResDto;
import com.herdsric.oms.lotus.utils.RsaEncrypt;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * @Description: lotus请求拦截器
 * @author: Dzx
 * @date: 2022.11.14
 */
@Component
@Slf4j
@RefreshScope
public class LoutsReqInterceptor<T> implements Interceptor<T> {

	@Resource
	private SendLotusAuthApi sendLotusAuthApi;

	@Value("${parameter.lotus.auth.appId}")
	private String appId;

	@Value("${parameter.lotus.auth.appSecret}")
	private String appSecret;

	/**
	 * 该方法在被调用时，并在beforeExecute前被调用
	 *
	 * @Param request Forest请求对象
	 * @Param args 方法被调用时传入的参数数组
	 */
	@Override
	public void onInvokeMethod(ForestRequest req, ForestMethod method, Object[] args) {
		try {
			LotusAuthResDto response = sendLotusAuthApi.getRsaPublicKey();
			Assert.notNull(response, "调用lotus获取公钥接口失败！！！ 返回结果:{}", response);
			Assert.isTrue("10000000".equals(response.getCode()), "调用lotus获取公钥接口失败！！！ 返回结果:{}", response);
			Assert.notNull(response.getData(), "调用lotus获取公钥接口失败！！！ 返回结果:{}", response);
			JSONObject json = new JSONObject();
			json.put("appId", appId);
			json.put("appSecret", appSecret);
			req.addHeader(LotusConstant.LOTUS_AUTH_AUTHORIZATION,
					RsaEncrypt.encrypt(json.toJSONString().getBytes(), response.getData()));
		}
		catch (Exception e) {
			log.error("Error get Rsa PublicKey");
			req.addBody("Error", "获取Rsa公钥接口出错");
		}
		req.addHeader("Content-Type", "application/json;charset=UTF-8");
		req.addHeader("sourceSystem", "WMS");
		req.addHeader("targetSystem", "SAP");
		req.addHeader("requestId", IdUtil.simpleUUID());
	}

}
