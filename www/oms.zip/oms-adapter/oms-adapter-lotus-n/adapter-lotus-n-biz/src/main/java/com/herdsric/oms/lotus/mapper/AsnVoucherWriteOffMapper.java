package com.herdsric.oms.lotus.mapper;

import com.herdsric.oms.common.mybatis.base.RootMapper;
import com.herdsric.oms.lotus.entity.AsnVoucherWriteOff;

/**
 * @author Herdsric
 * @description 针对表【lotus_asn_voucher_write_off】的数据库操作Mapper
 * @createDate 2022-12-13 11:20:25
 * @Entity com.herdsric.oms.adapter.entity.AsnVoucherWriteOff
 */
public interface AsnVoucherWriteOffMapper extends RootMapper<AsnVoucherWriteOff> {

	/**
	 * 查询重发数据根据Id
	 * @param id
	 */
	void selectResendDataById(Integer id);

}
