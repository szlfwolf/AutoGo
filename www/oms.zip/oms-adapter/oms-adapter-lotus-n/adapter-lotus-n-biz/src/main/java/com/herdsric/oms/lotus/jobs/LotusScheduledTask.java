package com.herdsric.oms.lotus.jobs;

import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONUtil;
import com.herdsric.oms.common.core.constant.CommonConstants;
import com.herdsric.oms.common.core.constant.SecurityConstants;
import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.common.feign.client.RemoteBizRecordService;
import com.herdsric.oms.common.job.common.AbstractCommonTask;
import com.herdsric.oms.lotus.common.LotusConstant;
import com.herdsric.oms.lotus.dto.MasterDataReqDto;
import com.herdsric.oms.lotus.dto.sap.CostCenterMasterDataDTO;
import com.herdsric.oms.lotus.enums.ApiType;
import com.herdsric.oms.lotus.jobs.common.JobCommon;
import com.herdsric.oms.lotus.service.CostCenterMasterDataService;
import com.herdsric.oms.lotus.service.LotusService;
import com.xxl.job.core.context.XxlJobHelper;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

/**
 * @Description: Lotus定时任务
 * @author: Dzx
 * @date: 2022.10.28
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class LotusScheduledTask extends AbstractCommonTask {

	private final LotusService lotusService;

	private final CostCenterMasterDataService costCenterMasterDataService;

	private final RemoteBizRecordService remoteBizRecordService;

	/**
	 * 早9点拉取lotus主数据同步到OMS
	 */
	// @Scheduled(cron = "0/3 * * * * ?")
	@XxlJob(JobCommon.JobName.JOB_LOTUS_MASTER_DATA_SYNCHRONIZATION)
	public void autoMaticCombination() {
		this.execute(JobCommon.TaskEnum.JOB_LOTUS_MASTER_DATA_SYNCHRONIZATION, x -> {
			// 转参数
			String param = XxlJobHelper.getJobParam();
			MasterDataReqDto masterDataReqDto = new MasterDataReqDto();
			if (StringUtils.isNotBlank(param)) {
				masterDataReqDto = JSONUtil.toBean(param, MasterDataReqDto.class);
			}
			lotusService.addMaterial(masterDataReqDto);
		});
	}

	/**
	 * 查询需要创建调拨凭证的调拨揽件asn单
	 */
	// @Scheduled(cron = "0/3 * * * * ?")
	@XxlJob(JobCommon.JobName.JOB_LOTUS_TRANSFER_DN_SKU_VOUCHER_CREATE)
	public void transferSkuVoucherCreate() {
		this.execute(JobCommon.TaskEnum.JOB_LOTUS_TRANSFER_DN_SKU_VOUCHER_CREATE, x -> {
			lotusService.sendTransferSkuVoucherCreate();
		});
	}

	/**
	 * 请求lotus获取成本中心主数据
	 */
	@XxlJob(JobCommon.JobName.JOB_LOTUS_COST_CENTER_MASTER_DATA)
	// @Scheduled(cron = "0/3 * * * * ?")
	public void lotusCostCenterMasterData() {
		this.execute(JobCommon.TaskEnum.JOB_LOTUS_COST_CENTER_MASTER_DATA, x -> {
			// 转参数
			String param = XxlJobHelper.getJobParam();
			CostCenterMasterDataDTO costCenterMasterDataDTO = new CostCenterMasterDataDTO();
			if (StringUtils.isNotBlank(param)) {
				costCenterMasterDataDTO = JSONUtil.toBean(param, CostCenterMasterDataDTO.class);
			}
			if (StringUtils.isNotBlank(costCenterMasterDataDTO.getCompanyCode())) {
				costCenterMasterDataService.getCostCenterMaster(costCenterMasterDataDTO);
			}
		});
	}

	@XxlJob(JobCommon.JobName.JOB_LOTUS_DNORDER_RETURN_RESPONSED)
	public void returnDnOrderResponsed() {
		this.execute(JobCommon.TaskEnum.JOB_LOTUS_DNORDER_RETURN_RESPONSED, x -> {
			try {
				R result = remoteBizRecordService.jobTrigger(ApiType.DN_ORDER_RETURN.name(), LotusConstant.CLIENT_CODE,
						SecurityConstants.FROM_IN);
				if (result.getCode() != CommonConstants.SUCCESS) {
					log.info(StrUtil.format("DnOrder退货单回传SAP客户失败重试 调用失败,错误信息:{}", result.getMsg()));
				}
			}
			catch (Exception e) {
				log.error(StrUtil.format("DnOrder退货单回传SAP客户失败重试 调用失败,错误信息:{}", e.getMessage()));
			}
		});
	}

	@XxlJob(JobCommon.JobName.JOB_LOTUS_DNORDER_RESPONSED)
	public void dnOrderResponsed() {
		this.execute(JobCommon.TaskEnum.JOB_LOTUS_DNORDER_RESPONSED, x -> {

			try {
				R result = remoteBizRecordService.jobTrigger(ApiType.DN_ORDER_STATUS_OUTBOUND_SYNC_TO_SAP.name(),
						LotusConstant.CLIENT_CODE, SecurityConstants.FROM_IN);
				if (result.getCode() != CommonConstants.SUCCESS) {
					log.info(StrUtil.format("DnOrder向SAP同步发运信息 调用失败,错误信息:{}", result.getMsg()));
				}
			}
			catch (Exception e) {
				log.error(StrUtil.format("DnOrder向SAP同步发运信息 调用失败,错误信息:{}", e.getMessage()));
			}

			try {
				R result = remoteBizRecordService.jobTrigger(
						ApiType.DN_ORDER_STATUS_OUTBOUND_SYNC_TO_LCMS_RELOCATION.name(), LotusConstant.CLIENT_CODE,
						SecurityConstants.FROM_IN);
				if (result.getCode() != CommonConstants.SUCCESS) {
					log.info(StrUtil.format("DnOrder向LCMS同步发运信息(移库单类型) 调用失败,错误信息:{}", result.getMsg()));
				}
			}
			catch (Exception e) {
				log.error(StrUtil.format("DnOrder向LCMS同步发运信息(移库单类型) 调用失败,错误信息:{}", e.getMessage()));
			}

			try {
				R result = remoteBizRecordService.jobTrigger(ApiType.DN_ORDER_STATUS_POD_SYNC_RELOCATION.name(),
						LotusConstant.CLIENT_CODE, SecurityConstants.FROM_IN);
				if (result.getCode() != CommonConstants.SUCCESS) {
					log.info(StrUtil.format("DnOrder向LCMS同步到货信息(移库单类型) 调用失败,错误信息:{}", result.getMsg()));
				}
			}
			catch (Exception e) {
				log.error(StrUtil.format("DnOrder向LCMS同步到货信息(移库单类型) 调用失败,错误信息:{}", e.getMessage()));
			}

		});
	}

}
