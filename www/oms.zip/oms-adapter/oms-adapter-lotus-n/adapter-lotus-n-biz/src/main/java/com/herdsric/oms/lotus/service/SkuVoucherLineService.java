package com.herdsric.oms.lotus.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.herdsric.oms.lotus.entity.SkuVoucherLine;

/**
 * @author Herdsric
 * @description 针对表【os_sku_voucher_line】的数据库操作Service
 * @createDate 2022-11-02 14:43:16
 */
public interface SkuVoucherLineService extends IService<SkuVoucherLine> {

}
