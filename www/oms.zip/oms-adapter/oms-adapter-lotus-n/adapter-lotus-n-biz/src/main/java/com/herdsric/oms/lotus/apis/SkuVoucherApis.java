package com.herdsric.oms.lotus.apis;

import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.common.security.annotation.Inner;
import com.herdsric.oms.lotus.dto.AsnOrderDTO;
import com.herdsric.oms.lotus.dto.sap.SkuVoucherDto;
import com.herdsric.oms.lotus.entity.SkuVoucher;
import com.herdsric.oms.lotus.service.SkuVoucherService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.apache.commons.compress.utils.Lists;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;

/**
 * @Author : liangzhenlei
 * @Date : 2022/9/16 17:47
 */
@RestController
@RequiredArgsConstructor
@RequestMapping("/apis/skuVoucher")
@Tag(name = "物料凭证对外接口")
public class SkuVoucherApis {

	private final SkuVoucherService skuVoucherService;

	/**
	 * 物料凭证创建并发送--oms调用
	 * @param skuVoucherDto
	 * @return R
	 */
	@Operation(summary = "物料凭证创建", description = "物料凭证创建")
	@PostMapping("/add")
	@Inner
	public R skuVoucherCreate(@RequestBody @Valid SkuVoucherDto skuVoucherDto) {
		return skuVoucherService.skuVoucherCreate(skuVoucherDto);
	}

}
