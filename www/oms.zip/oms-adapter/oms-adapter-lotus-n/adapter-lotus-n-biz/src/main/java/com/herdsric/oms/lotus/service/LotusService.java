package com.herdsric.oms.lotus.service;

import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.lotus.dto.MasterDataReqDto;
import com.herdsric.oms.lotus.dto.sap.LoutsStockVo;

/**
 * @author tyy
 * @createDate 2024/4/25 14:02
 */
public interface LotusService {

	R addMaterial(MasterDataReqDto masterDataReqDto);

	boolean sendTransferSkuVoucherCreate();

	R checkOfInventory(LoutsStockVo loutsStockVo);

}
