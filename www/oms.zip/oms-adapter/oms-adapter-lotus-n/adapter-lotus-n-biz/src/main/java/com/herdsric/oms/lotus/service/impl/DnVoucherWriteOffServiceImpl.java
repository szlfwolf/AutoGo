package com.herdsric.oms.lotus.service.impl;

import cn.hutool.core.collection.ListUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.herdsric.oms.common.core.constant.CommonConstants;
import com.herdsric.oms.common.core.constant.SecurityConstants;
import com.herdsric.oms.common.core.constant.enums.ExtendPropsEnum;
import com.herdsric.oms.common.core.exception.OmsBusinessException;
import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.lotus.api.RemoteLotusDnOrderDetailService;
import com.herdsric.oms.lotus.common.LotusConstant;
import com.herdsric.oms.lotus.common.SkuVoucherHandle;
import com.herdsric.oms.lotus.dto.DnOrderVo;
import com.herdsric.oms.lotus.dto.sap.DnVoucherWriteOffDto;
import com.herdsric.oms.lotus.dto.sap.DnVoucherWriteOffExcelDto;
import com.herdsric.oms.lotus.dto.sap.LotusDnLineBackDTO;
import com.herdsric.oms.lotus.entity.DnVoucherWriteOff;
import com.herdsric.oms.lotus.enums.ConvertUntilEnum;
import com.herdsric.oms.lotus.enums.DnVoucherWriteOffStatusEnum;
import com.herdsric.oms.lotus.mapper.DnVoucherWriteOffMapper;
import com.herdsric.oms.lotus.service.DnVoucherWriteOffService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import java.io.IOException;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author Herdsric
 * @description 针对表【lotus_dn_voucher_write_off】的数据库操作Service实现
 * @createDate 2022-12-15 11:31:09
 */
@Service
@AllArgsConstructor()
@Slf4j
public class DnVoucherWriteOffServiceImpl extends ServiceImpl<DnVoucherWriteOffMapper, DnVoucherWriteOff>
		implements DnVoucherWriteOffService {

	private final Validator validator;

	private final SkuVoucherHandle skuVoucherHandle;

	private final RemoteLotusDnOrderDetailService remoteLotusDnOrderDetailService;

	/**
	 * dn物料凭证冲销
	 * @param dnVoucherWriteOffDto 参数
	 * @param clientCode 客户code
	 * @return
	 */
	@Override
	public R dnWriteOff(DnVoucherWriteOffDto dnVoucherWriteOffDto, String clientCode) {
		return dnVoucherWriteOff(ListUtil.toList(dnVoucherWriteOffDto), clientCode);
	}

	/**
	 * dn物料凭证冲销ByExcel
	 * @param file
	 * @param clientCode 客户code
	 * @return
	 */
	@Override
	public R uploadDnWriteOffByExcel(MultipartFile file, String clientCode) {
		List<DnVoucherWriteOffExcelDto> dnVoucherWriteOffExcelDtoList;
		try {
			// 读取文
			dnVoucherWriteOffExcelDtoList = EasyExcel.read(file.getInputStream()).head(DnVoucherWriteOffExcelDto.class)
					.sheet().doReadSync();
		}
		catch (IOException e) {
			e.printStackTrace();
			return R.failed("解析文件异常");
		}
		if (CollectionUtils.isEmpty(dnVoucherWriteOffExcelDtoList)) {
			return R.ok();
		}
		List<DnVoucherWriteOffDto> dnVoucherWriteOffDtoList = new ArrayList<>(dnVoucherWriteOffExcelDtoList.size());
		// 校验excel参数
		Set<ConstraintViolation<DnVoucherWriteOffExcelDto>> sets = new HashSet<>();
		for (DnVoucherWriteOffExcelDto item : dnVoucherWriteOffExcelDtoList) {
			sets = validator.validate(item);
			if (!sets.isEmpty()) {
				return R.failed(sets.stream().findFirst().map(ConstraintViolation::getMessage).get());
			}
			// 转换为Dto
			DnVoucherWriteOffDto dnVoucherWriteOffDto = new DnVoucherWriteOffDto();
			dnVoucherWriteOffDto.setDnOrder(item.getDnOrder());
			dnVoucherWriteOffDto.setResendDn(item.getResendDn());
			dnVoucherWriteOffDtoList.add(dnVoucherWriteOffDto);
		}

		return dnVoucherWriteOff(dnVoucherWriteOffDtoList, clientCode);
	}

	/**
	 * dn凭证冲销
	 * @param dnVoucherWriteOffDtoList
	 * @param clientCode
	 * @return
	 */
	private R dnVoucherWriteOff(List<DnVoucherWriteOffDto> dnVoucherWriteOffDtoList, String clientCode) {
		List<String> dnOrderList = dnVoucherWriteOffDtoList.stream().map(DnVoucherWriteOffDto::getDnOrder).distinct()
				.collect(Collectors.toList());
		if (dnVoucherWriteOffDtoList.size() != dnOrderList.size()) {
			return R.failed("包含重复订单，请自行校验");
		}

		R<List<DnOrderVo>> result = remoteLotusDnOrderDetailService.getDnOrderDetail(dnOrderList, clientCode,
				SecurityConstants.FROM_IN);

		if (result == null || result.getCode() == CommonConstants.FAIL) {
			throw new OmsBusinessException("6006", StrUtil.format("获取DN详情信息异常,异常原因: {}"), result.getMsg().toString());
		}

		List<DnOrderVo> data = result.getData();
		if (CollectionUtils.isEmpty(data)) {
			return R.failed("没有根据订单号查到dn订单信息");
		}
		List<String> outOrderNumList = data.stream().map(DnOrderVo::getOrderNo).collect(Collectors.toList());
		boolean flag = false;
		StringBuilder errorMessage = new StringBuilder("没有找到订单信息,订单号为:");
		for (String dnOrder : dnOrderList) {
			if (!outOrderNumList.contains(dnOrder)) {
				errorMessage.append(dnOrder).append("、");
				flag = true;
			}
		}
		if (flag) {
			return R.failed(errorMessage.deleteCharAt(errorMessage.length() - 1).toString());
		}

		// 校验是否已经冲销
		List<DnVoucherWriteOff> dnVoucherWriteOffList = this.list(Wrappers.<DnVoucherWriteOff>lambdaQuery()
				.in(DnVoucherWriteOff::getBzOutOrderNo, dnOrderList).eq(DnVoucherWriteOff::getClientCode, clientCode)
				.eq(DnVoucherWriteOff::getStatus, DnVoucherWriteOffStatusEnum.ALREADY_WRITE_OFF.getValue())
				.select(DnVoucherWriteOff::getBzOutOrderNo));
		if (CollectionUtils.isNotEmpty(dnVoucherWriteOffList)) {
			return R.failed("订单号：" + dnVoucherWriteOffList.stream().map(DnVoucherWriteOff::getBzOutOrderNo)
					.collect(Collectors.joining("、")) + "已创建过订单冲销，不可重复冲销!");
		}
		List<DnVoucherWriteOff> dnWriteOffList = buildAsnVoucherWriteOff(dnVoucherWriteOffDtoList, dnOrderList,
				clientCode, data);
		skuVoucherHandle.buildSkuVoucherDnWriteOffReq(dnWriteOffList, data);
		List<DnVoucherWriteOff> sendSuccessList = dnWriteOffList.stream()
				.filter(e -> DnVoucherWriteOffStatusEnum.ALREADY_WRITE_OFF.getValue().equals(e.getStatus()))
				.collect(Collectors.toList());
		StringBuilder message = new StringBuilder();
		if (CollectionUtils.isNotEmpty(sendSuccessList)) {
			// 保存入数据库
			dnWrittenOffInsert(sendSuccessList);
			message.append("发送冲销成功的DN Order:   ").append(
					sendSuccessList.stream().map(DnVoucherWriteOff::getBzOutOrderNo).collect(Collectors.joining("、")))
					.append("\r\n");
		}
		List<DnVoucherWriteOff> sendFailList = dnWriteOffList.stream()
				.filter(e -> !DnVoucherWriteOffStatusEnum.ALREADY_WRITE_OFF.getValue().equals(e.getStatus()))
				.collect(Collectors.toList());
		if (CollectionUtils.isNotEmpty(sendFailList)) {
			message.append("发送冲销失败的DN Order:   ")
					.append(sendFailList.stream()
							.map(e -> e.getBzOutOrderNo() + " 失败原因:  " + e.getResponseContent() + "\r\n")
							.collect(Collectors.joining("、")));
			return R.failed(message.toString());
		}
		return R.ok(message.toString()).setMsg(message.toString());
	}

	/**
	 * dn保存
	 * @param sendSuccessList
	 */
	@Transactional(rollbackFor = Exception.class)
	public boolean dnWrittenOffInsert(List<DnVoucherWriteOff> sendSuccessList) {
		return this.saveBatch(sendSuccessList);
	}

	/**
	 * 组装dn料凭证撤销对象
	 * @param dnVoucherWriteOffDtoList 参数集合
	 * @param clientCode 客户编码
	 * @return
	 */
	private List<DnVoucherWriteOff> buildAsnVoucherWriteOff(List<DnVoucherWriteOffDto> dnVoucherWriteOffDtoList,
			List<String> dnOrderList, String clientCode, List<DnOrderVo> dnOrderVo) {

		// 查询需要重发的行信息并处理
		List<String> dnNos = dnVoucherWriteOffDtoList.stream()
				.filter(s -> CommonConstants.STATUS_DEL.equals(s.getResendDn())).map(s -> s.getDnOrder())
				.collect(Collectors.toList());
		if (CollectionUtils.isNotEmpty(dnNos)) {
			return isResend(dnNos, dnOrderList, clientCode, dnVoucherWriteOffDtoList, dnOrderVo);
		}
		List<String> dns = dnVoucherWriteOffDtoList.stream()
				.filter(s -> CommonConstants.STATUS_NORMAL.equals(s.getResendDn())).map(s -> s.getDnOrder())
				.collect(Collectors.toList());
		return isResend(dns, dnOrderList, clientCode, dnVoucherWriteOffDtoList, dnOrderVo);
	}

	public List<DnVoucherWriteOff> isResend(List<String> dnNos, List<String> dnOrderList, String clientCode,
			List<DnVoucherWriteOffDto> dnVoucherWriteOffDtoList, List<DnOrderVo> dnOrderVo) {
		String currentTime = DateUtil.now();
		List<DnVoucherWriteOff> dnVoucherWriteOffList = new ArrayList<>();
		R<List<DnOrderVo>> result = remoteLotusDnOrderDetailService.getDnAndWarehouse(dnOrderList, clientCode,
				SecurityConstants.FROM_IN);

		List<DnOrderVo> dnList = result.getData();

		Map<String, DnOrderVo> dnMap = dnList.stream()
				.collect(Collectors.toMap(DnOrderVo::getOrderNo, Function.identity(), (key1, key2) -> key2));

		List<LotusDnLineBackDTO> lotusDnLineList = new ArrayList<>();
		for (DnOrderVo orderVo : dnOrderVo) {
			for (DnOrderVo.OrderLine orderLine : orderVo.getOrderLineList()) {
				LotusDnLineBackDTO lotusDnLineBackDTO = new LotusDnLineBackDTO();
				lotusDnLineBackDTO.setOrderNo(orderVo.getOrderNo());
				lotusDnLineBackDTO.setWMSITEM(orderLine.getLineNo());
				lotusDnLineBackDTO.setMATNR(orderLine.getPartNumber());
				lotusDnLineBackDTO.setERFMG(String.valueOf(orderLine.getNum()));
				lotusDnLineBackDTO.setERFME(orderLine.getUnit());
				lotusDnLineBackDTO.setExtendProps(orderLine.getLineExtendProp());
				lotusDnLineList.add(lotusDnLineBackDTO);
			}
		}

		for (LotusDnLineBackDTO lotusDnLineBackDTO : lotusDnLineList) {
			JSONObject lineJsonObject = JSONObject.parseObject(lotusDnLineBackDTO.getExtendProps());
			// 工厂
			lotusDnLineBackDTO.setWERKS(LotusConstant.LOTUS_FACTORY);
			lotusDnLineBackDTO.setASNITEM(lotusDnLineBackDTO.getWMSITEM());
			// sap订单号和行号
			if (ObjectUtils.isNotEmpty(lineJsonObject)) {
				lotusDnLineBackDTO.setVGBEL(lineJsonObject.getString(ExtendPropsEnum.LOTUS_SAP_ORDER_NO.getValue()));
				lotusDnLineBackDTO
						.setVGPOS(lineJsonObject.getString(ExtendPropsEnum.LOTUS_SAP_ORDER_LINENO.getValue()));
			}
			// 单位PCS转EA
			lotusDnLineBackDTO.setERFME(ConvertUntilEnum.getValueByKey(lotusDnLineBackDTO.getERFME()));
			// 交货完成标记
			lotusDnLineBackDTO.setELIKZ(LotusConstant.ELIKZ);
			// 库存地点放入
			if (StringUtils.isBlank(dnMap.get(lotusDnLineBackDTO.getOrderNo()).getRemark())) {
				throw new RuntimeException("订单{" + lotusDnLineBackDTO.getOrderNo() + "}的仓库地点为空");
			}
			JSONObject jsonObject = JSONObject.parseObject(dnMap.get(lotusDnLineBackDTO.getOrderNo()).getRemark());
			if (ObjectUtils.isEmpty(jsonObject)
					|| StringUtils.isBlank(jsonObject.getString(ExtendPropsEnum.LOTUS_ADDRESS_NO.value))) {
				throw new RuntimeException("订单{" + lotusDnLineBackDTO.getOrderNo() + "}的仓库地点"
						+ ExtendPropsEnum.LOTUS_ADDRESS_NO.value + " is not config");
			}
			lotusDnLineBackDTO.setLGORT(jsonObject.getString(ExtendPropsEnum.LOTUS_ADDRESS_NO.value));
		}
		for (DnVoucherWriteOffDto item : dnVoucherWriteOffDtoList) {
			DnVoucherWriteOff dnVoucherWriteOff = new DnVoucherWriteOff().setClientCode(clientCode)
					.setSendWriteOffTime(currentTime).setSendWriteOff(CommonConstants.STATUS_NORMAL)
					.setResendDn(item.getResendDn()).setBzOutOrderNo(item.getDnOrder())
					.setDnNo(dnMap.get(item.getDnOrder()).getDnNo())
					.setWarehouseCode(dnMap.get(item.getDnOrder()).getWarehouseCode())
					.setStatus(DnVoucherWriteOffStatusEnum.NOT_SEND.getValue());
			// 根据order过滤
			List<LotusDnLineBackDTO> collect = lotusDnLineList.stream()
					.filter(s -> item.getDnOrder().equals(s.getOrderNo())).collect(Collectors.toList());
			dnVoucherWriteOff.setItems(collect);
			dnVoucherWriteOffList.add(dnVoucherWriteOff);
		}
		return dnVoucherWriteOffList;
	}

}
