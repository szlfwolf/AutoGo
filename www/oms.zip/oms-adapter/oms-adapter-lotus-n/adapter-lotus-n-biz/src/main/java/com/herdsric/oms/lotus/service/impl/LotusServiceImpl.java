package com.herdsric.oms.lotus.service.impl;

import cn.hutool.core.convert.Convert;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.lang.Assert;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.json.JSONUtil;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.dtflys.forest.http.ForestResponse;
import com.google.common.collect.Lists;
import com.herdsric.oms.common.client.masterdata.domain.SkuDm;
import com.herdsric.oms.common.core.constant.CommonConstants;
import com.herdsric.oms.common.core.constant.SecurityConstants;
import com.herdsric.oms.common.core.constant.enums.ExtendPropsEnum;
import com.herdsric.oms.common.core.constant.enums.SkuVoucherLineMoveTypeEnum;
import com.herdsric.oms.common.core.constant.enums.SkuVoucherOperateTypeEnum;
import com.herdsric.oms.common.core.constant.enums.SkuVoucherStatusEnum;
import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.common.feign.client.RemoteSkuService;
import com.herdsric.oms.lotus.api.RemoteSkuTransferRelationService;
import com.herdsric.oms.lotus.common.LotusConstant;
import com.herdsric.oms.lotus.common.MastDataHandle;
import com.herdsric.oms.lotus.common.SendLotusApi;
import com.herdsric.oms.lotus.dto.LotusCommonReqDto;
import com.herdsric.oms.lotus.dto.LotusCommonResDto;
import com.herdsric.oms.lotus.dto.MasterDataReqDto;
import com.herdsric.oms.lotus.dto.MasterDataResListDto;
import com.herdsric.oms.lotus.dto.sap.*;
import com.herdsric.oms.lotus.entity.SkuVoucher;
import com.herdsric.oms.lotus.service.LotusService;
import com.herdsric.oms.lotus.service.SkuVoucherService;
import lombok.extern.slf4j.Slf4j;
import net.dreamlu.mica.core.utils.CollectionUtil;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.ListUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author tyy
 * @createDate 2024/4/25 14:02
 */
@Slf4j
@Service
public class LotusServiceImpl implements LotusService {

	@Autowired
	private MastDataHandle mastDataHandle;

	@Autowired
	private SkuVoucherService skuVoucherService;

	@Autowired
	private RemoteSkuService remoteSkuService;

	@Autowired
	private RemoteSkuTransferRelationService remoteSkuTransferRelationService;

	@Autowired
	private SendLotusApi sendLotusApi;

	@Override
	public R addMaterial(MasterDataReqDto reqDto) {
		try {
			List<MasterDataResListDto> masterDataRes = mastDataHandle.reqMasterData(reqDto);
			if (CollectionUtils.isEmpty(masterDataRes)) {
				return R.ok("No master data");
			}
			// 数据处理
			List<SkuDm> skuDTOList = mastDataHandle.getSyncSkuData(masterDataRes);
			if (CollectionUtils.isEmpty(skuDTOList)) {
				return R.ok("No master data");
			}
			// 请求oms
			List<List<SkuDm>> skus = ListUtils.partition(skuDTOList, 100);
			for (List<SkuDm> skuDtoList : skus) {
				try {
					R result = remoteSkuService.saveBatch(skuDtoList, LotusConstant.CLIENT_CODE,
							SecurityConstants.FROM_IN);
					// 结果判断
					if (ObjectUtils.isEmpty(result) || CommonConstants.SUCCESS != result.getCode()) {
						log.info("OMS对主数据下发处理失败的sku:{}", skuDtoList);
						continue;
					}
					log.info("OMS对主数据下发处理成功");
				}
				catch (Exception e) {
					log.error("处理Lotus主数据下发发生错误!", e);
					continue;
				}
			}
		}
		catch (Exception e) {
			log.error("处理Lotus主数据下发发生错误!", e);
			return R.failed("处理Lotus主数据下发发生错误!,错误信息:" + e);
		}
		return R.ok("OMS对主数据下发处理成功");
	}

	/**
	 * 库存调拨回传-创建物料凭证
	 * @return
	 */
	@Override
	public boolean sendTransferSkuVoucherCreate() {
		try {
			String lastTime = null;
			// 查询调拨单的最后保存的揽件时间
			SkuVoucher SkuVoucher = skuVoucherService.getOne(
					Wrappers.<SkuVoucher>query().eq("operate_type", SkuVoucherOperateTypeEnum.STOCK_TRANSFER.getValue())
							.select("max(create_time) as createTime"));

			// 如果不为空最后保存的揽件时间向前加一天，方便获取增量数据，避免全量查询
			if (ObjectUtils.isNotEmpty(SkuVoucher) && StringUtils.isNotBlank(SkuVoucher.getCreateTime())) {
				lastTime = DateUtil
						.formatDateTime(DateUtil.offsetDay(DateUtil.parseDateTime(SkuVoucher.getCreateTime()), -1));
			}

			List<com.herdsric.oms.lotus.entity.SkuVoucher> skuVoucherList = skuVoucherService
					.list(Wrappers.<SkuVoucher>lambdaQuery()
							.eq(com.herdsric.oms.lotus.entity.SkuVoucher::getClientCode, LotusConstant.CLIENT_CODE)
							.eq(com.herdsric.oms.lotus.entity.SkuVoucher::getOperateType, LotusConstant.allocation)
							.gt(com.herdsric.oms.lotus.entity.SkuVoucher::getCreateTime, lastTime));

			List<String> orderNo = skuVoucherList.stream().map(x -> x.getOrderNo()).collect(Collectors.toList());

			SkuTransferRelationDto skuTransferRelationDto = new SkuTransferRelationDto();
			skuTransferRelationDto.setClientCode(LotusConstant.CLIENT_CODE);
			skuTransferRelationDto.setLastTime(lastTime);
			skuTransferRelationDto.setAsnNo(orderNo);
			// 获取不存在凭证的调拨单详情信息
			List<SkuTransferDto> dnTransferDetailDto = remoteSkuTransferRelationService
					.getSkuTransferList(skuTransferRelationDto, LotusConstant.CLIENT_CODE, SecurityConstants.FROM_IN);

			// 获取不存在凭证的调拨单详情信息
			if (CollectionUtils.isEmpty(dnTransferDetailDto)) {
				log.info("No Need transfer Type SkuVoucherCreate  job");
				return true;
			}

			R<List<Warehouse>> warehouseList = remoteSkuTransferRelationService
					.getWarehouseList(LotusConstant.CLIENT_CODE, SecurityConstants.FROM_IN);

			List<Warehouse> list = warehouseList.getData();

			if (CollectionUtils.isEmpty(list)) {
				log.info("仓库列表为空");
				return true;
			}
			// 添加凭证头信息
			for (SkuTransferDto skuTransferDto : dnTransferDetailDto) {
				String transferOutWarehouseCode = null;
				String transferInWarehouseCode = null;
				for (Warehouse warehouse : list) {
					if (ObjectUtils.isEmpty(warehouse) || StringUtils.isBlank(warehouse.getExtendProps())
							|| StringUtils.isBlank(warehouse.getWarehouseCode())
							|| !StringUtils.equalsAny(warehouse.getWarehouseCode(),
									skuTransferDto.getTransferOutWarehouseCode(),
									skuTransferDto.getTransferInWarehouseCode())) {
						continue;
					}
					JSONObject jsonObject = JSONObject.parseObject(warehouse.getExtendProps());
					if (ObjectUtils.isEmpty(jsonObject)
							|| StringUtils.isBlank(jsonObject.getString(ExtendPropsEnum.LOTUS_ADDRESS_NO.value))) {
						continue;
					}
					if (skuTransferDto.getTransferOutWarehouseCode().equals(warehouse.getWarehouseCode())) {
						transferOutWarehouseCode = jsonObject.getString(ExtendPropsEnum.LOTUS_ADDRESS_NO.value);
					}
					else if (skuTransferDto.getTransferInWarehouseCode().equals(warehouse.getWarehouseCode())) {
						transferInWarehouseCode = jsonObject.getString(ExtendPropsEnum.LOTUS_ADDRESS_NO.value);
					}
				}
				if (StringUtils.isBlank(transferOutWarehouseCode) || StringUtils.isBlank(transferInWarehouseCode)) {
					log.info("调拨单dn:{} 出仓或入仓的扩展字段没配置", skuTransferDto.getAsnNo());
					continue;
				}
				// 创建时间和揽件出库时间保持一致
				String currentTime = skuTransferDto.getInBoundedTime();
				SkuVoucherDto skuVoucherDto = new SkuVoucherDto()
						.setOperateType(SkuVoucherOperateTypeEnum.STOCK_TRANSFER.getValue())
						.setStatus(SkuVoucherStatusEnum.NOT_SEND.getValue())
						.setWarehouseCode(skuTransferDto.getTransferOutWarehouseCode())
						.setClientCode(CommonConstants.COMPANY_CODE_LOTUS).setOrderNo(skuTransferDto.getAsnNo())
						.setCreateTime(currentTime).setCreateBy(LotusConstant.LOTUS_SYSTEM).setUpdateTime(currentTime)
						.setUpdateBy(LotusConstant.LOTUS_SYSTEM);
				// 添加凭证行信息
				List<SkuVoucherLineDto> skuVoucherLineList = Lists.newArrayList();
				for (SkuTransferLineDto skuTransferLineDto : skuTransferDto.getSkuTransferLineDtoList()) {
					SkuVoucherLineDto skuVoucherLine = new SkuVoucherLineDto();
					skuVoucherLine.setLineNo(skuTransferLineDto.getLineNo())
							.setPartNumber(skuTransferLineDto.getPartNumber()).setAddressNo(transferOutWarehouseCode)
							.setReceiptAddressNo(transferInWarehouseCode).setBatchNo(skuTransferDto.getAsnNo())
							.setNum(Convert.toBigDecimal(skuTransferLineDto.getNum()))
							.setUnit(skuTransferLineDto.getUnit()).setSkuVoucherId(skuVoucherDto.getId())
							.setMoveType(SkuVoucherLineMoveTypeEnum.INVENTORY_TRANSFER.getValue())
							.setCreateTime(currentTime).setCreateBy(LotusConstant.LOTUS_SYSTEM)
							.setUpdateTime(currentTime).setUpdateBy(LotusConstant.LOTUS_SYSTEM);
					skuVoucherLineList.add(skuVoucherLine);
				}
				skuVoucherDto.setSkuVoucherLineDtoList(skuVoucherLineList);

				skuVoucherService.skuVoucherCreate(skuVoucherDto);
				log.info("调拨回传-创建物料凭执行结束。。。");
			}
		}
		catch (Exception e) {
			log.error("调拨回传-创建物料凭证出现异常:{}", e);
			return false;
		}
		return true;
	}

	@Override
	public R checkOfInventory(LoutsStockVo loutsStockVo) {
		ForestResponse<LotusCommonResDto<List<CheckOfInventoryDTO>>> ForestResponse = null;
		try {
			List<CheckOfInventoryDTO> checkOfInventoryDTOS = new ArrayList<>();
			// 构造请求参数
			CheckOfInventoryDTO inventoryDTO = new CheckOfInventoryDTO();
			if (CollectionUtil.isEmpty(loutsStockVo.getPartNumberList())) {
				// 零件号为空,设置工厂,仓库地点
				inventoryDTO.setLgort(loutsStockVo.getWarehouseExtendProps());
				inventoryDTO.setWerks(LotusConstant.LOTUS_FACTORY);
				checkOfInventoryDTOS.add(inventoryDTO);
			}
			else {
				for (String s : loutsStockVo.getPartNumberList()) {
					CheckOfInventoryDTO checkOfInventoryDTO = ObjectUtil.cloneByStream(inventoryDTO);
					checkOfInventoryDTO.setLgort(loutsStockVo.getWarehouseExtendProps());
					checkOfInventoryDTO.setMatnr(s);
					checkOfInventoryDTO.setWerks(LotusConstant.LOTUS_FACTORY);
					checkOfInventoryDTOS.add(checkOfInventoryDTO);
				}
			}
			// 接收partNumbers
			ForestResponse = sendLotusApi
					.checkOfInventory(new LotusCommonReqDto().setRequestData(checkOfInventoryDTOS));
			Assert.isTrue(ObjectUtils.isNotEmpty(ForestResponse.getResult()), "调用lotus接口失败！！！ 返回结果:{}", ForestResponse);
			log.info("库存校验返回结果:{}", JSONUtil.parse(ForestResponse.getResult().getResponseData()));
		}
		catch (Exception e) {
			log.info("lotus库存效验发生未知异常:{}", e.getMessage());
			return R.failed().setMsg(e.getMessage());
		}
		return R.ok().setData(ForestResponse.getResult().getResponseData());
	}

}
