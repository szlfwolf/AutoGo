package com.herdsric.oms.lotus.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.lotus.dto.sap.DnVoucherWriteOffDto;
import com.herdsric.oms.lotus.entity.DnVoucherWriteOff;
import org.springframework.web.multipart.MultipartFile;

/**
 * @author Herdsric
 * @description 针对表【lotus_dn_voucher_write_off】的数据库操作Service
 * @createDate 2022-12-15 11:31:09
 */
public interface DnVoucherWriteOffService extends IService<DnVoucherWriteOff> {

	/**
	 * dn物料凭证冲销
	 * @param dnVoucherWriteOffDto 参数
	 * @param clientCode 客户code
	 * @return
	 */
	R dnWriteOff(DnVoucherWriteOffDto dnVoucherWriteOffDto, String clientCode);

	/**
	 * dn物料凭证冲销ByExcel
	 * @param file
	 * @param clientCode 客户code
	 * @return
	 */
	R uploadDnWriteOffByExcel(MultipartFile file, String clientCode);

}
