package com.herdsric.oms.lotus.jobs.common;

import cn.hutool.core.util.StrUtil;
import com.herdsric.oms.common.job.common.JobTask;

public class JobCommon {

	private static final String JOB_KEY_PREFIX = "LOTUS-JOB-TASK";

	public static class JobName {

		/**
		 * 拉取lotus主数据同步到OMS
		 */
		public static final String JOB_LOTUS_MASTER_DATA_SYNCHRONIZATION = "lotusMasterDataSynchronization";

		/**
		 * 调拨asn发送给lotus
		 */
		public static final String JOB_LOTUS_TRANSFER_DN_SKU_VOUCHER_CREATE = "lotusTransferDnSkuVoucherCreate";

		/**
		 * 请求lotus获取成本中心主数据
		 */
		public static final String JOB_LOTUS_COST_CENTER_MASTER_DATA = "lotusCostCenterMasterData";

		/***
		 * DnOrder回传客户重试 退货单
		 */
		public static final String JOB_LOTUS_DNORDER_RETURN_RESPONSED = "lotusDnOrderReturnResponsed";

		/***
		 * DnOrder回传客户重试
		 */
		public static final String JOB_LOTUS_DNORDER_RESPONSED = "lotuDnOrderResponsed";

	}

	public enum TaskEnum implements JobTask {

		/**
		 * 拉取lotus主数据同步到OMS
		 */
		JOB_LOTUS_MASTER_DATA_SYNCHRONIZATION(JobName.JOB_LOTUS_MASTER_DATA_SYNCHRONIZATION, 30, "拉取lotus主数据同步到OMS"),
		/**
		 * 调拨dn揽件发送给lotus
		 */
		JOB_LOTUS_TRANSFER_DN_SKU_VOUCHER_CREATE(JobName.JOB_LOTUS_TRANSFER_DN_SKU_VOUCHER_CREATE, 30,
				"调拨dn揽件发送给lotus"),
		/**
		 * 请求lotus获取成本中心主数据
		 */
		JOB_LOTUS_COST_CENTER_MASTER_DATA(JobName.JOB_LOTUS_COST_CENTER_MASTER_DATA, 30, "请求lotus获取成本中心主数据"),

		/***
		 * DnOrderResponsed退货单回传客户重试
		 */
		JOB_LOTUS_DNORDER_RETURN_RESPONSED(JobName.JOB_LOTUS_DNORDER_RETURN_RESPONSED, 30, "DnOrder退货单回传客户重试"),
		/***
		 * DnOrder回传客户
		 */
		JOB_LOTUS_DNORDER_RESPONSED(JobName.JOB_LOTUS_DNORDER_RESPONSED, 30, "DnOrder回传客户重试");

		public String name;

		public int expireTime;

		public String desc;

		TaskEnum(String name, int expireTime, String desc) {
			this.name = name;
			this.expireTime = expireTime;
			this.desc = desc;
		}

		public String getDesc() {
			return StrUtil.concat(true, this.desc);
		}

		@Override
		public String getName() {
			return name;
		}

		@Override
		public int expireTime() {
			return expireTime;
		}

		@Override
		public String getDescription() {
			return desc;
		}

		public String getKey() {
			return StrUtil.concat(true, JOB_KEY_PREFIX, this.name);
		}

	}

}
