/*
 *    Copyright (c) 2018-2025, lengleng All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * Neither the name of the oms4cloud.com developer nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 * Author: lengleng (wangiegie@gmail.com)
 */

package com.herdsric.oms.lotus.controller;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.google.common.net.HttpHeaders;
import com.herdsric.oms.common.core.constant.enums.SkuVoucherOperateTypeEnum;
import com.herdsric.oms.common.core.constant.enums.SkuVoucherStatusEnum;
import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.lotus.entity.SkuVoucher;
import com.herdsric.oms.lotus.service.SkuVoucherService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

/**
 * 物料凭证
 *
 * @author dzx
 * @date 2022-11-03 16:43:48
 */
@RestController
@RequiredArgsConstructor
@RequestMapping("/skuVoucher")
@Tag(name = "物料凭证")
@SecurityRequirement(name = HttpHeaders.AUTHORIZATION)
public class SkuVoucherController {

	private final SkuVoucherService skuVoucherService;

	/**
	 * 分页查询
	 * @param page 分页对象
	 * @param skuVoucher s物料凭证
	 * @return
	 */
	@Operation(summary = "分页查询", description = "分页查询")
	@GetMapping("/page")
	@PreAuthorize("@pms.hasPermission('sku_voucher_get')")
	public R getSkuPackagePage(Page page, SkuVoucher skuVoucher, @RequestHeader("clientCode") String clientCode) {
		if (StringUtils.isBlank(clientCode)) {
			return R.failed().setMsg("clientCode 不能为空");
		}
		Page<SkuVoucher> pageList = skuVoucherService.page(page, Wrappers.<SkuVoucher>query().lambda()
				.eq(SkuVoucher::getClientCode, clientCode)
				.eq(StringUtils.isNotBlank(skuVoucher.getStatus()), SkuVoucher::getStatus, skuVoucher.getStatus())
				.eq(StringUtils.isNotBlank(skuVoucher.getOperateType()), SkuVoucher::getOperateType,
						skuVoucher.getOperateType())
				.like(StringUtils.isNotBlank(skuVoucher.getWarehouseCode()), SkuVoucher::getWarehouseCode,
						skuVoucher.getWarehouseCode())
				.like(StringUtils.isNotBlank(skuVoucher.getOrderNo()), SkuVoucher::getOrderNo, skuVoucher.getOrderNo())
				.orderByDesc(SkuVoucher::getCreateTime));
		if (pageList == null || CollectionUtils.isEmpty(pageList.getRecords())) {
			return R.ok(pageList);
		}
		pageList.getRecords().forEach(item -> {
			item.setStatusCode(item.getStatus());
			item.setOperateType(SkuVoucherOperateTypeEnum.getNameByValue(item.getOperateType()));
			item.setStatus(SkuVoucherStatusEnum.getNameByValue(item.getStatus()));
		});
		return R.ok(pageList);
	}

	/**
	 * 通过id查询物料凭证
	 * @param id id
	 * @return R
	 */
	@Operation(summary = "通过id查询", description = "通过id查询")
	@GetMapping("/{id}")
	@PreAuthorize("@pms.hasPermission('sku_voucher_get')")
	public R getById(@PathVariable("id") Integer id) {
		SkuVoucher skuVoucher = skuVoucherService.getById(id);
		if (ObjectUtils.isNotEmpty(skuVoucher)) {
			skuVoucher.setOperateType(SkuVoucherOperateTypeEnum.getNameByValue(skuVoucher.getOperateType()));
			skuVoucher.setStatusCode(skuVoucher.getStatus());
			skuVoucher.setStatus(SkuVoucherStatusEnum.getNameByValue(skuVoucher.getStatus()));
		}
		return R.ok(skuVoucher);
	}

	/**
	 * 通过id进行凭证冲销
	 * @param id id
	 * @return R
	 */
	@Operation(summary = "通过凭证id进行凭证冲销", description = "通过id进行凭证冲销")
	@PutMapping("/skuVoucherWriteOff/{id}")
	@PreAuthorize("@pms.hasPermission('sku_voucher_send')")
	public R skuVoucherWriteOffById(@PathVariable("id") Integer id) {
		return skuVoucherService.skuVoucherWriteOffById(id);
	}

	/**
	 * 通过凭证进行凭证创建请求重发
	 * @param id id
	 * @return R
	 */
	@Operation(summary = "通过id进行凭证创建请求重发", description = "通过id进行凭证创建请求重发")
	@PutMapping("/skuVoucherCreateResend/{id}")
	@PreAuthorize("@pms.hasPermission('sku_voucher_send')")
	public R skuVoucherCreateResend(@PathVariable("id") Integer id) {
		return skuVoucherService.skuVoucherCreateResend(id);
	}

}
