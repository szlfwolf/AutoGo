/*
 *    Copyright (c) 2018-2025, lengleng All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * Neither the name of the oms4cloud.com developer nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 * Author: lengleng (wangiegie@gmail.com)
 */

package com.herdsric.oms.lotus.controller;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.google.common.net.HttpHeaders;
import com.herdsric.oms.common.core.constant.enums.SkuVoucherLineMoveTypeEnum;
import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.lotus.entity.SkuVoucherLine;
import com.herdsric.oms.lotus.service.impl.SkuVoucherLineServiceImpl;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 物料凭证行数据
 *
 * @author dzx
 * @date 2022-11-03 16:43:48
 */
@RestController
@RequiredArgsConstructor
@RequestMapping("/skuVoucherLine")
@Tag(name = "物料凭证行数据")
@SecurityRequirement(name = HttpHeaders.AUTHORIZATION)
public class SkuVoucherLineController {

	private final SkuVoucherLineServiceImpl skuVoucherLineService;

	/**
	 * 分页查询
	 * @param page 分页对象
	 * @param skuVoucherLine 物料凭证行数据
	 * @return
	 */
	@Operation(summary = "分页查询", description = "分页查询")
	@GetMapping("/page")
	@PreAuthorize("@pms.hasPermission('sku_voucher_get')")
	public R getSkuPackagePage(Page page, SkuVoucherLine skuVoucherLine) {
		if (skuVoucherLine.getSkuVoucherId() == null || skuVoucherLine.getSkuVoucherId() == 0) {
			return R.failed("物料凭证id不能为空");
		}
		Page<SkuVoucherLine> pageList = skuVoucherLineService.page(page,
				Wrappers.<SkuVoucherLine>query().lambda()
						.like(StringUtils.isNotBlank(skuVoucherLine.getPartNumber()), SkuVoucherLine::getPartNumber,
								skuVoucherLine.getPartNumber())
						.eq(StringUtils.isNotBlank(skuVoucherLine.getMoveType()), SkuVoucherLine::getMoveType,
								skuVoucherLine.getMoveType())
						.eq(SkuVoucherLine::getSkuVoucherId, skuVoucherLine.getSkuVoucherId()));
		if (pageList == null || CollectionUtils.isEmpty(pageList.getRecords())) {
			return R.ok(pageList);
		}
		pageList.getRecords().forEach(item -> {
			item.setMoveType(SkuVoucherLineMoveTypeEnum.getNameByValue(item.getMoveType()));
		});
		return R.ok(pageList);
	}

}
