package com.herdsric.oms.lotus.common;

import com.dtflys.forest.annotation.BaseRequest;
import com.dtflys.forest.annotation.JSONBody;
import com.dtflys.forest.annotation.Post;
import com.dtflys.forest.converter.json.GsonEncoder;
import com.dtflys.forest.http.ForestResponse;
import com.herdsric.oms.lotus.common.interceptor.LoutsReqInterceptor;
import com.herdsric.oms.lotus.dto.LotusCommonReqDto;
import com.herdsric.oms.lotus.dto.LotusCommonResDto;
import com.herdsric.oms.lotus.dto.SkuVoucherCreateResDto;
import com.herdsric.oms.lotus.dto.sap.*;

import java.util.List;

/**
 * @Description: lotus请求接口
 * @author: Dzx
 * @date: 2022.10.31
 */

@BaseRequest(interceptor = LoutsReqInterceptor.class)
public interface SendLotusApi {

	/**
	 * 出库回传 /sap/bc/gui/zcommon/ZFMMM_WMS_TO_SAP_016A
	 * @param lotusCommonReqDto
	 * @return
	 */
	@GsonEncoder
	@Post(value = "#{url.louts.sendDnFeedback}", headers = { "serviceName:SAP&WMS00000014" })
	ForestResponse<LotusCommonResDto<DnBackResDto>> sendDnBack(@JSONBody LotusCommonReqDto lotusCommonReqDto);

	/**
	 * 创建物料凭证
	 * @param skuVoucherCreateReqDto
	 * @return
	 */
	@Post(value = "#{url.louts.skuVoucherCreate}", headers = { "serviceName:SAP&WMS00000011" })
	ForestResponse<LotusCommonResDto<SkuVoucherCreateResDto>> skuVoucherCreate(
			@JSONBody LotusCommonReqDto<SkuVoucherCreateReqDto> skuVoucherCreateReqDto);

	/**
	 * 物料凭证冲销 /sap/bc/gui/zcommon/ZFMMM_WMS_TO_SAP_015A
	 * @param skuVoucherCreateReqDto
	 * @return
	 */
	@Post(value = "#{url.louts.skuVoucherWriteOff}", headers = { "serviceName:SAP&WMS00000012" })
	ForestResponse<LotusCommonResDto<SkuVoucherWriteOffResDto>> skuVoucherWriteOff(
			@JSONBody LotusCommonReqDto<SkuVoucherWriteOffReqDto> skuVoucherCreateReqDto);

	/**
	 * 拉取成本中心主数据
	 * @param lotusCommonReqDto
	 * @return boolean
	 */
	@Post(value = "#{url.louts.getCostCenterMasterData}", headers = { "serviceName:SAP&WMS00000020" })
	ForestResponse<LotusCommonResDto<List<CostCenterMasterDataDTO>>> costCenterMasterData(
			@JSONBody LotusCommonReqDto lotusCommonReqDto);

	/**
	 * 库存校验 /sap/bc/gui/zcommon/ZFMMM_WMS_TO_SAP_007A
	 * @param lotusCommonReqDto
	 * @return
	 */
	@Post(value = "#{url.louts.checkOfInventory}", headers = { "serviceName:SAP&WMS00000010" })
	ForestResponse<LotusCommonResDto<List<CheckOfInventoryDTO>>> checkOfInventory(
			@JSONBody LotusCommonReqDto lotusCommonReqDto);

}
