package com.herdsric.oms.lotus.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.lotus.dto.sap.SkuVoucherDto;
import com.herdsric.oms.lotus.entity.SkuVoucher;

/**
 * @author Herdsric
 * @description 针对表【os_sku_voucher(物料凭证表)】的数据库操作Service
 * @createDate 2022-11-02 14:43:16
 */
public interface SkuVoucherService extends IService<SkuVoucher> {

	/**
	 * 物料凭证创建并发送
	 * @param skuVoucherDto
	 * @return R
	 */
	R skuVoucherCreate(SkuVoucherDto skuVoucherDto);

	/**
	 * 通过id进行凭证冲销
	 * @param id id
	 * @return
	 */
	R skuVoucherWriteOffById(Integer id);

	/**
	 * 通过凭证进行凭证创建请求重发
	 * @param id
	 * @return
	 */
	R skuVoucherCreateResend(Integer id);

}
