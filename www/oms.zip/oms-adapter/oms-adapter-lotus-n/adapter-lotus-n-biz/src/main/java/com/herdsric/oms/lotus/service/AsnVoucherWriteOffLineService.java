package com.herdsric.oms.lotus.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.herdsric.oms.lotus.entity.AsnVoucherWriteOffLine;

import java.util.List;

/**
 * @author Herdsric
 * @description 针对表【lotus_asn_voucher_write_off_line】的数据库操作Service
 * @createDate 2022-12-13 11:20:25
 */
public interface AsnVoucherWriteOffLineService extends IService<AsnVoucherWriteOffLine> {

	Boolean saveBatch(List<AsnVoucherWriteOffLine> list);

}
