/*
 *    Copyright (c) 2018-2025, lengleng All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * Neither the name of the oms4cloud.com developer nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 * Author: lengleng (wangiegie@gmail.com)
 */

package com.herdsric.oms.lotus.controller;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.google.common.net.HttpHeaders;
import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.common.log.annotation.SysLog;
import com.herdsric.oms.lotus.dto.sap.DnVoucherWriteOffDto;
import com.herdsric.oms.lotus.entity.DnVoucherWriteOff;
import com.herdsric.oms.lotus.enums.AsnVoucherWriteOffStatusEnum;
import com.herdsric.oms.lotus.service.DnVoucherWriteOffService;
import com.herdsric.oms.lotus.utils.HeadGetClientCodeUtil;
import com.pig4cloud.plugin.idempotent.annotation.Idempotent;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

/**
 * 物料凭证
 *
 * @author dzx
 * @date 2022-11-03 16:43:48
 */
@RestController
@RequiredArgsConstructor
@RequestMapping("/skuVoucher/dnWriteOff")
@Tag(name = "物料凭证Dn冲销")
@SecurityRequirement(name = HttpHeaders.AUTHORIZATION)
public class DnVoucherWriteOffController {

	private final DnVoucherWriteOffService dnVoucherWriteOffService;

	/**
	 * 物料凭证Dn冲销分页查询
	 * @param page 分页对象
	 * @param dnVoucherWriteOff 参数
	 * @return
	 */
	@Operation(summary = "物料凭证Dn冲销记录分页查询", description = "物料凭证Dn冲销记录分页查询")
	@GetMapping("/recordPage")
	public R getSkuPackagePage(Page page, DnVoucherWriteOff dnVoucherWriteOff, HttpServletRequest request) {
		String clientCode = HeadGetClientCodeUtil.getClientCode(request);
		Page<DnVoucherWriteOff> pageList = dnVoucherWriteOffService.page(page,
				Wrappers.<DnVoucherWriteOff>query().lambda().eq(DnVoucherWriteOff::getClientCode, clientCode)
						.eq(StringUtils.isNotBlank(dnVoucherWriteOff.getStatus()), DnVoucherWriteOff::getStatus,
								dnVoucherWriteOff.getStatus())
						.like(StringUtils.isNotBlank(dnVoucherWriteOff.getWarehouseCode()),
								DnVoucherWriteOff::getWarehouseCode, dnVoucherWriteOff.getWarehouseCode())
						.like(StringUtils.isNotBlank(dnVoucherWriteOff.getDnNo()), DnVoucherWriteOff::getDnNo,
								dnVoucherWriteOff.getDnNo())
						.like(StringUtils.isNotBlank(dnVoucherWriteOff.getBzOutOrderNo()),
								DnVoucherWriteOff::getBzOutOrderNo, dnVoucherWriteOff.getBzOutOrderNo())
						.orderByDesc(DnVoucherWriteOff::getCreateTime));
		if (pageList == null || CollectionUtils.isEmpty(pageList.getRecords())) {
			return R.ok(pageList);
		}
		pageList.getRecords().forEach(item -> {
			item.setStatusName(AsnVoucherWriteOffStatusEnum.getNameByValue(item.getStatus()));
		});
		return R.ok(pageList);
	}

	/**
	 * dn物料凭证冲销
	 * @param dnVoucherWriteOffDto 参数
	 * @return
	 */
	@Operation(summary = "dn物料凭证冲销", description = "dn物料凭证冲销")
	@SysLog("dn物料凭证冲销")
	@PostMapping("/dnWriteOff")
	@PreAuthorize("@pms.hasPermission('dn_voucher_writeOff_send')")
	@Idempotent(key = "'dnVoucherWriteOff-'+#dnVoucherWriteOffDto.dnOrder", expireTime = 300, delKey = true,
			info = "Do not repeat the operation")
	public R dnWriteOff(@RequestBody @Valid DnVoucherWriteOffDto dnVoucherWriteOffDto, HttpServletRequest request) {
		return dnVoucherWriteOffService.dnWriteOff(dnVoucherWriteOffDto, HeadGetClientCodeUtil.getClientCode(request));
	}

	/**
	 * dn物料凭证冲销ByExcel
	 * @param file
	 * @return
	 */
	@Operation(summary = "dn物料凭证冲销ByExcel", description = "dn物料凭证冲销ByExcel")
	@SysLog("dn物料凭证冲销ByExcel")
	@PostMapping("/uploadDnWriteOffByExcel")
	@PreAuthorize("@pms.hasPermission('upload_dn_voucher_writeOff_send')")
	public R uploadDnWriteOffByExcel(@RequestParam("file") MultipartFile file, HttpServletRequest request) {
		return dnVoucherWriteOffService.uploadDnWriteOffByExcel(file, HeadGetClientCodeUtil.getClientCode(request));
	}

}
