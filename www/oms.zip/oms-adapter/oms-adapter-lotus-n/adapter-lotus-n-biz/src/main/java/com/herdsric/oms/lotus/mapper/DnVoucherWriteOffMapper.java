package com.herdsric.oms.lotus.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.herdsric.oms.lotus.entity.DnVoucherWriteOff;

/**
 * @author Herdsric
 * @description 针对表【lotus_dn_voucher_write_off】的数据库操作Mapper
 * @createDate 2022-12-15 11:31:09
 * @Entity com.herdsric.oms.adapter.entity.DnVoucherWriteOff
 */
public interface DnVoucherWriteOffMapper extends BaseMapper<DnVoucherWriteOff> {

}
