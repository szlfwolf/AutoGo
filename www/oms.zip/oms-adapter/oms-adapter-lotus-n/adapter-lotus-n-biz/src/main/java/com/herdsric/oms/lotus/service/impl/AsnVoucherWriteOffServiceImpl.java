package com.herdsric.oms.lotus.service.impl;

import cn.hutool.core.convert.Convert;
import cn.hutool.core.date.DateUtil;
import com.alibaba.excel.EasyExcel;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.herdsric.oms.common.core.constant.CommonConstants;
import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.lotus.common.SkuVoucherHandle;
import com.herdsric.oms.lotus.dto.sap.AsnWriteOffExcelDto;
import com.herdsric.oms.lotus.entity.AsnVoucherWriteOff;
import com.herdsric.oms.lotus.entity.AsnVoucherWriteOffLine;
import com.herdsric.oms.lotus.entity.SkuVoucher;
import com.herdsric.oms.lotus.entity.SkuVoucherLine;
import com.herdsric.oms.lotus.enums.AsnVoucherWriteOffStatusEnum;
import com.herdsric.oms.lotus.mapper.AsnVoucherWriteOffLineMapper;
import com.herdsric.oms.lotus.mapper.AsnVoucherWriteOffMapper;
import com.herdsric.oms.lotus.mapper.SkuVoucherMapper;
import com.herdsric.oms.lotus.service.AsnVoucherWriteOffLineService;
import com.herdsric.oms.lotus.service.AsnVoucherWriteOffService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import java.io.IOException;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author Herdsric
 * @description 针对表【lotus_asn_voucher_write_off】的数据库操作Service实现
 * @createDate 2022-12-13 11:20:25
 */
@Slf4j
@Service
@AllArgsConstructor
public class AsnVoucherWriteOffServiceImpl extends ServiceImpl<AsnVoucherWriteOffMapper, AsnVoucherWriteOff>
		implements AsnVoucherWriteOffService {

	private final AsnVoucherWriteOffLineService asnVoucherWriteOffLineService;

	private final AsnVoucherWriteOffLineMapper asnVoucherWriteOffLineMapper;

	private final SkuVoucherMapper skuVoucherMapper;

	private final Validator validator;

	private static final String GROUP_PARTING = "[|||]";

	private final SkuVoucherHandle skuVoucherHandle;

	/**
	 * ans物料凭证冲销ByExcel
	 * @param file
	 * @param clientCode
	 * @return
	 */
	@Override
	public R uploadAsnWriteOffByExcel(MultipartFile file, String clientCode) {
		List<AsnWriteOffExcelDto> asnWriteOffExcelDtoList;
		try {
			// 读取文件
			asnWriteOffExcelDtoList = EasyExcel.read(file.getInputStream()).head(AsnWriteOffExcelDto.class).sheet()
					.doReadSync();
		}
		catch (IOException e) {
			e.printStackTrace();
			return R.failed("解析文件异常");
		}
		if (CollectionUtils.isEmpty(asnWriteOffExcelDtoList)) {
			return R.ok();
		}

		// 校验excel参数
		Set<ConstraintViolation<AsnWriteOffExcelDto>> sets;
		for (AsnWriteOffExcelDto item : asnWriteOffExcelDtoList) {
			sets = validator.validate(item);
			if (!sets.isEmpty()) {
				return R.failed(sets.stream().map(ConstraintViolation::getMessage).collect(Collectors.joining(",")));
			}
		}

		// 校验是否在物料凭证中已经存在凭证
		List<String> asnNos = asnWriteOffExcelDtoList.stream().map(AsnWriteOffExcelDto::getAsnNo).distinct()
				.collect(Collectors.toList());
		List<SkuVoucher> skuVoucherList = skuVoucherMapper
				.selectList(Wrappers.<SkuVoucher>lambdaQuery().eq(SkuVoucher::getClientCode, clientCode)
						.in(SkuVoucher::getOrderNo, asnNos).select(SkuVoucher::getOrderNo, SkuVoucher::getWarehouseCode,
								SkuVoucher::getSapStockOrderNo, SkuVoucher::getSendWriteOff, SkuVoucher::getSendTime));
		if (CollectionUtils.isEmpty(skuVoucherList)) {
			return R.failed("没有找到已创建的物料凭证,不能冲销");
		}
		Map<String, SkuVoucher> skuVoucherMap = skuVoucherList.stream()
				.collect(Collectors.toMap(SkuVoucher::getOrderNo, Function.identity()));
		boolean flag = false;
		StringBuilder errorMessage = new StringBuilder("没有找到已创建的物料凭证:");
		for (String asnNo : asnNos) {
			if (!skuVoucherMap.containsKey(asnNo) || skuVoucherMap.get(asnNo) == null
					|| StringUtils.isBlank(skuVoucherMap.get(asnNo).getSapStockOrderNo())) {
				errorMessage.append(asnNo).append("、");
				flag = true;
				continue;
			}
			if (CommonConstants.STATUS_DEL.equals(skuVoucherMap.get(asnNo).getSendWriteOff())) {
				return R.failed(asnNo + "已经进行过去全单冲销，不能冲销");
			}
		}
		if (flag) {
			return R.failed(errorMessage.deleteCharAt(errorMessage.length() - 1).toString());
		}

		// 对传入的集合分组，把相同asn、行号的物料相加放到一起
		Map<String, List<AsnWriteOffExcelDto>> asnWrittenOffMap = asnWriteOffExcelDtoList.stream().collect(Collectors
				.groupingBy(e -> e.getAsnNo() + GROUP_PARTING + e.getLineNo() + GROUP_PARTING + e.getPartNumber()));
		List<AsnWriteOffExcelDto> asnWrittenOffList = asnWrittenOffMap.values().stream().map(e -> {
			e.get(0).setQty(e.stream().mapToInt(item -> Convert.toInt(item.getQty(), 0)).sum());
			return e.get(0);
		}).collect(Collectors.toList());
		// 校验冲销数量是否超过了计划数量
		R validateResult = uploadAsnWriteOffByExcelValidate(asnWrittenOffList, clientCode, asnNos);
		if (validateResult.getCode() != CommonConstants.SUCCESS) {
			return R.failed(validateResult.getMsg());
		}
		// 组装对象信息
		List<AsnVoucherWriteOff> asnVoucherWriteOffList = this.buildAsnVoucherWriteOff(asnWrittenOffList, skuVoucherMap,
				clientCode);
		// 组装发送给lotus
		skuVoucherHandle.buildAsnVoucherWriteOffReq(asnVoucherWriteOffList);
		List<AsnVoucherWriteOff> sendSuccessList = asnVoucherWriteOffList.stream()
				.filter(e -> AsnVoucherWriteOffStatusEnum.ALREADY_WRITE_OFF.getValue().equals(e.getStatus()))
				.collect(Collectors.toList());
		StringBuilder message = new StringBuilder();
		if (CollectionUtils.isNotEmpty(sendSuccessList)) {
			// 保存入数据库
			asnWrittenOffInsert(sendSuccessList);
			message.append("发送冲销成功的Asn No:   ").append(
					sendSuccessList.stream().map(AsnVoucherWriteOff::getVoucherNo).collect(Collectors.joining("、")))
					.append("\r\n");
		}
		List<AsnVoucherWriteOff> sendFailList = asnVoucherWriteOffList.stream()
				.filter(e -> !AsnVoucherWriteOffStatusEnum.ALREADY_WRITE_OFF.getValue().equals(e.getStatus()))
				.collect(Collectors.toList());
		if (CollectionUtils.isNotEmpty(sendFailList)) {
			message.append("发送冲销失败的Asn No:   ")
					.append(sendFailList.stream()
							.map(e -> e.getVoucherNo() + " 失败原因:  " + e.getResponseContent() + "\r\n")
							.collect(Collectors.joining("、")));
			return R.failed(message.toString());
		}
		return R.ok(message.toString()).setMsg(message.toString());
	}

	/**
	 * asn冲销保存
	 * @param asnWrittenOffList
	 * @return
	 */
	@Transactional(rollbackFor = Exception.class)
	public boolean asnWrittenOffInsert(List<AsnVoucherWriteOff> asnWrittenOffList) {
		List<AsnVoucherWriteOffLine> asnVoucherWriteOffLineList = new LinkedList<>();
		for (AsnVoucherWriteOff asnWriteOff : asnWrittenOffList) {
			this.baseMapper.insert(asnWriteOff);
			for (AsnVoucherWriteOffLine asnVoucherWriteOffLine : asnWriteOff.getLine()) {
				asnVoucherWriteOffLine.setVoucherWriteOffId(asnWriteOff.getId());
				asnVoucherWriteOffLineList.add(asnVoucherWriteOffLine);
			}
		}
		return asnVoucherWriteOffLineService.saveBatch(asnVoucherWriteOffLineList);
	}

	/**
	 * 组装物料凭证销毁对象
	 * @param asnWrittenOffList 客户传入结合
	 * @param skuVoucherMap 物料凭证Map
	 * @param clientCode 客户编码
	 * @return
	 */
	private List<AsnVoucherWriteOff> buildAsnVoucherWriteOff(List<AsnWriteOffExcelDto> asnWrittenOffList,
			Map<String, SkuVoucher> skuVoucherMap, String clientCode) {
		String currentTime = DateUtil.now();
		List<AsnVoucherWriteOff> asnVoucherWriteOffList = new ArrayList<>();
		Map<String, List<AsnWriteOffExcelDto>> map = asnWrittenOffList.stream()
				.collect(Collectors.groupingBy(AsnWriteOffExcelDto::getAsnNo));
		map.forEach((asnNo, list) -> {
			AsnVoucherWriteOff asnVoucherWriteOff = new AsnVoucherWriteOff().setClientCode(clientCode)
					.setWarehouseCode(skuVoucherMap.get(asnNo).getWarehouseCode()).setSendWriteOffTime(currentTime)
					.setSendCreateTime(skuVoucherMap.get(asnNo).getSendTime())
					.setSapStockOrderNo(skuVoucherMap.get(asnNo).getSapStockOrderNo()).setVoucherNo(asnNo)
					.setStatus(AsnVoucherWriteOffStatusEnum.NOT_SEND.getValue())
					.setSendWriteOff(CommonConstants.STATUS_NORMAL);
			List<AsnVoucherWriteOffLine> asnVoucherWriteOffLineList = new ArrayList<>();
			for (AsnWriteOffExcelDto asnWriteOffExcelDto : list) {
				AsnVoucherWriteOffLine asnVoucherWriteOffLine = new AsnVoucherWriteOffLine().setClientCode(clientCode)
						.setWarehouseCode(skuVoucherMap.get(asnNo).getWarehouseCode()).setVoucherNo(asnNo)
						.setLineNo(asnWriteOffExcelDto.getLineNo()).setPartNumber(asnWriteOffExcelDto.getPartNumber())
						.setActualQty(asnWriteOffExcelDto.getActualQty()).setWriteOffQty(asnWriteOffExcelDto.getQty())
						.setUnit(asnWriteOffExcelDto.getUnit());
				asnVoucherWriteOffLineList.add(asnVoucherWriteOffLine);
			}
			asnVoucherWriteOff.setLine(asnVoucherWriteOffLineList);
			asnVoucherWriteOffList.add(asnVoucherWriteOff);
		});
		return asnVoucherWriteOffList;
	}

	/**
	 * ans物料凭证冲销ByExcel校验冲销数量
	 * @param asnWrittenOffList
	 * @param clientCode
	 * @param asnNos
	 * @return
	 */
	private R uploadAsnWriteOffByExcelValidate(List<AsnWriteOffExcelDto> asnWrittenOffList, String clientCode,
			List<String> asnNos) {
		try {
			// 获取asn实际收货数据
			List<SkuVoucherLine> skuVoucherLineList = skuVoucherMapper.selectSkuVoucherLineInfoByAsnNos(asnNos,
					clientCode);
			if (CollectionUtils.isEmpty(skuVoucherLineList)) {
				return R.failed("没查到sap物料凭证入库信息");
			}
			// 获取已经冲销过的信息
			List<AsnVoucherWriteOffLine> alreadyWrittenOffList = asnVoucherWriteOffLineMapper.getAlreadyWrittenOffList(
					Wrappers.<AsnVoucherWriteOffLine>lambdaQuery().eq(AsnVoucherWriteOffLine::getClientCode, clientCode)
							.in(AsnVoucherWriteOffLine::getVoucherNo, asnNos)

							.groupBy(AsnVoucherWriteOffLine::getVoucherNo, AsnVoucherWriteOffLine::getLineNo,
									AsnVoucherWriteOffLine::getPartNumber));
			boolean alreadyWrittenOffFlag = false;
			if (CollectionUtils.isNotEmpty(alreadyWrittenOffList)) {
				alreadyWrittenOffFlag = true;
			}
			StringBuilder errorMessage = new StringBuilder("错误信息:\n");
			boolean errorFlag = false;
			for (AsnWriteOffExcelDto item : asnWrittenOffList) {
				SkuVoucherLine skuVoucherLine = skuVoucherLineList.stream()
						.filter(e -> StringUtils.equals(item.getAsnNo(), e.getAsnNo())
								&& StringUtils.equals(item.getLineNo(), e.getLineNo())
								&& StringUtils.equals(item.getPartNumber(), e.getPartNumber()))
						.findFirst().orElse(null);
				if (ObjectUtils.isEmpty(skuVoucherLine)) {
					errorMessage.append("Asn No:" + item.getAsnNo() + "Line No:" + item.getLineNo() + "Part Number:"
							+ item.getPartNumber() + ",没查到入库单行信息\n");
					errorFlag = true;
					continue;
				}
				if (alreadyWrittenOffFlag) {
					AsnVoucherWriteOffLine alreadyWrittenOff = alreadyWrittenOffList.stream()
							.filter(e -> StringUtils.equals(item.getAsnNo(), e.getVoucherNo())
									&& StringUtils.equals(item.getLineNo(), e.getLineNo())
									&& StringUtils.equals(item.getPartNumber(), e.getPartNumber()))
							.findFirst().orElse(null);
					if (ObjectUtils.isNotEmpty(alreadyWrittenOff) && Convert.toInt(skuVoucherLine.getNum(),
							0) < item.getQty() + Convert.toInt(alreadyWrittenOff.getWriteOffQty(), 0)) {
						errorMessage.append("Asn No:" + item.getAsnNo() + "Line No:" + item.getLineNo() + "Part Number:"
								+ item.getPartNumber() + "冲销数量与已冲销数量之和不能大于实际数量\n");
						errorFlag = true;
						continue;
					}
				}
				if (Convert.toInt(skuVoucherLine.getNum(), 0) < item.getQty()) {
					errorMessage.append("Asn No:" + item.getAsnNo() + "Line No:" + item.getLineNo() + "Part Number:"
							+ item.getPartNumber() + "冲销数量大于实际数量\n");
					errorFlag = true;
					continue;
				}
				item.setActualQty(Convert.toInt(skuVoucherLine.getNum(), 0));
				item.setUnit(skuVoucherLine.getUnit());
			}
			if (errorFlag) {
				return R.failed(errorMessage.toString());
			}
			return R.ok();
		}
		catch (Exception e) {
			log.error("校验冲销数量时出现错误，错误信息:{}", e);
			return R.failed("校验冲销数量时出现错误,错误信息:{" + e.getMessage() + "}");
		}
	}

}
