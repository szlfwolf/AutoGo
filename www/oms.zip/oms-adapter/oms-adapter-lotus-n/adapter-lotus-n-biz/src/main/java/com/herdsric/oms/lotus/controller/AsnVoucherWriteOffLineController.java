/*
 *    Copyright (c) 2018-2025, lengleng All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * Neither the name of the oms4cloud.com developer nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 * Author: lengleng (wangiegie@gmail.com)
 */

package com.herdsric.oms.lotus.controller;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.google.common.net.HttpHeaders;
import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.lotus.entity.AsnVoucherWriteOffLine;
import com.herdsric.oms.lotus.service.AsnVoucherWriteOffLineService;
import com.herdsric.oms.lotus.utils.HeadGetClientCodeUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

/**
 * 物料凭证
 *
 * @author dzx
 * @date 2022-11-03 16:43:48
 */
@RestController
@RequiredArgsConstructor
@RequestMapping("/skuVoucher/asnWriteOffLine")
@Tag(name = "物料凭证Asn冲销行")
@SecurityRequirement(name = HttpHeaders.AUTHORIZATION)
public class AsnVoucherWriteOffLineController {

	private final AsnVoucherWriteOffLineService asnVoucherWriteOffLineService;

	/**
	 * 物料凭证Asn冲销分页查询
	 * @param page 分页对象
	 * @param asnVoucherWriteOffLine 参数
	 * @param request request
	 * @return
	 */
	@Operation(summary = "物料凭证Asn冲销分页查询", description = "物料凭证Asn冲销分页查询")
	@GetMapping("/page")
	@PreAuthorize("@pms.hasPermission('asn_writeOff_get')")
	public R getSkuPackagePage(Page page, AsnVoucherWriteOffLine asnVoucherWriteOffLine, HttpServletRequest request) {
		String clientCode = HeadGetClientCodeUtil.getClientCode(request);
		Page<AsnVoucherWriteOffLine> pageList = asnVoucherWriteOffLineService.page(page, Wrappers
				.<AsnVoucherWriteOffLine>query().lambda()
				.eq(asnVoucherWriteOffLine.getVoucherWriteOffId() != null, AsnVoucherWriteOffLine::getVoucherWriteOffId,
						asnVoucherWriteOffLine.getVoucherWriteOffId())
				.eq(AsnVoucherWriteOffLine::getClientCode, clientCode)
				.like(StringUtils.isNotBlank(asnVoucherWriteOffLine.getWarehouseCode()),
						AsnVoucherWriteOffLine::getWarehouseCode, asnVoucherWriteOffLine.getWarehouseCode())
				.like(StringUtils.isNotBlank(asnVoucherWriteOffLine.getPartNumber()),
						AsnVoucherWriteOffLine::getPartNumber, asnVoucherWriteOffLine.getPartNumber())
				.orderByDesc(AsnVoucherWriteOffLine::getCreateTime));
		return R.ok(pageList);
	}

}
