package com.herdsric.oms.lotus.common;

import com.dtflys.forest.annotation.JSONBody;
import com.dtflys.forest.annotation.Post;
import com.dtflys.forest.http.ForestResponse;
import com.herdsric.oms.lotus.common.interceptor.WtsAuthInterceptor;
import com.herdsric.oms.lotus.dto.LotusCommonReqDto;
import com.herdsric.oms.lotus.dto.LotusCommonResDto;
import com.herdsric.oms.lotus.dto.SkuVoucherCreateResDto;
import com.herdsric.oms.lotus.dto.sap.SkuVoucherCreateReqDto;
import com.herdsric.oms.lotus.dto.sap.SkuVoucherWriteOffReqDto;
import com.herdsric.oms.lotus.dto.sap.SkuVoucherWriteOffResDto;

public interface WtsApi {

	/**
	 * 创建物料凭证(WTS) /wts/api/ptms/inBound/receiveOfLuxMate
	 * @param skuVoucherCreateReqDto
	 * @return
	 */
	@Post(value = "#{lotus.wts.url.inboundVoucherPushWts}", headers = { "serviceName:SAP&WMS00000011" },
			interceptor = WtsAuthInterceptor.class)
	ForestResponse<LotusCommonResDto<SkuVoucherCreateResDto>> inboundVoucherPushWts(
			@JSONBody LotusCommonReqDto<SkuVoucherCreateReqDto> skuVoucherCreateReqDto);

	/**
	 * 物料凭证冲销 (WTS)
	 * @param skuVoucherCreateReqDto
	 * @return
	 */
	@Post(value = "#{lotus.wts.url.inboundVoucherWriteOffPushWts}", headers = { "serviceName:SAP&WMS00000012" },
			interceptor = WtsAuthInterceptor.class)
	ForestResponse<LotusCommonResDto<SkuVoucherWriteOffResDto>> inboundVoucherWriteOffPushWts(
			@JSONBody LotusCommonReqDto<SkuVoucherWriteOffReqDto> skuVoucherCreateReqDto);

}
