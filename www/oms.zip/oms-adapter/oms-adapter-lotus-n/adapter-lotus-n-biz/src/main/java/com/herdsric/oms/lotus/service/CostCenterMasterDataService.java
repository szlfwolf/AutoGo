package com.herdsric.oms.lotus.service;

import com.herdsric.oms.lotus.dto.sap.CostCenterMasterDataDTO;
import com.herdsric.oms.lotus.entity.CostCenterMasterData;

import java.util.List;

/**
 * @author ：lzq
 * @date ：Created in 2022-11-14 0014 15:54 @description：
 * @modified By：
 * @version: $
 */
public interface CostCenterMasterDataService {

	/**
	 * 同步成本中心主数据
	 */
	void getCostCenterMaster(CostCenterMasterDataDTO costCenterMasterDataDTO);

	Boolean updateBatch(List<CostCenterMasterData> list);

	Boolean saveBatch(List<CostCenterMasterData> list);

}
