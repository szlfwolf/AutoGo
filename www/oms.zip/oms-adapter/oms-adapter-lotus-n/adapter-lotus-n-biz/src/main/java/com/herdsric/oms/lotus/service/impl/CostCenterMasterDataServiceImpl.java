package com.herdsric.oms.lotus.service.impl;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.json.JSONArray;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.dtflys.forest.http.ForestResponse;
import com.herdsric.oms.lotus.common.LotusConstant;
import com.herdsric.oms.lotus.common.SendLotusApi;
import com.herdsric.oms.lotus.dto.LotusCommonReqDto;
import com.herdsric.oms.lotus.dto.LotusCommonResDto;
import com.herdsric.oms.lotus.dto.sap.CostCenterMasterDataDTO;
import com.herdsric.oms.lotus.entity.CostCenterMasterData;
import com.herdsric.oms.lotus.mapper.CostMasterDataMapper;
import com.herdsric.oms.lotus.service.CostCenterMasterDataService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author ：lzq
 * @date ：Created in 2022-11-14 0014 15:55 @description：
 * @modified By：
 * @version: $
 */
@Service
@Slf4j
public class CostCenterMasterDataServiceImpl extends ServiceImpl<CostMasterDataMapper, CostCenterMasterData>
		implements CostCenterMasterDataService {

	@Resource
	private SendLotusApi sendLotusApi;

	@Resource
	private CostMasterDataMapper costMasterDataMapper;

	@Override
	@Transactional(rollbackFor = Exception.class)
	public void getCostCenterMaster(CostCenterMasterDataDTO costCenterMasterDataDTO) {
		try {
			// 请求lotus拿到成本中心主数据
			ForestResponse<LotusCommonResDto<List<CostCenterMasterDataDTO>>> ForestResponse = sendLotusApi
					.costCenterMasterData(new LotusCommonReqDto().setRequestData(costCenterMasterDataDTO));

			if (ObjectUtils.isEmpty(ForestResponse.getResult())) {
				log.info("成本中心主数据同步出错");
			}

			if (ObjectUtils.isEmpty(ForestResponse.getResult().getResponseData())) {
				log.info("暂无需要同步的成本主数据");
				return;
			}

			// 查当前库得来的成本中心主数据
			List<CostCenterMasterData> costCenterMasterData = costMasterDataMapper
					.selectList(new LambdaQueryWrapper<CostCenterMasterData>());

			// 请求得来的成本中心主数据
			List<CostCenterMasterDataDTO> responseData = ForestResponse.getResult().getResponseData();

			// 交集(更新U)
			List<CostCenterMasterData> intersection = costCenterMasterData.stream()
					.filter(cost1 -> responseData.stream().map(CostCenterMasterDataDTO::getCostCenterCode)
							.anyMatch(cost2Code -> StringUtils.equals(cost1.getCostCenterCode(), cost2Code)))
					.collect(Collectors.toList());
			for (CostCenterMasterData centerMasterData : intersection) {
				centerMasterData.setStatus(LotusConstant.INTERSECTION);
			}
			// 差集(N)
			List<CostCenterMasterDataDTO> Subtraction = responseData.stream()
					.filter(cost1 -> costCenterMasterData.stream().map(CostCenterMasterData::getCostCenterCode)
							.noneMatch(cost2Code -> StringUtils.equals(cost1.getCostCenterCode(), cost2Code)))
					.collect(Collectors.toList());

			boolean updateResult = true;
			if (CollectionUtil.isNotEmpty(intersection)) {
				updateResult = this.updateBatch(intersection);
			}
			// 存储到表中
			boolean insertResult = true;
			if (CollectionUtil.isNotEmpty(Subtraction)) {
				List<CostCenterMasterData> afterCopy = new ArrayList<>();
				JSONArray objects = JSONUtil.parseArray(Subtraction);
				afterCopy.addAll(JSONUtil.toList(objects, CostCenterMasterData.class));
				insertResult = this.saveBatch(afterCopy);
			}

			if (updateResult && insertResult) {
				log.info("同步主数据成功");
				return;
			}
			log.info("同步成本主数据失败");
			return;
		}
		catch (Exception e) {
			log.info("同步成本中心主数据出现未知异常:{}", e);
			throw new RuntimeException(e);
		}
	}

	@Override
	public Boolean updateBatch(List<CostCenterMasterData> list) {
		if (CollectionUtil.isNotEmpty(list)) {
			int i = baseMapper.updateBatch(list);
			if (i > 0) {
				return true;
			}
		}
		return false;
	}

	@Override
	public Boolean saveBatch(List<CostCenterMasterData> list) {
		if (CollectionUtil.isNotEmpty(list)) {
			int i = baseMapper.insertBatch(list);
			if (i > 0) {
				return true;
			}
		}
		return false;
	}

}
