package com.herdsric.oms.lotus.common.domain.wts;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class Result {

	@JsonProperty("code")
	private Integer code;

	@JsonProperty("message")
	private String message;

	@JsonProperty("data")
	private DataDTO data;

	@JsonProperty("errorArgs")
	private Object errorArgs;

	@JsonProperty("currentTime")
	private Long currentTime;

	@JsonProperty("traceId")
	private String traceId;

	@JsonProperty("success")
	private Boolean success;

	@NoArgsConstructor
	@Data
	public static class DataDTO {

		@JsonProperty("access_token")
		private String accessToken;

		@JsonProperty("token_type")
		private String tokenType;

		@JsonProperty("expires_in")
		private Integer expiresIn;

		@JsonProperty("scope")
		private String scope;

	}

}
