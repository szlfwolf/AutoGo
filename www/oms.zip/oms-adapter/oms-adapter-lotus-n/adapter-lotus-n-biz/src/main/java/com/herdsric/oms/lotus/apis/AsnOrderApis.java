package com.herdsric.oms.lotus.apis;

import cn.hutool.core.util.StrUtil;
import com.herdsric.oms.common.client.asn.domain.AsnOrderDm;
import com.herdsric.oms.common.client.returns.dm.AsnOrderReturnDm;
import com.herdsric.oms.common.core.constant.CommonConstants;
import com.herdsric.oms.common.core.constant.SecurityConstants;
import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.common.feign.client.RemoteAsnOrderService;
import com.herdsric.oms.lotus.common.LotusConstant;
import com.herdsric.oms.lotus.dto.AsnOrderDTO;
import com.herdsric.oms.lotus.utils.LotusAndPortalBeanCovUtil;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@RestController
@RequestMapping("/asn")
@Tag(name = "AsnOrder对外接口")
@Validated
@RequiredArgsConstructor
@Slf4j
public class AsnOrderApis {

	private final RemoteAsnOrderService remoteAsnOrderService;

	@PostMapping("/addAsn")
	public R receive(@RequestBody @Valid AsnOrderDTO asnOrderDTO) {
		// 基础参数校验
		asnOrderDTO.check();
		// 判断但是是否是SAP退货单还是SAP采购单
		R result = null;
		if (StrUtil.equals(asnOrderDTO.getZdjlx(), LotusConstant.SAP_RETURN_FLAG)) {
			AsnOrderReturnDm returnOrderCreateDto = LotusAndPortalBeanCovUtil.asnReturnToStandard(asnOrderDTO);
			result = remoteAsnOrderService.asnOrderReturn(returnOrderCreateDto, LotusConstant.CLIENT_CODE,
					SecurityConstants.FROM_IN);
		}
		else {
			AsnOrderDm asnOrderDm = LotusAndPortalBeanCovUtil.asnToStandard(asnOrderDTO);
			result = remoteAsnOrderService.save(asnOrderDm, LotusConstant.CLIENT_CODE, SecurityConstants.FROM_IN);
		}

		if (!CommonConstants.SUCCESS.equals(result.getCode())) {
			return result;
		}
		return R.ok().setMsg(CommonConstants.LOTUS_SUCCESS_FLAG);
	}

}
