package com.herdsric.oms.lotus.apis;

import cn.hutool.core.util.StrUtil;
import com.herdsric.oms.common.client.asn.domain.AsnOrderDm;
import com.herdsric.oms.common.client.dn.domain.DnOrderDm;
import com.herdsric.oms.common.core.constant.CommonConstants;
import com.herdsric.oms.common.core.constant.SecurityConstants;
import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.common.feign.client.RemoteAsnOrderService;
import com.herdsric.oms.common.feign.client.RemoteDnOrderService;
import com.herdsric.oms.lotus.common.LotusConstant;
import com.herdsric.oms.lotus.config.AdapterConfig;
import com.herdsric.oms.lotus.dto.DnOrderDto;
import com.herdsric.oms.lotus.utils.LotusAndPortalBeanCovUtil;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/dn")
@Tag(name = "DnOrderApis对外接口")
@Validated
@RequiredArgsConstructor
public class DnOrderApis {

	private final RemoteDnOrderService remoteDnOrderService;

	private final RemoteAsnOrderService remoteAsnOrderService;

	private final AdapterConfig adapterConfig;

	@PostMapping("/addDn")
	public R receive(@RequestBody DnOrderDto dnOrderDto) {
		// 基础参数校验
		dnOrderDto.check();
		// 判断是否是DN正常入库还是DN退货入库
		R result = null;
		if (StrUtil.equals(dnOrderDto.getZjylx(), LotusConstant.SAP_RETURN_FLAG)) {
			AsnOrderDm asnOrderDm = LotusAndPortalBeanCovUtil.dnReturnMapping(dnOrderDto);
			result = remoteAsnOrderService.save(asnOrderDm, LotusConstant.CLIENT_CODE, SecurityConstants.FROM_IN);
		}
		else {
			DnOrderDm dnOrderDm = LotusAndPortalBeanCovUtil.dnToStandard(dnOrderDto);
			dnOrderDm.setContactEmail(StrUtil.isBlank(dnOrderDm.getContactEmail()) ? adapterConfig.getDnEmail()
					: dnOrderDm.getContactEmail());
			result = remoteDnOrderService.save(dnOrderDm, LotusConstant.CLIENT_CODE, SecurityConstants.FROM_IN);
		}

		if (!CommonConstants.SUCCESS.equals(result.getCode())) {
			return result;
		}
		return R.ok().setMsg(CommonConstants.LOTUS_SUCCESS_FLAG);

	}

}
