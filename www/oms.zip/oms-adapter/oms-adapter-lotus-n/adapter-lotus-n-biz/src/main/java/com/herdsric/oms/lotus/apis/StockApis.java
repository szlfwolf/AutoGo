package com.herdsric.oms.lotus.apis;

import cn.hutool.core.collection.CollectionUtil;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.herdsric.oms.common.client.stock.domain.StockDm;
import com.herdsric.oms.common.client.stock.dto.StockDTO;
import com.herdsric.oms.common.core.constant.SecurityConstants;
import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.common.feign.client.RemoteStockService;
import com.herdsric.oms.common.security.annotation.Inner;
import com.herdsric.oms.lotus.common.LotusConstant;
import com.herdsric.oms.lotus.dto.lcms.QueryAvaInventoryDto;
import com.herdsric.oms.lotus.dto.lcms.QueryAvaInventoryVo;
import com.herdsric.oms.lotus.dto.lcms.SearchStockRequestDTO;
import com.herdsric.oms.lotus.dto.lcms.SearchStockRespondVO;
import com.herdsric.oms.lotus.dto.sap.LoutsStockVo;
import com.herdsric.oms.lotus.service.LotusService;
import com.herdsric.oms.lotus.utils.LotusAndPortalBeanCovUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/lcms")
@Tag(name = "lcms查询库存对外接口")
@Validated
@RequiredArgsConstructor
public class StockApis {

	private final RemoteStockService remoteStockService;

	private final LotusService lotusService;

	//@formatter:off
	@PostMapping("/searchInventory")
	public R searchInventory(@Validated @RequestBody SearchStockRequestDTO searchStockRequestDTO) {
		// 进行Mapping映射
		StockDTO stockDTO = LotusAndPortalBeanCovUtil.searchInventoryToStockDm(searchStockRequestDTO);

		R<List<StockDm>> result = remoteStockService.queryStock(stockDTO, LotusConstant.CLIENT_CODE, SecurityConstants.FROM_IN);
		List<StockDm> data = result.getData();

		if (CollectionUtil.isEmpty(data)) {
			return R.failed().setMsg("未查询到当前零件");
		}

		List<SearchStockRespondVO> searchStockRespondVOList = LotusAndPortalBeanCovUtil.stockToSearchStockRespondVO(data);
		IPage<SearchStockRespondVO> page = new Page<>(stockDTO.getCurrent(), stockDTO.getSize());
		page.setRecords(searchStockRespondVOList);
		if (page.getRecords().size() >= page.getSize()) {
			page.setTotal(page.getSize() * (page.getCurrent() + 1));
			page.setPages(page.getCurrent() + 1);
		} else {
			page.setTotal((page.getCurrent() > 1 ? (page.getCurrent() - 1) * page.getSize() : 0) + page.getRecords().size());
			page.setPages(page.getCurrent());
		}
		return R.ok().setData(page).setMsg("Success");
	}

	@PostMapping("/queryAvaInventory")
	public R queryAvaInventory(@Validated @RequestBody QueryAvaInventoryDto queryAvaInventoryDto) {
		// 进行Mapping映射
		StockDTO stockDTO = LotusAndPortalBeanCovUtil.queryAvaInventoryToStockDm(queryAvaInventoryDto);

		R<List<StockDm>> result = remoteStockService.queryStock(stockDTO, LotusConstant.CLIENT_CODE, SecurityConstants.FROM_IN);

		List<StockDm> data = result.getData();

		if (CollectionUtil.isEmpty(data)) {
			return R.failed().setMsg("未查询到当前零件");
		}

		// 进行返回值映射
		List<QueryAvaInventoryVo> queryAvaInventoryVoList = LotusAndPortalBeanCovUtil.stockToQueryAvaInventoryVO(data);

		int total = queryAvaInventoryVoList.size(); // 总记录数
		int pageSize = (int) queryAvaInventoryDto.getSize(); // 每页记录数
		// 计算总页数
		int totalPages = total % pageSize == 0 ? total / pageSize : (total / pageSize) + 1;
		IPage<QueryAvaInventoryVo> page = new Page<>();
		page.setTotal(total);
		page.setCurrent(queryAvaInventoryDto.getCurrent());
		page.setSize(queryAvaInventoryDto.getSize());
		page.setRecords(queryAvaInventoryVoList);
		page.setPages(totalPages);
		return R.ok().setData(page).setMsg("Success");
	}
	//@formatter:on

	/**
	 * 库存校验--oms调用
	 * @param loutsStockVo
	 * @return R
	 */
	@Inner
	@Operation(summary = "库存校验", description = "库存校验")
	@PostMapping("/CheckOfInventory")
	public R checkOfInventory(@Valid @RequestBody LoutsStockVo loutsStockVo) {
		return lotusService.checkOfInventory(loutsStockVo);
	}

}
