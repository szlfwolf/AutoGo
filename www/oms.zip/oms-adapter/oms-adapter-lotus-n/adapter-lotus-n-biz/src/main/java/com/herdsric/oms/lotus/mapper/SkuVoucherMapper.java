package com.herdsric.oms.lotus.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.herdsric.oms.lotus.dto.sap.SkuVoucherDto;
import com.herdsric.oms.lotus.entity.SkuVoucher;
import com.herdsric.oms.lotus.entity.SkuVoucherLine;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author Herdsric
 * @description 针对表【os_sku_voucher(物料凭证表)】的数据库操作Mapper
 * @createDate 2022-11-02 14:43:15
 */
@Mapper
public interface SkuVoucherMapper extends BaseMapper<SkuVoucher> {

	/**
	 * 获取请求信息根据凭证id
	 * @param id
	 * @return
	 */
	SkuVoucherDto selectSkuVoucherById(@Param("id") Integer id);

	/**
	 * selectSkuVoucherLineInfoByAsnNos
	 * @param asnNos
	 * @param clientCode
	 * @return
	 */
	List<SkuVoucherLine> selectSkuVoucherLineInfoByAsnNos(@Param("asnNos") List<String> asnNos,
			@Param("clientCode") String clientCode);

}
