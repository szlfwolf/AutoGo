package com.herdsric.oms.lotus.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.herdsric.oms.lotus.entity.SkuVoucherLine;
import com.herdsric.oms.lotus.mapper.SkuVoucherLineMapper;
import com.herdsric.oms.lotus.service.SkuVoucherLineService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * @author Herdsric
 * @description 针对表【os_sku_voucher_line】的数据库操作Service实现
 * @createDate 2022-11-02 14:43:16
 */
@Service
@Slf4j
public class SkuVoucherLineServiceImpl extends ServiceImpl<SkuVoucherLineMapper, SkuVoucherLine>
		implements SkuVoucherLineService {

}
