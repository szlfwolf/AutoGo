package com.herdsric.oms.lotus.service.impl;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.lang.Assert;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.herdsric.oms.common.core.constant.CommonConstants;
import com.herdsric.oms.common.core.constant.enums.SkuVoucherStatusEnum;
import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.lotus.common.SkuVoucherHandle;
import com.herdsric.oms.lotus.dto.sap.SkuVoucherDto;
import com.herdsric.oms.lotus.dto.sap.SkuVoucherLineDto;
import com.herdsric.oms.lotus.entity.SkuVoucher;
import com.herdsric.oms.lotus.entity.SkuVoucherLine;
import com.herdsric.oms.lotus.mapper.SkuVoucherMapper;
import com.herdsric.oms.lotus.service.SkuVoucherLineService;
import com.herdsric.oms.lotus.service.SkuVoucherService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.compress.utils.Lists;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import java.util.List;

/**
 * @author Herdsric
 * @description 针对表【os_sku_voucher(物料凭证表)】的数据库操作Service实现
 * @createDate 2022-11-02 14:43:16
 */
@Service
@Slf4j
@AllArgsConstructor
public class SkuVoucherServiceImpl extends ServiceImpl<SkuVoucherMapper, SkuVoucher> implements SkuVoucherService {

	private final SkuVoucherLineService skuVoucherLineService;

	private final SkuVoucherHandle skuVoucherHandle;

	/**
	 * 物料凭证创建并发送
	 * @param skuVoucherDto
	 * @return R
	 */
	@Override
	@Transactional(rollbackFor = Exception.class)
	public R skuVoucherCreate(SkuVoucherDto skuVoucherDto) {
		try {
			// 发送物料凭证给lotus
			skuVoucherHandle.skuVoucherCreateSendLotus(skuVoucherDto);

			// 物料信息保存到数据库
			SkuVoucher skuVoucher = new SkuVoucher();
			BeanUtils.copyProperties(skuVoucherDto, skuVoucher);
			this.baseMapper.insert(skuVoucher);
			List<SkuVoucherLine> skuVoucherLineList = Lists.newArrayList();
			for (SkuVoucherLineDto skuVoucherLineDto : skuVoucherDto.getSkuVoucherLineDtoList()) {
				SkuVoucherLine skuVoucherLine = new SkuVoucherLine();
				BeanUtils.copyProperties(skuVoucherLineDto, skuVoucherLine);
				skuVoucherLine.setSkuVoucherId(skuVoucher.getId());
				skuVoucherLineList.add(skuVoucherLine);
			}
			skuVoucherLineService.saveBatch(skuVoucherLineList);
		}
		catch (Exception e) {
			log.error("物料凭证创建并发送出现异常:{}", e);
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			return R.failed("物料凭证创建并发送出现异常:{}", e.getMessage());
		}
		return R.ok("success");
	}

	/**
	 * 通过id进行凭证冲销
	 * @param id
	 * @return
	 */
	@Override
	public R skuVoucherWriteOffById(Integer id) {
		try {
			SkuVoucher voucher = this.getOne(Wrappers.<SkuVoucher>lambdaQuery().eq(SkuVoucher::getId, id)
					.eq(SkuVoucher::getSendWriteOff, CommonConstants.STATUS_DEL).last("limit 1"));
			if (ObjectUtils.isNotEmpty(voucher)) {
				return R.failed("该单已经成功发送过凭证冲销,不能重复发送");
			}
			SkuVoucher skuVoucher = this.baseMapper
					.selectOne(Wrappers.<SkuVoucher>query().lambda().eq(SkuVoucher::getId, id));
			Assert.notNull(skuVoucher, "凭证冲销异常，未查询到该凭证信息");
			Assert.notNull(skuVoucher.getSapStockOrderNo(), "参考物料凭证号不能为空");
			boolean flag = skuVoucherHandle.buildSkuVoucherWriteOffReq(skuVoucher);
			if (flag) {
				this.baseMapper.updateById(
						new SkuVoucher().setId(id).setStatus(SkuVoucherStatusEnum.ALREADY_WRITE_OFF.getValue())
								.setSendWriteOff(CommonConstants.STATUS_DEL).setSendWriteOffTime(DateUtil.now()));
				return R.ok().setMsg("发送凭证冲销成功");
			}
		}
		catch (Exception e) {
			log.error("凭证冲销异常：{}", e);
		}
		this.baseMapper.updateById(new SkuVoucher().setId(id).setStatus(SkuVoucherStatusEnum.FAIL_WRITE_OFF.getValue())
				.setSendWriteOffTime(DateUtil.now()));
		return R.failed("发送凭证冲销失败");
	}

	/**
	 * 通过凭证进行凭证创建请求重发
	 * @param id
	 * @return
	 */
	@Override
	public R skuVoucherCreateResend(Integer id) {
		SkuVoucher skuVoucher = this.getOne(Wrappers.<SkuVoucher>lambdaQuery().eq(SkuVoucher::getId, id)
				.eq(SkuVoucher::getSendCreate, CommonConstants.STATUS_DEL).last("limit 1"));
		if (ObjectUtils.isNotEmpty(skuVoucher)) {
			return R.failed("该单已经成功发送凭证创建,不能重复发送");
		}
		SkuVoucherDto skuVoucherDto = this.baseMapper.selectSkuVoucherById(id);
		if (ObjectUtils.isEmpty(skuVoucherDto)) {
			return R.failed("没有查到该凭证信息");
		}
		// 发送物料凭证给lotus
		boolean flag = skuVoucherHandle.skuVoucherCreateSendLotus(skuVoucherDto);
		if (flag) {
			// 更新发送状态
			this.baseMapper.updateById(new SkuVoucher().setId(id).setStatus(skuVoucherDto.getStatus())
					.setSapStockOrderNo(skuVoucherDto.getSapStockOrderNo()).setSendCreate(skuVoucherDto.getSendCreate())
					.setSendTime(skuVoucherDto.getSendTime()));
			return R.ok().setMsg("发送凭证创建成功!");
		}
		// 更新发送状态
		this.baseMapper.updateById(new SkuVoucher().setId(id).setStatus(skuVoucherDto.getStatus())
				.setSendTime(skuVoucherDto.getSendTime()));
		return R.failed("发送凭证创建失败!");
	}

}
