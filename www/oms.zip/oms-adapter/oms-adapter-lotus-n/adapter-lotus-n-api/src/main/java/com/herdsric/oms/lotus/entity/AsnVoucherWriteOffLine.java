package com.herdsric.oms.lotus.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.herdsric.oms.common.mybatis.base.LogicDelBaseEntity;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * @author Herdsric
 * @TableName lotus_asn_voucher_write_off_line
 */
@TableName(value = "lotus_asn_voucher_write_off_line")
@Data
@EqualsAndHashCode(callSuper = true)
@Schema(description = "asn凭证冲销行数据")
@Accessors(chain = true)
public class AsnVoucherWriteOffLine extends LogicDelBaseEntity {

	/**
	 *
	 */
	@TableId(type = IdType.AUTO)
	@Schema(description = "主键")
	private Integer id;

	/**
	 * client
	 */
	@Schema(description = "client")
	private String clientCode;

	/**
	 * 仓库code
	 */
	@Schema(description = "仓库code")
	private String warehouseCode;

	/**
	 * 物料凭证冲销表id
	 */
	@Schema(description = "物料凭证冲销id")
	private Integer voucherWriteOffId;

	/**
	 * 物料凭证单号(asn号)
	 */
	@Schema(description = "物料凭证单号(asn号)")
	private String voucherNo;

	/**
	 * 行号
	 */
	@Schema(description = "行号")
	private String lineNo;

	/**
	 * 零件号
	 */
	@Schema(description = "零件号")
	private String partNumber;

	/**
	 * 实际收货数量
	 */
	@Schema(description = "实际收货数量")
	private Integer actualQty;

	/**
	 * 冲销数量
	 */
	@Schema(description = "冲销数量")
	private Integer writeOffQty;

	/**
	 * 单位 （pce:袋装，pcs:件）
	 */
	@Schema(description = "单位 （pce:袋装，pcs:件）")
	private String unit;

}