package com.herdsric.oms.lotus.common;

public interface LotusConstant {

	/**
	 * LOTUS 暂时不拆单，默认设置仓库，客户下发不知道仓库代码，Adapters中设置默认仓库代码
	 */
	String WAREHOUSE_CODE = "BellsingleWarehouse";

	String CLIENT_CODE = "LOTUS";

	/**
	 * sap下发退货单标记
	 */
	String SAP_RETURN_FLAG = "1";

	/**
	 * sap下发退货单标记
	 */
	String SAP_FLAG = "0";

	/**
	 * sap 退货asn反馈
	 */
	String ASN_RETURN = "ASN_RETURN";

	/**
	 * dn货主代码
	 */
	String ZHZDM = "2";

	/**
	 * sap 退货dn反馈
	 */
	String DN_RETURN = "DNTH";

	String LOTUS_AUTH_AUTHORIZATION = "X-Lotus-Authorization";

	String LOTUS_RES_STATUS_SUCCESS = "S";

	String LOTUS_SYSTEM = "lotusSystem";

	String LOTUS_FACTORY = "EU11";

	/**
	 * 交货已完成标记
	 */
	String ELIKZ = "Y";

	/**
	 * 成本中心状态
	 */
	String INTERSECTION = "U";

	/**
	 * 欧洲时区
	 */
	String TIME_ZONE_EUROPE = "Europe/Amsterdam";

	/***
	 * 移库单类型
	 */
	String DN_TRANSACTION_TYPE = "2";

	/***
	 * 正常下发DN单发货类型
	 */
	String DN_DELIVELY_TYPE = "0";

	/***
	 * DN 过账类型
	 */
	String LOTUS_DN_BACK_POST = "1";

	/***
	 * dn 打包反馈SAP 类型
	 */
	String LOTUS_DN_PACKED_POST = "5";

	String LOTUS_SEND_USER_NAME = "Lux-mate";

	String SourceType = "FILE";

	String LOTUS_DN_BACK_WRITE_OFF = "2";

	String nameCN = "nameCN";

	String nameEN = "nameEN";

	String unit = "unit";

	String carModel = "carModel";

	String indate = "indate";

	String outdate = "outdate";

	String moq = "moq";

	String E = "E";

	String allocation = "3";

	String API = "API";

}
