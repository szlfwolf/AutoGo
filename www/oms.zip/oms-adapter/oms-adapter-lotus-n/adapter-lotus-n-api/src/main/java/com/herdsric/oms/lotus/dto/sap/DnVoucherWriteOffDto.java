package com.herdsric.oms.lotus.dto.sap;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.experimental.Accessors;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

/**
 * @author Herdsric
 * @TableName dn凭证冲销参数
 */
@Data
@Schema(description = "dn凭证冲销参数")
@Accessors(chain = true)
public class DnVoucherWriteOffDto {

	/**
	 * 是否重发Dn（0：否；1：是）
	 */
	@Schema(description = "是否重发Dn（0：否；1：是）")
	@NotBlank(message = "是否重发Dn不能为空")
	@Pattern(regexp = "^0|1", message = "是否重发格式错误")
	private String resendDn;

	/**
	 * dn订单号
	 */
	@Schema(description = "dn订单号")
	@NotBlank(message = "dn订单号不能为空")
	private String dnOrder;

}