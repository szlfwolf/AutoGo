package com.herdsric.oms.lotus.dto.sap;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.io.Serializable;

/**
 * @author ：lzq
 * @date ：Created in 2022-11-08 0008 11:24 @description：
 * @modified By：
 * @version: $
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LotusDnLineBackDTO implements Serializable {

	@Schema(description = "行号")
	@JsonProperty(value = "ASNITEM")
	@JSONField(name = "ASNITEM")
	private String ASNITEM;

	@Schema(description = "WMS行号")
	@JsonProperty(value = "WMSITEM")
	@JSONField(name = "WMSITEM")
	private String WMSITEM;

	@Schema(description = "特殊库存标识")
	@JsonProperty(value = "SOBKZ")
	@JSONField(name = "SOBKZ")
	private String SOBKZ;

	@Schema(description = "物料号")
	@JsonProperty(value = "MATNR")
	@JSONField(name = "MATNR")
	private String MATNR;

	@Schema(description = "工厂-固定值Lux")
	@JsonProperty(value = "WERKS")
	@JSONField(name = "WERKS")
	private String WERKS;

	@Schema(description = "库存地点")
	@JsonProperty(value = "LGORT")
	@JSONField(name = "LGORT")
	private String LGORT;

	@Schema(description = "实际出库数量")
	@JsonProperty(value = "ERFMG")
	@JSONField(name = "ERFMG")
	private String ERFMG;

	@Schema(description = "单位")
	@JsonProperty(value = "ERFME")
	@JSONField(name = "ERFME")
	private String ERFME;

	@Schema(description = "sap订单号")
	@JsonProperty(value = "VGBEL")
	@JSONField(name = "VGBEL")
	private String VGBEL;

	@Schema(description = "sap行号")
	@JsonProperty(value = "VGPOS")
	@JSONField(name = "VGPOS")
	private String VGPOS;

	@Schema(description = "交货完成标记")
	@JsonProperty(value = "ELIKZ")
	@JSONField(name = "ELIKZ")
	private String ELIKZ;

	@Schema(description = "项目文本")
	@JsonProperty(value = "SGTXT")
	@JSONField(name = "SGTXT")
	private String SGTXT;

	private String extendProps;

	private String orderNo;

	private String warehouseCode;

}
