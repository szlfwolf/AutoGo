package com.herdsric.oms.lotus.manages;

import cn.hutool.core.collection.CollectionUtil;
import com.herdsric.oms.common.client.stock.StockDefine;
import com.herdsric.oms.common.client.stock.domain.StockDm;
import com.herdsric.oms.common.client.stock.dto.StockDTO;
import com.herdsric.oms.common.client.stock.dto.StockVo;
import com.herdsric.oms.common.client.stock.process.StockProcessor;
import com.herdsric.oms.common.core.util.SpringContextHolder;
import com.herdsric.oms.lotus.common.LotusConstant;
import org.apache.commons.lang3.ObjectUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class StockManage extends CommonDefine implements StockDefine {

	public List<StockDm> queryStock(StockDTO stockDTO) {
		StockProcessor stockProcessor = SpringContextHolder.getBean(StockProcessor.class);
		// 查询到所有的零件
		List<StockDm> stockDms = stockProcessor.listStock(LotusConstant.CLIENT_CODE, stockDTO);

		if (CollectionUtil.isNotEmpty(stockDms)) {
			List<StockDm> collect = stockDms.stream().filter(stockDm -> ObjectUtils.isNotEmpty(stockDm.getPartNumber())
					&& ObjectUtils.isNotEmpty(stockDm.getWarehouseCode())).collect(Collectors.toList());

			// 提取 collect 中的 partNumber 到一个 List<String> 集合中
			List<String> partNumbers = collect.stream().map(StockDm::getPartNumber).collect(Collectors.toList());

			List<StockVo> stockList = stockProcessor.getStockList(partNumbers, stockDms.get(0).getWarehouseCode(),
					LotusConstant.CLIENT_CODE);

			Map<String, StockVo> stockVoMap = stockList.stream().collect(Collectors
					.toMap(stockVo -> stockVo.getPartNumber() + "_" + stockVo.getWarehouseCode(), Function.identity()));
			for (StockDm stockDm : stockDms) {
				// 生成查找用的键
				String key = stockDm.getPartNumber() + "_" + stockDm.getWarehouseCode();

				// 根据键从 Map 中获取对应的 StockVo 对象
				StockVo stockVo = stockVoMap.get(key);

				if (ObjectUtils.isNotEmpty(stockVo)) {
					Map<String, String> extendProps = new HashMap<>();

					extendProps.put(LotusConstant.nameCN, stockVo.getNameCN());
					extendProps.put(LotusConstant.nameEN, stockVo.getNameEN());
					extendProps.put(LotusConstant.unit, stockVo.getUnit());
					extendProps.put(LotusConstant.carModel, stockVo.getCarModel());
					extendProps.put(LotusConstant.indate, stockVo.getIndate());
					extendProps.put(LotusConstant.outdate, stockVo.getOutdate());
					extendProps.put(LotusConstant.moq, stockVo.getMoq());

					stockDm.setExtendProps(extendProps);
				}

			}
		}

		return stockDms;
	}

}
