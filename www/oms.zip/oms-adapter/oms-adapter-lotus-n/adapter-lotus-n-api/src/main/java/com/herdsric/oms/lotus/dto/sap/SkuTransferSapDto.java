package com.herdsric.oms.lotus.dto.sap;

import lombok.Data;

/**
 * @author tyy
 * @createDate 2024/4/30 16:59
 */
@Data
public class SkuTransferSapDto {

	private String clientCode;

	private String time;

}
