package com.herdsric.oms.lotus.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.herdsric.oms.common.mybatis.base.LogicDelBaseEntity;
import com.herdsric.oms.lotus.dto.sap.LotusDnLineBackDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.List;

/**
 * @author Herdsric
 * @TableName lotus_dn_voucher_write_off
 */
@TableName(value = "lotus_dn_voucher_write_off")
@Data
@EqualsAndHashCode(callSuper = true)
@Schema(description = "dn凭证冲销数据")
@Accessors(chain = true)
public class DnVoucherWriteOff extends LogicDelBaseEntity {

	/**
	 *
	 */
	@TableId(type = IdType.AUTO)
	@Schema(description = "主键")
	private Integer id;

	/**
	 * client
	 */
	@Schema(description = "client")
	private String clientCode;

	/**
	 * 仓库code
	 */
	@Schema(description = "仓库code")
	private String warehouseCode;

	/**
	 * 发送冲销时间
	 */
	@Schema(description = "发送冲销时间")
	private String sendWriteOffTime;

	/**
	 * 是否已发送凭证撤销（0：否；1：是）
	 */
	@Schema(description = "是否已发送凭证撤销（0：否；1：是）")
	private String sendWriteOff;

	/**
	 * 是否重发Dn（0：否；1：是）
	 */
	@Schema(description = "是否重发Dn（0：否；1：是）")
	private String resendDn;

	/**
	 * 出库订单号
	 */
	@Schema(description = "出库订单号")
	private String bzOutOrderNo;

	/**
	 * dn号
	 */
	@Schema(description = "dn号")
	private String dnNo;

	/**
	 * 响应内容
	 */
	private String responseContent;

	/**
	 * 发起状态(0:未冲销1：已冲销2：冲销失败)
	 */
	@Schema(description = "发起状态(0:未冲销1：已冲销2：冲销失败)")
	private String status;

	/**
	 * 发起状态名称(0:未发送1：已发送2：发送失败)
	 */
	@Schema(description = "发起状态(0:未发送1：已发送2：发送失败)")
	@TableField(exist = false)
	private String statusName;

	@TableField(exist = false)
	private List<LotusDnLineBackDTO> items;

}