package com.herdsric.oms.lotus.dto.lcms;

import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import java.io.Serializable;
import java.util.List;

/**
 * @author ：lzq
 * @date ：Created in 2022-12-15 0015 11:01 @description：
 * @modified By：
 * @version: $
 */
@Data
@Valid
public class SearchStockRequestDTO implements Serializable {

	/**
	 * 物料号
	 */
	private List<String> partCodeList;

	/***
	 * 配件名称
	 */
	private String partName;

	/**
	 * 仓库编码
	 */
	@NotBlank
	private String warehouseCode;

	/**
	 * 当前页
	 */
	private long current = 1L;

	/**
	 * 条数
	 */
	private long size = 10L;

}
