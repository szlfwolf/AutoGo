package com.herdsric.oms.lotus.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @author Herdsric
 * @TableName lotus_sku_voucher_line
 */
@Data
@Schema(description = "物料凭证明细")
@Accessors(chain = true)
@TableName("lotus_sku_voucher_line")
public class SkuVoucherLine implements Serializable {

	/**
	 *
	 */
	@TableId(type = IdType.AUTO)
	@Schema(description = "主键")
	private Integer id;

	/**
	 * wms单据号行号
	 */
	@Schema(description = "wms单据号行号")
	private String lineNo;

	/**
	 * 物料编码
	 */
	@Schema(description = "物料编码")
	private String partNumber;

	/**
	 * 移动类型 （采购入库 、退货，101； 盘点：盘盈701，盘亏702； 报废：551 库存调拨：311； 成本中心领用：广宣领用Z65；）
	 */
	@Schema(description = "移动类型 （采购入库 、退货，101；\n" + "盘点：盘盈701，盘亏702；\n" + "报废：551\n" + "库存调拨：311；\n"
			+ "成本中心领用：广宣领用Z65；")
	private String moveType;

	/**
	 * 收货库存地点
	 */
	@Schema(description = "收货库存地点")
	private String receiptAddressNo;

	/**
	 * 批次号
	 */
	@Schema(description = "批次号")
	private String batchNo;

	/**
	 * 数量
	 */
	@Schema(description = "数量")
	private BigDecimal num;

	/**
	 * 单位
	 */
	@Schema(description = "单位")
	private String unit;

	/**
	 * 发货库存地点
	 */
	@Schema(description = "发货库存地点")
	private String addressNo;

	/**
	 * 物料凭证id
	 */
	@Schema(description = "物料凭证id")
	private Integer skuVoucherId;

	/**
	 * SAP采购订单号
	 */
	@Schema(description = "SAP采购订单号")
	private String sapAsnNo;

	/**
	 * SAP采购订单行号
	 */
	@Schema(description = "SAP采购订单行号")
	private String sapAsnLineNo;

	/**
	 * asn订单号
	 */
	@Schema(description = "asn订单号")
	private String asnNo;

	/**
	 * asn订单行号
	 */
	@Schema(description = "asn订单行号")
	private String asnLineNo;

	/**
	 * 成本中心
	 */
	@Schema(description = "成本中心")
	private String costCenter;

	/**
	 * 创建时间
	 */
	@Schema(description = "创建时间")
	private String createTime;

	/**
	 * 创建人
	 */
	@Schema(description = "创建人")
	private String createBy;

	/**
	 * 更新时间
	 */
	@Schema(description = "更新时间")
	private String updateTime;

	/**
	 * 更新人
	 */
	@Schema(description = "主键")
	private String updateBy;

	/**
	 * 删除标识0：未删除，1：已删除
	 */
	@Schema(description = "删除标识0：未删除，1：已删除")
	private String isDelete;

	private static final long serialVersionUID = 1L;

}