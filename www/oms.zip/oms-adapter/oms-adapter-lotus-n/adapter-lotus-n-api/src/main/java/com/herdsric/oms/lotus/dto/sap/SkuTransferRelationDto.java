package com.herdsric.oms.lotus.dto.sap;

import lombok.Data;

import java.util.List;

/**
 * @author tyy
 * @createDate 2024/5/30 17:52
 */
@Data
public class SkuTransferRelationDto {

	private String lastTime;

	private List<String> asnNo;

	private String clientCode;

}
