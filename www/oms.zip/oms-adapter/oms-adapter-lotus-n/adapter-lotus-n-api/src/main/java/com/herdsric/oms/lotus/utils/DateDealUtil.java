package com.herdsric.oms.lotus.utils;

import cn.hutool.core.convert.Convert;
import cn.hutool.core.date.DateUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * 日期相关的操作
 *
 * @author Dawei
 */

@Slf4j
public class DateDealUtil {

	public static final long ONE_DAY = 86400;// 一天的秒数

	public static final String timeFormat = "yyyy-MM-dd HH:mm:ss";// 一天的秒数

	/**
	 * 欧洲时区
	 */
	private final static String TIME_ZONE_EUROPE = "Europe/Amsterdam";

	/**
	 * 北京时区
	 */
	private final static String TIME_ZONE_BEI = "UTC+8";

	/**
	 * 当天的开始时间
	 * @return
	 */
	public static long startOfTodDay() {
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		Date date = calendar.getTime();
		return date.getTime() / 1000;
	}

	/**
	 * 当天的结束时间
	 * @return
	 */
	public static long endOfTodDay() {
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.HOUR_OF_DAY, 23);
		calendar.set(Calendar.MINUTE, 59);
		calendar.set(Calendar.SECOND, 59);
		calendar.set(Calendar.MILLISECOND, 999);
		Date date = calendar.getTime();
		return date.getTime() / 1000;
	}

	/**
	 * 昨天的开始时间
	 * @return
	 */
	public static long startOfyesterday() {
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.add(Calendar.DATE, -1);
		calendar.set(Calendar.MILLISECOND, 0);
		Date date = calendar.getTime();
		return date.getTime() / 1000;
	}

	/**
	 * 昨天的结束时间
	 * @return
	 */
	public static long endOfyesterday() {
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.HOUR_OF_DAY, 23);
		calendar.set(Calendar.MINUTE, 59);
		calendar.set(Calendar.SECOND, 59);
		calendar.set(Calendar.MILLISECOND, 999);
		calendar.add(Calendar.DATE, -1);
		Date date = calendar.getTime();
		return date.getTime() / 1000;
	}

	/**
	 * 某天的开始时间
	 * @param dayUntilNow 距今多少天以前
	 * @return 时间戳
	 */
	public static long startOfSomeDay(int dayUntilNow) {
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		calendar.add(Calendar.DATE, -dayUntilNow);
		Date date = calendar.getTime();
		return date.getTime() / 1000;
	}

	/**
	 * 某天的結束时间
	 * @param dayUntilNow 距今多少天以前
	 * @return 时间戳
	 */
	public static long endOfSomeDay(int dayUntilNow) {
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.HOUR_OF_DAY, 23);
		calendar.set(Calendar.MINUTE, 59);
		calendar.set(Calendar.SECOND, 59);
		calendar.set(Calendar.MILLISECOND, 999);
		calendar.add(Calendar.DATE, -dayUntilNow);
		Date date = calendar.getTime();
		return date.getTime() / 1000;
	}

	/**
	 * 某天的年月日
	 * @param dayUntilNow 距今多少天以前
	 * @return 年月日map key为 year month day
	 */
	public static Map<String, Object> getYearMonthAndDay(int dayUntilNow) {
		Map<String, Object> map = new HashMap<String, Object>();
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		calendar.add(Calendar.DATE, -dayUntilNow);
		map.put("year", calendar.get(Calendar.YEAR));
		map.put("month", calendar.get(Calendar.MONTH) + 1);
		map.put("day", calendar.get(Calendar.DAY_OF_MONTH));
		return map;
	}

	/**
	 * 计算两个时间的间隔天数
	 * @param fDate 小的
	 * @param oDate 大的
	 * @return
	 */
	public static int daysOfTwo(Date fDate, Date oDate) {
		Calendar aCalendar = Calendar.getInstance();

		aCalendar.setTime(fDate);
		int day1 = aCalendar.get(Calendar.DAY_OF_YEAR);

		if (oDate == null) {
			aCalendar.setTime(new Date());
		}
		else {
			aCalendar.setTime(oDate);
		}
		int day2 = aCalendar.get(Calendar.DAY_OF_YEAR);

		return day2 - day1;
	}

	/**
	 * 将一个字符串转换成日期格式
	 * @param date
	 * @param pattern
	 * @return
	 */
	public static Date toDate(String date, String pattern) {
		if (("" + date).equals("")) {
			return null;
		}
		if (pattern == null) {
			pattern = "yyyy-MM-dd";
		}
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		Date newDate = new Date();
		try {
			newDate = sdf.parse(date);

		}
		catch (Exception ex) {
			ex.printStackTrace();
		}
		return newDate;
	}

	/**
	 * 把日期转换成字符串型
	 * @param date
	 * @param pattern
	 * @return
	 */
	public static String toString(Date date, String pattern) {
		if (date == null) {
			return "";
		}
		if (pattern == null) {
			pattern = "yyyy-MM-dd";
		}
		String dateString = "";
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		try {
			dateString = sdf.format(date);
		}
		catch (Exception ex) {
			ex.printStackTrace();
		}
		return dateString;
	}

	public static String toString(Long time, String pattern) {
		if (time > 0) {
			if (time.toString().length() == 10) {
				time = time * 1000;
			}
			Date date = new Date(time);
			String str = DateDealUtil.toString(date, pattern);
			return str;
		}
		return "";
	}

	/**
	 * 获取上个月的开始结束时间
	 * @return
	 */
	public static Long[] getLastMonth() {
		// 取得系统当前时间
		Calendar cal = Calendar.getInstance();
		int year = cal.get(Calendar.YEAR);
		int month = cal.get(Calendar.MONTH) + 1;

		// 取得系统当前时间所在月第一天时间对象
		cal.set(Calendar.DAY_OF_MONTH, 1);

		// 日期减一,取得上月最后一天时间对象
		cal.add(Calendar.DAY_OF_MONTH, -1);

		// 输出上月最后一天日期
		int day = cal.get(Calendar.DAY_OF_MONTH);

		String months = "";
		String days = "";

		if (month > 1) {
			month--;
		}
		else {
			year--;
			month = 12;
		}
		if (!(String.valueOf(month).length() > 1)) {
			months = "0" + month;
		}
		else {
			months = String.valueOf(month);
		}
		if (!(String.valueOf(day).length() > 1)) {
			days = "0" + day;
		}
		else {
			days = String.valueOf(day);
		}
		String firstDay = "" + year + "-" + months + "-01";
		String lastDay = "" + year + "-" + months + "-" + days;

		Long[] lastMonth = new Long[2];
		lastMonth[0] = DateDealUtil.getDateline(firstDay);
		lastMonth[1] = DateDealUtil.getDateline(lastDay);

		// //System.out.println(lastMonth[0] + "||" + lastMonth[1]);
		return lastMonth;
	}

	/**
	 * 获取当月的开始结束时间
	 * @return
	 */
	public static Long[] getCurrentMonth() {
		// 取得系统当前时间
		Calendar cal = Calendar.getInstance();
		int year = cal.get(Calendar.YEAR);
		int month = cal.get(Calendar.MONTH) + 1;
		// 输出下月第一天日期
		int notMonth = cal.get(Calendar.MONTH) + 2;
		// 取得系统当前时间所在月第一天时间对象
		cal.set(Calendar.DAY_OF_MONTH, 1);

		// 日期减一,取得上月最后一天时间对象
		cal.add(Calendar.DAY_OF_MONTH, -1);

		String months = "";
		String nextMonths = "";

		if (!(String.valueOf(month).length() > 1)) {
			months = "0" + month;
		}
		else {
			months = String.valueOf(month);
		}
		if (!(String.valueOf(notMonth).length() > 1)) {
			nextMonths = "0" + notMonth;
		}
		else {
			nextMonths = String.valueOf(notMonth);
		}
		String firstDay = "" + year + "-" + months + "-01";
		String lastDay = "" + year + "-" + nextMonths + "-01";
		Long[] currentMonth = new Long[2];
		currentMonth[0] = DateDealUtil.getDateline(firstDay);
		currentMonth[1] = DateDealUtil.getDateline(lastDay);

		// //System.out.println(lastMonth[0] + "||" + lastMonth[1]);
		return currentMonth;
	}

	public static long getTimestamp(String dateStr) {
		try {
			Date date = DateUtils.parseDate(dateStr, "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd", "yyyy/MM/dd HH:mm:ss",
					"yyyy/MM/dd", "yyyyMMddHHmmss");
			return date.getTime();
		}
		catch (ParseException e) {
			return 0;
		}
	}

	public static long getDateDiff(String startDate, String endDate) {
		try {
			Date start = DateUtils.parseDate(startDate, "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd", "yyyy/MM/dd HH:mm:ss",
					"yyyy/MM/dd");
			Date end = DateUtils.parseDate(endDate, "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd", "yyyy/MM/dd HH:mm:ss",
					"yyyy/MM/dd");
			return end.getTime() - start.getTime();
		}
		catch (Exception e) {
			return 0;
		}
	}

	public static long getTimeDiff(String startDate, String endDate) {
		try {
			Date start = DateUtils.parseDate(startDate, "HH:mm", "HH:mm:ss");
			Date end = DateUtils.parseDate(endDate, "HH:mm", "HH:mm:ss");
			return end.getTime() - start.getTime() > 0 ? end.getTime() - start.getTime()
					: end.getTime() - start.getTime() + 24 * 60 * 60 * 1000;
		}
		catch (Exception e) {
			return 0;
		}
	}

	public static String getDefMonth(String dateStr, String defaultVal) {
		long timestamp = getTimestamp(dateStr);
		if (timestamp == 0) {
			return defaultVal;
		}
		Calendar calendar = Calendar.getInstance();
		calendar.setTimeInMillis(timestamp);
		return String.valueOf(calendar.get(Calendar.MONTH) + 1);
	}

	public static long getDateline() {
		return System.currentTimeMillis() / 1000;
	}

	public static long getDateline(String date) {
		return (long) (toDate(date, "yyyy-MM-dd").getTime() / 1000);
	}

	public static long getDateHaveHour(String date) {
		return (long) (toDate(date, "yyyy-MM-dd HH").getTime() / 1000);
	}

	public static long getDateline(String date, String pattern) {
		return (long) (toDate(date, pattern).getTime() / 1000);
	}

	/***
	 * 获取文件后缀的时间
	 * @return
	 */
	public static String getFileNameTime() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd-HHmmss");
		String format = sdf.format(new Date());
		return format;
	}

	public static Date getCurUTCDate() {
		Calendar calendar = Calendar.getInstance();
		calendar.setTimeZone(TimeZone.getTimeZone("GMT"));
		return calendar.getTime();
	}

	// Date start = DateUtils.parseDate(startDate, "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd",
	// "yyyy/MM/dd HH:mm:ss", "yyyy/MM/dd");
	// public
	/**
	 * 日期相隔天数
	 * @param
	 * @param
	 * @return
	 */
	public static int getBetweenDays(String stime, String etime) {
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date sdate = null;
		Date eDate = null;
		try {
			sdate = df.parse(stime);
			eDate = df.parse(etime);
		}
		catch (ParseException e) {
			e.printStackTrace();
		}

		Long betweendays = (long) ((eDate.getTime() - sdate.getTime()) / (1000 * 60 * 60 * 24) + 0.5);// 天数间隔
		System.out.println("间隔天数" + betweendays.intValue() + "天");
		return betweendays.intValue();
	}

	/****
	 * 获取两个时间间隔多少秒
	 * @param beforeTime
	 * @param afterTime
	 * @Auther FanClys
	 * @CreateTime 2021-6-10 11:33:38
	 * @return
	 */
	public static int getTimeIntervalHMS(String beforeTime, String afterTime) {
		if (StringUtils.isEmpty(beforeTime) || StringUtils.isEmpty(afterTime)) {
			return 0;
		}
		int afterSeconds = Convert.toInt((toDate(afterTime, "yyyy-MM-dd HH:mm:ss").getTime() / 1000), 0);
		int beforeSeconds = Convert.toInt((toDate(beforeTime, "yyyy-MM-dd HH:mm:ss").getTime() / 1000), 0);
		return afterSeconds - beforeSeconds;
	}

	/***
	 * 获取当前系统时间字符串
	 * @param pattern
	 * @return
	 */
	public static String getNowTimeByFormat(String pattern) {
		ZoneId defaultZoneId = ZoneId.systemDefault();
		LocalDateTime localDateTime = LocalDateTime.now().atZone(defaultZoneId).toLocalDateTime();
		DateTimeFormatter dateTimeFormatter = null;
		if (StringUtils.isEmpty(pattern)) {
			// 格式化日期时间类型为字符串
			dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			String nowTime = dateTimeFormatter.format(localDateTime);
			return nowTime;
		}
		dateTimeFormatter = DateTimeFormatter.ofPattern(pattern);
		String nowTime = dateTimeFormatter.format(localDateTime).toString();
		return nowTime;
	}

	public static Boolean getTimeBetween(String time) {
		Long nowSecond = LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8"));
		long endSecond = LocalDateTime.parse(time).toEpochSecond(ZoneOffset.of("+8"));
		try {
			if ((nowSecond - endSecond) < 3 * 60 * 1000) {
				return true;
			}
		}
		catch (Exception e) {

			return false;
		}
		return false;
	}

	/**
	 * 校验传入的星期日期是否是今天
	 * @param dayOfWeek
	 * @return
	 */
	public static Boolean checkEqualDayOfWeek(String dayOfWeek) {
		String[] weekDays = { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };
		try {
			// 如果是北京时间时区设置GMT+8
			TimeZone.setDefault(TimeZone.getTimeZone("Europe/Amsterdam"));
			Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("Europe/Amsterdam"));
			String weekDay = weekDays[calendar.get(Calendar.DAY_OF_WEEK) - 1];
			log.info("------今天是：{}--------", weekDay);
			if (weekDay.equals(dayOfWeek)) {
				return true;
			}
		}
		catch (Exception e) {
			log.error("------校验传入的星期日期是否是今天异常：{}--------", e);
		}
		return false;
	}

	/***
	 * 时间转换
	 * @param date 转化的日期
	 * @param pattern 格式
	 * @return
	 */
	public static String strDateFormat(String date, String pattern) {
		if (StringUtils.isEmpty(date)) {
			return null;
		}
		try {
			SimpleDateFormat timeFormat1 = new SimpleDateFormat(pattern);
			return timeFormat1.format(DateUtil.parseDateTime(date));
		}
		catch (Exception e) {
			e.printStackTrace();
			log.error("时间转化异常:{}", e.getMessage());
		}
		return null;
	}

	/**
	 * 获取上一日yyyy-MM-dd
	 * @return
	 */
	public static String getYesterday() {
		return DateUtil.format(DateUtil.yesterday(), "yyyy-MM-dd");
	}

	public static String parseDateStr(String strDate) {
		if (StringUtils.isEmpty(strDate)) {
			return null;
		}
		Date date = null;
		try {
			SimpleDateFormat parser = new SimpleDateFormat("yyyyMMddHHmmss");
			date = parser.parse(strDate);
			return DateUtil.format(date, "yyyy-MM-dd HH:mm:ss");
		}
		catch (ParseException e) {
			e.printStackTrace();
			log.error("格式化失败" + e.getMessage());
			throw new RuntimeException("时间格式化错误");
		}
	}

	/**
	 * 校验时间格式是否为 yyyy-MM-dd HH:mm:ss
	 * @param date
	 * @return
	 */
	public static void isDateVail(String date) {
		// 用于指定 日期/时间 模式
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

		try {
			// Java 8 新添API 用于解析日期和时间
			LocalDateTime.parse(date, dtf);
		}
		catch (Exception e) {
			log.error("格式化失败" + e.getMessage());
			throw new RuntimeException("时间格式化错误");
		}
	}

	/**
	 * 欧洲时间转北京时间
	 * @param strDate
	 * @return
	 */
	public static String convertEUToCN(String strDate) {
		if (StringUtils.isBlank(strDate)) {
			strDate = DateUtil.now();
		}
		ZoneId oldZone = ZoneId.of(TIME_ZONE_EUROPE);
		ZoneId newZone = ZoneId.of(TIME_ZONE_BEI);
		DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(timeFormat);
		return LocalDateTime.parse(strDate, dateTimeFormatter).atZone(oldZone).withZoneSameInstant(newZone)
				.format(dateTimeFormatter);

	}

}
