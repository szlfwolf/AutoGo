package com.herdsric.oms.lotus.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * 物料凭证表
 *
 * @author dzx
 * @TableName lotus_sku_voucher
 */
@Data
@Schema(description = "物料凭证")
@Accessors(chain = true)
@TableName("lotus_sku_voucher")
public class SkuVoucher implements Serializable {

	/**
	 *
	 */
	@TableId(type = IdType.AUTO)
	@Schema(description = "主键")
	private Integer id;

	/**
	 * 发起凭证创建时间
	 */
	@Schema(description = "发起凭证创建时间")
	private String sendTime;

	/**
	 * 1.库存年终盘点2.库存报废回传3.库存调拨回传4.ASN收货回传5.库存领用回传
	 */
	@Schema(description = "1.库存年终盘点2.库存报废回传3.库存调拨回传4.ASN收货回传5.库存领用回传")
	private String operateType;

	/**
	 * 发起状态(0:未发送1：已发送2：发送失败)
	 */
	@Schema(description = "发起状态(0:未发送1：已发送2：发送失败)")
	private String status;

	/**
	 * 仓库code
	 */
	@Schema(description = "仓库code")
	private String warehouseCode;

	/**
	 * 参考物料凭证号
	 */
	@Schema(description = "参考物料凭证号")
	private String sapStockOrderNo;

	/**
	 * 货主
	 */
	@Schema(description = "货主")
	private String clientCode;

	/**
	 * 单号
	 */
	@Schema(description = "单号")
	private String orderNo;

	/**
	 * 是否已发送凭证创建（0：否；1：是）
	 */
	@Schema(description = "是否已发送凭证创建（0：否；1：是）")
	private String sendCreate;

	/**
	 * 是否已发送凭证撤销（0：否；1：是）
	 */
	@Schema(description = "是否已发送凭证撤销（0：否；1：是）")
	private String sendWriteOff;

	/**
	 * 发起凭证冲销时间
	 */
	@Schema(description = "发起凭证冲销时间")
	private String sendWriteOffTime;

	/**
	 * 创建时间
	 */
	@Schema(description = "创建时间")
	private String createTime;

	/**
	 * 创建人
	 */
	@Schema(description = "创建人")
	private String createBy;

	/**
	 * 更新时间
	 */
	@Schema(description = "更新时间")
	private String updateTime;

	/**
	 * 更新人
	 */
	@Schema(description = "更新人")
	private String updateBy;

	/**
	 * 删除标识0：未删除，1：已删除
	 */
	@Schema(description = "删除标识0：未删除，1：已删除")
	private String isDelete;

	private static final long serialVersionUID = 1L;

	/**
	 * 发起状态(0:未发送1：已发送2：发送失败)
	 */
	@Schema(description = "发起状态(0:未发送1：已发送2：发送失败)")
	@TableField(exist = false)
	private String statusCode;

}