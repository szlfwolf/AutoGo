package com.herdsric.oms.lotus.enums;

import com.herdsric.oms.common.core.validation.EnumValidator;

/**
 * TODO
 *
 * @author 52423
 * @date 2022-09-21 16:33
 */
public enum SkuPackageTypeEnum implements EnumValidator {

	KHTG("1", "客户提供"), RKBZ("2", "入库包装"), CCBZ("3", "存储包装"), PSBZ("4", "配送包装");

	public String value;

	public String desc;

	SkuPackageTypeEnum(String value, String desc) {
		this.value = value;
		this.desc = desc;
	}

	@Override
	public Object getValue() {
		return this.value;
	}

}
