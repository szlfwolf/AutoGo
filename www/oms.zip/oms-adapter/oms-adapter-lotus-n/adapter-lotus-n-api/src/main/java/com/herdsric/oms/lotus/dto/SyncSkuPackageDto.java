package com.herdsric.oms.lotus.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.experimental.Accessors;

import javax.validation.constraints.NotBlank;

/**
 * @Author : liangzhenlei
 * @Date : 2022/9/19 12:00
 */
@Data
@Accessors(chain = true)
public class SyncSkuPackageDto {

	/**
	 * 客户代码
	 */
	@Schema(description = "客户代码")
	private String clientCode;

	/**
	 * 零件代码
	 */
	@Schema(description = "零件代码")
	private String partNumber;

	/**
	 * 类型
	 */
	@Schema(description = "类型")
	private String type;

	/**
	 * 长度 mm
	 */
	@NotBlank(message = "长度不能为空")
	@Schema(description = "长度 mm")
	private String length;

	/**
	 * 宽度 mm
	 */
	@NotBlank(message = "宽度不能为空")
	@Schema(description = "宽度 mm")
	private String width;

	/**
	 * 高度 mm
	 */
	@NotBlank(message = "高度不能为空")
	@Schema(description = "高度 mm")
	private String height;

	/**
	 * 毛重 kg
	 */
	@NotBlank(message = "毛重不能为空")
	@Schema(description = "毛重 kg")
	private String grossWeight;

	/**
	 * 净重 kg
	 */
	@NotBlank(message = "净重不能为空")
	@Schema(description = "净重 kg")
	private String netWeight;

	/**
	 * 单位 pce:袋装 pcs:件
	 */
	@NotBlank(message = "Unit不能为空")
	@Schema(description = "单位 pce:袋装  pcs:件")
	private String unit;

	/**
	 * 单位包装内数量
	 */
	@NotBlank(message = "Moq不能为空")
	@Schema(description = "单位包装内数量")
	private String moq;

	/**
	 * remark1
	 */
	@Schema(description = "remark1")
	private String remark1;

	/**
	 * remark2
	 */
	@Schema(description = "remark2")
	private String remark2;

	/**
	 * 备注
	 */
	@Schema(description = "备注")
	private String remark3;

}
