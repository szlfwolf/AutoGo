package com.herdsric.oms.lotus.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.io.Serializable;

/**
 * @author ：lzq
 * @date ：Created in 2022-11-14 0014 15:56 @description：
 * @modified By：
 * @version: $
 */
@Data
@TableName("lotus_cost_center_master_data")
@Schema(description = "成本中心主数据")
public class CostCenterMasterData implements Serializable {

	@TableId
	@Schema(description = "成本中心编码")
	private String costCenterCode;

	@Schema(description = "成本中心描述")
	private String costCenterDescribed;

	@Schema(description = "控制范围")
	private String controlArea;

	@Schema(description = "公司代码")
	private String companyCode;

	@Schema(description = "负责人")
	private String principal;

	@Schema(description = "开始生效时间")
	private String startTime;

	@Schema(description = "有效截止时间")
	private String endTime;

	@Schema(description = "启用标识")
	private String enableFlag;

	@Schema(description = "状态")
	private String status;

}
