package com.herdsric.oms.lotus.dto.lcms;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author ：lzq
 * @date ：Created in 2022-12-12 0012 14:51 @description：
 * @modified By：
 * @version: $
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LcmsBillOfLadingInfoDTO implements Serializable {

	/**
	 * 包装箱号
	 */
	private String packageNo;

	/**
	 * 长
	 */
	private String packageLength;

	/**
	 * 宽
	 */
	private String packageWidth;

	/**
	 * 高
	 */
	private String packageHeight;

	/**
	 * 箱子净重
	 */
	private String packageNetweight;

	/**
	 * 箱子毛重
	 */
	private String packageGrossweight;

	/**
	 * 销售订单行项目编号
	 */
	private String itemno;

	/**
	 * 物料代码
	 */
	private String spCode;

	/**
	 * 交货单行项目编号
	 */
	private String dnitemNo;

	/**
	 * 数量
	 */
	private String deliveryQuantity;

	/**
	 * 扩展字段
	 */
	private String lineExtendProps;

}
