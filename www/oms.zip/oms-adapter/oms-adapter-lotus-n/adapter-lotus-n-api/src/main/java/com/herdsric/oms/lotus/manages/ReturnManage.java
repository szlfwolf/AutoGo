package com.herdsric.oms.lotus.manages;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.convert.Convert;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.herdsric.oms.common.client.asn.domain.ReturnOrderCreateDto;
import com.herdsric.oms.common.client.dn.domain.DnOrderDm;
import com.herdsric.oms.common.client.returns.ReturnBizDefine;
import com.herdsric.oms.common.client.returns.dm.AsnOrderReturnDm;
import com.herdsric.oms.common.client.returns.dto.AsnOrderReturnVo;
import com.herdsric.oms.common.client.returns.enums.ReturnEnum;
import com.herdsric.oms.common.client.returns.process.ReturnOrderProcess;
import com.herdsric.oms.common.core.constant.CommonConstants;
import com.herdsric.oms.common.core.constant.SecurityConstants;
import com.herdsric.oms.common.core.constant.enums.ExtendPropsEnum;
import com.herdsric.oms.common.core.constant.enums.SkuVoucherLineMoveTypeEnum;
import com.herdsric.oms.common.core.constant.enums.SkuVoucherOperateTypeEnum;
import com.herdsric.oms.common.core.constant.enums.SkuVoucherStatusEnum;
import com.herdsric.oms.common.core.exception.OmsBusinessException;
import com.herdsric.oms.common.core.util.JsonMapper;
import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.common.core.util.SpringContextHolder;
import com.herdsric.oms.lotus.api.RemoteLotusService;
import com.herdsric.oms.lotus.common.LotusConstant;
import com.herdsric.oms.lotus.dto.sap.SkuVoucherDto;
import com.herdsric.oms.lotus.dto.sap.SkuVoucherLineDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.compress.utils.Lists;
import org.apache.commons.lang3.ObjectUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author tyy
 * @createDate 2024/5/23 11:00
 */
@Slf4j
@RequiredArgsConstructor
public class ReturnManage extends CommonDefine implements ReturnBizDefine {

	@Override
	public void save(AsnOrderReturnDm asnOrderReturnDm) {
		ReturnOrderProcess returnOrderProcess = SpringContextHolder.getBean(ReturnOrderProcess.class);
		ReturnOrderCreateDto returnOrderCreateDto = new ReturnOrderCreateDto();
		Map<String, Object> extendProps = asnOrderReturnDm.getExtendProps();

		// 设置客户代码
		returnOrderCreateDto.setClientCode(LotusConstant.CLIENT_CODE);

		// 设置退货单源订单号
		returnOrderCreateDto.setSourceOrderNum(
				String.valueOf(extendProps.get(ExtendPropsEnum.LOTUS_SAP_SOURCE_ORDERNUM.getName())));

		// 设置退货类型
		returnOrderCreateDto
				.setReturnOrderType(String.valueOf(extendProps.get(ExtendPropsEnum.LOTUS_SAP_RETURN_TYPE.getName())));

		// 设置送货单号
		returnOrderCreateDto.setOrderNum(asnOrderReturnDm.getOrderNo());

		// 设置单据类型
		returnOrderCreateDto.setOrderType(asnOrderReturnDm.getOrderType());

		// 创建 itemList 列表
		List<ReturnOrderCreateDto.ReturnOrderLineVo> itemList = new ArrayList<>();

		// 遍历订单行
		for (DnOrderDm.OrderLine orderLine : asnOrderReturnDm.getOrderLines()) {
			// 创建 Item 对象
			ReturnOrderCreateDto.ReturnOrderLineVo item = new ReturnOrderCreateDto.ReturnOrderLineVo();

			// 复制属性
			BeanUtil.copyProperties(orderLine, item);

			item.setNum(String.valueOf(orderLine.getQty()));

			String json = JsonMapper.INSTANCE.toJson(orderLine.getExtendProps());
			// 设置 sap 订单号和行号
			item.setExtendProps(json);

			// 将 Item 对象添加到 itemList 列表中
			itemList.add(item);
		}
		// 设置 itemList
		returnOrderCreateDto.setItems(itemList);
		returnOrderProcess.saveAsnOrderLotus(returnOrderCreateDto);
	}

	@Override
	public void returnOrderResponseByWebhook(ReturnEnum returnEnum, String clientCode, String type, String orderNo) {
		ReturnOrderProcess returnOrderProcess = SpringContextHolder.getBean(ReturnOrderProcess.class);
		AsnOrderReturnVo asnOrderReturn = returnOrderProcess.getAsnOrderReturn(clientCode, orderNo);

		// 设置wmsNo为oms的asn号加 #六位随机数-废除
		String asnNo = asnOrderReturn.getOrderNo();

		// 添加凭证头信息
		String currentTime = DateUtil.now();
		SkuVoucherDto skuVoucher = new SkuVoucherDto()
				.setOperateType(SkuVoucherOperateTypeEnum.STOCK_ASN_RECEIPT.getValue())
				.setStatus(SkuVoucherStatusEnum.NOT_SEND.getValue()).setWarehouseCode(asnOrderReturn.getWarehouseCode())
				.setClientCode(CommonConstants.COMPANY_CODE_LOTUS).setOrderNo(asnNo).setCreateTime(currentTime)
				.setCreateBy(LotusConstant.LOTUS_SYSTEM).setUpdateTime(currentTime)
				.setUpdateBy(LotusConstant.LOTUS_SYSTEM);
		// 添加凭证行信息
		List<SkuVoucherLineDto> skuVoucherLineList = Lists.newArrayList();
		String sapAsnNo = null;
		String sapAsnLineNo = null;
		for (AsnOrderReturnVo.ReturnOrderLine returnOrderLine : asnOrderReturn.getOrderLine()) {

			System.out.println(returnOrderLine.getLineExtendProps());
			// 采购订单行号
			Map jsonObjectLine = JsonMapper.INSTANCE.fromJson(returnOrderLine.getLineExtendProps(), Map.class);

			if (ObjectUtils.isNotEmpty(jsonObjectLine)) {
				if (ObjectUtils.isEmpty(jsonObjectLine.get(ExtendPropsEnum.LOTUS_SAP_LINENO.getValue()))
						|| ObjectUtils.isEmpty(jsonObjectLine.get(ExtendPropsEnum.LOTUS_SAP_NO.getValue()))) {
					throw new RuntimeException("解析sap订单号失败");
				}
				sapAsnNo = String.valueOf(jsonObjectLine.get(ExtendPropsEnum.LOTUS_SAP_NO.getValue()));
				sapAsnLineNo = String.valueOf(jsonObjectLine.get(ExtendPropsEnum.LOTUS_SAP_LINENO.getValue()));
			}
			SkuVoucherLineDto skuVoucherLine = new SkuVoucherLineDto();
			skuVoucherLine.setLineNo(returnOrderLine.getLineNo()).setPartNumber(returnOrderLine.getPartNumber())
					.setAddressNo(asnOrderReturn.getWarehouseExtendProps()).setBatchNo(returnOrderLine.getBatchNo())
					.setNum(Convert.toBigDecimal(returnOrderLine.getNum())).setUnit(returnOrderLine.getUnit())
					.setSkuVoucherId(skuVoucher.getId()).setMoveType(SkuVoucherLineMoveTypeEnum.INBOUND.getValue())
					.setSapAsnNo(sapAsnNo).setSapAsnLineNo(sapAsnLineNo).setAsnNo(asnNo)
					.setAsnLineNo(returnOrderLine.getLineNo()).setCreateTime(currentTime)
					.setCreateBy(LotusConstant.LOTUS_SYSTEM).setUpdateTime(currentTime)
					.setUpdateBy(LotusConstant.LOTUS_SYSTEM);
			skuVoucherLineList.add(skuVoucherLine);
		}
		skuVoucher.setSkuVoucherLineDtoList(skuVoucherLineList);

		RemoteLotusService remoteLotusService = SpringContextHolder.getBean(RemoteLotusService.class);

		// 同步SAP
		R resultSap = remoteLotusService.SkuVoucher(skuVoucher, CommonConstants.COMPANY_CODE_LOTUS,
				SecurityConstants.FROM_IN);

		if (ObjectUtils.isEmpty(resultSap) || CommonConstants.SEND_LOTUS_SUCCESS_STATUS != resultSap.getCode()) {
			throw new OmsBusinessException("6005", StrUtil.format("AsnOrder退货单回传SAP异常,异常信息: {} ", resultSap.getMsg()));
		}

	}

}
