package com.herdsric.oms.lotus.api;

import com.herdsric.oms.common.core.constant.SecurityConstants;
import com.herdsric.oms.common.core.constant.ServiceNameConstants;
import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.lotus.dto.DnOrderVo;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author ：lzq
 * @date ：Created in 2022-10-31 0031 16:36 @description：
 * @modified By：
 * @version: $
 */
@FeignClient(contextId = "LotusDnOrderDetailService", value = ServiceNameConstants.OMS_SERVICE)
public interface RemoteLotusDnOrderDetailService {

	/**
	 * 查询DnOrder相关信息
	 * @return
	 */
	@PostMapping("/apis/dn/getDetail")
	R<List<DnOrderVo>> getDnOrderDetail(@RequestBody List<String> dnOrderList,
			@RequestHeader(name = "clientCode") String clientCode, @RequestHeader(SecurityConstants.FROM) String from);

	/**
	 * 查询Dn相关信息
	 * @return
	 */
	@PostMapping("/apis/dn/getDnAndWarehouse")
	R<List<DnOrderVo>> getDnAndWarehouse(@RequestBody List<String> dnOrderList,
			@RequestHeader(name = "clientCode") String clientCode, @RequestHeader(SecurityConstants.FROM) String from);

}
