/*
 *    Copyright (c) 2018-2025, lengleng All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * Neither the name of the oms4cloud.com developer nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 * Author: lengleng (wangiegie@gmail.com)
 */
package com.herdsric.oms.lotus.dto.sap;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.herdsric.oms.common.mybatis.base.LogicDelBaseEntity;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;

/**
 * 仓库基础表
 *
 * @author zcl
 * @date 2022-08-29 16:43:48
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Schema(description = "仓库基础表")
public class Warehouse extends LogicDelBaseEntity {

	/**
	 * 主键
	 */
	@Schema(description = "主键")
	private Integer id;

	/**
	 * 仓库代码
	 */
	@Schema(description = "仓库代码")
	private String warehouseCode;

	/**
	 * 仓库名称
	 */
	@Schema(description = "仓库名称")
	private String warehouseName;

	/**
	 * 父级仓库
	 */
	@Schema(description = "父级仓库")

	private String parentWarehouseCode;

	/**
	 * 国家代码
	 */
	@Schema(description = "国家代码")
	private String countryCode;

	/**
	 * 国家名称
	 */
	@Schema(description = "国家名称")
	private String countryName;

	/**
	 * 省份名称
	 */
	@Schema(description = "省份名称")
	private String provinceName;

	/**
	 * 市代码
	 */
	@Schema(description = "市代码")
	private String cityCode;

	/**
	 * 省份代码
	 */
	@Schema(description = "省份代码")
	private String provinceCode;

	/**
	 * 市名称
	 */
	@Schema(description = "市名称")
	private String cityName;

	/**
	 * 详细地址
	 */
	@Schema(description = "详细地址")
	private String address;

	/**
	 * 邮编代码
	 */
	@Schema(description = "邮编代码")
	private String zipCode;

	/**
	 * 联系人
	 */
	@Schema(description = "联系人")
	private String contactName;

	/**
	 * 联系人电话
	 */
	@Schema(description = "联系人电话")
	private String contactPhone;

	/**
	 * 联系人邮箱
	 */
	@Schema(description = "联系人邮箱")
	private String contactEmail;

	/**
	 * 唯智、Freja
	 */
	@Schema(description = "唯智、Freja")
	private String wms;

	/**
	 * 在建，装修中，使用，弃用
	 */
	@Schema(description = "在建，装修中，使用，弃用")
	private String status;

	/**
	 * 扩展字段
	 */
	@Schema(description = "扩展字段")
	private String extendProps;

}
