package com.herdsric.oms.lotus.dto.sap;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @author ：lzq
 * @date ：Created in 2023-01-11 0011 17:30 @description：
 * @modified By：
 * @version: $
 */
@Data
public class LcmsAsnFeedBackDTO implements Serializable {

	/**
	 * 入库单号
	 */
	private String inboundOrderNo;

	/**
	 * 承运单号
	 */
	private String toNo;

	/**
	 * 发运方式
	 */
	private String shipVia;

	/**
	 * 离开欧洲港口发往lce仓库的发运日期-时间戳
	 */
	private Long shipDate;

	/**
	 * 承运商名称
	 */
	private String forearderName;

	/**
	 * 承运商id
	 */
	private String forearderId;

	/**
	 * 交货单号
	 */
	private String doNo;

	/**
	 * 交货单状态
	 */
	private Integer toState;

	/**
	 * 签收人
	 */
	private String receivedBy;

	/**
	 * 签收日期-时间戳
	 */
	private Long receiveDate;

	/**
	 * 预计送达时间-时间戳
	 */
	private Long expecteDeliveryTime;

	/**
	 * 物流联系人
	 */
	private String contactPerson;

	/**
	 * 物流联系人电话
	 */
	private String contactPhone;

	/**
	 * 收货地址
	 */
	private String receiveAdress;

	/**
	 * 是否关单
	 */
	private Boolean isCloseOrder;

	/**
	 * 借用字段
	 */
	private String extendProps;

	/**
	 * 借用字段
	 */
	private String warehouseCode;

	/**
	 * 签收日期
	 */
	private Date receiveDateD;

	/**
	 * 预计送达时间
	 */
	private Date expecteDeliveryTimeD;

	/**
	 * 离开欧洲港口发往lce仓库的发运日期
	 */
	private Date shipDateD;

	/**
	 * 配件清单
	 */
	private List<LcmsAsnLineFeedBackDTO> syncDeliveryOrderDetailsReqList;

}
