package com.herdsric.oms.lotus.dto.lcms;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @Author tyy
 * @Date 2023/3/30 17:28
 * @PackageName:com.herdsric.oms.adapter.lotus.dto
 * @ClassName: QueryAvaInventoryDto
 * @Description:
 */
@Data
public class QueryAvaInventoryDto {

	@NotBlank(message = "物料号前缀不能为空")
	@Schema(description = "物料号前缀:ICO")
	private String partCodePrefix;

	@Schema(description = "物料号")
	private String partCode;

	@NotBlank(message = "仓库代码不能为空")
	@Schema(description = "仓库代码")
	private String warehouseCode;

	@Schema(description = "物料号名称")
	private String partName;

	/**
	 * 当前页
	 */
	private long current = 1L;

	/**
	 * 条数
	 */
	private long size = 10L;

}
