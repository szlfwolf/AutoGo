package com.herdsric.oms.lotus.dto.sap;

import com.alibaba.fastjson.annotation.JSONField;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.List;

/**
 * 请求物料凭证冲销Dto
 *
 * @author dzx
 * @TableName os_sku_voucher
 */
@Data
@Schema(description = "请求物料凭证冲销Dto")
@Accessors(chain = true)
public class SkuVoucherWriteOffReqDto implements Serializable {

	/**
	 * 年度
	 */
	@Schema(description = "年度")
	@JSONField(name = "MJAHR")
	private String year;

	/**
	 * 参考物料凭证号
	 */
	@Schema(description = "参考物料凭证号")
	@JSONField(name = "MBLNR")
	private String sapStockOrderNo;

	/**
	 * 过账时间
	 */
	@Schema(description = "过账时间")
	@JSONField(name = "BUDAT")
	private String postingDate;

	/**
	 * 冲销行信息
	 */
	@Schema(description = "冲销行信息")
	@JSONField(name = "ITEM")
	private List<SkuVoucherWriteOffItemReqDto> item;

	/**
	 * 存储响应信息
	 */
	@JSONField(serialize = false)
	private String responseContent;

	private static final long serialVersionUID = 1L;

}