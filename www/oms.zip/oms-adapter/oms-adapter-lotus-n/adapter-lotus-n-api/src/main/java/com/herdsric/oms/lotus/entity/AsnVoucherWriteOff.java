package com.herdsric.oms.lotus.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.herdsric.oms.common.mybatis.base.LogicDelBaseEntity;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.List;

/**
 * @author Herdsric
 * @TableName lotus_asn_voucher_write_off
 */

@Data
@TableName("lotus_asn_voucher_write_off")
@EqualsAndHashCode(callSuper = true)
@Schema(description = "asn凭证冲销")
@Accessors(chain = true)
public class AsnVoucherWriteOff extends LogicDelBaseEntity {

	/**
	 *
	 */
	@TableId(type = IdType.AUTO)
	@Schema(description = "主键")
	private Integer id;

	/**
	 * client
	 */
	@Schema(description = "client")
	private String clientCode;

	/**
	 * 仓库code
	 */
	@Schema(description = "仓库code")
	private String warehouseCode;

	/**
	 * 发送冲销时间
	 */
	@Schema(description = "发送冲销时间")
	private String sendWriteOffTime;

	/**
	 * 是否已发送凭证撤销（0：否；1：是）
	 */
	@Schema(description = "是否已发送凭证撤销（0：否；1：是）")
	private String sendWriteOff;

	/**
	 * 发送凭证创建时间
	 */
	@Schema(description = "发送凭证创建时间")
	private String sendCreateTime;

	/**
	 * 参考物料凭证号
	 */
	@Schema(description = "参考物料凭证号")
	private String sapStockOrderNo;

	/**
	 * 物料凭证单号(asn号)
	 */
	@Schema(description = "物料凭证单号(asn号)")
	private String voucherNo;

	/**
	 * 发起状态(0:未冲销1：已冲销2：冲销失败)
	 */
	@Schema(description = "发起状态(0:未冲销1：已冲销2：冲销失败)")
	private String status;

	/**
	 * 发起状态名称(0:未发送1：已发送2：发送失败)
	 */
	@Schema(description = "发起状态(0:未发送1：已发送2：发送失败)")
	@TableField(exist = false)
	private String statusName;

	/**
	 * 物料凭证行信息
	 */
	@TableField(exist = false)
	private List<AsnVoucherWriteOffLine> line;

	/**
	 * 存储响应信息
	 */
	@TableField(exist = false)
	private String responseContent;

}