package com.herdsric.oms.lotus.utils;

import cn.hutool.core.lang.Assert;
import org.apache.commons.lang3.StringUtils;

import javax.servlet.http.HttpServletRequest;

/**
 * @author tyy
 * @createDate 2022/5/23 18:36
 */
public class HeadGetClientCodeUtil {

	/**
	 * 请求头获取客户 clientCode
	 * @param request
	 * @return
	 */
	public static String getClientCode(HttpServletRequest request) {
		String clientCode = request.getHeader("clientCode");
		Assert.isTrue(StringUtils.isNotEmpty(clientCode), "请求头中客户编码不能为空");
		return clientCode;
	}

}
