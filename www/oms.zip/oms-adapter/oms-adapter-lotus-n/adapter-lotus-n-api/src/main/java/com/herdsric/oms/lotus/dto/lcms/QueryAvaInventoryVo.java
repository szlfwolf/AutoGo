package com.herdsric.oms.lotus.dto.lcms;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * @Author tyy
 * @Date 2023/3/30 17:37
 * @PackageName:com.herdsric.oms.adapter.lotus.dto
 * @ClassName: QueryAvaInventoryVo
 * @Description:
 */
@Data
public class QueryAvaInventoryVo {

	@Schema(description = "配件编码")
	private String partCode;

	@Schema(description = "配件英文名称")
	private String partNameEn;

	@Schema(description = "配件中文名称")
	private String partNameCn;

	@Schema(description = "仓库编码")
	private String warehouseCode;

	@Schema(description = "适用车型")
	private String vehicleModel;

	@Schema(description = "计量单位")
	private String spUint;

	@Schema(description = "包装量")
	private String moq;

	@Schema(description = "可用数量")
	private String availableQuantity;

}
