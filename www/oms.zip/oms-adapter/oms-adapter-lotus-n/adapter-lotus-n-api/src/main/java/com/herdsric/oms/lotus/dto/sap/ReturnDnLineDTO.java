package com.herdsric.oms.lotus.dto.sap;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * TODO
 *
 * @author 52423
 * @date 2022-09-08 16:26
 */
@Data
public class ReturnDnLineDTO {

	/**
	 * lineNo
	 */
	@Schema(description = "lineNo")
	@NotBlank(message = "行号不能为空")
	private String lineNo;

	/**
	 * batchNo
	 */
	@Schema(description = "batchNo")
	private String batchNo;

	/**
	 * partNumber
	 */
	@Schema(description = "partNumber")
	@NotBlank(message = "零件号不能为空")
	private String partNumber;

	/**
	 * unit
	 */
	@Schema(description = "unit")
	@NotBlank(message = "单位不能为空")
	private String unit;

	/**
	 * num
	 */
	@Schema(description = "num")
	@NotNull(message = "零件数量不能为空")
	private Double planNum;

	@NotNull(message = "实际数量不能为空")
	private Double actualNum;

	/**
	 * thirdMaterialNo
	 */
	@Schema(description = "thirdMaterialNo")
	private String thirdMaterialNo;

	/**
	 * variantNumber
	 */
	@Schema(description = "variantNumber")
	private String variantNumber;

	/**
	 * 仓库代码
	 */
	@Schema(description = "仓库代码")
	private String warehouseCode;

	/**
	 * 扩展字段
	 */
	@Schema(description = "扩展字段")
	private String extendProps;

}
