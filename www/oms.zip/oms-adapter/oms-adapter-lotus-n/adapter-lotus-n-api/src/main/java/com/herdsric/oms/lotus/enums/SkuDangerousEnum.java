package com.herdsric.oms.lotus.enums;

import com.alibaba.excel.util.StringUtils;
import com.herdsric.oms.common.core.validation.EnumValidator;

/**
 * 是否危险品
 *
 * @author 52423
 * @date 2022-09-05 17:40
 */
public enum SkuDangerousEnum implements EnumValidator {

	IS_DANGEROUS("0", "TRUE"), NO_DANGEROUS("1", "否");

	public String value;

	public String name;

	SkuDangerousEnum(String value, String name) {
		this.value = value;
		this.name = name;
	}

	@Override
	public Object getValue() {
		return this.name();
	}

	/**
	 * 通过name获取value
	 * @param name
	 * @return
	 */
	public static String getValueByName(String name) {
		if (StringUtils.isEmpty(name)) {
			return SkuDangerousEnum.NO_DANGEROUS.value;
		}
		for (SkuDangerousEnum enums : SkuDangerousEnum.values()) {
			if (enums.name.equals(name)) {
				return enums.value;
			}
		}
		return SkuDangerousEnum.NO_DANGEROUS.value;
	}

}
