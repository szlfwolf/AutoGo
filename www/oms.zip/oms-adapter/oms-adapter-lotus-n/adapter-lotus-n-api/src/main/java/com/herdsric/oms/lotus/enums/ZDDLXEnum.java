package com.herdsric.oms.lotus.enums;

import com.herdsric.oms.common.core.validation.EnumValidator;

/**
 * @author ：lzq lotus dn订单类型
 * @date ：Created in 2022-11-07 0007 10:35 @description：
 * @modified By：
 * @version: $
 */
public enum ZDDLXEnum implements EnumValidator {

	Z01("Z01", "Regular", "普通"), Z02("Z02", "Vor", "紧急"), Z03("Z03", "Z03", "三包"), Z04("Z04", "Z04", "定制"),
	Z05("Z05", "Z05", "海外"), Z06("Z06", "Z06", "直供"), Z07("Z07", "Z07", "货错保留"), CTC("C toC Customer", "To C", "CTC"),
	ZOR("ZOR", "ZOR", "LCE销售给各子公司"), ZRE("ZRE", "ZRE", "各子公司退回给LCE"), T01("T01", "T01", "T01"),
	T02("T02", "T02", "T02"), T03("T03", "T03", "T03"), T04("T04", "T04", "T04"), T05("T05", "T05", "T05"),
	TRE("TRE", "TRE", "TRE");

	public String key;

	public String value;

	public String descriptions;

	@Override
	public String getValue() {
		return this.key;
	}

	ZDDLXEnum(String key, String value, String descriptions) {
		this.key = key;
		this.value = value;
		this.descriptions = descriptions;
	}

	/***
	 * 获取OrderType
	 * @param key 传入key
	 * @return
	 */
	public static String getOrderType(String key) {
		for (ZDDLXEnum enums : ZDDLXEnum.values()) {
			if (enums.key.equals(key)) {
				return enums.value;
			}
		}
		return null;
	}

}
