package com.herdsric.oms.lotus.api;

import com.herdsric.oms.common.core.constant.SecurityConstants;
import com.herdsric.oms.common.core.constant.ServiceNameConstants;
import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.lotus.dto.sap.SkuVoucherDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

/**
 * @author ：lzq
 * @date ：Created in 2022-10-31 0031 16:36 @description：
 * @modified By：
 * @version: $
 */
@FeignClient(contextId = "LotusRemoteSkuVoucherService", value = ServiceNameConstants.ADAPTER_LOTUS_NEW)
public interface RemoteSkuVoucherService {

	/**
	 * 下发物料凭证创建到lotus
	 * @param skuVoucherDto
	 * @param form
	 * @return
	 */
	@PostMapping("/apis/skuVoucher/add")
	R skuVoucherCreate(@RequestBody SkuVoucherDto skuVoucherDto, @RequestHeader(SecurityConstants.FROM) String form);

}
