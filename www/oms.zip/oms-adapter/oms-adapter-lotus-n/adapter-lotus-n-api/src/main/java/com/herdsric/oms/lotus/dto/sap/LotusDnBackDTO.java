package com.herdsric.oms.lotus.dto.sap;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author ：lzq
 * @date ：Created in 2022-11-08 0008 11:17
 * @description：dn出库回传
 * @modified By：
 * @version: $
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL) // 只包含非空字段
public class LotusDnBackDTO implements Serializable {

	@Schema(description = "业务类型,1过账,2冲销,3删除")
	@JsonProperty(value = "ASNTYPE")
	@JSONField(name = "ASNTYPE")
	private String ASNTYPE;

	@Schema(description = "sap出库订单号")
	@JsonProperty(value = "ASNNO")
	@JSONField(name = "ASNNO")
	private String ASNNO;

	@Schema(description = "当前日期")
	@JsonProperty(value = "BLDAT")
	@JSONField(name = "BLDAT")
	private String BLDAT;

	@Schema(description = "凭证中的过账日期")
	@JsonProperty(value = "BUDAT")
	@JSONField(name = "BUDAT")
	private String BUDAT;

	@Schema(description = "用户名")
	@JsonProperty(value = "USNAM")
	@JSONField(name = "USNAM")
	private String USNAM;

	@Schema(description = "wms dn号")
	@JsonProperty(value = "WMSNO")
	@JSONField(name = "WMSNO")
	private String WMSNO;

	@Schema(description = "凭证抬头文本")
	@JsonProperty(value = "BKTXT")
	@JSONField(name = "BKTXT")
	private String BKTXT;

	@Schema(description = "重发标识")
	@JsonProperty(value = "RESEND")
	@JSONField(name = "RESEND")
	private String RESEND;

	@Schema(description = "交易类型 0发货|1退货|2移库")
	@JsonProperty(value = "zjylx")
	@JSONField(name = "zjylx")
	private String zjylx;

	@JsonProperty(value = "ITEM")
	@JSONField(name = "ITEM")
	private List<LotusDnLineBackDTO> ITEM;

	private String responseContent;

}
