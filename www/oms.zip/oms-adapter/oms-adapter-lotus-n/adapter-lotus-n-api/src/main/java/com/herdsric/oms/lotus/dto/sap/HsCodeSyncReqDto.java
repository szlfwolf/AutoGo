package com.herdsric.oms.lotus.dto.sap;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * @author Herdsric
 * @Tablevalue
 */
@Data
@Schema(description = "hsCode同步请求Dto")
@Accessors(chain = true)
public class HsCodeSyncReqDto implements Serializable {

	/**
	 * 物料编码
	 */
	@Schema(description = "物料编码")
	@JsonProperty(value = "MATNR")
	private String partNumber;

	/**
	 * 物料描述
	 */
	@Schema(description = "物料描述")
	@JsonProperty(value = "MAKTX")
	private String partDesc;

	/**
	 * HS_CODE
	 */
	@JsonProperty(value = "HS_CODE")
	private String hsCode;

	/**
	 * 国家
	 */
	@JsonProperty(value = "COUNTRY")
	private String countryCode;

	private static final long serialVersionUID = 1L;

}