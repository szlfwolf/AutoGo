package com.herdsric.oms.lotus.dto.newDTO;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@NoArgsConstructor
@Data
@Accessors(chain = true)
public class LotusNewCommonRespDto {

	@JsonProperty("status")
	private String status;

	@JsonProperty("errcode")
	private String errcode;

	@JsonProperty("message")
	private String message;

	@JsonProperty(" data ")
	private String data;

}
