package com.herdsric.oms.lotus.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.experimental.Accessors;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import java.util.List;

/**
 * @Description: 主数据Dto
 * @author: Dzx
 * @date: 2022.10.31
 */
@Data
@Accessors(chain = true)
@Schema(description = "Portal同步主数据并发送到WMSDto")
public class SyncSkuDto {

	/**
	 * 仓库不能为空
	 */
	@Schema(description = "仓库代码")
	@NotBlank(message = "仓库代码不能为空")
	private String warehouseCode;

	/**
	 * 客户代码
	 */
	@Schema(description = "客户代码")
	@NotBlank(message = "客户代码不能为空")
	private String clientCode;

	/**
	 * 品牌方
	 */
	@Schema(description = "品牌方")
	@NotBlank(message = "品牌方不能为空")
	private String brand;

	/**
	 * 供应商代码
	 */
	@Schema(description = "供应商代码")
	private String supplierCode;

	/**
	 * 供应商名字
	 */
	@Schema(description = "供应商名字")
	private String supplierName;

	/**
	 * 零件号
	 */
	@Schema(description = "零件号")
	@NotBlank(message = "零件号不能为空")
	private String partNumber;

	/**
	 * 零件号中文名称
	 */
	@Schema(description = "零件号中文名称")
	private String nameCn;

	/**
	 * 零件号英文名称
	 */
	@Schema(description = "零件号英文名称")
	private String nameEn;

	/**
	 * 零件描述
	 */
	@Schema(description = "零件描述")
	// @NotBlank(message = "零件描述不能为空")
	private String partDesc;

	/**
	 * 类型状态 n:新增 u:更新 c:取消
	 */
	@Schema(description = "类型状态 n:新增 u:更新 c:取消")
	@NotBlank(message = "类型状态不能为空") // 再加个枚举
	private String status;

	/**
	 * 是否危险品(y/n )
	 */
	@Schema(description = "是否危险品(y/n )")
	@NotBlank(message = "是否危险品不能为空")
	private String isDangerous;

	/**
	 * 是否允许摞放（y/n 目前未使用）| 目前正在使用叠放层数
	 */
	@Schema(description = "是否允许摞放（y/n 目前未使用）| 目前正在使用叠放层数")
	private String stackAllowed;

	/**
	 * 销售价格
	 */
	@Schema(description = "销售价格")
	private String sellingPrice;

	/**
	 * 采购价格
	 */
	@Schema(description = "采购价格")
	private String purchasPrice;

	/**
	 * 条码
	 */
	@Schema(description = "条码")
	private String ean;

	/**
	 * 单位
	 */
	@Schema(description = "单位")
	@NotBlank(message = "单位不能为空")
	private String unit;

	/**
	 * lhd：左驾 rhd：右驾
	 */
	@Schema(description = "lhd：左驾 rhd：右驾")
	private String hd;

	/**
	 * 车型
	 */
	@Schema(description = "车型")
	private String carModel;

	/**
	 * partType1
	 */
	@Schema(description = "partType1")
	private String partType1;

	/**
	 * partType2
	 */
	@Schema(description = "partType2")
	private String partType2;

	/**
	 * partType3
	 */
	@Schema(description = "partType3")
	private String partType3;

	/**
	 * partType4
	 */
	@Schema(description = "partType4")
	private String partType4;

	/**
	 * partType5
	 */
	@Schema(description = "partType5")
	private String partType5;

	/**
	 * 原厂地
	 */
	@Schema(description = "原厂地")
	private String originalSite;

	/**
	 * 包装单位集
	 */
	@Valid
	@Schema(description = "包装单位集")
	@NotEmpty(message = "包装单位集不能为空")
	private List<SyncSkuPackageDto> syncSkuPackageList;

	/**
	 * 旧替换零件号
	 */
	@Schema(description = "旧替换零件号")
	private String oldReplacePartNumber;

	/**
	 * 新替换零件号
	 */
	@Schema(description = "新替换零件号")
	private String newReplacePartNumber;

}
