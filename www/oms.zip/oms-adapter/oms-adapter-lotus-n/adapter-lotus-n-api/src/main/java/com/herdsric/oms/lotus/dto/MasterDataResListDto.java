package com.herdsric.oms.lotus.dto;

import com.alibaba.fastjson.annotation.JSONField;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * @Description: 主数据请求Dto
 * @author: Dzx
 * @date: 2022.10.31
 */
@Data
@Accessors(chain = true)
@Schema(description = "主数据响应Dto")
public class MasterDataResListDto {

	@JSONField(name = "matnr")
	private String matnr;

	@JSONField(name = "branded")
	private String branded;

	@JSONField(name = "maktx")
	private String maktx;

	@JSONField(name = "maktx_en")
	private String maktxEn;

	@JSONField(name = "meins")
	private String meins;

	@JSONField(name = "mtart")
	private String mtart;

	@JSONField(name = "matkl")
	private String matkl;

	@JSONField(name = "weightquantity")
	private String weightQuantity;

	@JSONField(name = "actualweight")
	private String actualWeight;

	@JSONField(name = "carmodel")
	private String carModel;

	@JSONField(name = "dangerousgoods")
	private String dangerousGoods;

	@JSONField(name = "suppliercode")
	private String supplierCode;

	@JSONField(name = "suppliername")
	private String supplierName;

	@JSONField(name = "replacementoldparts")
	private String replacementOldParts;

	@JSONField(name = "replacementnewparts")
	private String replacementNewParts;

	@JSONField(name = "length")
	private String length;

	@JSONField(name = "width")
	private String width;

	@JSONField(name = "height")
	private String height;

}
