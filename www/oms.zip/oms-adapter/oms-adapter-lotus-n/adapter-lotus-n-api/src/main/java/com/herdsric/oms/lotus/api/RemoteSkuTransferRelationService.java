package com.herdsric.oms.lotus.api;

import com.herdsric.oms.common.core.constant.SecurityConstants;
import com.herdsric.oms.common.core.constant.ServiceNameConstants;
import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.lotus.dto.sap.SkuTransferDto;
import com.herdsric.oms.lotus.dto.sap.SkuTransferRelationDto;
import com.herdsric.oms.lotus.dto.sap.Warehouse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author ：lzq
 * @date ：Created in 2022-10-31 0031 16:36 @description：
 * @modified By：
 * @version: $
 */
@FeignClient(contextId = "OmsService", value = ServiceNameConstants.OMS_SERVICE)
public interface RemoteSkuTransferRelationService {

	/**
	 * 进行向SAP同步 并创建物料凭证
	 * @return
	 */
	@PostMapping("/apis/skuTransferRelation/get")
	List<SkuTransferDto> getSkuTransferList(SkuTransferRelationDto skuTransferRelationDto,
			@RequestHeader(name = "clientCode") String clientCode, @RequestHeader(SecurityConstants.FROM) String from);

	/***
	 * 查询仓库信息
	 * @param clientCode
	 * @param fromIn
	 * @return
	 */
	@GetMapping("/apis/warehouse/getWarehouseExtend")
	R<List<Warehouse>> getWarehouseList(@RequestHeader(name = "clientCode") String clientCode,
			@RequestHeader(SecurityConstants.FROM) String fromIn);

}
