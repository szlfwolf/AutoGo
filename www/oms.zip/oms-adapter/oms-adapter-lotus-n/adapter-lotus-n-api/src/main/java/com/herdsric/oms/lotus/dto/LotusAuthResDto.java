package com.herdsric.oms.lotus.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * @author Herdsric
 * @TableName os_sku_voucher_line
 */
@Data
@Schema(description = "hsCodeDto")
@Accessors(chain = true)
public class LotusAuthResDto implements Serializable {

	/**
	 * 返回code
	 */
	@Schema(description = "code")
	private String code;

	/**
	 * data
	 */
	@Schema(description = "消息")
	private String data;

	/**
	 * 消息
	 */
	@Schema(description = "消息")
	private String message;

	private static final long serialVersionUID = 1L;

}