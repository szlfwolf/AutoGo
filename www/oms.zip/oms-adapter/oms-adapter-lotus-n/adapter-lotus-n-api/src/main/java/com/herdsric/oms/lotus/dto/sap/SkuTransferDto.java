package com.herdsric.oms.lotus.dto.sap;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.List;

/**
 * @Description: 物料调拨dnDto
 * @author: Dzx
 * @date: 2022.11.08
 */
@Data
@Accessors(chain = true)
@Schema(description = "物料调拨asnnDto")
public class SkuTransferDto {

	private String asnNo;

	private String transferOutWarehouseCode;

	private String transferInWarehouseCode;

	private String inBoundedTime;

	private List<SkuTransferLineDto> skuTransferLineDtoList;

}
