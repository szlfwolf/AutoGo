package com.herdsric.oms.lotus.dto;

import lombok.Data;

import java.util.List;

/**
 * @author tyy
 * @createDate 2024/6/6 15:53
 */
@Data
public class DnOrderVo {

	private String orderNo;

	private String warehouseCode;

	private String dnNo;

	private String remark;

	private String extendProp;

	private List<OrderLine> orderLineList;

	@Data
	public static class OrderLine {

		private String lineNo;

		private String partNumber;

		private String lineExtendProp;

		private Integer num;

		private String unit;

	}

}
