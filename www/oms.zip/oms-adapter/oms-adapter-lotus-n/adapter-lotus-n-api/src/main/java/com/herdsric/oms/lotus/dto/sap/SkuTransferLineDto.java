package com.herdsric.oms.lotus.dto.sap;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * @Description: 物料调拨dnDto
 * @author: Dzx
 * @date: 2022.11.08
 */
@Data
@Accessors(chain = true)
@Schema(description = "物料调拨dnDto")
public class SkuTransferLineDto {

	private String lineNo;

	private String partNumber;

	private String num;

	private String unit;

}
