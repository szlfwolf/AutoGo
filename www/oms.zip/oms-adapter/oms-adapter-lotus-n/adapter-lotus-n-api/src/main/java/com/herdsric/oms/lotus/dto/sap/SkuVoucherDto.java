package com.herdsric.oms.lotus.dto.sap;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.herdsric.oms.common.core.constant.enums.SkuVoucherOperateTypeEnum;
import com.herdsric.oms.common.core.constant.enums.SkuVoucherStatusEnum;
import com.herdsric.oms.common.core.validation.constraints.EnumCheck;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.experimental.Accessors;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import java.io.Serializable;
import java.util.List;

/**
 * 物料凭证表
 *
 * @author dzx
 * @TableName os_sku_voucher
 */
@Data
@Schema(description = "物料凭证")
@Accessors(chain = true)
public class SkuVoucherDto implements Serializable {

	/**
	 *
	 */
	@TableId(type = IdType.AUTO)
	@Schema(description = "主键")
	private Integer id;

	/**
	 * 发起时间
	 */
	@Schema(description = "发起时间")
	private String sendTime;

	/**
	 * 是否已创建
	 */
	@Schema(description = "是否发送已创建")
	private String sendCreate;

	/**
	 * 1.库存年终盘点2.库存报废回传3.库存调拨回传4.ASN收货回传5.库存领用回传
	 */
	@Schema(description = "1.库存年终盘点2.库存报废回传3.库存调拨回传4.ASN收货回传5.库存领用回传")
	@EnumCheck(SkuVoucherOperateTypeEnum.class)
	private String operateType;

	/**
	 * 发起状态(0:未发送1：已发送2：发送失败)
	 */
	@Schema(description = "发起状态(0:未发送1：已发送2：发送失败)")
	@EnumCheck(SkuVoucherStatusEnum.class)
	private String status;

	/**
	 * 参考物料凭证号
	 */
	@Schema(description = "参考物料凭证号")
	private String sapStockOrderNo;

	/**
	 * 仓库code
	 */
	@Schema(description = "仓库code")
	@NotBlank(message = "仓库code不能为空")
	private String warehouseCode;

	/**
	 * 货主
	 */
	@Schema(description = "货主")
	@NotBlank(message = "货主不能为空")
	private String clientCode;

	/**
	 * 单号
	 */
	@Schema(description = "单号")
	@NotBlank(message = "单号不能为空")
	private String orderNo;

	/**
	 * 创建时间
	 */
	@Schema(description = "创建时间")
	@NotBlank(message = "创建时间不能为空")
	private String createTime;

	/**
	 * 创建人
	 */
	@Schema(description = "创建人")
	private String createBy;

	/**
	 * 更新时间
	 */
	@Schema(description = "更新时间")
	private String updateTime;

	/**
	 * 更新人
	 */
	@Schema(description = "更新人")
	private String updateBy;

	/**
	 * 删除标识0：未删除，1：已删除
	 */
	@Schema(description = "删除标识0：未删除，1：已删除")
	private String isDelete;

	/**
	 * 凭证行数据
	 */
	@Valid
	@NotEmpty(message = "凭证行数据不能为空")
	private List<SkuVoucherLineDto> skuVoucherLineDtoList;

	private static final long serialVersionUID = 1L;

}