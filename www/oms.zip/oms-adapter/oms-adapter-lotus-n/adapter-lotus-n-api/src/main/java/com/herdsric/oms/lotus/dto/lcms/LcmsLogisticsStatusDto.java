package com.herdsric.oms.lotus.dto.lcms;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;

/**
 * @Author tyy
 * @Date 2023/4/4 15:33
 * @PackageName:com.herdsric.oms.adapter.lotus.dto
 * @ClassName: LcmsLogisticsStatusDto
 * @Description:
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LcmsLogisticsStatusDto {

	@Schema(description = "出库单号")
	@NotBlank(message = "luxmate出库单号不能为空")
	private String outboundOrderNo;

	@Schema(description = "业务单号")
	@NotBlank(message = "业务单号不能为空")
	private String businessNo;

	@Schema(description = "单据状态 0已打包|1已发货|已签收")
	@NotBlank(message = "单据状态不能为空")
	private Integer businessOrderState;

	@Schema(description = "业务类型 3:IOC移库单")
	@NotBlank(message = "业务类型不能为空")
	private String businessType;

	@Schema(description = "操作时间")
	private String operationDate;

	@Schema(description = "操作人")
	private String operation;

	private String sourceSystem;

}
