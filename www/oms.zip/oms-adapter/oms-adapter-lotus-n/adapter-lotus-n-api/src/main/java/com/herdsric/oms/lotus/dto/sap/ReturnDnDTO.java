package com.herdsric.oms.lotus.dto.sap;

import com.herdsric.oms.common.core.validation.RegexpConstants;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import java.util.HashMap;
import java.util.List;

/**
 * TODO
 *
 * @author 52423
 * @date 2022-09-07 19:10
 */
@Data
public class ReturnDnDTO {

	/**
	 * 仓库代码
	 */
	@Schema(description = "仓库代码")
	private String warehouseCode;

	/**
	 * 外部出库单号
	 */
	@Schema(description = "外部出库单号")
	@NotBlank(message = "外部出库单号不能为空")
	private String orderNum;

	/**
	 * 期望发货时间
	 */
	@Schema(description = "期望发货时间")
	@Pattern(regexp = RegexpConstants.YYYY_MM_DD_TIME)
	private String expectedDeliveryDate;

	/**
	 * ZCCK,QTCK
	 */
	@Schema(description = "ZCCK,QTCK")
	@NotBlank(message = "订单类型不能为空")
	private String orderType;

	/**
	 * 紧急单，普通单
	 */
	@Schema(description = "紧急单，普通单")
	private String urgentLevel;

	/**
	 * 订单来源方式:api,file
	 */
	@Schema(description = "订单来源方式:api,file")
	private String sourceType;

	/**
	 * 来源id: 交易号、文件id
	 */
	@Schema(description = "来源id: 交易号、文件id")
	private String sourceId;

	/**
	 * 国家代码
	 */
	@Schema(description = "国家代码")
	@NotBlank(message = "国家代码不能为空")
	private String countryCode;

	/**
	 * 客户地址代码
	 */
	private String customerCode;

	/**
	 * 国家名称
	 */
	@Schema(description = "国家名称")
	// @NotBlank(message = "国家名称不能为空")
	private String countryName;

	/**
	 * 省份代码
	 */
	@Schema(description = "省份代码")
	// @NotBlank(message = "省份名称不能为空")
	private String provinceCode;

	/**
	 * 省份名称
	 */
	@Schema(description = "省份名称")
	// @NotBlank(message = "省份名称不能为空")
	private String provinceName;

	/**
	 * 市代码
	 */
	@Schema(description = "市代码")
	private String cityCode;

	/**
	 * 市名称
	 */
	@Schema(description = "市名称")
	private String cityName;

	/**
	 * 详细地址
	 */
	@Schema(description = "详细地址")
	@NotBlank(message = "详细地址不能为空")
	private String address;

	/**
	 * 邮编代码
	 */
	@Schema(description = "邮编代码")
	@NotBlank(message = "邮编编码不能为空")
	private String zipCode;

	/**
	 * 收货联系人公司
	 */
	@Schema(description = "收货联系人公司")
	private String contactCompany;

	/**
	 * 联系人
	 */
	@Schema(description = "联系人")
	@NotBlank(message = "联系人不能为空")
	private String contactName;

	/**
	 * 联系人电话
	 */
	@Schema(description = "联系人电话")
	@NotBlank(message = "联系电话不能为空")
	private String contactPhone;

	/**
	 * 联系人邮箱
	 */
	@Schema(description = "联系人邮箱")
	private String contactEmail;

	/**
	 * 来源： 用于OMS 判断是否同步到Portal 默认：PORTAL
	 */
	private String tag;

	@Valid
	@NotEmpty(message = "零件清单不能为空")
	private List<ReturnDnLineDTO> items;

	/**
	 * 扩展字段
	 */
	@Schema(description = "扩展字段")
	private String extendProps;

	private HashMap<String, String> map;

}
