package com.herdsric.oms.lotus.manages;

import cn.hutool.core.bean.BeanUtil;
import com.herdsric.oms.common.client.enums.SyncEnum;
import com.herdsric.oms.common.client.hscode.HsCodeDefine;
import com.herdsric.oms.common.client.hscode.dto.HsCodeResponseDm;
import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.common.core.util.SpringContextHolder;
import com.herdsric.oms.common.webhook.CallbackHttpDefine;
import com.herdsric.oms.lotus.dto.LotusCommonReqDto;
import com.herdsric.oms.lotus.dto.sap.HsCodeSyncReqDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@RequiredArgsConstructor
public class HsCodeManage extends CommonDefine implements HsCodeDefine {

	/***
	 * HsCode 同步
	 * @param clientCode
	 * @param type
	 * @param hsCodeResponseDm
	 * @return
	 */
	@Override
	public R hsCodeSync(String clientCode, String type, List<HsCodeResponseDm> hsCodeResponseDm) {
		CallbackHttpDefine callbackHttpDefine = SpringContextHolder.getBean(CallbackHttpDefine.class);

		List<HsCodeSyncReqDto> hsCodeSyncReqDtoList = new ArrayList<>();
		for (HsCodeResponseDm codeResponseDm : hsCodeResponseDm) {
			HsCodeSyncReqDto hsCodeSyncReqDto = new HsCodeSyncReqDto();
			BeanUtil.copyProperties(codeResponseDm, hsCodeSyncReqDto);
			hsCodeSyncReqDtoList.add(hsCodeSyncReqDto);
		}
		R<Object> execute = callbackHttpDefine.execute(false, clientCode, null, null,
				new LotusCommonReqDto<List<HsCodeSyncReqDto>>().setRequestData(hsCodeSyncReqDtoList),
				SyncEnum.HSCODE_SYNC.name(), true);

		log.info("返回值:" + execute);
		return R.ok(hsCodeResponseDm);
	}

}
