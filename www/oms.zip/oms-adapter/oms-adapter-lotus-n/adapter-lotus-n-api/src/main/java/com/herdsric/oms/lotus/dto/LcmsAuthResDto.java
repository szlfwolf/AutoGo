package com.herdsric.oms.lotus.dto;

import com.alibaba.fastjson.annotation.JSONField;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * @author Herdsric
 * @TableName os_sku_voucher_line
 */
@Data
@Schema(description = "lcmsAuthResDto")
@Accessors(chain = true)
public class LcmsAuthResDto implements Serializable {

	/**
	 * 返回code
	 */
	@Schema(description = "code")
	private String code;

	/**
	 * data
	 */
	@Schema(description = "消息")
	private Data data;

	/**
	 * 消息
	 */
	@Schema(description = "消息")
	private String message;

	private static final long serialVersionUID = 1L;

	@lombok.Data
	public static class Data implements Serializable {

		/**
		 * accessToken
		 */
		@JSONField(name = "access_token")
		@Schema(description = "accessToken")
		private String accessToken;

		/**
		 * tokenType
		 */
		@JSONField(name = "token_type")
		@Schema(description = "tokenType")
		private String tokenType;

		/**
		 * 过期时间
		 */
		@JSONField(name = "expires_in")
		@Schema(description = "过期时间")
		private Long expiresIn;

		/**
		 * 范围
		 */
		@Schema(description = "范围")
		private String scope;

	}

}