package com.herdsric.oms.lotus.dto.sap;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @Description: asn凭证冲销Dto
 * @author: Dzx
 * @date: 2022.12.13
 */
@Data
@Schema(description = "asn凭证冲销Dto")
@EqualsAndHashCode
public class AsnWriteOffExcelDto {

	/**
	 * asn号
	 */
	@ExcelProperty("Asn No")
	@Schema(description = "asn号")
	@NotBlank(message = "Asn No不能为空")
	private String asnNo;

	/**
	 * 行号
	 */
	@ExcelProperty("Line No")
	@Schema(description = "行号")
	@NotBlank(message = "Line No不能为空")
	private String lineNo;

	/**
	 * 物料
	 */
	@ExcelProperty("Part Number")
	@Schema(description = "物料")
	@NotBlank(message = "Part Number不能为空")
	private String partNumber;

	/**
	 * 冲销数量
	 */
	@ExcelProperty("Qty")
	@Schema(description = "冲销数量")
	@NotNull(message = "Qty不能为空")
	@Min(value = 0, message = "Qty的值要大于等于0")
	private Integer qty;

	/**
	 * 预计数量
	 */
	@ExcelIgnore
	private Integer num;

	/**
	 * 实际收货数量
	 */
	@ExcelIgnore
	private Integer actualQty;

	/**
	 * 单位 （pce:袋装，pcs:件）
	 */
	@ExcelIgnore
	private String unit;

}
