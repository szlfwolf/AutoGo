package com.herdsric.oms.lotus.manages;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.StrUtil;
import com.herdsric.oms.common.client.asn.domain.WarehuseVo;
import com.herdsric.oms.common.client.dn.DnBizDefine;
import com.herdsric.oms.common.client.dn.domain.*;
import com.herdsric.oms.common.client.dn.dto.DnOrderResponseDTO;
import com.herdsric.oms.common.client.dn.enums.OrderSplitTypeEnum;
import com.herdsric.oms.common.client.dn.function.DnOptionFlag;
import com.herdsric.oms.common.client.dn.handle.DnOrderSplitFunction;
import com.herdsric.oms.common.client.dn.handle.SplitStrategy;
import com.herdsric.oms.common.client.dn.process.DnOrderProcessor;
import com.herdsric.oms.common.client.enums.PfepTypeEnum;
import com.herdsric.oms.common.client.enums.SyncEnum;
import com.herdsric.oms.common.core.constant.enums.ExtendPropsEnum;
import com.herdsric.oms.common.core.exception.ErrorCodeEnum;
import com.herdsric.oms.common.core.exception.OmsBusinessException;
import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.common.core.util.SpringContextHolder;
import com.herdsric.oms.common.security.util.SecurityUtils;
import com.herdsric.oms.common.webhook.CallbackHttpDefine;
import com.herdsric.oms.lotus.common.LotusConstant;
import com.herdsric.oms.lotus.dto.LotusCommonReqDto;
import com.herdsric.oms.lotus.dto.lcms.DeliveryInfoDTO;
import com.herdsric.oms.lotus.dto.lcms.DeliveryInfoLcmsPodDto;
import com.herdsric.oms.lotus.dto.lcms.LcmsBillOfLadingDTO;
import com.herdsric.oms.lotus.dto.lcms.LcmsLogisticsStatusDto;
import com.herdsric.oms.lotus.dto.newDTO.LotusNewCommonReqDto;
import com.herdsric.oms.lotus.dto.sap.LotusDnBackDTO;
import com.herdsric.oms.lotus.enums.ApiType;
import com.herdsric.oms.lotus.utils.LotusAndPortalBeanCovUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.function.Function;

@Slf4j
@RequiredArgsConstructor
public class DnOrderManage extends CommonDefine implements DnBizDefine {

	@Override
	public void save(DnOrderDm dnOrderDm) {
		dnOrderDm.setTypeEnum(OrderSplitTypeEnum.OS_00);
		dnOrderDm.setPfepTypeEnum(PfepTypeEnum.NO_BY_WAREHOUSE_CODE);
		DnOrderSplitFunction dnOrderSplitFunction = SplitStrategy.getStrategyFunction(dnOrderDm.getTypeEnum());
		dnOrderSplitFunction.preHandle(SecurityUtils.getTokenSupportClient(), dnOrderDm);
	}

	@Override
	public void dnOrderResponseByWebhook(String clientCode, String type, String batchNo) {
		CallbackHttpDefine callbackHttpDefine = SpringContextHolder.getBean(CallbackHttpDefine.class);
		DnOrderProcessor dnOrderProcessor = SpringContextHolder.getBean(DnOrderProcessor.class);

		Function<DnOptionFlag, Function<DnOrderResponseDTO, Boolean>> function = x -> {
			switch (x) {
				case Manual:
					return dm -> {
						log.info("{},BatchNo:{},dnOrder:{} 手动上传订单，不需要反馈", clientCode, batchNo, dm.getOrderNo());
						return false;
					};
				case Cancelled:
					return dm -> {
						log.info("{},BatchNo:{},dnOrder:{} 客户取消订单", clientCode, batchNo, dm.getOrderNo());
						// * 0:取消拣货，或者短拣 导致合单中某一个DN 一个零件数都没有则设置未整单无库存
						// * 2:仓库发起取消操作
						DnOrderCancelDm dnOrderCancelDm = BeanUtil.copyProperties(dm, DnOrderCancelDm.class);
						if (StrUtil.equals(dm.getNoInventoryType(), "0")) {
							dnOrderCancelDm.setReason("整单无库存");
						}
						else if (StrUtil.equals(dm.getNoInventoryType(), "2")) {
							dnOrderCancelDm.setReason("仓库发起取消操作");
						}
						else {
							dnOrderCancelDm.setReason("其他原因取消");
						}
						// 取消反馈客户
						LotusNewCommonReqDto lotusNewCommonReqDto = new LotusNewCommonReqDto()
								.setIsHead(dnOrderCancelDm).setUniqno(dnOrderCancelDm.getOrderNo());

						callbackHttpDefine.execute(false, clientCode, dm.getWarehouseCode(),
								dnOrderCancelDm.getOrderNo(), lotusNewCommonReqDto,
								SyncEnum.DN_ORDER_CANCEL_SYNC.name(), true);
						return true;
					};
				case Released:
					return dm -> {
						log.info("{},BatchNo:{},dnOrder:{} Released WMS，不需要反馈", clientCode, batchNo, dm.getOrderNo());
						return false;
					};
				case Packed:
					return dm -> { // 反馈SAP
						// 对象处理,特色业务逻辑
						DnOrderResponseDm dnOrderResponseDm = BeanUtil.copyProperties(dm, DnOrderResponseDm.class);

						String dnOrderType = dm.getValue(ExtendPropsEnum.LOTUS_TRADE_TYPE.getValue(), String.class);

						if (StrUtil.isBlank(dnOrderType)) {
							throw new OmsBusinessException(ErrorCodeEnum.E600306.code, "此订单的扩展信息为空,订单类型zjylx为空");
						}

						// 向SAP同步 DN物流状态信息 DN出库回传
						List<DnOrderLcmsResponseVo> dnOrderResponseSap = dnOrderProcessor
								.getDnOrderResponseSap(clientCode, dnOrderResponseDm);

						if (CollectionUtil.isEmpty(dnOrderResponseSap)) {
							log.info("向SAP同步物流信息异常,未查询到行信息");
							throw new OmsBusinessException(ErrorCodeEnum.E600307.code,
									"Abnormal synchronization of logistics information with SAP, no row information found");
						}

						LotusDnBackDTO lotusDnBackDTO = LotusAndPortalBeanCovUtil.toSapOutBound(dnOrderResponseSap,
								dnOrderResponseDm, dnOrderType, dnOrderResponseDm.getPackageTime());

						lotusDnBackDTO.setZjylx(dnOrderType);

						lotusDnBackDTO.setASNTYPE(LotusConstant.LOTUS_DN_PACKED_POST);
						lotusDnBackDTO.setUSNAM(LotusConstant.LOTUS_SEND_USER_NAME);
						callbackHttpDefine.execute(false, clientCode, dnOrderResponseDm.getWarehouseCode(),
								dnOrderResponseDm.getOrderNo(), new LotusCommonReqDto().setRequestData(lotusDnBackDTO),
								SyncEnum.DN_ORDER_STATUS_PACKED_SYNC.name(), true);
						// 调用完接口后修改回传客户状态
						dnOrderProcessor.updateByOrderNo(dnOrderResponseDm, clientCode);
						return true;
					};
				case Booked:
					return dm -> {
						// 对象处理,特色业务逻辑
						DnOrderResponseDm dnOrderResponseDm = BeanUtil.copyProperties(dm, DnOrderResponseDm.class);

						String dnOrderType = dm.getValue(ExtendPropsEnum.LOTUS_TRADE_TYPE.getValue(), String.class);

						if (StrUtil.isBlank(dnOrderType)) {
							throw new OmsBusinessException(ErrorCodeEnum.E600306.code, "此订单的扩展信息为空,订单类型zjylx为空");
						}

						// 判断是否是移库单类型
						if (StrUtil.equals(dnOrderType, LotusConstant.DN_DELIVELY_TYPE)) {
							List<DnOrderLcmsResponseVo> dnOrderResponseData = dnOrderProcessor
									.getDnOrderResponseData(clientCode, dnOrderResponseDm);

							// 查询仓库信息
							WarehuseVo warehouseDetail = dnOrderProcessor
									.getWarehouseDetail(dnOrderResponseDm.getWarehouseCode());
							// 查询地址信息
							ContactAddressVo contactAddressDetail = dnOrderProcessor
									.getContactAddressDetail(dnOrderResponseData.get(0).getAddressId());

							// 向LCMS同步承运单信息
							LcmsBillOfLadingDTO lcmsBillOfLadingDTO = LotusAndPortalBeanCovUtil.toLcmsBooked(
									dnOrderResponseDm, dnOrderResponseData, warehouseDetail, contactAddressDetail,
									dm.getShipType());
							callbackHttpDefine.execute(false, clientCode, dnOrderResponseDm.getWarehouseCode(),
									dnOrderResponseDm.getOrderNo(), lcmsBillOfLadingDTO,
									SyncEnum.DN_ORDER_STATUS_BOOKED_SYNC.name(), true);

						}
						return true;
					};
				case PickUp:
					return dm -> {
						// 对象处理,特色业务逻辑
						DnOrderResponseDm dnOrderResponseDm = BeanUtil.copyProperties(dm, DnOrderResponseDm.class);

						String dnOrderType = dm.getValue(ExtendPropsEnum.LOTUS_TRADE_TYPE.getValue(), String.class);

						if (StrUtil.isBlank(dnOrderType)) {
							throw new OmsBusinessException(ErrorCodeEnum.E600306.code, "此订单的扩展信息为空,订单类型zjylx为空");
						}

						// 向SAP同步 DN物流状态信息 DN出库回传
						List<DnOrderLcmsResponseVo> dnOrderResponseSap = dnOrderProcessor
								.getDnOrderResponseSap(clientCode, dnOrderResponseDm);

						if (CollectionUtil.isEmpty(dnOrderResponseSap)) {
							log.info("向SAP同步物流信息异常,未查询到行信息");
							throw new OmsBusinessException(ErrorCodeEnum.E600307.code,
									"Abnormal synchronization of logistics information with SAP, no row information found");
						}

						LotusDnBackDTO lotusDnBackDTO = LotusAndPortalBeanCovUtil.toSapOutBound(dnOrderResponseSap,
								dnOrderResponseDm, dnOrderType, dnOrderResponseDm.getPickUpTime());

						lotusDnBackDTO.setZjylx(dnOrderType);

						lotusDnBackDTO.setASNTYPE(LotusConstant.LOTUS_DN_BACK_POST);
						lotusDnBackDTO.setUSNAM(LotusConstant.LOTUS_SEND_USER_NAME);
						R<Object> execute = callbackHttpDefine.execute(false, clientCode,
								dnOrderResponseDm.getWarehouseCode(), dnOrderResponseDm.getOrderNo(),
								new LotusCommonReqDto().setRequestData(lotusDnBackDTO),
								ApiType.DN_ORDER_STATUS_OUTBOUND_SYNC_TO_SAP.name(), true);
						log.info("接口返回值信息:" + execute);
						// 调用完接口后修改回传客户状态
						dnOrderProcessor.updateByOrderNo(dnOrderResponseDm, clientCode);

						// 判断是否是移库单类型 LCMS 同步DN 正常单
						if (StrUtil.equals(dnOrderType, LotusConstant.DN_DELIVELY_TYPE)) {

							DeliveryInfoDTO deliveryInfoDTO = LotusAndPortalBeanCovUtil
									.toLcmsOutBoundNoRelocation(dnOrderResponseDm);
							deliveryInfoDTO.setEx(dm.getExtendProps());

							callbackHttpDefine.execute(false, clientCode, dnOrderResponseDm.getWarehouseCode(),
									dnOrderResponseDm.getOrderNo(), deliveryInfoDTO,
									SyncEnum.DN_ORDER_STATUS_OUTBOUND_SYNC.name(), true);
						}
						// 如果是移库单 LCMS
						if (StrUtil.equals(dnOrderType, LotusConstant.DN_TRANSACTION_TYPE)) {

							LcmsLogisticsStatusDto lcmsLogisticsStatusDto = LotusAndPortalBeanCovUtil
									.toLcmsOutBoundIsRelocation(dnOrderResponseDm);

							callbackHttpDefine.execute(false, clientCode, dnOrderResponseDm.getWarehouseCode(),
									dnOrderResponseDm.getOrderNo(), lcmsLogisticsStatusDto,
									ApiType.DN_ORDER_STATUS_OUTBOUND_SYNC_TO_LCMS_RELOCATION.name(), true);
						}

						return true;
					};

				case Delivery:
					return dm -> {
						// 对象处理,特色业务逻辑
						DnOrderResponseDm dnOrderResponseDm = BeanUtil.copyProperties(dm, DnOrderResponseDm.class);

						String dnOrderType = dm.getValue(ExtendPropsEnum.LOTUS_TRADE_TYPE.getValue(), String.class);

						if (StrUtil.isBlank(dnOrderType)) {
							throw new OmsBusinessException(ErrorCodeEnum.E600306.code, "此订单的扩展信息为空,订单类型zjylx为空");
						}

						// 判断是否是移库单类型 LCMS 同步DND到货信息 正常单
						if (StrUtil.equals(dnOrderType, LotusConstant.DN_DELIVELY_TYPE)) {
							DeliveryInfoLcmsPodDto deliveryInfoLcmsPodDto = LotusAndPortalBeanCovUtil
									.toLcmsPodNoRelocation(dnOrderResponseDm);
							deliveryInfoLcmsPodDto.setEx(dm.getExtendProps());

							callbackHttpDefine.execute(false, clientCode, dnOrderResponseDm.getWarehouseCode(),
									dnOrderResponseDm.getOrderNo(), deliveryInfoLcmsPodDto,
									SyncEnum.DN_ORDER_STATUS_POD_SYNC.name(), true);

						}
						// 如果是移库单类型 LCMS 同步DND到货信息
						if (StrUtil.equals(dnOrderType, LotusConstant.DN_TRANSACTION_TYPE)) {
							LcmsLogisticsStatusDto lcmsLogisticsStatusDto = LotusAndPortalBeanCovUtil
									.toLcmsPodIsRelocation(dnOrderResponseDm);

							callbackHttpDefine.execute(false, clientCode, dnOrderResponseDm.getWarehouseCode(),
									dnOrderResponseDm.getOrderNo(), lcmsLogisticsStatusDto,
									ApiType.DN_ORDER_STATUS_POD_SYNC_RELOCATION.name(), true);
						}

						return true;
					};
				default:
					return dm -> {
						// 其他情况不需要反馈
						return true;
					};
			}
		};
		dnOrderProcessor.dnOrderResponse(clientCode, type, batchNo, function);
	}

	@Override
	public void dnOrderCancelByWebhook(String clientCode, String batchNo) {

		DnOrderProcessor dnOrderProcessor = SpringContextHolder.getBean(DnOrderProcessor.class);
		Function<DnOptionFlag, Function<DnOrderResponseDTO, Boolean>> function = x -> {
			switch (x) {
				case Manual:
					return dm -> {
						log.info("{},BatchNo:{},dnOrder:{} 手动上传订单，不需要反馈", clientCode, batchNo, dm.getOrderNo());
						return false;
					};
				case Cancelled:
					return dm -> {
						log.info("{},BatchNo:{},dnOrder:{} 仓库发起取消订单", clientCode, batchNo, dm.getOrderNo());
						// * 0:取消拣货，或者短拣 导致合单中某一个DN 一个零件数都没有则设置未整单无库存
						// * 2:仓库发起取消操作
						DnOrderCancelDm dnOrderCancelDm = BeanUtil.copyProperties(dm, DnOrderCancelDm.class);
						dnOrderCancelDm.setReason("仓库发起取消操作");
						// 取消反馈客户
						CallbackHttpDefine callbackHttpDefine = SpringContextHolder.getBean(CallbackHttpDefine.class);

						LotusNewCommonReqDto lotusNewCommonReqDto = new LotusNewCommonReqDto()
								.setIsHead(dnOrderCancelDm).setUniqno(dnOrderCancelDm.getOrderNo());

						callbackHttpDefine.execute(false, clientCode, dm.getWarehouseCode(),
								dnOrderCancelDm.getOrderNo(), lotusNewCommonReqDto,
								SyncEnum.DN_ORDER_CANCEL_SYNC.name(), true);
						return true;
					};
				default:
					return dm -> {
						// 其他情况不需要反馈
						return true;
					};
			}
		};

		dnOrderProcessor.dnOrderCancelByWebhook(clientCode, batchNo, function);
	}

}
