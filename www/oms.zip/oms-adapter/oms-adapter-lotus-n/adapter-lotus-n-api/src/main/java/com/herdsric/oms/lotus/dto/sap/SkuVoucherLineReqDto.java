package com.herdsric.oms.lotus.dto.sap;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.herdsric.oms.common.core.constant.CommonConstants;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @author Herdsric
 * @TableName os_sku_voucher_line
 */
@Data
@Schema(description = "物料凭证明细")
@Accessors(chain = true)
public class SkuVoucherLineReqDto implements Serializable {

	/**
	 * wms单据号行号
	 */
	@Schema(description = "wms单据号行号")
	@JsonProperty(value = "WMSITEM")
	@JSONField(name = "WMSITEM")
	private String lineNo;

	/**
	 * 物料编码
	 */
	@Schema(description = "物料编码")
	@JsonProperty(value = "MATNR")
	@JSONField(name = "MATNR")
	private String partNumber;

	/**
	 * 移动类型 （采购入库 、退货，101； 盘点：盘盈701，盘亏702； 报废：551 库存调拨：311； 成本中心领用：广宣领用Z65；）
	 */
	@Schema(description = "移动类型 （采购入库 、退货，101；\n" + "盘点：盘盈701，盘亏702；\n" + "报废：551\n" + "库存调拨：311；\n"
			+ "成本中心领用：广宣领用Z65；")
	@JsonProperty(value = "BWART")
	@JSONField(name = "BWART")
	private String moveType;

	/**
	 * 工厂
	 */
	@JsonProperty(value = "WERKS", defaultValue = CommonConstants.LOTUS_FACTORY)
	@JSONField(name = "WERKS", defaultValue = CommonConstants.LOTUS_FACTORY)
	private String factory;

	/**
	 * 发货库存地点
	 */
	@Schema(description = "发货库存地点")
	@JsonProperty(value = "LGORT")
	@JSONField(name = "LGORT")
	private String addressNo;

	/**
	 * 批次号
	 */
	@Schema(description = "批次号")
	@JsonProperty(value = "CHARG")
	@JSONField(name = "CHARG")
	private String batchNo;

	/**
	 * 数量
	 */
	@Schema(description = "数量")
	@JsonProperty(value = "ERFMG")
	@JSONField(name = "ERFMG")
	private BigDecimal num;

	/**
	 * 单位
	 */
	@Schema(description = "单位")
	@JsonProperty(value = "ERFME")
	@JSONField(name = "ERFME")
	private String unit;

	/**
	 * SAP采购订单号
	 */
	@Schema(description = "SAP采购订单号")
	@JsonProperty(value = "EBELN")
	@JSONField(name = "EBELN")
	private String sapAsnNo;

	/**
	 * SAP采购订单行号
	 */
	@Schema(description = "SAP采购订单行号")
	@JsonProperty(value = "EBELP")
	@JSONField(name = "EBELP")
	private String sapAsnLineNo;

	/**
	 * asn订单号
	 */
	@Schema(description = "asn订单号")
	@JsonProperty(value = "ASNNO")
	@JSONField(name = "ASNNO")
	private String asnNo;

	/**
	 * asn订单行号
	 */
	@Schema(description = "asn订单行号")
	@JsonProperty(value = "ASNDETAILNO")
	@JSONField(name = "ASNDETAILNO")
	private String asnLineNo;

	/**
	 * 收货库存地点
	 */
	@Schema(description = "收货库存地点")
	@JsonProperty(value = "UMLGO")
	@JSONField(name = "UMLGO")
	private String receiptAddressNo;

	/**
	 * 成本中心
	 */
	@Schema(description = "成本中心")
	@JsonProperty(value = "KOSTL")
	@JSONField(name = "KOSTL")
	private String costCenter;

	private static final long serialVersionUID = 1L;

}