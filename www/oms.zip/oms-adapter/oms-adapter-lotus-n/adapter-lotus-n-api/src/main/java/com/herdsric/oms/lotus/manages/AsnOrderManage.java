package com.herdsric.oms.lotus.manages;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.convert.Convert;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.herdsric.oms.common.client.asn.AsnBizDefine;
import com.herdsric.oms.common.client.asn.domain.*;
import com.herdsric.oms.common.client.asn.dto.AsnOrderResponseDTO;
import com.herdsric.oms.common.client.asn.function.AsnOptionFlag;
import com.herdsric.oms.common.client.asn.process.AsnProcessor;
import com.herdsric.oms.common.client.enums.SyncEnum;
import com.herdsric.oms.common.client.enums.UnitEnum;
import com.herdsric.oms.common.core.constant.CommonConstants;
import com.herdsric.oms.common.core.constant.SecurityConstants;
import com.herdsric.oms.common.core.constant.enums.ExtendPropsEnum;
import com.herdsric.oms.common.core.constant.enums.SkuVoucherLineMoveTypeEnum;
import com.herdsric.oms.common.core.constant.enums.SkuVoucherOperateTypeEnum;
import com.herdsric.oms.common.core.constant.enums.SkuVoucherStatusEnum;
import com.herdsric.oms.common.core.exception.OmsBusinessException;
import com.herdsric.oms.common.core.util.JsonMapper;
import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.common.core.util.SpringContextHolder;
import com.herdsric.oms.common.webhook.CallbackHttpDefine;
import com.herdsric.oms.lotus.api.RemoteLotusService;
import com.herdsric.oms.lotus.common.LotusConstant;
import com.herdsric.oms.lotus.dto.LotusCommonReqDto;
import com.herdsric.oms.lotus.dto.sap.*;
import com.herdsric.oms.lotus.enums.ApiType;
import com.herdsric.oms.lotus.utils.LotusAndPortalBeanCovUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.compress.utils.Lists;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

@Slf4j
@RequiredArgsConstructor
public class AsnOrderManage extends CommonDefine implements AsnBizDefine {

	@Override
	public void save(AsnDm asnDm) {

	}

	@Override
	public boolean asnResponseByWebhook(String url, AsnDm asnDm) {
		return false;
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public void save(AsnOrderDm asnOrderDm) {
		log.info("处理客户下发的ASNOrder,当前单号:" + asnOrderDm.getOrderNo());

		AsnProcessor asnProcessor = SpringContextHolder.getBean(AsnProcessor.class);

		// 判断是否是DN退货单 //如果是DN退货单 ,进行创建BL,创建AsnOrder
		if (StrUtil.equals(asnOrderDm.getOrderType(), LotusConstant.DN_RETURN)) {

			BlAddDto blAddDto = LotusAndPortalBeanCovUtil.dnReturnToStandard(asnOrderDm);
			blAddDto.setClientCode(CommonConstants.COMPANY_CODE_LOTUS);
			asnProcessor.addBl(blAddDto);

			InOrderVo inOrderVo = LotusAndPortalBeanCovUtil.dnReturnToAsnOrder(asnOrderDm);
			asnProcessor.addAsnOrderDnReturn(inOrderVo);
		}
		else {
			asnProcessor.addAsnOrder(asnOrderDm);
		}

	}

	@Override
	public void asnOrderResponseByWebhook(String clientCode, String type, String orderNo) {
		AsnProcessor asnProcessor = SpringContextHolder.getBean(AsnProcessor.class);
		Function<AsnOptionFlag, Function<AsnOrderResponseDTO, Boolean>> function = x -> {
			switch (x) {
				case Manual:
					return dm -> {
						log.info("{},AsnOrder:{}, 手动上传订单，不需要反馈", clientCode, orderNo);
						return false;
					};
				case Responsed:
					return dm -> {
						CallbackHttpDefine callbackHttpDefine = SpringContextHolder.getBean(CallbackHttpDefine.class);
						// 对象处理,特色业务逻辑
						AsnOrderResponseDm asnOrderResponseDm = BeanUtil.copyProperties(dm, AsnOrderResponseDm.class);

						HashMap<String, String> warehouseExtendProp = asnProcessor
								.getWarehouseExtendProp(asnOrderResponseDm);

						if (StringUtils.isNotEmpty(asnOrderResponseDm.getOrderType())
								&& StringUtils.equals(CommonConstants.DN_RETURN, asnOrderResponseDm.getOrderType())) {
							LotusDnBackDTO lotusDnBackDTO = LotusAndPortalBeanCovUtil
									.dnToLotusDnReturnBack(asnOrderResponseDm, warehouseExtendProp);
							callbackHttpDefine.execute(false, clientCode, lotusDnBackDTO.getITEM().get(0).getLGORT(),
									lotusDnBackDTO.getASNNO(), new LotusCommonReqDto().setRequestData(lotusDnBackDTO),
									ApiType.DN_ORDER_RETURN.name(), true);
						}
						else {
							// 回传LCMS 关单标记true/false
							AsnOrderResponseLcmsDto lcmsAsnFeedBackDTO = asnProcessor
									.getLcmsAsnFeedback(asnOrderResponseDm, LotusConstant.CLIENT_CODE);
							if (ObjectUtil.isNotEmpty(asnOrderResponseDm)) {
								List<AsnOrderResponseLineDm> collect = asnOrderResponseDm.getOrderLines().stream()
										.filter(p -> p.getQty() > 0).collect(Collectors.toList());

								// 实际数量为0不需要反馈给客户
								if (CollectionUtils.isEmpty(collect)) {
									return true;
								}
								asnOrderResponseDm.setOrderLines(collect);
								SkuVoucherDto skuVoucher = new SkuVoucherDto();
								// 添加凭证头信息
								String currentTime = DateUtil.now();

								skuVoucher.setOperateType(SkuVoucherOperateTypeEnum.STOCK_ASN_RECEIPT.getValue());
								skuVoucher.setStatus(SkuVoucherStatusEnum.NOT_SEND.getValue());
								skuVoucher.setWarehouseCode(asnOrderResponseDm.getWarehouseCode());
								skuVoucher.setClientCode(CommonConstants.COMPANY_CODE_LOTUS);
								skuVoucher.setOrderNo(asnOrderResponseDm.getOrderNo());
								skuVoucher.setCreateTime(currentTime);
								skuVoucher.setCreateBy(CommonConstants.LOTUS_SYSTEM);
								skuVoucher.setUpdateTime(currentTime);
								skuVoucher.setUpdateBy(CommonConstants.LOTUS_SYSTEM);
								// 添加凭证行信息
								List<SkuVoucherLineDto> skuVoucherLineList = Lists.newArrayList();

								for (AsnOrderResponseLineDm orderLine : asnOrderResponseDm.getOrderLines()) {
									// 采购订单行号
									Map jsonObjectLine = JsonMapper.INSTANCE.fromJson(orderLine.getExtendProps(),
											Map.class);

									if (jsonObjectLine == null
											|| ObjectUtil.isEmpty(
													jsonObjectLine.get(ExtendPropsEnum.LOTUS_SAP_LINENO.getValue()))
											|| ObjectUtil.isEmpty(
													jsonObjectLine.get(ExtendPropsEnum.LOTUS_SAP_NO.getValue()))) {
										throw new RuntimeException("解析sap订单号失败,行信息扩展字段为空");
									}

									SkuVoucherLineDto skuVoucherLine = new SkuVoucherLineDto();
									skuVoucherLine.setLineNo(orderLine.getLineNo())
											.setPartNumber(orderLine.getPartNumber())
											.setAddressNo(
													warehouseExtendProp.get(asnOrderResponseDm.getWarehouseCode()))
											.setBatchNo(orderLine.getBatchNo())
											.setNum(Convert.toBigDecimal(orderLine.getQty()))
											.setUnit(orderLine.getUnit()).setSkuVoucherId(skuVoucher.getId())
											.setMoveType(SkuVoucherLineMoveTypeEnum.INBOUND.getValue())
											.setSapAsnNo(String.valueOf(
													jsonObjectLine.get(ExtendPropsEnum.LOTUS_SAP_NO.getValue())))
											.setSapAsnLineNo(String.valueOf(
													jsonObjectLine.get(ExtendPropsEnum.LOTUS_SAP_LINENO.getValue())))
											.setAsnNo(skuVoucher.getOrderNo()).setAsnLineNo(orderLine.getLineNo())
											.setCreateTime(currentTime).setCreateBy(CommonConstants.LOTUS_SYSTEM)
											.setUpdateTime(currentTime).setUpdateBy(CommonConstants.LOTUS_SYSTEM);
									skuVoucherLineList.add(skuVoucherLine);
								}
								skuVoucher.setSkuVoucherLineDtoList(skuVoucherLineList);

								RemoteLotusService remoteLotusService = SpringContextHolder
										.getBean(RemoteLotusService.class);

								// 同步SAP
								R resultSap = remoteLotusService.SkuVoucher(skuVoucher,
										CommonConstants.COMPANY_CODE_LOTUS, SecurityConstants.FROM_IN);

								if (ObjectUtils.isEmpty(resultSap)
										|| CommonConstants.SEND_LOTUS_SUCCESS_STATUS != resultSap.getCode()) {
									throw new OmsBusinessException("6005",
											StrUtil.format("AsnOrder回传SAP异常,异常信息: {} ", resultSap.getMsg()));
								}

								// 回传LCMS
								// 回传LCMS进行实体类映射
								WarehuseVo warehouseDetail = asnProcessor
										.getWarehouseDetail(asnOrderResponseDm.getWarehouseCode());

								LcmsAsnFeedBackDTO lcmsAsnFeedBackDTO1 = LotusAndPortalBeanCovUtil
										.inOrderToLcmsAsnResponse(asnOrderResponseDm, warehouseDetail,
												lcmsAsnFeedBackDTO);

								// 是否关单标记
								lcmsAsnFeedBackDTO1.setIsCloseOrder(false);

								List<LcmsAsnLineFeedBackDTO> lcmsAsnLineFeedBackDTOList = new ArrayList<>();
								for (AsnOrderResponseLineDm asnOrderResponseLineDm : collect) {
									LcmsAsnLineFeedBackDTO lcmsAsnLineFeedBackDTO = new LcmsAsnLineFeedBackDTO();
									lcmsAsnLineFeedBackDTO
											.setDeliveryQuantity(BigDecimal.valueOf(asnOrderResponseLineDm.getQty()));
									lcmsAsnLineFeedBackDTO.setExtendProps(asnOrderResponseLineDm.getExtendProps());
									lcmsAsnLineFeedBackDTO.setOrderNo(asnOrderResponseDm.getOrderNo());
									lcmsAsnLineFeedBackDTO.setSpCode(asnOrderResponseLineDm.getPartNumber());
									lcmsAsnLineFeedBackDTO.setSpUnit(asnOrderResponseLineDm.getUnit());

									lcmsAsnLineFeedBackDTOList.add(lcmsAsnLineFeedBackDTO);

								}

								lcmsAsnFeedBackDTO1.setSyncDeliveryOrderDetailsReqList(lcmsAsnLineFeedBackDTOList);
								for (LcmsAsnLineFeedBackDTO lcmsAsnLineFeedBackDTO : lcmsAsnFeedBackDTO1
										.getSyncDeliveryOrderDetailsReqList()) {
									// 转换单位
									if (StrUtil.equals(UnitEnum.PCS.value, lcmsAsnLineFeedBackDTO.getSpUnit())) {
										lcmsAsnLineFeedBackDTO.setSpUnit(UnitEnum.EA.value);
									}
									else {
										lcmsAsnLineFeedBackDTO
												.setSpUnit(UnitEnum.getUnitValue(lcmsAsnLineFeedBackDTO.getSpUnit()));
									}
									//
									Map jsonObject = JsonMapper.INSTANCE
											.fromJson(lcmsAsnLineFeedBackDTO.getExtendProps(), Map.class);
									if (ObjectUtils.isNotEmpty(jsonObject)) {
										// 采购订单号
										if (ObjectUtil
												.isNotEmpty(jsonObject.get(ExtendPropsEnum.LOTUS_SAP_NO.getValue()))) {
											lcmsAsnLineFeedBackDTO.setPoNo(String
													.valueOf(jsonObject.get(ExtendPropsEnum.LOTUS_SAP_NO.getValue())));
										}
										if (ObjectUtil.isNotEmpty(
												jsonObject.get(ExtendPropsEnum.LOTUS_ASN_LCMS_NO.getValue()))) {
											lcmsAsnLineFeedBackDTO.setSoNo(String.valueOf(
													jsonObject.get(ExtendPropsEnum.LOTUS_ASN_LCMS_NO.getValue())));
										}
									}
								}

								callbackHttpDefine.execute(false, clientCode, asnOrderResponseDm.getWarehouseCode(),
										asnOrderResponseDm.getOrderNo(), lcmsAsnFeedBackDTO1,
										SyncEnum.ASN_ORDER_RESPONSED_SYNC.name(), true);

							}

						}
						return true;
					};
				case Closed:
					return dm -> {
						CallbackHttpDefine callbackHttpDefine = SpringContextHolder.getBean(CallbackHttpDefine.class);
						// 对象处理,特色业务逻辑
						AsnOrderResponseDm asnOrderResponseDm = BeanUtil.copyProperties(dm, AsnOrderResponseDm.class);
						// 如果是DN退货单直接跳过
						if (!StrUtil.equals(asnOrderResponseDm.getOrderType(), LotusConstant.DN_RETURN)) {
							// 回传LCMS 关单标记true/false
							AsnOrderResponseLcmsDto lcmsAsnFeedBackDTO = asnProcessor
									.getLcmsAsnFeedback(asnOrderResponseDm, LotusConstant.CLIENT_CODE);

							WarehuseVo warehouseDetail = asnProcessor
									.getWarehouseDetail(asnOrderResponseDm.getWarehouseCode());
							// 回传LCMS进行实体类映射
							LcmsAsnFeedBackDTO lcmsAsnFeedBackDTO1 = LotusAndPortalBeanCovUtil
									.inOrderToLcmsAsnResponse(asnOrderResponseDm, warehouseDetail, lcmsAsnFeedBackDTO);
							// 是否关单标记
							lcmsAsnFeedBackDTO1.setIsCloseOrder(true);

							lcmsAsnFeedBackDTO1.setSyncDeliveryOrderDetailsReqList(null);
							callbackHttpDefine.execute(false, clientCode, asnOrderResponseDm.getWarehouseCode(),
									asnOrderResponseDm.getOrderNo(), lcmsAsnFeedBackDTO1,
									SyncEnum.ASN_ORDER_CLOSED_SYNC.name(), true);

							return true;
						}

						return true;
					};
				default:
					return dm -> {
						// 其他情况不需要反馈
						return true;
					};
			}
		};
		asnProcessor.asnOrderResponse(clientCode, type, orderNo, function);
	}

}
