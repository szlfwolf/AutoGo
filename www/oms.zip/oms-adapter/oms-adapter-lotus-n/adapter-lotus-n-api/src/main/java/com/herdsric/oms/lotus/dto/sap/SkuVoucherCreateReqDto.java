package com.herdsric.oms.lotus.dto.sap;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.herdsric.oms.common.core.constant.CommonConstants;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.experimental.Accessors;

import javax.validation.Valid;
import java.io.Serializable;
import java.util.List;

/**
 * 请求物料凭证Dto
 *
 * @author dzx
 * @TableName os_sku_voucher
 */
@Data
@Schema(description = "物料凭证")
@Accessors(chain = true)
public class SkuVoucherCreateReqDto implements Serializable {

	/**
	 * 凭证日期
	 */
	@Schema(description = "凭证日期")
	@JsonProperty(value = "BLDAT")
	@JSONField(name = "BLDAT")
	private String voucherDate;

	/**
	 * 凭证时间
	 */
	@Schema(description = "凭证时间")
	@JsonProperty(value = "ZTIME")
	@JSONField(name = "ZTIME")
	private String voucherTime;

	/**
	 * 过账时间
	 */
	@Schema(description = "过账日期")
	@JsonProperty(value = "BUDAT")
	@JSONField(name = "BUDAT")
	private String postingDate;

	/**
	 * 用户名
	 */
	@Schema(description = "用户名")
	@JsonProperty(value = "USNAM", defaultValue = CommonConstants.LOTUS_SEND_USER_NAME)
	@JSONField(name = "USNAM", defaultValue = CommonConstants.LOTUS_SEND_USER_NAME)
	private String userName;

	/**
	 * wms单据号
	 */
	@Schema(description = "wms单据号")
	@JsonProperty(value = "WMSNO")
	@JSONField(name = "WMSNO")
	private String orderNo;

	/**
	 * 凭证行数据
	 */
	@Valid
	@JsonProperty(value = "ITEM")
	@JSONField(name = "ITEM")
	private List<SkuVoucherLineReqDto> skuVoucherLineReqDtoList;

	private static final long serialVersionUID = 1L;

}