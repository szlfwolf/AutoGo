package com.herdsric.oms.lotus.dto.lcms;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author ：lzq
 * @date ：Created in 2022-12-13 0013 10:50
 * @description：lcms发货信息DTO
 * @modified By：
 * @version: $
 */
@Data
public class DeliveryInfoDTO implements Serializable {

	/**
	 * 请求来源
	 */
	private String sourceSystem;

	/**
	 * 承运单号
	 */
	private String toNo;

	/**
	 * sap交货订单号
	 */
	private String doNo;

	/**
	 * 发货时间
	 */
	private String shipDate;

	/**
	 * 时区
	 */
	private String tz;

	/**
	 * 运输轨迹地址
	 */
	private String toCycleLink;

	/**
	 * 扩展字段
	 */
	private String ex;

}
