package com.herdsric.oms.lotus.dto;

import com.alibaba.fastjson.annotation.JSONField;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 *
 * Lotus公用请求Dto
 *
 * @author dzx
 *
 */
@Data
@Schema(description = "Lotus公用请求Dto")
@Accessors(chain = true)
public class LotusCommonReqDto<T> {

	@Schema(description = "请求")
	@JSONField(name = "requestdata")
	private T requestData;

}