package com.herdsric.oms.lotus.dto;

import com.alibaba.fastjson.annotation.JSONField;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.List;

/**
 * @Description:
 * @author: Dzx
 * @date: 2022.11.17
 */
@Data
@Accessors(chain = true)
@Schema(description = "主数据响应Dto")
public class MasterDataResDto {

	/**
	 * 返回状态
	 */
	@Schema(description = "返回状态")
	@JSONField(name = "status")
	private String status;

	/**
	 * 消息
	 */
	@Schema(description = "消息")
	@JSONField(name = "message")
	private String message;

	/**
	 * 消息
	 */
	@Schema(description = "消息")
	@JSONField(name = "list")
	private List<MasterDataResListDto> list;

}
