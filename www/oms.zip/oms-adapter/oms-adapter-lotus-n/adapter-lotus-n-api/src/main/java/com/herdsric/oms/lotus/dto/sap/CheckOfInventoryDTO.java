package com.herdsric.oms.lotus.dto.sap;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.Data;

import java.io.Serializable;

/**
 * @author ：lzq
 * @date ：Created in 2022-11-09 0009 10:41 @description：
 * @modified By：
 * @version: $
 */
@Data
public class CheckOfInventoryDTO implements Serializable {

	/**
	 * 物料
	 */
	@JSONField(name = "MATNR")
	private String matnr;

	/**
	 * 工厂
	 */
	@JSONField(name = "WERKS")
	private String werks;

	/**
	 * 库存地点
	 */
	@JSONField(name = "LGORT")
	private String lgort;

	/**
	 * 数量
	 */
	@JSONField(name = "LABST")
	private String labst;

}
