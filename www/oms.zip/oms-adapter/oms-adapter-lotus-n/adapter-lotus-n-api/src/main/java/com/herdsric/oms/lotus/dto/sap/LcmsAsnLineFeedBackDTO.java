package com.herdsric.oms.lotus.dto.sap;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @author ：lzq
 * @date ：Created in 2023-01-11 0011 17:31 @description：
 * @modified By：
 * @version: $
 */
@Data
public class LcmsAsnLineFeedBackDTO implements Serializable {

	private String orderNo;

	/**
	 * 配件代码-必传
	 */
	private String spCode;

	/**
	 * 交货单行项目号
	 */
	private String dnitemno;

	/**
	 * 销售订单行项目号
	 */
	private String itemno;

	/**
	 * 采购单编码-必传
	 */
	private String poNo;

	/**
	 * 销售单编码-必传
	 */
	private String soNo;

	/**
	 * 承运数量-必传
	 */
	private BigDecimal deliveryQuantity;

	/**
	 * 单价
	 */
	private BigDecimal price;

	/**
	 * 单位
	 */
	private String spUnit;

	/**
	 * 借用字段
	 */
	private String extendProps;

}
