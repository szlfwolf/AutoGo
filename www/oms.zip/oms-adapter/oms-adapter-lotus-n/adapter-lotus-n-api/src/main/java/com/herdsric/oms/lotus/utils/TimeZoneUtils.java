package com.herdsric.oms.lotus.utils;

import cn.hutool.core.date.DateUtil;
import lombok.extern.slf4j.Slf4j;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Slf4j
public class TimeZoneUtils {

	/**
	 * 欧洲时区
	 */
	private final static String TIME_ZONE_EUROPE = "Europe/Amsterdam";

	/**
	 * LocalDateTime 转换
	 */
	private final static DateTimeFormatter dtftime = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

	/**
	 * LocalDateTime 转换
	 */
	private final static DateTimeFormatter dtfData = DateTimeFormatter.ofPattern("yyyyMMdd");

	/**
	 * Date 转换
	 */
	private final static SimpleDateFormat sdfTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	/**
	 * 时区转换（EDI中 爱驰的DN反馈操作时间转UTC有用到、接口鉴权中转UTC有用到）
	 * @param time
	 * @param timeZone
	 * @return
	 */
	public static String TimeZoneConversion(String time, String timeZone) {
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
			SimpleDateFormat sdftime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date parse = sdftime.parse(time);
			sdf.setTimeZone(TimeZone.getTimeZone(timeZone));
			return sdf.format(parse);
		}
		catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * 时间(格式：yyyyMMddHHmmss )转欧洲时区
	 * @param time yyyyMMddHHmmss
	 * @return yyyy-MM-dd HH:mm:ss
	 */
	public static String yyyyMMddHHmmssConvertEuropeTime(String time) {
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
			SimpleDateFormat sdftime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date parse = sdf.parse(time);
			sdftime.setTimeZone(TimeZone.getTimeZone(TIME_ZONE_EUROPE));
			return sdftime.format(parse);
		}
		catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * 将时间转欧洲时区
	 * @param time
	 * @param timeZone
	 * @return
	 */
	public static String TimeZoneConversionsdftime(String time, String timeZone) {
		try {
			SimpleDateFormat sdftime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date parse = sdftime.parse(time);
			sdftime.setTimeZone(TimeZone.getTimeZone(timeZone));
			return sdftime.format(parse);
		}
		catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * 获取当前欧洲日期
	 * @return yyyy-MM-dd 00:00:00
	 */
	public static String getNowEuropeanTimeOfYYYYMMddHHmmss() {
		try {
			SimpleDateFormat sdftime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date parse = sdftime.parse(DateUtil.now());
			sdftime.setTimeZone(TimeZone.getTimeZone(TIME_ZONE_EUROPE));
			return sdftime.format(parse).substring(0, 11) + "00:00:00";
		}
		catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * 获取今年的欧洲日期的第一天 2021-01-01 00:00:00
	 * @return
	 */
	public static String getNowEuropeanOfYearFirstDay() {
		try {
			SimpleDateFormat sdftime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date parse = sdftime.parse(DateUtil.now());
			sdftime.setTimeZone(TimeZone.getTimeZone(TIME_ZONE_EUROPE));
			return sdftime.format(parse).substring(0, 5) + "01-01 00:00:00";
		}
		catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	/***
	 * 时间转欧洲时区
	 * @param time yyyy-MM-dd HH:mm:ss
	 * @return
	 */
	public static String convertToEuropeTime(String time) {
		try {
			SimpleDateFormat sdftime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date parse = sdftime.parse(time);
			sdftime.setTimeZone(TimeZone.getTimeZone(TIME_ZONE_EUROPE));
			return sdftime.format(parse);
		}
		catch (Exception e) {
			log.error("将时间转成欧洲时区时间异常：" + e.getMessage(), e);
			return null;
		}
	}

	/***
	 * 获取当前欧洲时间
	 * @return
	 */
	public static String getEuropeNowTime() {
		return TimeZoneUtils.TimeZoneConversionsdftime(DateUtil.now(), TIME_ZONE_EUROPE);
	}

	/**
	 * 时间转换为欧洲时区（格式：yyyyMMddHHmmss）
	 * @param time yyyy-MM-dd HH:mm:ss
	 * @return yyyyMMddHHmmss
	 */
	public static String convertToEuropeTimeFormatyyyyMMddHHmmss(String time) {
		try {
			SimpleDateFormat sdftime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
			Date parse = sdftime.parse(time);
			sdf.setTimeZone(TimeZone.getTimeZone(TIME_ZONE_EUROPE));
			return sdf.format(parse);
		}
		catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	/***
	 * 获取当前欧洲时间-时间戳
	 * @return
	 */
	public static long getEuropeNowTimeMillions() {
		String europeTime = TimeZoneUtils.TimeZoneConversionsdftime(DateUtil.now(), TIME_ZONE_EUROPE);
		return DateUtil.parse(europeTime).getTime();
	}

	/***
	 * 时间转时间戳
	 * @return
	 */
	public static long dateTimeConvertMillions(String dateTime) {
		return DateUtil.parse(dateTime).getTime();
	}

	// public static void main(String[] args) {
	// String s = TimeZoneConversion("2021-06-18 00:00:00", "Etc/GMT-6");
	// System.out.println(s);
	// }
	public static String getEuropeNowTimedhl() {
		Date now = new Date(); // 创建一个Date对象，获取当前时间
		SimpleDateFormat dateParse = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		dateParse.setTimeZone(TimeZone.getTimeZone("GMT"));
		return dateParse.format(now);
	}

	public static String getEuropeNowTimedhlformat2(String shipTime) {

		try {
			String shipTimeAdd = addDateMinut(shipTime, 1);
			SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date parse = simpleDateFormat1.parse(shipTimeAdd);
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'GMT'XXX");
			simpleDateFormat.setTimeZone(TimeZone.getTimeZone(TIME_ZONE_EUROPE));
			return simpleDateFormat.format(parse);
		}
		catch (ParseException e) {
			e.printStackTrace();
			return null;
		}
	}

	public static String getEuropeNowTimedhlformat3() {
		Date now = new Date(); // 创建一个Date对象，获取当前时间
		SimpleDateFormat dateParse = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		dateParse.setTimeZone(TimeZone.getTimeZone("GMT"));
		return dateParse.format(now);
	}

	public static String getEuropeNowTimedhlformat4() {
		Date now = new Date(); // 创建一个Date对象，获取当前时间
		// SimpleDateFormat dateParse = new
		// SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'GMT'XXX");
		// dateParse.setTimeZone(TimeZone.getTimeZone("GMT"));
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'GMT'XXX");
		simpleDateFormat.setTimeZone(TimeZone.getTimeZone("Europe/Amsterdam"));
		return simpleDateFormat.format(now);
		// return dateParse.format(now);
	}

	/**
	 * 将时间戳转成字符串
	 * @param timestamp
	 * @return
	 */
	public static String timestampToDateString(Long timestamp) {
		LocalDateTime localDateTime = LocalDateTime.ofInstant(Instant.ofEpochMilli(timestamp), ZoneId.systemDefault());
		return dtftime.format(localDateTime);
	}

	/**
	 * 将LocalDateTime转成字符串
	 * @param localDateTime
	 * @return
	 */
	public static String localDateTimeToDateString(LocalDateTime localDateTime) {
		return dtftime.format(localDateTime);
	}

	/**
	 * 时间字符串转时间格式 yyyy-MM-dd HH:mm:ss
	 * @return
	 */
	public static Date DateStringConvertDateTime(String dateString) {
		try {
			sdfTime.setLenient(false); // 检查时间是否合法
			return sdfTime.parse(dateString);
		}
		catch (ParseException e) {
			log.error("字符串时间转Date异常：{}", e.getMessage());
		}
		return null;
	}

	public static void main(String[] args) throws ParseException {
		// Date now = new Date(); // 创建一个Date对象，获取当前时间
		// SimpleDateFormat dateParse = new
		// SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'GMT'XXX");
		// dateParse.setTimeZone(TimeZone.getTimeZone(TIME_ZONE_EUROPE));
		// System.out.println(dateParse.format(now));
		// System.out.println(getEuropeNowTimedhl());
		// String time = "2021-09-28 13:58:34";
		// System.out.println(getEuropeNowTimedhlformat2(time));

		// Date now = new Date( "2010-02-11T17:10:09 GMT+01:00");
		// SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		// dateParse.setTimeZone(TimeZone.getTimeZone(TIME_ZONE_EUROPE));
		// System.out.println(simpleDateFormat.format(now));
		// SimpleDateFormat simpleDateFormat = new
		// SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'GMT+'XXX");
		// Date now = new Date(); // 创建一个Date对象，获取当前时间
		// Date parse = simpleDateFormat.parse(DateUtil.now());
		// String format = simpleDateFormat.format(now);
		// System.out.println(format);

		// System.out.println(DateStringConvertDateTime("2021-05-4 11:00:00"));

		Set<String> strSet = new HashSet<>();
		strSet.add("2021-01-04");
		strSet.add("2021-01-05");
		System.out.println(strSet);

	}

	/**
	 * 给时间加上几个小时
	 * @param day 当前时间 格式：yyyy-MM-dd HH:mm:ss
	 * @param minute 需要加的时间
	 * @return
	 */
	public static String addDateMinut(String day, int minute) {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = null;
		try {
			date = format.parse(day);
		}
		catch (Exception ex) {
			ex.printStackTrace();
		}
		if (date == null) {
			return "";
		}
		System.out.println("front:" + format.format(date)); // 显示输入的日期
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.MINUTE, minute);// 24小时制
		date = cal.getTime();
		System.out.println("after:" + format.format(date)); // 显示更新后的日期
		cal = null;
		return format.format(date);

	}

	/**
	 * 获取UTC+0时区的当前时间字符串
	 * @return
	 */
	public static String getNowDateTimeUtc0Str() {
		LocalDateTime now = LocalDateTime.now(ZoneId.of("UTC+0"));
		return now.format(dtftime);
	}

	/**
	 * 获取当前北京日期字符串
	 * @return
	 */
	public static String getNowDateUtc8Str() {
		LocalDateTime now = LocalDateTime.now(ZoneId.of("UTC+8"));
		return now.format(dtfData);
	}

}
