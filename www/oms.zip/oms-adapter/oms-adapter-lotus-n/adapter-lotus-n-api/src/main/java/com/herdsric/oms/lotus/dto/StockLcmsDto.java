package com.herdsric.oms.lotus.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.util.List;

/**
 * @author tyy
 * @createDate 2024/5/9 10:42
 */

@Data
public class StockLcmsDto {

	/**
	 * 物料号
	 */
	private List<String> partCodeList;

	/***
	 * 配件名称
	 */
	private String partName;

	/**
	 * 仓库编码
	 */
	@NotBlank
	private String warehouseCode;

}
