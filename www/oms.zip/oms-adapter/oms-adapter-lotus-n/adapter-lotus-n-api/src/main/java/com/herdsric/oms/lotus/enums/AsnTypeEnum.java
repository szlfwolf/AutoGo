package com.herdsric.oms.lotus.enums;

import com.herdsric.oms.common.core.validation.EnumValidator;
import lombok.Getter;

/**
 * TODO
 *
 * @author 52423
 * @date 2022-08-31 16:19
 */
@Getter
public enum AsnTypeEnum implements EnumValidator {

	ZCRK("0", "ZCRK", "正常入库"), THRK("1", "THRK", "退货入库");

	public String key;

	public String value;

	public String description;

	AsnTypeEnum(String key, String value, String description) {
		this.key = key;
		this.value = value;
		this.description = description;
	}

	@Override
	public String getValue() {
		return this.key;
	}

	/***
	 * 获取value
	 * @param key 传入key
	 * @return
	 */
	public static String getValueBykey(String key) {
		for (AsnTypeEnum enums : AsnTypeEnum.values()) {
			if (enums.key.equals(key)) {
				return enums.value;
			}
		}

		return AsnTypeEnum.ZCRK.value;
	}

}
