package com.herdsric.oms.lotus.api;

import com.herdsric.oms.common.core.constant.SecurityConstants;
import com.herdsric.oms.common.core.constant.ServiceNameConstants;
import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.lotus.dto.sap.LoutsStockVo;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;

/**
 * @Author : liangzhenlei
 * @Date : 2022/11/11 15:22
 */
@FeignClient(contextId = "remoteLotusStockService", value = ServiceNameConstants.ADAPTER_LOTUS_NEW)
public interface RemoteLotusStockService {

	@PostMapping("/lcms/CheckOfInventory")
	R checkOfInventory(LoutsStockVo loutsStockVo, @RequestHeader(SecurityConstants.FROM) String from);

}
