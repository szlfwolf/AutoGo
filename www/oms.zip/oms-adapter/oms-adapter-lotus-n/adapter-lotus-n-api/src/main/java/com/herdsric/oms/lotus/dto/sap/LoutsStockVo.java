package com.herdsric.oms.lotus.dto.sap;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import java.util.List;

/**
 * 路特斯库存请求对象
 *
 * @Author : liangzhenlei
 * @Date : 2022/11/11 15:25
 */
@Data
@Schema(description = "路特斯库存请求对象")
public class LoutsStockVo {

	/**
	 * 仓库代码
	 */
	@NotEmpty(message = "仓库代码不能为空")
	@Schema(description = "仓库代码")
	private String warehouseCode;

	/**
	 * 零件号
	 */
	@Valid
	@Schema(description = "零件号")
	private List<String> partNumberList;

	private String warehouseExtendProps;

}
