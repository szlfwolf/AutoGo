package com.herdsric.oms.lotus.manages;

import cn.hutool.core.util.StrUtil;
import com.herdsric.oms.common.client.common.BaseDefine;
import com.herdsric.oms.lotus.common.LotusConstant;

public class CommonDefine implements BaseDefine {

	@Override
	public boolean isSupport(String clientCode) {
		return StrUtil.equals(LotusConstant.CLIENT_CODE, clientCode);
	}

}
