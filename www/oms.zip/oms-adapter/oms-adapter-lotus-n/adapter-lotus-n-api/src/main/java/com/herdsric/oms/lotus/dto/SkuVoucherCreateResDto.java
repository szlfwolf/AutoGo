package com.herdsric.oms.lotus.dto;

import com.alibaba.fastjson.annotation.JSONField;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * 物料凭证响应Dto
 *
 * @author dzx
 * @TableName os_sku_voucher
 */
@Data
@Schema(description = "物料凭证响应Dto")
@Accessors(chain = true)
public class SkuVoucherCreateResDto implements Serializable {

	/**
	 * 年度
	 */
	@Schema(description = "年度")
	@JSONField(name = "mjahr")
	private String year;

	/**
	 * 参考物料凭证号
	 */
	@Schema(description = "参考物料凭证号")
	@JSONField(name = "mblnr")
	private String sapStockOrderNo;

	/**
	 * 返回状态
	 */
	@Schema(description = "类型")
	@JSONField(name = "status")
	private String status;

	/**
	 * 消息
	 */
	@Schema(description = "消息")
	@JSONField(name = "message")
	private String message;

	private static final long serialVersionUID = 1L;

}