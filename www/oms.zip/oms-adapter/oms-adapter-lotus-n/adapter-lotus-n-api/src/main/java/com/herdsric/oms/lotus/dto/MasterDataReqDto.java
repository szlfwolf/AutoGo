package com.herdsric.oms.lotus.dto;

import com.alibaba.fastjson.annotation.JSONField;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * @Description: 主数据请求Dto
 * @author: Dzx
 * @date: 2022.10.31
 */
@Data
@Accessors(chain = true)
@Schema(description = "主数据请求Dto")
public class MasterDataReqDto {

	@JSONField(name = "MATNR")
	@Schema(description = "物料编码")
	private String matnr;

	@JSONField(name = "MAKTX")
	@Schema(description = "物料描述")
	private String maktx;

	@JSONField(name = "MTART")
	@Schema(description = "物料类型")
	private String mtart;

	@Schema(description = "物料组")
	@JSONField(name = "MATKL")
	private String matkl;

	@Schema(description = "起始日期")
	@JSONField(name = "DATE1")
	private String date1;

	@Schema(description = "截止日期")
	@JSONField(name = "DATE2")
	private String date2;

	public MasterDataReqDto() {
	}

	public MasterDataReqDto(String date1, String date2) {
		this.date1 = date1;
		this.date2 = date2;
	}

}
