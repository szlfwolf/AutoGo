package com.herdsric.oms.lotus.dto;

import com.alibaba.fastjson.annotation.JSONField;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 *
 * Lotus公用响应Dto
 *
 * @author dzx
 *
 */
@Data
@Schema(description = "Lotus公用响应Dto")
@Accessors(chain = true)
public class LotusCommonResDto<T> {

	@Schema(description = "响应")
	@JSONField(name = "responsedata")
	private T responseData;

}