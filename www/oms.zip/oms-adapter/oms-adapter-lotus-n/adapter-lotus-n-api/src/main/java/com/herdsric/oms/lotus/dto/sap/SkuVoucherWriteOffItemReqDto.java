package com.herdsric.oms.lotus.dto.sap;

import com.alibaba.fastjson.annotation.JSONField;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * 请求物料凭证冲销ItemDto
 *
 * @author dzx
 * @TableName os_sku_voucher
 */
@Data
@Schema(description = "请求物料凭证冲销ItemDto")
@Accessors(chain = true)
public class SkuVoucherWriteOffItemReqDto implements Serializable {

	/**
	 * 年度
	 */
	@Schema(description = "年度")
	@JSONField(name = "WMSITEM")
	private String lineNo;

	/**
	 * 参考物料凭证号
	 */
	@Schema(description = "参考物料凭证号")
	@JSONField(name = "MENGE")
	private Integer qty;

	private static final long serialVersionUID = 1L;

}