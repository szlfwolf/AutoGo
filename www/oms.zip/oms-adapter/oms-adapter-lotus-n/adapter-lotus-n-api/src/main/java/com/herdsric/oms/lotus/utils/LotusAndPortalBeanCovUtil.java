package com.herdsric.oms.lotus.utils;

import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSONObject;
import com.herdsric.oms.common.client.asn.domain.*;
import com.herdsric.oms.common.client.asn.process.AsnProcessor;
import com.herdsric.oms.common.client.dn.domain.*;
import com.herdsric.oms.common.client.enums.UnitEnum;
import com.herdsric.oms.common.client.masterdata.domain.SkuDm;
import com.herdsric.oms.common.client.returns.dm.AsnOrderReturnDm;
import com.herdsric.oms.common.client.stock.domain.StockDm;
import com.herdsric.oms.common.client.stock.dto.StockDTO;
import com.herdsric.oms.common.core.constant.CommonConstants;
import com.herdsric.oms.common.core.constant.enums.ExtendPropsEnum;
import com.herdsric.oms.common.core.util.SpringContextHolder;
import com.herdsric.oms.lotus.common.LotusConstant;
import com.herdsric.oms.lotus.dto.AsnOrderDTO;
import com.herdsric.oms.lotus.dto.DnOrderDto;
import com.herdsric.oms.lotus.dto.MasterDataResListDto;
import com.herdsric.oms.lotus.dto.lcms.*;
import com.herdsric.oms.lotus.dto.sap.LcmsAsnFeedBackDTO;
import com.herdsric.oms.lotus.dto.sap.LotusDnBackDTO;
import com.herdsric.oms.lotus.dto.sap.LotusDnLineBackDTO;
import com.herdsric.oms.lotus.enums.AsnTypeEnum;
import com.herdsric.oms.lotus.enums.CTypeEnum;
import com.herdsric.oms.lotus.enums.SkuDangerousEnum;
import com.herdsric.oms.lotus.enums.SkuPackageTypeEnum;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author lzq
 */
@Slf4j
public class LotusAndPortalBeanCovUtil {

	public static AsnOrderDm asnToStandard(AsnOrderDTO asnOrderDTO) {
		AsnOrderDm asnOrderDm = new AsnOrderDm();

		asnOrderDm.setOrderNo(asnOrderDTO.getAsnno());
		asnOrderDm.setSupplierCode(asnOrderDTO.getLifnr());
		asnOrderDm.setEtaTime(asnOrderDTO.getZbudat());
		asnOrderDm.setRemark(asnOrderDTO.getComments());
		if (StrUtil.equals(asnOrderDTO.getZdjlx(), LotusConstant.SAP_RETURN_FLAG)) {
			asnOrderDm.setOrderType(AsnTypeEnum.THRK.value);
		}
		else if (StrUtil.equals(asnOrderDTO.getZdjlx(), LotusConstant.SAP_FLAG)) {
			asnOrderDm.setOrderType(AsnTypeEnum.ZCRK.value);
		}

		List<AsnOrderLineDm> orderLines = new ArrayList<>();

		for (AsnOrderDTO.OrderLine orderLine : asnOrderDTO.getItem()) {
			AsnOrderLineDm line = new AsnOrderLineDm();
			Map<String, Object> sapAsnLineMap = new HashMap<>();
			// 行号
			line.setLineNo(orderLine.getAsndetailno());
			// 批次号
			line.setBatchNo(orderLine.getBatchno());
			// 物料号
			line.setPartNumber(orderLine.getMatnr());
			// 数量
			line.setQty(orderLine.getWamng());
			// 单位
			if (StrUtil.equals(orderLine.getMeins(), UnitEnum.EA.value)) {
				line.setUnit(UnitEnum.PCS.value);
			}
			else {
				line.setUnit(UnitEnum.getUnitValue(orderLine.getMeins()));
			}
			// 行备注
			line.setRemark(StrUtil.isBlank(orderLine.getDetailremark()) ? asnOrderDTO.getComments()
					: orderLine.getDetailremark());

			sapAsnLineMap.put(ExtendPropsEnum.LOTUS_SAP_SOURCE_ORDERNUM.getValue(), asnOrderDTO.getReference_asn());
			sapAsnLineMap.put(ExtendPropsEnum.LOTUS_SAP_NO.getValue(), orderLine.getEbeln());
			sapAsnLineMap.put(ExtendPropsEnum.LOTUS_SAP_LINENO.getValue(), orderLine.getEbelp());
			sapAsnLineMap.put(ExtendPropsEnum.LOTUS_VRET.getValue(), asnOrderDTO.getVret());
			sapAsnLineMap.put(ExtendPropsEnum.LOTUS_ASN_LCMS_NO.getValue(), orderLine.getLcmsno());
			sapAsnLineMap.put(ExtendPropsEnum.LOTUS_SAP_PRODUCT.getValue(), orderLine.getProduct());
			sapAsnLineMap.put(ExtendPropsEnum.LOTUS_SAP_PRODUCTDATE.getValue(), orderLine.getProductdate());
			sapAsnLineMap.put(ExtendPropsEnum.LOTUS_SAP_VALIDITYDATE.getValue(), orderLine.getValiditydate());
			// sap订单号和行号
			line.setExtendProps(sapAsnLineMap);
			orderLines.add(line);
		}
		asnOrderDm.setOrderLines(orderLines);
		return asnOrderDm;
	}

	public static DnOrderDm dnToStandard(DnOrderDto dnOrderDto) {
		DnOrderDm dnOrderDm = new DnOrderDm();

		dnOrderDm.setOrderNo(dnOrderDto.getAsnno());
		dnOrderDm.setExpectedDeliveryDate(dnOrderDto.getLfdat());
		dnOrderDm.setCountryCode(dnOrderDto.getLand1());
		dnOrderDm.setZipCode(dnOrderDto.getPost_code1());
		dnOrderDm.setUrgentType(CTypeEnum.getValueByKey(dnOrderDto.getCtype(), dnOrderDto.getZddlx()));
		dnOrderDm.setOrderType(CTypeEnum.getValueByKey(dnOrderDto.getCtype(), dnOrderDto.getZddlx()));
		dnOrderDm.setContactName(dnOrderDto.getDeliverypeople());
		dnOrderDm.setWarehouseCode(LotusConstant.WAREHOUSE_CODE);
		// 收件人电话
		dnOrderDm.setContactPhone(dnOrderDto.getDeliveryphonee());
		// 收件人地址
		dnOrderDm.setAddress(dnOrderDto.getDeliveryaddress());
		// 送达城市
		dnOrderDm.setCityCode(
				StringUtils.isBlank(dnOrderDto.getCity()) ? LotusConstant.CLIENT_CODE : dnOrderDto.getCity());
		// 联系人邮箱
		dnOrderDm.setContactEmail(dnOrderDto.getEmail());
		// 送达城市
		dnOrderDm.setCityName(dnOrderDto.getCity());
		// 公司地址填门店名称
		dnOrderDm.setContactCompany(dnOrderDto.getName1());
		// 客户备注字段 Dn推送仓库时使用
		dnOrderDm.setRemark(dnOrderDto.getComments());
		// 交易类型
		Map<String, Object> sapOrderMap = new HashMap<>();
		sapOrderMap.put(ExtendPropsEnum.LOTUS_TRADE_TYPE.getValue(), dnOrderDto.getZjylx());
		sapOrderMap.put(ExtendPropsEnum.LOTUS_KUNNR1.getValue(), dnOrderDto.getKunnr1());
		sapOrderMap.put(ExtendPropsEnum.LOTUS_NAME1.getValue(), dnOrderDto.getName1());
		dnOrderDm.setExtendProps(sapOrderMap);

		List<DnOrderDm.OrderLine> OrderLineList = new ArrayList<>();
		for (DnOrderDto.LotusDnDetailDTO dnDetail : dnOrderDto.getItem()) {
			Map<String, Object> sapDnLineMap = new HashMap<>();
			DnOrderDm.OrderLine orderLine = new DnOrderDm.OrderLine();
			// 行号
			orderLine.setLineNo(dnDetail.getAsndetailno());
			// 物料号
			orderLine.setPartNumber(dnDetail.getMatnr());
			// 数量
			orderLine.setQty(Double.valueOf(dnDetail.getWamng()));
			// 行字段备注
			orderLine.setRemark(StrUtil.isBlank(dnDetail.getDetailremark()) ? dnOrderDto.getComments()
					: dnDetail.getDetailremark());

			// 单位
			if (StrUtil.equals(dnDetail.getMeins(), UnitEnum.EA.value)) {
				orderLine.setUnit(UnitEnum.PCS.value);
			}
			else {
				orderLine.setUnit(UnitEnum.getUnitValue(dnDetail.getMeins()));
			}
			// sap交货订单号
			sapDnLineMap.put(ExtendPropsEnum.LOTUS_SAP_ORDER_NO.getValue(), dnDetail.getVgbel());
			// sap交货单行号
			sapDnLineMap.put(ExtendPropsEnum.LOTUS_SAP_ORDER_LINENO.getValue(), dnDetail.getAsndetailno());
			// lcms销售单项目行号
			sapDnLineMap.put(ExtendPropsEnum.LOTUS_LCMS_LINENO.getValue(), dnDetail.getVgpos());
			// lcms订单号
			sapDnLineMap.put(ExtendPropsEnum.LOTUS_LCMS_NO.getValue(), dnDetail.getLcmsno());
			// 收件人编码
			sapDnLineMap.put(ExtendPropsEnum.LOTUS_DN_KUNNR.getValue(), dnOrderDto.getKunnr());
			orderLine.setExtendProps(sapDnLineMap);
			OrderLineList.add(orderLine);
		}
		dnOrderDm.setOrderLines(OrderLineList);

		return dnOrderDm;
	}

	public static BlAddDto dnReturnToStandard(AsnOrderDm asnOrderDm) {
		BlAddDto blAddDTO = new BlAddDto();

		Map<String, Object> asnOrderMap = asnOrderDm.getExtendProps();

		blAddDTO.setOriginalOrderNo(
				String.valueOf(asnOrderMap.get(ExtendPropsEnum.LOTUS_SAP_SOURCE_ORDERNUM.getName())));
		blAddDTO.setClientCode(CommonConstants.COMPANY_CODE_LOTUS);
		blAddDTO.setBillLandNum(asnOrderDm.getOrderNo());
		blAddDTO.setCountryCode(String.valueOf(ExtendPropsEnum.LOTUS_SAP_CountryCode.getName()));
		AsnProcessor asnProcessor = SpringContextHolder.getBean(AsnProcessor.class);

		String warehouse = asnProcessor.getDnReturnWarehouse(CommonConstants.COMPANY_CODE_LOTUS,
				blAddDTO.getOriginalOrderNo());

		blAddDTO.setWarehouseCode(warehouse);

		List<BlLineAddDto> blLineAddDTOS = new ArrayList<>();

		for (AsnOrderLineDm orderLine : asnOrderDm.getOrderLines()) {
			BlLineAddDto blLineAddDto = new BlLineAddDto();
			blLineAddDto.setQty(orderLine.getQty());
			blLineAddDto.setUnit(orderLine.getUnit());
			blLineAddDto.setPartNumber(orderLine.getPartNumber());
			blLineAddDTOS.add(blLineAddDto);
		}
		blAddDTO.setBlLineList(blLineAddDTOS);
		return blAddDTO;
	}

	public static AsnOrderReturnDm asnReturnToStandard(AsnOrderDTO asnOrderDTO) {

		AsnOrderReturnDm returnOrderCreateDto = new AsnOrderReturnDm();

		Map<String, Object> extendProps = new HashMap<>();

		// 送货单号
		returnOrderCreateDto.setOrderNo(asnOrderDTO.getAsnno());
		// 退货单源订单号
		extendProps.put(ExtendPropsEnum.LOTUS_SAP_SOURCE_ORDERNUM.getName(), asnOrderDTO.getReference_asn());
		// 退货类型
		extendProps.put(ExtendPropsEnum.LOTUS_SAP_RETURN_TYPE.getName(), LotusConstant.ASN_RETURN);
		// 单据类型
		returnOrderCreateDto.setOrderType(AsnTypeEnum.getValueBykey(asnOrderDTO.getZdjlx()));

		returnOrderCreateDto.setRemark(asnOrderDTO.getComments());

		List<DnOrderDm.OrderLine> orderLineList = new ArrayList<>();
		for (AsnOrderDTO.OrderLine lotusAsnDetail : asnOrderDTO.getItem()) {
			DnOrderDm.OrderLine portalAsnDetail = new DnOrderDm.OrderLine();

			Map<String, Object> sapAsnLineMap = new HashMap<>();
			// 行号
			portalAsnDetail.setLineNo(lotusAsnDetail.getAsndetailno());
			// 批次号
			portalAsnDetail.setBatchNo(lotusAsnDetail.getBatchno());
			// 物料号
			portalAsnDetail.setPartNumber(lotusAsnDetail.getMatnr());
			// 数量
			portalAsnDetail.setQty(Double.valueOf(lotusAsnDetail.getWamng()));
			// 备注
			portalAsnDetail.setRemark(StrUtil.isBlank(lotusAsnDetail.getDetailremark()) ? asnOrderDTO.getComments()
					: lotusAsnDetail.getDetailremark());
			// 单位
			if (StrUtil.equals(lotusAsnDetail.getMeins(), UnitEnum.EA.value)) {
				portalAsnDetail.setUnit(UnitEnum.PCS.value);
			}
			else {
				portalAsnDetail.setUnit(UnitEnum.getUnitValue(lotusAsnDetail.getMeins()));
			}
			sapAsnLineMap.put(ExtendPropsEnum.LOTUS_SAP_NO.getValue(), lotusAsnDetail.getEbeln());
			sapAsnLineMap.put(ExtendPropsEnum.LOTUS_SAP_LINENO.getValue(), lotusAsnDetail.getEbelp());
			sapAsnLineMap.put(ExtendPropsEnum.LOTUS_VRET.getValue(), asnOrderDTO.getVret());
			sapAsnLineMap.put(ExtendPropsEnum.LOTUS_ASN_LCMS_NO.getValue(), lotusAsnDetail.getLcmsno());
			// sap订单号和行号
			portalAsnDetail.setExtendProps(sapAsnLineMap);
			orderLineList.add(portalAsnDetail);
		}
		returnOrderCreateDto.setExtendProps(extendProps);
		returnOrderCreateDto.setOrderLines(orderLineList);
		return returnOrderCreateDto;
	}

	public static SkuDm skuToOmsSku(MasterDataResListDto resDto) {
		SkuDm syncSkuDto = new SkuDm();
		syncSkuDto.setBrand(
				StringUtils.isBlank(resDto.getBranded()) ? CommonConstants.COMPANY_CODE_LOTUS : resDto.getBranded());
		syncSkuDto.setPartNumber(resDto.getMatnr());
		syncSkuDto.setNameCn(resDto.getMaktx());
		syncSkuDto.setPartDesc(StringUtils.isBlank(resDto.getMaktxEn()) ? resDto.getMaktx() : resDto.getMaktxEn());
		syncSkuDto.setNameEn(StringUtils.isBlank(resDto.getMaktxEn()) ? resDto.getMaktx() : resDto.getMaktxEn());
		syncSkuDto.setPartType1(resDto.getMtart());
		syncSkuDto.setPartType2(resDto.getMatkl());
		syncSkuDto.setCarModel(resDto.getCarModel());
		syncSkuDto.setIsDangerous(SkuDangerousEnum.getValueByName(resDto.getDangerousGoods()));
		syncSkuDto.setSupplierCode(resDto.getSupplierCode());
		syncSkuDto.setSupplierName(resDto.getSupplierName());
		// 包装单位集
		SkuDm.PackageUnit syncSkuPackageDto = new SkuDm.PackageUnit();
		syncSkuPackageDto.setType(SkuPackageTypeEnum.KHTG.value);
		syncSkuPackageDto.setLength(StringUtils.isBlank(resDto.getLength()) ? "0" : resDto.getLength());
		syncSkuPackageDto.setWidth(StringUtils.isBlank(resDto.getWidth()) ? "0" : resDto.getWidth());
		syncSkuPackageDto.setHeight(StringUtils.isBlank(resDto.getHeight()) ? "0" : resDto.getHeight());
		syncSkuPackageDto.setNetWeight(com.herdsric.oms.lotus.utils.DataUtil.gramToKilogram(resDto.getActualWeight()));
		syncSkuPackageDto.setGrossWeight(syncSkuPackageDto.getNetWeight());
		syncSkuPackageDto.setUnit(resDto.getMeins());
		syncSkuPackageDto.setMoq("1.0");
		syncSkuDto.setPackageList(Arrays.asList(syncSkuPackageDto));
		return syncSkuDto;
	}

	public static LotusDnBackDTO dnToLotusDnReturnBack(AsnOrderResponseDm asnOrderResponseDm,
			HashMap<String, String> warehouseExtendProp) {
		LotusDnBackDTO lotusDnBackDTO = new LotusDnBackDTO();
		lotusDnBackDTO.setASNNO(asnOrderResponseDm.getOrderNo());
		String currentTime = DateUtil.format(DateUtil.parseDateTime(DateDealUtil.convertEUToCN(DateUtil.now())),
				DatePattern.PURE_DATE_FORMAT);
		lotusDnBackDTO.setBLDAT(currentTime);
		lotusDnBackDTO.setBUDAT(currentTime);
		lotusDnBackDTO.setWMSNO(asnOrderResponseDm.getOrderNo());
		// 退货场景
		lotusDnBackDTO.setZjylx(LotusConstant.LOTUS_DN_BACK_POST);

		lotusDnBackDTO.setASNTYPE(LotusConstant.LOTUS_DN_BACK_POST);
		lotusDnBackDTO.setUSNAM(LotusConstant.LOTUS_SEND_USER_NAME);
		// 采购订单号
		List<LotusDnLineBackDTO> lotusDnLineBackDTOS = new ArrayList<>();

		for (AsnOrderResponseLineDm dnDetail : asnOrderResponseDm.getOrderLines()) {
			LotusDnLineBackDTO lotusDnLineFeedbackDTO = new LotusDnLineBackDTO();
			lotusDnLineFeedbackDTO.setASNITEM(dnDetail.getLineNo());
			lotusDnLineFeedbackDTO.setWMSITEM(dnDetail.getLineNo());
			lotusDnLineFeedbackDTO.setMATNR(dnDetail.getPartNumber());
			if (StrUtil.equals(dnDetail.getUnit(), UnitEnum.PCS.value)) {
				lotusDnLineFeedbackDTO.setERFME(UnitEnum.EA.value);
			}
			else {
				lotusDnLineFeedbackDTO.setERFME(UnitEnum.getUnitValue(dnDetail.getUnit()));
			}
			lotusDnLineFeedbackDTO.setERFMG(Double.toString(dnDetail.getQty()));
			lotusDnLineFeedbackDTO.setLGORT(warehouseExtendProp.get(asnOrderResponseDm.getWarehouseCode()));
			lotusDnLineFeedbackDTO.setWERKS(LotusConstant.LOTUS_FACTORY);
			lotusDnLineFeedbackDTO.setELIKZ(LotusConstant.ELIKZ);
			// 采购订单行号
			JSONObject lineJsonObject = JSONObject.parseObject(dnDetail.getExtendProps());
			if (ObjectUtils.isNotEmpty(lineJsonObject)) {
				lotusDnLineFeedbackDTO
						.setVGBEL(lineJsonObject.getString(ExtendPropsEnum.LOTUS_SAP_ORDER_NO.getValue()));
				lotusDnLineFeedbackDTO
						.setVGPOS(lineJsonObject.getString(ExtendPropsEnum.LOTUS_SAP_ORDER_LINENO.getValue()));
				lotusDnLineBackDTOS.add(lotusDnLineFeedbackDTO);
			}

		}
		lotusDnBackDTO.setITEM(lotusDnLineBackDTOS);

		return lotusDnBackDTO;
	}

	public static LcmsBillOfLadingDTO toLcmsBooked(DnOrderResponseDm dnOrderResponseDm,
			List<DnOrderLcmsResponseVo> dnOrderResponseData, WarehuseVo warehouseDetail,
			ContactAddressVo contactAddressDetail, String shipType) {
		DnOrderLcmsResponseVo dnOrderLcmsResponseVo = dnOrderResponseData.get(0);
		LcmsBillOfLadingDTO lcmsBillOfLadingDTO = new LcmsBillOfLadingDTO();

		List<LcmsBillOfLadingInfoDTO> packageInfo = new ArrayList<>();
		// 设置请求来源
		lcmsBillOfLadingDTO.setSourceSystem(CommonConstants.SOURCE_SYSTEM);
		lcmsBillOfLadingDTO.setAddressId(dnOrderLcmsResponseVo.getAddressId());
		lcmsBillOfLadingDTO.setWarehouseCode(dnOrderResponseDm.getWarehouseCode());
		lcmsBillOfLadingDTO.setBatchNo(dnOrderResponseDm.getOrderLines().get(0).getBatchNo());
		lcmsBillOfLadingDTO.setExtendProps(dnOrderLcmsResponseVo.getExtendProps());

		lcmsBillOfLadingDTO.setDoNo(dnOrderResponseDm.getOrderNo());

		lcmsBillOfLadingDTO.setToNo(dnOrderResponseDm.getTrackingNumber());

		lcmsBillOfLadingDTO.setToCreateDate(dnOrderLcmsResponseVo.getBookedTime());
		lcmsBillOfLadingDTO.setToDate(dnOrderLcmsResponseVo.getBookedTime());

		lcmsBillOfLadingDTO.setExpecteDeliveryTime(dnOrderLcmsResponseVo.getExpecteDeliveryTime());

		// 设置承运商代码
		lcmsBillOfLadingDTO.setForearderCode(CommonConstants.SOURCE_SYSTEM);

		// 采购订单行号
		JSONObject jsonObject = JSONObject.parseObject(dnOrderLcmsResponseVo.getExtendProps());
		if (ObjectUtils.isNotEmpty(jsonObject)) {
			// 有门店code就拼接上
			if (StringUtils.isNotEmpty(jsonObject.getString(ExtendPropsEnum.LOTUS_KUNNR1.getValue()))) {
				lcmsBillOfLadingDTO.setDlrCode(jsonObject.getString(ExtendPropsEnum.LOTUS_KUNNR1.getValue()));
			}
		}
		// 设置时区
		lcmsBillOfLadingDTO.setTz(LotusConstant.TIME_ZONE_EUROPE);

		lcmsBillOfLadingDTO.setForearderContactInfo(warehouseDetail.getContactName() + "+"
				+ warehouseDetail.getContactPhone() + "+" + warehouseDetail.getContactEmail());

		lcmsBillOfLadingDTO.setShipVia(shipType);

		lcmsBillOfLadingDTO.setContactPhone(contactAddressDetail.getContactPhone());
		lcmsBillOfLadingDTO.setReceiveAdress(contactAddressDetail.getAddress());
		lcmsBillOfLadingDTO.setContactPerson(contactAddressDetail.getContactName());

		for (OrderLineDm orderLine : dnOrderResponseDm.getOrderLines()) {
			List<DnOrderLcmsResponseVo> collect = dnOrderResponseData.stream()
					.filter(x -> StrUtil.equals(x.getLineNo(), orderLine.getLineNo())
							&& StrUtil.equals(x.getPartNumber(), orderLine.getPartNumber()))
					.collect(Collectors.toList());

			DnOrderLcmsResponseVo dnOrderLcmsResponseVo1 = collect.get(0);
			// 行信息扩展字段
			JSONObject lineJsonObject = JSONObject.parseObject(dnOrderLcmsResponseVo1.getLineExtendProps());

			LcmsBillOfLadingInfoDTO lcmsBillOfLadingInfoDTO = new LcmsBillOfLadingInfoDTO();

			lcmsBillOfLadingInfoDTO.setPackageNo(orderLine.getBoxNo());
			lcmsBillOfLadingInfoDTO.setPackageLength(orderLine.getLength());
			lcmsBillOfLadingInfoDTO.setPackageWidth(orderLine.getWidth());
			lcmsBillOfLadingInfoDTO.setPackageHeight(orderLine.getHeight());
			lcmsBillOfLadingInfoDTO.setPackageNetweight(orderLine.getNetWeight());
			lcmsBillOfLadingInfoDTO.setPackageGrossweight(orderLine.getWeight());
			lcmsBillOfLadingInfoDTO.setSpCode(orderLine.getPartNumber());
			lcmsBillOfLadingInfoDTO.setDeliveryQuantity(orderLine.getQty());
			lcmsBillOfLadingInfoDTO.setLineExtendProps(dnOrderLcmsResponseVo1.getLineExtendProps());

			if (ObjectUtils.isNotEmpty(lineJsonObject)) {
				// lcms销售订单行项目编号
				lcmsBillOfLadingInfoDTO
						.setItemno(lineJsonObject.getString(ExtendPropsEnum.LOTUS_LCMS_LINENO.getValue()));
				// lcms销售订单号
				lcmsBillOfLadingDTO.setSoNo(lineJsonObject.getString(ExtendPropsEnum.LOTUS_LCMS_NO.getValue()));
				// 交货单行项目编号
				lcmsBillOfLadingInfoDTO
						.setDnitemNo(lineJsonObject.getString(ExtendPropsEnum.LOTUS_SAP_ORDER_LINENO.getValue()));
			}

			packageInfo.add(lcmsBillOfLadingInfoDTO);
		}

		lcmsBillOfLadingDTO.setPackageInfo(packageInfo);

		return lcmsBillOfLadingDTO;
	}

	public static DeliveryInfoDTO toLcmsOutBoundNoRelocation(DnOrderResponseDm dnOrderResponseDm) {
		DeliveryInfoDTO deliveryInfoDTO = new DeliveryInfoDTO();

		deliveryInfoDTO.setSourceSystem(CommonConstants.SOURCE_SYSTEM);
		deliveryInfoDTO.setToNo(dnOrderResponseDm.getTrackingNumber());
		deliveryInfoDTO.setDoNo(dnOrderResponseDm.getOrderNo());
		deliveryInfoDTO.setShipDate(dnOrderResponseDm.getPickUpTime());
		deliveryInfoDTO.setTz(LotusConstant.TIME_ZONE_EUROPE);
		deliveryInfoDTO.setToCycleLink(dnOrderResponseDm.getOrderTracingLink());

		return deliveryInfoDTO;
	}

	public static LcmsLogisticsStatusDto toLcmsOutBoundIsRelocation(DnOrderResponseDm dnOrderResponseDm) {
		LcmsLogisticsStatusDto lcmsLogisticsStatusDto = new LcmsLogisticsStatusDto();
		lcmsLogisticsStatusDto.setSourceSystem(CommonConstants.SOURCE_SYSTEM);
		long currentTimeMillis = System.currentTimeMillis();
		String timestampInSeconds = String.valueOf(currentTimeMillis / 1000);

		lcmsLogisticsStatusDto.setOperation(CommonConstants.SOURCE_SYSTEM);
		lcmsLogisticsStatusDto.setOperationDate(timestampInSeconds);
		lcmsLogisticsStatusDto.setOutboundOrderNo(dnOrderResponseDm.getOrderNo());
		lcmsLogisticsStatusDto.setBusinessNo(dnOrderResponseDm.getOrderNo());

		lcmsLogisticsStatusDto.setBusinessOrderState(1);
		lcmsLogisticsStatusDto.setBusinessType(LotusConstant.DN_TRANSACTION_TYPE);

		return lcmsLogisticsStatusDto;
	}

	public static LotusDnBackDTO toSapOutBound(List<DnOrderLcmsResponseVo> dnOrderResponseSap,
			DnOrderResponseDm dnOrderResponseDm, String orderType, String operationTime) {
		LotusDnBackDTO lotusDnBackDTO = new LotusDnBackDTO();

		lotusDnBackDTO.setASNNO(dnOrderResponseDm.getOrderNo());
		String currentTime = DateUtil.format(DateUtil.parseDateTime(DateDealUtil.convertEUToCN(operationTime)),
				DatePattern.PURE_DATE_FORMAT);
		lotusDnBackDTO.setBLDAT(currentTime);
		lotusDnBackDTO.setBUDAT(currentTime);
		lotusDnBackDTO.setWMSNO(dnOrderResponseDm.getOrderNo());

		// 采购订单号
		List<LotusDnLineBackDTO> lotusDnLineBackDTOS = new ArrayList<>();

		Map<String, List<OrderLineDm>> collect1 = dnOrderResponseDm.getOrderLines().stream()
				.collect(Collectors.groupingBy(line -> line.getLineNo() + line.getPartNumber()));

		collect1.forEach((k, v) -> {
			OrderLineDm orderLine = v.get(0);
			Double sum = v.stream().map(OrderLineDm::getQty).mapToDouble(Double::valueOf).sum();
			orderLine.setQty(String.valueOf(sum));

			LotusDnLineBackDTO lotusDnLineFeedbackDTO = new LotusDnLineBackDTO();
			lotusDnLineFeedbackDTO.setASNITEM(orderLine.getLineNo());
			lotusDnLineFeedbackDTO.setWMSITEM(orderLine.getLineNo());
			lotusDnLineFeedbackDTO.setMATNR(orderLine.getPartNumber());
			if (StrUtil.equals(orderLine.getUnit(), UnitEnum.PCS.value)) {
				lotusDnLineFeedbackDTO.setERFME(UnitEnum.EA.value);
			}
			else {
				lotusDnLineFeedbackDTO.setERFME(UnitEnum.getUnitValue(orderLine.getUnit()));
			}
			lotusDnLineFeedbackDTO.setERFMG(orderLine.getQty());
			lotusDnLineFeedbackDTO.setLGORT(dnOrderResponseSap.get(0).getWarehouseExtendProps());
			lotusDnLineFeedbackDTO.setWERKS(LotusConstant.LOTUS_FACTORY);
			lotusDnLineFeedbackDTO.setELIKZ(LotusConstant.ELIKZ);

			List<DnOrderLcmsResponseVo> collect = dnOrderResponseSap.stream()
					.filter(a -> StrUtil.equals(a.getLineNo(), orderLine.getLineNo())
							&& StrUtil.equals(a.getPartNumber(), orderLine.getPartNumber()))
					.collect(Collectors.toList());

			DnOrderLcmsResponseVo dnOrderLcmsResponseVo = collect.get(0);

			// 采购订单行号
			JSONObject lineJsonObject = JSONObject.parseObject(dnOrderLcmsResponseVo.getLineExtendProps());
			if (ObjectUtils.isNotEmpty(lineJsonObject)) {
				if (StringUtils.equals(orderType, LotusConstant.DN_TRANSACTION_TYPE)) {
					lotusDnLineFeedbackDTO.setVGBEL(dnOrderResponseDm.getOrderNo());
					lotusDnLineFeedbackDTO
							.setVGPOS(lineJsonObject.getString(ExtendPropsEnum.LOTUS_LCMS_LINENO.getValue()));
				}
				else {
					lotusDnLineFeedbackDTO
							.setVGBEL(lineJsonObject.getString(ExtendPropsEnum.LOTUS_SAP_ORDER_NO.getValue()));
					lotusDnLineFeedbackDTO
							.setVGPOS(lineJsonObject.getString(ExtendPropsEnum.LOTUS_LCMS_LINENO.getValue()));
				}
			}
			lotusDnLineBackDTOS.add(lotusDnLineFeedbackDTO);

		});
		lotusDnBackDTO.setITEM(lotusDnLineBackDTOS);
		return lotusDnBackDTO;
	}

	public static DeliveryInfoLcmsPodDto toLcmsPodNoRelocation(DnOrderResponseDm dnOrderResponseDm) {
		DeliveryInfoLcmsPodDto deliveryInfoLcmsPodDto = new DeliveryInfoLcmsPodDto();

		deliveryInfoLcmsPodDto.setSourceSystem(CommonConstants.SOURCE_SYSTEM);
		deliveryInfoLcmsPodDto.setToNo(dnOrderResponseDm.getTrackingNumber());
		deliveryInfoLcmsPodDto.setDoNo(dnOrderResponseDm.getOrderNo());
		deliveryInfoLcmsPodDto.setArriveDate(dnOrderResponseDm.getPodTime());
		deliveryInfoLcmsPodDto.setTz(LotusConstant.TIME_ZONE_EUROPE);
		deliveryInfoLcmsPodDto.setShipDate(dnOrderResponseDm.getPickUpTime());

		return deliveryInfoLcmsPodDto;
	}

	public static LcmsLogisticsStatusDto toLcmsPodIsRelocation(DnOrderResponseDm dnOrderResponseDm) {
		LcmsLogisticsStatusDto lcmsLogisticsStatusDto = new LcmsLogisticsStatusDto();

		long currentTimeMillis = System.currentTimeMillis();
		String timestampInSeconds = String.valueOf(currentTimeMillis / 1000);
		lcmsLogisticsStatusDto.setOperationDate(timestampInSeconds);
		lcmsLogisticsStatusDto.setOutboundOrderNo(dnOrderResponseDm.getOrderNo());
		lcmsLogisticsStatusDto.setBusinessNo(dnOrderResponseDm.getOrderNo());
		lcmsLogisticsStatusDto.setSourceSystem(CommonConstants.SOURCE_SYSTEM);
		lcmsLogisticsStatusDto.setOperation(CommonConstants.SOURCE_SYSTEM);
		lcmsLogisticsStatusDto.setBusinessOrderState(2);
		lcmsLogisticsStatusDto.setBusinessType(CommonConstants.DN_TRANSACTION_TYPE);

		return lcmsLogisticsStatusDto;
	}

	public static AsnOrderDm dnReturnMapping(DnOrderDto dnOrderDto) {
		AsnOrderDm asnOrderDm = new AsnOrderDm();

		HashMap<String, Object> asnOrderMap = new HashMap<>();

		asnOrderMap.put(ExtendPropsEnum.LOTUS_SAP_SOURCE_ORDERNUM.getName(), dnOrderDto.getReference_dn());
		asnOrderMap.put(ExtendPropsEnum.LOTUS_SAP_CountryCode.getName(), dnOrderDto.getLand1());
		asnOrderMap.put(ExtendPropsEnum.LOTUS_SAP_ZJYLX.getName(), dnOrderDto.getZjylx());

		asnOrderDm.setOrderNo(dnOrderDto.getAsnno());
		asnOrderDm.setOrderType(LotusConstant.DN_RETURN);
		asnOrderDm.setBillLandNum(dnOrderDto.getAsnno());
		DateTime dateTime = DateUtil.offsetDay(DateUtil.date(), 3);
		asnOrderDm.setEtaTime(DateUtil.format(dateTime, "yyyy-MM-dd HH:mm:ss"));
		asnOrderDm.setRemark(dnOrderDto.getComments());
		List<AsnOrderLineDm> inboundOrderLines = new ArrayList<>();
		for (DnOrderDto.LotusDnDetailDTO lotusDnDetailDTO : dnOrderDto.getItem()) {
			AsnOrderLineDm inboundOrderLine = new AsnOrderLineDm();
			HashMap<String, Object> sapDnLineMap = new HashMap<>();

			inboundOrderLine.setLineNo(lotusDnDetailDTO.getAsndetailno());
			inboundOrderLine.setPartNumber(lotusDnDetailDTO.getMatnr());
			inboundOrderLine.setQty(lotusDnDetailDTO.getWamng());
			if (StrUtil.equals(lotusDnDetailDTO.getMeins(), UnitEnum.EA.value)) {
				inboundOrderLine.setUnit(UnitEnum.PCS.value);
			}
			else {
				inboundOrderLine.setUnit(UnitEnum.getUnitValue(lotusDnDetailDTO.getMeins()));
			}
			inboundOrderLine.setRemark(StrUtil.isBlank(lotusDnDetailDTO.getDetailremark()) ? dnOrderDto.getComments()
					: lotusDnDetailDTO.getDetailremark());
			// sap交货订单号
			sapDnLineMap.put(ExtendPropsEnum.LOTUS_SAP_ORDER_NO.getValue(), lotusDnDetailDTO.getVgbel());
			// sap交货单行号
			sapDnLineMap.put(ExtendPropsEnum.LOTUS_SAP_ORDER_LINENO.getValue(), lotusDnDetailDTO.getAsndetailno());
			// lcms销售单项目行号
			sapDnLineMap.put(ExtendPropsEnum.LOTUS_LCMS_LINENO.getValue(), lotusDnDetailDTO.getVgpos());
			// lcms订单号
			sapDnLineMap.put(ExtendPropsEnum.LOTUS_LCMS_NO.getValue(), lotusDnDetailDTO.getLcmsno());
			// 收件人编码
			sapDnLineMap.put(ExtendPropsEnum.LOTUS_DN_KUNNR.getValue(), dnOrderDto.getKunnr());

			inboundOrderLine.setExtendProps(sapDnLineMap);
			inboundOrderLines.add(inboundOrderLine);
		}

		asnOrderDm.setExtendProps(asnOrderMap);
		asnOrderDm.setOrderLines(inboundOrderLines);

		return asnOrderDm;
	}

	public static InOrderVo dnReturnToAsnOrder(AsnOrderDm asnOrderDm) {
		InOrderVo inOrderVo = new InOrderVo();

		Map<String, Object> asnOrderExtendProps = asnOrderDm.getExtendProps();

		inOrderVo.setOrderNo(asnOrderDm.getOrderNo());
		inOrderVo.setClientCode(CommonConstants.COMPANY_CODE_LOTUS);
		inOrderVo.setEtaTime(asnOrderDm.getEtaTime());
		// orderType
		inOrderVo.setOriginalOrderNo(
				String.valueOf(asnOrderExtendProps.get(ExtendPropsEnum.LOTUS_SAP_SOURCE_ORDERNUM.getName())));
		inOrderVo.setOrderType(LotusConstant.DN_RETURN);
		inOrderVo.setInOrderNum(asnOrderDm.getOrderNo());
		List<InOrderLineVo> inOrderLines = new ArrayList<>();
		for (AsnOrderLineDm lotusDnDetailDTO : asnOrderDm.getOrderLines()) {
			InOrderLineVo inOrderLineVo = new InOrderLineVo();
			HashMap<String, Object> sapDnLineMap = new HashMap<>();
			inOrderLineVo.setLineNo(lotusDnDetailDTO.getLineNo());
			inOrderLineVo.setPartNumber(lotusDnDetailDTO.getPartNumber());
			inOrderLineVo.setNum(lotusDnDetailDTO.getQty());
			inOrderLineVo.setUnit(lotusDnDetailDTO.getUnit());

			inOrderLineVo.setExtendProps(lotusDnDetailDTO.getExtendProps());
			inOrderLines.add(inOrderLineVo);
		}

		inOrderVo.setInOrderLines(inOrderLines);
		return inOrderVo;
	}

	public static StockDTO searchInventoryToStockDm(SearchStockRequestDTO searchStockRequestDTO) {
		StockDTO stockDTO = new StockDTO();

		stockDTO.setWarehouseCode(searchStockRequestDTO.getWarehouseCode());
		stockDTO.setPartNumbers(searchStockRequestDTO.getPartCodeList());
		stockDTO.setPartNumberName(searchStockRequestDTO.getPartName());
		stockDTO.setCurrent((int) searchStockRequestDTO.getCurrent());
		stockDTO.setSize((int) searchStockRequestDTO.getSize());

		return stockDTO;
	}

	public static StockDTO queryAvaInventoryToStockDm(QueryAvaInventoryDto queryAvaInventoryDto) {
		StockDTO stockDTO = new StockDTO();

		stockDTO.setPartNumberPrefix(queryAvaInventoryDto.getPartCodePrefix());
		stockDTO.setPartNumberName(queryAvaInventoryDto.getPartName());
		stockDTO.setPartNumber(queryAvaInventoryDto.getPartCode());
		stockDTO.setWarehouseCode(queryAvaInventoryDto.getWarehouseCode());
		return stockDTO;
	}

	public static List<SearchStockRespondVO> stockToSearchStockRespondVO(List<StockDm> data) {
		List<SearchStockRespondVO> searchStockRespondVOList = new ArrayList<>(data.size());
		for (StockDm datum : data) {
			Map<String, String> extendProps = datum.getExtendProps();

			SearchStockRespondVO searchStockRespondVO = new SearchStockRespondVO();
			searchStockRespondVO.setPartCode(datum.getPartNumber());
			searchStockRespondVO.setWarehouseCode(datum.getWarehouseCode());
			searchStockRespondVO.setInventoryQuantity(String.valueOf(datum.getTotalQty()));
			searchStockRespondVO.setAvailableQuantity(String.valueOf(datum.getUsableTotalQty()));
			searchStockRespondVO.setInTransitQuantity(String.valueOf(datum.getIntransitQty()));

			searchStockRespondVO.setPartNameCn(extendProps.get(LotusConstant.nameCN));
			searchStockRespondVO.setPartNameEn(extendProps.get(LotusConstant.nameEN));
			searchStockRespondVO.setVehicleModel(extendProps.get(LotusConstant.carModel));
			if (StrUtil.equals(extendProps.get(LotusConstant.unit), UnitEnum.PCS.value)) {
				searchStockRespondVO.setSpUint(UnitEnum.EA.value);
			}
			else {
				searchStockRespondVO.setSpUint(UnitEnum.getUnitValue(extendProps.get(LotusConstant.unit)));
			}
			searchStockRespondVO.setTimeOfRecentInbound(extendProps.get(LotusConstant.indate));
			searchStockRespondVO.setTimeOfRecentOutbound(extendProps.get(LotusConstant.outdate));

			searchStockRespondVOList.add(searchStockRespondVO);
		}
		return searchStockRespondVOList;
	}

	public static List<QueryAvaInventoryVo> stockToQueryAvaInventoryVO(List<StockDm> data) {
		List<QueryAvaInventoryVo> queryAvaInventoryVoList = new ArrayList<>();

		for (StockDm datum : data) {
			QueryAvaInventoryVo queryAvaInventoryVo = new QueryAvaInventoryVo();

			Map<String, String> extendProps = datum.getExtendProps();

			queryAvaInventoryVo.setPartCode(datum.getPartNumber());
			queryAvaInventoryVo.setPartNameCn(extendProps.get(LotusConstant.nameCN));
			queryAvaInventoryVo.setPartNameEn(extendProps.get(LotusConstant.nameEN));
			queryAvaInventoryVo.setWarehouseCode(datum.getWarehouseCode());
			queryAvaInventoryVo.setVehicleModel(extendProps.get(LotusConstant.carModel));
			if (StrUtil.equals(extendProps.get(LotusConstant.unit), UnitEnum.PCS.value)) {
				queryAvaInventoryVo.setSpUint(UnitEnum.EA.value);
			}
			else {
				queryAvaInventoryVo.setSpUint(UnitEnum.getUnitValue(extendProps.get(LotusConstant.unit)));
			}
			queryAvaInventoryVo.setMoq(extendProps.get(LotusConstant.moq));
			queryAvaInventoryVo.setAvailableQuantity(String.valueOf(datum.getUsableTotalQty()));

			queryAvaInventoryVoList.add(queryAvaInventoryVo);
		}

		return queryAvaInventoryVoList;
	}

	public static LcmsAsnFeedBackDTO inOrderToLcmsAsnResponse(AsnOrderResponseDm asnOrderResponseDm,
			WarehuseVo warehouseDetail, AsnOrderResponseLcmsDto asnOrderResponseLcmsDto) {
		LcmsAsnFeedBackDTO lcmsAsnFeedBackDTO = new LcmsAsnFeedBackDTO();

		lcmsAsnFeedBackDTO.setWarehouseCode(asnOrderResponseDm.getWarehouseCode());
		lcmsAsnFeedBackDTO.setDoNo(asnOrderResponseDm.getOrderNo());
		lcmsAsnFeedBackDTO.setShipVia(asnOrderResponseLcmsDto.getShipType());
		// 设置承运商代码
		lcmsAsnFeedBackDTO.setForearderName(CommonConstants.SOURCE_SYSTEM);
		lcmsAsnFeedBackDTO.setToNo(asnOrderResponseDm.getOrderNo());
		lcmsAsnFeedBackDTO.setInboundOrderNo(lcmsAsnFeedBackDTO.getToNo());

		lcmsAsnFeedBackDTO.setReceivedBy(warehouseDetail.getContactName());
		lcmsAsnFeedBackDTO.setContactPerson(warehouseDetail.getContactName());
		lcmsAsnFeedBackDTO.setContactPhone(warehouseDetail.getContactPhone());
		lcmsAsnFeedBackDTO.setReceiveAdress(warehouseDetail.getAddress());

		Map<String, AsnOrderResponseLcmsDto.OrderResponseDto> collect = asnOrderResponseLcmsDto.getOrderResponse()
				.stream().collect(Collectors.toMap(x -> x.getLineNo() + "_" + x.getPartNumber(), Function.identity()));

		for (AsnOrderResponseLineDm orderLine : asnOrderResponseDm.getOrderLines()) {
			// 生成查找用的键
			String key = orderLine.getLineNo() + "_" + orderLine.getPartNumber();

			AsnOrderResponseLcmsDto.OrderResponseDto orderResponseDto = collect.get(key);
			if (orderLine.getPlanQty().equals(orderResponseDto.getMappedQty())) {
				lcmsAsnFeedBackDTO.setToState(CommonConstants.LCMS_ORDER_STATUS_ALL);
				continue;
			}
			lcmsAsnFeedBackDTO.setToState(CommonConstants.LCMS_ORDER_STATUS_PART);
		}

		// 转换时间戳
		if (asnOrderResponseLcmsDto.getCreateTime() != null) {
			lcmsAsnFeedBackDTO.setShipDate(asnOrderResponseLcmsDto.getCreateTime().getTime());
		}
		if (asnOrderResponseLcmsDto.getEtaTime() != null) {
			lcmsAsnFeedBackDTO.setReceiveDate(asnOrderResponseLcmsDto.getEtaTime().getTime());
			lcmsAsnFeedBackDTO.setExpecteDeliveryTime(asnOrderResponseLcmsDto.getEtaTime().getTime());
		}
		return lcmsAsnFeedBackDTO;

	}

}
