package com.herdsric.oms.lotus.enums;

public enum ApiType {

	DN_ORDER_STATUS_POD_SYNC_RELOCATION, DN_ORDER_STATUS_OUTBOUND_SYNC_TO_LCMS_RELOCATION,
	DN_ORDER_STATUS_OUTBOUND_SYNC_TO_SAP, SKU_Voucher_Create, SKU_Voucher_WriteOff, DN_ORDER_RETURN;

}
