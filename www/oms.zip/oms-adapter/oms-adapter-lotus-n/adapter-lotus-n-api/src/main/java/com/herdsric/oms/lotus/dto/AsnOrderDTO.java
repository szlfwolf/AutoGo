package com.herdsric.oms.lotus.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.herdsric.oms.common.client.enums.UnitEnum;
import com.herdsric.oms.common.core.exception.OmsBusinessException;
import com.herdsric.oms.common.core.validation.RegexpConstants;
import com.herdsric.oms.common.core.validation.constraints.EnumCheck;
import com.herdsric.oms.lotus.common.LotusConstant;
import com.herdsric.oms.lotus.enums.AsnTypeEnum;
import com.herdsric.oms.lotus.utils.DateDealUtil;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import java.util.HashMap;
import java.util.List;

@Data
public class AsnOrderDTO {

	@Schema(description = "入库单号")
	@NotEmpty(message = "入库单号不能为空")
	private String asnno;

	@Schema(description = "ASN类型")
	@NotEmpty(message = "ASN类型不能为空")
	private String asntype;

	@Schema(description = "供应商编号")
	@NotEmpty(message = "供应商编号不能为空")
	private String lifnr;

	@Schema(description = "供应商名称")
	@NotEmpty(message = "供应商名称不能为空")
	private String name1;

	@Schema(description = "预计到货时间:yyyy-MM-dd HH:mm:ss")
	@Pattern(regexp = RegexpConstants.YYYY_MM_DD_TIME, message = "预计到货时间输入有误,格式:yyyy-MM-dd HH:mm:ss")
	@NotEmpty(message = "预计到货时间不能为空")
	private String zbudat;

	@Schema(description = "备注")
	private String comments;

	@Schema(description = "单据类型")
	@NotEmpty(message = "单据类型不能为空")
	@EnumCheck(AsnTypeEnum.class)
	private String zdjlx;

	@Schema(description = "退货单原订单号")
	private String reference_asn;

	@Schema(description = "工厂编码")
	@NotEmpty(message = "工厂编码不能为空")
	private String werks;

	@Schema(description = "虚拟标识")
	private String vret;

	/**
	 * 入库单零件清单
	 */
	@Schema(description = "ASN明细")
	@NotEmpty(message = "ASN明细不能为空")
	@Valid
	private List<OrderLine> item;

	@Data
	public static class OrderLine {

		@Schema(description = "ASN行号")
		@NotEmpty(message = "送货单行号不能为空")
		private String asndetailno;

		@Schema(description = "sap采购订单号")
		@NotEmpty(message = "sap采购订单号不能为空")
		private String ebeln;

		@Schema(description = "sap采购订单行号")
		@NotEmpty(message = "采购项目凭证编号不能为空")
		private String ebelp;

		// @NotEmpty(message = "批次号不能为空")
		@Schema(description = "批次号")
		private String batchno;

		@Schema(description = "lcms订单号")
		private String lcmsno;

		@Schema(description = "产地")
		// @NotEmpty(message = "产地不能为空")
		private String product;

		@Schema(description = "有效期")
		// @NotEmpty(message = "有效期不能为空")
		private String productdate;

		@Schema(description = "生产日期")
		// @NotEmpty(message = "生产日期不能为空")
		private String validitydate;

		@Schema(description = "物料号")
		@NotEmpty(message = "物料号不能为空")
		private String matnr;

		@Schema(description = "数量")
		@NotEmpty(message = "数量不能为空")
		private String wamng;

		@Schema(description = "单位")
		@NotEmpty(message = "单位不能为空")
		@EnumCheck(value = UnitEnum.class)
		private String meins;

		@Schema(description = "备注")
		private String detailremark;

		@Schema(description = "包装")
		@JsonProperty(defaultValue = "package")
		private String pack;

		@Schema(description = "状态")
		private String state;

	}

	public void check() {

		if (LotusConstant.SAP_RETURN_FLAG.equals(this.getZdjlx()) && StringUtils.isBlank(this.getReference_asn())) {
			throw new OmsBusinessException("6001", "如果ZDJLX为1（退货），退货单原订单号(reference_asn)不能为空");
		}
		// 效验partnumber加lineno唯一
		HashMap<String, String> map = new HashMap<>();
		for (OrderLine asnLine : this.item) {
			if (map.containsKey(asnLine.getAsndetailno() + asnLine.getMatnr())) {
				throw new OmsBusinessException("6002", "ASNDETAILNO+MATNR应该唯一");
			}
			map.put(asnLine.getAsndetailno() + asnLine.getMatnr(), null);
		}

		try {
			DateDealUtil.isDateVail(this.getZbudat());
		}
		catch (Exception e) {
			throw new OmsBusinessException("6003", "时间格式错误,yyyy-MM-dd HH:mm:ss");
		}

	}

}
