package com.herdsric.oms.lotus.enums;

import com.herdsric.oms.common.core.validation.EnumValidator;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;

/**
 * @Description: 物料凭证状态类型
 * @author: Dzx
 * @date: 2022.11.02
 */
@Getter
@RequiredArgsConstructor
public enum DnVoucherWriteOffStatusEnum implements EnumValidator {

	NOT_SEND("0", "未发送"), ALREADY_WRITE_OFF("1", "已冲销"), FAIL_WRITE_OFF("2", "冲销失败"),;

	/**
	 * 类型
	 */
	private final String value;

	/**
	 * 描述
	 */
	private final String name;

	/**
	 * 根据名称获取value
	 * @param value
	 * @return
	 */
	public static String getNameByValue(String value) {
		if (StringUtils.isEmpty(value)) {
			return null;
		}
		for (DnVoucherWriteOffStatusEnum enums : DnVoucherWriteOffStatusEnum.values()) {
			if (enums.value.equals(value)) {
				return enums.getName();
			}
		}

		return null;
	}

}
