package com.herdsric.oms.lotus.enums;

import com.herdsric.oms.common.core.validation.EnumValidator;

/**
 * @author ：lzq
 * @date ：Created in 2022-11-07 0007 11:51 @description：
 * @modified By：
 * @version: $
 */
public enum CTypeEnum implements EnumValidator {

	TOB("B", "To B"), TOC("C", "To C"), CLAIM("Claim", "Claim");

	private String key;

	private String value;

	CTypeEnum(String key, String value) {
		this.key = key;
		this.value = value;
	}

	@Override
	public String getValue() {
		return this.key;
	}

	/***
	 * 根据key获取value
	 * @param key 传入key
	 * @return
	 */
	public static String getValueByKey(String key, String zddlx) {
		if (CTypeEnum.TOB.key.equals(key)) {
			return ZDDLXEnum.getOrderType(zddlx);
		}
		return CTypeEnum.TOC.value;
	}

}
