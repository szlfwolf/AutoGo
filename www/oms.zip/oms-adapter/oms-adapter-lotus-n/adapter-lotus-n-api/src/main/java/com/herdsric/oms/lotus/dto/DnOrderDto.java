package com.herdsric.oms.lotus.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.herdsric.oms.common.client.enums.UnitEnum;
import com.herdsric.oms.common.core.exception.OmsBusinessException;
import com.herdsric.oms.common.core.validation.RegexpConstants;
import com.herdsric.oms.common.core.validation.constraints.EnumCheck;
import com.herdsric.oms.lotus.common.LotusConstant;
import com.herdsric.oms.lotus.enums.CTypeEnum;
import com.herdsric.oms.lotus.enums.ZDDLXEnum;
import com.herdsric.oms.lotus.utils.DateDealUtil;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import java.util.HashMap;
import java.util.List;

/**
 * @author tyy
 * @createDate 2024/4/24 14:46
 */
@Data
public class DnOrderDto {

	@Schema(description = "出库库单号")
	@NotEmpty(message = "出库单号不能为空")
	@JsonProperty("asnno")
	private String asnno;

	@Schema(description = "收件人编码")
	@NotEmpty(message = "收件人编码不能为空")
	@JsonProperty("kunnr")
	private String kunnr;

	@Schema(description = "送达方名称")
	@NotEmpty(message = "送达方名称不能为空")
	@JsonProperty("name")
	private String name;

	@Schema(description = "门店编码")
	@JsonProperty("kunnr1")
	private String kunnr1;

	@Schema(description = "门店名称")
	@JsonProperty("name1")
	private String name1;

	@Schema(description = "交货单创建日期")
	@Pattern(regexp = RegexpConstants.YYYY_MM_DD_TIME, message = "交货单创建日期输入有误,格式:yyyy-MM-dd HH:mm:ss")
	@NotEmpty(message = "交货单创建日期不能为空")
	@JsonProperty("erdat")
	private String erdat;

	@Schema(description = "计划运输日期")
	@Pattern(regexp = RegexpConstants.YYYY_MM_DD_TIME, message = "计划运输日期输入有误,格式:yyyy-MM-dd HH:mm:ss")
	@NotEmpty(message = "计划运输日期不能为空")
	@JsonProperty("tddat")
	private String tddat;

	@Schema(description = "预计交货日期")
	@Pattern(regexp = RegexpConstants.YYYY_MM_DD_TIME, message = "预计交货日期输入有误,格式:yyyy-MM-dd HH:mm:ss")
	@NotEmpty(message = "要求交货日期不能为空")
	@JsonProperty("lfdat")
	private String lfdat;

	@Schema(description = "客户类型")
	@NotEmpty(message = "客户类型不能为空")
	@JsonProperty("ctype")
	@EnumCheck(CTypeEnum.class)
	private String ctype;

	@Schema(description = "国家2位代码")
	@NotEmpty(message = "国家2位代码不能为空")
	@JsonProperty("land1")
	private String land1;

	@Schema(description = "邮政编码")
	@NotEmpty(message = "邮政编码不能为空")
	@JsonProperty("post_code1")
	private String post_code1;

	@Schema(description = "收件人名称")
	@NotEmpty(message = "送达联系人不能为空")
	@JsonProperty("deliverypeople")
	private String deliverypeople;

	@Schema(description = "收件人电话")
	@NotEmpty(message = "送达联系电话不能为空")
	@JsonProperty("deliveryphonee")
	private String deliveryphonee;

	@Schema(description = "收件人地址")
	@NotEmpty(message = "送达地址地址不能为空")
	@JsonProperty("deliveryaddress")
	private String deliveryaddress;

	@Schema(description = "送达城市")
	@JsonProperty("city")
	private String city;

	@Schema(description = "联系人邮箱")
	@Pattern(regexp = RegexpConstants.EMAIL, message = "联系人邮箱格式不正确")
	@JsonProperty("email")
	private String email;

	@Schema(description = "备注")
	@JsonProperty("comments")
	private String comments;

	@Schema(description = "交易类型,发货|退货|移库不能为空")
	@NotEmpty(message = "交易类型,发货|退货|移库不能为空")
	@JsonProperty("zjylx")
	private String zjylx;

	@Schema(description = "退货单对应的交货单号")
	@JsonProperty("reference_dn")
	private String reference_dn;

	@Schema(description = "订单类型")
	@NotEmpty(message = "订单类型不能为空")
	@JsonProperty("zddlx")
	@EnumCheck(ZDDLXEnum.class)
	private String zddlx;

	@Schema(description = "货主代码")
	@NotEmpty(message = "货主代码不能为空")
	@JsonProperty("zhzdm")
	private String zhzdm;

	@Schema(description = "是否补发标识")
	@NotEmpty(message = "是否补发标识不能为空")
	@JsonProperty("sfbf")
	private String sfbf;

	@Schema(description = "ITEM")
	@JsonProperty("item")
	@NotEmpty(message = "明细不能为空")
	@Valid
	private List<LotusDnDetailDTO> item;

	@Data
	public static class LotusDnDetailDTO {

		@Schema(description = "ASN行号")
		@NotEmpty(message = "送货单行号不能为空")
		private String asndetailno;

		@Schema(description = "sap采购订单号")
		@NotEmpty(message = "sap采购订单号不能为空")
		private String ebeln;

		@Schema(description = "sap采购订单行号")
		@NotEmpty(message = "采购项目凭证编号不能为空")
		private String ebelp;

		@Schema(description = "sap订单号")
		@NotEmpty(message = "sap订单号不能为空")
		@JsonProperty("vgbel")
		private String vgbel;

		@Schema(description = "sap行号")
		@NotEmpty(message = "销售订单的项目编号不能为空")
		@JsonProperty("vgpos")
		private String vgpos;

		// @NotEmpty(message = "批次号不能为空")
		@Schema(description = "批次号")
		private String batchno;

		@Schema(description = "lcms订单号")
		private String lcmsno;

		@Schema(description = "产地")
		// @NotEmpty(message = "产地不能为空")
		private String product;

		@Schema(description = "有效期")
		// @NotEmpty(message = "有效期不能为空")
		private String productdate;

		@Schema(description = "生产日期")
		// @NotEmpty(message = "生产日期不能为空")
		private String validitydate;

		@Schema(description = "物料号")
		@NotEmpty(message = "物料号不能为空")
		private String matnr;

		@Schema(description = "数量")
		@NotEmpty(message = "数量不能为空")
		private String wamng;

		@Schema(description = "单位")
		@NotEmpty(message = "单位不能为空")
		@EnumCheck(value = UnitEnum.class)
		private String meins;

		@Schema(description = "备注")
		private String detailremark;

		@Schema(description = "包装")
		@JsonProperty(defaultValue = "package")
		private String pack;

		@Schema(description = "状态")
		private String state;

	}

	public void check() {

		// 效验partnumber加lineno唯一
		HashMap<String, String> map = new HashMap<>();
		for (LotusDnDetailDTO dnLine : this.getItem()) {
			if (map.containsKey(dnLine.getAsndetailno() + dnLine.getMatnr())) {
				throw new OmsBusinessException("6004", "ASNDETAILNO+MATNR应该唯一");
			}
			map.put(dnLine.getAsndetailno() + dnLine.getMatnr(), null);
		}

		// 当货主代码为线下门店时,门店编码和门店名称必填
		if (LotusConstant.ZHZDM.equals(this.getZhzdm())) {
			if (StringUtils.isBlank(this.getKunnr1()) || StringUtils.isBlank(this.getName1())) {
				throw new OmsBusinessException("6005", "门店编码和名称缺失");
			}
		}

		try {
			DateDealUtil.isDateVail(this.getErdat());
		}
		catch (Exception e) {
			throw new OmsBusinessException("6003", "时间格式错误,yyyy-MM-dd HH:mm:ss");
		}

	}

}
