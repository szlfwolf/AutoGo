package com.herdsric.oms.lotus.convert;

import com.alibaba.excel.converters.Converter;
import com.alibaba.excel.converters.ReadConverterContext;

/**
 * @Description: 是否重发转换器
 * @author: Dzx
 * @date: 2022.12.15
 */
public class ResendDnConverter implements Converter<String> {

	private final String Y = "Y";

	private final String N = "N";

	/**
	 * 这里读的时候会调用
	 * @param context
	 * @return
	 */
	@Override
	public String convertToJavaData(ReadConverterContext<?> context) {
		String stringValue = null;
		try {
			stringValue = context.getReadCellData().getStringValue();
			if (Y.equals(stringValue)) {
				return "1";
			}
			if (N.equals(stringValue)) {
				return "0";
			}
		}
		catch (Exception e) {

		}
		return stringValue;
	}

}
