package com.herdsric.oms.lotus.dto.lcms;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * @author ：lzq
 * @date ：Created in 2022-12-12 0012 14:44 @description：
 * @modified By：
 * @version: $
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LcmsBillOfLadingDTO implements Serializable {

	/**
	 * 请求来源
	 */
	private String sourceSystem;

	/**
	 * 门店代码
	 */
	private String dlrCode;

	/**
	 * Lcms销售订单号
	 */
	private String soNo;

	/**
	 * sap交货订单号
	 */
	private String doNo;

	/**
	 * 承运单号
	 */
	private String toNo;

	/**
	 * 承运单创建时间
	 */
	private String toCreateDate;

	/**
	 * 承运日期
	 */
	private String toDate;

	/**
	 * 时区
	 */
	private String tz;

	/**
	 * 承运商代码
	 */
	private String forearderCode;

	/**
	 * 承运商联系方式
	 */
	private String forearderContactInfo;

	/**
	 * 运输方式
	 */
	private String shipVia;

	/**
	 * 预计到货时间
	 */
	private String expecteDeliveryTime;

	/**
	 * 物流联系人
	 */
	private String contactPerson;

	/**
	 * 联系电话
	 */
	private String contactPhone;

	/**
	 * 收货地址
	 */
	private String receiveAdress;

	/**
	 * 扩展字段
	 */
	private String extendProps;

	/**
	 * 仓库代码
	 */
	private String warehouseCode;

	/**
	 * 批次号
	 */
	private String batchNo;

	/**
	 * 联系人地址
	 */
	private String addressId;

	/**
	 * 包装信息
	 */
	private List<LcmsBillOfLadingInfoDTO> packageInfo;

}
