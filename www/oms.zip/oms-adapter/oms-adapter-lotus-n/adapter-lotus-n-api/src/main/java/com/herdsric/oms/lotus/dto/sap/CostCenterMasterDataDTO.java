package com.herdsric.oms.lotus.dto.sap;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.Data;

import java.io.Serializable;

/**
 * @author ：lzq
 * @date ：Created in 2022-11-14 0014 16:28 @description：
 * @modified By：
 * @version: $
 */
@Data
public class CostCenterMasterDataDTO implements Serializable {

	/**
	 * 创建修改日期
	 */
	@JSONField(name = "UDATE")
	private String UDATE;

	/**
	 * 成本中心编码
	 */
	@JSONField(name = "KOSTL")
	private String costCenterCode;

	/**
	 * 公司代码
	 */
	@JSONField(name = "BUKRS")
	private String companyCode;

	/**
	 * 成本中心描述
	 */
	@JSONField(name = "KTEXT")
	private String costCenterDescribed;

	/**
	 * 控制范围
	 */
	@JSONField(name = "KOKRS")
	private String controlArea;

	/**
	 * 负责人
	 */
	@JSONField(name = "VERAK")
	private String principal;

	/**
	 * 开始生效时间
	 */
	@JSONField(name = "DATAB")
	private String startTime;

	/**
	 * 有效截止日期
	 */
	@JSONField(name = "DATBI")
	private String endTime;

	/**
	 * 启用标识
	 */
	@JSONField(name = "ENABLEDFLAG")
	private String enableFlag;

}
