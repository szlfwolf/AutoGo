package com.herdsric.oms.lotus.dto.lcms;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author ：lzq
 * @date ：Created in 2022-12-15 0015 11:06 @description：
 * @modified By：
 * @version: $
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SearchStockRespondVO implements Serializable {

	/**
	 * 物料代码
	 */
	private String partCode;

	/**
	 * 物料英文名称
	 */
	private String partNameEn;

	/**
	 * 物料中文名称
	 */
	private String partNameCn;

	/**
	 * 仓库代码
	 */
	private String warehouseCode;

	/**
	 * 计量单位
	 */
	private String spUint;

	/**
	 * 实际库存数量
	 */
	private String inventoryQuantity;

	/**
	 * 适用车型
	 */
	private String vehicleModel;

	/**
	 * 可用数量
	 */
	private String availableQuantity;

	/**
	 * 在途数量
	 */
	private String inTransitQuantity;

	/**
	 * 最近入库时间
	 */
	private String timeOfRecentInbound;

	/**
	 * 最近出库时间
	 */
	private String timeOfRecentOutbound;

}
