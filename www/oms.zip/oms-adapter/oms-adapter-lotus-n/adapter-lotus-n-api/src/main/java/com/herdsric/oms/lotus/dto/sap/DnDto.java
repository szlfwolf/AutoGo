/*
 *    Copyright (c) 2018-2025, lengleng All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * Neither the name of the oms4cloud.com developer nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 * Author: lengleng (wangiegie@gmail.com)
 */
package com.herdsric.oms.lotus.dto.sap;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.herdsric.oms.common.mybatis.base.LogicDelBaseEntity;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 出库单
 *
 * @author oms code generator
 * @date 2022-08-29 15:27:21
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Schema(description = "出库单")
public class DnDto extends LogicDelBaseEntity {

	/**
	 * 主键
	 */
	@Schema(description = "主键")
	private Integer id;

	/**
	 * 出库订单号
	 */
	@Schema(description = "出库订单号")
	private String bzOutOrderNo;

	/**
	 * 客户代码
	 */
	@Schema(description = "客户代码")
	private String clientCode;

	/**
	 * 仓库代码
	 */
	@Schema(description = "仓库代码")
	private String warehouseCode;

	/**
	 * 出库单号（系统生成）
	 */
	@Schema(description = "出库单号（系统生成）")
	private String dnNo;

	/**
	 * 合单号
	 */
	@Schema(description = "合单号")
	private String batchNo;

	/**
	 * zcck/qtck
	 */
	@Schema(description = "zcck/qtck")
	private String dnType;

	/**
	 * 紧急
	 */
	@Schema(description = "紧急")
	private String urgentLevel;

	/**
	 * 打包，分拣，签收，。。。
	 */
	@Schema(description = "打包，分拣，签收，。。。")
	private String status;

	/**
	 * 货运公司代码
	 */
	@Schema(description = "货运公司代码")
	private String shipCompanyCode;

	/**
	 * 货运公司名称
	 */
	@Schema(description = "货运公司名称")
	private String shipCompanyName;

	/**
	 * 货运单号
	 */
	@Schema(description = "货运单号")
	private String shipNo;

	/**
	 * 货运状态
	 */
	@Schema(description = "货运状态")
	private String shipStatus;

	/**
	 * 整单无库存，部分无库存，无库存
	 */
	@Schema(description = "整单无库存，部分无库存，无库存")
	private String noInventoryType;

	/**
	 * 收货地址外键id
	 */
	@Schema(description = "收货地址外键id")
	private Integer addressId;

	/**
	 * 期望发货时间
	 */
	@Schema(description = "期望发货时间")
	private String expectedDeliveryDate;

	/**
	 * 签收照片
	 */
	@Schema(description = "签收照片")
	private String podImg;

	/**
	 * 创建时间
	 */
	@Schema(description = "创建时间")
	private String productTime;

	/**
	 * 分仓时间
	 */
	@Schema(description = "分仓时间")
	private String dispatchTime;

	/**
	 * 发送到wms仓库时间
	 */
	@Schema(description = "发送到wms仓库时间")
	private String releaseTime;

	/**
	 * 开始拣货时间
	 */
	@Schema(description = "开始拣货时间")
	private String pickingTime;

	/**
	 * 拣货完成时间
	 */
	@Schema(description = "拣货完成时间")
	private String pickedTime;

	/**
	 * 开始打包
	 */
	@Schema(description = "开始打包")
	private String packingTime;

	/**
	 * 打包完成时间
	 */
	@Schema(description = "打包完成时间")
	private String packedTime;

	/**
	 * 出库时间
	 */
	@Schema(description = "出库时间")
	private String outboundedTime;

	/**
	 * 运输出车时间
	 */
	@Schema(description = "运输出车时间")
	private String shippedTime;

	/**
	 * 签收时间
	 */
	@Schema(description = "签收时间")
	private String podTime;

	/**
	 * 取消时间
	 */
	@Schema(description = "取消时间")
	private String cancelTime;

	/**
	 * 描述
	 */
	@Schema(description = "描述")
	private String remark;

	/***
	 * 来源类型
	 */
	@Schema(description = "来源类型")
	private String sourceType;

	/***
	 * 来源ID
	 */
	@Schema(description = "来源ID")
	private String sourceId;

	/***
	 * 订车时间
	 */
	@Schema(description = "订车时间")
	private String bookedTime;

	/**
	 * 来源： 用于OMS 判断是否同步到Portal 默认：PORTAL
	 */
	@Schema(description = "来源： 用于OMS 判断是否同步到Portal 默认：PORTAL")
	private String tag;

}
