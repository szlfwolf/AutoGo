package com.herdsric.oms.lotus.utils;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * @Description: 数据工具
 * @author: Dzx
 * @date: 2022.11.01
 */
@Slf4j
public class DataUtil {

	private static final String KILOGRAM_ZERO = "0";

	/**
	 * G转换成KG
	 */
	public static String gramToKilogram(String gram) {
		try {
			if (StringUtils.isBlank(gram)) {
				return KILOGRAM_ZERO;
			}
			return new BigDecimal(gram).divide(new BigDecimal("1000"), 2, BigDecimal.ROUND_HALF_UP).stripTrailingZeros()
					.toPlainString();
		}
		catch (Exception e) {
			return KILOGRAM_ZERO;
		}
	}

	/**
	 * 拆分集合为多个子集合
	 * @param <T>
	 * @param sourceList 源集合list
	 * @param batchCount 每个子list的最大容量
	 * @return
	 */
	public static <T> List<List<T>> batchList(List<T> sourceList, int batchCount) {
		List<List<T>> returnList = new ArrayList<>();
		// 从第0个下标开始
		int startIndex = 0;
		while (startIndex < sourceList.size()) {
			int endIndex = 0;
			if (sourceList.size() - batchCount < startIndex) {
				endIndex = sourceList.size();
			}
			else {
				endIndex = startIndex + batchCount;
			}
			returnList.add(sourceList.subList(startIndex, endIndex));
			// 下一批
			startIndex = startIndex + batchCount;
		}
		return returnList;
	}

}
