package com.herdsric.oms.lotus.api;

import com.herdsric.oms.common.core.constant.SecurityConstants;
import com.herdsric.oms.common.core.constant.ServiceNameConstants;
import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.lotus.dto.sap.SkuVoucherDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;

/**
 * @author ：lzq
 * @date ：Created in 2022-10-31 0031 16:36 @description：
 * @modified By：
 * @version: $
 */
@FeignClient(contextId = "LotusNewService", value = ServiceNameConstants.ADAPTER_LOTUS_NEW)
public interface RemoteLotusService {

	/**
	 * 进行向SAP同步 并创建物料凭证
	 * @return
	 */
	@PostMapping("/apis/skuVoucher/add")
	R SkuVoucher(SkuVoucherDto skuVoucherDto, @RequestHeader(name = "clientCode") String clientCode,
			@RequestHeader(SecurityConstants.FROM) String from);

}
