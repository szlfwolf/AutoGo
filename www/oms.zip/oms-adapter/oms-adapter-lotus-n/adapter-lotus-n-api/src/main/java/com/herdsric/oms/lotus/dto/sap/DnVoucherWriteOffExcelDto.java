package com.herdsric.oms.lotus.dto.sap;

import com.alibaba.excel.annotation.ExcelProperty;
import com.herdsric.oms.lotus.convert.ResendDnConverter;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

/**
 * @author Herdsric
 * @TableName dn凭证冲销参数
 */
@Data
@Schema(description = "dn凭证冲销参数")
@EqualsAndHashCode
public class DnVoucherWriteOffExcelDto {

	/**
	 * dn订单号
	 */
	@ExcelProperty("Dn Order")
	@NotBlank(message = "dn号不能为空")
	@Schema(description = "dn订单号")
	private String dnOrder;

	/**
	 * 是否重发Dn（0：否；1：是）
	 */
	@ExcelProperty(value = "Resend Dn", converter = ResendDnConverter.class)
	@NotBlank(message = "是否重发Dn不能为空")
	@Schema(description = "是否重发Dn（0/1）")
	@Pattern(regexp = "^0|1", message = "是否重发格式错误")
	private String resendDn;

}