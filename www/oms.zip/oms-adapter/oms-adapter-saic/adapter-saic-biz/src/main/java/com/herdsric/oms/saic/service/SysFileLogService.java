package com.herdsric.oms.saic.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.herdsric.oms.saic.entity.SysFileLog;

public interface SysFileLogService extends IService<SysFileLog> {

}
