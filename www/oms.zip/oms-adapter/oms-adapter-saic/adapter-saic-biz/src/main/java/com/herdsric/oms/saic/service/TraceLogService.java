package com.herdsric.oms.saic.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.IService;
import com.herdsric.oms.saic.entity.TraceLog;

import java.util.List;
import java.util.function.Function;

public interface TraceLogService extends IService<TraceLog> {

	boolean batchSaveOrUpdate(List<TraceLog> list, Function<TraceLog, LambdaQueryWrapper<TraceLog>> function);

	void saveBatch(List<TraceLog> list);

	void physicsDeleteByType(String name);

	List<TraceLog> listNotSendAsn();

	List<TraceLog> listNotSendDn();

	List<TraceLog> listNotSendSku();

}
