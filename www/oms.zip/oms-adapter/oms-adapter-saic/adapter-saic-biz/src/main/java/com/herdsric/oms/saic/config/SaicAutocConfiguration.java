package com.herdsric.oms.saic.config;

import com.herdsric.oms.saic.sftp.ConnectionPool;
import com.herdsric.oms.saic.sftp.ShellProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableConfigurationProperties({ WmsProperties.class, ShellProperties.class, SaicCommonProperties.class })
public class SaicAutocConfiguration {

	@Bean
	public ConnectionPool connectionPool(ShellProperties shellProperties) {
		return new ConnectionPool(shellProperties);
	}

}
