package com.herdsric.oms.saic.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

@Data
@ConfigurationProperties(prefix = "saic.common")
public class SaicCommonProperties {

	private String showUri;

}
