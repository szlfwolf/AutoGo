package com.herdsric.oms.saic.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.herdsric.oms.common.client.asn.domain.AsnOrderDm;
import com.herdsric.oms.common.client.dn.domain.DnOrderDm;
import com.herdsric.oms.common.client.masterdata.domain.SkuDm;
import com.herdsric.oms.common.core.constant.CommonConstants;
import com.herdsric.oms.common.core.constant.SecurityConstants;
import com.herdsric.oms.common.core.util.JsonMapper;
import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.common.feign.client.RemoteAsnOrderService;
import com.herdsric.oms.common.feign.client.RemoteDnOrderService;
import com.herdsric.oms.common.feign.client.RemoteSkuService;
import com.herdsric.oms.common.mybatis.base.BaseEntity;
import com.herdsric.oms.saic.config.AdapterConfig;
import com.herdsric.oms.saic.csv.InboundHeadDto;
import com.herdsric.oms.saic.csv.OutboundHeadDto;
import com.herdsric.oms.saic.csv.SkuDto;
import com.herdsric.oms.saic.entity.SysFileLog;
import com.herdsric.oms.saic.entity.TraceLog;
import com.herdsric.oms.saic.enums.DirectionEnum;
import com.herdsric.oms.saic.enums.TypeEnum;
import com.herdsric.oms.saic.service.SaicReadFilesService;
import com.herdsric.oms.saic.service.SysFileLogService;
import com.herdsric.oms.saic.service.TraceLogService;
import com.herdsric.oms.saic.sftp.ConnectionPool;
import com.herdsric.oms.saic.sftp.ShellProperties;
import com.herdsric.oms.saic.util.CsvUtils;
import com.herdsric.oms.saic.util.SaicConstants;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class SaicReadFilesServiceImpl implements SaicReadFilesService {

	private final RemoteSkuService remoteSkuService;

	private final RemoteAsnOrderService remoteAsnOrderService;

	private final RemoteDnOrderService remoteDnOrderService;

	private final SysFileLogService sysFileLogService;

	private final TraceLogService traceLogService;

	private final ConnectionPool connectionPool;

	private final ShellProperties shellProperties;

	private final AdapterConfig adapterConfig;

	@Override
	public void downloadFiles() {
		Map<String, ShellProperties.Config> configMap = shellProperties.getConfigMap();
		for (String key : configMap.keySet()) {
			ShellProperties.Config config = configMap.get(key);
			if (StrUtil.equals(config.getDirection(), DirectionEnum.IN.name())) {
				try {
					String localPath = shellProperties.generateLocalPath(key);
					List<SysFileLog> sysFileLogs = connectionPool.down(config.getRemotePath(), config.getRegex(),
							localPath, config.getRemotePathBak(), key);
					sysFileLogService.saveBatch(sysFileLogs);
				}
				catch (Exception e) {
					log.error("下载文件失败:{}", e.getMessage(), e);
				}
			}
		}
	}

	@Override
	public void readSkuMasterData() {
		List<TraceLog> traceLogs = traceLogService.listNotSendSku();
		if (traceLogs.isEmpty()) {
			log.info("没有待处理的ITEMS");
			return;
		}
		List<SkuDm> skuDms = new ArrayList<>();
		for (TraceLog traceLog : traceLogs) {
			try {
				SkuDto skuDto = JsonMapper.INSTANCE.fromJson(traceLog.getMsgIn(), SkuDto.class);
				SkuDm skuDm = SkuDto.toSkuDm(skuDto);
				traceLog.setMsgOut(JsonMapper.INSTANCE.toJson(skuDm));
				skuDms.add(skuDm);
			}
			catch (Exception e) {
				log.error("处理SKU:{} 订单失败:{}", traceLog.getReference(), e.getMessage(), e);
				traceLog.setStatus(CommonConstants.N);
				traceLog.setMessage(StrUtil.maxLength(e.getMessage(), 4000));
			}
			finally {
				traceLog.setRetryNum(traceLog.getRetryNum() + 1);
			}
		}
		if (CollectionUtil.isNotEmpty(skuDms)) {
			R result = remoteSkuService.saveBatch(skuDms, CommonConstants.COMPANY_CODE_SAIC, SecurityConstants.FROM_IN);
			for (TraceLog traceLog : traceLogs) {
				if (skuDms.stream().anyMatch(x -> StrUtil.equals(x.getPartNumber(), traceLog.getReference()))) {
					traceLog.setStatus(result.getCode() == 0 ? CommonConstants.Y : CommonConstants.N);
					traceLog.setMessage(JsonMapper.INSTANCE.toJson(result));
				}
			}
		}

		traceLogService.updateBatchById(traceLogs);
	}

	@Override
	public void singleHandleAsn() {
		List<TraceLog> traceLogs = traceLogService.listNotSendAsn();
		if (traceLogs.isEmpty()) {
			log.info("没有待处理的ASN订单");
			return;
		}

		List<TraceLog> traceLogs2 = new ArrayList<>();
		for (TraceLog traceLog : traceLogs) {
			try {
				TraceLog pTraceLog = traceLog.getLTraceLog();
				AsnOrderDm asnOrderDm = InboundHeadDto.toAsnOrderDm(traceLog.getMsgIn(), pTraceLog.getMsgIn());
				traceLog.setMsgOut(JsonMapper.INSTANCE.toJson(asnOrderDm));

				R response = remoteAsnOrderService.save(asnOrderDm, CommonConstants.COMPANY_CODE_SAIC,
						SecurityConstants.FROM_IN);
				if (response.getCode() == CommonConstants.SUCCESS) {
					traceLog.setStatus(CommonConstants.Y);
					pTraceLog.setStatus(CommonConstants.Y);
				}
				else {
					traceLog.setStatus(CommonConstants.N);
					pTraceLog.setStatus(CommonConstants.N);
				}
				traceLog.setMessage(JsonMapper.INSTANCE.toJson(response));
				pTraceLog.setMessage(JsonMapper.INSTANCE.toJson(response));
			}
			catch (Exception e) {
				log.error("处理ASN:{} 订单失败:{}", traceLog.getReference(), e.getMessage(), e);
				traceLog.setStatus(CommonConstants.N);
				traceLog.setMessage(StrUtil.maxLength(e.getMessage(), 4000));
			}
			finally {
				traceLog.setRetryNum(traceLog.getRetryNum() + 1);

				traceLogs2.add(traceLog);
				traceLogs2.add(traceLog.getLTraceLog());
			}
		}

		traceLogService.updateBatchById(traceLogs2);
	}

	@Override
	public void singleHandleDn() {
		List<TraceLog> traceLogs = traceLogService.listNotSendDn();
		if (traceLogs.isEmpty()) {
			log.info("没有待处理的DN订单");
			return;
		}
		List<TraceLog> traceLogs2 = new ArrayList<>();
		for (TraceLog traceLog : traceLogs) {
			try {
				TraceLog pTraceLog = traceLog.getLTraceLog();
				DnOrderDm dnOrderDm = OutboundHeadDto.toDnOrderDm(traceLog.getMsgIn(), pTraceLog.getMsgIn());

				dnOrderDm.setContactEmail(StrUtil.isBlank(dnOrderDm.getContactEmail()) ? adapterConfig.getDnEmail()
						: dnOrderDm.getContactEmail());

				traceLog.setMsgOut(JsonMapper.INSTANCE.toJson(dnOrderDm));

				R response = remoteDnOrderService.save(dnOrderDm, CommonConstants.COMPANY_CODE_SAIC,
						SecurityConstants.FROM_IN);
				if (response.getCode() == CommonConstants.SUCCESS) {
					traceLog.setStatus(CommonConstants.Y);
					pTraceLog.setStatus(CommonConstants.Y);
				}
				else {
					traceLog.setStatus(CommonConstants.N);
					pTraceLog.setStatus(CommonConstants.N);
				}
				traceLog.setMessage(JsonMapper.INSTANCE.toJson(response));
				pTraceLog.setMessage(JsonMapper.INSTANCE.toJson(response));
			}
			catch (Exception e) {
				log.error("处理DN:{} 订单失败:{}", traceLog.getReference(), e.getMessage(), e);
				traceLog.setStatus(CommonConstants.N);
				traceLog.setMessage(StrUtil.maxLength(e.getMessage(), 4000));
			}
			finally {
				traceLog.setRetryNum(traceLog.getRetryNum() + 1);
				traceLogs2.add(traceLog);
				traceLogs2.add(traceLog.getLTraceLog());
			}
		}

		traceLogService.updateBatchById(traceLogs2);
	}

	@Override
	public void retryAnalyzeFile() {
		LambdaQueryWrapper<SysFileLog> lambdaQueryWrapper = Wrappers.lambdaQuery();
		lambdaQueryWrapper.eq(SysFileLog::getStatus, CommonConstants.N);
		lambdaQueryWrapper.eq(SysFileLog::getDirection, DirectionEnum.IN.name());
		lambdaQueryWrapper.lt(SysFileLog::getRetryNum, 3);
		lambdaQueryWrapper.orderByAsc(BaseEntity::getCreateTime);
		lambdaQueryWrapper.last("limit 30");
		List<SysFileLog> sysFileLogs = sysFileLogService.list(lambdaQueryWrapper);
		if (sysFileLogs.isEmpty()) {
			log.info("没有待解析的文件");
			return;
		}

		for (SysFileLog sysFileLog : sysFileLogs) {
			try {
				TypeEnum typeEnum = TypeEnum.instance(sysFileLog.getType());
				List<TraceLog> traceLogs = new ArrayList<>();
				List<Object> objList;
				switch (typeEnum) {
					case SKU:
						traceLogService.physicsDeleteByType(TypeEnum.SKU.name());
					case INBOUND_H:
					case OUTBOUND_H:
						objList = CsvUtils.readCSVFile(sysFileLog.getLocalPath() + sysFileLog.getLocalName(),
								typeEnum.clazz);
						for (Object obj : objList) {
							TraceLog traceLog = new TraceLog();
							traceLog.setReference(typeEnum.getReference(obj));
							traceLog.setType(typeEnum.name());
							traceLog.setMsgIn(JsonMapper.INSTANCE.toJson(obj));
							traceLog.setMsgOut("");
							traceLog.setSource(CommonConstants.COMPANY_CODE_SAIC);
							traceLog.setTarget(SaicConstants.OMS);
							traceLog.setRetryNum(0);
							traceLog.setCreateBy(sysFileLog.getName());
							traceLog.setStatus(CommonConstants.N);
							traceLogs.add(traceLog);
						}
						sysFileLog.setStatus(CommonConstants.Y);
						sysFileLog.setMessage("文件解析成功");
						traceLogService.saveBatch(traceLogs);
						break;
					case INBOUND_P:
					case OUTBOUND_P:
						try {
							objList = CsvUtils.readCSVFile(sysFileLog.getLocalPath() + sysFileLog.getLocalName(),
									typeEnum.clazz);
							for (Object obj : objList) {
								TraceLog traceLog = new TraceLog();
								traceLog.setReference(typeEnum.getReference(obj));
								traceLog.setType(typeEnum.name());
								traceLog.setMsgIn(JsonMapper.INSTANCE.toJson(obj));
								traceLog.setMsgOut("");
								traceLog.setSource(CommonConstants.COMPANY_CODE_SAIC);
								traceLog.setTarget(SaicConstants.OMS);
								traceLog.setRetryNum(0);
								traceLog.setCreateBy(sysFileLog.getName());
								traceLog.setStatus(CommonConstants.N);
								traceLogs.add(traceLog);
							}
							sysFileLog.setStatus(CommonConstants.Y);
							sysFileLog.setMessage("文件解析成功");
							Map<String, List<TraceLog>> map = traceLogs.stream()
									.collect(Collectors.groupingBy(TraceLog::getReference, Collectors.toList()));
							List<TraceLog> traceLogs2 = new ArrayList<>();
							// 存在多行数据，需要合并处理
							map.forEach((k, v) -> {
								TraceLog traceLog = BeanUtil.copyProperties(v.get(0), TraceLog.class);
								List<Map<String, Object>> msgInList = new ArrayList<>();
								for (TraceLog x : v) {
									msgInList.add(JsonMapper.INSTANCE.fromJson(x.getMsgIn(), Map.class));
								}
								traceLog.setMsgIn(JsonMapper.INSTANCE.toJson(msgInList));
								traceLogs2.add(traceLog);
							});
							traceLogService.saveBatch(traceLogs2);
						}
						catch (Exception e) {
							sysFileLog.setStatus(CommonConstants.N);
							sysFileLog.setMessage(StrUtil.maxLength(e.getMessage(), 4000));
							log.error("读取文件失败:{}", e.getMessage(), e);
						}
						break;
					default:
						sysFileLog.setMessage("未知类型无法解析");
						log.error("未知类型文件:{}", sysFileLog.getType());
				}
			}
			catch (Exception e) {
				sysFileLog.setStatus(CommonConstants.N);
				sysFileLog.setMessage(StrUtil.maxLength(e.getMessage(), 4000));
				log.error("读取文件失败:{}", e.getMessage(), e);
			}
			finally {
				sysFileLog.setRetryNum(sysFileLog.getRetryNum() + 1);
				sysFileLogService.updateById(sysFileLog);
			}
		}

	}

}
