package com.herdsric.oms.saic.job;

import cn.hutool.core.util.StrUtil;
import com.herdsric.oms.common.job.common.AbstractCommonTask;
import com.herdsric.oms.saic.enums.DirectionEnum;
import com.herdsric.oms.saic.handler.MergeFileHandler;
import com.herdsric.oms.saic.job.common.JobCommon;
import com.herdsric.oms.saic.service.SaicReadFilesService;
import com.herdsric.oms.saic.service.SaicSendFileService;
import com.herdsric.oms.saic.sftp.ShellProperties;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Slf4j
@Component
@RequiredArgsConstructor
public class SaicJob extends AbstractCommonTask {

	private final SaicReadFilesService saicReadFilesService;

	private final MergeFileHandler mergeFileHandler;

	private final SaicSendFileService saicSendFileService;

	private final ShellProperties shellProperties;

	@XxlJob(JobCommon.JobName.BATCH_DOWNLOAD_FILE_JOB)
	public void batchDownloadCsv() {
		this.execute(JobCommon.TaskEnum.BATCH_DOWNLOAD_FILE_JOB, x -> saicReadFilesService.downloadFiles());
	}

	@XxlJob(JobCommon.JobName.RETRY_ANALYZE_FILE_JOB)
	public void retryAnalyseFile() {
		this.execute(JobCommon.TaskEnum.RETRY_ANALYZE_FILE_JOB, x -> saicReadFilesService.retryAnalyzeFile());
	}

	@XxlJob(JobCommon.JobName.BATCH_UPLOAD_FILE_JOB)
	public void batchUploadCsv() {
		this.execute(JobCommon.TaskEnum.BATCH_UPLOAD_FILE_JOB, x -> {
			Map<String, ShellProperties.Config> configMap = shellProperties.getConfigMap();

			List<String> typeList = new ArrayList<>();
			configMap.forEach((k, v) -> {
				if (StrUtil.equals(v.getDirection(), DirectionEnum.OUT.name())) {
					typeList.add(k);
				}
			});
			mergeFileHandler.pushFileToSftp(typeList);
		});
	}

	@XxlJob(JobCommon.JobName.ITEM_TO_OMS_JOB)
	public void itemToOms() {
		this.execute(JobCommon.TaskEnum.ITEM_TO_OMS_JOB, x -> {
			saicReadFilesService.readSkuMasterData();
		});
	}

	@XxlJob(JobCommon.JobName.ASN_ORDER_TO_OMS_JOB)
	public void asnOrderToOms() {
		this.execute(JobCommon.TaskEnum.ASN_ORDER_TO_OMS_JOB, x -> {
			saicReadFilesService.singleHandleAsn();
		});
	}

	@XxlJob(JobCommon.JobName.DN_ORDER_TO_OMS_JOB)
	public void dnOrderToOms() {
		this.execute(JobCommon.TaskEnum.DN_ORDER_TO_OMS_JOB, x -> {
			saicReadFilesService.singleHandleDn();
		});
	}

	/**
	 * 业务确认，不需要快照同步
	 */
	// @XxlJob(JobCommon.JobName.INVENTORY_PULL_TO_CLIENT_JOB)
	public void inventoryPullToClient() {
		this.execute(JobCommon.TaskEnum.INVENTORY_PULL_TO_CLIENT_JOB, x -> saicSendFileService.sendInventoryFile());
	}

}
