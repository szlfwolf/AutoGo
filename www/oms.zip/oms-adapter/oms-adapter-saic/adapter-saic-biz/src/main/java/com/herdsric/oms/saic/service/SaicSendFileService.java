package com.herdsric.oms.saic.service;

import com.herdsric.oms.common.client.dn.domain.DnSplitDm;
import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.saic.csv.*;

import java.util.List;

public interface SaicSendFileService {

	void sendInventoryFile();

	R sendPackingConfirmationFile(List<PkgHeadDto> pkgHeadDtoList, List<PkgLineDto> pkgLineDtoList, String dn);

	R sendDispathConfirmationFile(GiDto giDto, String dn);

	R sendPodFile(PodDto podDto, String dn);

	R splitDn(DnSplitDm dnSplitDm);

	R sendInboundResponseFile(List<GrDto> grDtos, String asnNo);

}
