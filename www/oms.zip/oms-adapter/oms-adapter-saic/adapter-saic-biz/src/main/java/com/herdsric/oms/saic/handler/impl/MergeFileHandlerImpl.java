package com.herdsric.oms.saic.handler.impl;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.io.FileUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.herdsric.oms.common.core.constant.CommonConstants;
import com.herdsric.oms.common.mybatis.base.BaseEntity;
import com.herdsric.oms.saic.entity.SysFileLog;
import com.herdsric.oms.saic.enums.DirectionEnum;
import com.herdsric.oms.saic.handler.MergeFileHandler;
import com.herdsric.oms.saic.service.SysFileLogService;
import com.herdsric.oms.saic.sftp.ConnectionPool;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class MergeFileHandlerImpl implements MergeFileHandler {

	private final SysFileLogService sysFileLogService;

	private final ConnectionPool connectionPool;

	@Override
	public void pushFileToSftp(List<String> list) {
		List<SysFileLog> sysFileLogs = sysFileLogService.list(Wrappers.<SysFileLog>lambdaQuery()
				.in(SysFileLog::getType, list).eq(SysFileLog::getDirection, DirectionEnum.OUT.name())
				.eq(SysFileLog::getStatus, CommonConstants.N).le(SysFileLog::getRetryNum, "3")
				.orderByAsc(BaseEntity::getCreateTime).last("LIMIT 100"));
		if (CollectionUtil.isEmpty(sysFileLogs)) {
			log.info("没有需要上传的文件");
			return;
		}
		for (SysFileLog sysFileLog : sysFileLogs) {
			try {
				boolean tag = connectionPool.upload(sysFileLog.getPath(), sysFileLog.getName(),
						FileUtil.file(sysFileLog.getLocalPath() + sysFileLog.getLocalName()));
				if (tag) {
					sysFileLog.setStatus(CommonConstants.Y);
					sysFileLog.setMessage("上传成功");
					sysFileLogService.updateById(sysFileLog);
				}
				else {
					sysFileLog.setMessage("上传失败");
				}
			}
			catch (Exception e) {
				sysFileLog.setMessage(StrUtil.maxLength(e.getMessage(), 4000));
				log.error("上传文件失败", e);
			}
			finally {
				sysFileLog.setRetryNum(sysFileLog.getRetryNum() + 1);
				sysFileLogService.updateById(sysFileLog);
			}

		}

	}

}
