package com.herdsric.oms.saic.apis.dto;

import lombok.*;
import lombok.experimental.Accessors;

import java.io.Serializable;

@Builder
@ToString
@Accessors(chain = true)
@AllArgsConstructor
public class WMSResult<T> implements Serializable {

	private static final long serialVersionUID = 1L;

	@Getter
	@Setter
	private String status;

	@Getter
	@Setter
	private String statusMsg;

	@Getter
	@Setter
	private T data;

	public WMSResult() {
		super();
	}

	public WMSResult(T data) {
		super();
		this.data = data;
	}

	public WMSResult(String statusMsg, String status) {
		super();
		this.statusMsg = statusMsg;
		this.status = status;
	}

	public WMSResult(T data, String statusMsg, String status) {
		super();
		this.data = data;
		this.statusMsg = statusMsg;
		this.status = status;
	}

}