package com.herdsric.oms.saic.service.impl;

import cn.hutool.core.collection.CollectionUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.enums.SqlMethod;
import com.baomidou.mybatisplus.core.toolkit.Constants;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.herdsric.oms.common.core.constant.CommonConstants;
import com.herdsric.oms.common.core.exception.ErrorCodeEnum;
import com.herdsric.oms.common.core.exception.OmsBusinessException;
import com.herdsric.oms.common.mybatis.base.BaseEntity;
import com.herdsric.oms.saic.entity.TraceLog;
import com.herdsric.oms.saic.enums.TypeEnum;
import com.herdsric.oms.saic.mapper.TraceLogMapper;
import com.herdsric.oms.saic.service.TraceLogService;
import org.apache.ibatis.binding.MapperMethod;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

@Service
public class TraceLogServiceImpl extends ServiceImpl<TraceLogMapper, TraceLog> implements TraceLogService {

	@Override
	public boolean batchSaveOrUpdate(List<TraceLog> list, Function<TraceLog, LambdaQueryWrapper<TraceLog>> function) {
		String selectListSqlStatement = this.getSqlStatement(SqlMethod.SELECT_LIST);

		List<TraceLog> updateList = new ArrayList<>();
		List<TraceLog> saveList = new ArrayList<>();
		this.executeBatch(list, (sqlSession, entity) -> {
			MapperMethod.ParamMap<Object> param = new MapperMethod.ParamMap();
			param.put(Constants.WRAPPER, function.apply(entity));
			List<TraceLog> logs = sqlSession.selectList(selectListSqlStatement, param);

			if (logs.isEmpty()) {
				saveList.add(entity);
			}
			else if (logs.size() > 1) {
				throw new OmsBusinessException(ErrorCodeEnum.E999999);
			}
			else {
				entity.setRetryNum(logs.get(0).getRetryNum() + 1);
				entity.setId(logs.get(0).getId());
				updateList.add(entity);
			}
		});

		if (CollectionUtil.isNotEmpty(updateList)) {
			this.getBaseMapper().updateBatch(updateList);
		}
		if (CollectionUtil.isNotEmpty(saveList)) {
			this.getBaseMapper().insertBatch(saveList);
		}

		return true;
	}

	@Override
	public void saveBatch(List<TraceLog> list) {
		if (CollectionUtil.isNotEmpty(list)) {
			List<List<TraceLog>> splitList = CollectionUtil.split(list, 1000);
			for (List<TraceLog> subList : splitList) {
				this.baseMapper.insertBatch(subList);
			}
		}
	}

	@Override
	public void physicsDeleteByType(String type) {
		this.baseMapper.physicsDeleteByType(type);
	}

	@Override
	public List<TraceLog> listNotSendAsn() {
		String pType = TypeEnum.INBOUND_P.name();
		String hType = TypeEnum.INBOUND_H.name();
		String status = CommonConstants.N;
		int retryNum = 3;
		int position = 6;
		return this.baseMapper.selectNotSendLogs(pType, hType, status, retryNum, position);
	}

	@Override
	public List<TraceLog> listNotSendDn() {
		String pType = TypeEnum.OUTBOUND_P.name();
		String hType = TypeEnum.OUTBOUND_H.name();
		String status = CommonConstants.N;
		int retryNum = 3;
		int position = 5;
		return this.baseMapper.selectNotSendLogs(pType, hType, status, retryNum, position);
	}

	@Override
	public List<TraceLog> listNotSendSku() {
		LambdaQueryWrapper<TraceLog> lambdaQueryWrapper = Wrappers.lambdaQuery();
		lambdaQueryWrapper.eq(TraceLog::getType, TypeEnum.SKU.name());
		lambdaQueryWrapper.lt(TraceLog::getRetryNum, 3);
		lambdaQueryWrapper.eq(TraceLog::getStatus, CommonConstants.N);
		lambdaQueryWrapper.orderByAsc(BaseEntity::getCreateTime);
		lambdaQueryWrapper.last("limit 100");
		return this.baseMapper.selectList(lambdaQueryWrapper);
	}

}
