package com.herdsric.oms.saic.mapper;

import com.herdsric.oms.common.mybatis.base.RootMapper;
import com.herdsric.oms.saic.entity.TraceLog;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface TraceLogMapper extends RootMapper<TraceLog> {

	void physicsDeleteByType(@Param("type") String type);

	List<TraceLog> selectNotSendLogs(@Param("pType") String pType, @Param("hType") String hType,
			@Param("status") String status, @Param("retryNum") int retryNum, @Param("position") int position);

}
