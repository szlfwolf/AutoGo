package com.herdsric.oms.saic.job.common;

import cn.hutool.core.util.StrUtil;
import com.herdsric.oms.common.job.common.JobTask;

public class JobCommon {

	private static final String JOB_KEY_PREFIX = "SAIC-JOB-TASK";

	public static class JobName {

		/**
		 * CSV 批量下载JOG任务
		 */
		public static final String BATCH_DOWNLOAD_FILE_JOB = "batchDownloadFileJob";

		/**
		 * 重试解析下载文件
		 */
		public static final String RETRY_ANALYZE_FILE_JOB = "retryAnalyzeFileJob";

		/**
		 * CSV 批量上传JOG任务
		 */
		public static final String BATCH_UPLOAD_FILE_JOB = "batchUploadFileJob";

		/**
		 * 主数据推送OMS JOG任务
		 */
		public static final String ITEM_TO_OMS_JOB = "itemToOmsJob";

		/**
		 * AsnOrder推送OMS JOG任务
		 */
		public static final String ASN_ORDER_TO_OMS_JOB = "asnOrderToOmsJob";

		/**
		 * DnOrder推送OMS JOG任务
		 */
		public static final String DN_ORDER_TO_OMS_JOB = "dnOrderToOmsJob";

		/**
		 * 拉取快照信息同步到客户端 JOG任务
		 */
		public static final String INVENTORY_PULL_TO_CLIENT_JOB = "inventoryPullToClientJob";

	}

	public enum TaskEnum implements JobTask {

		BATCH_DOWNLOAD_FILE_JOB(JobName.BATCH_DOWNLOAD_FILE_JOB, 30, "CSV 批量下载JOG任务"),

		RETRY_ANALYZE_FILE_JOB(JobName.RETRY_ANALYZE_FILE_JOB, 30, "重试解析下载文件"),
		BATCH_UPLOAD_FILE_JOB(JobName.BATCH_UPLOAD_FILE_JOB, 30, "CSV 批量上传JOG任务"),
		ITEM_TO_OMS_JOB(JobName.ITEM_TO_OMS_JOB, 30, "主数据推送OMS JOG任务"),
		ASN_ORDER_TO_OMS_JOB(JobName.ASN_ORDER_TO_OMS_JOB, 30, "AsnOrder推送OMS JOG任务"),
		DN_ORDER_TO_OMS_JOB(JobName.DN_ORDER_TO_OMS_JOB, 30, "DnOrder推送OMS JOG任务"),
		INVENTORY_PULL_TO_CLIENT_JOB(JobName.INVENTORY_PULL_TO_CLIENT_JOB, 30, "拉取快照信息同步到客户端 JOG任务");

		public String name;

		public int expireTime;

		public String desc;

		TaskEnum(String name, int expireTime, String desc) {
			this.name = name;
			this.expireTime = expireTime;
			this.desc = desc;
		}

		public String getDesc() {
			return StrUtil.concat(true, this.desc);
		}

		@Override
		public String getName() {
			return name;
		}

		@Override
		public int expireTime() {
			return expireTime;
		}

		@Override
		public String getDescription() {
			return desc;
		}

		public String getKey() {
			return StrUtil.concat(true, JOB_KEY_PREFIX, this.name);
		}

	}

}
