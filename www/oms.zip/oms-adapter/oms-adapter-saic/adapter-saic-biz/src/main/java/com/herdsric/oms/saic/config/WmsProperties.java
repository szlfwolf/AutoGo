package com.herdsric.oms.saic.config;

import com.herdsric.oms.common.core.util.SignUtils;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.List;

@Data
@ConfigurationProperties(prefix = "wms.http")
public class WmsProperties {

	private String serverAddress;

	private String authKey;

	private String orgKey;

	private List<String> methods;

	public String url(Method method) {
		return this.serverAddress + method.url;
	}

	public String generateApiKey() {
		return SignUtils.generateApiKey(this.authKey, this.orgKey);
	}

	public enum Method {

		/**
		 * OMS 库存查询接口
		 */
		INVENTORY_QUERY("/appName/api/inventory/query");

		public final String url;

		Method(String url) {
			this.url = url;
		}

	}

}
