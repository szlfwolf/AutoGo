package com.herdsric.oms.saic.apis;

import cn.hutool.core.util.StrUtil;
import com.herdsric.oms.common.client.asn.domain.AsnOrderResponseDm;
import com.herdsric.oms.common.client.dn.domain.DnSplitDm;
import com.herdsric.oms.common.client.dn.dto.DnOrderResponseDTO;
import com.herdsric.oms.common.client.enums.SyncEnum;
import com.herdsric.oms.common.core.constant.CommonConstants;
import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.saic.apis.dto.WMSResult;
import com.herdsric.oms.saic.csv.*;
import com.herdsric.oms.saic.dto.DnCancellationDto;
import com.herdsric.oms.saic.service.Saic2OmsService;
import com.herdsric.oms.saic.service.SaicSendFileService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
public class DnApis {

	private final Saic2OmsService saic2WmsService;

	private final SaicSendFileService saicSendFileService;

	/***
	 * edi->adapter,再到oms
	 * @param dnCancellationDto
	 * @return
	 */
	@PostMapping(value = "/apis/dn/cancellation")
	public WMSResult cancellation(@RequestBody @Valid DnCancellationDto dnCancellationDto) {
		try {
			dnCancellationDto.check();
			R result = saic2WmsService.cancelDn(dnCancellationDto);
			if (result.getCode() == CommonConstants.SUCCESS) {
				return WMSResult.builder().status("0")
						.statusMsg(StrUtil.format("Dn:{} cancellation success.", dnCancellationDto.getDnNo())).build();
			}
			return WMSResult.builder().status("1002").statusMsg(result.getMsg()).build();
		}
		catch (Exception e) {
			log.error(e.getMessage(), e);
			return WMSResult.builder().status("1003")
					.statusMsg(StrUtil.format("Dn:{} cancellation failed.", dnCancellationDto.getDnNo())).build();
		}
	}

	/**
	 * 同步DnOrder拆单信息，并生成文件
	 * @param dnSplitDm
	 * @return
	 */
	@PostMapping("/apis/sync-dns")
	public R splitDn(@Valid @RequestBody DnSplitDm dnSplitDm) {
		return saicSendFileService.splitDn(dnSplitDm);
	}

	/**
	 * 根据DnOrder状态生成文件
	 * @param dnOrderResponseDTO
	 * @param type
	 * @return
	 */
	@PostMapping("/apis/sync-dn/{type}")
	public R syncDnOrderStatus(@RequestBody DnOrderResponseDTO dnOrderResponseDTO, @PathVariable("type") String type) {
		SyncEnum syncEnum = SyncEnum.instance(type);
		switch (syncEnum) {
			case DN_ORDER_CANCEL_SYNC:
			case DN_ORDER_STATUS_PACKED_SYNC:
				List<PkgHeadDto> pkgHeadDtos = PkgHeadDto.convert(dnOrderResponseDTO);
				List<PkgLineDto> pkgLineDtos = PkgLineDto.convert(dnOrderResponseDTO);
				return saicSendFileService.sendPackingConfirmationFile(pkgHeadDtos, pkgLineDtos,
						dnOrderResponseDTO.getOrderNo());
			case DN_ORDER_STATUS_BOOKED_SYNC:
				break;

			case DN_ORDER_STATUS_OUTBOUND_SYNC:
				GiDto giDto = GiDto.convert(dnOrderResponseDTO);
				return saicSendFileService.sendDispathConfirmationFile(giDto, dnOrderResponseDTO.getOrderNo());

			case DN_ORDER_STATUS_POD_SYNC:
				PodDto podDto = PodDto.convert(dnOrderResponseDTO);
				return saicSendFileService.sendPodFile(podDto, dnOrderResponseDTO.getOrderNo());
			default:
				log.error("暂不支持的同步类型:{}", type);
				break;
		}
		return R.ok();
	}

	/**
	 * 根据AsnOrder状态生成文件
	 * @param asnOrderResponseDm
	 * @param type
	 * @return
	 */
	@PostMapping("/apis/sync-asn-status/{type}")
	public R syncAsnOrderStatus(@RequestBody AsnOrderResponseDm asnOrderResponseDm, @PathVariable("type") String type) {
		SyncEnum syncEnum = SyncEnum.instance(type);
		switch (syncEnum) {
			case ASN_ORDER_RESPONSED_SYNC:
				List<GrDto> grDtos = GrDto.convert(asnOrderResponseDm);
				saicSendFileService.sendInboundResponseFile(grDtos, asnOrderResponseDm.getOrderNo());
				break;
			default:
				log.error("暂不支持的同步类型:{}", type);
				break;
		}
		return R.ok();
	}

}
