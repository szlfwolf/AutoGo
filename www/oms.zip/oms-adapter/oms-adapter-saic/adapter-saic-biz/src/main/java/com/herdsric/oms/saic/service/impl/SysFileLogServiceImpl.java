package com.herdsric.oms.saic.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.herdsric.oms.saic.entity.SysFileLog;
import com.herdsric.oms.saic.mapper.SysFileLogMapper;
import com.herdsric.oms.saic.service.SysFileLogService;
import org.springframework.stereotype.Service;

@Service
public class SysFileLogServiceImpl extends ServiceImpl<SysFileLogMapper, SysFileLog> implements SysFileLogService {

}
