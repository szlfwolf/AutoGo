package com.herdsric.oms.saic.service;

import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.saic.dto.DnCancellationDto;

public interface Saic2OmsService {

	R cancelDn(DnCancellationDto dnCancellationDto);

}
