package com.herdsric.oms.saic.service.impl;

import cn.hutool.core.util.StrUtil;
import com.herdsric.oms.common.client.dn.domain.DnOrderCancelDm;
import com.herdsric.oms.common.core.constant.CommonConstants;
import com.herdsric.oms.common.core.constant.SecurityConstants;
import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.common.feign.client.RemoteDnOrderService;
import com.herdsric.oms.saic.dto.DnCancellationDto;
import com.herdsric.oms.saic.service.Saic2OmsService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class Saic2OmsServiceImpl implements Saic2OmsService {

	private final RemoteDnOrderService remoteDnOrderService;

	@Override
	public R cancelDn(DnCancellationDto dnCancellationDto) {
		if (!CommonConstants.COMPANY_CODE_SAIC.equals(dnCancellationDto.getClientCode())) {
			log.info("出库单取消不是{}客户", CommonConstants.COMPANY_CODE_SAIC);
			return R.failed(StrUtil.format("Customer: {} DN cancellation function is temporarily not supported",
					dnCancellationDto.getClientCode()));
		}
		DnOrderCancelDm dnOrderCancelDm = new DnOrderCancelDm();
		dnOrderCancelDm.setOrderNo(dnCancellationDto.getDnNo());
		R result = remoteDnOrderService.cancelDnOrder(dnOrderCancelDm, dnCancellationDto.getClientCode(),
				SecurityConstants.FROM_IN);

		if (result.getCode() == CommonConstants.SUCCESS) {
			return R.ok("", StrUtil.format("DN: {} has been cancelled successfully", dnCancellationDto.getDnNo()));
		}
		return result;
	}

}
