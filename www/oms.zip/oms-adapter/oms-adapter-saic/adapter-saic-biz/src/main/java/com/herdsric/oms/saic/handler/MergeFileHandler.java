package com.herdsric.oms.saic.handler;

import java.util.List;

public interface MergeFileHandler {

	void pushFileToSftp(List<String> type);

}
