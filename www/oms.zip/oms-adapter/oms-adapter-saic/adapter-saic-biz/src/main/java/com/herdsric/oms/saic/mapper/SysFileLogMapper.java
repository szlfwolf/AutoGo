package com.herdsric.oms.saic.mapper;

import com.herdsric.oms.common.mybatis.base.RootMapper;
import com.herdsric.oms.saic.entity.SysFileLog;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface SysFileLogMapper extends RootMapper<SysFileLog> {

}
