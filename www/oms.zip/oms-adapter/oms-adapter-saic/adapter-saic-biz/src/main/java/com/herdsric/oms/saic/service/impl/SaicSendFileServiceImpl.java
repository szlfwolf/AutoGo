package com.herdsric.oms.saic.service.impl;

import cn.hutool.core.convert.Convert;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.io.FileUtil;
import cn.hutool.core.util.IdUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.herdsric.oms.common.client.dn.domain.DnSplitDm;
import com.herdsric.oms.common.client.dn.domain.DnSplitLineDm;
import com.herdsric.oms.common.core.constant.CommonConstants;
import com.herdsric.oms.common.core.util.JsonMapper;
import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.saic.config.WmsProperties;
import com.herdsric.oms.saic.csv.*;
import com.herdsric.oms.saic.entity.InventoryInfo;
import com.herdsric.oms.saic.entity.SysFileLog;
import com.herdsric.oms.saic.enums.DirectionEnum;
import com.herdsric.oms.saic.enums.TypeEnum;
import com.herdsric.oms.saic.param.SearchInventoryParam;
import com.herdsric.oms.saic.service.SaicSendFileService;
import com.herdsric.oms.saic.service.SysFileLogService;
import com.herdsric.oms.saic.sftp.ShellProperties;
import com.herdsric.oms.saic.util.CsvUtils;
import com.herdsric.oms.saic.util.SaicConstants;
import com.herdsric.oms.saic.wmsapi.WmsHttpApi;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.jetbrains.annotations.NotNull;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class SaicSendFileServiceImpl implements SaicSendFileService {

	private final WmsHttpApi wmsHttpApi;

	private final SysFileLogService sysFileLogService;

	private final ShellProperties shellProperties;

	private final WmsProperties wmsProperties;

	@Override
	public void sendInventoryFile() {
		SearchInventoryParam searchInventoryParam = new SearchInventoryParam();
		searchInventoryParam.setCompanyCode(CommonConstants.COMPANY_CODE_SAIC);
		searchInventoryParam.setDamage("");
		searchInventoryParam.setAll(true);
		// EDI->wms返回库存分页查询数据
		String responseData = wmsHttpApi.sendPost(wmsProperties.url(WmsProperties.Method.INVENTORY_QUERY),
				searchInventoryParam, wmsProperties.generateApiKey(), IdUtil.simpleUUID());
		InventoryInfo inventoryInfo = JsonMapper.INSTANCE.fromJson(responseData, InventoryInfo.class);
		if (null != inventoryInfo && CollectionUtils.isNotEmpty(inventoryInfo.getData())) {
			log.info("==============记录上传的Inventory文件==============");
			List<StockDto> stockDtos = StockDto.convert(inventoryInfo.getData());
			LocalDateTime dateTime = LocalDateTime.now();
			generateFileAndLogByType(TypeEnum.SR, stockDtos, "", dateTime, false);
			log.info("==============发送库存文件结束===============");
		}
		else {
			log.info("发送InventoryFile出现异常");
		}
	}

	@Override
	@Transactional(rollbackFor = { Exception.class })
	public synchronized R sendPackingConfirmationFile(List<PkgHeadDto> pkgHeadDtoList, List<PkgLineDto> pkgLineDtoList,
			String dn) {
		LocalDateTime dateTime = LocalDateTime.now();
		generateFileAndLogByType(TypeEnum.PKG_P, pkgLineDtoList, dn, dateTime);
		generateFileAndLogByType(TypeEnum.PKG_H, pkgHeadDtoList, dn, dateTime);
		return R.ok();
	}

	@Override
	@Transactional(rollbackFor = { Exception.class })
	public R sendDispathConfirmationFile(GiDto giDto, String dn) {
		LocalDateTime dateTime = LocalDateTime.now();
		return generateFileAndLogByType(TypeEnum.GI, Arrays.asList(giDto), dn, dateTime);
	}

	@Override
	@Transactional(rollbackFor = { Exception.class })
	public R sendPodFile(PodDto podDto, String dn) {
		LocalDateTime dateTime = LocalDateTime.now();
		return generateFileAndLogByType(TypeEnum.POD, Arrays.asList(podDto), dn, dateTime);
	}

	@Override
	@Transactional(rollbackFor = { Exception.class })
	public R splitDn(DnSplitDm dnSplitDm) {
		LocalDateTime dateTime = LocalDateTime.now();

		List<List<String>> listDatas = new ArrayList<>();
		List<String> data = new ArrayList<>();
		data.add(dnSplitDm.getOrderNum());
		data.add(dnSplitDm.isSplit() ? "1" : "0");
		listDatas.add(data);
		if (dnSplitDm.isSplit()) {
			for (DnSplitLineDm subDnLine : dnSplitDm.getDnSplitLineDms()) {
				List<String> dataline = new ArrayList<>();
				dataline.add(SaicConstants.CSV_P);
				dataline.add(subDnLine.getDnNo());
				dataline.add(subDnLine.getLineNo());
				dataline.add(subDnLine.getPartNumber());
				dataline.add(String.valueOf(Convert.toInt(subDnLine.getNum())));

				dataline.add(Convert.toStr(subDnLine.getExtendProps().get(SaicConstants.poNumber), ""));
				dataline.add(Convert.toStr(subDnLine.getExtendProps().get(SaicConstants.orgItemCode), ""));

				listDatas.add(dataline);
			}
		}
		return generateFileAndLogByType(TypeEnum.SPLIT_DN, listDatas, dnSplitDm.getOrderNum(), dateTime);
	}

	@Override
	@Transactional(rollbackFor = { Exception.class })
	public R sendInboundResponseFile(List<GrDto> grDtos, String asnNo) {
		LocalDateTime dateTime = LocalDateTime.now();
		return generateFileAndLogByType(TypeEnum.GR, grDtos, asnNo, dateTime);
	}

	private R<?> generateFileAndLogByType(TypeEnum typeEnum, List<?> objs, String orderNum, LocalDateTime dateTime) {
		return generateFileAndLogByType(typeEnum, objs, orderNum, dateTime, true);
	}

	@NotNull
	private R<?> generateFileAndLogByType(TypeEnum typeEnum, List<?> objs, String orderNum, LocalDateTime dateTime,
			boolean check) {
		long start = System.currentTimeMillis();
		if (check) {
			List<SysFileLog> data = sysFileLogService.list(Wrappers.<SysFileLog>lambdaQuery()
					.eq(SysFileLog::getBatchNo, orderNum).eq(SysFileLog::getType, typeEnum));
			if (data.size() == 1) {
				log.warn("文件已经生成且上传无需再次上传asnNo:{},type:{}", orderNum, typeEnum);
				return R.ok();
			}
		}

		String fileName = typeEnum.generateFileName(orderNum, dateTime);
		ShellProperties.Config config = shellProperties.getConfig(typeEnum.name());
		String localPath = shellProperties.generateLocalPath(typeEnum.name());

		CsvUtils.writeCSVFile(localPath, fileName, objs);

		SysFileLog fileLog = new SysFileLog();
		fileLog.setSource(SaicConstants.OMS);
		fileLog.setTarget(CommonConstants.COMPANY_CODE_SAIC);
		fileLog.setBatchNo(StrUtil.isBlank(orderNum) ? fileName : orderNum);
		fileLog.setReference(StrUtil.isBlank(orderNum) ? fileName : orderNum);
		fileLog.setStatus(CommonConstants.N);
		fileLog.setDirection(DirectionEnum.OUT.name());
		fileLog.setSize(FileUtil.size(FileUtil.file(localPath + fileName)));
		fileLog.setMessage("文件生成成功");
		fileLog.setLastModifiedDate(DateUtil.now());
		fileLog.setRetryNum(0);
		fileLog.setCostTime(System.currentTimeMillis() - start);
		fileLog.setLocalName(fileName);
		fileLog.setLocalPath(localPath);
		fileLog.setName(fileName);
		fileLog.setPath(config.getRemotePath());
		fileLog.setType(typeEnum.name());

		sysFileLogService.save(fileLog);
		return R.ok();
	}

}
