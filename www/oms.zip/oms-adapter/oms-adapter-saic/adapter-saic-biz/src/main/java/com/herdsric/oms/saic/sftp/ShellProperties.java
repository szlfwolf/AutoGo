package com.herdsric.oms.saic.sftp;

import cn.hutool.core.util.StrUtil;
import com.herdsric.oms.common.core.exception.ErrorCodeEnum;
import com.herdsric.oms.common.core.exception.OmsBusinessException;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.time.LocalDate;
import java.util.Map;

@Data
@ConfigurationProperties(prefix = "saic.sftp")
public class ShellProperties {

	/**
	 * host 地址
	 */
	private String host = "127.0.0.1";

	/**
	 * 端口号
	 */
	private Integer port = 22;

	/**
	 * 用户名
	 */
	private String username = "";

	/**
	 * 密码
	 */
	private String password = "";

	private String strictHostKeyChecking = "no";

	private Integer timeout = 30000;

	private Integer incrementalConnections = 3;

	private Integer maxConnections = 10;

	private Map<String, Config> configMap;

	@Data
	public static class Config {

		private String direction;

		private String remotePath;

		private String remotePathBak;

		private String localPath;

		/**
		 * 下载时候的正则表达式
		 */
		private String regex;

	}

	public Config getConfig(String method) {
		if (this.getConfigMap() != null && this.getConfigMap().containsKey(method)) {
			return this.getConfigMap().get(method);
		}
		throw new OmsBusinessException(ErrorCodeEnum.E100001.code, StrUtil.format("SFTP {}配置缺失", method));
	}

	public String generateLocalPath(String method) {
		Config config = this.getConfig(method);
		return StrUtil.format(config.getLocalPath(), LocalDate.now(), method);

	}

}
