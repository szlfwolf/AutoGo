package com.herdsric.oms.saic;

import com.herdsric.oms.common.feign.annotation.EnableOmsFeignClients;
import com.herdsric.oms.common.job.annotation.EnableOmsXxlJob;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.scheduling.annotation.EnableAsync;

@EnableOmsXxlJob
@EnableOmsFeignClients
@EnableDiscoveryClient
@SpringBootApplication
@EnableAsync
public class AdapterSaicBizApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdapterSaicBizApplication.class, args);
	}

}
