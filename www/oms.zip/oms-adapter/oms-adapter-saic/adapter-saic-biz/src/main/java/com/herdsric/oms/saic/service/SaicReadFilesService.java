package com.herdsric.oms.saic.service;

public interface SaicReadFilesService {

	/**
	 * 文件下载，然后入库，解析到对应的库中
	 */
	void downloadFiles();

	void readSkuMasterData();

	void singleHandleAsn();

	void singleHandleDn();

	void retryAnalyzeFile();

}
