package com.herdsric.oms.saic.manages;

import cn.hutool.core.util.StrUtil;
import com.herdsric.oms.common.client.common.BaseDefine;
import com.herdsric.oms.common.core.constant.CommonConstants;

public class CommonDefine implements BaseDefine {

	@Override
	public boolean isSupport(String clientCode) {
		return StrUtil.equals(CommonConstants.COMPANY_CODE_SAIC, clientCode);
	}

}
