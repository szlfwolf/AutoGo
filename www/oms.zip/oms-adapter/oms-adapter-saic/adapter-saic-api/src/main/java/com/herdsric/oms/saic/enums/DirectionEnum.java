package com.herdsric.oms.saic.enums;

public enum DirectionEnum {

	IN, OUT;

}
