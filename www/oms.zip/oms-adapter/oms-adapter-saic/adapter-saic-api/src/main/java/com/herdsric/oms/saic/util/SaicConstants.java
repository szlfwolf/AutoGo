package com.herdsric.oms.saic.util;

public interface SaicConstants {

	String CSV_P = "P";

	String CSV_H = "H";

	String OMS = "OMS";

	// {"referenceNo":"r523452","orgItemCode":"10041514","poNumber":"4AXXX122A27"}
	String poNumber = "poNumber";

	String orgItemCode = "orgItemCode";

	String referenceNo = "referenceNo";

}
