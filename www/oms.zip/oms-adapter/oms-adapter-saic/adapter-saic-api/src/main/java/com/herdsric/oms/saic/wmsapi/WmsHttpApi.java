package com.herdsric.oms.saic.wmsapi;

import com.dtflys.forest.annotation.Body;
import com.dtflys.forest.annotation.Request;
import com.dtflys.forest.annotation.Var;
import org.springframework.stereotype.Component;

@Component
public interface WmsHttpApi<T> {

	@Request(url = "${requestUrl}", type = "POST", headers = { "Accept-Charset: UTF-8",
			"Content-Type: application/json", "trackNo: ${trackNo}", "apiKey: ${apiKey}" })
	String sendPost(@Var("requestUrl") String requestUrl, @Body T param, @Var("apiKey") String apiKey,
			@Var("trackNo") String trackNo);

}
