package com.herdsric.oms.saic.csv;

import com.herdsric.oms.common.client.dn.dto.DnOrderResponseDTO;
import com.herdsric.oms.saic.util.DateUtils;
import com.opencsv.bean.CsvBindByPosition;
import lombok.Data;

@Data
public class GiDto {

	@CsvBindByPosition(position = 0, required = true)
	private String outboundDispatchNumber;

	@CsvBindByPosition(position = 1, required = true)
	private String loadDate;

	@CsvBindByPosition(position = 2, required = true)
	private String freightLoadID;

	@CsvBindByPosition(position = 3, required = true)
	private String trackingNumber;

	public static GiDto convert(DnOrderResponseDTO dnOrderResponseDTO) {
		GiDto dto = new GiDto();
		dto.setOutboundDispatchNumber(dnOrderResponseDTO.getOrderNo());
		dto.setLoadDate(DateUtils.dateFormatChange(dnOrderResponseDTO.getPickUpTime()));
		dto.setFreightLoadID(dnOrderResponseDTO.getVehicleNo());
		dto.setTrackingNumber(dnOrderResponseDTO.getTrackingNumber());
		return dto;
	}

}
