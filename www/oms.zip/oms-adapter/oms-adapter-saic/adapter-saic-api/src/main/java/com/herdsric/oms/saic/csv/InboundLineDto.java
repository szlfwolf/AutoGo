package com.herdsric.oms.saic.csv;

import com.opencsv.bean.CsvBindByPosition;
import lombok.Data;

@Data
public class InboundLineDto {

	@CsvBindByPosition(position = 0, required = true)
	private String inboundAdviceNumber;

	@CsvBindByPosition(position = 1, required = true)
	private String inboundAdvicePosition;

	@CsvBindByPosition(position = 2, required = true)
	private String expectedArrivalDate;

	@CsvBindByPosition(position = 3, required = true)
	private String partNumber;

	@CsvBindByPosition(position = 4, required = true)
	private String quantity;

	@CsvBindByPosition(position = 5, required = true)
	private String unit;

	@CsvBindByPosition(position = 6, required = true)
	private String batch;

	@CsvBindByPosition(position = 7)
	private String containerNo;

	@CsvBindByPosition(position = 8)
	private String packageNo;

	@CsvBindByPosition(position = 9)
	private String packageType;

	@CsvBindByPosition(position = 10)
	private String variant;

}
