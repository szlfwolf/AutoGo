package com.herdsric.oms.saic.manages;

import cn.hutool.core.date.DateUtil;
import com.herdsric.oms.common.client.dn.DnBizDefine;
import com.herdsric.oms.common.client.dn.domain.DnOrderCancelDm;
import com.herdsric.oms.common.client.dn.domain.DnOrderDm;
import com.herdsric.oms.common.client.dn.domain.OrderLineDm;
import com.herdsric.oms.common.client.dn.dto.DnOrderResponseDTO;
import com.herdsric.oms.common.client.dn.dto.DnSplitDTO;
import com.herdsric.oms.common.client.dn.function.DnOptionFlag;
import com.herdsric.oms.common.client.dn.handle.DnOrderSplitFunction;
import com.herdsric.oms.common.client.dn.handle.SplitStrategy;
import com.herdsric.oms.common.client.dn.process.DnOrderProcessor;
import com.herdsric.oms.common.client.enums.SyncEnum;
import com.herdsric.oms.common.core.util.SpringContextHolder;
import com.herdsric.oms.common.security.util.SecurityUtils;
import com.herdsric.oms.common.webhook.CallbackHttpDefine;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.function.Function;

@Slf4j
@RequiredArgsConstructor
public class DnOrderManage extends CommonDefine implements DnBizDefine {

	@Override
	public void save(DnOrderDm dnOrderDm) {
		DnOrderSplitFunction dnOrderSplitFunction = SplitStrategy.getStrategyFunction(dnOrderDm.getTypeEnum());
		dnOrderSplitFunction.preHandle(SecurityUtils.getTokenSupportClient(), dnOrderDm);
	}

	@Override
	public void dnOrderResponseByWebhook(String clientCode, String type, String batchNo) {
		DnOrderProcessor dnOrderProcessor = SpringContextHolder.getBean(DnOrderProcessor.class);
		CallbackHttpDefine callbackHttpDefine = SpringContextHolder.getBean(CallbackHttpDefine.class);
		Function<DnOptionFlag, Function<DnOrderResponseDTO, Boolean>> function = x -> {
			switch (x) {
				case Manual:
					return dm -> {
						log.info("{},BatchNo:{},dnOrder:{} 手动上传订单，不需要反馈", clientCode, batchNo, dm.getOrderNo());
						return false;
					};
				case Cancelled:
					return dm -> {
						List<OrderLineDm> orderLines = dm.getOrderLines();
						for (OrderLineDm orderLineDm : orderLines) {
							// 仓库整单无库存，业务指定打包号为 NPNO20230515
							orderLineDm.setBoxNo("NPNO20230515");
							orderLineDm.setCbm("0");
							orderLineDm.setWeight("0");
							orderLineDm.setNetWeight("0");
							orderLineDm.setLength("0");
							orderLineDm.setWidth("0");
							orderLineDm.setHeight("0");
							orderLineDm.setPackageType("PACL");
							orderLineDm.setPackageTime(DateUtil.now());
						}
						// 对象处理,特色业务逻辑
						callbackHttpDefine.execute(true, clientCode, dm.getWarehouseCode(), dm.getOrderNo(), dm, type,
								true);
						return true;
					};
				case Packed:
				case PickUp:
				case Delivery:
					return dm -> {
						// 对象处理,特色业务逻辑
						callbackHttpDefine.execute(true, clientCode, dm.getWarehouseCode(), dm.getOrderNo(), dm, type,
								true);
						return true;
					};
				default:
					return dm -> {
						// 其他情况不需要反馈
						return true;
					};
			}
		};
		dnOrderProcessor.dnOrderResponse(clientCode, type, batchNo, function);
	}

	@Override
	public void cancelDnOrder(String clientCode, DnOrderCancelDm dnOrderCancelDm) {
		DnOrderProcessor dnOrderProcessor = SpringContextHolder.getBean(DnOrderProcessor.class);
		dnOrderProcessor.dnOrderCancel(clientCode, dnOrderCancelDm);
	}

	public void dnOrderCancelByWebhook(String clientCode, String batchNo) {
		DnOrderProcessor dnOrderProcessor = SpringContextHolder.getBean(DnOrderProcessor.class);
		CallbackHttpDefine callbackHttpDefine = SpringContextHolder.getBean(CallbackHttpDefine.class);
		Function<DnOptionFlag, Function<DnOrderResponseDTO, Boolean>> function = x -> {
			switch (x) {
				case Manual:
					return dm -> {
						log.info("{},BatchNo:{},dnOrder:{} 手动上传订单，不需要反馈", clientCode, batchNo, dm.getOrderNo());
						return false;
					};

				case Cancelled:
					return dm -> {
						List<OrderLineDm> orderLines = dm.getOrderLines();
						for (OrderLineDm orderLineDm : orderLines) {
							// 仓库取消，业务指定打包号为 CPNO20230515
							orderLineDm.setBoxNo("CPNO20230515");
							orderLineDm.setCbm("0");
							orderLineDm.setWeight("0");
							orderLineDm.setNetWeight("0");
							orderLineDm.setLength("0");
							orderLineDm.setWidth("0");
							orderLineDm.setHeight("0");
							orderLineDm.setPackageType("PACL");
							orderLineDm.setPackageTime(DateUtil.now());
						}
						callbackHttpDefine.execute(true, clientCode, dm.getWarehouseCode(), dm.getOrderNo(), dm,
								SyncEnum.DN_ORDER_CANCEL_SYNC.name(), true);
						return true;
					};
				default:
					return dm -> {
						// 其他情况不需要反馈
						return true;
					};
			}
		};
		dnOrderProcessor.dnOrderCancelByWebhook(clientCode, batchNo, function);
	}

	public void dnSplitResponseByWebhook(String clientCode, String type, String orderNum, List<String> dnNums) {

		Function<DnOptionFlag, Function<DnSplitDTO, Boolean>> function = x -> {
			switch (x) {
				case Manual:
					return dm -> {
						log.info("{},orderNum:{},dnNums:{} 手动上传订单，不需要拆单反馈", clientCode, orderNum, dnNums);
						return false;
					};
				default:
					return dm -> {
						// 其他情况正常走标准逻辑反馈客户
						return true;
					};
			}
		};

		DnOrderProcessor dnOrderProcessor = SpringContextHolder.getBean(DnOrderProcessor.class);
		dnOrderProcessor.dnSplitResponseByWebhook(clientCode, type, orderNum, dnNums, function);
	}

}
