package com.herdsric.oms.saic.enums;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.herdsric.oms.common.client.dn.domain.DnSplitDm;
import com.herdsric.oms.saic.csv.*;

import java.time.LocalDateTime;
import java.util.Arrays;

public enum TypeEnum {

	/**
	 * MM_YYYYMMDD_HHMMSS.csv
	 */

	SKU("SKU", "SKU", "MM_{}_{}.csv", DirectionEnum.IN, SkuDto.class),

	/**
	 * ASN_P/H_YYYYMMDD_HHMMSS.csv
	 */
	INBOUND_P("AsnOrder", "INBOUND", "ASN_P_{}_{}.csv", DirectionEnum.IN, InboundLineDto.class),
	INBOUND_H("AsnOrder", "INBOUND", "ASN_H_{}_{}.csv", DirectionEnum.IN, InboundHeadDto.class),
	/**
	 * GR_{Inbound}_YYYYMMDD_HHMMSS.csv
	 */
	GR("AsnOrder", "FeedBack", "GR_{}_{}_{}.csv", DirectionEnum.OUT, GrDto.class),
	/**
	 * DN_P/H_YYYYMMDD_HHMMSS.csv
	 */
	OUTBOUND_P("DnOrder", "OUTBOUND", "DN_P_{}_{}.csv", DirectionEnum.IN, OutboundLineDto.class),
	OUTBOUND_H("DnOrder", "OUTBOUND", "DN_H_{}_{}.csv", DirectionEnum.IN, OutboundHeadDto.class),
	/**
	 * DN_{Outbound}_YYYYMMDD_HHMMSS.csv
	 */
	SPLIT_DN("DnOrder", "dnSplit", "DN_{}_{}_{}.csv", DirectionEnum.OUT, DnSplitDm.class),

	/**
	 * PKG_H_{Outbound}_YYYYMMDD_HHMMSS.csv PKG_P_{Outbound}_YYYYMMDD_HHMMSS.csv
	 */
	PKG_P("DnOrder", "Packaged", "PKG_P_{}_{}_{}.csv", DirectionEnum.OUT, PkgLineDto.class),
	PKG_H("DnOrder", "Packaged", "PKG_H_{}_{}_{}.csv", DirectionEnum.OUT, PkgHeadDto.class),
	/**
	 * GI_{Outbound}_YYYYMMDD_HHMMSS.csv
	 */
	GI("DnOrder", "Outbound", "GI_{}_{}_{}.csv", DirectionEnum.OUT, GiDto.class),
	/**
	 * POD_{Outbound}_YYYYMMDD_HHMMSS.csv
	 */
	POD("DnOrder", "Pod", "POD_{}_{}_{}.csv", DirectionEnum.OUT, PodDto.class),
	/**
	 * SR_YYYYMMDD_HHMMSS.csv
	 */
	SR("InventoryRecon", "Stock", "SR_{}_{}.csv", DirectionEnum.OUT, null);

	public String bizType;

	public String bizSubType;

	public String nameFormat;

	public DirectionEnum direction;

	public Class clazz;

	TypeEnum(String bizType, String bizSubType, String nameFormat, DirectionEnum direction, Class clazz) {
		this.bizType = bizType;
		this.bizSubType = bizSubType;
		this.nameFormat = nameFormat;
		this.direction = direction;
		this.clazz = clazz;
	}

	public static TypeEnum instance(String key) {
		return Arrays.stream(TypeEnum.values()).filter(x -> x.name().equals(key)).findAny()
				.orElseThrow(() -> new IllegalArgumentException("Invalid key: " + key));
	}

	public String generateFileName(String orderNum, LocalDateTime dateTime) {
		String dateStr = DateUtil.format(dateTime, "yyyyMMdd");
		String timeStr = DateUtil.format(dateTime, "HHmmss");
		if (StrUtil.isNotBlank(orderNum)) {
			return StrUtil.format(nameFormat, orderNum, dateStr, timeStr);
		}

		return StrUtil.format(nameFormat, dateStr, timeStr);
	}

	public static String getReference(Object obj) {
		if (obj instanceof SkuDto)
			return ((SkuDto) obj).getPartNumber();
		if (obj instanceof InboundHeadDto)
			return ((InboundHeadDto) obj).getInboundAdviceNumber();
		if (obj instanceof InboundLineDto)
			return ((InboundLineDto) obj).getInboundAdviceNumber();
		if (obj instanceof GrDto)
			return ((GrDto) obj).getInboundAdviceNumber();
		if (obj instanceof OutboundHeadDto)
			return ((OutboundHeadDto) obj).getOutboundDispatchNumber();
		if (obj instanceof OutboundLineDto)
			return ((OutboundLineDto) obj).getOutboundDispatchNumber();
		if (obj instanceof DnSplitDm)
			return ((DnSplitDm) obj).getOrderNum();
		if (obj instanceof PkgHeadDto)
			return ((PkgHeadDto) obj).getOutboundDispatchNumber();
		if (obj instanceof PkgLineDto)
			return ((PkgLineDto) obj).getOutboundDispatchNumber();
		if (obj instanceof GiDto)
			return ((GiDto) obj).getOutboundDispatchNumber();
		if (obj instanceof PodDto)
			return ((PodDto) obj).getOutboundDispatchNumber();

		return null;
	}

}
