package com.herdsric.oms.saic.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.herdsric.oms.common.mybatis.base.LogicDelBaseEntity;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@TableName("sys_trace_log")
@EqualsAndHashCode(callSuper = true)
@Schema(description = "文件处理日志表")
public class TraceLog extends LogicDelBaseEntity {

	@TableId(type = IdType.AUTO)
	private Integer id;

	private String reference;

	private String type;

	private String msgIn;

	private String msgOut;

	private String message;

	private String source;

	private String target;

	private String status;

	private int retryNum;

	@TableField(exist = false)
	private TraceLog lTraceLog;

}
