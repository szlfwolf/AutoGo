package com.herdsric.oms.saic.param;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.Data;

@Data
public class SearchInventoryParam {

	private Integer id;

	private String class1;

	private String companyCode;

	private String code;

	private String name;

	private Integer pageNo;

	@JSONField(name = "PageCount")
	private Integer PageCount;

	@JSONField(name = "Damage")
	private String Damage;

	private String isHazardous;

	private Boolean all;

}
