package com.herdsric.oms.saic.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class DnCancellationDto {

	@NotBlank(message = "clientCode cannot be empty")
	private String clientCode;

	@NotBlank(message = "dnNo cannot be empty")
	private String dnNo;

	public void check() {
	}

}
