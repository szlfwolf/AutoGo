package com.herdsric.oms.saic.csv;

import com.herdsric.oms.common.client.dn.dto.DnOrderResponseDTO;
import com.herdsric.oms.saic.util.DateUtils;
import com.opencsv.bean.CsvBindByPosition;
import lombok.Data;

@Data
public class PodDto {

	@CsvBindByPosition(position = 0, required = true)
	private String outboundDispatchNumber;

	@CsvBindByPosition(position = 1, required = true)
	private String timeOfReceipt;

	public static PodDto convert(DnOrderResponseDTO dnOrderResponseDTO) {
		PodDto podDto = new PodDto();
		podDto.setOutboundDispatchNumber(dnOrderResponseDTO.getOrderNo());
		podDto.setTimeOfReceipt(DateUtils.dateFormatChange(dnOrderResponseDTO.getPodTime()));
		return podDto;
	}

}
