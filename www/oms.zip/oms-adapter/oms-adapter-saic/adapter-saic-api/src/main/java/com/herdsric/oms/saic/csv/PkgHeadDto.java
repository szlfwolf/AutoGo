package com.herdsric.oms.saic.csv;

import cn.hutool.core.convert.Convert;
import com.herdsric.oms.common.client.dn.domain.OrderLineDm;
import com.herdsric.oms.common.client.dn.dto.DnOrderResponseDTO;
import com.opencsv.bean.CsvBindByPosition;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class PkgHeadDto {

	@CsvBindByPosition(position = 0, required = true)
	private String outboundDispatchNumber;

	@CsvBindByPosition(position = 1, required = true)
	private String packageNumber;

	/**
	 * kg
	 */
	@CsvBindByPosition(position = 2, required = true)
	private String netWeight;

	/**
	 * kg
	 */
	@CsvBindByPosition(position = 3, required = true)
	private String grossWeight;

	/**
	 * mm
	 */
	@CsvBindByPosition(position = 4, required = true)
	private String length;

	/**
	 * mm
	 */
	@CsvBindByPosition(position = 5, required = true)
	private String width;

	/**
	 * mm
	 */
	@CsvBindByPosition(position = 6, required = true)
	private String height;

	/**
	 * m³
	 */
	@CsvBindByPosition(position = 7, required = true)
	private String cbm;

	public static List<PkgHeadDto> convert(DnOrderResponseDTO dnOrderResponseDTO) {
		List<PkgHeadDto> pkgHeadDtoList = new ArrayList<>();
		List<String> packageNumbers = new ArrayList<>();
		for (OrderLineDm orderLineDm : dnOrderResponseDTO.getOrderLines()) {
			if (packageNumbers.contains(orderLineDm.getBoxNo())) {
				continue;
			}
			packageNumbers.add(orderLineDm.getBoxNo());
			PkgHeadDto pkgHeadDto = new PkgHeadDto();
			pkgHeadDto.setOutboundDispatchNumber(dnOrderResponseDTO.getOrderNo());
			pkgHeadDto.setPackageNumber(orderLineDm.getBoxNo());
			pkgHeadDto.setNetWeight(orderLineDm.getNetWeight());
			pkgHeadDto.setGrossWeight(orderLineDm.getWeight());
			/**
			 * convert m to mm WMS 下发单位 m, 需转换为 mm 反馈客户
			 */
			pkgHeadDto.setLength(String.valueOf(Convert.toDouble(orderLineDm.getLength(), 0D) * 1000));
			pkgHeadDto.setWidth(String.valueOf(Convert.toDouble(orderLineDm.getWidth(), 0D) * 1000));
			pkgHeadDto.setHeight(String.valueOf(Convert.toDouble(orderLineDm.getHeight(), 0D) * 1000));
			pkgHeadDto.setCbm(orderLineDm.getCbm());
			pkgHeadDtoList.add(pkgHeadDto);
		}
		return pkgHeadDtoList;
	}

}
