package com.herdsric.oms.saic.entity;

import com.herdsric.oms.common.client.masterdata.domain.SkuDm;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class SaicSkuDatabase {

	private static final long serialVersionUID = 1L;

	private String clientCode;

	private String brand;

	private String supplierCode;

	private String supplierName;

	private String partNumber;

	private String nameCn;

	private String nameEn;

	private String partDesc;

	private String status;

	private String isDangerous;

	private String stackAllowed;

	private String sellingPrice;

	private String purchasPrice;

	private String monetaryUnit;

	private String ean;

	private String unit;

	private String packUp;

	private String hd;

	private String carModel;

	private String partType1;

	private String partType2;

	private String partType3;

	private String partType4;

	private String partType5;

	private String productGroup;

	private String materialGroup;

	private String originalSite;

	private String storageType;

	private String capacity;

	private String attribute;

	private String halfYearlyType;

	private String weeklyType;

	private String vmWarehouseCode;

	private String type;

	private String length;

	private String width;

	private String height;

	private String grossWeight;

	private String netWeight;

	private String moq;

	public static List<SkuDm> convert(List<SaicSkuDatabase> saicSkuDatabases) {
		List<SkuDm> skuDms = new ArrayList<>();
		saicSkuDatabases.forEach(x -> {
			SkuDm skuDm = new SkuDm();
			skuDm.setBrand(x.getBrand());
			skuDm.setPartNumber(x.getPartNumber());
			skuDm.setNameCn(x.getNameCn());
			skuDm.setNameEn(x.getNameEn());
			skuDm.setPartDesc(x.getPartDesc());
			skuDm.setIsDangerous(x.getIsDangerous());
			skuDm.setIsStackAllowed(x.getStackAllowed() == null ? "0" : "1");
			skuDm.setProductGroup(x.getProductGroup());
			skuDm.setMaterialGroup(x.getMaterialGroup());
			ArrayList<SkuDm.PackageUnit> packageUnits = new ArrayList<>();
			SkuDm.PackageUnit packageUnit = new SkuDm.PackageUnit();
			packageUnit.setType("1");
			packageUnit.setLength(x.getLength());
			packageUnit.setWidth(x.getWidth());
			packageUnit.setHeight(x.getHeight());
			packageUnit.setGrossWeight(x.getGrossWeight());
			packageUnit.setNetWeight(x.getNetWeight());
			packageUnit.setMoq(x.getMoq());
			packageUnit.setUnit(x.getUnit());
			packageUnits.add(packageUnit);
			skuDm.setPackageList(packageUnits);
			skuDms.add(skuDm);
		});
		return skuDms;
	}

}
