package com.herdsric.oms.saic.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.herdsric.oms.common.mybatis.base.LogicDelBaseEntity;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@TableName("sys_file_log")
@EqualsAndHashCode(callSuper = true)
@Schema(description = "文件处理日志表")
public class SysFileLog extends LogicDelBaseEntity {

	/**
	 * id
	 */
	@TableId(type = IdType.AUTO)
	private Integer id;

	/**
	 * 来源
	 */
	private String source;

	/**
	 * 目的
	 */
	private String target;

	/**
	 * msg_reference
	 */
	private String reference;

	/**
	 * 批次，批量上传下载
	 */
	private String batchNo;

	/**
	 * 本地服务器路径
	 */
	private String localPath;

	/**
	 * 本地服务器文件名称
	 */
	private String localName;

	/**
	 * 路径
	 */
	private String path;

	/**
	 * 文件名称
	 */
	private String name;

	/**
	 * 业务类型
	 */
	private String type;

	/**
	 * 操作状态
	 */
	private String status;

	/**
	 * 方向：OUT-上传/IN-下载
	 */
	private String direction;

	/**
	 * 文件最新修改时间
	 */
	private String lastModifiedDate;

	/**
	 * 消息
	 */
	private String message;

	/**
	 * 耗时（ms）
	 */
	private long costTime;

	/**
	 * 重试次数
	 */
	private int retryNum;

	/**
	 * 文件大小
	 */
	private long size;

}
