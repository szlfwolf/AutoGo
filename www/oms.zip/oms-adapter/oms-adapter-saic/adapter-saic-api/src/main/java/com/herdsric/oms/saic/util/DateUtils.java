package com.herdsric.oms.saic.util;

import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateUtil;

public class DateUtils {

	public static String dateFormatChange(String dateStr, String oldFormat, String newFormat) {
		return DateUtil.format(DateUtil.parse(dateStr, oldFormat), newFormat);
	}

	/**
	 * yyyy-MM-dd HH:mm:ss yyyyMMddHHmmss
	 * @param dateStr
	 * @return
	 */

	public static String dateFormatChange(String dateStr) {
		return dateFormatChange(dateStr, DatePattern.NORM_DATETIME_PATTERN, DatePattern.PURE_DATETIME_PATTERN);
	}

}
