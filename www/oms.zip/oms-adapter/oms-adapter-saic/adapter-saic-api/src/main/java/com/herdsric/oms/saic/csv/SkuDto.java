package com.herdsric.oms.saic.csv;

import cn.hutool.core.convert.Convert;
import cn.hutool.core.util.StrUtil;
import com.herdsric.oms.common.client.masterdata.domain.SkuDm;
import com.opencsv.bean.CsvBindByPosition;
import lombok.Data;

import java.util.ArrayList;

@Data
public class SkuDto {

	@CsvBindByPosition(position = 0)
	private String brand;

	@CsvBindByPosition(position = 1, required = true)
	private String partNumber;

	@CsvBindByPosition(position = 2)
	private String partDescription;

	@CsvBindByPosition(position = 3)
	private String partDescription2;

	@CsvBindByPosition(position = 4)
	private String partDescription3;

	@CsvBindByPosition(position = 5, required = true)
	private String quantityUnit;

	@CsvBindByPosition(position = 6, required = true)
	private String length;

	@CsvBindByPosition(position = 7, required = true)
	private String width;

	@CsvBindByPosition(position = 8, required = true)
	private String height;

	@CsvBindByPosition(position = 9, required = true)
	private String grossWeight;

	@CsvBindByPosition(position = 10)
	private String netWeight;

	@CsvBindByPosition(position = 11)
	private String dangerous;

	@CsvBindByPosition(position = 12, required = true)
	private String moq;

	@CsvBindByPosition(position = 13)
	private String packageType;

	@CsvBindByPosition(position = 14)
	private String stackAllowed;

	@CsvBindByPosition(position = 15)
	private String productGroup;

	@CsvBindByPosition(position = 16)
	private String materialGroup;

	public static SkuDm toSkuDm(SkuDto skuDto) {
		SkuDm skuDm = new SkuDm();
		skuDm.setBrand(skuDto.getBrand());
		skuDm.setPartNumber(skuDto.getPartNumber());
		skuDm.setNameCn(skuDto.getPartDescription());
		skuDm.setNameEn(skuDto.getPartDescription());
		skuDm.setPartDesc(
				StrUtil.isBlank(skuDto.getPartDescription()) ? skuDm.getPartNumber() : skuDto.getPartDescription());
		skuDm.setPartType1(skuDto.getPartDescription2());
		skuDm.setPartType2(skuDto.getPartDescription3());
		skuDm.setPartType3(skuDto.getProductGroup());
		skuDm.setPartType4(skuDto.getMaterialGroup());
		skuDm.setIsDangerous(StrUtil.equals(skuDto.getDangerous(), "DG") ? "1" : "0");
		skuDm.setIsStackAllowed((skuDto.getStackAllowed() == null || skuDto.getStackAllowed().isEmpty()) ? "0" : "1");

		ArrayList<SkuDm.PackageUnit> packageUnits = new ArrayList<>();
		SkuDm.PackageUnit packageUnit = new SkuDm.PackageUnit();
		packageUnit.setType("1");
		packageUnit.setLength(skuDto.getLength());
		packageUnit.setWidth(skuDto.getWidth());
		packageUnit.setHeight(skuDto.getHeight());
		packageUnit.setGrossWeight(skuDto.getGrossWeight());
		packageUnit.setNetWeight(Convert.toStr(skuDto.getNetWeight(), "0"));
		packageUnit.setMoq(skuDto.getMoq());
		packageUnit.setUnit(skuDto.getQuantityUnit());
		packageUnits.add(packageUnit);
		skuDm.setPackageList(packageUnits);
		return skuDm;
	}

}
