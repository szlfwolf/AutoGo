package com.herdsric.oms.saic.entity;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class InventoryInfo implements Serializable {

	private List<DataInfo> data;

	private Pagination pagination;

	@Data
	public static class Pagination {

		// 总数据量
		private Long total;

		// 当前页最大展示数
		@JSONField(name = "PageCount")
		private Long PageCount;

		// 当前页码
		@JSONField(name = "pageNo")
		private Long pageNo;

	}

	@Data
	public static class DataInfo {

		private Integer id;

		// 库存状态/是否破损
		private String inventoryStatus;

		// 货主编码
		private String companyCode;

		// 货品编码
		private String code;

		// 货品名称
		private String name;

		// 货品大类
		private String class1;

		// 是否危险品
		private Integer isHazardous;

		// 扩展字段1
		private String itemExtendedField1;

		// 扩展字段2
		private String itemExtendedField2;

		// 扩展字段3
		private String itemExtendedField3;

		// 包装单位
		private String unit;

		// 件装量
		private Integer convertFigure;

		// 长
		private Double length;

		// 宽
		private Double width;

		// ⾼高
		private Double height;

		// 毛重
		private Double weight;

		// 净重
		private Double netweight;

		// 扩展字段1
		private String unitExtendedField1;

		// 扩展字段2
		private String unitExtendedField2;

		// 扩展字段3
		private String unitExtendedField3;

		// 数量
		private Integer qty;

	}

}
