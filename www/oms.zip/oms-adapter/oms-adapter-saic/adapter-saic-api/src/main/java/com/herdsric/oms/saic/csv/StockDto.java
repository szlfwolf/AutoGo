package com.herdsric.oms.saic.csv;

import cn.hutool.core.util.StrUtil;
import com.herdsric.oms.saic.entity.InventoryInfo;
import com.opencsv.bean.CsvBindByPosition;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class StockDto {

	/**
	 * Brand (MG or MX)
	 */
	@CsvBindByPosition(position = 0, required = true)
	private String brand;

	@CsvBindByPosition(position = 1, required = true)
	private String partNumber;

	@CsvBindByPosition(position = 2, required = true)
	private String quantity;

	@CsvBindByPosition(position = 3, required = true)
	private String unit;

	@CsvBindByPosition(position = 4)
	private String qualityCode;

	/**
	 * “R”=Rack, "S"=Shelf
	 */
	@CsvBindByPosition(position = 5, required = true)
	private String storageType;

	public static List<StockDto> convert(List<InventoryInfo.DataInfo> data) {
		List<StockDto> sendDataList = new ArrayList<>();
		data.stream().forEach(x -> {

			String unit = StrUtil.isBlank(x.getUnit()) || StrUtil.equals(x.getUnit(), "null") ? ""
					: (StrUtil.equals(x.getUnit(), "EA") ? "PCE" : x.getUnit());
			String qualityCode = StrUtil.equals(x.getInventoryStatus(), "合格") ? "" : "Q";
			String brand = StrUtil.isBlank(x.getItemExtendedField2())
					|| StrUtil.equals(x.getItemExtendedField2(), "null") ? "" : x.getItemExtendedField2();
			String skuCode = StrUtil.isBlank(x.getCode()) || StrUtil.equals(x.getCode(), "null") ? "" : x.getCode();
			String qty = x.getQty() == null ? "0" : x.getQty().toString();

			if (StrUtil.isAllBlank(brand, skuCode, unit)) {
				// 过滤掉空的数据
				return;
			}
			StockDto stockDto = new StockDto();
			stockDto.setBrand(brand);
			stockDto.setPartNumber(skuCode);
			stockDto.setQuantity(qty);
			stockDto.setUnit(unit);
			stockDto.setQualityCode(qualityCode);
			stockDto.setStorageType("S");
			sendDataList.add(stockDto);
		});

		return sendDataList;
	}

}
