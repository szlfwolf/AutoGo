package com.herdsric.oms.saic.csv;

import com.herdsric.oms.common.client.dn.domain.OrderLineDm;
import com.herdsric.oms.common.client.dn.dto.DnOrderResponseDTO;
import com.herdsric.oms.saic.util.DateUtils;
import com.opencsv.bean.CsvBindByPosition;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class PkgLineDto {

	@CsvBindByPosition(position = 0, required = true)
	private String outboundDispatchNumber;

	@CsvBindByPosition(position = 1, required = true)
	private String outboundDispatchPosition;

	@CsvBindByPosition(position = 2, required = true)
	private String partNumber;

	@CsvBindByPosition(position = 3, required = true)
	private String quantity;

	@CsvBindByPosition(position = 4, required = true)
	private String quantityUnit;

	@CsvBindByPosition(position = 5, required = true)
	private String packedDate;

	@CsvBindByPosition(position = 6, required = true)
	private String packageNumber;

	@CsvBindByPosition(position = 7, required = true)
	private String packageType;

	@CsvBindByPosition(position = 8, required = true)
	private String pickFrom;

	public static List<PkgLineDto> convert(DnOrderResponseDTO dnOrderResponseDTO) {
		List<PkgLineDto> pkgLineDtoList = new ArrayList<>();
		for (OrderLineDm orderLineDm : dnOrderResponseDTO.getOrderLines()) {
			PkgLineDto pkgLineDto = new PkgLineDto();
			pkgLineDto.setOutboundDispatchNumber(dnOrderResponseDTO.getOrderNo());
			pkgLineDto.setOutboundDispatchPosition(orderLineDm.getLineNo());
			pkgLineDto.setPartNumber(orderLineDm.getPartNumber());
			pkgLineDto.setQuantity(orderLineDm.getQty());
			pkgLineDto.setQuantityUnit(orderLineDm.getUnit());
			pkgLineDto.setPackedDate(DateUtils.dateFormatChange(orderLineDm.getPackageTime()));
			pkgLineDto.setPackageNumber(orderLineDm.getBoxNo());
			pkgLineDto.setPackageType(orderLineDm.getPackageType());
			pkgLineDto.setPickFrom("R");
			pkgLineDtoList.add(pkgLineDto);
		}
		return pkgLineDtoList;
	}

}
