package com.herdsric.oms.saic.util;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.io.FileUtil;
import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.opencsv.bean.*;
import com.opencsv.exceptions.CsvDataTypeMismatchException;
import com.opencsv.exceptions.CsvRequiredFieldEmptyException;

import java.io.*;
import java.util.List;

public class CsvUtils {

	/**
	 * csv文件导入并转为java对象
	 * @param fileName
	 * @param clazz
	 * @param <T>
	 * @return
	 */
	public static <T> List<T> readCSVFile(String fileName, Class<T> clazz) {
		try {
			FileReader reader = new FileReader(fileName);
			CSVReader csvReader = new CSVReader(reader);

			HeaderColumnNameMappingStrategy<T> strategy = new HeaderColumnNameMappingStrategy<>();
			strategy.setType(clazz);

			CsvToBean<T> csvToBean = new CsvToBeanBuilder<T>(csvReader).withType(clazz).build();

			return csvToBean.parse();

		}
		catch (FileNotFoundException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * 将java对象转为csv文件导出
	 * @param fileName
	 * @param list
	 * @param <T>
	 * @return
	 */
	public static <T> void writeCSVFile(String path, String fileName, List<T> list) {

		if (list.get(0) instanceof List) {
			_writeCSVFileList(path, fileName, (List<List<T>>) list);
		}
		else {
			_writeCSVFileBean(path, fileName, list);
		}
	}

	private static <T> void _writeCSVFileBean(String path, String fileName, List<T> list) {
		if (CollectionUtil.isEmpty(list)) {
			return;
		}
		try {
			File file = FileUtil.file(path);
			if (!file.exists()) {
				file.mkdirs();
			}
			FileWriter writer = new FileWriter(path + fileName);
			StatefulBeanToCsv<T> beanToCsv = new StatefulBeanToCsvBuilder<T>(writer).withOrderedResults(false).build();
			beanToCsv.write(list);
			writer.flush();
			writer.close();
		}
		catch (FileNotFoundException e) {
			throw new RuntimeException(e);
		}
		catch (CsvRequiredFieldEmptyException e) {
			throw new RuntimeException(e);
		}
		catch (CsvDataTypeMismatchException e) {
			throw new RuntimeException(e);
		}
		catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	private static <T> void _writeCSVFileList(String path, String fileName, List<List<T>> dataList) {
		if (CollectionUtil.isEmpty(dataList)) {
			return;
		}
		try {
			File file = FileUtil.file(path);
			if (!file.exists()) {
				file.mkdirs();
			}
			FileWriter fileWriter = new FileWriter(path + fileName);
			CSVWriter writer = new CSVWriter(fileWriter);
			for (List<T> ts : dataList) {
				writer.writeNext(ts.toArray(new String[0]));
			}
			writer.flush();
			writer.close();
		}
		catch (FileNotFoundException e) {
			throw new RuntimeException(e);
		}
		catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

}