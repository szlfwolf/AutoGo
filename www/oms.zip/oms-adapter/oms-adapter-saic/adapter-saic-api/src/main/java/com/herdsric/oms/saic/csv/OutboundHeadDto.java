package com.herdsric.oms.saic.csv;

import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.fasterxml.jackson.core.type.TypeReference;
import com.herdsric.oms.common.client.dn.domain.DnOrderDm;
import com.herdsric.oms.common.client.dn.enums.OrderSplitTypeEnum;
import com.herdsric.oms.common.client.enums.PfepTypeEnum;
import com.herdsric.oms.common.core.util.JsonMapper;
import com.herdsric.oms.saic.util.SaicConstants;
import com.opencsv.bean.CsvBindByPosition;
import lombok.Data;

import java.util.*;

@Data
public class OutboundHeadDto {

	@CsvBindByPosition(position = 0, required = true)
	private String outboundDispatchNumber;

	@CsvBindByPosition(position = 1)
	private String shippingType;

	@CsvBindByPosition(position = 2, required = true)
	private String orderType;

	@CsvBindByPosition(position = 3)
	private String expectedDeliveryDate;

	@CsvBindByPosition(position = 4, required = true)
	private String customerNumber;

	@CsvBindByPosition(position = 5, required = true)
	private String consignee1;

	@CsvBindByPosition(position = 6)
	private String consignee2;

	@CsvBindByPosition(position = 7, required = true)
	private String address;

	@CsvBindByPosition(position = 8, required = true)
	private String zipCode;

	@CsvBindByPosition(position = 9, required = true)
	private String cityName;

	@CsvBindByPosition(position = 10, required = true)
	private String countryCode;

	@CsvBindByPosition(position = 11, required = true)
	private String contactNumber;

	@CsvBindByPosition(position = 12)
	private String contactEmail;

	@CsvBindByPosition(position = 13, required = true)
	private String dnDate;

	public static DnOrderDm toDnOrderDm(String msgIn, String lMsgIn) {

		OutboundHeadDto outboundHeadDto = JsonMapper.INSTANCE.fromJson(msgIn, OutboundHeadDto.class);
		DnOrderDm dnOrderDm = new DnOrderDm();
		dnOrderDm.setOrderNo(outboundHeadDto.getOutboundDispatchNumber());
		dnOrderDm.setOrderType(outboundHeadDto.getOrderType());
		/**
		 * "Internal Order" 表示自提单 业务确定了，李进
		 * 自提单逻辑更新：orderType:Regular,expectedDeliveryDate:null
		 */
		if (StrUtil.isNotBlank(outboundHeadDto.getExpectedDeliveryDate())) {
			Date expectedDeliveryDate = DateUtil.parse(outboundHeadDto.getExpectedDeliveryDate(),
					DatePattern.PURE_DATETIME_PATTERN);
			dnOrderDm.setExpectedDeliveryDate(DateUtil.format(expectedDeliveryDate, DatePattern.NORM_DATETIME_PATTERN));
		}
		else if (StrUtil.equals(outboundHeadDto.getOrderType(), "Regular")) {
			// SAIC 暂时不管自提单逻辑
			// dnOrderDm.setDeliveryType("1");
		}

		dnOrderDm.setCustomerCode(outboundHeadDto.getCustomerNumber());
		dnOrderDm.setContactName(outboundHeadDto.getConsignee1());
		dnOrderDm.setContactCompany(outboundHeadDto.getConsignee2());
		dnOrderDm.setCountryCode(outboundHeadDto.getCountryCode());
		dnOrderDm.setCountryName(outboundHeadDto.getCountryCode());
		// dnOrderDm.setProvinceCode(outboundHeadDto.getProvinceCode());
		// dnOrderDm.setProvinceName(outboundHeadDto.getProvinceName());

		dnOrderDm.setPfepTypeEnum(PfepTypeEnum.ORDER_TO_DN_MASTER);
		dnOrderDm.setTypeEnum(OrderSplitTypeEnum.OS_01);

		dnOrderDm.setAddress(outboundHeadDto.getAddress());
		dnOrderDm.setZipCode(outboundHeadDto.getZipCode());
		dnOrderDm.setCityName(outboundHeadDto.getCityName());
		dnOrderDm.setCityCode(outboundHeadDto.getCityName());
		dnOrderDm.setContactPhone(outboundHeadDto.getContactNumber());
		dnOrderDm.setContactEmail(outboundHeadDto.getContactEmail());

		Date dnDate = DateUtil.parse(outboundHeadDto.getDnDate(), "dd-MMM-yy", Locale.US);
		dnOrderDm.setDnDate(DateUtil.format(dnDate, DatePattern.NORM_DATETIME_PATTERN));
		List<DnOrderDm.OrderLine> orderLines = new ArrayList<>();

		List<OutboundLineDto> outboundLineDtos = JsonMapper.INSTANCE.fromJson(lMsgIn,
				new TypeReference<List<OutboundLineDto>>() {
				});
		outboundLineDtos.forEach(x -> {
			DnOrderDm.OrderLine orderLine = new DnOrderDm.OrderLine();
			orderLine.setBatchNo(x.getBatch());
			orderLine.setLineNo(x.getOutboundDispatchPosition());
			orderLine.setPartNumber(x.getPartNumber());
			orderLine.setQty(new Double(x.getQuantity()));
			orderLine.setUnit(x.getUnit());
			// {"referenceNo":"r523452","orgItemCode":"10041514","poNumber":"4AXXX122A27"}
			Map<String, Object> extendProps = new HashMap<>();
			extendProps.put(SaicConstants.poNumber, x.getPoNumber());
			extendProps.put(SaicConstants.referenceNo, x.getCustomerReferenceNo());
			extendProps.put(SaicConstants.orgItemCode, x.getOriginalPartsNo());
			orderLine.setExtendProps(extendProps);
			orderLines.add(orderLine);
		});
		dnOrderDm.setOrderLines(orderLines);

		return dnOrderDm;
	}

}
