package com.herdsric.oms.saic.csv;

import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateUtil;
import com.fasterxml.jackson.core.type.TypeReference;
import com.herdsric.oms.common.client.asn.domain.AsnOrderDm;
import com.herdsric.oms.common.client.asn.domain.AsnOrderLineDm;
import com.herdsric.oms.common.core.util.JsonMapper;
import com.opencsv.bean.CsvBindByPosition;
import lombok.Data;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Data
public class InboundHeadDto {

	@CsvBindByPosition(position = 0, required = true)
	private String inboundAdviceNumber;

	@CsvBindByPosition(position = 1, required = true)
	private String supplierNumber;

	@CsvBindByPosition(position = 2, required = true)
	private String expectedArrivalDate;

	@CsvBindByPosition(position = 3)
	private String mark;

	@CsvBindByPosition(position = 4, required = true)
	private String shipmentInvoiceNumber;

	@CsvBindByPosition(position = 5)
	private String billOfLanding;

	public static AsnOrderDm toAsnOrderDm(String msgIn, String lMsgIn) {
		InboundHeadDto inboundHeadDto = JsonMapper.INSTANCE.fromJson(msgIn, InboundHeadDto.class);
		AsnOrderDm asnOrderDm = new AsnOrderDm();
		asnOrderDm.setOrderType("ZCRK");
		asnOrderDm.setOrderNo(inboundHeadDto.getInboundAdviceNumber());
		asnOrderDm.setBillLandNum(inboundHeadDto.getBillOfLanding());
		asnOrderDm.setInvoiceNum(inboundHeadDto.getShipmentInvoiceNumber());

		Date expectedArrivalDate = DateUtil.parse(inboundHeadDto.getExpectedArrivalDate(),
				DatePattern.PURE_DATETIME_PATTERN);
		asnOrderDm.setEtaTime(DateUtil.format(expectedArrivalDate, DatePattern.NORM_DATETIME_PATTERN));
		asnOrderDm.setSupplierCode(inboundHeadDto.getSupplierNumber());
		List<InboundLineDto> inboundLineDtos = JsonMapper.INSTANCE.fromJson(lMsgIn,
				new TypeReference<List<InboundLineDto>>() {
				});
		List<AsnOrderLineDm> inboundOrderLines = new ArrayList<>();
		inboundLineDtos.forEach(x -> {
			AsnOrderLineDm inboundOrderLine = new AsnOrderLineDm();
			inboundOrderLine.setLineNo(x.getInboundAdvicePosition());
			inboundOrderLine.setBatchNo(x.getBatch());
			inboundOrderLine.setPartNumber(x.getPartNumber());
			inboundOrderLine.setQty(x.getQuantity());
			inboundOrderLine.setUnit(x.getUnit());
			inboundOrderLine.setContainerNo(x.getContainerNo());
			inboundOrderLine.setPalletNo(x.getPackageNo());
			inboundOrderLines.add(inboundOrderLine);
		});
		asnOrderDm.setOrderLines(inboundOrderLines);
		return asnOrderDm;
	}

}
