package com.herdsric.oms.saic.csv;

import com.herdsric.oms.common.client.asn.domain.AsnOrderResponseDm;
import com.herdsric.oms.common.client.asn.domain.AsnOrderResponseLineDm;
import com.opencsv.bean.CsvBindByPosition;
import lombok.Data;

import java.util.List;

@Data
public class GrDto {

	@CsvBindByPosition(position = 0, required = true)
	private String inboundAdviceNumber;

	@CsvBindByPosition(position = 1, required = true)
	private String inboundAdvicePosition;

	@CsvBindByPosition(position = 2, required = true)
	private String partNumber;

	@CsvBindByPosition(position = 3, required = true)
	private String quantity;

	@CsvBindByPosition(position = 4, required = true)
	private String quantityUnit;

	@CsvBindByPosition(position = 5, required = true)
	private String receivedDate;

	@CsvBindByPosition(position = 6)
	private String qualityCode;

	@CsvBindByPosition(position = 7, required = true)
	private String goodReceivingNo;

	public static List<GrDto> convert(AsnOrderResponseDm asnOrderResponseDm) {
		List<GrDto> grDtoList = new java.util.ArrayList<>();
		for (AsnOrderResponseLineDm asnOrderResponseLineDm : asnOrderResponseDm.getOrderLines()) {
			GrDto grDto = new GrDto();
			grDto.setInboundAdviceNumber(asnOrderResponseDm.getOrderNo());
			grDto.setInboundAdvicePosition(asnOrderResponseLineDm.getLineNo());
			grDto.setPartNumber(asnOrderResponseLineDm.getPartNumber());
			grDto.setQuantity(String.valueOf(asnOrderResponseLineDm.getQty()));
			grDto.setQuantityUnit(asnOrderResponseLineDm.getUnit());
			grDto.setReceivedDate(asnOrderResponseDm.getOperateTime());
			grDto.setQualityCode("0");
			grDto.setGoodReceivingNo("1");
			grDtoList.add(grDto);
		}
		return grDtoList;
	}

}
