package com.herdsirc.oms.wz.service;

import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.wz.dto.outbound.CommonPackage;
import com.herdsric.oms.wz.dto.outbound.DnCancelDto;
import com.herdsric.oms.wz.dto.outbound.DockInfo;

public interface OutboundService {

	R packageInfoByWz(CommonPackage commonPackage);

	R dnCancelByWz(DnCancelDto dnCancelDto);

	R dnDockByDnNo(DockInfo dockInfoDto);

}
