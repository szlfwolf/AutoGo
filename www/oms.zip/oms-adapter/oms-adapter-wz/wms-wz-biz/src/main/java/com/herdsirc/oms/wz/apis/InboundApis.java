package com.herdsirc.oms.wz.apis;

import cn.hutool.core.collection.CollectionUtil;
import com.herdsirc.oms.wz.dto.ResultData;
import com.herdsirc.oms.wz.service.InboundService;
import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.wz.dto.inbound.InboundFeedback;
import com.pig4cloud.plugin.idempotent.annotation.Idempotent;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import java.util.List;
import java.util.Set;

@RestController
@RequiredArgsConstructor
@RequestMapping("/apis/inbound")
@Tag(name = "入库单对外接口")
public class InboundApis {

	private final InboundService inboundService;

	private final Validator validator;

	/**
	 * 入库单过账回传接口
	 * @param inboundFeedbacks
	 * @return
	 */
	@Operation(summary = "入库单过账回传接口", description = "入库单过账回传接口")
	@PostMapping("feedback")
	@Idempotent(key = "'inboundFeedback-'+ #inboundFeedbacks.toString()", expireTime = 300, delKey = true,
			info = "Do not repeat the operation")
	public R inboundFeedback(@RequestBody List<InboundFeedback> inboundFeedbacks) {
		Set<ConstraintViolation<InboundFeedback>> sets;
		for (InboundFeedback inboundFeedback : inboundFeedbacks) {
			sets = validator.validate(inboundFeedback);
			if (CollectionUtil.isNotEmpty(sets)) {
				return R.failed(sets.stream().findFirst().map(ConstraintViolation::getMessage).get());
			}
			inboundFeedback.check();
		}

		ResultData resultData = inboundService.postbackAsn(inboundFeedbacks);
		return CollectionUtil.isEmpty(resultData.getErrorList()) ? R.ok(resultData.getSuccessList())
				: R.failed(resultData);
	}

}
