package com.herdsirc.oms.wz.service.impl;

import com.herdsirc.oms.wz.dto.ResultData;
import com.herdsirc.oms.wz.service.InboundService;
import com.herdsirc.oms.wz.utils.InboundUtil;
import com.herdsric.oms.common.core.constant.CommonConstants;
import com.herdsric.oms.common.core.constant.SecurityConstants;
import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.common.feign.wms.RemoteInboundService;
import com.herdsric.oms.common.wms.inbound.domain.InboundFeedbackDm;
import com.herdsric.oms.wz.dto.inbound.InboundFeedback;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class InboundServiceImpl implements InboundService {

	private final RemoteInboundService remoteInboundService;

	@Override
	public ResultData postbackAsn(List<InboundFeedback> inboundFeedbacks) {

		ResultData resultData = new ResultData();

		List<String> successList = new ArrayList<>();
		List<String> errorList = new ArrayList<>();
		Map<String, String> resultMap = new HashMap<>();
		for (InboundFeedback inboundFeedback : inboundFeedbacks) {
			InboundFeedbackDm inboundFeedbackDm = InboundUtil.convertInboundFeedback(inboundFeedback);
			R result = remoteInboundService.feedback(inboundFeedbackDm, inboundFeedbackDm.getClientCode(),
					SecurityConstants.FROM_IN);
			if (result.getCode() == CommonConstants.SUCCESS) {
				successList.add((String) result.getData());
			}
			else {
				errorList.add(inboundFeedback.getInboundNo());
				resultMap.put(inboundFeedback.getInboundNo(), result.getMsg());
			}
		}
		resultData.setSuccessList(successList);
		resultData.setErrorList(errorList);
		resultData.setErrorMsgMap(resultMap);

		return resultData;
	}

}
