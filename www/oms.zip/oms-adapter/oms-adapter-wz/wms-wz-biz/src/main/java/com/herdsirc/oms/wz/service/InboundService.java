package com.herdsirc.oms.wz.service;

import com.herdsirc.oms.wz.dto.ResultData;
import com.herdsric.oms.wz.dto.inbound.InboundFeedback;

import java.util.List;

public interface InboundService {

	ResultData postbackAsn(List<InboundFeedback> inboundFeedbacks);

}
