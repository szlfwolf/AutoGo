
package com.herdsirc.oms.wz.apis;

import com.herdsirc.oms.wz.service.StockService;
import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.wz.dto.stock.StockQueryDTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping("/apis/stock")
@Tag(name = "库存对外接口")
public class StockApis {

	private final StockService stockService;

	/**
	 * 库存查询
	 * @param stockQueryDTO
	 * @return
	 */
	@Operation(summary = "库存查询", description = "库存查询")
	@PostMapping("list")
	public R list(@Validated @RequestBody StockQueryDTO stockQueryDTO) {
		stockQueryDTO.check();

		return R.ok(stockService.queryList(stockQueryDTO));
	}

}
