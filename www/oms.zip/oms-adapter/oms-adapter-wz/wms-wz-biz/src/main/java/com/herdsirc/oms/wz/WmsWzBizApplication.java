package com.herdsirc.oms.wz;

import com.herdsric.oms.common.feign.annotation.EnableOmsFeignClients;
import com.herdsric.oms.common.job.annotation.EnableOmsXxlJob;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@EnableOmsXxlJob
@EnableOmsFeignClients
@EnableDiscoveryClient
@SpringBootApplication
public class WmsWzBizApplication {

	public static void main(String[] args) {
		SpringApplication.run(WmsWzBizApplication.class, args);
	}

}
