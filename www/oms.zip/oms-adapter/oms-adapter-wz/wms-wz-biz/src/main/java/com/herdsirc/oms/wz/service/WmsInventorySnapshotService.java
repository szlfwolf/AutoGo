package com.herdsirc.oms.wz.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.herdsric.oms.wz.entity.WmsInventory;
import com.herdsric.oms.wz.entity.WmsInventorySnapshot;

import java.util.List;

public interface WmsInventorySnapshotService extends IService<WmsInventorySnapshot> {

	void saveBatch(List<WmsInventorySnapshot> list);

}
