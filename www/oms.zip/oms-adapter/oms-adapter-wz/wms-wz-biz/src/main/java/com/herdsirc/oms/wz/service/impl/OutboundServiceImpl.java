package com.herdsirc.oms.wz.service.impl;

import com.herdsirc.oms.wz.service.OutboundService;
import com.herdsirc.oms.wz.utils.OutboundUtil;
import com.herdsric.oms.common.core.constant.SecurityConstants;
import com.herdsric.oms.common.core.exception.ErrorCodeEnum;
import com.herdsric.oms.common.core.exception.OmsBusinessException;
import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.common.feign.wms.RemoteOutboundService;
import com.herdsric.oms.common.wms.outbound.domain.DockDm;
import com.herdsric.oms.common.wms.outbound.domain.OutboundFeedbackDm;
import com.herdsric.oms.wz.dto.outbound.CommonPackage;
import com.herdsric.oms.wz.dto.outbound.CommonPackageItem;
import com.herdsric.oms.wz.dto.outbound.DnCancelDto;
import com.herdsric.oms.wz.dto.outbound.DockInfo;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class OutboundServiceImpl implements OutboundService {

	private final RemoteOutboundService remoteOutboundService;

	@Override
	public R packageInfoByWz(CommonPackage commonPackage) {
		if (commonPackage.getDetails().stream().map(CommonPackageItem::getBoxNo).distinct().count() > 1) {
			throw new OmsBusinessException(ErrorCodeEnum.E600315, ErrorCodeEnum.E600315.msg);
		}
		OutboundFeedbackDm outboundFeedbackDm = OutboundUtil.convertCommonPackageToOutboundFeedbackDm(commonPackage);
		return remoteOutboundService.feedback(outboundFeedbackDm, outboundFeedbackDm.getClientCode(),
				SecurityConstants.FROM_IN);
	}

	@Override
	public R dnCancelByWz(DnCancelDto dnCancelDto) {
		OutboundFeedbackDm outboundFeedbackDm = OutboundUtil.convertDnCancelDtoToOutboundFeedbackDm(dnCancelDto);
		return remoteOutboundService.feedback(outboundFeedbackDm, outboundFeedbackDm.getClientCode(),
				SecurityConstants.FROM_IN);
	}

	@Override
	public R dnDockByDnNo(DockInfo dockInfoDto) {
		DockDm dockDm = OutboundUtil.convertDockInfoToDockDm(dockInfoDto);
		return remoteOutboundService.dockFeedback(dockDm, dockDm.getClientCode(), SecurityConstants.FROM_IN);
	}

}
