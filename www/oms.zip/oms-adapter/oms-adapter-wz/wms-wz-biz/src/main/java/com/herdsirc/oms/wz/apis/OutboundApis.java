package com.herdsirc.oms.wz.apis;

import com.herdsirc.oms.wz.service.OutboundService;
import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.wz.dto.outbound.CommonPackage;
import com.herdsric.oms.wz.dto.outbound.DnCancelDto;
import com.herdsric.oms.wz.dto.outbound.DockInfo;
import com.pig4cloud.plugin.idempotent.annotation.Idempotent;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping("/apis/outbound")
@Tag(name = "出库单对外接口")
public class OutboundApis {

	private final OutboundService outboundService;

	/**
	 * 4.5.包装信息反馈 WMS主动调用
	 * @param commonPackage
	 * @return
	 */
	@Operation(summary = "包装信息反馈", description = "包装信息反馈")
	@PostMapping("packaged")
	@Idempotent(key = "'commonPackage-'+#commonPackage.outboundNo", expireTime = 300, delKey = true,
			info = "Do not repeat the operation")
	public R outboundPackaged(@Validated @RequestBody CommonPackage commonPackage) {
		commonPackage.checkValid();
		return outboundService.packageInfoByWz(commonPackage);
	}

	/**
	 * 4.6.Dock号反馈 WMS主动调用
	 * @return R
	 */
	@Operation(summary = "Outbound dock反馈对外接口", description = "Outbound dock反馈对外接口")
	@PostMapping("dock")
	@Idempotent(key = "'dockInfoDto-' +#dockInfoDto.outboundNo", expireTime = 300, delKey = true,
			info = "Do not repeat the operation")
	public R outboundDock(@Validated @RequestBody DockInfo dockInfoDto) {
		dockInfoDto.validCheck();
		return outboundService.dnDockByDnNo(dockInfoDto);
	}

	/**
	 * 4.8.拣货单取消 WMS主动调用
	 * @param dnCancelDto
	 * @return
	 */

	@Operation(summary = "拣货单取消", description = "拣货单取消")
	@PostMapping("cancelled")
	@Idempotent(key = "'dnCancelDto-' + #dnCancelDto.outboundNo", expireTime = 300, delKey = true,
			info = "Do not repeat the operation")
	public R outboundCancelByWms(@Validated @RequestBody DnCancelDto dnCancelDto) {
		dnCancelDto.validCheck();
		return outboundService.dnCancelByWz(dnCancelDto);
	}

}
