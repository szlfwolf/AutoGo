package com.herdsirc.oms.wz.service;

import com.herdsric.oms.wz.dto.stock.StockQueryDTO;

import java.util.List;

public interface StockService {

	List queryList(StockQueryDTO stockQueryDTO);

}
