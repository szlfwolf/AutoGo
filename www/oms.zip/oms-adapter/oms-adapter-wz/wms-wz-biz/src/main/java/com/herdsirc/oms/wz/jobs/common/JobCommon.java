package com.herdsirc.oms.wz.jobs.common;

import cn.hutool.core.util.StrUtil;
import com.herdsric.oms.common.job.common.JobTask;

public class JobCommon {

	private static final String JOB_KEY_PREFIX = "Wz-JOB-TASK";

	public static class JobName {

		/**
		 * 从WZ同步库存
		 */
		public static final String INVENTORY_SYNC = "inventorySync";

	}

	public enum TaskEnum implements JobTask {

		/**
		 * 从WZ同步库存
		 */
		INVENTORY_SYNC(JobName.INVENTORY_SYNC, 30, "从WZ同步库存");

		public String name;

		public int expireTime;

		public String desc;

		TaskEnum(String name, int expireTime, String desc) {
			this.name = name;
			this.expireTime = expireTime;
			this.desc = desc;
		}

		public String getDesc() {
			return StrUtil.concat(true, this.desc);
		}

		@Override
		public String getName() {
			return name;
		}

		@Override
		public int expireTime() {
			return expireTime;
		}

		@Override
		public String getDescription() {
			return getDesc();
		}

		public String getKey() {
			return StrUtil.concat(true, JOB_KEY_PREFIX, this.name);
		}

	}

}
