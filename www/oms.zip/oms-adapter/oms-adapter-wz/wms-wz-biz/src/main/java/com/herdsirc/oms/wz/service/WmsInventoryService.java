package com.herdsirc.oms.wz.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.herdsric.oms.wz.dto.inventory.InventoryQueryDto;
import com.herdsric.oms.wz.entity.WmsInventory;

import java.util.List;

public interface WmsInventoryService extends IService<WmsInventory> {

	void saveBatch(List<WmsInventory> list);

	void physicsDelete(String date);

	Object queryList(InventoryQueryDto inventoryQueryDto);

}
