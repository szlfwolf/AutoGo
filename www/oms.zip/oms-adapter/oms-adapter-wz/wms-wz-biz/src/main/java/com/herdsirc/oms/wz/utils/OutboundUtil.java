package com.herdsirc.oms.wz.utils;

import cn.hutool.core.convert.Convert;
import cn.hutool.core.util.RandomUtil;
import cn.hutool.core.util.StrUtil;
import com.herdsric.oms.common.wms.outbound.domain.DockDm;
import com.herdsric.oms.common.wms.outbound.domain.OutboundFeedbackDm;
import com.herdsric.oms.common.wms.outbound.domain.OutboundFeedbackLineDm;
import com.herdsric.oms.common.wms.outbound.enums.OutboundStatusEnum;
import com.herdsric.oms.wz.dto.outbound.CommonPackage;
import com.herdsric.oms.wz.dto.outbound.CommonPackageItem;
import com.herdsric.oms.wz.dto.outbound.DnCancelDto;
import com.herdsric.oms.wz.dto.outbound.DockInfo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class OutboundUtil {

	private static final String GROUP_KEY_FORMAT = "BOX:{}_LINE:{}_ITEM:{}_UNIT:{}";

	//@formatter:off
	public static OutboundFeedbackDm convertCommonPackageToOutboundFeedbackDm(CommonPackage commonPackage) {
		OutboundFeedbackDm outboundFeedbackDm = new OutboundFeedbackDm();
		outboundFeedbackDm.setSequenceNo(RandomUtil.randomNumbers(10));
		outboundFeedbackDm.setOutboundNo(commonPackage.getOutboundNo());
		outboundFeedbackDm.setClientCode(commonPackage.getCompanyCode());
		outboundFeedbackDm.setWarehouseCode(commonPackage.getWarehouseCode());
		outboundFeedbackDm.setStatus(OutboundStatusEnum.PACKED.name());
		outboundFeedbackDm.setExpressTracingNo(commonPackage.getExpressTracingNo());

		Map<String, List<CommonPackageItem>> itemsMap = commonPackage.getDetails().stream().collect(Collectors.groupingBy(x -> StrUtil.format(GROUP_KEY_FORMAT, x.getBoxNo(), x.getLineNo(), x.getItemCode(), x.getUnit())));

		List<OutboundFeedbackLineDm> outboundFeedbackLineDms = new ArrayList<>();
		itemsMap.forEach((k, v) -> {
			Double sumPackQty = v.stream().map(x -> BigDecimal.valueOf(Double.valueOf(x.getPackQty()))).reduce(BigDecimal.ZERO, BigDecimal::add).doubleValue();
			CommonPackageItem item = v.get(0);
			OutboundFeedbackLineDm outboundFeedbackLineDm = new OutboundFeedbackLineDm();
			outboundFeedbackLineDm.setLineNo(item.getLineNo());
			outboundFeedbackLineDm.setItemCode(item.getItemCode());
			outboundFeedbackLineDm.setPackageNo(item.getBoxNo());
			outboundFeedbackLineDm.setUnit(item.getUnit());
			outboundFeedbackLineDm.setPackQty(sumPackQty);
			outboundFeedbackLineDm.setWidth(Convert.toDouble(item.getWidth()));
			outboundFeedbackLineDm.setHeight(Convert.toDouble(item.getHeight()));
			outboundFeedbackLineDm.setLength(Convert.toDouble(item.getLength()));
			outboundFeedbackLineDm.setWeight(Convert.toDouble(item.getNetWeight()));
			outboundFeedbackLineDm.setGrossWeight(Convert.toDouble(item.getWeight()));
			// outboundFeedbackLineDm.setVolume(Convert.toDouble(item.get()));
			// outboundFeedbackLineDm.setGrossVolume(Convert.toDouble(item.get()));
			outboundFeedbackLineDm.setPackageType(item.getPackingType());
			outboundFeedbackLineDm.setPackageTime(item.getPackagingTime());
			// 是否危险品
			outboundFeedbackLineDm.setIsDangerous(commonPackage.getIsDangerous());
			// 包裹序号
			outboundFeedbackLineDm.setSerialNumber(commonPackage.getSerialNumber());
			// 是否结束
			outboundFeedbackLineDm.setIsFinished(commonPackage.getIsFinished());

			outboundFeedbackLineDms.add(outboundFeedbackLineDm);

		});
		outboundFeedbackDm.setLineList(outboundFeedbackLineDms);

		return outboundFeedbackDm;
	}
	//@formatter:on

	public static OutboundFeedbackDm convertDnCancelDtoToOutboundFeedbackDm(DnCancelDto dnCancelDto) {
		OutboundFeedbackDm outboundFeedbackDm = new OutboundFeedbackDm();
		outboundFeedbackDm.setSequenceNo(RandomUtil.randomNumbers(10));
		outboundFeedbackDm.setOutboundNo(dnCancelDto.getOutboundNo());
		outboundFeedbackDm.setClientCode(dnCancelDto.getCompanyCode());
		outboundFeedbackDm.setWarehouseCode(dnCancelDto.getWarehouseCode());
		outboundFeedbackDm.setStatus(OutboundStatusEnum.CANCELLED.name());
		return outboundFeedbackDm;
	}

	public static DockDm convertDockInfoToDockDm(DockInfo dockInfoDto) {
		DockDm dockDm = new DockDm();
		dockDm.setSequenceNo(RandomUtil.randomNumbers(10));
		dockDm.setOutboundNo(dockInfoDto.getOutboundNo());
		dockDm.setClientCode(dockInfoDto.getCompanyCode());
		dockDm.setWarehouseCode(dockInfoDto.getWarehouseCode());
		return dockDm;
	}

}
