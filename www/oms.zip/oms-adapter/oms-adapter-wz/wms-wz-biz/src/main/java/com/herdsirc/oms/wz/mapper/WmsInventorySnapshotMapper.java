package com.herdsirc.oms.wz.mapper;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.herdsric.oms.common.mybatis.base.RootMapper;
import com.herdsric.oms.wz.entity.WmsInventorySnapshot;
import org.apache.ibatis.annotations.Mapper;

@Mapper
@DS("adapter")
public interface WmsInventorySnapshotMapper extends RootMapper<WmsInventorySnapshot> {

}
