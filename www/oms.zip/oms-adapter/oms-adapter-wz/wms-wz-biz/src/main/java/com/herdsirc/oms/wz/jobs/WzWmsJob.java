package com.herdsirc.oms.wz.jobs;

import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateUtil;
import com.herdsirc.oms.wz.jobs.common.JobCommon;
import com.herdsirc.oms.wz.mapper.WzInventoryMapper;
import com.herdsirc.oms.wz.service.InventorySyncService;
import com.herdsric.oms.common.job.common.AbstractCommonTask;
import com.herdsric.oms.wz.dto.inventory.InventoryDto;
import com.herdsric.oms.wz.entity.WmsInventory;
import com.herdsric.oms.wz.enums.ClientValueEnum;
import com.herdsric.oms.wz.enums.WarehouseValueEnum;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@Component
@RequiredArgsConstructor
public class WzWmsJob extends AbstractCommonTask {

	private final WzInventoryMapper wzInventoryMapper;

	private final InventorySyncService inventorySyncService;

	/**
	 * 凌晨执行，拉取前一天的库存数据
	 */
	@XxlJob(JobCommon.JobName.INVENTORY_SYNC)
	public void inventorySync() {
		this.execute(JobCommon.TaskEnum.INVENTORY_SYNC, x -> {
			String date = DateUtil.format(DateUtil.yesterday(), DatePattern.NORM_DATE_PATTERN);
			List<WmsInventory> wmsInventories = new ArrayList<>();
			for (ClientValueEnum clientValueEnum : ClientValueEnum.values()) {
				List<InventoryDto> wzInventory = wzInventoryMapper.getWzInventoryByClientCode(clientValueEnum.wmsValue,
						null);
				for (InventoryDto inventoryDto : wzInventory) {
					WmsInventory wmsInventory = new WmsInventory();
					wmsInventory.setClientCode(clientValueEnum.omsValue);
					wmsInventory.setWarehouseCode(WarehouseValueEnum.getOmsValue(inventoryDto.getWarehouseCode()));
					wmsInventory.setPartNumber(inventoryDto.getItemCode());
					wmsInventory.setName(inventoryDto.getItemName());
					wmsInventory.setIsHazardous("");
					wmsInventory.setUnit(inventoryDto.getUnit());
					wmsInventory.setQty(inventoryDto.getTotalQty());
					wmsInventory.setAvailableQty(inventoryDto.getAvailableQty());
					wmsInventory.setDate(date);

					wmsInventories.add(wmsInventory);
				}
			}

			inventorySyncService.wzInventorySync(date, wmsInventories);
		});
	}

}
