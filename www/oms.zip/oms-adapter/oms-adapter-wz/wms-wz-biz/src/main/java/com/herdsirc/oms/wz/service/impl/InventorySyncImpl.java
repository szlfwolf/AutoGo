package com.herdsirc.oms.wz.service.impl;

import cn.hutool.core.bean.BeanUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.herdsirc.oms.wz.service.InventorySyncService;
import com.herdsirc.oms.wz.service.WmsInventoryService;
import com.herdsirc.oms.wz.service.WmsInventorySnapshotService;
import com.herdsric.oms.wz.entity.WmsInventory;
import com.herdsric.oms.wz.entity.WmsInventorySnapshot;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class InventorySyncImpl implements InventorySyncService {

	private final WmsInventoryService wmsInventoryService;

	private final WmsInventorySnapshotService wmsInventorySnapshotService;

	@Override
	@Transactional(rollbackFor = Exception.class)
	public void wzInventorySync(String date, List<WmsInventory> wmsInventories) {
		// 防止重复执行，导致前一天的库存数据不一致，如果有则不需要重复删除插入，更新库存快照
		LambdaQueryWrapper<WmsInventory> lambdaQueryWrapper = new LambdaQueryWrapper<>();
		lambdaQueryWrapper.eq(WmsInventory::getDate, date);
		lambdaQueryWrapper.orderByAsc(WmsInventory::getDate);
		lambdaQueryWrapper.last("LIMIT 1");
		WmsInventory wmsInventory = wmsInventoryService.getOne(lambdaQueryWrapper);
		if (wmsInventory != null) {
			log.info("WZ Inventory has been synced, date: {}, skip.", date);
			return;
		}

		// 删除历史库存数据
		wmsInventoryService.physicsDelete(date);

		wmsInventoryService.saveBatch(wmsInventories);
		List<WmsInventorySnapshot> wmsInventorySnapshots = BeanUtil.copyToList(wmsInventories,
				WmsInventorySnapshot.class);
		wmsInventorySnapshotService.saveBatch(wmsInventorySnapshots);
	}

}
