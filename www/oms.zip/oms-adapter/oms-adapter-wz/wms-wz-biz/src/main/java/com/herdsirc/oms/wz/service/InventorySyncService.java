package com.herdsirc.oms.wz.service;

import com.herdsric.oms.wz.entity.WmsInventory;

import java.util.List;

public interface InventorySyncService {

	void wzInventorySync(String date, List<WmsInventory> wmsInventories);

}
