package com.herdsirc.oms.wz.mapper;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.herdsric.oms.wz.dto.inventory.InventoryDto;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
@DS("wz")
public interface WzInventoryMapper {

	List<String> getWzClientCodes();

	List<InventoryDto> getWzInventoryByClientCode(@Param("clientCode") String clientCode,
			@Param("warehouseCode") String warehouseCode);

}
