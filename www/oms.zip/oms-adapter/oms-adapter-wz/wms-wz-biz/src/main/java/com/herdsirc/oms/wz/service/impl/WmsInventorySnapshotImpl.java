package com.herdsirc.oms.wz.service.impl;

import cn.hutool.core.collection.CollectionUtil;
import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.herdsirc.oms.wz.mapper.WmsInventorySnapshotMapper;
import com.herdsirc.oms.wz.service.WmsInventorySnapshotService;
import com.herdsric.oms.wz.entity.WmsInventorySnapshot;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@DS("adapter")
public class WmsInventorySnapshotImpl extends ServiceImpl<WmsInventorySnapshotMapper, WmsInventorySnapshot>
		implements WmsInventorySnapshotService {

	@Override
	public void saveBatch(List<WmsInventorySnapshot> list) {
		if (CollectionUtil.isNotEmpty(list)) {
			List<List<WmsInventorySnapshot>> splitList = CollectionUtil.split(list, 1000);
			for (List<WmsInventorySnapshot> subList : splitList) {
				this.baseMapper.insertBatch(subList);
			}
		}
	}

}
