package com.herdsirc.oms.wz.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.herdsirc.oms.wz.dto.WmsInventoryDTO;
import com.herdsirc.oms.wz.mapper.WmsInventoryMapper;
import com.herdsirc.oms.wz.service.WmsInventoryService;
import com.herdsirc.oms.wz.service.WmsInventorySnapshotService;
import com.herdsric.oms.wz.dto.inventory.InventoryQueryDto;
import com.herdsric.oms.wz.entity.WmsInventory;
import com.herdsric.oms.wz.entity.WmsInventorySnapshot;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@DS("adapter")
@RequiredArgsConstructor
public class WmsInventoryImpl extends ServiceImpl<WmsInventoryMapper, WmsInventory> implements WmsInventoryService {

	private final WmsInventorySnapshotService wmsInventorySnapshotService;

	@Override
	public void saveBatch(List<WmsInventory> list) {
		if (CollectionUtil.isNotEmpty(list)) {
			List<List<WmsInventory>> splitList = CollectionUtil.split(list, 1000);
			for (List<WmsInventory> subList : splitList) {
				this.baseMapper.insertBatch(subList);
			}
		}
	}

	@Override
	public void physicsDelete(String date) {
		this.baseMapper.physicsDelete(date);
	}

	@Override
	public List<WmsInventoryDTO> queryList(InventoryQueryDto inventoryQueryDto) {
		if (StrUtil.isBlank(inventoryQueryDto.getDate())) {
			LambdaQueryWrapper<WmsInventory> queryWrapper = Wrappers.<WmsInventory>lambdaQuery()
					.eq(WmsInventory::getClientCode, inventoryQueryDto.getClientCode())
					.eq(WmsInventory::getWarehouseCode, inventoryQueryDto.getWarehouseCode());
			List<WmsInventory> wmsInventoryList = this.list(queryWrapper);
			return BeanUtil.copyToList(wmsInventoryList, WmsInventoryDTO.class);
		}
		else {
			LambdaQueryWrapper<WmsInventorySnapshot> queryWrapper = Wrappers.<WmsInventorySnapshot>lambdaQuery()
					.eq(WmsInventorySnapshot::getClientCode, inventoryQueryDto.getClientCode())
					.eq(WmsInventorySnapshot::getWarehouseCode, inventoryQueryDto.getWarehouseCode())
					.eq(WmsInventorySnapshot::getDate, inventoryQueryDto.getDate());

			List<WmsInventorySnapshot> wmsInventoryList = wmsInventorySnapshotService.list(queryWrapper);
			return BeanUtil.copyToList(wmsInventoryList, WmsInventoryDTO.class);
		}
	}

}
