package com.herdsirc.oms.wz.mapper;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.herdsric.oms.common.mybatis.base.RootMapper;
import com.herdsric.oms.wz.entity.WmsInventory;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
@DS("adapter")
public interface WmsInventoryMapper extends RootMapper<WmsInventory> {

	void physicsDelete(@Param("date") String date);

}
