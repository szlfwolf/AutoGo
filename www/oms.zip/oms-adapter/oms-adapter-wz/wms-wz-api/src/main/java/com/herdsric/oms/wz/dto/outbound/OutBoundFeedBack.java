package com.herdsric.oms.wz.dto.outbound;

import lombok.Data;

import java.io.Serializable;

/**
 * @author zhu
 * @date 2021/7/9/11:53
 */
@Data
public class OutBoundFeedBack implements Serializable {

	/**
	 * 仓库编码
	 */
	private String warehouseCode;

	/**
	 * 货主编码
	 */
	private String companyCode;

	/**
	 * 出库单据号
	 */
	private String outboundNo;

	/**
	 * 过账日期
	 */
	private String buDate;

	private String boxNo;

}
