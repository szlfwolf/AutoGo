package com.herdsric.oms.wz.enums;

import cn.hutool.core.util.StrUtil;
import com.herdsric.oms.common.core.exception.ErrorCodeEnum;
import com.herdsric.oms.common.core.exception.OmsBusinessException;
import com.herdsric.oms.common.core.validation.EnumValidator;

import java.util.Arrays;

public enum PackageTypeEnum implements EnumValidator {

	// PLT/PACL/SPLT
	PLT("PLT", "PLT", "托盘"), PACL("PACL", "PACL", "包裹"), SPLT("SPLT", "PLT", "超级托盘");

	public final String wmsValue;

	public final String omsValue;

	public final String desc;

	PackageTypeEnum(String wmsValue, String omsValue, String desc) {
		this.omsValue = omsValue;
		this.wmsValue = wmsValue;
		this.desc = desc;
	}

	@Override
	public Object getValue() {
		return this.wmsValue;
	}

	public static String getOmsValue(String wmsValue) {
		PackageTypeEnum packageTypeEnum = Arrays.stream(PackageTypeEnum.values())
				.filter(x -> StrUtil.equals(x.wmsValue, wmsValue)).findAny()
				.orElseThrow(() -> new OmsBusinessException(ErrorCodeEnum.E100001.code,
						StrUtil.format("打包类型：{}不存在", wmsValue)));
		return packageTypeEnum.omsValue;
	}

}
