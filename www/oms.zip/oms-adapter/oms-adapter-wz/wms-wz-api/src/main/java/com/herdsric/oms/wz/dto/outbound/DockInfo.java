package com.herdsric.oms.wz.dto.outbound;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.List;

@Data

public class DockInfo {

	/**
	 * 货主编码
	 */
	@NotBlank(message = "货主代码不能为空")
	private String companyCode;

	/**
	 * 仓库编码
	 */
	@NotBlank(message = "仓库代码不能为空")
	private String warehouseCode;

	/**
	 * 出库单据号
	 */
	@NotBlank(message = "出库单不能为空")
	private String outboundNo;

	@Valid
	@NotNull(message = "包装信息不能为空")
	private List<DockDetail> details;

	public void validCheck() {
	}

	@Data
	public static class DockDetail {

		@JsonProperty("Dock")
		private String dockNo;

		/**
		 * pack_info_id
		 */
		private Integer packInfoId;

		/***
		 * 月台状态 0：未发货 1：已发货
		 */
		private String dockStatus;

		/**
		 * 创建时间
		 */
		private String createTime;

		/**
		 * 修改时间
		 */
		private String updateTime;

		/**
		 * 备注
		 */
		private String remark;

	}

}
