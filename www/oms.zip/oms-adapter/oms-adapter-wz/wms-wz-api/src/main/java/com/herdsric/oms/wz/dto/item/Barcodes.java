package com.herdsric.oms.wz.dto.item;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class Barcodes {

	@JsonProperty(index = 1)
	private String code;

	@JsonProperty(index = 2)
	private String type;

}
