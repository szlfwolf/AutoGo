package com.herdsric.oms.wz;

public interface WzConstant {

	String WMS_TYPE = "WEIZHI";

	String SKU_PUSH_WMS_WAREHOUSE_CODE = "10";

	String UNIT_PCE = "PCE";

	String UNIT_PCS = "PCS";

	/**
	 * 未妥投的订单
	 */
	String RETURN = "_return";

}
