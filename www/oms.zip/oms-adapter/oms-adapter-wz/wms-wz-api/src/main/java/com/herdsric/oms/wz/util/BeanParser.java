package com.herdsric.oms.wz.util;

import com.herdsric.oms.common.wms.inbound.dto.InboundDTO;
import com.herdsric.oms.common.wms.itemcode.dto.ItemCodeDTO;
import com.herdsric.oms.common.wms.outbound.dto.OutboundDTO;
import com.herdsric.oms.common.wms.outbound.dto.TaskDTO;
import com.herdsric.oms.wz.dto.inbound.CommonInbound;
import com.herdsric.oms.wz.dto.inbound.Inbound;
import com.herdsric.oms.wz.dto.item.CommonProduct;
import com.herdsric.oms.wz.dto.item.Product;
import com.herdsric.oms.wz.dto.outbound.CommonOutbound;
import com.herdsric.oms.wz.dto.outbound.OutBoundFeedBack;
import com.herdsric.oms.wz.dto.outbound.Outbound;

import java.util.ArrayList;
import java.util.List;

public class BeanParser {

	public static List<? extends CommonProduct> parserSku(List<ItemCodeDTO> itemCodes) {
		return Product.convert(itemCodes);
	}

	public static CommonInbound parserAsn(InboundDTO inboundDTO) {
		return Inbound.convert(inboundDTO);
	}

	public static CommonOutbound parserDn(OutboundDTO outboundDTO) {
		return Outbound.convert(outboundDTO);
	}

	public static List<OutBoundFeedBack> parserDnFeedBack(TaskDTO taskDTO) {
		List<OutBoundFeedBack> outBoundFeedBacks = new ArrayList<>();
		for (String packageNo : taskDTO.getPackageNoList()) {
			OutBoundFeedBack outBoundFeedBack = new OutBoundFeedBack();
			outBoundFeedBack.setCompanyCode(taskDTO.getClientCode());
			outBoundFeedBack.setWarehouseCode(taskDTO.getWarehouseCode());
			outBoundFeedBack.setOutboundNo(taskDTO.getBatchNo());
			outBoundFeedBack.setBuDate(taskDTO.getOutboundTime());
			outBoundFeedBack.setBoxNo(packageNo);
			outBoundFeedBacks.add(outBoundFeedBack);
		}

		return outBoundFeedBacks;
	}

}