package com.herdsric.oms.wz.dto.stock;

public class StockQueryDTO {

	public void check() {
	}

}
