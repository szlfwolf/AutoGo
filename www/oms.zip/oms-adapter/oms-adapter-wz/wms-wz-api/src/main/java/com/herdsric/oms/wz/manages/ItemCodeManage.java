package com.herdsric.oms.wz.manages;

import com.herdsric.oms.common.client.enums.SyncEnum;
import com.herdsric.oms.common.core.util.SpringContextHolder;
import com.herdsric.oms.common.webhook.CallbackHttpDefine;
import com.herdsric.oms.common.wms.itemcode.ItemCodeBizDefine;
import com.herdsric.oms.common.wms.itemcode.dto.ItemCodeDTO;
import com.herdsric.oms.common.wms.itemcode.process.ItemCodeProcessor;
import com.herdsric.oms.wz.WzConstant;
import com.herdsric.oms.wz.dto.item.CommonProduct;
import com.herdsric.oms.wz.util.BeanParser;

import java.util.Arrays;
import java.util.List;
import java.util.function.Function;

public class ItemCodeManage extends CommonDefine implements ItemCodeBizDefine {

	@Override
	public void pushItemCode2Wms(String clientCode, String wmsType, List<String> itemCodes) {
		CallbackHttpDefine callbackHttpDefine = SpringContextHolder.getBean(CallbackHttpDefine.class);

		Function<List<ItemCodeDTO>, Boolean> function = x -> {
			List<? extends CommonProduct> itemCodeList = BeanParser.parserSku(x);
			for (CommonProduct commonProduct : itemCodeList) {
				callbackHttpDefine.execute(true, WzConstant.WMS_TYPE, clientCode, commonProduct.getWarehouseCode(),
						commonProduct.getCode(), Arrays.asList(commonProduct), SyncEnum.SKU_PUSH_WMS_SYNC.name(), true);
			}
			return true;
		};

		ItemCodeProcessor itemCodeProcessor = SpringContextHolder.getBean(ItemCodeProcessor.class);
		itemCodeProcessor.itemCodes2Wms(clientCode, itemCodes, function);
	}

}
