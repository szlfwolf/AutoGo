package com.herdsric.oms.wz.manages;

import com.herdsric.oms.common.client.enums.SyncEnum;
import com.herdsric.oms.common.core.util.SpringContextHolder;
import com.herdsric.oms.common.webhook.CallbackHttpDefine;
import com.herdsric.oms.common.wms.outbound.OutboundBizDefine;
import com.herdsric.oms.common.wms.outbound.domain.DockDm;
import com.herdsric.oms.common.wms.outbound.domain.OutboundFeedbackDm;
import com.herdsric.oms.common.wms.outbound.dto.OutboundDTO;
import com.herdsric.oms.common.wms.outbound.dto.TaskDTO;
import com.herdsric.oms.common.wms.outbound.process.OutboundProcessor;
import com.herdsric.oms.wz.WzConstant;
import com.herdsric.oms.wz.dto.outbound.CommonOutbound;
import com.herdsric.oms.wz.dto.outbound.OutBoundFeedBack;
import com.herdsric.oms.wz.util.BeanParser;

import java.util.Arrays;
import java.util.List;
import java.util.function.Function;

public class OutboundManage extends CommonDefine implements OutboundBizDefine {

	@Override
	public void outbound2WmsByWebhook(String clientCode, String warehouseCode, String outboundNo) {

		CallbackHttpDefine callbackHttpDefine = SpringContextHolder.getBean(CallbackHttpDefine.class);

		Function<OutboundDTO, Boolean> function = x -> {
			CommonOutbound outbound = BeanParser.parserDn(x);
			callbackHttpDefine.execute(true, WzConstant.WMS_TYPE, clientCode, warehouseCode, outboundNo,
					Arrays.asList(outbound), SyncEnum.DN_ORDER_PUSH_WMS_SYNC.name(), false);
			return true;
		};

		OutboundProcessor outboundProcessor = SpringContextHolder.getBean(OutboundProcessor.class);
		outboundProcessor.pushOutbound2WmsByWebhook(clientCode, warehouseCode, outboundNo, function);
	}

	@Override
	public void outboundFeedBack4Wms(OutboundFeedbackDm outboundFeedbackDm) {
		OutboundProcessor outboundProcessor = SpringContextHolder.getBean(OutboundProcessor.class);
		outboundProcessor.outboundFeedbackHandler(outboundFeedbackDm, WzConstant.WMS_TYPE);
	}

	@Override
	public void outboundNotice2WmsByWebhook(String clientCode, String warehouseCode, String taskNo) {

		CallbackHttpDefine callbackHttpDefine = SpringContextHolder.getBean(CallbackHttpDefine.class);

		Function<TaskDTO, Boolean> function = x -> {
			List<OutBoundFeedBack> outBoundFeedBackList = BeanParser.parserDnFeedBack(x);

			for (OutBoundFeedBack outBoundFeedBack : outBoundFeedBackList) {
				callbackHttpDefine.execute(true, WzConstant.WMS_TYPE, clientCode, warehouseCode,
						outBoundFeedBack.getBoxNo(), outBoundFeedBack, SyncEnum.DN_ORDER_BILL_PUSH_WMS_SYNC.name(),
						true);
			}
			return true;
		};

		OutboundProcessor outboundProcessor = SpringContextHolder.getBean(OutboundProcessor.class);
		outboundProcessor.outboundConfirmByWebhook(clientCode, warehouseCode, taskNo, function);
	}

	@Override
	public void dockOutbound4Wms(DockDm dockDm) {
		OutboundProcessor outboundProcessor = SpringContextHolder.getBean(OutboundProcessor.class);
		outboundProcessor.outboundDockHandler(dockDm);
	}

}
