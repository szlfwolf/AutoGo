package com.herdsric.oms.wz.manages;

import com.herdsric.oms.common.client.enums.SyncEnum;
import com.herdsric.oms.common.core.util.SpringContextHolder;
import com.herdsric.oms.common.webhook.CallbackHttpDefine;
import com.herdsric.oms.common.wms.inbound.InboundBizDefine;
import com.herdsric.oms.common.wms.inbound.domain.InboundFeedbackDm;
import com.herdsric.oms.common.wms.inbound.dto.InboundDTO;
import com.herdsric.oms.common.wms.inbound.process.InboundProcessor;
import com.herdsric.oms.wz.WzConstant;
import com.herdsric.oms.wz.dto.inbound.CommonInbound;
import com.herdsric.oms.wz.util.BeanParser;

import java.util.Arrays;
import java.util.function.Function;

public class InboundManage extends CommonDefine implements InboundBizDefine {

	@Override
	public void inbound2WmsByWebhook(String clientCode, String warehouseCode, String inboundNo) {

		CallbackHttpDefine callbackHttpDefine = SpringContextHolder.getBean(CallbackHttpDefine.class);

		Function<InboundDTO, Boolean> function = x -> {
			CommonInbound inbound = BeanParser.parserAsn(x);
			callbackHttpDefine.execute(true, WzConstant.WMS_TYPE, clientCode, warehouseCode, inboundNo,
					Arrays.asList(inbound), SyncEnum.ASN_PUSH_WMS_SYNC.name(), true);
			return true;
		};

		InboundProcessor inboundProcessor = SpringContextHolder.getBean(InboundProcessor.class);
		inboundProcessor.pushInbound2WmsByWebhook(clientCode, warehouseCode, inboundNo, function);
	}

	@Override
	public void inboundFeedBack4Wms(InboundFeedbackDm inboundFeedbackDm) {
		InboundProcessor inboundProcessor = SpringContextHolder.getBean(InboundProcessor.class);
		inboundProcessor.inboundFeedbackHandler(inboundFeedbackDm, WzConstant.WMS_TYPE);
	}

}
