package com.herdsric.oms.wz.dto.outbound;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class OutBoundDetails {

	// 明细行号
	private String lineNo;

	// 货品编码
	private String itemCode;

	// 包装单位
	private String unit;

	// 期待包装数量
	private String packQty;

	// 预计到达时间
	private String estimatedate;

	// 扩展字段1
	private String extendedField1;

	// 扩展字段2
	private String extendedField2;

	// 明细备注
	private String remark;

	// PO号
	private String poNumber;

	// 客户关联号
	private String referenceNo;

	// 原始货品编号
	private String orgItemCode;

	@JsonProperty(index = 9)
	private OutBoundLotInfo lotInfo;

}