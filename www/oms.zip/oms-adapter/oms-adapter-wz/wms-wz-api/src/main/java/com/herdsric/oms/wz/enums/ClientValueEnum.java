package com.herdsric.oms.wz.enums;

import cn.hutool.core.util.StrUtil;
import com.herdsric.oms.common.core.exception.ErrorCodeEnum;
import com.herdsric.oms.common.core.exception.OmsBusinessException;

import java.util.Arrays;

public enum ClientValueEnum {

	//@formatter:off
	SAIC("上汽汽车配件", "SAIC"),
	GW("长城", "GW"),
	NIO("蔚来", "NIO"),
	LUXMATE("Lux-mate", "Lux-mate"),
	LOTUS("莲花", "LOTUS"),
	ZEEKR("ZEEKR", "ZEEKR");
	//@formatter:on

	public final String wmsValue;

	public final String omsValue;

	ClientValueEnum(String wmsValue, String omsValue) {
		this.wmsValue = wmsValue;
		this.omsValue = omsValue;
	}

	public static String getOmsValue(String wmsValue) {
		ClientValueEnum clientValueEnum = Arrays.stream(ClientValueEnum.values())
				.filter(x -> StrUtil.equals(x.wmsValue, wmsValue)).findAny()
				.orElseThrow(() -> new OmsBusinessException(ErrorCodeEnum.E100001.code,
						StrUtil.format("客户：{}不存在", wmsValue)));
		return clientValueEnum.omsValue;
	}

}
