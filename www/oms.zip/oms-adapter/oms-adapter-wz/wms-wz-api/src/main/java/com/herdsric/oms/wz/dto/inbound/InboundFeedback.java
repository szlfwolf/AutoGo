package com.herdsric.oms.wz.dto.inbound;

import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import java.io.Serializable;
import java.util.List;

@Data
public class InboundFeedback implements Serializable {

	/**
	 * 仓库编码
	 */
	@NotBlank(message = "仓库编码不能为空")
	private String warehouseCode;

	/**
	 * 货主编码
	 */
	@NotBlank(message = "货主编码不能为空")
	private String companyCode;

	/**
	 * 收货单据号
	 */
	@NotBlank(message = "收货单据号不能为空")
	private String inboundNo;

	/**
	 * 扩展字段1
	 */
	private String extendedField1;

	/**
	 * 扩展字段2
	 */
	private String extendedField2;

	@Valid
	@NotEmpty
	private List<InboundFeedbackDetails> details;

	public void check() {
	}

}
