package com.herdsric.oms.wz.dto.stock;

public class StockQuery {

	public void check() {
	}

}
