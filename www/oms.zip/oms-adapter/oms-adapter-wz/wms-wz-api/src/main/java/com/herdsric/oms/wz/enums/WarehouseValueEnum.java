package com.herdsric.oms.wz.enums;

import cn.hutool.core.util.StrUtil;

import java.util.Arrays;
import java.util.Optional;

public enum WarehouseValueEnum {

	//@formatter:off
	WC_Mijdrecht("Mijdrecht", "FLKF"),
	WC_Bellsingle("Bellsingle", "BellsingleWarehouse"),
	WC_10("荷兰阿姆斯特丹配件仓库", "10"),
	WC_20("法兰克福仓", "20"),
	WC_CDC("乐世汽车配件德国仓", "CDC-000001");
	//@formatter:on

	public final String wmsValue;

	public final String omsValue;

	WarehouseValueEnum(String wmsValue, String omsValue) {
		this.wmsValue = wmsValue;
		this.omsValue = omsValue;
	}

	public static String getOmsValue(String wmsValue) {
		Optional<WarehouseValueEnum> optional = Arrays.stream(WarehouseValueEnum.values())
				.filter(x -> StrUtil.equals(x.wmsValue, wmsValue)).findAny();
		return optional.isPresent() ? optional.get().omsValue : wmsValue;
	}

}
