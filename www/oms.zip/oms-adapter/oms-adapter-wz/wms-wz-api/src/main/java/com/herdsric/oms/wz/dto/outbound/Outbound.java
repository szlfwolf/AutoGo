package com.herdsric.oms.wz.dto.outbound;

import cn.hutool.core.convert.Convert;
import cn.hutool.core.util.RandomUtil;
import cn.hutool.core.util.StrUtil;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.herdsric.oms.common.wms.common.CommonStatusEnum;
import com.herdsric.oms.common.wms.outbound.domain.OutboundLineDm;
import com.herdsric.oms.common.wms.outbound.dto.OutboundDTO;
import com.herdsric.oms.common.wms.outbound.dto.OutboundLineDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Data
@EqualsAndHashCode(callSuper = true)
public class Outbound extends CommonOutbound {

	@JsonProperty("UUID")
	private String uuid = RandomUtil.randomString(16);

	// 单据类型
	private String orderType;

	// 预计达到时间
	private String requireArriveDate;

	// 优先级
	private String priority;

	// 收货⼈
	private String receiverName;

	// 联系电话
	private String telephone;

	// 手机号
	private String mobile;

	// 描述
	private String description;

	// 状态
	private String status;

	// 扩展字段1
	private String extendedField1;

	// 扩展字段2
	private String extendedField2;

	// 扩展字段3
	private String extendedField3;

	private String extendedField4;

	private String extendedField5;

	private String dnOrderDate;

	// 国家代码
	private String country;

	/**
	 * 仓库需要的备注字段
	 */
	private String remark;

	@JsonProperty(index = 24)
	private List<OutBoundDetails> details;

	public static Outbound convert(OutboundDTO outboundDTO) {
		Outbound outbound = new Outbound();
		outbound.setOutboundNo(outboundDTO.getOutboundNo());
		outbound.setCompanyCode(outboundDTO.getClientCode());
		outbound.setWarehouseCode(outboundDTO.getWarehouseCode());
		outbound.setStatus(CommonStatusEnum.N.name());
		outbound.setRequireArriveDate(outboundDTO.getExpectedDeliveryDate());
		outbound.setReceiverName(outboundDTO.getContactName());
		outbound.setOrderType(outboundDTO.getType());
		outbound.setMobile(outboundDTO.getContactPhone());
		outbound.setCountry(outboundDTO.getCountryCode());
		outbound.setExtendedField1(outboundDTO.getAddress());
		outbound.setExtendedField2(StrUtil.format("{}-{}", outboundDTO.getCountryCode(), outboundDTO.getZipCode()));
		outbound.setExtendedField3(Convert.toStr(outboundDTO.getRemark(), ""));
		outbound.setExtendedField4(outboundDTO.getDnNos());
		outbound.setExtendedField5(Convert.toStr(outboundDTO.getRemark(), ""));
		outbound.setRemark(Convert.toStr(outboundDTO.getClientRemark(), ""));
		outbound.setDnOrderDate(Convert.toStr(outboundDTO.getDnDate(), ""));

		List<OutBoundDetails> detailsList = new ArrayList<>();
		Map<String, List<OutboundLineDTO>> lineMap = outboundDTO.getOutboundLines().stream().collect(
				Collectors.groupingBy(x -> StrUtil.format("lineNo:{}-itemCode:{}", x.getLineNo(), x.getItemCode())));
		for (String key : lineMap.keySet()) {
			OutboundLineDTO outboundLine = lineMap.get(key).get(0);
			OutBoundDetails detail = new OutBoundDetails();
			detail.setLineNo(outboundLine.getLineNo());
			detail.setItemCode(outboundLine.getItemCode());
			detail.setUnit(outboundLine.getUnit());
			Double sumQty = lineMap.get(key).stream().map(OutboundLineDm::getPackQty).reduce(Double::sum).get();
			detail.setPackQty(Convert.toStr(sumQty));
			detail.setEstimatedate("");
			detail.setExtendedField1(Convert.toStr(outboundLine.getRemark(), ""));
			detail.setExtendedField2(Convert.toStr(outboundLine.getVin(), ""));
			String clientRemark = Convert.toStr(outboundLine.getClientRemark(), "");
			if (!StrUtil.equals(outboundDTO.getDnNo(), outboundDTO.getDnNos())) {
				clientRemark = StrUtil.format("DN:{} {}",
						lineMap.get(key).stream().map(OutboundLineDTO::getDnNo).distinct().collect(Collectors.toList()),
						clientRemark);
			}
			detail.setRemark(clientRemark);// 明细备注
			Map<String, Object> extendProps = outboundLine.getExtendProps();
			detail.setPoNumber((String) extendProps.getOrDefault("poNumber", ""));
			detail.setReferenceNo((String) extendProps.getOrDefault("referenceNo", ""));
			detail.setOrgItemCode((String) extendProps.getOrDefault("orgItemCode", ""));
			OutBoundLotInfo lotInfo = new OutBoundLotInfo();
			detail.setLotInfo(lotInfo);
			detailsList.add(detail);

		}
		outbound.setDetails(detailsList);
		return outbound;
	}

}
