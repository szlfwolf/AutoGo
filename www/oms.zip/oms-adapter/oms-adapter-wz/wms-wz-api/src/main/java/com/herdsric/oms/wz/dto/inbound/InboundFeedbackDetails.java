package com.herdsric.oms.wz.dto.inbound;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

@Data
public class InboundFeedbackDetails implements Serializable {

	/**
	 * 明细行号
	 */
	@NotBlank(message = "明细行号不能为空")
	private String lineNo;

	/**
	 * 货品编码
	 */
	@NotBlank(message = "货品编码不能为空")
	private String itemCode;

	/**
	 * 包装单位
	 */
	@NotBlank(message = "包装单位不能为空")
	private String unit;

	/**
	 * 实际收货数量
	 */
	@NotBlank(message = "实际收货数量不能为空")
	private String receivedQty;

	/**
	 * 库存状态
	 */
	private String inventoryStatus;

	/**
	 * 存货日期
	 */

	private String storageDate;

	/**
	 * 入库时间
	 */

	private String Storagetime;

	/**
	 * 是否破损
	 */
	private String damage;

	/**
	 * 扩展字段1
	 */
	private String extendedField1;

	/**
	 * 扩展字段2
	 */
	private String extendedField2;

	/**
	 * 批次号
	 */
	private InboundFeedbackLotInfo lotInfo;

}
