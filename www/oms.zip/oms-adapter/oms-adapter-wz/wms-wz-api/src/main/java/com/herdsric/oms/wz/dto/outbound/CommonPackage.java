package com.herdsric.oms.wz.dto.outbound;

import com.herdsric.oms.common.core.validation.RegexpConstants;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.util.List;

@Data
public class CommonPackage {

	/**
	 * 货主编码
	 */
	@NotBlank(message = "货主代码不能为空")
	private String companyCode;

	/**
	 * 仓库编码
	 */
	@NotBlank(message = "仓库代码不能为空")
	private String warehouseCode;

	/**
	 * 出库单据号
	 */
	@NotBlank(message = "出库单不能为空")
	private String outboundNo;

	private String isDangerous;

	/**
	 * 快递单号进度查询地址
	 */
	private String expressTracingNo;

	@Valid
	@NotNull(message = "包装信息不能为空")
	private List<CommonPackageItem> details;

	@NotNull(message = "包裹序号,不能为空")
	private Integer serialNumber;

	@Pattern(regexp = RegexpConstants.Y_N, message = "是否最后一个包裹,必须为:Y/N ")
	private String isFinished;

	// @formatter:off
	/**
	 * {
	 *     "serialNumber": "2",
	 *     "isFinished": "Y",
	 *     "warehouseCode": "FLKF",
	 *     "companyCode": "SAIC",
	 *     "outboundNo": "5A9012522930-1",
	 *     "details": [
	 *         {
	 *             "lineNo": "00000000",
	 *             "itemCode": "00000000",
	 *             "unit": "PCS",
	 *             "PackQty": "1.0",
	 *             "boxNo": "00000000",
	 *             "length": "1.0",
	 *             "width": "1.0",
	 *             "height": "1.0",
	 *             "weight": "1.0",
	 *             "netweight": "1.0",
	 *             "Packagingtime": "2025-01-01 01:00:00",
	 *             "Packingtype": "PACL"
	 *         }
	 *     ]
	 * }
	 */
	// @formatter:on
	public void checkValid() {
	}

}
