package com.herdsric.oms.wz.dto.inbound;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.convert.Convert;
import cn.hutool.core.util.RandomUtil;
import cn.hutool.core.util.StrUtil;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.herdsric.oms.common.wms.common.CommonStatusEnum;
import com.herdsric.oms.common.wms.inbound.dto.InboundDTO;
import com.herdsric.oms.common.wms.inbound.dto.InboundLineDTO;
import com.herdsric.oms.wz.WzConstant;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.ArrayList;
import java.util.List;

@Data
@EqualsAndHashCode(callSuper = true)
public class Inbound extends CommonInbound {

	@JsonProperty("UUID")
	private String uuid = RandomUtil.randomString(16);

	@JsonProperty(index = 3)
	private String orderType;

	@JsonProperty(index = 5)
	private String estimateDate;

	@JsonProperty(index = 6)
	private String supplierCode;

	@JsonProperty(index = 7)
	private String remark;

	@JsonProperty(index = 8)
	private String status;

	@JsonProperty(index = 9)
	private String extendedField1;

	@JsonProperty(index = 10)
	private String extendedField2;

	@JsonProperty(index = 11)
	private List<InBoundDetails> details;

	public static Inbound convert(InboundDTO inboundDTO) {
		Inbound inbound = BeanUtil.copyProperties(inboundDTO, Inbound.class);
		inbound.setUuid(RandomUtil.randomString(16));
		inbound.setCompanyCode(inboundDTO.getClientCode());
		inbound.setWarehouseCode(inboundDTO.getWarehouseCode());
		inbound.setInboundNo(inboundDTO.getInboundNo());
		inbound.setOrderType(inboundDTO.getType());
		if (StrUtil.contains(inboundDTO.getInboundNo(), WzConstant.RETURN)) {
			inbound.setOrderType("YCRK");
		}
		inbound.setEstimateDate(inboundDTO.getEstimateTime());
		inbound.setSupplierCode("");
		inbound.setRemark(Convert.toStr(inboundDTO.getRemark(), ""));
		inbound.setStatus(CommonStatusEnum.N.name());
		inbound.setExtendedField1("");
		inbound.setExtendedField2("");

		List<InBoundDetails> inBoundDetailsList = new ArrayList<>();
		for (InboundLineDTO inboundLine : inboundDTO.getInboundLines()) {
			InBoundDetails inBoundDetail = new InBoundDetails();
			inBoundDetail.setLineNo(inboundLine.getLineNo());
			inBoundDetail.setItemCode(inboundLine.getItemCode());
			inBoundDetail.setUnit(inboundLine.getUnit());
			inBoundDetail.setPackQty(inboundLine.getPackQty());
			inBoundDetail.setBoxNo(inboundDTO.getContainerNo());
			inBoundDetail.getLotInfo().setEuhsCode(Convert.toStr(inboundLine.getEuHsCode(), ""));
			inBoundDetail.getLotInfo().setExtendedField2(Convert.toStr(inboundLine.getVin(), ""));
			inBoundDetailsList.add(inBoundDetail);
		}

		inbound.setDetails(inBoundDetailsList);
		return inbound;
	}

}