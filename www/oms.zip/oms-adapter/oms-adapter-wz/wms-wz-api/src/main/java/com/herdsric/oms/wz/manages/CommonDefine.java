package com.herdsric.oms.wz.manages;

import cn.hutool.core.util.StrUtil;
import com.herdsric.oms.common.client.common.BaseDefine;
import com.herdsric.oms.wz.WzConstant;

public class CommonDefine implements BaseDefine {

	@Override
	public boolean isSupport(String wmsType) {
		return StrUtil.equals(WzConstant.WMS_TYPE, wmsType);
	}

}
