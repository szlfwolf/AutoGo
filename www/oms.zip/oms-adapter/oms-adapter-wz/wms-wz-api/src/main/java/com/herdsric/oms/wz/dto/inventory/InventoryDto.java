package com.herdsric.oms.wz.dto.inventory;

import lombok.Data;

@Data
public class InventoryDto {

	private String clientCode;

	private String warehouseCode;

	private String itemCode;

	private String itemName;

	private String unit;

	private Integer totalQty;

	private Integer qualifiedTotalQty;

	private Integer availableQty;

}
