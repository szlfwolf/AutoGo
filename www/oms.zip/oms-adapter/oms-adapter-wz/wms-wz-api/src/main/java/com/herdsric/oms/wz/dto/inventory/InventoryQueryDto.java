package com.herdsric.oms.wz.dto.inventory;

import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class InventoryQueryDto {

	@NotBlank(message = "clientCode is not blank or empty")
	private String clientCode;

	@NotBlank(message = "warehouseCode is not blank or empty")
	private String warehouseCode;

	private String partNumber;

	/**
	 * 快照版本时间，不传默认查询最新版本
	 */
	private String date;

	// 上汽汽车配件
	// 爱驰
	// 长城
	// 小鹏
	// 蔚来
	// Lux-mate
	// 莲花
	// ZEEKR

	// Mijdrecht
	// Bellsingle
	// 荷兰阿姆斯特丹配件仓库
	// 乐世汽车配件德国仓
	public void check() {

	}

}
