package com.herdsric.oms.wz.dto.item;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class CommonProduct {

	@JsonProperty(index = 1)
	protected String warehouseCode;

	@JsonProperty(index = 2)
	protected String companyCode;

	@JsonProperty(index = 3)
	protected String code;

	@JsonProperty(index = 4)
	protected String name;

}
