package com.herdsric.oms.wz.dto.inbound;

import lombok.Data;

import java.io.Serializable;

@Data
public class InboundFeedbackLotInfo implements Serializable {

	/**
	 * 批次号
	 */
	private String lot;

	/**
	 * 生产日期
	 */
	private String productDate;

	/**
	 * 供应商编码
	 */
	private String supplierCode;

	/**
	 * 扩展字段1
	 */
	private String extendedField1;

	/**
	 * 扩展字段2
	 */
	private String extendedField2;

}
