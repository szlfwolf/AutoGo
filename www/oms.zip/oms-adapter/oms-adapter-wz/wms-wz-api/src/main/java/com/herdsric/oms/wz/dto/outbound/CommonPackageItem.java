package com.herdsric.oms.wz.dto.outbound;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.herdsric.oms.common.client.enums.UnitEnum;
import com.herdsric.oms.common.core.validation.RegexpConstants;
import com.herdsric.oms.common.core.validation.constraints.EnumCheck;
import com.herdsric.oms.wz.enums.PackageTypeEnum;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

@Data
public class CommonPackageItem {

	/**
	 * 明细行号
	 */
	private String lineNo;

	/**
	 * 货品编码
	 */
	@NotBlank(message = "货品编码不能为空")
	private String itemCode;

	/**
	 * 包装单位
	 */
	@NotBlank(message = "包装单位不能为空")
	@EnumCheck(value = UnitEnum.class, message = "包装单位格式错误")
	private String unit;

	/**
	 * 包装数量
	 */
	@JsonProperty("PackQty")
	@Pattern(regexp = "^[1-9]\\d*\\.\\d*|0\\.\\d*[1-9]\\d*|[1-9]\\d*$", message = "包装数量必须为正整数或者正浮点数")
	private String packQty;

	/**
	 * 周转箱号
	 */
	@NotBlank(message = "周转箱号不能为空")
	private String boxNo;

	/**
	 * 长
	 */
	@Pattern(regexp = "^[1-9]\\d*\\.\\d*|0\\.\\d*[1-9]\\d*|[1-9]\\d*$", message = "长度必须为正整数或者正浮点数")
	private String length = "0";

	/**
	 * 宽
	 */
	@Pattern(regexp = "^[1-9]\\d*\\.\\d*|0\\.\\d*[1-9]\\d*|[1-9]\\d*$", message = "宽度必须为正整数或者正浮点数")
	private String width = "0";

	/**
	 * 高
	 */
	@Pattern(regexp = "^[1-9]\\d*\\.\\d*|0\\.\\d*[1-9]\\d*|[1-9]\\d*$", message = "高度必须为正整数或者正浮点数")
	private String height = "0";

	/**
	 * 毛重
	 */
	@Pattern(regexp = "^[1-9]\\d*\\.\\d*|0\\.\\d*[1-9]\\d*|[1-9]\\d*$", message = "毛重必须为正整数或者正浮点数")
	private String weight = "0";

	/**
	 * 净重
	 */
	@JsonProperty("netweight")
	@Pattern(regexp = "^[1-9]\\d*\\.\\d*|0\\.\\d*[1-9]\\d*|[1-9]\\d*$", message = "净重必须为正整数或者正浮点数")
	private String netWeight = "0";

	/**
	 * 包装时间
	 */
	@JsonProperty("Packagingtime")
	@Pattern(regexp = RegexpConstants.YYYY_MM_DD_TIME, message = "包装时间格式错误")
	private String packagingTime;

	/**
	 * 包装类型 PLT/PACL/SPLT
	 */
	@JsonProperty("Packingtype")
	@NotBlank(message = "包装类型不能为空")
	@EnumCheck(value = PackageTypeEnum.class, message = "包装信息格式必须为PLT/PACL/SPLT")
	private String packingType;

}
