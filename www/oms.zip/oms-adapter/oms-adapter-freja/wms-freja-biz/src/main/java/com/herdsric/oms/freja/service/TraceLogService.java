package com.herdsric.oms.freja.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.IService;
import com.herdsric.oms.freja.entity.TraceLog;

import java.util.List;
import java.util.function.Function;

public interface TraceLogService extends IService<TraceLog> {

	boolean batchSaveOrUpdate(List<TraceLog> list, Function<TraceLog, LambdaQueryWrapper<TraceLog>> function);

	void saveBatch(List<TraceLog> list);

	/**
	 * 拉取指定次数推送失败的请求，重新上传
	 * @param type
	 * @param size
	 * @return
	 */
	List<TraceLog> selectTraceLogs(String type, int size);

}
