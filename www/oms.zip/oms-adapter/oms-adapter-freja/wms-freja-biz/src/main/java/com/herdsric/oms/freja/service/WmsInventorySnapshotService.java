package com.herdsric.oms.freja.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.herdsric.oms.freja.entity.WmsInventorySnapshot;

import java.util.List;

public interface WmsInventorySnapshotService extends IService<WmsInventorySnapshot> {

	void saveBatch(List<WmsInventorySnapshot> list);

	void physicsDelete(String clientCode, String warehouseCode, String date);

}
