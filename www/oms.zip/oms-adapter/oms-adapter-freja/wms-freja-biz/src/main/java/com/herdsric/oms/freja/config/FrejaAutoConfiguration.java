package com.herdsric.oms.freja.config;

import com.herdsric.oms.freja.sftp.ConnectionPool;
import com.herdsric.oms.freja.sftp.ShellProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * TODO
 *
 * @author 52423
 * @date 2022-08-31 18:40
 */
@Configuration
@EnableConfigurationProperties({ ShellProperties.class })
public class FrejaAutoConfiguration {

	@Bean
	public ConnectionPool connectionPool(ShellProperties shellProperties) {
		return new ConnectionPool(shellProperties);
	}

}
