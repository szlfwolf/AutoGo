package com.herdsric.oms.freja.enums;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.text.StrPool;
import cn.hutool.core.util.StrUtil;
import net.dreamlu.mica.core.utils.DatePattern;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public enum TypeEnum {

	ITEM_CODE("ITEM_CODE_SYNC", "MM_{}_{}_{}.json", DirectionEnum.OUT),
	INBOUND("INBOUND_SYNC", "ASN_{}_{}_{}.json", DirectionEnum.OUT),
	OUTBOUND("OUTBOUND_SYNC", "DN_{}_{}_{}.json", DirectionEnum.OUT),

	STOCK_SNAPSHOT("STOCK_SNAPSHOT", "StockInhandReport_{}_{}_{}.json", DirectionEnum.IN);

	public String bizType;

	public String nameFormat;

	public DirectionEnum direction;

	TypeEnum(String bizType, String nameFormat, DirectionEnum direction) {
		this.bizType = bizType;
		this.nameFormat = nameFormat;
		this.direction = direction;
	}

	public static List<String> listDirections(DirectionEnum out) {
		return Arrays.stream(TypeEnum.values()).filter(x -> x.direction.equals(out)).map(x -> x.bizType)
				.collect(Collectors.toList());
	}

	public String generateFileName(String orderNum, LocalDateTime dateTime) {
		String dateStr = DateUtil.format(dateTime, "yyyyMMdd");
		String timeStr = DateUtil.format(dateTime, "HHmmss");
		if (StrUtil.isNotBlank(orderNum)) {
			return StrUtil.format(nameFormat, orderNum, dateStr, timeStr);
		}

		return StrUtil.format(nameFormat, dateStr, timeStr);
	}

	/**
	 * 获取文件名中的日期字符串 yyyy-MM-dd(暂时只适用于STOCK_SNAPSHOT)
	 * @param fileName
	 * @return
	 */
	public String getDate(String fileName) {
		if (this != STOCK_SNAPSHOT) {
			return null;
		}
		if (StrUtil.isBlank(fileName)) {
			return null;
		}
		List<String> fileNameList = StrUtil.split(fileName, StrPool.UNDERLINE);
		if (fileNameList.size() == 4) {
			return DateUtil.format(
					DateUtil.parse(fileNameList.get(2), DatePattern.PURE_DATETIME_PATTERN,
							DatePattern.PURE_DATE_PATTERN).toLocalDateTime().minusDays(1),
					DatePattern.NORM_DATE_PATTERN);
		}
		return null;
	}

}
