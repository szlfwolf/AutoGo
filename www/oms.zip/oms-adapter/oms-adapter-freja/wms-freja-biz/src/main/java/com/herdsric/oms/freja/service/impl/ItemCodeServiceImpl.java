package com.herdsric.oms.freja.service.impl;

import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.freja.dto.item.Product;
import com.herdsric.oms.freja.enums.TypeEnum;
import com.herdsric.oms.freja.service.ItemCodeService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class ItemCodeServiceImpl implements ItemCodeService {

	private final FjWmsService fjWmsService;

	@Override
	public R pushWms(Product product) {
		return fjWmsService.generateFileByType(product, TypeEnum.ITEM_CODE);
	}

}
