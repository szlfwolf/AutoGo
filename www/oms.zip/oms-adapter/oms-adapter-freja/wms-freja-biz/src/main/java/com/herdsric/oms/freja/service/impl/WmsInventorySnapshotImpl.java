package com.herdsric.oms.freja.service.impl;

import cn.hutool.core.collection.CollectionUtil;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.herdsric.oms.freja.entity.WmsInventorySnapshot;
import com.herdsric.oms.freja.mapper.WmsInventorySnapshotMapper;
import com.herdsric.oms.freja.service.WmsInventorySnapshotService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class WmsInventorySnapshotImpl extends ServiceImpl<WmsInventorySnapshotMapper, WmsInventorySnapshot>
		implements WmsInventorySnapshotService {

	@Override
	public void saveBatch(List<WmsInventorySnapshot> list) {
		if (CollectionUtil.isNotEmpty(list)) {
			List<List<WmsInventorySnapshot>> splitList = CollectionUtil.split(list, 1000);
			for (List<WmsInventorySnapshot> subList : splitList) {
				this.baseMapper.insertBatch(subList);
			}
		}
	}

	@Override
	public void physicsDelete(String clientCode, String warehouseCode, String date) {
		this.baseMapper.physicsDeleteByCwd(clientCode, warehouseCode, date);
	}

}
