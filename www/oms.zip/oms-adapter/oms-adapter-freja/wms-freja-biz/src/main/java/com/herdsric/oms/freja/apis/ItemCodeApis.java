package com.herdsric.oms.freja.apis;

import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.common.wms.itemcode.dto.ItemCodeDTO;
import com.herdsric.oms.freja.dto.item.Product;
import com.herdsric.oms.freja.service.ItemCodeService;
import com.pig4cloud.plugin.idempotent.annotation.Idempotent;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/apis/item-code")
@Tag(name = "主数据对外接口")
public class ItemCodeApis {

	private final ItemCodeService itemCodeService;

	/**
	 * 零件下发WMS接口
	 * @param itemCodeDTO
	 * @return
	 */
	@Operation(summary = "零件下发WMS接口", description = "零件下发WMS接口")
	@PostMapping
	@Idempotent(key = "'itemCodeDTO-'+#itemCodeDTO.hashCode()", expireTime = 300, delKey = true,
			info = "Do not repeat the operation")
	public R add(@RequestBody ItemCodeDTO itemCodeDTO) {
		List<Product> products = Product.convert(Arrays.asList(itemCodeDTO));
		return itemCodeService.pushWms(products.get(0));
	}

}
