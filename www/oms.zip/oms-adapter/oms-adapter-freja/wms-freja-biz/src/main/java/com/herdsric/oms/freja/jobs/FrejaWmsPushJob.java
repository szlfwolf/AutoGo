package com.herdsric.oms.freja.jobs;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.herdsric.oms.common.core.constant.CommonConstants;
import com.herdsric.oms.common.job.common.AbstractCommonTask;
import com.herdsric.oms.common.mybatis.base.BaseEntity;
import com.herdsric.oms.freja.entity.SysFileLog;
import com.herdsric.oms.freja.enums.DirectionEnum;
import com.herdsric.oms.freja.enums.TypeEnum;
import com.herdsric.oms.freja.jobs.common.JobCommon;
import com.herdsric.oms.freja.service.ReadFileService;
import com.herdsric.oms.freja.service.SysFileLogService;
import com.herdsric.oms.freja.sftp.ConnectionPool;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @Author : liangzhenlei
 * @Date : 2024/4/17 17:03
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class FrejaWmsPushJob extends AbstractCommonTask {

	private final SysFileLogService sysFileLogService;

	private final ReadFileService readFileService;

	private final ConnectionPool connectionPool;

	/**
	 * 批量文件上传
	 */
	@XxlJob(JobCommon.JobName.PUSH_JSON_FILES_TO_WMS)
	public void batchPushJsonFiles() {
		this.execute(JobCommon.TaskEnum.PUSH_JSON_FILES_TO_WMS, x -> {
			List<String> types = TypeEnum.listDirections(DirectionEnum.OUT);
			for (String type : types) {
				LambdaQueryWrapper<SysFileLog> lambdaQueryWrapper = Wrappers.lambdaQuery();
				lambdaQueryWrapper.eq(SysFileLog::getStatus, CommonConstants.N);
				lambdaQueryWrapper.eq(SysFileLog::getDirection, DirectionEnum.OUT.name());
				lambdaQueryWrapper.lt(SysFileLog::getRetryNum, 3);
				lambdaQueryWrapper.eq(SysFileLog::getType, type);
				lambdaQueryWrapper.orderByAsc(BaseEntity::getUpdateTime);
				lambdaQueryWrapper.last("LIMIT 200");
				List<SysFileLog> sysFileLogs = sysFileLogService.list(lambdaQueryWrapper);
				for (SysFileLog sysFileLog : sysFileLogs) {
					long start = System.currentTimeMillis();
					try {
						boolean tag = connectionPool.upload(sysFileLog.getPath(), sysFileLog.getName(),
								sysFileLog.getLocalPath());
						if (tag) {
							sysFileLog.setStatus(CommonConstants.Y);
							sysFileLog.setMessage("上传成功");
						}
						else {
							sysFileLog.setStatus(CommonConstants.N);
							sysFileLog.setMessage("上传失败");
						}
					}
					catch (Exception e) {
						log.error("上传文件失败", e);
						sysFileLog.setStatus(CommonConstants.N);
						sysFileLog.setMessage(StrUtil.maxLength(e.getMessage(), 4000));
					}
					finally {
						sysFileLog.setCostTime(System.currentTimeMillis() - start);
						sysFileLog.setRetryNum(sysFileLog.getRetryNum() + 1);
					}
				}

				sysFileLogService.updateBatchById(sysFileLogs);
			}

		});
	}

	/**
	 * 批量下载文件
	 */
	@XxlJob(JobCommon.JobName.BATCH_DOWNLOAD_JSON_FILES)
	public void downloadJson() {
		this.execute(JobCommon.TaskEnum.BATCH_DOWNLOAD_JSON_FILES, x -> {
			List<String> types = TypeEnum.listDirections(DirectionEnum.IN);
			for (String type : types) {
				readFileService.downloadFiles(TypeEnum.valueOf(type));
			}
		});
	}

	/**
	 * 解析库存快照文件
	 */
	@XxlJob(JobCommon.JobName.READ_STOCK_FILE_JSON)
	public void parseStockJson() {
		this.execute(JobCommon.TaskEnum.READ_STOCK_FILE_JSON, x -> {
			List<String> types = TypeEnum.listDirections(DirectionEnum.IN);
			LambdaQueryWrapper<SysFileLog> lambdaQueryWrapper = Wrappers.lambdaQuery();
			lambdaQueryWrapper.eq(SysFileLog::getStatus, CommonConstants.N);
			lambdaQueryWrapper.eq(SysFileLog::getDirection, DirectionEnum.IN.name());
			lambdaQueryWrapper.lt(SysFileLog::getRetryNum, 3);
			lambdaQueryWrapper.in(SysFileLog::getType, types);
			lambdaQueryWrapper.orderByAsc(BaseEntity::getUpdateTime);
			lambdaQueryWrapper.last("LIMIT 1");

			List<SysFileLog> sysFileLogs = sysFileLogService.list(lambdaQueryWrapper);
			if (CollectionUtil.isEmpty(sysFileLogs)) {
				log.info("没有待解析的库存快照文件");
				return;
			}
			for (SysFileLog sysFileLog : sysFileLogs) {
				readFileService.readFiles(sysFileLog);
			}
		});
	}

}
