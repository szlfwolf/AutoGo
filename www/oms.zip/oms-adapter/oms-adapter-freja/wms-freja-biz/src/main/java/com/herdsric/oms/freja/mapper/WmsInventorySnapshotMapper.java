package com.herdsric.oms.freja.mapper;

import com.herdsric.oms.common.mybatis.base.RootMapper;
import com.herdsric.oms.freja.entity.WmsInventorySnapshot;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface WmsInventorySnapshotMapper extends RootMapper<WmsInventorySnapshot> {

	void physicsDeleteByCwd(@Param("clientCode") String clientCode, @Param("warehouseCode") String warehouseCode,
			@Param("date") String date);

}
