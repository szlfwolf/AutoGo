package com.herdsric.oms.freja.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.IService;
import com.herdsric.oms.freja.entity.SysFileLog;

import java.util.List;
import java.util.function.Function;

public interface SysFileLogService extends IService<SysFileLog> {

	boolean batchSaveOrUpdate(List<SysFileLog> list, Function<SysFileLog, LambdaQueryWrapper<SysFileLog>> function);

	void saveBatch(List<SysFileLog> list);

}
