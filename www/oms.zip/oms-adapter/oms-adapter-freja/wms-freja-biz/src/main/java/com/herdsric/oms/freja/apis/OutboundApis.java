package com.herdsric.oms.freja.apis;

import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.common.wms.outbound.dto.OutboundDTO;
import com.herdsric.oms.freja.dto.outbound.CommonPackage;
import com.herdsric.oms.freja.dto.outbound.OutBoundStatus;
import com.herdsric.oms.freja.dto.outbound.Outbound;
import com.herdsric.oms.freja.service.OutboundService;
import com.pig4cloud.plugin.idempotent.annotation.Idempotent;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping("/apis/outbound")
@Tag(name = "出库单对外接口")
public class OutboundApis {

	private final OutboundService outboundService;

	/**
	 * 出库单下发WMS接口
	 * @param outboundDTO
	 * @return
	 */
	@Operation(summary = "出库单下发WMS接口", description = "出库单下发WMS接口")
	@PostMapping
	@Idempotent(key = "'outboundDTO-'+#outboundDTO.hashCode()", expireTime = 300, delKey = true,
			info = "Do not repeat the operation")
	public R add(@RequestBody OutboundDTO outboundDTO) {
		Outbound outbound = Outbound.convert(outboundDTO);
		return outboundService.pushWms(outbound);
	}

	/**
	 * v2/freja/sendDnPackageTOPortal
	 * @param commonPackage
	 * @return
	 */
	@Operation(summary = "包装信息反馈", description = "包装信息反馈")
	@PostMapping("packaged")
	@Idempotent(key = "'commonPackage-'+#commonPackage.outboundNo", expireTime = 300, delKey = true,
			info = "Do not repeat the operation")
	public R outboundPackaged(@Validated @RequestBody CommonPackage commonPackage) {
		commonPackage.checkValid();
		return outboundService.packageInfoByWz(commonPackage);
	}

	/**
	 * v2/freja/sendDnStateTOPortal
	 * @param outBoundStatus
	 * @return
	 */
	@Operation(summary = "包装信息反馈", description = "包装信息反馈")
	@PostMapping("status")
	@Idempotent(key = "'outBoundStatus-'+#outBoundStatus.outboundNo", expireTime = 300, delKey = true,
			info = "Do not repeat the operation")
	public R outboundStatusFeedback(@Validated @RequestBody OutBoundStatus outBoundStatus) {
		outBoundStatus.checkValid();
		return outboundService.statusFeedback(outBoundStatus);
	}

}
