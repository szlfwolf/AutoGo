package com.herdsric.oms.freja.sftp;

import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.io.FileUtil;
import cn.hutool.core.util.RandomUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.extra.ssh.JschUtil;
import com.herdsric.oms.common.core.constant.CommonConstants;
import com.herdsric.oms.common.core.exception.ErrorCodeEnum;
import com.herdsric.oms.common.core.exception.OmsBusinessException;
import com.herdsric.oms.common.log.sftp.SftpLogProcessor;
import com.herdsric.oms.common.log.sftp.SftpProperties;
import com.herdsric.oms.freja.FrejaConstant;
import com.herdsric.oms.freja.entity.SysFileLog;
import com.jcraft.jsch.*;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import javax.annotation.PostConstruct;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

@Data
@Slf4j
public class ConnectionPool {

	private String strictHostKeyChecking;

	private Integer timeout;

	private ShellProperties shellProperties;

	/**
	 * host地址
	 */
	private String host = "";

	/**
	 * 端口号
	 */
	private Integer port = 22;

	/**
	 * 用户名
	 */
	private String username = "";

	/**
	 * 密码
	 */
	private String password = "";

	/**
	 * 每次扩容增加几个连接
	 */
	private int incrementalConnections = 2;

	/**
	 * 最大连接数
	 */
	private int maxConnections = 10;

	/**
	 * 最大空闲连接
	 */
	private int maxIdle = 5;

	/**
	 * 最小空闲连接
	 */
	private int minIdel = 3;

	private Vector<PooledConnection> connections = null;

	@PostConstruct
	private void init() {
		createPool();
	}

	public ConnectionPool(ShellProperties shellProperties) {
		this.shellProperties = shellProperties;
		this.host = shellProperties.getHost();
		this.port = shellProperties.getPort();
		this.username = shellProperties.getUsername();
		this.password = shellProperties.getPassword();
		this.incrementalConnections = shellProperties.getIncrementalConnections();
		this.maxConnections = shellProperties.getMaxConnections();
		this.strictHostKeyChecking = shellProperties.getStrictHostKeyChecking();
		this.timeout = shellProperties.getTimeout();
	}

	/**
	 * 构造方法
	 * @param strictHostKeyChecking 连接模式
	 * @param timeout 超时时间
	 */
	public ConnectionPool(String strictHostKeyChecking, Integer timeout) {
		this.strictHostKeyChecking = strictHostKeyChecking;
		this.timeout = timeout;
	}

	/**
	 * 构造方法
	 * @param strictHostKeyChecking 连接模式
	 * @param timeout 超时时间
	 * @param incrementalConnections 增量大小
	 */
	public ConnectionPool(String strictHostKeyChecking, Integer timeout, int incrementalConnections) {
		this.strictHostKeyChecking = strictHostKeyChecking;
		this.timeout = timeout;
		this.incrementalConnections = incrementalConnections;
	}

	/**
	 * 构造方法
	 * @param strictHostKeyChecking 连接模式
	 * @param timeout 超时时间
	 * @param incrementalConnections 增量大小
	 * @param maxConnections 连接池最大连接数
	 */
	public ConnectionPool(String strictHostKeyChecking, Integer timeout, int incrementalConnections,
			int maxConnections) {
		this.strictHostKeyChecking = strictHostKeyChecking;
		this.timeout = timeout;
		this.incrementalConnections = incrementalConnections;
		this.maxConnections = maxConnections;
	}

	/**
	 * 创建连接池，判断连接池是否创建，如果连接池没有创建则创建连接池
	 */
	public synchronized void createPool() {
		if (Objects.nonNull(connections)) {
			return;
		}
		connections = new Vector<>();
		log.info("create shell connectionPool success!");
	}

	/**
	 * 创建指定数量的连接放入连接池中
	 * @param numConnections 创建数量
	 * @throws JSchException 建立远程连接异常
	 */
	private void createConnections(int numConnections) throws JSchException {
		for (int x = 0; x < numConnections; x++) {

			// 判断是否已达连接池最大连接，如果到达最大连接数据则不再创建连接
			if (this.maxConnections > 0 && this.connections.size() >= this.maxConnections) {
				break;
			}

			// 在连接池中新增一个连接
			try {
				connections.addElement(new PooledConnection(newConnection(), host));
			}
			catch (JSchException e) {
				log.error("create shell connection failed {}", e.getMessage());
				throw new JSchException();
			}
			log.info("Session connected!");
		}
	}

	/**
	 * 新一个连接session
	 * @return 创建的session
	 * @throws JSchException 远程连接异常
	 */
	private Session newConnection() throws JSchException {
		// 创建一个session
		JSch jsch = new JSch();
		Session session = jsch.getSession(username, host, port);
		session.setPassword(password);
		Properties sshConfig = new Properties();
		sshConfig.put("StrictHostKeyChecking", strictHostKeyChecking);
		session.setConfig(sshConfig);
		session.connect(timeout);
		session.setTimeout(60 * 1000);
		session.setServerAliveInterval(1800);
		return session;
	}

	/**
	 * 获取一个可用session
	 * @return 可用的session
	 * @throws JSchException 远程连接异常
	 */
	public synchronized Session getConnection() throws JSchException {
		// 连接池还没创建，则返回 null
		if (Objects.isNull(connections)) {
			return null;
		}

		// 获得一个可用的数据库连接
		Session session = getFreeConnection();

		// 假如目前没有可以使用的连接，即所有的连接都在使用中，等一会重试
		while (Objects.isNull(session)) {
			wait(250);
			session = getFreeConnection();
		}

		return session;
	}

	/**
	 * 获取一个可用session
	 * @return 返回可用session
	 * @throws JSchException 远程连接异常
	 */
	private Session getFreeConnection() throws JSchException {
		Session session = findFreeConnection();
		// 如果没有可用连接，则创建连接，
		if (Objects.isNull(session)) {
			createConnections(incrementalConnections);
			session = findFreeConnection();
			if (Objects.isNull(session)) {
				return null;
			}
		}
		return session;
	}

	/**
	 * 查找可用连接
	 * @return 返回可用连接
	 */
	private synchronized Session findFreeConnection() {
		Session session = null;
		PooledConnection conn;

		Enumeration<PooledConnection> enumerate = connections.elements();

		// 遍历所有的对象，看是否有可用的连接
		while (enumerate.hasMoreElements()) {
			conn = enumerate.nextElement();
			if (!host.equals(conn.getTag())) {
				continue;
			}
			if (!conn.isBusy()) {
				session = conn.getSession();
				conn.setBusy(true);
				if (!testConnection(session)) {
					try {
						session = newConnection();
					}
					catch (JSchException e) {
						log.error("create shell connection failed {}", e.getMessage());
						return null;
					}
					conn.setSession(session);
				}
				break;
			}
		}
		return session;
	}

	/**
	 * 测试连接是否可用
	 * @param session 需要测试的session
	 * @return 是否可用
	 */
	private boolean testConnection(Session session) {
		boolean connected = session.isConnected();
		if (!connected) {
			closeConnection(session);
			return false;
		}
		return true;
	}

	/**
	 * 将session放回连接池中
	 * @param session 需要放回连接池中的session
	 */
	public synchronized void returnConnection(Session session) {
		// 确保连接池存在，假如连接没有创建（不存在），直接返回
		if (Objects.isNull(connections)) {
			log.error("ConnectionPool does not exist");
			return;
		}
		PooledConnection conn;
		Enumeration<PooledConnection> enumerate = connections.elements();

		// 遍历连接池中的所有连接，找到这个要返回的连接对象，将状态设置为空闲
		while (enumerate.hasMoreElements()) {
			conn = enumerate.nextElement();
			if (session.equals(conn.getSession())) {
				// conn.getSession().disconnect();
				// connections.remove(conn);
				conn.setBusy(false);
			}
		}

	}

	/**
	 * 刷新连接池
	 * @throws JSchException 远程连接异常
	 */
	public synchronized void refreshConnections() throws JSchException {
		// 确保连接池己创新存在
		if (Objects.isNull(connections)) {
			log.error("ConnectionPool does not exist");
			return;
		}
		PooledConnection conn;
		Enumeration<PooledConnection> enumerate = connections.elements();
		while (enumerate.hasMoreElements()) {
			conn = enumerate.nextElement();
			if (conn.isBusy()) {
				wait(5000);
			}
			closeConnection(conn.getSession());
			conn.setSession(newConnection());
			conn.setBusy(false);
		}
	}

	/**
	 * 关闭连接池
	 */
	public synchronized void closeConnectionPool() {
		// 确保连接池存在，假如不存在，返回
		if (Objects.isNull(connections)) {
			log.info("Connection pool does not exist");
			return;
		}
		PooledConnection conn;
		Enumeration<PooledConnection> enumerate = connections.elements();
		while (enumerate.hasMoreElements()) {
			conn = enumerate.nextElement();
			if (conn.isBusy()) {
				wait(5000);
			}
			closeConnection(conn.getSession());
			connections.removeElement(conn);
		}
		connections = null;
	}

	/**
	 * 关闭session会话
	 * @param session 需要关闭的session
	 */
	private void closeConnection(Session session) {
		session.disconnect();
	}

	/**
	 * 线程暂停
	 * @param mSeconds 暂停时间
	 */
	private void wait(int mSeconds) {
		try {
			Thread.sleep(mSeconds);
		}
		catch (InterruptedException e) {
			log.error("{} 线程暂停失败 -> {}", Thread.currentThread().getName(), e.getMessage());
		}
	}

	// TODO 后续有用到再加
	public boolean batchUpload(String path, String name, List<File> files) {
		Session session = null;
		try {
			session = getConnection();
			ChannelSftp channelSftp = JschUtil.openSftp(session, 60000);
			if (StrUtil.isNotBlank(path)) {
				channelSftp.cd(path);
			}
			for (File file : files) {
				channelSftp.put(new FileInputStream(file), name);
			}
			return true;
		}
		catch (Exception e) {
			log.error("path:{},name:{},上传失败", path, name, e);
			return false;
		}
		finally {
			if (session != null) {
				returnConnection(session);
			}
		}
	}

	public boolean upload(String path, String name, String localPath) {
		SftpProperties sftpProperties = new SftpProperties();
		sftpProperties.setHost(host);
		sftpProperties.setLocalPath(localPath);
		sftpProperties.setLocalName(name);
		sftpProperties.setPath(path);
		sftpProperties.setName(name);

		return SftpLogProcessor.apply(sftpProperties, x -> {
			Session session = null;
			ChannelSftp channelSftp = null;
			try {
				session = getConnection();
				channelSftp = JschUtil.openSftp(session, 30000);
				if (StrUtil.isNotBlank(path)) {
					channelSftp.cd(path);
				}
				File file = FileUtil.file(localPath + name);

				channelSftp.put(new FileInputStream(file), name);
				log.info("path:{},name:{},上传成功,本地备份文件：{}", path, name, name);
				return true;
			}
			catch (Exception e) {
				log.error("path:{},name:{},上传失败", path, name, e);
				throw new OmsBusinessException(ErrorCodeEnum.E999999.code, e.getMessage());
			}
			finally {
				if (channelSftp != null) {
					channelSftp.disconnect();
				}
				if (session != null) {
					returnConnection(session);
				}
			}
		});
	}

	public List<SysFileLog> down(String path, String regex, String localPath, String type) {
		List<SysFileLog> ftpLogs = new ArrayList<>();

		SftpProperties sftpProperties = new SftpProperties();
		sftpProperties.setHost(host);
		sftpProperties.setLocalPath(localPath);
		sftpProperties.setPath(path);

		Map<String, SftpATTRS> fileMap = new HashMap<>();

		Session session = null;
		ChannelSftp channelSftp = null;
		try {
			session = getConnection();
			channelSftp = JschUtil.openSftp(session);
			if (StrUtil.isNotBlank(path)) {
				channelSftp.cd(path);
			}

			channelSftp.ls(path, v -> {
				log.info("Download 匹配规则：{},读取的文件清单：{}", regex, v);
				boolean flag = v != null && v.getAttrs().getSize() > 0 && v.getFilename().matches(regex);
				if (flag) {
					fileMap.put(v.getFilename(), v.getAttrs());
				}
				return ChannelSftp.LsEntrySelector.CONTINUE;
			});

			String batchNo = RandomUtil.randomString(64);
			log.info("SFTP-DOWN:{},可以下载的文件数量：{}", path, fileMap.size());

			// 创建文件夹
			File dirFile = new File(localPath);
			if (!dirFile.exists()) {
				dirFile.mkdirs();
			}
			for (String fileName : fileMap.keySet()) {
				sftpProperties.setLocalName(fileName);
				sftpProperties.setName(fileName);
				// 创建文件
				File file = FileUtil.file(localPath + fileName);
				channelSftp.get(fileName, new FileOutputStream(file));
				ChannelSftp finalChannelSftp = channelSftp;
				SftpLogProcessor.apply(sftpProperties, x -> {
					AtomicBoolean isSuccess = new AtomicBoolean();
					try {
						long fileDownStart = System.currentTimeMillis();

						SysFileLog ftpLog = new SysFileLog();
						ftpLog.setSource(CommonConstants.COMPANY_CODE_NIO);
						ftpLog.setTarget(FrejaConstant.WMS_TYPE);
						ftpLog.setDirection("IN");
						ftpLog.setType(type);
						ftpLog.setLocalName(fileName);
						ftpLog.setLocalPath(localPath);
						ftpLog.setName(fileName);
						ftpLog.setPath(path);
						ftpLog.setReference(fileName);
						ftpLog.setSize(fileMap.get(fileName).getSize());
						ftpLog.setLastModifiedDate(new Date(fileMap.get(fileName).getMTime() * 1000L));
						ftpLog.setStatus(CommonConstants.N);
						ftpLog.setBatchNo(batchNo);
						ftpLog.setCostTime(System.currentTimeMillis() - fileDownStart);
						ftpLog.setMessage("文件下载成功");
						ftpLog.setRetryNum(0);
						ftpLogs.add(ftpLog);
						isSuccess.compareAndSet(false, true);

						log.info("SFTP-DOWN:{},文件：{}下载成功", path, fileName);
						// finalChannelSftp.put(file.getAbsolutePath(), remotePathBak +
						// fileName, ChannelSftp.OVERWRITE);
						// log.info("SFTP-DOWN:{},文件：{}备份成功 {}", path, fileName,
						// remotePathBak + fileName);
						finalChannelSftp.rm(fileName);
						log.info("SFTP-DOWN:{},文件：{}文件删除成功", path, fileName);
					}
					catch (Exception e) {
						log.error(e.getMessage(), e);
					}

					return isSuccess.get();
				});
			}
			return ftpLogs;
		}
		catch (Exception e) {
			log.error(e.getMessage(), e);
			return ftpLogs;
		}
		finally {
			if (channelSftp != null) {
				channelSftp.disconnect();
			}
			if (session != null) {
				returnConnection(session);
			}
		}

	}

	/**
	 * 对象连接状态
	 */
	@Data
	static class PooledConnection {

		/**
		 * 远程连接
		 */
		Session session;

		/**
		 * 此连接是否正在使用的标志，默认没有正在使用
		 */
		boolean busy = false;

		/**
		 * 连接标记
		 */
		String tag;

		/**
		 * 构造函数，根据一个 Session 构造一个 PooledConnection 对象
		 * @param session 连接
		 * @param tag 连接标记
		 */
		public PooledConnection(Session session, String tag) {
			this.session = session;
			this.tag = tag;
		}

	}

	public static String longToDate(long time) {
		return DateUtil.format(new Date(time), DatePattern.NORM_DATETIME_PATTERN);
	}

}
