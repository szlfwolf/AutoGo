package com.herdsric.oms.freja.service.impl;

import com.herdsric.oms.common.core.constant.SecurityConstants;
import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.common.feign.wms.RemoteInboundService;
import com.herdsric.oms.common.wms.inbound.domain.InboundFeedbackDm;
import com.herdsric.oms.freja.dto.inbound.Inbound;
import com.herdsric.oms.freja.dto.inbound.InboundFeedback;
import com.herdsric.oms.freja.enums.TypeEnum;
import com.herdsric.oms.freja.service.InboundService;
import com.herdsric.oms.freja.utils.InboundUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class InboundServiceImpl implements InboundService {

	private final RemoteInboundService remoteInboundService;

	private final FjWmsService fjWmsService;

	@Override
	public R postbackAsn(InboundFeedback inboundFeedback) {
		InboundFeedbackDm inboundFeedbackDm = InboundUtil.convertInboundFeedback(inboundFeedback);
		R result = remoteInboundService.feedback(inboundFeedbackDm, inboundFeedbackDm.getClientCode(),
				SecurityConstants.FROM_IN);
		return result;
	}

	@Override
	public R pushWms(Inbound inbound) {
		return fjWmsService.generateFileByType(inbound, TypeEnum.INBOUND);
	}

}
