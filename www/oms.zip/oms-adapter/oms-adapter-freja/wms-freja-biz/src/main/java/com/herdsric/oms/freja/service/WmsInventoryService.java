package com.herdsric.oms.freja.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.herdsric.oms.freja.dto.inventory.InventoryQueryDto;
import com.herdsric.oms.freja.entity.WmsInventory;

import java.util.List;

public interface WmsInventoryService extends IService<WmsInventory> {

	void saveBatch(List<WmsInventory> list);

	boolean batchUpdateStocks(String date, List<WmsInventory> wmsInventorys);

	Object queryList(InventoryQueryDto inventoryQueryDto);

}
