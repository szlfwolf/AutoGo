package com.herdsric.oms.freja.service;

import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.freja.dto.outbound.*;

public interface OutboundService {

	R packageInfoByWz(CommonPackage commonPackage);

	R pushWms(Outbound outbound);

	R statusFeedback(OutBoundStatus outBoundStatus);

}
