package com.herdsric.oms.freja.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.convert.Convert;
import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.NumberUtil;
import cn.hutool.core.util.StrUtil;
import com.herdsric.oms.common.core.constant.SecurityConstants;
import com.herdsric.oms.common.core.exception.ErrorCodeEnum;
import com.herdsric.oms.common.core.exception.OmsBusinessException;
import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.common.feign.tms.RemoteJobTransportService;
import com.herdsric.oms.common.feign.wms.RemoteOutboundService;
import com.herdsric.oms.common.tms.transport.*;
import com.herdsric.oms.common.wms.outbound.domain.OutboundFeedbackDm;
import com.herdsric.oms.common.wms.outbound.enums.OutboundStatusEnum;
import com.herdsric.oms.freja.FrejaConstant;
import com.herdsric.oms.freja.dto.outbound.CommonPackage;
import com.herdsric.oms.freja.dto.outbound.OutBoundStatus;
import com.herdsric.oms.freja.dto.outbound.Outbound;
import com.herdsric.oms.freja.dto.outbound.PackageDetailDto;
import com.herdsric.oms.freja.enums.TypeEnum;
import com.herdsric.oms.freja.service.OutboundService;
import com.herdsric.oms.freja.utils.OutboundUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Arrays;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class OutboundServiceImpl implements OutboundService {

	private final RemoteOutboundService remoteOutboundService;

	private final RemoteJobTransportService remoteJobTransportService;

	private final FjWmsService fjWmsService;

	@Override
	public R packageInfoByWz(CommonPackage commonPackage) {
		// todo 打包反馈 按照箱子拆分反馈OMS(是否危险品 包裹序号 是否结束)
		OutboundFeedbackDm outboundFeedbackDm = OutboundUtil.convertCommonPackageToOutboundFeedbackDm(commonPackage);

		return remoteOutboundService.feedback(outboundFeedbackDm, outboundFeedbackDm.getClientCode(),
				SecurityConstants.FROM_IN);
	}

	@Override
	public R pushWms(Outbound outbound) {
		return fjWmsService.generateFileByType(outbound, TypeEnum.OUTBOUND);
	}

	//@formatter:off
	@Override
	public R statusFeedback(OutBoundStatus outBoundStatus) {
		// // todo 模拟TPT 推送OMS
		// statusMap.put("50", OutboundStatusEnum.BOOKED.name());
		// statusMap.put("60", OutboundStatusEnum.OUTBOUND.name());
		// statusMap.put("70", OutboundStatusEnum.FINISHED.name());

		if (StrUtil.equals(outBoundStatus.getOutboundStatus(), OutboundStatusEnum.BOOKED.name())) {
			DateTime buDate = DateUtil.parse(outBoundStatus.getBuDate(), DatePattern.NORM_DATETIME_PATTERN, DatePattern.PURE_DATETIME_PATTERN);
			JobBookDm jobBookDm = new JobBookDm();

			jobBookDm.setClientCode(outBoundStatus.getCompanyCode());
			jobBookDm.setBookingTime(DateUtil.format(buDate, DatePattern.NORM_DATETIME_PATTERN));
			jobBookDm.setServiceType(StrUtil.isBlank(outBoundStatus.getExpressCompany()) ? FrejaConstant.FREJA_DEFAULT_CARRIER_CODE : outBoundStatus.getExpressCompany());
			jobBookDm.setCarrierCode(StrUtil.isBlank(outBoundStatus.getExpressCompany()) ? FrejaConstant.FREJA_DEFAULT_CARRIER_CODE : outBoundStatus.getExpressCompany());
			jobBookDm.setWarehouseCode(outBoundStatus.getWarehouseCode());
			jobBookDm.setWaybillNo(outBoundStatus.getOutboundNo());
			jobBookDm.setTaskNoList(Arrays.asList(outBoundStatus.getOutboundNo()));
			jobBookDm.setTracingLink(StrUtil.isBlank(outBoundStatus.getRemark2()) ? outBoundStatus.getExpressTracingNo() : outBoundStatus.getRemark2());
			return remoteJobTransportService.book(jobBookDm, outBoundStatus.getCompanyCode(), SecurityConstants.FROM_IN);

		} else if (StrUtil.equals(outBoundStatus.getOutboundStatus(), OutboundStatusEnum.OUTBOUND.name())) {
			//TODO Freja 暂时没有Loaded节点，Outbound:直接更新Loaded,Outbound
			DateTime buDate = DateUtil.parse(outBoundStatus.getBuDate(), DatePattern.NORM_DATETIME_PATTERN, DatePattern.PURE_DATETIME_PATTERN);

			JobLoadedDm jobLoadedDm = new JobLoadedDm();
			jobLoadedDm.setClientCode(outBoundStatus.getCompanyCode());
			jobLoadedDm.setLoadedTime(DateUtil.format(buDate, DatePattern.NORM_DATETIME_PATTERN));
			jobLoadedDm.setWarehouseCode(outBoundStatus.getWarehouseCode());
			jobLoadedDm.setTaskNoList(Arrays.asList(outBoundStatus.getOutboundNo()));
			remoteJobTransportService.loaded(jobLoadedDm, outBoundStatus.getCompanyCode(), SecurityConstants.FROM_IN);

			JobPickUpDm jobPickUpDm = new JobPickUpDm();
			jobPickUpDm.setClientCode(outBoundStatus.getCompanyCode());
			jobPickUpDm.setOutboundTime(DateUtil.format(buDate, DatePattern.NORM_DATETIME_PATTERN));
			jobPickUpDm.setWarehouseCode(outBoundStatus.getWarehouseCode());
			jobPickUpDm.setVehicleNo(outBoundStatus.getOutboundNo());
			jobPickUpDm.setTaskNoList(Arrays.asList(outBoundStatus.getOutboundNo()));

			List<PackageDm> packageDms = CollectionUtil.newArrayList();
			if (CollectionUtil.isNotEmpty(outBoundStatus.getPackageDetails())) {
				for (PackageDetailDto box : outBoundStatus.getPackageDetails()) {
					PackageDm packageDm  = BeanUtil.copyProperties(box, PackageDm.class);
					packageDm.setPackageNo(box.getBoxNo());
					packageDm.setLength(String.valueOf((Convert.toDouble(box.getLength(), 0D) / 1000)));
					packageDm.setWidth(String.valueOf(Convert.toDouble(box.getWidth(), 0D) / 1000));
					packageDm.setHeight(String.valueOf(Convert.toDouble(box.getHeight(), 0D) / 1000));
					packageDm.setNetWeight(String.valueOf(Convert.toDouble(box.getNetWeight(), 0D)));
					packageDm.setGrossWeight(String.valueOf(Convert.toDouble(box.getWeight(), 0D)));
					packageDm.setPackageType(box.getPackingType());
					packageDm.setCbm(NumberUtil.mul(box.getLength(), box.getWidth(), box.getHeight()).divide(BigDecimal.valueOf(1000000000), 8, RoundingMode.HALF_UP).stripTrailingZeros().toPlainString());
					packageDms.add(packageDm);
				}
			}
			jobPickUpDm.setPackages(packageDms);

			return remoteJobTransportService.pickUp(jobPickUpDm, outBoundStatus.getCompanyCode(), SecurityConstants.FROM_IN);
		} else if (StrUtil.equals(outBoundStatus.getOutboundStatus(), OutboundStatusEnum.FINISHED.name())) {
			//TODO Freja 暂时没有Arrived节点，FINISHED:直接更新Arrived,Finished
			DateTime buDate = DateUtil.parse(outBoundStatus.getBuDate(), DatePattern.NORM_DATETIME_PATTERN, DatePattern.PURE_DATETIME_PATTERN);

			JobArrivedDm jobArrivedDm = new JobArrivedDm();
			jobArrivedDm.setClientCode(outBoundStatus.getCompanyCode());
			jobArrivedDm.setArrivedTime(DateUtil.format(buDate, DatePattern.NORM_DATETIME_PATTERN));
			jobArrivedDm.setWarehouseCode(outBoundStatus.getWarehouseCode());
			jobArrivedDm.setTaskNoList(Arrays.asList(outBoundStatus.getOutboundNo()));
			remoteJobTransportService.arrived(jobArrivedDm, outBoundStatus.getCompanyCode(), SecurityConstants.FROM_IN);

			JobDeliveryDm jobDeliveryDm = new JobDeliveryDm();
			jobDeliveryDm.setClientCode(outBoundStatus.getCompanyCode());
			jobDeliveryDm.setSignTime(DateUtil.format(buDate, DatePattern.NORM_DATETIME_PATTERN));
			jobDeliveryDm.setTaskNoList(Arrays.asList(outBoundStatus.getOutboundNo()));
			jobDeliveryDm.setRemark(outBoundStatus.getRemark());
			jobDeliveryDm.setWarehouseCode(outBoundStatus.getWarehouseCode());
			jobDeliveryDm.setTracingLink(StrUtil.isBlank(outBoundStatus.getRemark2()) ? outBoundStatus.getExpressTracingNo() : outBoundStatus.getRemark2());
			return remoteJobTransportService.taskDelivery(jobDeliveryDm, outBoundStatus.getCompanyCode(), SecurityConstants.FROM_IN);
		}

		throw new OmsBusinessException(ErrorCodeEnum.E100002.code, StrUtil.format("不支持的状态:{}", outBoundStatus.getOutboundStatus()));
	}
	//@formatter:on

}
