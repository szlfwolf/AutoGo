package com.herdsric.oms.freja.apis;

import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.freja.dto.inventory.InventoryQueryDto;
import com.herdsric.oms.freja.service.WmsInventoryService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping("/apis/inventory")
@Tag(name = "WMS库存对外接口")
public class WmsInventoryApis {

	private final WmsInventoryService wmsInventoryService;

	/**
	 * wms库存查询
	 * @param inventoryQueryDto
	 * @return
	 */
	@Operation(summary = "wms库存查询", description = "wms库存查询")
	@PostMapping("list")
	public R list(@Validated @RequestBody InventoryQueryDto inventoryQueryDto) {
		inventoryQueryDto.check();

		return R.ok(wmsInventoryService.queryList(inventoryQueryDto));
	}

}
