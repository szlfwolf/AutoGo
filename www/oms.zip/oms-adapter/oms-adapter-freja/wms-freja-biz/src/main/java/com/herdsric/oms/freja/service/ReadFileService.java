package com.herdsric.oms.freja.service;

import com.herdsric.oms.freja.entity.SysFileLog;
import com.herdsric.oms.freja.enums.TypeEnum;

public interface ReadFileService {

	void downloadFiles(TypeEnum typeEnum);

	void readFiles(SysFileLog sysFileLog);

}
