package com.herdsric.oms.freja.jobs.common;

import cn.hutool.core.util.StrUtil;
import com.herdsric.oms.common.job.common.JobTask;

public class JobCommon {

	private static final String JOB_KEY_PREFIX = "Freja-JOB-TASK";

	public static class JobName {

		/**
		 * 批量上传文件
		 */
		public static final String PUSH_JSON_FILES_TO_WMS = "pushJsonFilesToWms";

		/**
		 * 批量下载文件
		 */
		public static final String BATCH_DOWNLOAD_JSON_FILES = "batchDownloadJsonFiles";

		/**
		 * 解析库存快照文件
		 */
		public static final String READ_STOCK_FILE_JSON = "readStockFileJson";

	}

	public enum TaskEnum implements JobTask {

		/**
		 * 批量上传文件
		 */
		PUSH_JSON_FILES_TO_WMS(JobName.PUSH_JSON_FILES_TO_WMS, 30, "批量上传文件"),
		/**
		 * 批量下载文件
		 */
		BATCH_DOWNLOAD_JSON_FILES(JobName.BATCH_DOWNLOAD_JSON_FILES, 30, "批量下载文件"),
		/**
		 * 解析库存快照文件
		 */
		READ_STOCK_FILE_JSON(JobName.READ_STOCK_FILE_JSON, 30, "解析库存快照文件");

		public String name;

		public int expireTime;

		public String desc;

		TaskEnum(String name, int expireTime, String desc) {
			this.name = name;
			this.expireTime = expireTime;
			this.desc = desc;
		}

		public String getDesc() {
			return StrUtil.concat(true, this.desc);
		}

		@Override
		public String getName() {
			return name;
		}

		@Override
		public int expireTime() {
			return expireTime;
		}

		@Override
		public String getDescription() {
			return getDesc();
		}

		public String getKey() {
			return StrUtil.concat(true, JOB_KEY_PREFIX, this.name);
		}

	}

}
