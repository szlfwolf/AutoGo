package com.herdsric.oms.freja.service.impl;

import cn.hutool.core.convert.Convert;
import cn.hutool.core.util.StrUtil;
import com.fasterxml.jackson.core.type.TypeReference;
import com.herdsric.oms.common.core.constant.CommonConstants;
import com.herdsric.oms.common.core.util.JsonMapper;
import com.herdsric.oms.freja.dto.inventory.Data;
import com.herdsric.oms.freja.dto.inventory.Stock;
import com.herdsric.oms.freja.entity.SysFileLog;
import com.herdsric.oms.freja.entity.WmsInventory;
import com.herdsric.oms.freja.enums.TypeEnum;
import com.herdsric.oms.freja.service.ReadFileService;
import com.herdsric.oms.freja.service.SysFileLogService;
import com.herdsric.oms.freja.service.WmsInventoryService;
import com.herdsric.oms.freja.sftp.ConnectionPool;
import com.herdsric.oms.freja.sftp.ShellProperties;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class ReadFileServiceImpl implements ReadFileService {

	private final ShellProperties shellProperties;

	private final ConnectionPool connectionPool;

	private final WmsInventoryService wmsInventoryService;

	private final SysFileLogService sysFileLogService;

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void downloadFiles(TypeEnum typeEnum) {
		ShellProperties.Config config = shellProperties.getConfigMap().get(typeEnum.bizType);
		String localPath = shellProperties.generateLocalPath(typeEnum.bizType);
		List<SysFileLog> sysFileLogs = connectionPool.down(config.getRemotePath(), config.getRegex(), localPath,
				typeEnum.bizType);
		sysFileLogService.saveBatch(sysFileLogs);

		sysFileLogService.updateBatchById(sysFileLogs);
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public void readFiles(SysFileLog sysFileLog) {
		if (StrUtil.equals(sysFileLog.getType(), TypeEnum.STOCK_SNAPSHOT.bizType)) {
			long start = System.currentTimeMillis();
			String date = TypeEnum.STOCK_SNAPSHOT.getDate(sysFileLog.getLocalName());
			List<WmsInventory> wmsInventorys = new ArrayList<>();
			try {
				// TODO 解析文件名称,获取日期
				Stock stock = JsonMapper.INSTANCE.fromJson(
						new File(sysFileLog.getLocalPath() + sysFileLog.getLocalName()), new TypeReference<Stock>() {
						});
				List<Data> data = stock.getData();
				for (Data dataDetail : data) {
					WmsInventory wmsInventory = new WmsInventory();
					wmsInventory.setClientCode(stock.getCompanyCode());
					wmsInventory.setWarehouseCode(stock.getWarehouseCode());
					wmsInventory.setPartNumber(dataDetail.getCode());
					wmsInventory.setName(dataDetail.getName());
					wmsInventory.setIsHazardous(dataDetail.getHazardous());
					wmsInventory.setUnit(dataDetail.getUnit());
					wmsInventory.setQty(Convert.toInt(dataDetail.getQty()));
					wmsInventory.setAvailableQty(Convert.toInt(dataDetail.getAvailableQty()));
					wmsInventory.setDate(date);
					wmsInventory.setCreateBy(sysFileLog.getLocalName());
					wmsInventorys.add(wmsInventory);
				}
				sysFileLog.setStatus(CommonConstants.Y);
				sysFileLog.setMessage("文件解析成功");

				wmsInventoryService.batchUpdateStocks(date, wmsInventorys);
			}
			catch (Exception e) {
				sysFileLog.setStatus(CommonConstants.N);
				sysFileLog.setMessage(StrUtil.maxLength(e.getMessage(), 4000));
				log.error("读取文件失败:{}", e.getMessage(), e);
			}
			finally {
				sysFileLog.setRetryNum(sysFileLog.getRetryNum() + 1);
				sysFileLog.setCostTime(System.currentTimeMillis() - start);
				sysFileLogService.updateById(sysFileLog);
			}
		}

	}

}
