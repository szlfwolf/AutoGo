package com.herdsric.oms.freja.service;

import com.herdsric.oms.freja.dto.stock.StockQueryDTO;

import java.util.List;

public interface StockService {

	List queryList(StockQueryDTO stockQueryDTO);

}
