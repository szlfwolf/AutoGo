package com.herdsric.oms.freja.service.impl;

import cn.hutool.core.io.FileUtil;
import cn.hutool.core.util.RandomUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.herdsric.oms.common.core.constant.CommonConstants;
import com.herdsric.oms.common.core.util.JsonMapper;
import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.freja.FrejaConstant;
import com.herdsric.oms.freja.dto.inbound.Inbound;
import com.herdsric.oms.freja.dto.item.Product;
import com.herdsric.oms.freja.dto.outbound.Outbound;
import com.herdsric.oms.freja.entity.SysFileLog;
import com.herdsric.oms.freja.enums.DirectionEnum;
import com.herdsric.oms.freja.enums.TypeEnum;
import com.herdsric.oms.freja.service.SysFileLogService;
import com.herdsric.oms.freja.service.WmsService;
import com.herdsric.oms.freja.sftp.ShellProperties;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.io.File;
import java.time.LocalDateTime;
import java.util.Arrays;

@Data
@Slf4j
@Component
@RequiredArgsConstructor
public class FjWmsService implements WmsService {

	private final ShellProperties shellProperties;

	private final SysFileLogService sysFileLogService;

	@Override
	public R generateFileByType(Object obj, TypeEnum type) {
		String source;
		String reference;
		if (obj instanceof Inbound) {
			source = ((Inbound) obj).getCompanyCode();
			reference = ((Inbound) obj).getInboundNo();
		}
		else if (obj instanceof Outbound) {
			source = ((Outbound) obj).getCompanyCode();
			reference = ((Outbound) obj).getOutboundNo();
		}
		else if (obj instanceof Product) {
			source = ((Product) obj).getCompanyCode();
			reference = ((Product) obj).getCode();
		}
		else {
			return R.failed();
		}
		ShellProperties.Config config = shellProperties.getConfig(type.bizType);
		String fileName = type.generateFileName(reference, LocalDateTime.now());
		String localPath = shellProperties.generateLocalPath(type.bizType);

		File file = FileUtil.file(localPath + fileName);
		FileUtil.touch(file);
		FileUtil.writeUtf8String(JsonMapper.INSTANCE.toJson(obj), file);
		SysFileLog sysFileLog = new SysFileLog();
		sysFileLog.setDirection(DirectionEnum.OUT.name());
		sysFileLog.setBatchNo(RandomUtil.randomString(10));
		sysFileLog.setReference(reference);
		sysFileLog.setLocalName(fileName);
		sysFileLog.setLocalPath(localPath);
		sysFileLog.setName(fileName);
		sysFileLog.setPath(config.getRemotePath());
		sysFileLog.setType(type.bizType);
		sysFileLog.setSource(source);
		sysFileLog.setTarget(FrejaConstant.WMS_TYPE);
		sysFileLog.setStatus(CommonConstants.N);
		sysFileLog.setRetryNum(0);
		sysFileLog.setCostTime(0L);
		sysFileLog.setSize(FileUtil.size(file));
		sysFileLog.setLastModifiedDate(FileUtil.lastModifiedTime(file));

		sysFileLogService.batchSaveOrUpdate(Arrays.asList(sysFileLog),
				x -> Wrappers.<SysFileLog>lambdaQuery().eq(SysFileLog::getReference, reference)
						.eq(SysFileLog::getType, type.bizType).eq(SysFileLog::getLocalName, fileName));

		return R.ok(StrUtil.format("文件生成成功，文件名：{}", fileName));
	}

}
