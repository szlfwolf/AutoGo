package com.herdsric.oms.freja.apis;

import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.common.wms.inbound.dto.InboundDTO;
import com.herdsric.oms.freja.dto.inbound.Inbound;
import com.herdsric.oms.freja.dto.inbound.InboundFeedback;
import com.herdsric.oms.freja.service.InboundService;
import com.pig4cloud.plugin.idempotent.annotation.Idempotent;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@RestController
@RequiredArgsConstructor
@RequestMapping("/apis/inbound")
@Tag(name = "入库单对外接口")
public class InboundApis {

	private final InboundService inboundService;

	/**
	 * 入库单下发WMS接口
	 * @param inboundDTO
	 * @return
	 */
	@Operation(summary = "入库单下发WMS接口", description = "入库单下发WMS接口")
	@PostMapping
	@Idempotent(key = "'inboundDTO-'+#inboundDTO.hashCode()", expireTime = 300, delKey = true,
			info = "Do not repeat the operation")
	public R add(@Valid @RequestBody InboundDTO inboundDTO) {
		Inbound inbound = Inbound.convert(inboundDTO);
		return inboundService.pushWms(inbound);
	}

	/**
	 * 入库单过账回传接口
	 * @param inboundFeedback
	 * @return
	 */
	@Operation(summary = "入库单过账回传接口", description = "入库单过账回传接口")
	@PostMapping("feedback")
	@Idempotent(key = "'inboundFeedback-'+#inboundFeedback.hashCode()", expireTime = 300, delKey = true,
			info = "Do not repeat the operation")
	public R inboundFeedback(@Valid @RequestBody InboundFeedback inboundFeedback) {
		inboundFeedback.check();
		return inboundService.postbackAsn(inboundFeedback);
	}

}
