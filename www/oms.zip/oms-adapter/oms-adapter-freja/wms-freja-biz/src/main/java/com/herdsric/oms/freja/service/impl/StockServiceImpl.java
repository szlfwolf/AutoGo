package com.herdsric.oms.freja.service.impl;

import cn.hutool.core.bean.BeanUtil;
import com.herdsric.oms.common.core.constant.SecurityConstants;
import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.common.feign.wms.RemoteStockService;
import com.herdsric.oms.common.wms.stock.domain.StockDm;
import com.herdsric.oms.freja.dto.stock.StockQueryDTO;
import com.herdsric.oms.freja.service.StockService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class StockServiceImpl implements StockService {

	private final RemoteStockService remoteStockService;

	@Override
	public List queryList(StockQueryDTO stockQueryDTO) {
		StockDm stockDm = BeanUtil.copyProperties(stockQueryDTO, StockDm.class);
		R result = remoteStockService.queryStock(stockDm, stockDm.getWarehouseCode(), SecurityConstants.FROM_IN);
		return (List) result.getData();
	}

}
