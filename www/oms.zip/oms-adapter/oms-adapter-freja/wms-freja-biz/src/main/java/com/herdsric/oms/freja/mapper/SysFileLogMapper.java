package com.herdsric.oms.freja.mapper;

import com.herdsric.oms.common.mybatis.base.RootMapper;
import com.herdsric.oms.freja.entity.SysFileLog;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface SysFileLogMapper extends RootMapper<SysFileLog> {

}
