package com.herdsric.oms.freja.enums;

public enum DirectionEnum {

	IN, OUT;

}
