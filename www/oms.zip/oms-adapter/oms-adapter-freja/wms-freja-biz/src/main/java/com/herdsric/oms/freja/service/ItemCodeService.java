package com.herdsric.oms.freja.service;

import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.freja.dto.item.Product;

public interface ItemCodeService {

	R pushWms(Product product);

}
