package com.herdsric.oms.freja.service.impl;

import cn.hutool.core.collection.CollectionUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.enums.SqlMethod;
import com.baomidou.mybatisplus.core.toolkit.Constants;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.herdsric.oms.common.core.exception.ErrorCodeEnum;
import com.herdsric.oms.common.core.exception.OmsBusinessException;
import com.herdsric.oms.freja.entity.SysFileLog;
import com.herdsric.oms.freja.mapper.SysFileLogMapper;
import com.herdsric.oms.freja.service.SysFileLogService;
import org.apache.ibatis.binding.MapperMethod;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

@Service
public class SysFileLogServiceImpl extends ServiceImpl<SysFileLogMapper, SysFileLog> implements SysFileLogService {

	@Override
	public boolean batchSaveOrUpdate(List<SysFileLog> list,
			Function<SysFileLog, LambdaQueryWrapper<SysFileLog>> function) {
		String selectListSqlStatement = this.getSqlStatement(SqlMethod.SELECT_LIST);

		List<SysFileLog> updateList = new ArrayList<>();
		List<SysFileLog> saveList = new ArrayList<>();
		this.executeBatch(list, (sqlSession, entity) -> {
			MapperMethod.ParamMap<Object> param = new MapperMethod.ParamMap();
			param.put(Constants.WRAPPER, function.apply(entity));
			List<SysFileLog> logs = sqlSession.selectList(selectListSqlStatement, param);

			if (logs.isEmpty()) {
				saveList.add(entity);
			}
			else if (logs.size() > 1) {
				throw new OmsBusinessException(ErrorCodeEnum.E999999);
			}
			else {
				entity.setRetryNum(logs.get(0).getRetryNum() + 1);
				entity.setId(logs.get(0).getId());
				updateList.add(entity);
			}
		});

		if (CollectionUtil.isNotEmpty(updateList)) {
			this.getBaseMapper().updateBatch(updateList);
		}
		if (CollectionUtil.isNotEmpty(saveList)) {
			this.getBaseMapper().insertBatch(saveList);
		}

		return true;
	}

	@Override
	public void saveBatch(List<SysFileLog> list) {
		if (CollectionUtil.isNotEmpty(list)) {
			this.baseMapper.insertBatch(list);
		}
	}

}
