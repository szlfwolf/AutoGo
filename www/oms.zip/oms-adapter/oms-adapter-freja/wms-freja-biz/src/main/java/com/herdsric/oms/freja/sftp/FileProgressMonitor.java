package com.herdsric.oms.freja.sftp;

import com.jcraft.jsch.SftpProgressMonitor;
import lombok.AllArgsConstructor;

@AllArgsConstructor
public class FileProgressMonitor implements SftpProgressMonitor {

	private final long length;

	@Override
	public void init(int i, String s, String s1, long l) {

	}

	@Override
	public boolean count(long l) {
		return false;
	}

	@Override
	public void end() {

	}

}
