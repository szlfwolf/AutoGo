package com.herdsric.oms.freja.dto;

import cn.hutool.core.date.DateUtil;
import lombok.Data;

@Data
public class WmsInventoryDTO {

	private String clientCode;

	private String warehouseCode;

	private String partNumber;

	private String name;

	private String isHazardous;

	private String unit;

	private Integer qty;

	private Integer availableQty;

	private String date = DateUtil.today();

}
