package com.herdsric.oms.freja.service;

import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.freja.enums.TypeEnum;

public interface WmsService {

	R generateFileByType(Object obj, TypeEnum typeEnum);

}
