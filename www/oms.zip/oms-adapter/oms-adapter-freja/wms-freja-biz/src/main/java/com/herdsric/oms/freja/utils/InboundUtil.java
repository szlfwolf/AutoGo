package com.herdsric.oms.freja.utils;

import cn.hutool.core.convert.Convert;
import cn.hutool.core.util.RandomUtil;
import com.herdsric.oms.common.wms.inbound.domain.InboundFeedbackDm;
import com.herdsric.oms.common.wms.inbound.domain.InboundFeedbackLineDm;
import com.herdsric.oms.common.wms.inbound.enums.InboundStatusEnum;
import com.herdsric.oms.freja.dto.inbound.InboundFeedback;
import com.herdsric.oms.freja.dto.inbound.InboundFeedbackDetails;

import java.util.ArrayList;
import java.util.List;

public class InboundUtil {

	public static InboundFeedbackDm convertInboundFeedback(InboundFeedback inboundFeedback) {
		InboundFeedbackDm inboundFeedbackDm = new InboundFeedbackDm();
		inboundFeedbackDm.setSequenceNo(RandomUtil.randomNumbers(10));
		inboundFeedbackDm.setInboundNo(inboundFeedback.getInboundNo());
		inboundFeedbackDm.setStatus(InboundStatusEnum.P.name());
		inboundFeedbackDm.setMultipleReceipts(true);
		inboundFeedbackDm.setClientCode(inboundFeedback.getCompanyCode());
		inboundFeedbackDm.setWarehouseCode(inboundFeedback.getWarehouseCode());

		List<InboundFeedbackLineDm> lines = new ArrayList<>();
		for (InboundFeedbackDetails detail : inboundFeedback.getDetails()) {
			InboundFeedbackLineDm line = new InboundFeedbackLineDm();
			line.setLineNo(detail.getLineNo());
			line.setItemCode(detail.getItemCode());
			line.setUnit(detail.getUnit());
			line.setDamage(detail.getDamage());
			line.setReceivedQty(Convert.toDouble(detail.getReceivedQty()));
			line.setInventoryStatus(detail.getInventoryStatus());
			line.setInventoryTime(detail.getStorageDate());
			line.setStorageTime(detail.getStoragetime());
			line.setRemark(detail.getExtendedField1());
			if (detail.getLotInfo() != null) {
				line.setBatchNo(detail.getLotInfo().getLot());
				line.setVin(detail.getLotInfo().getExtendedField1());
			}

			lines.add(line);
		}

		inboundFeedbackDm.setLineList(lines);
		return inboundFeedbackDm;
	}

}
