package com.herdsric.oms.freja.service;

import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.freja.dto.inbound.Inbound;
import com.herdsric.oms.freja.dto.inbound.InboundFeedback;

public interface InboundService {

	R postbackAsn(InboundFeedback inboundFeedback);

	R pushWms(Inbound inbound);

}
