package com.herdsric.oms.freja.dto;

import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class ResultData {

	private List<String> errorList;

	private List<String> successList;

	private Map<String, String> errorMsgMap;

}
