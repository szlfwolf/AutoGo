package com.herdsric.oms.freja.utils;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.convert.Convert;
import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.RandomUtil;
import com.herdsric.oms.common.client.enums.UnitEnum;
import com.herdsric.oms.common.core.constant.CommonConstants;
import com.herdsric.oms.common.wms.outbound.domain.OutboundFeedbackDm;
import com.herdsric.oms.common.wms.outbound.domain.OutboundFeedbackLineDm;
import com.herdsric.oms.common.wms.outbound.enums.OutboundStatusEnum;
import com.herdsric.oms.freja.FrejaConstant;
import com.herdsric.oms.freja.dto.outbound.CommonPackage;
import com.herdsric.oms.freja.dto.outbound.CommonPackageItem;
import com.herdsric.oms.freja.dto.outbound.OutBoundStatus;
import com.herdsric.oms.freja.dto.outbound.PackageDetailDto;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

public class OutboundUtil {

	//@formatter:off
	public static OutboundFeedbackDm convertCommonPackageToOutboundFeedbackDm(CommonPackage commonPackage) {
		OutboundFeedbackDm outboundFeedbackDm = new OutboundFeedbackDm();
		outboundFeedbackDm.setSequenceNo(RandomUtil.randomNumbers(10));
		outboundFeedbackDm.setOutboundNo(commonPackage.getOutboundNo());
		outboundFeedbackDm.setClientCode(commonPackage.getCompanyCode());
		outboundFeedbackDm.setWarehouseCode(commonPackage.getWarehouseCode());
		outboundFeedbackDm.setStatus(OutboundStatusEnum.PACKED.name());
		outboundFeedbackDm.setExpressTracingNo(commonPackage.getExpressTracingNo());

		List<CommonPackageItem> items = commonPackage.getDetails();
		List<OutboundFeedbackLineDm> outboundFeedbackLineDms = new ArrayList<>();
		AtomicInteger packageIndex = new AtomicInteger(0);
		Map<String, List<CommonPackageItem>> packageDetailMap = items.stream().collect(Collectors.groupingBy(CommonPackageItem::getBoxNo));
		packageDetailMap.forEach((x, y) -> {
			packageIndex.incrementAndGet();
			for (CommonPackageItem item : y) {
				OutboundFeedbackLineDm outboundFeedbackLineDm = new OutboundFeedbackLineDm();
				outboundFeedbackLineDm.setLineNo(item.getLineNo());
				outboundFeedbackLineDm.setItemCode(item.getItemCode());
				outboundFeedbackLineDm.setPackageNo(item.getBoxNo());
				outboundFeedbackLineDm.setUnit(UnitEnum.PCS.value);
				outboundFeedbackLineDm.setPackQty(Convert.toDouble(item.getPackQty()));
				outboundFeedbackLineDm.setWidth(Convert.toDouble(item.getWidth(), 0D));
				outboundFeedbackLineDm.setHeight(Convert.toDouble(item.getHeight(), 0D));
				outboundFeedbackLineDm.setLength(Convert.toDouble(item.getLength(), 0D));
				outboundFeedbackLineDm.setWeight(Convert.toDouble(item.getNetWeight(), 0D));
				outboundFeedbackLineDm.setGrossWeight(Convert.toDouble(item.getWeight(), 0D));
				outboundFeedbackLineDm.setPackageType(item.getPackingType());
				outboundFeedbackLineDm.setPackageTime(DateUtil.format(DateUtil.parse(item.getPackagingTime(), DatePattern.NORM_DATETIME_PATTERN, DatePattern.PURE_DATETIME_PATTERN), DatePattern.NORM_DATETIME_PATTERN));
				outboundFeedbackLineDm.setSerialNumber(packageIndex.get());
				// 如果是最后一个元素
				outboundFeedbackLineDm.setIsFinished(packageIndex.get() == packageDetailMap.size() ? CommonConstants.Y : CommonConstants.N);
				outboundFeedbackLineDms.add(outboundFeedbackLineDm);
			}
		});
		outboundFeedbackDm.setLineList(outboundFeedbackLineDms);

		return outboundFeedbackDm;
	}

	// TODO 暂时没有打包数量，40 状态无法更新, 60 状态可以更新.但是无效
	@Deprecated
	public static OutboundFeedbackDm convertStatusToOutboundFeedbackDm(OutBoundStatus outBoundStatus) {
		OutboundFeedbackDm outboundFeedbackDm = new OutboundFeedbackDm();
		outboundFeedbackDm.setSequenceNo(RandomUtil.randomNumbers(10));
		outboundFeedbackDm.setOutboundNo(outBoundStatus.getOutboundNo());
		outboundFeedbackDm.setClientCode(outBoundStatus.getCompanyCode());
		outboundFeedbackDm.setWarehouseCode(outBoundStatus.getWarehouseCode());
		outboundFeedbackDm.setStatus(outBoundStatus.getOutboundStatus());
		outboundFeedbackDm.setOperatorName(FrejaConstant.WMS_TYPE);
		outboundFeedbackDm.setOperatorTime(DateUtil.format(DateUtil.parse(outBoundStatus.getBuDate(), DatePattern.NORM_DATETIME_PATTERN, DatePattern.PURE_DATETIME_PATTERN), DatePattern.NORM_DATETIME_PATTERN));
		outboundFeedbackDm.setExpressTracingNo(outBoundStatus.getExpressTracingNo());

		if (CollectionUtil.isNotEmpty(outBoundStatus.getPackageDetails())) {
			Map<String, List<PackageDetailDto>> packageDetailMap = outBoundStatus.getPackageDetails().stream().collect(Collectors.groupingBy(PackageDetailDto::getBoxNo));

			List<OutboundFeedbackLineDm> outboundFeedbackLineDms = new ArrayList<>();
			AtomicInteger packageIndex = new AtomicInteger(0);
			packageDetailMap.forEach((x, y) -> {
				packageIndex.getAndIncrement();
				for (PackageDetailDto packageDetail : y) {
					OutboundFeedbackLineDm outboundFeedbackLineDm = new OutboundFeedbackLineDm();
					outboundFeedbackLineDm.setLineNo(packageDetail.getLineNo());
					outboundFeedbackLineDm.setItemCode(packageDetail.getItemCode());
					outboundFeedbackLineDm.setPackageNo(packageDetail.getBoxNo());
					outboundFeedbackLineDm.setUnit(packageDetail.getUnit());
//					outboundFeedbackLineDm.setPackQty(Convert.toDouble(packageDetail.getPackQty()));

					// Freja 传递的长宽高 cm OMS 入库是 m
					outboundFeedbackLineDm.setWidth(Convert.toDouble(packageDetail.getWidth(), 0D) / 100);
					outboundFeedbackLineDm.setHeight(Convert.toDouble(packageDetail.getHeight(), 0D) / 100);
					outboundFeedbackLineDm.setLength(Convert.toDouble(packageDetail.getLength(), 0D) / 100);
					outboundFeedbackLineDm.setWeight(Convert.toDouble(packageDetail.getNetWeight()));
					outboundFeedbackLineDm.setGrossWeight(Convert.toDouble(packageDetail.getWeight()));
					outboundFeedbackLineDm.setPackageType(packageDetail.getPackingType());
					outboundFeedbackLineDm.setPackageTime(DateUtil.format(DateUtil.parse(packageDetail.getPackagingTime(), DatePattern.NORM_DATETIME_PATTERN, DatePattern.PURE_DATETIME_PATTERN), DatePattern.NORM_DATETIME_PATTERN));
					outboundFeedbackLineDm.setSerialNumber(packageIndex.get());
					outboundFeedbackLineDm.setIsFinished(packageIndex.get() == outBoundStatus.getPackageDetails().size() ? CommonConstants.Y : CommonConstants.N);
					outboundFeedbackLineDms.add(outboundFeedbackLineDm);
				}
			});
			outboundFeedbackDm.setLineList(outboundFeedbackLineDms);
		} else {
			outboundFeedbackDm.setLineList(new ArrayList<>());
		}
		return outboundFeedbackDm;
	}
	//@formatter:on

}
