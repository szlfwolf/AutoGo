package com.herdsric.oms.freja.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.herdsric.oms.freja.dto.WmsInventoryDTO;
import com.herdsric.oms.freja.dto.inventory.InventoryQueryDto;
import com.herdsric.oms.freja.entity.WmsInventory;
import com.herdsric.oms.freja.entity.WmsInventorySnapshot;
import com.herdsric.oms.freja.mapper.WmsInventoryMapper;
import com.herdsric.oms.freja.service.WmsInventoryService;
import com.herdsric.oms.freja.service.WmsInventorySnapshotService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class WmsInventoryImpl extends ServiceImpl<WmsInventoryMapper, WmsInventory> implements WmsInventoryService {

	private final WmsInventorySnapshotService wmsInventorySnapshotService;

	@Override
	public void saveBatch(List<WmsInventory> list) {
		if (CollectionUtil.isNotEmpty(list)) {
			List<List<WmsInventory>> splitList = CollectionUtil.split(list, 1000);
			for (List<WmsInventory> subList : splitList) {
				this.baseMapper.insertBatch(subList);
			}
		}
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public boolean batchUpdateStocks(String date, List<WmsInventory> wmsInventorys) {

		Map<String, List<WmsInventory>> map = wmsInventorys.stream()
				.collect(Collectors.groupingBy(x -> StrUtil.format("{}={}", x.getClientCode(), x.getWarehouseCode())));

		map.forEach((k, v) -> {

			String clientCode = v.get(0).getClientCode();
			String warehouseCode = v.get(0).getWarehouseCode();

			LambdaQueryWrapper<WmsInventory> queryWrapper = Wrappers.lambdaQuery();
			queryWrapper.select(WmsInventory::getDate);
			queryWrapper.eq(WmsInventory::getWarehouseCode, warehouseCode);
			queryWrapper.eq(WmsInventory::getClientCode, clientCode);
			queryWrapper.orderByAsc(WmsInventory::getDate);
			queryWrapper.last("LIMIT 1");
			WmsInventory lastInventory = this.baseMapper.selectOne(queryWrapper);
			boolean isNewWmsInventoryData = lastInventory == null;
			if (lastInventory != null && StrUtil.compare(lastInventory.getDate(), date, false) < 0) {
				log.info("lastInventory date :{}, Delete inventory data before {}.", lastInventory.getDate(), date);
				this.baseMapper.physicsDelete(clientCode, warehouseCode);
				isNewWmsInventoryData = true;
			}

			if (isNewWmsInventoryData) {
				this.saveBatch(wmsInventorys);
			}
			wmsInventorySnapshotService.physicsDelete(clientCode, warehouseCode, date);
			List<WmsInventorySnapshot> wmsInventorySnapshots = BeanUtil.copyToList(wmsInventorys,
					WmsInventorySnapshot.class);
			wmsInventorySnapshotService.saveBatch(wmsInventorySnapshots);
		});

		return true;
	}

	@Override
	public Object queryList(InventoryQueryDto inventoryQueryDto) {
		if (StrUtil.isBlank(inventoryQueryDto.getDate())) {
			LambdaQueryWrapper<WmsInventory> queryWrapper = Wrappers.<WmsInventory>lambdaQuery()
					.eq(WmsInventory::getClientCode, inventoryQueryDto.getClientCode())
					.eq(WmsInventory::getWarehouseCode, inventoryQueryDto.getWarehouseCode())
					.ge(WmsInventory::getAvailableQty, 0).ge(WmsInventory::getQty, 0);
			List<WmsInventory> wmsInventoryList = this.list(queryWrapper);
			return BeanUtil.copyToList(wmsInventoryList, WmsInventoryDTO.class);
		}
		else {
			LambdaQueryWrapper<WmsInventorySnapshot> queryWrapper = Wrappers.<WmsInventorySnapshot>lambdaQuery()
					.eq(WmsInventorySnapshot::getClientCode, inventoryQueryDto.getClientCode())
					.eq(WmsInventorySnapshot::getWarehouseCode, inventoryQueryDto.getWarehouseCode())
					.eq(WmsInventorySnapshot::getDate, inventoryQueryDto.getDate())
					.ge(WmsInventorySnapshot::getAvailableQty, 0).ge(WmsInventorySnapshot::getQty, 0);

			List<WmsInventorySnapshot> wmsInventoryList = wmsInventorySnapshotService.list(queryWrapper);
			return BeanUtil.copyToList(wmsInventoryList, WmsInventoryDTO.class);
		}

	}

}
