package com.herdsric.oms.freja.dto;

import lombok.Builder;
import lombok.Data;
import lombok.experimental.Tolerate;

@Data
@Builder
public class ErrorMap {

	@Tolerate
	public ErrorMap() {
	}

	private String code;

	private String msg;

}
