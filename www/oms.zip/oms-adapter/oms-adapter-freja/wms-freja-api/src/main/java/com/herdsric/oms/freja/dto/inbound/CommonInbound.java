package com.herdsric.oms.freja.dto.inbound;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.herdsric.oms.common.core.util.JsonMapper;
import lombok.Data;

@Data
public class CommonInbound {

	@JsonProperty(index = 1)
	protected String warehouseCode;

	@JsonProperty(index = 2)
	protected String companyCode;

	@JsonProperty(index = 4)
	protected String inboundNo;

	public static CommonInbound parser(String wmsName, String json) {
		return JsonMapper.INSTANCE.fromJson(json, com.herdsric.oms.freja.dto.inbound.CommonInbound.class);
	}

}