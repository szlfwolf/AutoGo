package com.herdsric.oms.freja.dto.outbound;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Data
@Slf4j
public class CommonOutbound {

	@JsonProperty(index = 1)
	protected String warehouseCode;

	@JsonProperty(index = 2)
	protected String companyCode;

	@JsonProperty(index = 3)
	protected String outboundNo;

}
