package com.herdsric.oms.freja.manages;

import com.herdsric.oms.common.client.enums.SyncEnum;
import com.herdsric.oms.common.core.util.SpringContextHolder;
import com.herdsric.oms.common.webhook.CallbackHttpDefine;
import com.herdsric.oms.common.wms.outbound.OutboundBizDefine;
import com.herdsric.oms.common.wms.outbound.domain.DockDm;
import com.herdsric.oms.common.wms.outbound.domain.OutboundFeedbackDm;
import com.herdsric.oms.common.wms.outbound.dto.OutboundDTO;
import com.herdsric.oms.common.wms.outbound.process.OutboundProcessor;
import com.herdsric.oms.freja.FrejaConstant;

import java.util.function.Function;

public class OutboundManage extends CommonDefine implements OutboundBizDefine {

	@Override
	public void outbound2WmsByWebhook(String clientCode, String warehouseCode, String outboundNo) {

		CallbackHttpDefine callbackHttpDefine = SpringContextHolder.getBean(CallbackHttpDefine.class);

		Function<OutboundDTO, Boolean> function = x -> {
			callbackHttpDefine.execute(true, FrejaConstant.WMS_TYPE, clientCode, warehouseCode, outboundNo, x,
					SyncEnum.DN_ORDER_PUSH_WMS_SYNC.name(), true);
			return true;
		};

		OutboundProcessor outboundProcessor = SpringContextHolder.getBean(OutboundProcessor.class);
		outboundProcessor.pushOutbound2WmsByWebhook(clientCode, warehouseCode, outboundNo, function);
	}

	@Override
	public void outboundFeedBack4Wms(OutboundFeedbackDm outboundFeedbackDm) {
		OutboundProcessor outboundProcessor = SpringContextHolder.getBean(OutboundProcessor.class);
		outboundProcessor.outboundFeedbackHandler(outboundFeedbackDm, FrejaConstant.WMS_TYPE);
	}

}
