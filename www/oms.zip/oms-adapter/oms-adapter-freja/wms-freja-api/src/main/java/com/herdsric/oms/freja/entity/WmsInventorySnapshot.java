package com.herdsric.oms.freja.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.herdsric.oms.common.mybatis.base.LogicDelBaseEntity;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;

@Data
@TableName("wms_inventory_snapshot")
@EqualsAndHashCode(callSuper = true)
@Schema(description = "库存日志表")
public class WmsInventorySnapshot extends LogicDelBaseEntity {

	/**
	 * id
	 */
	@TableId(type = IdType.AUTO)
	private Integer id;

	private String clientCode;

	private String warehouseCode;

	private String partNumber;

	private String name;

	private String isHazardous;

	private String unit;

	private Integer qty;

	private Integer availableQty;

	private String date;

}
