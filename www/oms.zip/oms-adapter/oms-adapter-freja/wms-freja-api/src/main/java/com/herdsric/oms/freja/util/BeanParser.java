package com.herdsric.oms.freja.util;

public class BeanParser {

}