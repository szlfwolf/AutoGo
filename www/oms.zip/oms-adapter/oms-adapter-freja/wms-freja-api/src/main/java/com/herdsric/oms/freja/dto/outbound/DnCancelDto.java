package com.herdsric.oms.freja.dto.outbound;

import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class DnCancelDto {

	@NotBlank(message = "仓库代码不能为空")
	private String warehouseCode;

	@NotBlank(message = "客户代码不能为空")
	private String clientCode;

	@NotBlank(message = "出库单不能为空")
	private String outboundNo;

	private String cancelReason;

}
