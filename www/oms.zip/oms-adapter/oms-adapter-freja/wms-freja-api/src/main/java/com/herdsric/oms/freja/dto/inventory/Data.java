package com.herdsric.oms.freja.dto.inventory;

import com.fasterxml.jackson.annotation.JsonProperty;

@lombok.Data
public class Data {

	private String code;

	private String name;

	@JsonProperty("isHazardous")
	private String Hazardous;

	private String unit;

	private String qty;

	private String availableQty;

}
