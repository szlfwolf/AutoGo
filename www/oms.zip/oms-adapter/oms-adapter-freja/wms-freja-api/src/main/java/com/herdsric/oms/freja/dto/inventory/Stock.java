package com.herdsric.oms.freja.dto.inventory;

import com.herdsric.oms.freja.dto.inventory.Data;

import java.util.List;

@lombok.Data
public class Stock {

	private String warehouseCode;

	private String companyCode;

	private List<Data> data;

}
