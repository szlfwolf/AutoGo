package com.herdsric.oms.freja.dto.outbound;

import cn.hutool.core.convert.Convert;
import cn.hutool.core.util.StrUtil;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.herdsric.oms.common.wms.common.CommonStatusEnum;
import com.herdsric.oms.common.wms.outbound.dto.OutboundDTO;
import com.herdsric.oms.common.wms.outbound.dto.OutboundLineDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Data
@EqualsAndHashCode(callSuper = true)
public class Outbound extends CommonOutbound {

	@JsonProperty(index = 4)
	private String orderType;

	@JsonProperty(index = 5)
	private String requireArriveDate;

	@JsonProperty(index = 6)
	private int priority;

	@JsonProperty(index = 7)
	private String addressId;

	@JsonProperty(index = 8)
	private String receiverName;

	@JsonProperty(index = 9)
	private String telephone;

	@JsonProperty(index = 10)
	private String mobile;

	@JsonProperty(index = 11)
	private String email;

	@JsonProperty(index = 12)
	private String postCode;

	@JsonProperty(index = 13)
	private String country;

	@JsonProperty(index = 14)
	private String province;

	@JsonProperty(index = 15)
	private String city;

	@JsonProperty(index = 16)
	private String district;

	@JsonProperty(index = 17)
	private String address;

	@JsonProperty(index = 18)
	private String description;

	@JsonProperty(index = 19)
	private String status;

	@JsonProperty(index = 20)
	private String extendedField1;

	@JsonProperty(index = 21)
	private String extendedField2;

	@JsonProperty(index = 22)
	private String delivery; // 自提标识，1： 物流配送 2自提

	@JsonProperty(index = 23)
	private String remark; // 备注

	@JsonProperty(index = 24)
	private List<OutBoundDetails> details;

	public static Outbound convert(OutboundDTO outboundDTO) {
		Outbound outbound = new Outbound();
		outbound.setOutboundNo(outboundDTO.getOutboundNo());
		outbound.setCompanyCode(outboundDTO.getClientCode());
		outbound.setWarehouseCode(outboundDTO.getWarehouseCode());
		outbound.setStatus(CommonStatusEnum.N.name());
		outbound.setRequireArriveDate(Convert.toStr(outboundDTO.getExpectedDeliveryDate(), ""));
		outbound.setReceiverName(outboundDTO.getContactName());
		// TODO 默认设置为ZCRK
		outbound.setOrderType("ZCRK");
		if (StrUtil.equalsIgnoreCase(outboundDTO.getType(), "VOR")) {
			outbound.setPriority(3);
		}
		else if (StrUtil.equalsIgnoreCase(outboundDTO.getType(), "Urgent")) {
			outbound.setPriority(2);
		}
		else {
			outbound.setPriority(1);
		}
		// 收货方式 0：to b; 1：to c ; 2:Self Pick Up，发给freja需要 fixMe
		// saicDnHead.getConsigneePickup()
		outbound.setDelivery(Convert.toStr(outboundDTO.getDeliveryType(), "0"));
		// 增加备注字段
		outbound.setRemark(""); // 暂时没有用到给空
		// 客户公司
		outbound.setAddressId(Convert.toStr(outboundDTO.getAddress(), ""));
		outbound.setReceiverName(Convert.toStr(outboundDTO.getContactName(), ""));
		outbound.setTelephone(Convert.toStr(outboundDTO.getContactPhone(), ""));
		outbound.setMobile(Convert.toStr(outboundDTO.getContactPhone(), ""));
		outbound.setEmail(Convert.toStr(outboundDTO.getContactEmail(), ""));
		outbound.setPostCode(Convert.toStr(outboundDTO.getZipCode(), ""));
		outbound.setCountry(Convert.toStr(outboundDTO.getCountryCode(), ""));
		outbound.setProvince("");
		outbound.setCity(Convert.toStr(outboundDTO.getCityCode(), ""));
		outbound.setDistrict("");
		outbound.setAddress(Convert.toStr(outboundDTO.getAddress(), ""));
		outbound.setDescription("");
		outbound.setStatus("N");
		outbound.setExtendedField1("");
		outbound.setExtendedField2("");

		List<OutBoundDetails> detailsList = new ArrayList<>();
		Map<String, List<OutboundLineDTO>> lineMap = outboundDTO.getOutboundLines().stream()
				.peek(x -> x.setLineNo(String.format("%06d", Integer.valueOf(x.getLineNo())))).collect(Collectors
						.groupingBy(x -> StrUtil.format("lineNo:{}-itemCode:{}", x.getLineNo(), x.getItemCode())));
		for (String key : lineMap.keySet()) {
			OutboundLineDTO outboundLine = lineMap.get(key).get(0);
			OutBoundDetails detail = new OutBoundDetails();
			detail.setLineNo(outboundLine.getLineNo());
			detail.setItemCode(outboundLine.getItemCode());
			detail.setUnit(outboundLine.getUnit());
			Double sumQty = lineMap.get(key).stream().map(l -> Convert.toDouble(l.getPackQty())).reduce(Double::sum)
					.get();
			detail.setPackQty(sumQty);
			detail.setEstimatedate(Convert.toStr(outboundDTO.getExpectedDeliveryDate(), ""));

			// 20220704 李进确认全客户，合单情况下，行具体细分到对应的DN号
			String clientRemark = Convert.toStr(outboundLine.getClientRemark(), "");
			if (!StrUtil.equals(outboundDTO.getDnNo(), outboundDTO.getDnNos())) {
				clientRemark = StrUtil.format("DN:{} {}",
						lineMap.get(key).stream().map(OutboundLineDTO::getDnNo).distinct().collect(Collectors.toList()),
						clientRemark);
			}
			detail.setExtendedField1(clientRemark);
			detail.setExtendedField2("");

			// 批次信息
			OutBoundLotInfo outBoundLotInfo = new OutBoundLotInfo();
			outBoundLotInfo.setLot("");
			outBoundLotInfo.setProductDate("");
			outBoundLotInfo.setExtendedField1("");
			outBoundLotInfo.setExtendedField2("");
			detail.setLotInfo(outBoundLotInfo);
			detailsList.add(detail);
		}
		outbound.setDetails(detailsList);
		return outbound;
	}

}
