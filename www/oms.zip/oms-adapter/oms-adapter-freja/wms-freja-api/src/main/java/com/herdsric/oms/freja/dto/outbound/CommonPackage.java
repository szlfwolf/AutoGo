package com.herdsric.oms.freja.dto.outbound;

import com.herdsric.oms.common.core.validation.RegexpConstants;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.util.List;

@Data
public class CommonPackage {

	/**
	 * 货主编码
	 */
	@NotBlank(message = "货主代码不能为空")
	private String companyCode;

	/**
	 * 仓库编码
	 */
	@NotBlank(message = "仓库代码不能为空")
	private String warehouseCode;

	/**
	 * 出库单据号
	 */
	@NotBlank(message = "出库单不能为空")
	private String outboundNo;

	/**
	 * 快递单号进度查询地址
	 */
	private String expressTracingNo;

	@Valid
	@NotNull(message = "包装信息不能为空")
	private List<CommonPackageItem> details;

	public void checkValid() {
	}

}
