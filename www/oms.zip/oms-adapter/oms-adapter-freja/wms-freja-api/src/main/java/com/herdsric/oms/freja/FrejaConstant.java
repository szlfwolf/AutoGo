package com.herdsric.oms.freja;

public interface FrejaConstant {

	String WMS_TYPE = "FREJA";

	String FREJA_DEFAULT_CARRIER_CODE = "LUX-MATE";

	String SKU_PUSH_WMS_WAREHOUSE_CODE = "NIO-Norway-01";

	String UNIT_PCE = "PCE";

	String UNIT_PCS = "PCS";

	/**
	 * 未妥投的订单
	 */
	String RETURN = "_return";

	/**
	 * >= 0的数<br/>
	 * 0.0<br/>
	 * 0<br/>
	 * 0.1<br/>
	 * 1<br/>
	 * 1.2
	 */
	String GE_ZERO = "^0|[1-9]\\d*\\.\\d*|0\\.\\d*|[1-9]\\d*$";

}
