package com.herdsric.oms.freja.dto.outbound;

import com.herdsric.oms.common.wms.outbound.enums.OutboundStatusEnum;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
public class OutBoundStatus {

	@NotBlank(message = "仓库代码不能为空")
	private String warehouseCode;

	@NotBlank(message = "客户代码不能为空")
	private String companyCode;

	@NotBlank(message = "出库单不能为空")
	private String outboundNo;

	private String buDate;

	/**
	 * 10：receive outbound order 20：Start picking 30：Start packing 40：Packing is complete
	 * 50：Car booking completed 60：out bound 70：Have been received
	 */
	@NotBlank(message = "出库单状态不能为空")
	@Pattern(regexp = "^[2-7]0$", message = "出库单状态不正确")
	private String outboundStatus;

	/**
	 * 快递单号
	 */
	private String expressTracingNo;

	/**
	 * 快递公司
	 */
	private String expressCompany;

	/**
	 * 用于70状态：Remark for 70：Have been received
	 */
	private String remark;

	/**
	 * 物流查询地址：Tracking link
	 */
	private String remark2;

	@Valid
	private List<PackageDetailDto> packageDetails;

	public static Map<String, String> statusMap = new HashMap<>();

	static {
		statusMap.put("40", OutboundStatusEnum.PACKED.name());
		statusMap.put("50", OutboundStatusEnum.BOOKED.name());
		statusMap.put("60", OutboundStatusEnum.OUTBOUND.name());
		statusMap.put("70", OutboundStatusEnum.FINISHED.name());
	}

	public void checkValid() {
		if (statusMap.containsKey(outboundStatus)) {
			this.outboundStatus = statusMap.get(outboundStatus);
		}
		else {
			throw new IllegalArgumentException("出库单状态不正确");
		}
	}

	/**
	 * 根据当前节点获取下一个节点 状态
	 * @param dnStatusEnum
	 * @return
	 */
	public static String getFrejaStatusByOmsStatus(String dnStatusEnum) {
		for (Map.Entry<String, String> enumEntry : statusMap.entrySet()) {
			if (enumEntry.getValue().equals(dnStatusEnum)) {
				return String.valueOf(Integer.valueOf(enumEntry.getKey()) + 10);
			}
		}
		return null;
	}

}
