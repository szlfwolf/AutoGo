package com.herdsric.oms.freja.dto.item;

import cn.hutool.core.convert.Convert;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.herdsric.oms.common.wms.itemcode.dto.ItemCodeDTO;
import com.herdsric.oms.common.wms.itemcode.dto.PackageDTO;
import com.herdsric.oms.freja.FrejaConstant;
import lombok.Data;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Data
public class Product extends CommonProduct {

	@JsonProperty(index = 5)
	private String baseUnit;

	@JsonProperty(index = 6)
	private int bePrecision;

	@JsonProperty(index = 7)
	private String class1;

	@JsonProperty(index = 8)
	private int beSet;

	@JsonProperty(index = 9)
	private String allowCross;

	@JsonProperty(index = 10)
	private String isHazardous;

	@JsonProperty(index = 11)
	private String status;

	@JsonProperty(index = 12)
	private String extendedField1;

	@JsonProperty(index = 13)
	private String extendedField2;

	@JsonProperty(index = 14)
	private String extendedField3;

	@JsonProperty(index = 15)
	private List<PackageUnits> packageUnits;

	@JsonProperty(index = 16)
	private List<Barcodes> barcodes;

	public static List<Product> convert(List<ItemCodeDTO> itemCodes) {
		List<Product> products = new ArrayList<>();
		for (ItemCodeDTO itemCode : itemCodes) {
			Product product = new Product();
			product.setCompanyCode(itemCode.getClientCode());
			product.setWarehouseCode(FrejaConstant.SKU_PUSH_WMS_WAREHOUSE_CODE);
			product.setCode(itemCode.getPartNumber());
			product.setName(itemCode.getPartDesc());
			product.setBaseUnit(itemCode.getUnit());
			product.setBePrecision(0);
			product.setClass1("");
			product.setBeSet(1);
			product.setAllowCross("1");
			product.setIsHazardous(itemCode.getIsDangerous());
			product.setStatus(itemCode.getStatus());
			product.setExtendedField1("");
			product.setExtendedField2(Convert.toStr(itemCode.getBrand(), ""));
			product.setExtendedField3("");

			// 只下发原始类型的包装
			List<PackageUnits> packageList = new ArrayList<>();
			for (PackageDTO packageDTO : itemCode.getPackageList()) {

				boolean isPcs = true;

				if (Convert.toDouble(packageDTO.getMoq(), 1D) > 1) {
					PackageUnits unitPce = new PackageUnits();
					// Freja UNIT 默认设置为PCE（SET.KG,...）
					unitPce.setUnit(FrejaConstant.UNIT_PCE);
					unitPce.setUnitSn(itemCode.getPartNumber());
					unitPce.setStandardUnit(1);
					unitPce.setConvertFigure(Convert.toDouble(packageDTO.getMoq(), 1D));
					unitPce.setLength(Convert.toDouble(packageDTO.getLength(), 0D));
					unitPce.setWidth(Convert.toDouble(packageDTO.getWidth(), 0D));
					unitPce.setHeight(Convert.toDouble(packageDTO.getHeight(), 0D));
					unitPce.setWeight(Convert.toDouble(packageDTO.getGrossWeight(), 0D));
					unitPce.setNetweight(Convert.toDouble(packageDTO.getNetWeight(), 0D));
					unitPce.setDescription("");
					unitPce.setExtendedField1("");
					unitPce.setExtendedField2("");
					unitPce.setExtendedField3("");
					packageList.add(unitPce);
					isPcs = false;
				}

				PackageUnits unitPcs = new PackageUnits();
				unitPcs.setUnit(FrejaConstant.UNIT_PCS);
				unitPcs.setUnitSn(itemCode.getPartNumber());
				unitPcs.setStandardUnit(1);
				unitPcs.setConvertFigure(1.0);
				unitPcs.setLength(isPcs ? Convert.toDouble(packageDTO.getLength(), 0D) : 0D);
				unitPcs.setWidth(isPcs ? Convert.toDouble(packageDTO.getWidth(), 0D) : 0D);
				unitPcs.setHeight(isPcs ? Convert.toDouble(packageDTO.getHeight(), 0D) : 0D);
				unitPcs.setWeight(isPcs ? Convert.toDouble(packageDTO.getGrossWeight(), 0D) : 0D);
				unitPcs.setNetweight(isPcs ? Convert.toDouble(packageDTO.getNetWeight(), 0D) : 0D);
				unitPcs.setDescription("");
				unitPcs.setExtendedField1("");
				unitPcs.setExtendedField2("");
				unitPcs.setExtendedField3("");
				packageList.add(unitPcs);
			}
			product.setPackageUnits(packageList);
			Barcodes barcodes = new Barcodes();
			barcodes.setCode(itemCode.getPartNumber());
			barcodes.setType("PN");
			product.setBarcodes(Arrays.asList(barcodes));

			products.add(product);
		}
		return products;

	}

}
