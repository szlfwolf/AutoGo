package com.herdsric.oms.freja.dto.stock;

public class StockQueryDTO {

	public void check() {
	}

}
