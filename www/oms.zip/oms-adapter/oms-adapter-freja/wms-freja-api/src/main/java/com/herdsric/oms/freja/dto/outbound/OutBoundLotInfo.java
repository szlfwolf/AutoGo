package com.herdsric.oms.freja.dto.outbound;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class OutBoundLotInfo {

	@JsonProperty(index = 1)
	private String lot = "";

	@JsonProperty(index = 2)
	private String productDate = "";

	@JsonProperty(index = 3)
	private String extendedField1 = "";

	@JsonProperty(index = 4)
	private String extendedField2 = "";

}