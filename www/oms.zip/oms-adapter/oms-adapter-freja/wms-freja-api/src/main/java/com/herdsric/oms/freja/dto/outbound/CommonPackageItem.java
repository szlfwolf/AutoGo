package com.herdsric.oms.freja.dto.outbound;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

@Data
public class CommonPackageItem {

	/**
	 * 明细行号
	 */
	private String lineNo;

	/**
	 * 货品编码
	 */
	@NotBlank(message = "货品编码不能为空")
	private String itemCode;

	/**
	 * 周转箱号
	 */
	@NotBlank(message = "周转箱号不能为空")
	private String boxNo;

	/**
	 * 包装单位
	 */
	@NotBlank(message = "包装单位不能为空")
	// @EnumCheck(value= UnitEnum.class, message = "单位格式不正确")
	private String unit;

	@NotBlank(message = "packQty不能为空")
	private String packQty;

	/**
	 * 长
	 */
	private String length = "0";

	/**
	 * 宽
	 */
	private String width = "0";

	/**
	 * 高
	 */
	private String height = "0";

	/**
	 * 毛重
	 */
	private String weight = "0";

	/**
	 * 净重
	 */
	private String netWeight = "0";

	/**
	 * 包装时间
	 */
	@JsonProperty("packagingtime")
	private String packagingTime;

	/**
	 * 包装类型
	 */
	@JsonProperty("packingtype")
	private String packingType;

}
