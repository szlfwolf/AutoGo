package com.herdsric.oms.freja.dto.inbound;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class InBoundDetails {

	@JsonProperty(index = 1)
	private String lineNo;

	@JsonProperty(index = 2)
	private String itemCode;

	@JsonProperty(index = 3)
	private String unit;

	@JsonProperty(index = 4)
	private double packQty;

	@JsonProperty(index = 5)
	private String boxNo;

	@JsonProperty(index = 6)
	private InBoundLotInfo lotInfo = new InBoundLotInfo();

}