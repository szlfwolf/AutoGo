package com.herdsric.oms.freja.dto.item;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class PackageUnits {

	@JsonProperty(index = 1)
	private String unit;

	@JsonProperty(index = 2)
	private String unitSn;

	@JsonProperty(index = 3)
	private int standardUnit;

	@JsonProperty(index = 4)
	private double convertFigure;

	@JsonProperty(index = 5)
	private double length;

	@JsonProperty(index = 6)
	private double width;

	@JsonProperty(index = 7)
	private double height;

	@JsonProperty(index = 8)
	private double weight;

	@JsonProperty(index = 9)
	private double netweight;

	@JsonProperty(index = 10)
	private String description;

	@JsonProperty(index = 11)
	private String extendedField1;

	@JsonProperty(index = 12)
	private String extendedField2;

	@JsonProperty(index = 13)
	private String extendedField3;

}
