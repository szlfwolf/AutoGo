package com.herdsric.oms.freja.dto.inventory;

import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class InventoryQueryDto {

	@NotBlank(message = "clientCode not blank")
	private String clientCode;

	@NotBlank(message = "warehouseCode not blank")
	private String warehouseCode;

	/**
	 * 快照版本时间，不传默认查询最新版本
	 */
	private String date;

	public void check() {
	}

}
