package com.herdsric.oms.freja.dto.inbound;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class InBoundLotInfo {

	@JsonProperty(index = 1)
	private String lot = "";

	@JsonProperty(index = 2)
	private String productDate = "";

	@JsonProperty(index = 3)
	private String euhsCode = "";

	@JsonProperty(index = 4)
	private String extendedField1 = "";

	/**
	 * 存放VIN
	 */
	@JsonProperty(index = 5)
	private String extendedField2 = "";

}