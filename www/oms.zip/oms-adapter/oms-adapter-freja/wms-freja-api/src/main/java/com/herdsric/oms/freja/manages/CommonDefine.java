package com.herdsric.oms.freja.manages;

import cn.hutool.core.util.StrUtil;
import com.herdsric.oms.common.client.common.BaseDefine;
import com.herdsric.oms.freja.FrejaConstant;

public class CommonDefine implements BaseDefine {

	@Override
	public boolean isSupport(String wmsType) {
		return StrUtil.equals(FrejaConstant.WMS_TYPE, wmsType);
	}

}
