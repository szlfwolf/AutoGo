package com.herdsric.oms.freja.dto.outbound;

import com.herdsric.oms.freja.FrejaConstant;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

@Data
public class PackageDetailDto {

	private String lineNo;

	/**
	 * WMS 暂时不会提供 默认设置为 空
	 */
	private String itemCode = "";

	/**
	 * WMS 暂时不会提供 默认设置为 PCS
	 */
	private String unit = "PCS";

	@NotBlank(message = "length 不能为空")
	@Pattern(regexp = FrejaConstant.GE_ZERO, message = "长度必须为0或正整数或者正浮点数")
	private String length;

	@NotBlank(message = "width 不能为空")
	@Pattern(regexp = FrejaConstant.GE_ZERO, message = "宽度必须为0或正整数或者正浮点数")
	private String width;

	@NotBlank(message = "height 不能为空")
	@Pattern(regexp = FrejaConstant.GE_ZERO, message = "高度必须为0或正整数或者正浮点数")
	private String height;

	@NotBlank(message = "weight 不能为空")
	@Pattern(regexp = FrejaConstant.GE_ZERO, message = "毛重必须为0或正整数或者正浮点数")
	private String weight;

	private String packagingTime;

	@NotBlank(message = "箱号不能为空")
	private String boxNo;

	private String netWeight;

	@NotBlank(message = "packingType 不能为空")
	@Pattern(regexp = "^PLT|PACL|SPLT|PL1|PL2|PL4|PL5|PL6|PL7|BOX|CLL|PKK$", message = "包装类型格式不支持")
	private String packingType;

	public PackageDetailDto init(String dateTime) {
		this.setLineNo("0");
		this.setItemCode("");
		this.setHeight("0");
		this.setLength("0");
		this.setWidth("0");
		this.setWeight("0");
		this.setNetWeight("0");
		this.setBoxNo("0");
		this.setPackagingTime(dateTime);
		this.setPackingType("PACL");
		return this;
	}

}
