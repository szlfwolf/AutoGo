package com.herdsric.oms.freja.dto.stock;

public class StockQuery {

	public void check() {
	}

}
