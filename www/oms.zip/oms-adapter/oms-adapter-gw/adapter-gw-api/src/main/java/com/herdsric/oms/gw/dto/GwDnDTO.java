package com.herdsric.oms.gw.dto;

import lombok.Data;

import javax.validation.constraints.NotEmpty;
import java.io.Serializable;
import java.util.List;

/**
 * GW DN
 *
 * @Author : liangzhenlei
 * @Date : 2024/4/16 16:05
 */
@Data
public class GwDnDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	// @ApiModelProperty(value = "客户唯一标识")
	@NotEmpty(message = "客户唯一标识不能为空")
	private String client;

	// @ApiModelProperty(value = "仓库code")
	@NotEmpty(message = "仓库code不能为空")
	private String warehouseCode;

	// @ApiModelProperty(value = "出库库单号")
	@NotEmpty(message = "出库单号不能为空")
	private String dnNo;

	// @ApiModelProperty("DN类型。默认NOMARL")
	private String dnType;

	// @ApiModelProperty("紧急类型：0: Stock Order; 1: VOR; 2:Urgent Order ，默认为0")
	private String urgentType;

	// @ApiModelProperty("DN计划发货时间:yyyy-MM-dd HH:mm:ss")
	private String planShipTime;

	// @ApiModelProperty("DN计划收货时间:yyyy-MM-dd HH:mm:ss")
	private String planDeliveryTime;

	// @ApiModelProperty("收件人姓名")
	@NotEmpty(message = "收件人姓名不能为空")
	private String consigneeName;

	// @ApiModelProperty("收件人手机、座机等联系方式")
	@NotEmpty(message = "收件人手机不能为空")
	private String consigneePhone;

	// @ApiModelProperty("收件人邮箱")
	private String consigneeEmail;

	// @ApiModelProperty("收件人所属国家代码")
	@NotEmpty(message = "收件人所属国家代码不能为空")
	private String addressCountryCode;

	// @ApiModelProperty("收件人地址省份")
	private String addressProvince;

	// @ApiModelProperty("收件人地址城市")
	@NotEmpty(message = "收件人地址城市不能为空")
	private String addressCity;

	// @ApiModelProperty("收件人地址县区")
	private String addressDistrict;

	// @ApiModelProperty("收件地址")
	@NotEmpty(message = "收件地址不能为空")
	private String address;

	// @ApiModelProperty("收件地址邮编")
	@NotEmpty(message = "收件地址邮编不能为空")
	private String addressZipcode;

	// @ApiModelProperty("收件人所属地址")
	private String consigneeCompany;

	// @ApiModelProperty("客户编号")
	private String customerNumber;

	// @ApiModelProperty("orderCode")
	@NotEmpty(message = "orderCode不能为空")
	private String orderCode;

	// @ApiModelProperty("备注")
	private String remark;

	// @ApiModelProperty("DN明细")
	@NotEmpty(message = "DN明细不能为空")
	private List<GwDnDTODetail> dnDetails;

}