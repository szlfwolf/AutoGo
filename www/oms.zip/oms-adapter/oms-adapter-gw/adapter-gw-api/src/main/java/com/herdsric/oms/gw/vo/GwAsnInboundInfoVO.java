package com.herdsric.oms.gw.vo;

import com.herdsric.oms.common.client.asn.domain.AsnOrderResponseDm;
import com.herdsric.oms.common.client.asn.domain.AsnOrderResponseLineDm;
import com.herdsric.oms.gw.common.GWConstant;
import com.herdsric.oms.gw.enums.GwAsnTypeEnum;
import com.herdsric.oms.gw.utils.DateDealUtil;
import lombok.Data;
import org.apache.commons.compress.utils.Lists;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;

/**
 * ASN-ORDER 入库反馈同步GW
 */
@Data
public class GwAsnInboundInfoVO implements Serializable {

	private static final long serialVersionUID = 1L;

	// @ApiModelProperty(value = "客户唯一标识")
	@NotEmpty(message = "客户唯一标识不能为空")
	private String client;

	// @ApiModelProperty(value = "仓库code")
	private String warehouseCode;

	// @ApiModelProperty(value = "入库单号")
	@NotEmpty(message = "入库单号不能为空")
	private String asnNo;

	// @ApiModelProperty(value = "供应商编号")
	private String supplierNo;

	// @ApiModelProperty(value = "操作时间")
	@NotEmpty(message = "操作时间不能为空")
	private String operateTime;

	// @ApiModelProperty("ASN类型。默认NOMARL")
	private String asnType;

	// @ApiModelProperty("是否手动上传")
	// private String manualUpload;

	// @ApiModelProperty("ASN明细")
	@NotEmpty(message = "ASN明细不能为空")
	@Valid
	private List<GwAsnInboundInfoDetailVO> asnDetails;

	@Data
	static class GwAsnInboundInfoDetailVO implements Serializable {

		private static final long serialVersionUID = 1L;

		private Integer id;

		// @ApiModelProperty("ASN行号")
		@NotEmpty(message = "行号不能为空")
		private String lineNo;

		// @ApiModelProperty("SKU编号")
		@NotEmpty(message = "SKU编号不能为空")
		private String skuNo;

		// @ApiModelProperty("数量")
		@NotNull(message = "数量不能为空")
		private Integer qty;

		// @ApiModelProperty("批次号")
		private String batchNo;

		// @ApiModelProperty(value = "regular")
		private String regular;

	}

	/**
	 * ASN-ORDER 入库反馈同步GW AsnOrderResponseDm对象转换GwAsnInboundInfoVO
	 * @return
	 */
	public static GwAsnInboundInfoVO asnOrderResponseConvert(AsnOrderResponseDm asnOrderResponseDm) {
		GwAsnInboundInfoVO gwAsnInboundInfoVO = new GwAsnInboundInfoVO();
		gwAsnInboundInfoVO.setClient(GWConstant.CLIENT_CODE);
		gwAsnInboundInfoVO.setWarehouseCode(asnOrderResponseDm.getWarehouseCode());
		gwAsnInboundInfoVO.setAsnNo(asnOrderResponseDm.getOrderNo());
		// gwAsnInboundInfoVO.setSupplierNo();
		gwAsnInboundInfoVO
				.setOperateTime(DateDealUtil.strDateFormat(asnOrderResponseDm.getOperateTime(), "yyyyMMddHHmmss"));

		gwAsnInboundInfoVO.setAsnType(GwAsnTypeEnum.getKey(asnOrderResponseDm.getOrderType()));
		List<GwAsnInboundInfoDetailVO> asnDetailList = Lists.newArrayList();
		for (AsnOrderResponseLineDm orderLine : asnOrderResponseDm.getOrderLines()) {
			GwAsnInboundInfoDetailVO gwAsnInboundInfoDetailVO = new GwAsnInboundInfoDetailVO();

			gwAsnInboundInfoDetailVO.setLineNo(orderLine.getLineNo());
			gwAsnInboundInfoDetailVO.setSkuNo(orderLine.getPartNumber());
			gwAsnInboundInfoDetailVO.setQty(orderLine.getQty());
			gwAsnInboundInfoDetailVO.setBatchNo(orderLine.getBatchNo());
			gwAsnInboundInfoDetailVO.setRegular("Y");
			asnDetailList.add(gwAsnInboundInfoDetailVO);

		}
		gwAsnInboundInfoVO.setAsnDetails(asnDetailList);
		return gwAsnInboundInfoVO;

	}

}