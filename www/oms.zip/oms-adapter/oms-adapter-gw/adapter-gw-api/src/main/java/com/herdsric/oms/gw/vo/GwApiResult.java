package com.herdsric.oms.gw.vo;

import com.herdsric.oms.gw.enums.GwResultCode;
import lombok.*;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * 响应信息主体
 */
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Accessors(chain = true)
public class GwApiResult<T> implements Serializable {

	private static final long serialVersionUID = 1L;

	@Getter
	@Setter
	private int status;

	@Getter
	@Setter
	private String statusMsg;

	@Getter
	@Setter
	private T data;

	public static <T> GwApiResult<T> failed(GwResultCode gwResultCode) {
		return restResult(null, gwResultCode.getCode(), gwResultCode.getDesc());
	}

	public static <T> GwApiResult<T> failed() {
		return restResult(null, GwResultCode.OTHER_ERROR.getCode(), GwResultCode.OTHER_ERROR.getDesc());
	}

	public static <T> GwApiResult<T> failed(int code, String msg) {
		return restResult(null, code, msg);
	}

	public static <T> GwApiResult<T> ok(T data) {
		return restResult(data, GwResultCode.SUCCESS.getCode(), GwResultCode.SUCCESS.getDesc());
	}

	public static <T> GwApiResult<T> ok() {
		return restResult(null, GwResultCode.SUCCESS.getCode(), GwResultCode.SUCCESS.getDesc());
	}

	private static <T> GwApiResult<T> restResult(T data, int status, String statusMsg) {
		GwApiResult<T> apiResult = new GwApiResult<>();
		apiResult.setStatus(status);
		apiResult.setData(data);
		apiResult.setStatusMsg(statusMsg);
		return apiResult;
	}

}