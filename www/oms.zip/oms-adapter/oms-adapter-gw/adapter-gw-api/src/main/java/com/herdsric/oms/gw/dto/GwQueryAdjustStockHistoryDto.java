package com.herdsric.oms.gw.dto;

import lombok.Data;
import java.util.List;

@Data
public class GwQueryAdjustStockHistoryDto {

	private String client;

	private String warehouseCode;

	private String date;

	private List<StockAdjustDetail> stockAdjustDetails;

}
