package com.herdsric.oms.gw.dto;

import lombok.Data;

@Data
public class StockAdjustDetail {

	private String skuNo;

	private int qty;

	private String remark;

}
