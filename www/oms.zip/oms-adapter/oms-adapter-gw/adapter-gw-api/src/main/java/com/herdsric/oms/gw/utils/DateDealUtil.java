package com.herdsric.oms.gw.utils;

import cn.hutool.core.date.DateUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;

/**
 * @Author : liangzhenlei
 * @Date : 2024/4/17 18:05
 */
@Slf4j
public class DateDealUtil {

	/**
	 * LocalDateTime 转换
	 */
	private final static DateTimeFormatter dtftime = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

	public static String parseDateStr(String strDate) {
		if (StringUtils.isEmpty(strDate)) {
			return null;
		}
		Date date = null;
		try {
			SimpleDateFormat parser = new SimpleDateFormat("yyyyMMddHHmmss");
			date = parser.parse(strDate);
			return DateUtil.format(date, "yyyy-MM-dd HH:mm:ss");
		}
		catch (ParseException e) {
			e.printStackTrace();
			log.error("格式化失败" + e.getMessage());
		}
		return null;
	}

	/**
	 * 获取当前北京时间字符串
	 * @return
	 */
	public static String getNowDateTimeUtc8Str() {
		LocalDateTime now = LocalDateTime.now(ZoneId.of("UTC+8"));
		return now.format(dtftime);
	}

	/***
	 * 时间转换
	 * @param date 转化的日期
	 * @param pattern 格式
	 * @return
	 */
	public static String strDateFormat(String date, String pattern) {
		if (StringUtils.isEmpty(date)) {
			return null;
		}
		try {
			SimpleDateFormat timeFormat1 = new SimpleDateFormat(pattern);
			return timeFormat1.format(DateUtil.parseDateTime(date));
		}
		catch (Exception e) {
			e.printStackTrace();
			log.error("时间转化异常:{}", e.getMessage());
		}
		return null;
	}

	/**
	 * 获取上一日yyyy-MM-dd
	 * @return
	 */
	public static String getYesterday() {
		return DateUtil.format(DateUtil.yesterday(), "yyyy-MM-dd");
	}

}
