package com.herdsric.oms.gw.utils;

import cn.hutool.core.date.DateUtil;
import com.herdsric.oms.common.client.asn.domain.AsnOrderDm;
import com.herdsric.oms.common.client.asn.domain.AsnOrderLineDm;
import com.herdsric.oms.common.client.dn.domain.DnOrderCancelDm;
import com.herdsric.oms.common.client.dn.domain.DnOrderDm;
import com.herdsric.oms.common.client.dn.domain.OrderLineDm;
import com.herdsric.oms.common.client.dn.dto.DnOrderResponseDTO;
import com.herdsric.oms.common.client.dn.function.DnOptionFlag;
import com.herdsric.oms.common.client.masterdata.domain.SkuDm;
import com.herdsric.oms.gw.common.GWConstant;
import com.herdsric.oms.gw.dto.*;
import com.herdsric.oms.gw.entity.GwMaterial;
import com.herdsric.oms.gw.enums.GwAsnTypeEnum;
import com.herdsric.oms.gw.enums.GwDnUrgentTypeEnum;
import com.herdsric.oms.gw.vo.GwCreateOutboundToInfoReq;
import com.herdsric.oms.gw.vo.GwUpdateDnStatusReq;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.compress.utils.Lists;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Author : liangzhenlei
 * @Date : 2024/4/17 17:47
 */
@Slf4j
@Component
public class GwAndOmsBeanCovUtil {

	private static final SimpleDateFormat portalTimeFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	@Value("${gw.boxDetails.containerNo:''}")
	private String containerNo;

	@Value("${gw.boxDetails.palletNo:''}")
	private String palletNo;

	private static final String yyyyMMddHHmmss = "yyyyMMddHHmmss";

	/**
	 * gw的主数据实体转化为OMS实体
	 * @param gwMaterial
	 * @return
	 */
	public SkuDm gwSkuToSkuDm(GwMaterial gwMaterial) {
		SkuDm res = new SkuDm();

		res.setBrand(GWConstant.CLIENT_CODE);
		// res.setSupplierCode();
		// res.setSupplierName();
		res.setPartNumber(gwMaterial.getCode());
		res.setNameCn(gwMaterial.getName());
		res.setNameEn(gwMaterial.getNameEN());
		res.setPartDesc(StringUtils.isBlank(gwMaterial.getNameEN()) ? gwMaterial.getName() : gwMaterial.getNameEN());
		if (GWConstant.PROPERTY_DANGEROUS_A.equals(gwMaterial.getProperty())
				|| GWConstant.PROPERTY_DANGEROUS_B.equals(gwMaterial.getProperty())) {
			res.setIsDangerous(GWConstant.COMMON_ONE);
		}
		// res.setIsStackAllowed();
		res.setIsAllowCross("1");
		// res.setIsKit();
		// res.setEan();
		// res.setHd();
		// res.setCarModel();
		res.setPartType1(gwMaterial.getMaterialGroup());
		res.setPartType2(gwMaterial.getMaterialGroup());
		res.setPartType3(gwMaterial.getSpecialPartType());
		// res.setPartType4();
		// res.setPartType5();
		// res.setOriginalSite();
		// res.setEuHscode();
		// res.setIsRepackage();
		// res.setRepackageType();
		// res.setSellingPrice();
		// res.setPurchasPrice();
		// res.setCurrencyUnit();
		// res.setStorageType();
		// res.setCapacity();
		// res.setExtendProps();
		SkuDm.PackageUnit packageUnit = new SkuDm.PackageUnit();

		packageUnit.setType("1");
		packageUnit.setLength("0");
		packageUnit.setWidth("0");
		packageUnit.setHeight("0");
		if (gwMaterial.getNetWeight() != null) {
			// 默认为KG
			if (!GWConstant.NET_WEIGHT_UNIT_G.equals(gwMaterial.getNetWeightUnit())) {
				packageUnit.setNetWeight(gwMaterial.getNetWeight().stripTrailingZeros().toPlainString());
			}
			else {
				packageUnit.setNetWeight(
						gwMaterial.getNetWeight().divide(new BigDecimal(1000), 2, BigDecimal.ROUND_HALF_UP)
								.stripTrailingZeros().toPlainString());
			}
		}
		packageUnit.setGrossWeight(packageUnit.getNetWeight());
		if (!GWConstant.QUANTITY_UNIT_PCE.equals(gwMaterial.getDeliveryUnit())) {
			packageUnit.setUnit(GWConstant.QUANTITY_UNIT_PCS);
		}
		else {
			packageUnit.setUnit(GWConstant.QUANTITY_UNIT_PCE);
		}
		packageUnit.setMoq(StringUtils.isBlank(gwMaterial.getDeliveryUnitNum())
				|| GWConstant.COMMON_ZERO.equals(gwMaterial.getDeliveryUnitNum().trim()) ? GWConstant.COMMON_ONE
						: gwMaterial.getDeliveryUnitNum());
		// packageUnit.setExtendProps(Maps.newHashMap());

		res.setPackageList(Collections.singletonList(packageUnit));
		// res.setKitList();
		// res.setReplaceList();
		return res;
	}

	/**
	 * asn数据实体转化为OMS实体
	 * @param gwAsnDTO
	 * @return
	 */
	public AsnOrderDm gwAsnDTOToAsnOrderDm(GwAsnDTO gwAsnDTO) {
		AsnOrderDm asnOrderDm = new AsnOrderDm();

		asnOrderDm.setOrderType(GwAsnTypeEnum.getAsnType(gwAsnDTO.getAsnType()));
		// TODO shippingMethod-->shipType 字段还未创建
		String shipType = gwAsnDTO.getShippingMethod();
		asnOrderDm.setOrderNo(gwAsnDTO.getAsnNo());
		asnOrderDm.setBillLandNum(gwAsnDTO.getBillNo());
		asnOrderDm.setEtdTime(gwAsnDTO.getPlanShipTime());
		// asnOrderDm.setCarrier();
		// asnOrderDm.setDestination();
		asnOrderDm.setInvoiceNum(gwAsnDTO.getInvoiceNo());
		// asnOrderDm.setPostDischarge();
		asnOrderDm.setEtaTime(gwAsnDTO.getPlanDeliveryTime());
		// asnOrderDm.setAtaTime();
		// asnOrderDm.setArrivalTime();
		// asnOrderDm.setPickUpTime();
		asnOrderDm.setSupplierCode(gwAsnDTO.getSupplierNo());
		// asnOrderDm.setRemark();
		// asnOrderDm.setExtendProps();

		List<AsnOrderLineDm> inboundOrderLineList = Lists.newArrayList();
		for (GwAsnDTODetail asnDetail : gwAsnDTO.getAsnDetails()) {
			AsnOrderLineDm inboundOrderLine = new AsnOrderLineDm();
			inboundOrderLine.setBatchNo(asnDetail.getBatchNo());
			inboundOrderLine.setLineNo(asnDetail.getLineNo());
			inboundOrderLine.setPartNumber(asnDetail.getSkuNo());
			inboundOrderLine.setQty(String.valueOf(asnDetail.getQty()));
			inboundOrderLine.setUnit(GWConstant.QUANTITY_UNIT_PCS);
			// inboundOrderLine.setVin();
			// inboundOrderLine.setRemark();
			// inboundOrderLine.setExtendProps();
			inboundOrderLine.setContainerNo(gwAsnDTO.getContainerNo());
			inboundOrderLine.setPalletNo(gwAsnDTO.getPalletNo());

			inboundOrderLineList.add(inboundOrderLine);
		}
		asnOrderDm.setOrderLines(inboundOrderLineList);
		return asnOrderDm;
	}

	public DnOrderDm gwDnToDnOrderDm(GwDnDTO gwDnDTO) {
		DnOrderDm dnOrderDm = new DnOrderDm();
		// dnOrderDm.setSequenceNo();
		dnOrderDm.setOrderType(GwDnUrgentTypeEnum.getUrgentType(gwDnDTO.getUrgentType()));
		dnOrderDm.setUrgentType(gwDnDTO.getUrgentType());
		dnOrderDm.setOrderNo(gwDnDTO.getDnNo());
		dnOrderDm.setWarehouseCode(gwDnDTO.getWarehouseCode());
		dnOrderDm.setCustomerCode(gwDnDTO.getCustomerNumber());
		dnOrderDm.setCountryCode(gwDnDTO.getAddressCountryCode());
		// dnOrderDm.setCountryName();
		dnOrderDm.setCityCode(gwDnDTO.getAddressCity());
		dnOrderDm.setProvinceCode(gwDnDTO.getAddressProvince());
		// dnOrderDm.setCityName();
		dnOrderDm.setAddress(gwDnDTO.getAddress());
		dnOrderDm.setZipCode(gwDnDTO.getAddressZipcode());
		dnOrderDm.setContactCompany(gwDnDTO.getConsigneeCompany());
		dnOrderDm.setContactName(gwDnDTO.getConsigneeName());
		dnOrderDm.setContactPhone(gwDnDTO.getConsigneePhone());
		dnOrderDm.setContactEmail(gwDnDTO.getConsigneeEmail());
		dnOrderDm.setExpectedShipDate(DateDealUtil.parseDateStr(gwDnDTO.getPlanShipTime()));
		dnOrderDm.setExpectedDeliveryDate(DateDealUtil.parseDateStr(gwDnDTO.getPlanDeliveryTime()));
		// dnOrderDm.setDeliveryType();
		dnOrderDm.setRemark(gwDnDTO.getRemark());
		Map<String, Object> map = new HashMap<>();
		map.put(GWConstant.orderCode, gwDnDTO.getOrderCode());
		map.put(GWConstant.dnType, gwDnDTO.getDnType());
		map.put(GWConstant.containerNo, containerNo);
		map.put(GWConstant.palletNo, palletNo);
		dnOrderDm.setExtendProps(map);
		List<GwDnDTODetail> dnDetails = gwDnDTO.getDnDetails();
		List<DnOrderDm.OrderLine> lineList = Lists.newArrayList();
		for (GwDnDTODetail dnDetail : dnDetails) {
			DnOrderDm.OrderLine orderLine = new DnOrderDm.OrderLine();
			orderLine.setBatchNo(dnDetail.getBatchNo());
			orderLine.setLineNo(dnDetail.getLineNo());
			orderLine.setPartNumber(dnDetail.getSkuNo());
			orderLine.setQty(Double.valueOf(dnDetail.getQty()));
			orderLine.setUnit(GWConstant.QUANTITY_UNIT_PCS);
			// orderLine.setVin();
			orderLine.setRemark(dnDetail.getDetailRemark());
			// orderLine.setExtendProps();

			lineList.add(orderLine);
		}
		dnOrderDm.setOrderLines(lineList);
		// dnOrderDm.setPfepTypeEnum();

		return dnOrderDm;
	}

	public DnOrderCancelDm gwCancelDNToDnOrderCancelDm(GwCancelOrderMaterialDTO gwCancelDTO) {
		DnOrderCancelDm dnOrderCancelDm = new DnOrderCancelDm();
		dnOrderCancelDm.setOrderNo(gwCancelDTO.getDnNo());
		dnOrderCancelDm.setReason("GW WMS取消订单");
		return dnOrderCancelDm;
	}

	/**
	 * TPT按照包裹维度后，状态不标准了，需要通过类型来判断
	 * @param dnOrderResponseDm
	 * @return
	 */
	public GwUpdateDnStatusReq dsnOrderResponseConvertPackage(DnOptionFlag flag, DnOrderResponseDTO dnOrderResponseDm) {

		GwUpdateDnStatusReq responseData = new GwUpdateDnStatusReq();
		responseData.setClient(GWConstant.CLIENT_CODE);
		responseData.setDnNo(dnOrderResponseDm.getOrderNo());
		responseData.setDnType(dnOrderResponseDm.getValue(GWConstant.dnType, String.class));
		responseData.setWarehouseCode(dnOrderResponseDm.getWarehouseCode());
		// gwUpdateDnStatusReq.setUrgentType();

		switch (flag) {
			case Cancelled:
				responseData.setDnStatus("NoInventory");
				responseData.setOperateTime(DateUtil.format(LocalDateTime.now(), yyyyMMddHHmmss));
				break;
			case Packed:
				responseData.setDnStatus("Packed");
				responseData.setOperateTime(DateDealUtil
						.strDateFormat(dnOrderResponseDm.getOrderLines().get(0).getPackageTime(), yyyyMMddHHmmss));
				break;
			case PickUp:
				responseData.setDnStatus("Solicitation");
				responseData
						.setOperateTime(DateDealUtil.strDateFormat(dnOrderResponseDm.getPickUpTime(), yyyyMMddHHmmss));
				break;
			case Delivery:
				responseData.setDnStatus("Closed");
				responseData.setOperateTime(DateDealUtil.strDateFormat(dnOrderResponseDm.getPodTime(), yyyyMMddHHmmss));
				break;

			default:
				log.error("orderNo:{}，未知的订单状态：{}", dnOrderResponseDm.getOrderNo(), flag);
				return null;
		}

		if (flag != DnOptionFlag.Cancelled) {
			List<GwUpdateDnStatusReq.GwUpdateDnStatusPackageReq> list = Lists.newArrayList();
			for (OrderLineDm orderLine : dnOrderResponseDm.getOrderLines()) {
				GwUpdateDnStatusReq.GwUpdateDnStatusPackageReq packageDetail = new GwUpdateDnStatusReq.GwUpdateDnStatusPackageReq();
				packageDetail.setLineNo(orderLine.getLineNo());
				packageDetail.setSkuNo(orderLine.getPartNumber());
				packageDetail.setQty(new BigDecimal(orderLine.getQty()).intValue());
				packageDetail.setBatchNo(orderLine.getBatchNo());
				packageDetail.setContainerNo(dnOrderResponseDm.getValue(GWConstant.containerNo, String.class));
				packageDetail.setPalletNo(dnOrderResponseDm.getValue(GWConstant.palletNo, String.class));
				packageDetail.setBoxNo(orderLine.getBoxNo());
				packageDetail.setLength(orderLine.getLength());
				packageDetail.setWidth(orderLine.getWidth());
				packageDetail.setHeight(orderLine.getHeight());
				packageDetail.setVolume(orderLine.getCbm());
				packageDetail.setGrossWeight(orderLine.getWeight());
				packageDetail.setNetWeight(orderLine.getNetWeight());

				list.add(packageDetail);
			}
			responseData.setPackageDetails(list);
		}

		return responseData;

	}

	public GwCreateOutboundToInfoReq dsnOrderResponseConvertPickUp(DnOrderResponseDTO dnOrderResponseDm) {
		GwCreateOutboundToInfoReq gwCreateOutboundToInfoReq = new GwCreateOutboundToInfoReq();
		gwCreateOutboundToInfoReq.setClient(GWConstant.CLIENT_CODE);
		gwCreateOutboundToInfoReq.setDnNo(dnOrderResponseDm.getOrderNo());
		gwCreateOutboundToInfoReq.setShipperCode(dnOrderResponseDm.getExpressCode());
		gwCreateOutboundToInfoReq.setShipperName(dnOrderResponseDm.getExpressCode());
		gwCreateOutboundToInfoReq.setShipperNo(dnOrderResponseDm.getTrackingNumber());
		gwCreateOutboundToInfoReq.setOrderCode(dnOrderResponseDm.getValue(GWConstant.orderCode, String.class));
		gwCreateOutboundToInfoReq.setPlanDeliveryTime(dnOrderResponseDm.getOmsEta());
		gwCreateOutboundToInfoReq.setWarehouseCode(dnOrderResponseDm.getWarehouseCode());
		List<GwCreateOutboundToInfoReq.GwDnPackageDetailReq> list = Lists.newArrayList();
		for (OrderLineDm orderLine : dnOrderResponseDm.getOrderLines()) {
			GwCreateOutboundToInfoReq.GwDnPackageDetailReq gwDnPackageDetailReq = new GwCreateOutboundToInfoReq.GwDnPackageDetailReq();
			gwDnPackageDetailReq.setContainerNo(dnOrderResponseDm.getValue(GWConstant.containerNo, String.class));
			gwDnPackageDetailReq.setPalletNo(dnOrderResponseDm.getValue(GWConstant.palletNo, String.class));
			gwDnPackageDetailReq.setBoxNo(orderLine.getBoxNo());
			gwDnPackageDetailReq.setLength(orderLine.getLength());
			gwDnPackageDetailReq.setWidth(orderLine.getWidth());
			gwDnPackageDetailReq.setHeight(orderLine.getHeight());
			gwDnPackageDetailReq.setVolume(orderLine.getCbm());
			gwDnPackageDetailReq.setGrossWeight(orderLine.getWeight());
			gwDnPackageDetailReq.setNetWeight(orderLine.getNetWeight());
			gwDnPackageDetailReq.setLineNo(orderLine.getLineNo());
			gwDnPackageDetailReq.setSkuNo(orderLine.getPartNumber());
			gwDnPackageDetailReq.setQty(orderLine.getQty());

			list.add(gwDnPackageDetailReq);
		}
		gwCreateOutboundToInfoReq.setBoxDetails(list);

		return gwCreateOutboundToInfoReq;

	}

}
