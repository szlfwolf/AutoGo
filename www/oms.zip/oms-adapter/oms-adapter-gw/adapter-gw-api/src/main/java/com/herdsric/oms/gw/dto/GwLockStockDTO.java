package com.herdsric.oms.gw.dto;

import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;

/**
 * @Author : liangzhenlei
 * @Date : 2024/4/16 16:05
 */
@Data
public class GwLockStockDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	/**
	 * 客户
	 */
	// @ApiModelProperty(value = "客户唯一标识")
	@NotEmpty(message = "客户唯一标识不能为空")
	private String client;

	/**
	 * 仓库编码
	 */
	// @ApiModelProperty(value = "仓库编码")
	@NotEmpty(message = "仓库编码")
	private String warehouseCode;

	/**
	 * 操作类型。lock：锁定；unlock：解锁
	 */
	// @ApiModelProperty(value = "操作类型")
	@NotEmpty(message = "操作类型不能为空")
	private String type;

	/**
	 * 调整原因等备注信息
	 */
	private String remark;

	/**
	 * 需要操作的skuNo列表
	 */
	// @ApiModelProperty("需要操作的skuNo列表")
	@NotEmpty(message = "需要操作的skuNo列表不能为空")
	@Valid
	private List<GwLockOrUnLockSkuStock> skuItems;

	@Data
	public static class GwLockOrUnLockSkuStock implements Serializable {

		private static final long serialVersionUID = 1L;

		/**
		 * sku
		 */
		// @ApiModelProperty(value = "skuNo")
		@NotEmpty(message = "skuNo不能为空")
		private String skuNo;

		/**
		 * 解锁 或 锁定数量
		 */
		// @ApiModelProperty(value = "解锁锁定数量")
		@NotNull(message = "qty不能为null")
		private Integer qty;

	}

}