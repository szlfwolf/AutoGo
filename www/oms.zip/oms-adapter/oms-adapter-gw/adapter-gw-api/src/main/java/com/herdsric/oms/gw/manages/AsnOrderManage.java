package com.herdsric.oms.gw.manages;

import cn.hutool.core.bean.BeanUtil;
import com.herdsric.oms.common.client.asn.AsnBizDefine;
import com.herdsric.oms.common.client.asn.domain.AsnOrderDm;
import com.herdsric.oms.common.client.asn.domain.AsnOrderResponseDm;
import com.herdsric.oms.common.client.asn.dto.AsnOrderResponseDTO;
import com.herdsric.oms.common.client.asn.function.AsnOptionFlag;
import com.herdsric.oms.common.client.asn.process.AsnProcessor;
import com.herdsric.oms.common.core.util.SpringContextHolder;
import com.herdsric.oms.common.webhook.CallbackHttpDefine;
import com.herdsric.oms.gw.vo.GwAsnInboundInfoVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.function.Function;

/**
 * @Author : liangzhenlei
 * @Date : 2024/4/16 16:05
 */
@Slf4j
@RequiredArgsConstructor
public class AsnOrderManage extends CommonDefine implements AsnBizDefine {

	@Override
	public void save(AsnOrderDm asnOrderDm) {
		AsnProcessor asnProcessor = SpringContextHolder.getBean(AsnProcessor.class);
		asnProcessor.addAsnOrder(asnOrderDm);
	}

	@Override
	public void asnOrderResponseByWebhook(String clientCode, String type, String orderNo) {

		AsnProcessor asnProcessor = SpringContextHolder.getBean(AsnProcessor.class);
		Function<AsnOptionFlag, Function<AsnOrderResponseDTO, Boolean>> function = x -> {
			switch (x) {
				case Manual:
					return dm -> {
						log.info("{},AsnOrder:{}, 手动上传订单，不需要反馈", clientCode, orderNo);
						return false;
					};
				case Responsed:
				case Closed:
					return dm -> {
						CallbackHttpDefine callbackHttpDefine = SpringContextHolder.getBean(CallbackHttpDefine.class);
						// 对象处理,特色业务逻辑
						AsnOrderResponseDm asnOrderResponseDm = BeanUtil.copyProperties(dm, AsnOrderResponseDm.class);
						GwAsnInboundInfoVO gwAsnInboundInfoVO = GwAsnInboundInfoVO
								.asnOrderResponseConvert(asnOrderResponseDm);
						callbackHttpDefine.execute(true, clientCode, dm.getWarehouseCode(), dm.getOrderNo(),
								gwAsnInboundInfoVO, type, false);
						return true;
					};
				default:
					return dm -> {
						// 其他情况不需要反馈
						return true;
					};
			}
		};

		asnProcessor.asnOrderResponse(clientCode, type, orderNo, function);
	}

}
