package com.herdsric.oms.gw.gwapi;

import com.dtflys.forest.annotation.Header;
import com.dtflys.forest.annotation.JSONBody;
import com.dtflys.forest.annotation.Post;
import com.dtflys.forest.annotation.Var;
import com.herdsric.oms.gw.dto.GwQueryAdjustStockHistoryDto;
import com.herdsric.oms.gw.dto.GwStockDamageHistoryDTO;
import com.herdsric.oms.gw.entity.GwCreateOutboundToInfoRes;
import com.herdsric.oms.gw.entity.GwMaterialRes;

import java.util.Map;

/**
 * @Author : liangzhenlei
 * @Date : 2024/4/17 18:29
 */
public interface GwHttpApi {

	@Post(url = "${url}", dataType = "json", contentType = "application/json", charset = "UTF-8")
	GwMaterialRes selectMaterial(@Var("url") String url, @Header Map<String, String> headers,
			@JSONBody Map<String, Object> parMap);

	@Post(url = "${url}", dataType = "json", contentType = "application/json", charset = "UTF-8")
	GwCreateOutboundToInfoRes sendStockAdjustHistoryToClientReq(@Var("url") String url, @Header("apiKey") String apiKey,
			@JSONBody GwQueryAdjustStockHistoryDto gwQueryAdjustStockHistoryDto);

	@Post(url = "${url}", dataType = "json", contentType = "application/json", charset = "UTF-8")
	GwCreateOutboundToInfoRes sendStockDamageHistoryToClientReq(@Var("url") String url, @Header("apiKey") String apiKey,
			@JSONBody GwStockDamageHistoryDTO gwStockDamageHistoryDTO);

}
