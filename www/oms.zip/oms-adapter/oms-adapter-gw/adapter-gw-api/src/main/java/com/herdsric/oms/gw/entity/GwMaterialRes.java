package com.herdsric.oms.gw.entity;

import lombok.Data;

import java.util.List;

/**
 * @Author : liangzhenlei
 * @Date : 2024/4/16 16:05
 */
@Data
public class GwMaterialRes {

	private String code;

	private GwMaterialResChild result;

	@Data
	public static class GwMaterialResChild {

		private Integer page;

		private Integer total;

		private List<GwMaterial> rows;

		private String message;

	}

}