package com.herdsric.oms.gw.dto;

import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import java.io.Serializable;
import java.util.List;

/**
 * GW ASN
 *
 * @Author : liangzhenlei
 * @Date : 2024/4/16 16:05
 */
@Data
public class GwAsnDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	// @ApiModelProperty(value = "客户唯一标识")
	@NotEmpty(message = "客户唯一标识不能为空")
	private String client;

	// @ApiModelProperty(value = "仓库code")
	@NotEmpty(message = "仓库code不能为空")
	private String warehouseCode;

	// @ApiModelProperty(value = "入库单号")
	@NotEmpty(message = "入库单号不能为空")
	private String asnNo;

	// @ApiModelProperty(value = "供应商编号")
	private String supplierNo;

	// @ApiModelProperty("ASN计划发货时间:yyyy-MM-dd HH:mm:ss")
	@NotEmpty(message = "计划发货时间不能为空")
	// @JsonProperty(value = "ETD")
	private String planShipTime;

	// @ApiModelProperty("ASN计划收货时间:yyyy-MM-dd HH:mm:ss")
	@NotEmpty(message = "计划收获时间不能为空")
	// @JsonProperty(value = "ETA")
	private String planDeliveryTime;

	// @ApiModelProperty(value = "发票号")
	private String invoiceNo;

	// @ApiModelProperty("提运单号")
	private String billNo;

	// @ApiModelProperty("ASN类型。默认NOMARL")
	@NotEmpty(message = "asn类型不能为空")
	private String asnType;

	// @ApiModelProperty("发运方式")
	private String shippingMethod;

	// @ApiModelProperty("船名（集装箱号）")
	@NotBlank(message = "集装箱号不能为空")
	// @JsonProperty(value = "CONTAINER")
	private String containerNo;

	// @ApiModelProperty("托盘号")
	@NotBlank(message = "托盘号不能为空")
	private String palletNo;

	// @ApiModelProperty("ASN明细")
	@NotEmpty(message = "ASN明细不能为空")
	@Valid
	private List<GwAsnDTODetail> asnDetails;

}