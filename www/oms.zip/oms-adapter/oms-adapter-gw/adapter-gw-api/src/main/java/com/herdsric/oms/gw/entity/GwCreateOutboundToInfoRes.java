package com.herdsric.oms.gw.entity;

import lombok.Data;

/**
 * @Description: 装箱信息通知客户返回
 * @author: Dzx
 * @date: 2022.06.07
 */
@Data
public class GwCreateOutboundToInfoRes {

	/**
	 *
	 */
	private String status;

	/**
	 * 提示信息
	 */
	private String statusMsg;

	/**
	 * 返回数据
	 */
	private Object data;

}