package com.herdsric.oms.gw.enums;

public enum ApiTypeEnum {

	/**
	 * GW DN ORDER 同步客户 （PICK_UP创建）
	 */
	GW_DN_ORDER_RETURN_PICK_UP_CREATE,

	/**
	 * GW DN ORDER 同步客户 （PICK_UP状态反馈）
	 */
	GW_DN_ORDER_RETURN_PICK_UP_INFO,

}
