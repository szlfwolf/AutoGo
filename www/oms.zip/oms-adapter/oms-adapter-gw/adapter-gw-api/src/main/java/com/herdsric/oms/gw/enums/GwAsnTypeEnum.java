package com.herdsric.oms.gw.enums;

import com.alibaba.excel.util.StringUtils;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum GwAsnTypeEnum {

	NORMAL("0", "ZCRK"), RETURN("1", "THRK");

	private final String key;

	private final String asnType;

	/***
	 * 获取asnType
	 * @param key 传入key
	 * @return
	 */
	public static String getAsnType(String key) {
		if (StringUtils.isEmpty(key)) {
			return GwAsnTypeEnum.NORMAL.getAsnType();
		}
		for (GwAsnTypeEnum enums : GwAsnTypeEnum.values()) {
			if (enums.key.equals(key)) {
				return enums.getAsnType();
			}
		}

		return GwAsnTypeEnum.NORMAL.getAsnType();
	}

	/***
	 * 获取key
	 * @param asnType 传入asnType
	 * @return
	 */
	public static String getKey(String asnType) {
		if (StringUtils.isEmpty(asnType)) {
			return GwAsnTypeEnum.NORMAL.getKey();
		}
		for (GwAsnTypeEnum enums : GwAsnTypeEnum.values()) {
			if (enums.asnType.equals(asnType)) {
				return enums.getKey();
			}
		}
		return GwAsnTypeEnum.NORMAL.getKey();
	}

}