package com.herdsric.oms.gw.manages;

import cn.hutool.core.convert.Convert;
import cn.hutool.core.date.DateUtil;
import com.herdsric.oms.common.client.dn.DnBizDefine;
import com.herdsric.oms.common.client.dn.domain.DnOrderCancelDm;
import com.herdsric.oms.common.client.dn.domain.DnOrderDm;
import com.herdsric.oms.common.client.dn.dto.DnOrderResponseDTO;
import com.herdsric.oms.common.client.dn.enums.OrderSplitTypeEnum;
import com.herdsric.oms.common.client.dn.function.DnOptionFlag;
import com.herdsric.oms.common.client.dn.handle.DnOrderSplitFunction;
import com.herdsric.oms.common.client.dn.handle.SplitStrategy;
import com.herdsric.oms.common.client.dn.process.DnOrderProcessor;
import com.herdsric.oms.common.client.enums.PfepTypeEnum;
import com.herdsric.oms.common.client.enums.SyncEnum;
import com.herdsric.oms.common.core.util.SpringContextHolder;
import com.herdsric.oms.common.security.util.SecurityUtils;
import com.herdsric.oms.common.webhook.CallbackHttpDefine;
import com.herdsric.oms.gw.common.GWConstant;
import com.herdsric.oms.gw.enums.ApiTypeEnum;
import com.herdsric.oms.gw.enums.GwDnUrgentTypeEnum;
import com.herdsric.oms.gw.utils.DateDealUtil;
import com.herdsric.oms.gw.utils.GwAndOmsBeanCovUtil;
import com.herdsric.oms.gw.vo.GwCreateOutboundToInfoReq;
import com.herdsric.oms.gw.vo.GwUpdateDnStatusReq;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.function.Function;

/**
 * @Author : liangzhenlei
 * @Date : 2024/4/16 16:06
 */
@Slf4j
@RequiredArgsConstructor
public class DnOrderManage extends CommonDefine implements DnBizDefine {

	@Override
	public void save(DnOrderDm dnOrderDm) {
		dnOrderDm.setPfepTypeEnum(PfepTypeEnum.NO_BY_WAREHOUSE_CODE);
		dnOrderDm.setTypeEnum(OrderSplitTypeEnum.OS_00);

		DnOrderSplitFunction dnOrderSplitFunction = SplitStrategy.getStrategyFunction(dnOrderDm.getTypeEnum());
		dnOrderSplitFunction.preHandle(SecurityUtils.getTokenSupportClient(), dnOrderDm);
	}

	@Override
	public void dnOrderResponseByWebhook(String clientCode, String type, String batchNo) {
		DnOrderProcessor dnOrderProcessor = SpringContextHolder.getBean(DnOrderProcessor.class);
		CallbackHttpDefine callbackHttpDefine = SpringContextHolder.getBean(CallbackHttpDefine.class);
		GwAndOmsBeanCovUtil updateDnStatusReq = SpringContextHolder.getBean(GwAndOmsBeanCovUtil.class);

		Function<DnOptionFlag, Function<DnOrderResponseDTO, Boolean>> function = x -> {
			switch (x) {
				case Manual:
					return dm -> {
						log.info("{},BatchNo:{},dnOrder:{} 手动上传订单，不需要反馈", clientCode, batchNo, dm.getOrderNo());
						return false;
					};
				case Released:
					return dm -> {
						log.info("{},BatchNo:{},dnOrder:{} Released WMS，不需要反馈", clientCode, batchNo, dm.getOrderNo());
						return false;
					};
				case Booked:
					return dm -> {
						log.info("{},BatchNo:{},dnOrder:{} Booked，不需要反馈", clientCode, batchNo, dm.getOrderNo());
						return false;
					};
				case PickUp:
					return dm -> {
						GwUpdateDnStatusReq gwUpdateDnStatusReq = updateDnStatusReq.dsnOrderResponseConvertPackage(x,
								dm);
						callbackHttpDefine.execute(true, clientCode, dm.getWarehouseCode(), dm.getOrderNo(),
								gwUpdateDnStatusReq, ApiTypeEnum.GW_DN_ORDER_RETURN_PICK_UP_INFO.name(), true);

						GwCreateOutboundToInfoReq createOutboundToInfoReq = updateDnStatusReq
								.dsnOrderResponseConvertPickUp(dm);
						callbackHttpDefine.execute(true, clientCode, dm.getWarehouseCode(), dm.getOrderNo(),
								createOutboundToInfoReq, ApiTypeEnum.GW_DN_ORDER_RETURN_PICK_UP_CREATE.name(), true);
						return true;
					};
				case Cancelled:
				case Packed:
				case Delivery:
					return dm -> {
						GwUpdateDnStatusReq gwUpdateDnStatusReq = updateDnStatusReq.dsnOrderResponseConvertPackage(x,
								dm);
						callbackHttpDefine.execute(true, clientCode, dm.getWarehouseCode(), dm.getOrderNo(),
								gwUpdateDnStatusReq, type, true);
						return true;
					};
				default:
					return dm -> {
						// 其他情况不需要反馈
						return true;
					};
			}
		};

		dnOrderProcessor.dnOrderResponse(clientCode, type, batchNo, function);
	}

	@Override
	public void cancelDnOrder(String clientCode, DnOrderCancelDm dnOrderCancelDm) {
		DnOrderProcessor dnOrderProcessor = SpringContextHolder.getBean(DnOrderProcessor.class);
		dnOrderProcessor.dnOrderCancel(clientCode, dnOrderCancelDm);

	}

	@Override
	public void dnOrderCancelByWebhook(String clientCode, String batchNo) {

		DnOrderProcessor dnOrderProcessor = SpringContextHolder.getBean(DnOrderProcessor.class);
		Function<DnOptionFlag, Function<DnOrderResponseDTO, Boolean>> function = x -> {
			switch (x) {
				case Manual:
					return dm -> {
						log.info("{},BatchNo:{},dnOrder:{} 手动上传订单，不需要反馈", clientCode, batchNo, dm.getOrderNo());
						return false;
					};
				case Cancelled:
					return dm -> {
						GwUpdateDnStatusReq gwUpdateDnStatusReq = new GwUpdateDnStatusReq();
						gwUpdateDnStatusReq.setDnType(Convert.toStr(dm.getValue(GWConstant.dnType, String.class), ""));
						gwUpdateDnStatusReq.setUrgentType(GwDnUrgentTypeEnum.getUrgentKey(dm.getOrderType()));
						gwUpdateDnStatusReq.setClient(clientCode);
						gwUpdateDnStatusReq.setWarehouseCode(dm.getWarehouseCode());
						gwUpdateDnStatusReq.setDnNo(dm.getOrderNo());
						gwUpdateDnStatusReq.setDnStatus("Cancelled");
						gwUpdateDnStatusReq
								.setOperateTime(DateDealUtil.strDateFormat(DateUtil.now(), "yyyyMMddHHmmss"));

						CallbackHttpDefine callbackHttpDefine = SpringContextHolder.getBean(CallbackHttpDefine.class);
						callbackHttpDefine.execute(true, clientCode, gwUpdateDnStatusReq.getWarehouseCode(),
								gwUpdateDnStatusReq.getDnNo(), gwUpdateDnStatusReq,
								SyncEnum.DN_ORDER_CANCEL_SYNC.name(), true);
						return true;
					};
				default:
					return dm -> {
						// 其他情况不需要反馈
						return true;
					};
			}
		};

		dnOrderProcessor.dnOrderCancelByWebhook(clientCode, batchNo, function);
	}

}
