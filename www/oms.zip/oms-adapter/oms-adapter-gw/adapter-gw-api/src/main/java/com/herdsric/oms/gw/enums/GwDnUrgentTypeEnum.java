package com.herdsric.oms.gw.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

@Getter
@AllArgsConstructor
public enum GwDnUrgentTypeEnum {

	STOCK_ORDER("0", "Stock Order"), URGENT_ORDER("1", "Urgent Order"),;

	private String key;

	private String urgentType;

	/***
	 * 获取urgentType
	 * @param key 传入key
	 * @return
	 */
	public static String getUrgentType(String key) {
		if (StringUtils.isEmpty(key)) {
			return GwDnUrgentTypeEnum.STOCK_ORDER.getUrgentType();
		}
		for (GwDnUrgentTypeEnum enums : GwDnUrgentTypeEnum.values()) {
			if (enums.key.equals(key)) {
				return enums.getUrgentType();
			}
		}

		return GwDnUrgentTypeEnum.STOCK_ORDER.getUrgentType();
	}

	/***
	 * 获取key
	 * @param urgentType 传入urgentType
	 * @return
	 */
	public static String getUrgentKey(String urgentType) {
		if (StringUtils.isEmpty(urgentType)) {
			return GwDnUrgentTypeEnum.STOCK_ORDER.getKey();
		}
		for (GwDnUrgentTypeEnum enums : GwDnUrgentTypeEnum.values()) {
			if (urgentType.equals(enums.urgentType)) {
				return enums.getKey();
			}
		}
		return GwDnUrgentTypeEnum.STOCK_ORDER.getKey();
	}

}