package com.herdsric.oms.gw.vo;

import cn.hutool.core.util.StrUtil;
import com.herdsric.oms.common.client.dn.domain.DnOrderResponseDm;
import com.herdsric.oms.gw.common.GWConstant;
import lombok.Data;
import org.apache.commons.compress.utils.Lists;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * 出库单的状态及出库详情参数
 */
@Data
public class GwUpdateDnStatusReq implements Serializable {

	private static final long serialVersionUID = 1L;

	/**
	 * 客户唯一标识
	 */
	private String client;

	/**
	 * 出库单号
	 */
	private String dnNo;

	/**
	 * DN类型，默认NOMARL
	 */
	private String dnType;

	/**
	 * 紧急类型，默认Regular。[“Regular”, “Urgent”]
	 */
	private String urgentType;

	/**
	 * DN当前状态。 Picking 开始拣货; Picked 拣货完成; Packing 开始打包 ; Packed 打包完成 ; Shipped 订车完成;
	 * Solicitation 揽件出库 ; Closed 签收完成；Cancelled 取消成功；NoInventory 整单无库存
	 */
	private String dnStatus;

	/**
	 * 操作时间。格式yyyyMMddHHmmss
	 */
	private String operateTime;

	/**
	 * 仓库编码
	 */
	private String warehouseCode;

	/**
	 * 出库打包明细。打包完成之后有数据，具体字段如下
	 */
	private List<GwUpdateDnStatusPackageReq> packageDetails;

	@Data
	public static class GwUpdateDnStatusPackageReq implements Serializable {

		private static final long serialVersionUID = 1L;

		/**
		 * 行号。对应出库单指令中的行号
		 */
		private String lineNo;

		/**
		 * sku编号
		 */
		private String skuNo;

		/**
		 * 实际出库数量。最小单位数量，如果一行拆成多个箱子打包，这里需要汇总值
		 */
		private Integer qty;

		/**
		 * 批次号
		 */
		private String batchNo;

		/**
		 * 集装箱号。固定值
		 */
		private String containerNo;

		/**
		 * 托盘号
		 */
		private String palletNo;

		/**
		 * 批次号
		 */
		private String boxNo;

		/**
		 * 批次号
		 */
		private String length;

		/**
		 * 批次号
		 */
		private String width;

		/**
		 * 批次号
		 */
		private String height;

		/**
		 * 批次号
		 */
		private String volume;

		/**
		 * 批次号
		 */
		private String grossWeight;

		/**
		 * 批次号
		 */
		private String netWeight;

	}

}