package com.herdsric.oms.gw.dto;

import lombok.Data;

/**
 * @author ：lzq
 * @date ：Created in 2022/6/9 15:26 @description：
 * @modified By：
 * @version: $
 */
@Data
public class DamageStockSnapshotVo {

	private String skuNo;

	private int qty;

	private String warehouseCode;

	private int damageQty;

	private int pendingQty;

	private int lockedQty;

	private int availableQty;

	private String remark = "";

}