package com.herdsric.oms.gw.manages;

import cn.hutool.core.util.StrUtil;
import com.herdsric.oms.common.client.common.BaseDefine;
import com.herdsric.oms.gw.common.GWConstant;

/**
 * @Author : liangzhenlei
 * @Date : 2024/4/16 16:05
 */
public class CommonDefine implements BaseDefine {

	@Override
	public boolean isSupport(String clientCode) {
		return StrUtil.equals(GWConstant.CLIENT_CODE, clientCode);
	}

}
