package com.herdsric.oms.gw.entity;

import lombok.Data;

import java.math.BigDecimal;

/**
 * @Author : liangzhenlei
 * @Date : 2024/4/16 16:05
 */
@Data
// @ApiModel(value = "主数据")
public class GwMaterial {

	private static final long serialVersionUID = 1L;

	// @ApiModelProperty(value = "配件编码")
	private String code;

	// @ApiModelProperty(value = "配件名称")
	private String name;

	// @ApiModelProperty(value = "配件名称-英文")
	private String nameEN;

	// @ApiModelProperty(value = "配件名称-本土语言")
	private String nameLocal;

	// @ApiModelProperty(value = "工厂编码")
	private String factoryCode;

	// @ApiModelProperty(value = "工厂名称")
	private String factoryname;

	// @ApiModelProperty(value = "区域")
	private String region;

	// @ApiModelProperty(value = "发货基本单位")
	private String basicUnitNum;

	// @ApiModelProperty(value = "发货单位")
	private String deliveryUnit;

	// @ApiModelProperty(value = "发货单位数量")
	private String deliveryUnitNum;

	// @ApiModelProperty(value = "物料组")
	private String materialGroup;

	// @ApiModelProperty(value = "采购基本单位数量")
	private String basicUnitNum2;

	// @ApiModelProperty(value = "采购订单单位")
	private String purchaseOrderUnit;

	// @ApiModelProperty(value =
	// "配件状态：1=删除,2=替换,3=正常,4=因采购/仓库而被冻结,5=因任务清单/BOM而被冻结,6=冻结采购,7=冻结库存移动")
	private String status;

	// @ApiModelProperty(value = "配件净重，长度：（20,3）")
	private BigDecimal netWeight;

	// @ApiModelProperty(value = "净重单位")
	private String netWeightUnit;

	// @ApiModelProperty(value = "包装体积，长度：（20,15）")
	private Double packingVolume;

	// @ApiModelProperty(value = "包装体积单位")
	private String packingVolumeUnit;

	// @ApiModelProperty(value = "运输方式：1=空运2=海运3=快递4=随车5=铁运（多种运输方式使用逗号分隔）")
	private String transportType;

	// @ApiModelProperty(value = "配件属性：1=常规件,2=A类危险品(禁报),3=B类危险品,4=特殊件")
	private String property;

	// @ApiModelProperty(value = "特殊件类型：1=车身总成,2=车厢总成,3=发动机类,4=车架,5=变速器控制单元,6=ECU")
	private String specialPartType;

	// @ApiModelProperty(value = "更新时间")
	private String updateTime;

	// @ApiModelProperty(value = "更新时间-时间戳表示")
	private String updateTimeStamp;

}