package com.herdsric.oms.gw.vo;

import lombok.Data;

@Data
public class GwQueryAdjustStockHistoryVo {

	private String client;

	private String warehouseCode;

	private String skuNo;

	private int qty;

}