package com.herdsric.oms.gw.dto;

import lombok.Data;

import java.util.List;

@Data
public class GwStockDamageHistoryDTO {

	private String client;

	private String date;

	private String warehouseCode;

	List<DamageStockSnapshotVo> stockDamageDetails;

}