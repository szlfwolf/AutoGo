package com.herdsric.oms.gw.common;

public interface GWConstant {

	String CLIENT_CODE = "GW";

	String COMMON_ONE = "1";

	String COMMON_ZERO = "0";

	/**
	 * 数量单位
	 */
	String QUANTITY_UNIT_PCS = "PCS";

	String QUANTITY_UNIT_PCE = "PCE";

	/**
	 * 净重单位
	 */
	String NET_WEIGHT_UNIT_G = "G";

	/**
	 * 危险品判断
	 */
	String PROPERTY_DANGEROUS_A = "2";

	String PROPERTY_DANGEROUS_B = "3";

	String orderCode = "orderCode";

	String dnType = "dnType";

	String containerNo = "containerNo";

	String palletNo = "palletNo";

}
