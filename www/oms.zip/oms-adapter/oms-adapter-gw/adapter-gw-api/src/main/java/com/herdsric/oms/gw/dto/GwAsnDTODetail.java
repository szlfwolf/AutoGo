package com.herdsric.oms.gw.dto;

import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * GW ASN 详情
 *
 * @Author : liangzhenlei
 * @Date : 2024/4/16 16:05
 */
@Data
public class GwAsnDTODetail implements Serializable {

	private static final long serialVersionUID = 1L;

	// @ApiModelProperty("ASN行号")
	@NotEmpty(message = "行号不能为空")
	private String lineNo;

	// @ApiModelProperty("SKU编号")
	private String skuNo;

	// @ApiModelProperty("数量")
	@NotNull(message = "数量不能为空")
	private Integer qty;

	// @ApiModelProperty("批次号")
	private String batchNo;

}