package com.herdsric.oms.gw.enums;

import com.herdsric.oms.gw.common.GWConstant;

public enum GwResultCode {

	SUCCESS(0, "成功"), OTHER_ERROR(1, "其他异常"), CLIENT_ERROR(3, "该接口只支持" + GWConstant.CLIENT_CODE + "客户使用,请检查传入的客户");

	private int code;

	private String desc;

	private GwResultCode(int code, String desc) {
		this.code = code;
		this.desc = desc;
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

}
