package com.herdsric.oms.gw.manages;

import com.herdsric.oms.common.client.stock.StockDefine;
import com.herdsric.oms.common.client.stock.domain.StockDm;
import com.herdsric.oms.common.client.stock.domain.StockLogDm;
import com.herdsric.oms.common.client.stock.dto.StockDTO;
import com.herdsric.oms.common.client.stock.process.StockProcessor;
import com.herdsric.oms.common.core.util.SpringContextHolder;
import com.herdsric.oms.common.security.util.SecurityUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

/**
 * @Author : liangzhenlei
 * @Date : 2024/4/16 16:06
 */
@Slf4j
@RequiredArgsConstructor
public class StockManage extends CommonDefine implements StockDefine {

	@Override
	public List<StockDm> queryStock(StockDTO stockDTO) {
		StockProcessor stockProcessor = SpringContextHolder.getBean(StockProcessor.class);
		String clientCode = SecurityUtils.getTokenSupportClient();
		return stockProcessor.listStock(clientCode, stockDTO);
	}

	@Override
	public List<StockLogDm> queryStockLog(String warehouseCode, List<String> partNumbers, String type) {
		return null;
	}

	@Override
	public boolean stockLogSync(String clientCode, String warehouseCode, String refNo, String type) {
		return false;
	}

}
