package com.herdsric.oms.gw.dto;

import lombok.Data;

import javax.validation.constraints.NotEmpty;

/**
 * GW 取消 DN订单
 *
 * @Author : liangzhenlei
 * @Date : 2024/4/16 16:05
 */
@Data
public class GwCancelOrderMaterialDTO {

	/**
	 * 出库单号
	 */
	@NotEmpty(message = "出库单号不能为空")
	private String dnNo;

	/**
	 * 仓库编码
	 */
	@NotEmpty(message = "仓库编码不能为空")
	private String warehouseCode;

	/**
	 * 客户唯一标识
	 */
	@NotEmpty(message = "客户唯一标识不能为空")
	private String client;

}