package com.herdsric.oms.gw.vo;

import cn.hutool.core.util.StrUtil;
import com.herdsric.oms.common.client.dn.domain.DnOrderResponseDm;
import com.herdsric.oms.gw.common.GWConstant;
import lombok.Data;
import org.apache.commons.compress.utils.Lists;

import java.math.BigDecimal;
import java.util.List;

/**
 * 将出库单的装箱信息通知客户请求参数
 */
@Data
public class GwCreateOutboundToInfoReq {

	/**
	 * 客户
	 */
	private String client;

	/**
	 * 出库单号
	 */
	private String dnNo;

	/**
	 * 承运商编号。订车完成之后有数据
	 */
	private String shipperCode;

	/**
	 * 承运商名称。订车完成之后有数据
	 */
	private String shipperName;

	/**
	 * 快递单号。订车完成之后有数据
	 */
	private String shipperNo;

	/**
	 * DN计划收货时间。格式yyyyMMddHHmmss
	 */
	private String planDeliveryTime;

	/**
	 * orderCode
	 */
	private String orderCode;

	/**
	 * 仓库编码
	 */
	private String warehouseCode;

	/**
	 * 包装信息
	 */
	private List<GwDnPackageDetailReq> boxDetails;

	@Data
	public static class GwDnPackageDetailReq {

		/**
		 * 集装箱号。固定值
		 */
		private String containerNo;

		/**
		 * 托盘号。固定值
		 */
		private String palletNo;

		/**
		 * 包装箱号
		 */
		private String boxNo;

		/**
		 * 包装箱子的长（单位：米）
		 */
		private String length;

		/**
		 * 包装箱子的宽（单位：米）
		 */
		private String width;

		/**
		 * 包装箱子的高（单位：米）
		 */
		private String height;

		/**
		 * 集装箱的体积
		 */
		private String volume;

		/**
		 * 毛重（单位kg）
		 */
		private String grossWeight;

		/**
		 * 净重（单位kg）
		 */
		private String netWeight;

		/**
		 * 行号
		 */
		private String lineNo;

		/**
		 * sku编号
		 */
		private String skuNo;

		/**
		 * 该箱子装了该行号的sku数量
		 */
		private String qty;

	}

}
