package com.herdsric.oms.gw.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@Data
@ConfigurationProperties(prefix = "gw.api")
public class GwApiConfig {

	private String apiKey;

	private String warehouseCode;

	private String server;

	private String selectMaterialAppKey;

	private String selectMaterialAppSecret;

	private String selectMaterialUrl;

	private String appKey;

	private String secretKey;

}