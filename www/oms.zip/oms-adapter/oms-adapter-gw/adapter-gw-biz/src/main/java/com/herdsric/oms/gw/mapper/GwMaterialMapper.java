package com.herdsric.oms.gw.mapper;

import com.herdsric.oms.gw.dto.DamageStockSnapshotVo;
import com.herdsric.oms.gw.vo.GwQueryAdjustStockHistoryVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @Author : liangzhenlei
 * @Date : 2024/4/25 16:13
 */
@Mapper
public interface GwMaterialMapper {

	List<GwQueryAdjustStockHistoryVo> queryAdjustStockHistoryByGw(@Param("client") String client,
			@Param("yesterday") String yesterday, @Param("now") String now);

	List<DamageStockSnapshotVo> queryDamageStockHistoryByGw(@Param("client") String client,
			@Param("yesterday") String yesterday, @Param("damageOrNot") String damageOrNot);

}
