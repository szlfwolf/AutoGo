package com.herdsric.oms.gw.service;

import com.herdsric.oms.gw.dto.GwAsnDTO;
import com.herdsric.oms.gw.dto.GwCancelOrderMaterialDTO;
import com.herdsric.oms.gw.dto.GwDnDTO;
import com.herdsric.oms.gw.vo.GwApiResult;

/**
 * @Author : liangzhenlei
 * @Date : 2024/4/17 17:25
 */
public interface GwMaterialService {

	/**
	 * 添加主数据
	 */
	void addMaterial();

	/**
	 * 添加ASN
	 * @param gwAsnDTO
	 * @return
	 */
	GwApiResult addAsn(GwAsnDTO gwAsnDTO);

	/**
	 * 添加DN
	 * @param gwDnDTO
	 * @return
	 */
	GwApiResult addDn(GwDnDTO gwDnDTO);

	/**
	 * DN 取消
	 * @param gwCancelDTO
	 * @return
	 */
	GwApiResult cancelDn(GwCancelOrderMaterialDTO gwCancelDTO);

	/**
	 * gw发送库存盘点调整记录
	 */
	void syncStockAdjustHistory();

	/**
	 * gw发送损耗库存记录
	 */
	void syncStockDamageHistory();

}
