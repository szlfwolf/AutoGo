package com.herdsric.oms.gw.apis;

import com.herdsric.oms.gw.dto.GwAsnDTO;
import com.herdsric.oms.gw.service.GwMaterialService;
import com.herdsric.oms.gw.vo.GwApiResult;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * @Author : liangzhenlei
 * @Date : 2024/4/17 16:51
 */
@RestController
@RequestMapping("/apis/gw/asn")
@Tag(name = "GW AnOrderApis对外接口")
@Validated
@RequiredArgsConstructor
@Slf4j
public class AsnOrderApis {

	private final GwMaterialService gwMaterialService;

	@PostMapping("/receive")
	public GwApiResult receive(@RequestBody @Valid GwAsnDTO gwAsnDTO) {
		return gwMaterialService.addAsn(gwAsnDTO);
	}

}
