package com.herdsric.oms.gw.config;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @author ：lzq
 * @date ：Created in 2022/6/24 10:39 @description：
 * @modified By：
 * @version: $
 */
@Component
@Data
public class GwConfig {

	@Value("${gw.url.syncStockAdjustHistoryUrl}")
	private String syncStockAdjustHistoryUrl;

	@Value("${gw.url.syncStockDamageHistoryUrl}")
	private String syncStockDamageHistoryUrl;

}
