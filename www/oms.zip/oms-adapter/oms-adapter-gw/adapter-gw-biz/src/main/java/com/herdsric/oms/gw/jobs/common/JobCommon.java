package com.herdsric.oms.gw.jobs.common;

import cn.hutool.core.util.StrUtil;
import com.herdsric.oms.common.job.common.JobTask;

/**
 * @Author : liangzhenlei
 * @Date : 2024/4/17 17:04
 */
public class JobCommon {

	private static final String JOB_KEY_PREFIX = "GW-JOB-TASK";

	public static class JobName {

		/**
		 * sku同步到oms
		 */
		public static final String SKU = "skuCreate";

		/**
		 * 发送上一日库存调整记录
		 */
		public static final String STOCK_ADJUST_HISTORY = "stockAdjustHistory";

		/**
		 * 发送上一日库存损耗调整记录
		 */
		public static final String STOCK_DAMAGE_HISTORY = "stockDamageHistory";

		/**
		 * DN PickUp 订单状态更新
		 */
		public static final String DN_ORDER_RETURN_PICK_UP_INFO = "dnOrderReturnPickUpInfo";

		/**
		 * DN PickUp 订单创建
		 */
		public static final String DN_ORDER_RETURN_PICK_UP_CREATE = "dnOrderReturnPickUpCreate";

	}

	public enum TaskEnum implements JobTask {

		/**
		 * 从GW查询SKU同步到OMS
		 */
		SKU(JobName.SKU, 30, "从GW查询SKU同步到OMS"),
		/**
		 * 发送上一日库存调整记录
		 */
		STOCK_ADJUST_HISTORY(JobName.STOCK_ADJUST_HISTORY, 30, "发送上一日库存调整记录"),
		/**
		 * 发送上一日库存损耗调整记录
		 */
		STOCK_DAMAGE_HISTORY(JobName.STOCK_DAMAGE_HISTORY, 30, "发送上一日库存损耗调整记录"),
		/**
		 * DN PickUp 订单状态更新
		 */
		DN_ORDER_RETURN_PICK_UP_INFO(JobName.DN_ORDER_RETURN_PICK_UP_INFO, 30, "ASN/DN 回传客户失败重试"),
		/**
		 * DN PickUp 订单创建
		 */
		DN_ORDER_RETURN_PICK_UP_CREATE(JobName.DN_ORDER_RETURN_PICK_UP_CREATE, 30, "DN PickUp 订单创建");

		public String name;

		public int expireTime;

		public String desc;

		TaskEnum(String name, int expireTime, String desc) {
			this.name = name;
			this.expireTime = expireTime;
			this.desc = desc;
		}

		public String getDesc() {
			return StrUtil.concat(true, this.desc);
		}

		@Override
		public String getName() {
			return name;
		}

		@Override
		public int expireTime() {
			return expireTime;
		}

		@Override
		public String getDescription() {
			return getDesc();
		}

		public String getKey() {
			return StrUtil.concat(true, JOB_KEY_PREFIX, this.name);
		}

	}

}
