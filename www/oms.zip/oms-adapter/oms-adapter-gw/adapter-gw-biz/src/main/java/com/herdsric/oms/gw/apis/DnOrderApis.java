package com.herdsric.oms.gw.apis;

import com.herdsric.oms.gw.dto.GwCancelOrderMaterialDTO;
import com.herdsric.oms.gw.dto.GwDnDTO;
import com.herdsric.oms.gw.service.GwMaterialService;
import com.herdsric.oms.gw.vo.GwApiResult;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/**
 * @Author : liangzhenlei
 * @Date : 2024/4/17 16:59
 */
@RestController
@RequestMapping("/apis/gw/dn")
@Tag(name = "GW DnOrderApis对外接口")
@Validated
@RequiredArgsConstructor
public class DnOrderApis {

	private final GwMaterialService gwMaterialService;

	@PostMapping("/receive")
	public GwApiResult receive(@RequestBody @Valid GwDnDTO gwDnDTO) {
		return gwMaterialService.addDn(gwDnDTO);
	}

	@PostMapping("/cancellation")
	public GwApiResult cancellation(@RequestBody @Valid GwCancelOrderMaterialDTO GwCancelDTO) {
		return gwMaterialService.cancelDn(GwCancelDTO);
	}

}
