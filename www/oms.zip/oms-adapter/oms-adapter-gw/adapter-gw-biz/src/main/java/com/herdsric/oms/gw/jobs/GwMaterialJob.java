package com.herdsric.oms.gw.jobs;

import cn.hutool.core.util.StrUtil;
import com.herdsric.oms.common.core.constant.CommonConstants;
import com.herdsric.oms.common.core.constant.SecurityConstants;
import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.common.feign.client.RemoteBizRecordService;
import com.herdsric.oms.common.job.common.AbstractCommonTask;
import com.herdsric.oms.gw.common.GWConstant;
import com.herdsric.oms.gw.enums.ApiTypeEnum;
import com.herdsric.oms.gw.jobs.common.JobCommon;
import com.herdsric.oms.gw.service.GwMaterialService;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * @Author : liangzhenlei
 * @Date : 2024/4/17 17:03
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class GwMaterialJob extends AbstractCommonTask {

	private final GwMaterialService gwMaterialService;

	private final RemoteBizRecordService remoteBizRecordService;

	@XxlJob(JobCommon.JobName.SKU)
	public void skuCreate() {
		this.execute(JobCommon.TaskEnum.SKU, x -> {
			gwMaterialService.addMaterial();
		});
	}

	@XxlJob(JobCommon.JobName.STOCK_ADJUST_HISTORY)
	public void stockAdjustHistory() {
		this.execute(JobCommon.TaskEnum.STOCK_ADJUST_HISTORY, x -> {
			gwMaterialService.syncStockAdjustHistory();
		});
	}

	@XxlJob(JobCommon.JobName.STOCK_DAMAGE_HISTORY)
	public void stockDamageHistory() {
		this.execute(JobCommon.TaskEnum.STOCK_DAMAGE_HISTORY, x -> {
			gwMaterialService.syncStockDamageHistory();
		});
	}

	@XxlJob(JobCommon.JobName.DN_ORDER_RETURN_PICK_UP_INFO)
	public void dnOrderReturnPickUpInfo() {
		this.execute(JobCommon.TaskEnum.DN_ORDER_RETURN_PICK_UP_INFO, x -> {
			R result = remoteBizRecordService.jobTrigger(ApiTypeEnum.GW_DN_ORDER_RETURN_PICK_UP_INFO.name(),
					GWConstant.CLIENT_CODE, SecurityConstants.FROM_IN);
			if (result.getCode() != CommonConstants.SUCCESS) {
				log.info(StrUtil.format("查询反馈数据feign调用失败,错误信息:{}", result.getMsg()));
			}
		});
	}

	@XxlJob(JobCommon.JobName.DN_ORDER_RETURN_PICK_UP_CREATE)
	public void dnOrderReturnPickUpCreate() {
		this.execute(JobCommon.TaskEnum.DN_ORDER_RETURN_PICK_UP_CREATE, x -> {
			R result = remoteBizRecordService.jobTrigger(ApiTypeEnum.GW_DN_ORDER_RETURN_PICK_UP_CREATE.name(),
					GWConstant.CLIENT_CODE, SecurityConstants.FROM_IN);
			if (result.getCode() != CommonConstants.SUCCESS) {
				log.info(StrUtil.format("查询反馈数据feign调用失败,错误信息:{}", result.getMsg()));
			}
		});
	}

}
