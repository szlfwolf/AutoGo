package com.herdsric.oms.gw.service.impl;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.cloud.commons.lang.StringUtils;
import com.herdsric.oms.common.client.asn.domain.AsnOrderDm;
import com.herdsric.oms.common.client.dn.domain.DnOrderCancelDm;
import com.herdsric.oms.common.client.dn.domain.DnOrderDm;
import com.herdsric.oms.common.client.masterdata.domain.SkuDm;
import com.herdsric.oms.common.core.constant.SecurityConstants;
import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.common.feign.client.RemoteAsnOrderService;
import com.herdsric.oms.common.feign.client.RemoteDnOrderService;
import com.herdsric.oms.common.feign.client.RemoteSkuService;
import com.herdsric.oms.common.webhook.utils.gw.GwSignatureTool;
import com.herdsric.oms.gw.common.GWConstant;
import com.herdsric.oms.gw.config.AdapterConfig;
import com.herdsric.oms.gw.config.GwApiConfig;
import com.herdsric.oms.gw.config.GwConfig;
import com.herdsric.oms.gw.dto.*;
import com.herdsric.oms.gw.entity.GwCreateOutboundToInfoRes;
import com.herdsric.oms.gw.entity.GwMaterial;
import com.herdsric.oms.gw.entity.GwMaterialRes;
import com.herdsric.oms.gw.enums.GwResultCode;
import com.herdsric.oms.gw.gwapi.GwHttpApi;
import com.herdsric.oms.gw.mapper.GwMaterialMapper;
import com.herdsric.oms.gw.service.GwMaterialService;
import com.herdsric.oms.gw.utils.DateDealUtil;
import com.herdsric.oms.gw.utils.GwAndOmsBeanCovUtil;
import com.herdsric.oms.gw.utils.HmacSignUtil;
import com.herdsric.oms.gw.vo.GwApiResult;
import com.herdsric.oms.gw.vo.GwQueryAdjustStockHistoryVo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @Author : liangzhenlei
 * @Date : 2024/4/17 17:25
 */
@Slf4j
@Service
public class GwMaterialServiceImpl implements GwMaterialService {

	@Resource
	private GwAndOmsBeanCovUtil gwAndOmsBeanCovUtil;

	@Resource
	private RemoteSkuService remoteSkuService;

	@Resource
	private RemoteAsnOrderService remoteAsnOrderService;

	@Resource
	private RemoteDnOrderService remoteDnOrderService;

	@Resource
	private GwMaterialMapper gwMaterialMapper;

	@Resource
	private GwHttpApi gwApi;

	@Resource
	private GwApiConfig gwApiConfig;

	@Resource
	private GwConfig gwConfig;

	@Resource
	private AdapterConfig adapterConfig;

	@Override
	public void addMaterial() {
		try {
			int pageSize = 100;
			int totalPages = 0;
			Map<String, Object> parMap = new HashMap<>(6);
			parMap.put("region", "EU");
			parMap.put("factoryCode", "EU12");
			parMap.put("page", "1");
			parMap.put("size", pageSize);
			// 获取北京时间
			String updateTimeEnd = DateDealUtil.getNowDateTimeUtc8Str();
			String updateTimeStart = DateUtil
					.formatDateTime(DateUtil.offsetHour(DateUtil.parseDateTime(updateTimeEnd), -25));
			log.info("当前请求gw主数据开始时间:{}——结束时间:{}", updateTimeStart, updateTimeEnd);
			parMap.put("updateTimeStart", updateTimeStart);
			parMap.put("updateTimeEnd", updateTimeEnd);
			Map<String, String> headers = HmacSignUtil.createSignHeader(gwApiConfig.getSelectMaterialAppKey(),
					gwApiConfig.getSelectMaterialAppSecret(), gwApiConfig.getSelectMaterialUrl(), "post");
			GwMaterialRes gwMaterials = gwApi.selectMaterial(gwApiConfig.getSelectMaterialUrl(), headers, parMap);
			if (gwMaterials == null || !"200".equals(gwMaterials.getCode())) {
				log.error("查询GW主数据信息错误,返回数据{}", gwMaterials);
				return;
			}
			Integer totalRows = gwMaterials.getResult().getTotal();
			List<GwMaterial> gwMaterialList = new ArrayList<>(totalRows);
			gwMaterialList.addAll(gwMaterials.getResult().getRows());
			// 计算总页数
			if ((totalRows % pageSize) == 0) {
				totalPages = totalRows / pageSize;
			}
			else {
				totalPages = totalRows / pageSize + 1;
			}
			// 总数大于100去循环往后查
			if (totalRows > 100) {
				// 循环查询
				for (int i = 2; i <= totalPages; i++) {
					parMap.put("page", i);
					try {
						GwMaterialRes gwMaterialRes = gwApi.selectMaterial(gwApiConfig.getSelectMaterialUrl(), headers,
								parMap);
						if (gwMaterialRes == null || !"200".equals(gwMaterialRes.getCode())) {
							log.error("查询GW主数据信息错误,返回数据{}", gwMaterialRes);
							continue;
						}
						gwMaterialList.addAll(gwMaterialRes.getResult().getRows());
					}
					catch (Exception e) {
						log.error("处理GW主数据下发消息发生错误!", e);
					}
				}
			}
			if (CollectionUtils.isEmpty(gwMaterialList)) {
				return;
			}
			log.info("gw主数据查到{}条", gwMaterialList.size());
			List<SkuDm> skuDmList = new ArrayList<>();
			// 转化实体
			for (GwMaterial item : gwMaterialList) {
				// 如果中文名称和英文名称为空sku不处理
				if (StringUtils.isBlank(item.getName()) && StringUtils.isBlank(item.getNameEN())) {
					continue;
				}
				// 转化实体
				SkuDm skuDm = gwAndOmsBeanCovUtil.gwSkuToSkuDm(item);
				skuDmList.add(skuDm);
			}

			try {
				// 请求OMS
				R result = remoteSkuService.saveBatch(skuDmList, GWConstant.CLIENT_CODE, SecurityConstants.FROM_IN);
				// 结果判断
				if (result.getCode() == 0) {
					log.debug("GW sku同步数据结果：{}", result.getMsg());
				}
			}
			catch (Exception e) {
				log.warn("GW sku同步数据到oms失败： {}", e.getMessage());
				log.error("GW sku同步数据到oms失败：", e);
			}
		}
		catch (Exception ex) {
			log.error("处理GW主数据下发消息发生错误!", ex);
		}
	}

	@Override
	public GwApiResult addAsn(GwAsnDTO gwAsnDTO) {
		try {
			// 校验入参
			GwApiResult gwApiResult = checkAsn(gwAsnDTO);
			if (GwResultCode.SUCCESS.getCode() != gwApiResult.getStatus()) {
				return gwApiResult;
			}
			// 转化实体
			AsnOrderDm asnOrderDm = gwAndOmsBeanCovUtil.gwAsnDTOToAsnOrderDm(gwAsnDTO);
			// 请求OMS
			R omsResult = remoteAsnOrderService.save(asnOrderDm, GWConstant.CLIENT_CODE, SecurityConstants.FROM_IN);
			log.info("GW 发送ASN到OMS成功，返回结果：{}", omsResult);
			// 结果判断
			if (null != omsResult && 0 == omsResult.getCode()) {
				log.info("OMS对GW ASN指令处理成功");
				return GwApiResult.ok().setStatusMsg("success");
			}
			else {
				log.info("OMS对GW ASN指令处理失败");
				return GwApiResult.failed().setStatusMsg(omsResult.getMsg());
			}
		}
		catch (Exception e) {
			log.error("处理GW的asn下发消息发生错误!", e);
			return GwApiResult.failed().setStatusMsg("处理GW的asn下发消息发生未知错误");
		}
	}

	@Override
	public GwApiResult addDn(GwDnDTO gwDnDTO) {
		try {
			// 校验入参
			GwApiResult gwApiResult = checkDn(gwDnDTO);
			if (GwResultCode.SUCCESS.getCode() != gwApiResult.getStatus()) {
				return gwApiResult;
			}
			// 转化实体
			DnOrderDm dnOrderDm = gwAndOmsBeanCovUtil.gwDnToDnOrderDm(gwDnDTO);

			dnOrderDm.setContactEmail(StrUtil.isBlank(dnOrderDm.getContactEmail()) ? adapterConfig.getDnEmail()
					: dnOrderDm.getContactEmail());

			// 请求OMS
			R result = remoteDnOrderService.save(dnOrderDm, GWConstant.CLIENT_CODE, SecurityConstants.FROM_IN);
			log.info("GW 发送DN到OMS成功，返回结果：{}", result);
			// 结果判断
			if (null != result && 0 == result.getCode()) {
				log.info("OMS对GW DN指令处理成功");
				return GwApiResult.ok().setStatusMsg("success");
			}
			else {
				log.info("OMS对GW DN指令处理失败");
				return GwApiResult.failed().setStatusMsg(result.getMsg());
			}
		}
		catch (Exception ex) {
			log.error("处理GW新增出库单消息发生错误!", ex);
			return GwApiResult.failed().setStatusMsg("处理GW新增出库单消息发生错误");
		}
	}

	@Override
	public GwApiResult cancelDn(GwCancelOrderMaterialDTO gwCancelDTO) {
		try {
			if (!GWConstant.CLIENT_CODE.equals(gwCancelDTO.getClient())) {
				log.info("GW出库单取消不是{}客户", GWConstant.CLIENT_CODE);
				return GwApiResult.failed(GwResultCode.CLIENT_ERROR);
			}
			// 转化实体
			DnOrderCancelDm dnOrderCancelDm = gwAndOmsBeanCovUtil.gwCancelDNToDnOrderCancelDm(gwCancelDTO);
			// 请求OMS
			R result = remoteDnOrderService.cancelDnOrder(dnOrderCancelDm, GWConstant.CLIENT_CODE,
					SecurityConstants.FROM_IN);
			log.info("GW 发送DN Cancel 到OMS成功，返回结果：{}", result);
			// 结果判断
			if (null != result && 0 == result.getCode()) {
				log.info("GW 出库单取消处理成功");
				return GwApiResult.ok();
			}
			else if (null == result) {
				return GwApiResult.failed();
			}
			else {
				log.info("GW 出库单取消失败");
				return GwApiResult.failed(result.getCode(), result.getMsg());
			}
		}
		catch (Exception ex) {
			log.error("GW对取消订单消息发生错误!", ex);
			return GwApiResult.failed();
		}
	}

	@Override
	public void syncStockAdjustHistory() {
		log.info("开始发送库存调整记录到GW");
		try {
			// 加密url
			String signUrl = GwSignatureTool.getSignUrl(gwApiConfig.getAppKey(), gwApiConfig.getSecretKey(),
					gwConfig.getSyncStockAdjustHistoryUrl());
			LocalDateTime now = LocalDateTime.now();
			// 获取昨天的同一时间
			LocalDateTime yesterday = now.minus(1, ChronoUnit.DAYS);
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			String formatNow = now.format(formatter);
			String formattedYesterday = yesterday.format(formatter);
			// 过滤掉盘点后结算数量为0的零件
			List<GwQueryAdjustStockHistoryVo> stockHistoryVoList = gwMaterialMapper
					.queryAdjustStockHistoryByGw(GWConstant.CLIENT_CODE, formattedYesterday, formatNow);
			if (CollectionUtil.isEmpty(stockHistoryVoList)) {

				GwQueryAdjustStockHistoryDto gwQueryAdjustStockHistoryDto = new GwQueryAdjustStockHistoryDto();
				gwQueryAdjustStockHistoryDto.setClient(GWConstant.CLIENT_CODE);
				gwQueryAdjustStockHistoryDto.setWarehouseCode(gwApiConfig.getWarehouseCode());
				gwQueryAdjustStockHistoryDto.setDate(DateUtil.format(DateUtil.parse(DateUtil.now()), "yyyyMMddHHmmss"));
				gwQueryAdjustStockHistoryDto.setStockAdjustDetails(Collections.emptyList());

				GwCreateOutboundToInfoRes gwCreateOutboundToInfoRes = gwApi.sendStockAdjustHistoryToClientReq(signUrl,
						gwApiConfig.getApiKey(), gwQueryAdjustStockHistoryDto);

				if (GWConstant.COMMON_ZERO.equals(gwCreateOutboundToInfoRes.getStatus())) {
					log.info("发送库存调整记录到gw成功:{}", gwQueryAdjustStockHistoryDto);
				}
				else {
					log.error("发送库存调整记录到gw失败:{}", gwQueryAdjustStockHistoryDto);
				}
				return;
			}
			// 根据仓库code分组
			Map<String, List<GwQueryAdjustStockHistoryVo>> collect = stockHistoryVoList.stream()
					.collect(Collectors.groupingBy(GwQueryAdjustStockHistoryVo::getWarehouseCode));
			collect.keySet().forEach(x -> {
				GwQueryAdjustStockHistoryDto gwQueryAdjustStockHistoryDto = new GwQueryAdjustStockHistoryDto();
				gwQueryAdjustStockHistoryDto.setClient(GWConstant.CLIENT_CODE);
				gwQueryAdjustStockHistoryDto.setWarehouseCode(x);
				gwQueryAdjustStockHistoryDto.setDate(DateUtil.format(DateUtil.parse(DateUtil.now()), "yyyyMMddHHmmss"));
				List<StockAdjustDetail> stockAdjustDetails = new ArrayList<>();
				collect.get(x).forEach(y -> {
					StockAdjustDetail stockAdjustDetail = new StockAdjustDetail();
					stockAdjustDetail.setSkuNo(y.getSkuNo());
					stockAdjustDetail.setQty(y.getQty());
					// stockAdjustDetail.setRemark();
					stockAdjustDetails.add(stockAdjustDetail);
				});
				gwQueryAdjustStockHistoryDto.setStockAdjustDetails(stockAdjustDetails);
				// 给gw发送请求
				log.info("{}同步库存盘点数据：{}", GWConstant.CLIENT_CODE, gwQueryAdjustStockHistoryDto);
				GwCreateOutboundToInfoRes gwCreateOutboundToInfoRes = gwApi.sendStockAdjustHistoryToClientReq(signUrl,
						gwApiConfig.getApiKey(), gwQueryAdjustStockHistoryDto);
				if (GWConstant.COMMON_ZERO.equals(gwCreateOutboundToInfoRes.getStatus())) {
					log.info("发送库存调整记录到gw成功:{}", gwQueryAdjustStockHistoryDto);
				}
				else {
					log.error("发送库存调整记录到gw失败:{}", gwQueryAdjustStockHistoryDto);
				}
			});
		}
		catch (Exception e) {
			log.error("发送库存调整记录到gw出现未知异常:{}", e.getMessage());
		}
	}

	@Override
	public void syncStockDamageHistory() {

		log.info("开始发送损耗调整记录到GW");
		try {
			// 加密url
			String signUrl = GwSignatureTool.getSignUrl(gwApiConfig.getAppKey(), gwApiConfig.getSecretKey(),
					gwConfig.getSyncStockDamageHistoryUrl());
			GwStockDamageHistoryDTO gwStockDamageHistoryDTO = new GwStockDamageHistoryDTO();
			// 记录成功和失败
			List<GwStockDamageHistoryDTO> successfulList = new ArrayList<>();
			List<GwStockDamageHistoryDTO> failList = new ArrayList<>();
			List<DamageStockSnapshotVo> damageStockSnapshotVos = gwMaterialMapper
					.queryDamageStockHistoryByGw(GWConstant.CLIENT_CODE, DateDealUtil.getYesterday(), "1");
			if (null == damageStockSnapshotVos || damageStockSnapshotVos.isEmpty()) {

				gwStockDamageHistoryDTO.setClient(GWConstant.CLIENT_CODE);
				gwStockDamageHistoryDTO.setWarehouseCode(gwApiConfig.getWarehouseCode());
				gwStockDamageHistoryDTO.setDate(DateUtil.format(DateUtil.parse(DateUtil.now()), "yyyyMMddHHmmss"));
				gwStockDamageHistoryDTO.setStockDamageDetails(Collections.emptyList());
				// 给gw发送请求
				GwCreateOutboundToInfoRes gwCreateOutboundToInfoRes = gwApi.sendStockDamageHistoryToClientReq(signUrl,
						gwApiConfig.getApiKey(), gwStockDamageHistoryDTO);

				if (GWConstant.COMMON_ZERO.equals(gwCreateOutboundToInfoRes.getStatus())) {
					successfulList.add(gwStockDamageHistoryDTO);
					log.info("发送损耗库存调整记录到gw成功:{}", gwStockDamageHistoryDTO);
				}
				else {
					failList.add(gwStockDamageHistoryDTO);
					log.error("发送损耗库存调整记录到gw失败:{}", gwStockDamageHistoryDTO);
				}
				log.info("发送给gw的损耗库存调整记录成功:{}次", successfulList.size());
				log.info("发送给gw的损耗库存调整记录失败:{}次", failList.size());
				return;
			}

			// 根据仓库code分组
			Map<String, List<DamageStockSnapshotVo>> collect = damageStockSnapshotVos.stream()
					.collect(Collectors.groupingBy(DamageStockSnapshotVo::getWarehouseCode));
			for (Map.Entry<String, List<DamageStockSnapshotVo>> stringListEntry : collect.entrySet()) {
				gwStockDamageHistoryDTO.setClient(GWConstant.CLIENT_CODE);
				gwStockDamageHistoryDTO.setWarehouseCode(stringListEntry.getKey());
				gwStockDamageHistoryDTO.setDate(DateUtil.format(DateUtil.parse(DateUtil.now()), "yyyyMMddHHmmss"));
				gwStockDamageHistoryDTO.setStockDamageDetails(stringListEntry.getValue());
				// 给gw发送请求
				GwCreateOutboundToInfoRes gwCreateOutboundToInfoRes = gwApi.sendStockDamageHistoryToClientReq(signUrl,
						gwApiConfig.getApiKey(), gwStockDamageHistoryDTO);
				if (GWConstant.COMMON_ZERO.equals(gwCreateOutboundToInfoRes.getStatus())) {
					successfulList.add(gwStockDamageHistoryDTO);
					log.info("发送损耗库存调整记录到gw成功:{}", gwStockDamageHistoryDTO);
				}
				else {
					failList.add(gwStockDamageHistoryDTO);
					log.error("发送损耗库存调整记录到gw失败:{}", gwStockDamageHistoryDTO);
				}
			}
			log.info("发送给gw的损耗库存调整记录成功:{}次", successfulList.size());
			log.info("发送给gw的损耗库存调整记录失败:{}次", failList.size());

		}
		catch (Exception e) {
			log.error("发送损耗库存调整记录到gw出现未知异常:{}", e.getMessage());
		}
	}

	public GwApiResult checkAsn(GwAsnDTO gwAsnDTO) {

		if (!GWConstant.CLIENT_CODE.equals(gwAsnDTO.getClient())) {
			log.info("gw addAsn用户名出错");
			return GwApiResult.failed().setStatusMsg("用户名错误");
		}

		try {
			gwAsnDTO.setPlanDeliveryTime(DateDealUtil.parseDateStr(gwAsnDTO.getPlanDeliveryTime()));
			gwAsnDTO.setPlanShipTime(DateDealUtil.parseDateStr(gwAsnDTO.getPlanShipTime()));
		}
		catch (Exception e) {
			log.error("校验asn时间出错:{}", e);
			return GwApiResult.failed().setStatusMsg("时间格式错误");
		}
		return GwApiResult.ok();
	}

	public GwApiResult checkDn(GwDnDTO gwDnDTO) {
		if (!GWConstant.CLIENT_CODE.equals(gwDnDTO.getClient())) {
			log.info("gw add DN用户名出错");
			return GwApiResult.failed().setStatusMsg("用户名错误");
		}

		try {
			gwDnDTO.setPlanDeliveryTime(DateDealUtil.parseDateStr(gwDnDTO.getPlanDeliveryTime()));
			gwDnDTO.setPlanShipTime(DateDealUtil.parseDateStr(gwDnDTO.getPlanShipTime()));
		}
		catch (Exception e) {
			log.error("校验 DN 时间出错:{}", e);
			return GwApiResult.failed().setStatusMsg("时间格式错误");
		}
		return GwApiResult.ok();
	}

}
