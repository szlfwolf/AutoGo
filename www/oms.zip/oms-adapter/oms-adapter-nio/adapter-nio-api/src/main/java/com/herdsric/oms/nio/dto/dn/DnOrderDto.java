package com.herdsric.oms.nio.dto.dn;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.RandomUtil;
import cn.hutool.core.util.StrUtil;
import com.herdsric.oms.common.client.dn.domain.DnOrderCancelDm;
import com.herdsric.oms.common.client.dn.domain.DnOrderDm;
import com.herdsric.oms.common.core.exception.ErrorCodeEnum;
import com.herdsric.oms.common.core.exception.OmsBusinessException;
import com.herdsric.oms.nio.common.NioApiResult;
import com.herdsric.oms.nio.common.NioConstant;
import com.herdsric.oms.nio.enums.*;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * @author zcl
 */
@Data
@Slf4j
public class DnOrderDto {

	private String schema;

	@NotNull
	private NioDnOrderDto param;

	@Data
	public static class NioDnOrderDto {

		/**
		 * 蔚来合单号
		 */
		@NotNull(message = "nioOrderNo can not be null or empty")
		private String nioOrderNo;

		/**
		 * 订单类型 1 常规订单 2 紧急订单 4 VOR订单<br/>
		 * 客户提供的文档描述：对于配件订单有值。订单类型；1、常规订单SKT 2、紧急订单RO 3、直送订单 4、VOR订单
		 * 5、受控订单，6、门店转移订单，7、领料订单
		 */
		private String orderType;

		/**
		 * 处理类型，1-新建，2-取消（如果类型为2，LOPA会发送需要取消的物料行）
		 */
		@NotNull(message = "disposeType can not be null or empty")
		private String disposeType;

		/**
		 * 关联订单号；
		 */
		private String associatedOrderNo;

		/**
		 * OFS 或 MERCURY
		 */
		@NotNull(message = "salePlatformSource can not be null or empty")
		private String salePlatformSource;

		/**
		 * 第三方平台代码
		 */
		@NotNull(message = "isvSource can not be null or empty")
		private String isvSource;

		/**
		 * 仓库编号
		 */
		@NotNull(message = "warehouseNo can not be null or empty")
		private String warehouseNo;

		/**
		 * 目的仓库代码，这个值为空为C端订单，不为空为B端订单。
		 */
		private String destWarehouseNo;

		/**
		 * 自提标识，“1”代表自提(发给freja的delivery给 2 ：代表Self delivery )
		 */
		private String consigneePickup;

		/**
		 * 收货人姓名
		 */
		@NotNull(message = "consigneeName can not be null or empty")
		private String consigneeName;

		/**
		 * 收货公司
		 */
		@NotNull(message = "receiveCompany can not be null or empty")
		private String receiveCompany;

		/**
		 * 收货人手机
		 */
		@NotNull(message = "consigneeMobile can not be null or empty")
		private String consigneeMobile;

		/**
		 * 收货人电话（收货人电话、手机至少有一个不为空）
		 */
		private String consigneePhone;

		/**
		 * 收货人电话邮箱
		 */
		private String consigneeEmail;

		/**
		 * 期望发货时间,格式为：YYYYMMDD24HIMMSS
		 */
		private long expectDate;

		/**
		 * 收货人国家，自提非必填
		 */
		private String addressProvince;

		/**
		 * 收货人城市，自提非必填
		 */
		private String addressCity;

		/**
		 * 收货人国家
		 */
		private String addressCountry;

		/**
		 * 收货人地址 ，自提非必填
		 */
		private String consigneeAddress;

		/**
		 * 收货人邮编
		 */
		private String consigneePostcode;

		/**
		 * 承运商编号
		 */
		private String shipperCode;

		/**
		 * 承运商运单号
		 */
		private String shipperNo;

		/**
		 * 快递产品
		 */
		private String businessType;

		/**
		 * 目的地代码
		 */
		private String destinationCode;

		/**
		 * 目的地名称
		 */
		private String destinationName;

		/**
		 * 发件网点代码
		 */
		private String sendWebsiteCode;

		/**
		 * 发件网点名称
		 */
		private String sendWebsiteName;

		/**
		 * 寄件方式
		 */
		private String sendMode;

		/**
		 * 收件方式
		 */
		private String receiveMode;

		/**
		 * 预约配送起始时间 ,格式为：YYYYMMdd24HIMMSS
		 */
		private long appointDeliveryStartTime;

		/**
		 * 预约配送结束时间 ,格式为：YYYYMMdd24HIMMSS
		 */
		private long appointDeliveryEndTime;

		/**
		 * 是否保价 1 保价
		 */
		private String insuredPrice;

		/**
		 * 保价声明价值
		 */
		private BigDecimal insuredValue;

		/**
		 * 运费支付方式
		 */
		private BigDecimal thirdPayment;

		/**
		 * 月结账号
		 */
		private String monthlyAccount;

		/**
		 * 寄托物
		 */
		private String shipment;

		/**
		 * 面单模板备注
		 */
		private String sellerRemark;

		/**
		 * 合单对应的订单列表
		 */
		@NotNull(message = "orderList can not be null or empty")
		private List<NioOrder> orderList;

	}

	@Data
	@Valid
	public static class NioOrder {

		/**
		 * 蔚来出库指令号，对自营物料发送蔚来物流平台物流单号
		 */
		private String logisticsNo;

		/**
		 * 蔚来原始订单号
		 */
		private String nioOrderNo;

		/**
		 * 蔚来DN单号
		 */
		private String nioSubOrderNo;

		/**
		 * 销售下单时间，格式为：YYYYMMdd24HIMMSS
		 */
		private long orderCreateTime;

		/**
		 * 订单优先级
		 */
		private String priorityLevel;

		/**
		 * 客户留言
		 */
		private String consigneeRemark;

		/**
		 * 销售出库NIO物料编号列表
		 */
		@NotNull(message = "orderDetailList can not be null or empty")
		@Valid
		private List<DnOrderDetailDto> orderDetailList;

	}

	public void check() {
		if (!StrUtil.equals(NioConstant.DN_SCHEMA, this.schema)) {
			throw new OmsBusinessException(NioResultCode.OTHER_ERROR.getValue(),
					StrUtil.format("The schema field must be:{}", NioConstant.DN_SCHEMA));
		}

		NioDnOrderDto nioDnOrderDto = this.param;
		String disposeType = nioDnOrderDto.getDisposeType();
		if (!StrUtil.equalsAny(disposeType, NioConstant.DISPOSE_TYPE_1, NioConstant.DISPOSE_TYPE_2)) {
			throw new OmsBusinessException(ErrorCodeEnum.E600314.code, "The disposeType field must be 1 or 2");
		}

		if (!StrUtil.isAllNotBlank(nioDnOrderDto.getConsigneeName(), nioDnOrderDto.getConsigneePhone(),
				nioDnOrderDto.getAddressCountry(), nioDnOrderDto.getAddressCity(), nioDnOrderDto.getConsigneeAddress(),
				nioDnOrderDto.getConsigneePostcode())) {
			log.warn("DN收货信息不完整");
			throw new OmsBusinessException(NioResultCode.CONSIGNEE_ADDRESS_ERROR.getValue(), "DN收货信息不完整");
		}

		// 数据格式
		if (!StrUtil.equalsAny(nioDnOrderDto.getDisposeType(), NioConstant.DISPOSE_TYPE_1,
				NioConstant.DISPOSE_TYPE_2)) {
			log.warn("处理类型不存在, 传入的处理类型：[{}]", nioDnOrderDto.getDisposeType());
			throw new OmsBusinessException(NioResultCode.OTHER_ERROR.getValue(),
					StrUtil.format("处理类型不存在, 传入的处理类型：{}", nioDnOrderDto.getDisposeType()));
		}

		try {
			Long.valueOf(nioDnOrderDto.getExpectDate());
		}
		catch (Exception e) {
			throw new OmsBusinessException(NioResultCode.TIME_FORMAT_ERROR.getValue(), e.getMessage());
		}
		// 校验DN明细
		List<NioOrder> nioOrders = nioDnOrderDto.getOrderList();
		if (CollectionUtil.isEmpty(nioOrders)) {
			log.warn("DN明细为空");
			throw new OmsBusinessException(NioResultCode.SKU_CODE_ERROR.getValue(), "DN明细为空");
		}
		for (NioOrder nioOrder : nioOrders) {
			if (CollectionUtil.isEmpty(nioOrder.getOrderDetailList())) {
				log.warn("DN明细为空");
				throw new OmsBusinessException(NioResultCode.SKU_CODE_ERROR.getValue(),
						NioResultCode.SKU_CODE_ERROR.getMsg());
			}
			for (DnOrderDetailDto nioOrderDetail : nioOrder.getOrderDetailList()) {
				if (StrUtil.isBlank(nioOrderDetail.getNioMaterialNo()) || null == nioOrderDetail.getQuantity()
						|| 0 == nioOrderDetail.getQuantity().intValue()) {
					log.info("DN detail缺少必填项，详情：{}", nioOrderDetail);
					throw new OmsBusinessException(NioResultCode.OTHER_ERROR.getValue(), "DN detail缺少必填项，详情");
				}
			}
		}
		boolean invalidQty = this.param.orderList.stream().flatMap(order -> order.getOrderDetailList().stream())
				.anyMatch(detail -> !isQtyValid(detail.getQuantity()));
		if (invalidQty) {
			throw new OmsBusinessException(NioResultCode.OTHER_ERROR.getValue(), StrUtil
					.format("AsnOrder part quantity is less than or equal to zero，or quantity format is wrong!"));
		}
	}

	public static DnOrderDm convertCreate(DnOrderDto dnOrderDto) {
		NioDnOrderDto nioDnOrderDto = dnOrderDto.getParam();
		DnOrderDm dnOrderDm = new DnOrderDm();
		dnOrderDm.setSequenceNo(RandomUtil.randomNumbers(10));
		dnOrderDm.setOrderNo(nioDnOrderDto.getNioOrderNo());
		// 默认都是普通级别
		String orderType = nioDnOrderDto.getOrderType();
		if (StrUtil.isBlank(orderType)) {
			log.info("订单类型为空，默认为Regular");
			orderType = "Regular";
		}
		else {
			log.info("订单类型为：" + orderType);
			switch (orderType) {
				case "1":
					log.info("订单为常规订单");
					orderType = "Regular";
					break;
				case "2":
					log.info("订单为紧急订单");
					orderType = "Urgent";
					break;
				case "4":
					log.info("订单为VOR订单");
					orderType = "VOR";
					break;
				// FixMe 虚拟单后续需要和业务确认定义类型
				// case "8":
				// log.info("订单为Claim订单");
				// orderType = "Claim";
				// break;
				default:
					log.info("未匹配到对应的订单类型，默认为常规订单");
					orderType = "Regular";
					break;
			}
		}
		// NIO自提标识，“1”代表自提
		/**
		 * 0：to b; 1：to c ; 2:Self Pick Up，发给freja需要 fixMe<br>
		 * OMS 状态配送类型<br>
		 * 0: to b<br>
		 * 1: to c<br>
		 * 2: Self Pick Up<br>
		 * "": 空值无含义<br>
		 */
		dnOrderDm.setDeliveryType(StrUtil.equals(nioDnOrderDto.getConsigneePickup(), "1") ? "2" :
		// OFS：to b
				(StrUtil.equals(nioDnOrderDto.getSalePlatformSource(), "OFS") ? "0" :
				// MERCURY：to c
						(StrUtil.equals(nioDnOrderDto.getSalePlatformSource(), "MERCURY") ? "1" : "")));

		dnOrderDm.setOrderType(
				NioConsigneePickupTypeEnum.getOrderTypeByConsigneePickupType(dnOrderDm.getDeliveryType(), orderType));
		dnOrderDm.setVirtualWarehouseCode(nioDnOrderDto.getWarehouseNo());
		if (VmWarehouseEnum.isNl(nioDnOrderDto.getWarehouseNo())) {
			dnOrderDm.setWarehouseCode(WarehouseCodeEnum.Holland.code);
		}
		else if (VmWarehouseEnum.isNo(nioDnOrderDto.getWarehouseNo())) {
			dnOrderDm.setWarehouseCode(WarehouseCodeEnum.Norway.code);
		}
		dnOrderDm.setContactName(nioDnOrderDto.getConsigneeName());
		dnOrderDm.setContactCompany(nioDnOrderDto.getReceiveCompany());
		dnOrderDm.setContactPhone(StrUtil.isBlank(nioDnOrderDto.getConsigneeMobile())
				? nioDnOrderDto.getConsigneePhone() : nioDnOrderDto.getConsigneeMobile());
		dnOrderDm.setContactEmail(nioDnOrderDto.getConsigneeEmail());
		dnOrderDm.setExpectedShipDate(dateTimeFormat(nioDnOrderDto.getExpectDate()));
		dnOrderDm.setCountryCode(nioDnOrderDto.getAddressCountry());
		dnOrderDm.setCityCode(nioDnOrderDto.getAddressCity());
		dnOrderDm.setAddress(nioDnOrderDto.getConsigneeAddress());
		dnOrderDm.setZipCode(nioDnOrderDto.getConsigneePostcode());
		dnOrderDm.setRemark(nioDnOrderDto.getSellerRemark());

		List<DnOrderDm.OrderLine> orderLines = new ArrayList<>();
		int position = 1;
		for (NioOrder nioOrder : nioDnOrderDto.getOrderList()) {
			for (DnOrderDetailDto dnOrderDetailDto : nioOrder.getOrderDetailList()) {
				DnOrderDm.OrderLine orderLine = new DnOrderDm.OrderLine();
				orderLine.setBatchNo(dnOrderDetailDto.getBatchNo());
				orderLine.setLineNo(String.format("%06d", position));
				orderLine.setPartNumber(dnOrderDetailDto.getNioMaterialNo());
				orderLine.setQty(dnOrderDetailDto.getQuantity().doubleValue());
				orderLine.setUnit(StrUtil.isBlank(dnOrderDetailDto.getUnit()) ? NioConstant.UNIT_PCS
						: dnOrderDetailDto.getUnit());
				orderLine.setRemark(dnOrderDetailDto.getSellerRemark());
				Map<String, Object> lineMap = new HashMap<>();
				lineMap.put("isvMaterialNo", dnOrderDetailDto.getIsvMaterialNo());
				lineMap.put("materialName", dnOrderDetailDto.getMaterialName());
				orderLine.setExtendProps(lineMap);
				orderLines.add(orderLine);
				position++;
			}
		}
		dnOrderDm.setOrderLines(orderLines);
		return dnOrderDm;
	}

	public static DnOrderCancelDm convertCancel(DnOrderDto dnOrderDto) {
		// 不支持取消DN
		return null;

	}

	private static String dateTimeFormat(long timestamp) {
		// 将时间戳转换为LocalDateTime对象
		LocalDateTime dateTime = LocalDateTime.ofInstant(Instant.ofEpochMilli(timestamp), ZoneId.systemDefault());
		// 定义日期时间格式
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		// 将LocalDateTime对象格式化为字符串时间
		return dateTime.format(formatter);
	}

	private static boolean isQtyValid(BigDecimal qtyValue) {
		try {
			// 检查 qty 是否大于 0
			if (qtyValue.compareTo(BigDecimal.ZERO) > 0) {
				// 检查 qty 是否是整数或具有 ".0" 的小数位
				return qtyValue.stripTrailingZeros().scale() <= 0;
			}
		}
		catch (Exception e) {
			return false;
		}
		return false;
	}

}
