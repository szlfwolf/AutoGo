package com.herdsric.oms.nio.vo.dn;

import lombok.Data;

import java.math.BigDecimal;

/**
 * @author zcl
 */
@Data
public class NioRequestDnPackageItem {

	/**
	 * NIO物料编号
	 */
	private String nioMaterialNo;

	/**
	 * 第三方物料编号
	 */
	private String isvMaterialNo;

	/**
	 * 物料名称
	 */
	private String materialName;

	/**
	 * 批次号
	 */
	private String batchNo;

	/**
	 * 生产日期
	 */
	private String produceDate;

	/**
	 * 有效期
	 */
	private String validity;

	/**
	 * NIO物料编号
	 */
	private BigDecimal quantity;

}
