package com.herdsric.oms.nio.vo.dn;

import lombok.Data;

import java.util.List;

/**
 * @author zcl
 */
@Data
public class NioRequestDnPackage {

	/**
	 * 包裹子单号。UC销售订单传unconfirmed
	 */
	private String packageNo;

	/**
	 * 出库包裹重量，单位：克
	 */
	private String packageWeight;

	/**
	 * 出库包裹状态，1为已打包，2为已出库
	 */
	private String packageStatus;

	/**
	 * 包裹中NIO物料编码列表
	 */
	private List<NioRequestDnPackageItem> materialList;

	/**
	 * 操作时间，格式为YYYYMMDD24HIMMSS
	 */
	private long operateTime;

	/**
	 * 操作人
	 */
	private String operateUser;

}
