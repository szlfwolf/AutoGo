package com.herdsric.oms.nio.dto.sku;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.convert.Convert;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.herdsric.oms.common.client.masterdata.domain.SkuDm;
import com.herdsric.oms.common.core.exception.OmsBusinessException;
import com.herdsric.oms.nio.common.NioConstant;
import com.herdsric.oms.nio.enums.NioResultCode;
import com.herdsric.oms.nio.enums.VmWarehouseEnum;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author zcl
 */
@Data
@Slf4j
public class SkuDto {

	@NotBlank(message = "schema can not be null or empty")
	private String schema;

	@Valid
	@NotNull(message = "param can not be null or empty")
	private List<NioMaterial> param;

	public static List<SkuDm> convert(SkuDto skuDto) {
		List<NioMaterial> nioMaterials = skuDto.getParam();
		List<SkuDm> skuDmList = new ArrayList<>();
		nioMaterials.forEach(x -> {
			SkuDm skuDm = new SkuDm();
			skuDm.setPartNumber(x.getNioMaterialNo());
			skuDm.setNameEn(x.getMaterialName());
			skuDm.setNameCn(x.getMaterialName());
			skuDm.setPartDesc(x.getMaterialName());
			if (NioConstant.VM_WAREHOUSE_CODE_KIND_1.equals(x.getMaterialKind())) {
				skuDm.setVmWarehouseCode(
						String.join(StrUtil.COMMA, VmWarehouseEnum.NORDC04.code, VmWarehouseEnum.NLRDC04.code));
			}
			else if (NioConstant.VM_WAREHOUSE_CODE_KIND_2.equals(x.getMaterialKind())) {
				skuDm.setVmWarehouseCode(
						String.join(StrUtil.COMMA, VmWarehouseEnum.NORDC01.code, VmWarehouseEnum.NLRDC01.code));
			}
			else if (NioConstant.VM_WAREHOUSE_CODE_KIND_3.equals(x.getMaterialKind())) {
				skuDm.setVmWarehouseCode(
						String.join(StrUtil.COMMA, VmWarehouseEnum.NORDC02.code, VmWarehouseEnum.NLRDC02.code));
			}
			else if (NioConstant.VM_WAREHOUSE_CODE_KIND_4.equals(x.getMaterialKind())) {
				skuDm.setVmWarehouseCode(
						String.join(StrUtil.COMMA, VmWarehouseEnum.NORDC03.code, VmWarehouseEnum.NLRDC03.code));
			}
			// 增加最小包装数量
			if (CollectionUtil.isNotEmpty(x.getPackageDetails())) {
				NioPackageDetail nioPackageDetail = x.getPackageDetails().get(0);// 取第一组数据
				List<SkuDm.PackageUnit> packageUnits = new ArrayList<>();
				SkuDm.PackageUnit packageUnit = new SkuDm.PackageUnit();
				if (StrUtil.isNotBlank(x.getMiniPackageQty())) {
					packageUnit.setMoq(x.getMiniPackageQty());
				}
				else {
					// 默认给1
					packageUnit.setMoq(NioConstant.MOQ_1);
				}
				// 包装单位设置 大于1就是PCE
				if (Convert.toInt(packageUnit.getMoq()) > 1) {
					packageUnit.setUnit(NioConstant.UNIT_PCE);
				}
				else {
					packageUnit.setUnit(NioConstant.UNIT_PCS);
				}
				if (ObjectUtil.isNotNull(x.getGrossWeight())) {
					packageUnit.setGrossWeight(x.getGrossWeight().divide(new BigDecimal(1000), 4, RoundingMode.HALF_UP)
							.stripTrailingZeros().toPlainString());
				}
				else {
					packageUnit.setGrossWeight("0");
				}
				if (ObjectUtil.isNotNull(nioPackageDetail)) {
					packageUnit.setLength(ObjectUtil.isNotNull(nioPackageDetail.getInnerLength())
							? String.valueOf(nioPackageDetail.getInnerLength()) : "0");
					packageUnit.setHeight(ObjectUtil.isNotNull(nioPackageDetail.getInnerHeight())
							? String.valueOf(nioPackageDetail.getInnerHeight()) : "0");
					packageUnit.setWidth(ObjectUtil.isNotNull(nioPackageDetail.getInnerWidth())
							? String.valueOf(nioPackageDetail.getInnerWidth()) : "0");
				}
				packageUnit.setType(NioConstant.PACKAGE_TYPE_1);
				packageUnits.add(packageUnit);
				skuDm.setPackageList(packageUnits);
			}
			skuDmList.add(skuDm);
		});
		return skuDmList;
	}

	public void check() {
		if (!StrUtil.equals(NioConstant.SKU_SCHEMA, this.schema)) {
			throw new OmsBusinessException(NioResultCode.OTHER_ERROR.getValue(),
					StrUtil.format("The schema field must be:{}", NioConstant.SKU_SCHEMA));
		}
		for (NioMaterial nioMaterial : param) {
			// 校验
			if (StrUtil.isEmpty(nioMaterial.getNioMaterialNo()) || StrUtil.isEmpty(nioMaterial.getMaterialName())
					|| nioMaterial.getUpdateTime() == null) {
				throw new OmsBusinessException(NioResultCode.OTHER_ERROR.getValue(),
						"Required fields such as material code, material name, operation time, etc. have null values！");
			}
			if (StrUtil.isEmpty(nioMaterial.getMaterialKind())
					|| !Arrays.asList("1", "2", "3", "4").contains(nioMaterial.getMaterialKind())) {
				throw new OmsBusinessException(NioResultCode.OTHER_ERROR.getValue(),
						"Material type is empty or incorrect!");
			}
		}
	}

}
