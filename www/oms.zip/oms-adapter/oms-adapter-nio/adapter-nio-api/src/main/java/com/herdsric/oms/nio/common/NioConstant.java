package com.herdsric.oms.nio.common;

public interface NioConstant {

	String CLIENT_CODE = "NIO";

	String ASN_SCHEMA = "po.addASN";

	String ASN_UPDATE_SCHEMA = "po.updatePO";

	String ASN_UPDATE_SUPPLIER_NO = "NIO";

	String ASN_SPECIAL_UPDATE_SCHEMA = "stock.specialStockIn";

	String DN_SCHEMA = "order.addOrder";

	String SKU_SCHEMA = "master.transportMaterialInfo";

	String STOCK_SCHEMA = "stock.queryStock";

	String CANCEL_ORDER_SCHEMA = "order.cancelOrder";

	String DN_UPDATE_SCHEMA = "order.updateOrder";

	String DN_SPECIAL_UPDATE_SCHEMA = "stock.specialStockOut";

	String ASN_SOURCE_TYPE = "API";

	String ASN_TYPE = "NORMAL";

	String DN_SOURCE_TYPE = "API";

	String DISPOSE_TYPE_1 = "1";

	String DISPOSE_TYPE_2 = "2";

	String CONSIGNEE_PICKUP = "1";

	/**
	 * 0 ： normal transportation to company // to b
	 */
	String FREJA_DELIVERY_TO_B = "0";

	/**
	 * 1：parcel to private client (nearest post office) // to c
	 */
	String FREJA_DELIVERY_TO_C = "1";

	/**
	 * 2：self pick up
	 */
	String FREJA_DELIVERY_OF_SELF_PICK_UP = "2";

	String VM_WAREHOUSE_CODE_KIND_1 = "1";

	String VM_WAREHOUSE_CODE_KIND_2 = "2";

	String VM_WAREHOUSE_CODE_KIND_3 = "3";

	String VM_WAREHOUSE_CODE_KIND_4 = "4";

	String MOQ_1 = "1";

	String UNIT_PCS = "PCS";

	String UNIT_PCE = "PCE";

	String ISV_SOURCE = "luxmate";

	String SHIPPER_NAME = "LUX-MATE";

	String SHIPPER_CODE = "LUX-MATE";

	String TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";

	String OPERATE_USER = "LUX-MATE";

	String OUT_LEVEL = "usable";

	String IN_LEVEL = "usable";

	String PICKING = "Picking";

	String PACKING = "Packing";

	String PACKED = "Packed";

	String BOOKED = "Booked";

	String OUTBOUNDED = "Outbounded";

	String RECEIVED = "Received";

	String PACKAGE_TYPE_1 = "1";

	String DN_SPECIAL_TYPE = "QTCK";

}
