package com.herdsric.oms.nio.vo.asn;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.RandomUtil;
import cn.hutool.core.util.StrUtil;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.herdsric.oms.common.client.asn.domain.AsnOrderDm;
import com.herdsric.oms.common.client.asn.domain.AsnOrderResponseDm;
import com.herdsric.oms.common.client.asn.domain.AsnOrderResponseLineDm;
import com.herdsric.oms.nio.common.NioConstant;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author zcl
 */
@Data
@JsonPropertyOrder({ "schema", "param" })
public class NioSpecialAsnResponseVo {

	private String schema;

	private NioSpecialRequestAsn param;

	public static NioSpecialAsnResponseVo convert(String clientCode, String type, AsnOrderResponseDm asnOrderResponseDm,
			AsnOrderDm asnOrderDm) {
		NioSpecialAsnResponseVo nioSpecialAsnResponseVo = new NioSpecialAsnResponseVo();
		nioSpecialAsnResponseVo.setSchema(NioConstant.ASN_SPECIAL_UPDATE_SCHEMA);
		NioSpecialRequestAsn nioSpecialRequestAsn = new NioSpecialRequestAsn();
		nioSpecialRequestAsn.setIsvSource(NioConstant.ISV_SOURCE);
		nioSpecialRequestAsn.setWarehouseNo(asnOrderDm.getVmWarehouseCode());
		nioSpecialRequestAsn.setNioInNo(asnOrderResponseDm.getOrderNo() + StrUtil.DASHED + RandomUtil.randomString(4));
		nioSpecialRequestAsn.setStockInType(asnOrderResponseDm.getOrderType());
		// nioSpecialRequestAsn.setReasonDesc();

		if (CollectionUtil.isEmpty(asnOrderResponseDm.getOrderLines())) {
			return nioSpecialAsnResponseVo;
		}

		ArrayList<NioSpecialRequestAsnOrderDetail> nioSpecialRequestAsnOrderDetails = new ArrayList<>();
		for (AsnOrderResponseLineDm orderLine : asnOrderResponseDm.getOrderLines()) {
			NioSpecialRequestAsnOrderDetail nioSpecialRequestAsnOrderDetail = new NioSpecialRequestAsnOrderDetail();
			nioSpecialRequestAsnOrderDetail.setNioMaterialNo(orderLine.getPartNumber());
			// nioSpecialRequestAsnOrderDetail.setIsvMaterialNo();
			// nioSpecialRequestAsnOrderDetail.setMaterialName();
			nioSpecialRequestAsnOrderDetail.setQuantity(new BigDecimal(orderLine.getQty()));
			nioSpecialRequestAsnOrderDetail.setInLevel(NioConstant.IN_LEVEL);
			// nioSpecialRequestAsnOrderDetail.setMaterialItem();
			// nioSpecialRequestAsnOrderDetail.setShipperCode();
			// nioSpecialRequestAsnOrderDetail.setShipperName();
			// nioSpecialRequestAsnOrderDetail.setShipperNo();
			nioSpecialRequestAsnOrderDetail.setOperateTime(convertTime(asnOrderResponseDm.getOperateTime()));
			nioSpecialRequestAsnOrderDetail.setOperateUser(NioConstant.OPERATE_USER);
			// nioSpecialRequestAsnOrderDetail.setBatchDetailList();
			nioSpecialRequestAsnOrderDetails.add(nioSpecialRequestAsnOrderDetail);
		}

		// 将SKU相同的进行合并 数量累加
		// 先按SKU分组
		Map<String, List<NioSpecialRequestAsnOrderDetail>> nioOrderDetailListGroupBySku = nioSpecialRequestAsnOrderDetails
				.stream().collect(Collectors.groupingBy(NioSpecialRequestAsnOrderDetail::getNioMaterialNo));
		// 合并后的SKU
		List<NioSpecialRequestAsnOrderDetail> nioOrderDetailListOfMerge = new ArrayList<>();
		// 再将数量累加
		nioOrderDetailListGroupBySku.forEach((sku, detailList) -> {
			BigDecimal totalQuantity = detailList.stream().map(NioSpecialRequestAsnOrderDetail::getQuantity)
					.reduce(BigDecimal.ZERO, BigDecimal::add);
			// 重新设置SKU数量
			NioSpecialRequestAsnOrderDetail nioSpecialRequestAsnOrderDetail = detailList.get(0);
			nioSpecialRequestAsnOrderDetail.setQuantity(totalQuantity);
			nioOrderDetailListOfMerge.add(nioSpecialRequestAsnOrderDetail);
		});

		nioSpecialRequestAsn.setOrderDetailList(nioOrderDetailListOfMerge);
		nioSpecialAsnResponseVo.setParam(nioSpecialRequestAsn);
		return nioSpecialAsnResponseVo;
	}

	private static long convertTime(String time) {
		// 定义日期时间格式
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(NioConstant.TIME_FORMAT);
		// 解析字符串为 LocalDateTime 对象
		LocalDateTime dateTime = LocalDateTime.parse(time, formatter);
		// 转换为 long 类型时间戳
		return dateTime.toEpochSecond(java.time.ZoneOffset.UTC) * 1000;
	}

	@Data
	@JsonPropertyOrder({ "isvSource", "nioInNo", "orderDetailList", "stockInType", "warehouseNo" })
	public static class NioSpecialRequestAsn {

		/**
		 * 第三方平台代码
		 */
		private String isvSource;

		/**
		 * 仓库编号，自营物料必填，代销物料物流非蔚来运营非必填
		 */
		private String warehouseNo;

		/**
		 * 蔚来入库单据号
		 */
		private String nioInNo;

		/**
		 * 售后特殊入库类型（ ZPRK:赠品入库、 CZTHRK:车展退货入库、 XSTHRK:销售退货入库、 HGRK:回购入库、 KGSDBRK:跨公司调拨入库、
		 * SPRK:索赔入库、 QTRK:其他入库）
		 *
		 * 精品特殊入库类型（ ZBRK:组包入库、 ZJRK:质检入库、 THRK:退货线下入库、 TCRK:特殊采购入库、 JSRK:寄售退货、 HDRK:活动退货、
		 * HHRK:换货入库、 FLRK:辅料入库、 FXRK:返修入库、 DFRK:代发退货、 CBRK:拆包入库、 PYRK:盘盈入库、 QTRK:其他入库）
		 */
		private String stockInType;

		/**
		 * 库存调整原因
		 */
		// private String reasonDesc;

		/**
		 * 蔚来入库单据号
		 */
		private List<NioSpecialRequestAsnOrderDetail> orderDetailList;

	}

	@Data
	@JsonPropertyOrder({ "inLevel", "nioMaterialNo", "operateTime", "operateUser", "quantity" })
	public static class NioSpecialRequestAsnOrderDetail {

		/**
		 * NIO物料编号
		 */
		private String nioMaterialNo;

		/**
		 * 第三方物料编号
		 */
		// private String isvMaterialNo;

		/**
		 * 物料名称
		 */
		// private String materialName;

		/**
		 * 物料数量列表
		 */
		private BigDecimal quantity;

		/**
		 * 入库物料质量：usable:Useable物料/levelA:A类质损物料/levelB:B类质损物料/levelC:C类质损物料
		 */
		private String inLevel;

		/**
		 * 物料品类
		 */
		// private String materialItem;

		/**
		 * 承运商编号
		 */
		// private String shipperCode;

		/**
		 * 承运商名称
		 */
		// private String shipperName;

		/**
		 * 快递单号
		 */
		// private String shipperNo;

		/**
		 * 操作时间，格式为YYYYMMDD24HIMMSS
		 */
		private long operateTime;

		/**
		 * 操作人
		 */
		private String operateUser;

		/**
		 * 出库的批次明细数据
		 */
		// private List<NioSpecialRequestBatchDetail> batchDetailList;

	}

	@Data
	public static class NioSpecialRequestBatchDetail {

		/**
		 * NIO物料编号
		 */
		private String nioMaterialNo;

		/**
		 * 批次号
		 */
		private String batchNo;

		/**
		 * 生产日期
		 */
		private String produceDate;

		/**
		 * 有效期
		 */
		private String validity;

		/**
		 * 实际数量
		 */
		private int realQty;

	}

}
