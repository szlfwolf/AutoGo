package com.herdsric.oms.nio.vo.asn;

import cn.hutool.core.util.RandomUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.herdsric.oms.common.client.asn.domain.AsnOrderDm;
import com.herdsric.oms.common.client.asn.domain.AsnOrderResponseDm;
import com.herdsric.oms.common.client.asn.domain.AsnOrderResponseLineDm;
import com.herdsric.oms.nio.common.NioConstant;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * @author zcl
 */
@Data
@Slf4j
@JsonPropertyOrder({ "schema", "param" })
public class NioAsnResponseVo implements Serializable {

	private String schema;

	private NioRequestAsn param;

	public static NioAsnResponseVo convert(String clientCode, String type, AsnOrderResponseDm asnOrderResponseDm,
			AsnOrderDm asnOrderDm) {
		NioAsnResponseVo nioAsnResponseVo = new NioAsnResponseVo();
		nioAsnResponseVo.setSchema(NioConstant.ASN_UPDATE_SCHEMA);
		NioRequestAsn nioRequestAsn = new NioRequestAsn();
		nioRequestAsn.setAsnNo(asnOrderResponseDm.getOrderNo());
		nioRequestAsn.setIsvInboundNo(asnOrderResponseDm.getOrderNo() + StrUtil.DASHED + RandomUtil.randomString(4));
		nioRequestAsn.setIsvSource(NioConstant.ISV_SOURCE);
		// 转换成对应的虚拟仓库代码
		// nioRequestAsn.setOperateType();
		nioRequestAsn.setOperateTime(convertTime(asnOrderResponseDm.getOperateTime()));
		nioRequestAsn.setOperateUser(NioConstant.OPERATE_USER);

		List<NioRequestAsnDetail> nioRequestAsnDetails = new ArrayList<>();
		for (AsnOrderResponseLineDm orderLine : asnOrderResponseDm.getOrderLines()) {

			NioRequestAsnDetail nioRequestAsnDetail = new NioRequestAsnDetail();
			String lineNo = orderLine.getLineNo();
			try {
				if (StrUtil.isNotBlank(lineNo)) {
					lineNo = String.valueOf(new BigDecimal(lineNo).toBigInteger().intValue()); // 行号转
																								// int
					// NIO接口过来的是INT类型
				}
			}
			catch (Exception ex) {
				log.error("行号: " + lineNo + " 转INT异常,用原来的行号：" + ex.getMessage(), ex);
			}
			nioRequestAsnDetail.setLevelAQty(0);
			nioRequestAsnDetail.setLevelBQty(0);
			nioRequestAsnDetail.setLevelCQty(0);
			nioRequestAsnDetail.setAsnItemNo(lineNo);
			nioRequestAsnDetail.setNioMaterialNo(orderLine.getPartNumber());
			// nioRequestAsnDetail.setBatchNo(orderLine.getBatchNo());
			int num = orderLine.getQty();
			if (num <= 0) {
				continue;
			}
			nioRequestAsnDetail.setApplyQty(num);
			nioRequestAsnDetail.setRealInstoreQty(num);
			nioRequestAsnDetails.add(nioRequestAsnDetail);
		}
		nioRequestAsn.setReceivedItemList(nioRequestAsnDetails);
		nioRequestAsn.setSupplierNo(NioConstant.ASN_UPDATE_SUPPLIER_NO);
		nioRequestAsn.setWarehouseNo(asnOrderDm.getVmWarehouseCode());
		nioAsnResponseVo.setParam(nioRequestAsn);

		String jsonString = JSON.toJSONString(nioAsnResponseVo);
		return JSON.parseObject(jsonString).toJavaObject(NioAsnResponseVo.class);
	}

	private static long convertTime(String time) {
		// 定义日期时间格式
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(NioConstant.TIME_FORMAT);
		// 解析字符串为 LocalDateTime 对象
		LocalDateTime dateTime = LocalDateTime.parse(time, formatter);
		// 转换为 long 类型时间戳
		return dateTime.toEpochSecond(java.time.ZoneOffset.UTC) * 1000;
	}

	@Data
	@JsonPropertyOrder({ "asnNo", "isvInboundNo", "isvSource", "operateTime", "operateUser", "receivedItemList",
			"supplierNo", "warehouseNo" })
	public static class NioRequestAsn implements Serializable {

		/**
		 * 第三方平台代码
		 */
		private String isvSource;

		/**
		 * 仓库编号，自营物料必填，代销物料物流非蔚来运营非必填
		 */
		private String warehouseNo;

		/**
		 * ASN号码
		 */
		private String asnNo;

		/**
		 * 第三方入库凭证号
		 */
		private String isvInboundNo;

		/**
		 * 供应商编码
		 */
		private String supplierNo;

		/**
		 * 1：签收,2：签收撤回，3 入库上架 操作类型，如果为空则默认入库
		 */
		// private String operateType;

		/**
		 * 操作时间，格式为YYYYMMDD24HIMMSS
		 */
		private long operateTime;

		/**
		 * 操作人
		 */
		private String operateUser;

		/**
		 * 入库清单
		 */
		private List<NioRequestAsnDetail> receivedItemList;

	}

}
