package com.herdsric.oms.nio.dto.asn;

import lombok.Data;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

/**
 * @author zcl
 */
@Data
public class AsnOrderDetailDto {

	/**
	 * ASN行号
	 */
	@NotNull(message = "ASN行号不能为空")
	private String asnItemNo;

	/**
	 * NIO物料编号
	 */
	@NotNull(message = "物料编号不能为空")
	private String nioMaterialNo;

	/**
	 * 第三方物料编号
	 */
	private String isvMaterialNo;

	/**
	 * 批次号
	 */
	private String batchNo;

	/**
	 * ASN申请入库数量
	 */
	@NotNull(message = "入库数量不能为空")
	private BigDecimal asnQty;

	/**
	 * 物料基本单位
	 */
	@NotNull(message = "物料基本单位不能为空")
	private String itemUnit;

	/**
	 * PO号
	 */
	private String poNo;

	/**
	 * PO行号
	 */
	private String poLineNo;

	/**
	 * PO此物料订购数量
	 */
	private BigDecimal poLineQty;

	/**
	 * PO计划交货时间，格式为YYYYMMDD24HIMMSS
	 */
	private long poPlanDeliveryTime;

}
