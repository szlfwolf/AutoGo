package com.herdsric.oms.nio.vo.dn;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.herdsric.oms.common.client.dn.domain.OrderLineDm;
import com.herdsric.oms.common.client.dn.dto.DnOrderResponseDTO;
import com.herdsric.oms.nio.common.NioConstant;
import com.herdsric.oms.nio.enums.ApiTypeEnum;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author zcl
 */
@Data
@Slf4j
@JsonPropertyOrder({ "schema", "param" })
public class NioSpecialDnOrderResponseVo {

	private String schema;

	private NioSpecialRequestDn param;

	public static NioSpecialDnOrderResponseVo convert(String type, DnOrderResponseDTO dnOrderResponseDm) {
		NioSpecialDnOrderResponseVo nioSpecialDnOrderResponseVo = new NioSpecialDnOrderResponseVo();
		nioSpecialDnOrderResponseVo.setSchema(NioConstant.DN_SPECIAL_UPDATE_SCHEMA);
		// Step1: 只有出库状态通知的时候，将特殊DN的出库信息反馈给NIO
		if (!ApiTypeEnum.NIO_SPECIAL_DN_ORDER_RESPONSE_SYNC.name().equals(type)) {
			log.info("特殊DN非出库(Solicitation)状态，不通知NIO");
			return null;
		}
		NioSpecialRequestDn nioSpecialRequestDn = new NioSpecialRequestDn();
		nioSpecialRequestDn.setIsvSource(NioConstant.ISV_SOURCE);
		nioSpecialRequestDn.setWarehouseNo(dnOrderResponseDm.getVirtualWarehouseCode());
		nioSpecialRequestDn.setNioOutNo(dnOrderResponseDm.getOrderNo());
		nioSpecialRequestDn.setStockOutType(NioConstant.DN_SPECIAL_TYPE);
		// if (CollectionUtil.isNotEmpty(dnOrderResponseDm.getOrderLines()) &&
		// !StrUtil.equalsAny(type,
		// SyncEnum.DN_ORDER_STATUS_PICKING_SYNC.name(),
		// SyncEnum.DN_ORDER_STATUS_PACKING_SYNC.name())) {
		// nioSpecialDnOrderResponseVo.setParam(nioSpecialRequestDn);
		// return nioSpecialDnOrderResponseVo;
		// }
		// nioSpecialRequestDn.setReasonDesc();
		List<NioSpecialRequestDnOrderDetail> orderDetailList = new ArrayList<>();
		for (OrderLineDm orderLine : dnOrderResponseDm.getOrderLines()) {
			NioSpecialRequestDnOrderDetail nioSpecialRequestDnOrderDetail = new NioSpecialRequestDnOrderDetail();
			nioSpecialRequestDnOrderDetail.setNioMaterialNo(orderLine.getPartNumber());
			// nioSpecialRequestDnOrderDetail.setIsvMaterialNo();
			// nioSpecialRequestDnOrderDetail.setMaterialName();
			nioSpecialRequestDnOrderDetail.setQuantity(new BigDecimal(orderLine.getQty()).intValue());
			nioSpecialRequestDnOrderDetail.setOutLevel(NioConstant.OUT_LEVEL);
			// nioSpecialRequestDnOrderDetail.setReasonItem();
			// nioSpecialRequestDnOrderDetail.setMaterialItem();
			// nioSpecialRequestDnOrderDetail.setShipperCode();
			// nioSpecialRequestDnOrderDetail.setShipperName();
			// nioSpecialRequestDnOrderDetail.setShipperNo();
			nioSpecialRequestDnOrderDetail.setOperateTime(convertTime(dnOrderResponseDm.getPackageTime()));
			nioSpecialRequestDnOrderDetail.setOperateUser(NioConstant.OPERATE_USER);
			// nioSpecialRequestDnOrderDetail.setBatchDetailList();
			orderDetailList.add(nioSpecialRequestDnOrderDetail);
		}
		// 将SKU相同的进行合并 数量累加
		// 先按SKU分组
		Map<String, List<NioSpecialRequestDnOrderDetail>> nioOrderDetailListGroupBySku = orderDetailList.stream()
				.collect(Collectors.groupingBy(NioSpecialRequestDnOrderDetail::getNioMaterialNo));
		// 合并后的SKU
		List<NioSpecialRequestDnOrderDetail> nioDnDetailListOfMerge = new ArrayList<>();
		// 再将数量累加
		nioOrderDetailListGroupBySku.forEach((sku, detailList) -> {
			int totalQuantity = detailList.stream().mapToInt(NioSpecialRequestDnOrderDetail::getQuantity).sum();
			// 重新设置SKU数量
			NioSpecialRequestDnOrderDetail nioSpecialRequestAsnOrderDetail = detailList.get(0);
			nioSpecialRequestAsnOrderDetail.setQuantity(totalQuantity);
			nioDnDetailListOfMerge.add(nioSpecialRequestAsnOrderDetail);
		});

		nioSpecialRequestDn.setOrderDetailList(nioDnDetailListOfMerge);
		nioSpecialDnOrderResponseVo.setParam(nioSpecialRequestDn);
		return nioSpecialDnOrderResponseVo;
	}

	private static long convertTime(String time) {
		// 定义日期时间格式
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(NioConstant.TIME_FORMAT);
		// 解析字符串为 LocalDateTime 对象
		LocalDateTime dateTime = LocalDateTime.parse(time, formatter);
		// 转换为 long 类型时间戳
		return dateTime.toEpochSecond(java.time.ZoneOffset.UTC) * 1000;
	}

	@Data
	@JsonPropertyOrder({ "isvSource", "nioOutNo", "orderDetailList", "stockOutType", "warehouseNo" })
	public static class NioSpecialRequestDn {

		/**
		 * 第三方平台代码
		 */
		private String isvSource;

		/**
		 * 仓库编号，自营物料必填，代销物料物流非蔚来运营非必填
		 */
		private String warehouseNo;

		/**
		 * 蔚来入库单据号
		 */
		private String nioOutNo;

		/**
		 * 售后特殊出库类型（ CGTHCK:采购退货出库、 WWZJCK:委外子件出库、 KGSDBCK:跨公司调拨出库、 SPCK:索赔出库、 BFCK:报废出库、
		 * QTCK:其他出库）
		 *
		 * 精品特殊出库类型（ ZBCK:组包出库、 ZJCK:质检出库、 XHCK:销毁出库、 WWCK:委外出库、 TGCK:退供出库、 JSCK:寄售出库、
		 * HDCK:活动出库、 HHCK:换货出库、 PKCK盘亏出库、 FLCK:辅料出库、 FXCK:返修出库、 DFCK:代发出库、 CKCH:出口出库、
		 * CBCK:拆包出库、 BFCK:补发出库、 DCCK:DC线下出库、 QTCK:其他出库）
		 */
		private String stockOutType;

		/**
		 * 库存调整原因
		 */
		// private String reasonDesc;

		/**
		 * 蔚来入库单据号
		 */
		private List<NioSpecialRequestDnOrderDetail> orderDetailList;

	}

	@Data
	@JsonPropertyOrder({ "nioMaterialNo", "operateTime", "operateUser", "outLevel", "quantity" })
	public static class NioSpecialRequestDnOrderDetail {

		/**
		 * NIO物料编号
		 */
		private String nioMaterialNo;

		/**
		 * 第三方物料编号
		 */
		// private String isvMaterialNo;

		/**
		 * 物料名称
		 */
		// private String materialName;

		/**
		 * 物料数量列表
		 */
		private int quantity;

		/**
		 * 出库物料质量：usable:Useable物料/levelA:A类质损物料/levelB:B类质损物料/levelC:C类质损物料
		 */
		private String outLevel;

		/**
		 * 明细调整原因；对于retail 为盘盈原因：1：自然损耗；2：非自然损耗
		 */
		// private String reasonItem;

		/**
		 * 物料品类:1: 精品2：车商城
		 */
		// private String materialItem;

		/**
		 * 承运商编号
		 */
		// private String shipperCode;

		/**
		 * 承运商名称
		 */
		// private String shipperName;

		/**
		 * 快递单号
		 */
		// private String shipperNo;

		/**
		 * 操作时间，格式为YYYYMMDD24HIMMSS
		 */
		private long operateTime;

		/**
		 * 操作人
		 */
		private String operateUser;

		/**
		 * 出库的批次明细数据
		 */
		// private List<NioSpecialRequestBatchDetail> batchDetailList;

	}

	@Data
	public static class NioSpecialRequestBatchDetail {

		/**
		 * NIO物料编号
		 */
		private String nioMaterialNo;

		/**
		 * 批次号
		 */
		private String batchNo;

		/**
		 * 生产日期
		 */
		private String produceDate;

		/**
		 * 有效期
		 */
		private String validity;

		/**
		 * 实际数量
		 */
		private int realQty;

	}

}
