
package com.herdsric.oms.nio.common;

import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.nio.enums.NioResultCode;
import com.herdsric.oms.nio.vo.stock.StockVo;
import lombok.Data;

/**
 * <p>
 * NIO ASN
 * </p>
 *
 * @author zcl
 */
@Data
public class NioApiResult {

	public NioApiResult() {
	}

	public NioApiResult(R r) {
		if (r.getCode() == 0) {
			this.resultCode = NioResultCode.SUCCESS.getValue();
			this.resultDesc = r.getMsg();
		}
		else {
			this.resultCode = NioResultCode.OTHER_ERROR.getValue();
			this.resultDesc = r.getMsg();
		}
	}

	public NioApiResult(NioResultCode code) {
		this.resultCode = code.getValue();
		this.resultDesc = code.getMsg();
	}

	public NioApiResult(String code, String msg) {
		this.resultCode = code;
		this.resultDesc = msg;
	}

	public NioApiResult(String code, StockVo data) {
		this.resultCode = code;
		this.data = data;
	}

	public NioApiResult(String code, String msg, Object data) {
		this.resultCode = code;
		this.resultDesc = msg;
		this.data = data;
	}

	/**
	 * WL-0000： 成功， 其他：参数异常
	 */
	private String resultCode;

	/**
	 * 反馈结果描述
	 */
	private String resultDesc;

	private Object data;

}
