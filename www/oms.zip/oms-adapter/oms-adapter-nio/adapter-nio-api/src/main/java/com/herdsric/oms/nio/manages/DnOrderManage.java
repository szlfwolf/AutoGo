package com.herdsric.oms.nio.manages;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.herdsric.oms.common.client.dn.DnBizDefine;
import com.herdsric.oms.common.client.dn.domain.DnOrderCancelDm;
import com.herdsric.oms.common.client.dn.domain.DnOrderDm;
import com.herdsric.oms.common.client.dn.dto.DnOrderResponseDTO;
import com.herdsric.oms.common.client.dn.enums.OrderSplitTypeEnum;
import com.herdsric.oms.common.client.dn.function.DnOptionFlag;
import com.herdsric.oms.common.client.dn.handle.DnOrderSplitFunction;
import com.herdsric.oms.common.client.dn.handle.SplitStrategy;
import com.herdsric.oms.common.client.dn.process.DnOrderProcessor;
import com.herdsric.oms.common.client.enums.PfepTypeEnum;
import com.herdsric.oms.common.client.masterdata.domain.SkuDm;
import com.herdsric.oms.common.client.masterdata.process.SkuProcessor;
import com.herdsric.oms.common.core.exception.ErrorCodeEnum;
import com.herdsric.oms.common.core.exception.OmsBusinessException;
import com.herdsric.oms.common.core.util.JsonMapper;
import com.herdsric.oms.common.core.util.SpringContextHolder;
import com.herdsric.oms.common.security.util.SecurityUtils;
import com.herdsric.oms.common.webhook.CallbackHttpDefine;
import com.herdsric.oms.nio.common.NioConstant;
import com.herdsric.oms.nio.enums.ApiTypeEnum;
import com.herdsric.oms.nio.enums.VmWarehouseEnum;
import com.herdsric.oms.nio.vo.dn.NioDnOrderResponseVo;
import com.herdsric.oms.nio.vo.dn.NioSpecialDnOrderResponseVo;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author zcl
 */
@Slf4j
@RequiredArgsConstructor
public class DnOrderManage extends CommonDefine implements DnBizDefine {

	@Override
	public void save(DnOrderDm dnOrderDm) {
		List<String> partNumbers = dnOrderDm.getOrderLines().stream().map(DnOrderDm.OrderLine::getPartNumber)
				.collect(Collectors.toList());
		SkuProcessor skuProcessor = SpringContextHolder.getBean(SkuProcessor.class);
		List<SkuDm> skuDmList = skuProcessor.fetchByClientAndPartNumbers(NioConstant.CLIENT_CODE, partNumbers);
		List<SkuDm> mismatchSku = skuDmList
				.stream().filter(a -> !Arrays.stream(a.getVmWarehouseCode().split(StrUtil.COMMA))
						.collect(Collectors.toList()).contains(dnOrderDm.getVirtualWarehouseCode()))
				.collect(Collectors.toList());
		String mismatchInfo = mismatchSku.stream().map(a -> {
			HashMap<String, String> map = new HashMap<>();
			map.put(a.getPartNumber(), a.getVmWarehouseCode());
			return map;
		}).flatMap(map -> map.entrySet().stream()).map(entry -> entry.getKey() + StrUtil.C_COLON + entry.getValue())
				.collect(Collectors.joining(StrUtil.COMMA));
		if (CollectionUtil.isNotEmpty(mismatchSku)) {
			throw new OmsBusinessException(ErrorCodeEnum.E100002.code,
					StrUtil.format("Mismatch between Order Warehouse Code:{} and Parts Virtual Warehouse Codes: {}",
							dnOrderDm.getVirtualWarehouseCode(), mismatchInfo));
		}

		if (VmWarehouseEnum.isNl(dnOrderDm.getVirtualWarehouseCode())) {
			dnOrderDm.setPfepTypeEnum(PfepTypeEnum.ORDER_MASTER);
			dnOrderDm.setTypeEnum(OrderSplitTypeEnum.OS_02);
		}
		else if (VmWarehouseEnum.isNo(dnOrderDm.getVirtualWarehouseCode())) {
			dnOrderDm.setPfepTypeEnum(PfepTypeEnum.NO_BY_WAREHOUSE_CODE);
			dnOrderDm.setTypeEnum(OrderSplitTypeEnum.OS_00);
		}
		else {
			throw new OmsBusinessException(ErrorCodeEnum.E999999.code,
					StrUtil.format("Virtual Warehouse Code:{} not support", dnOrderDm.getVirtualWarehouseCode()));

		}

		DnOrderSplitFunction dnOrderSplitFunction = SplitStrategy.getStrategyFunction(dnOrderDm.getTypeEnum());
		dnOrderSplitFunction.preHandle(SecurityUtils.getTokenSupportClient(), dnOrderDm);
	}

	//@formatter:off
	@Override
	public void dnOrderResponseByWebhook(String clientCode, String type, String batchNo) {

		CallbackHttpDefine callbackHttpDefine = SpringContextHolder.getBean(CallbackHttpDefine.class);
		DnOrderProcessor dnOrderProcessor = SpringContextHolder.getBean(DnOrderProcessor.class);
		Function<DnOptionFlag, Function<DnOrderResponseDTO, Boolean>> function = (x) -> {

			AtomicBoolean manual = new AtomicBoolean(false);
			switch (x) {
				case Manual:
					return dm -> {
						log.info("{},BatchNo:{},dnOrder:{} 手动上传订单，需要反馈", clientCode, batchNo, dm.getOrderNo());
						manual.set(true);
						return true;
					};
				case Cancelled:
					//wms取消订单反馈客户
					return dm -> {
						log.info("{},BatchNo:{},dnOrder:{} 取消订单，不需要反馈", clientCode, batchNo, dm.getOrderNo());
						return false;
					};
				case Created:
					//Picking BatchNo == OrderNo, 根据 orderNo 查询母单信息
					return dm -> {
						if (manual.get()) {
							log.info("type:{},{},BatchNo:{},dnOrder:{} 手动上传订单，不需要反馈", type, clientCode, batchNo, dm.getOrderNo());
						} else {
							NioDnOrderResponseVo obj = NioDnOrderResponseVo.convert(type, dm);
							callbackHttpDefine.execute( clientCode, dm.getWarehouseCode(), dm.getOrderNo(), obj, type, false);
							log.info("{},dnOrder:{} ，type:{},反馈客户：{}", clientCode, dm.getOrderNo(), type, JsonMapper.INSTANCE.toJson(obj));
						}
						return true;
					};
				case Released:
				case Packed:
				case Booked:
				case Delivery:
					return dm -> {
						if (manual.get()) {
							log.info("type:{},{},BatchNo:{},dnOrder:{} 手动上传订单，不需要反馈", type, clientCode, batchNo, dm.getOrderNo());
						} else {
							NioDnOrderResponseVo obj = NioDnOrderResponseVo.convert(type, dm);
							callbackHttpDefine.execute(clientCode, dm.getWarehouseCode(), dm.getOrderNo(), obj, type, true);
							log.info("{},dnOrder:{} ，type:{},反馈客户：{}", clientCode, dm.getOrderNo(), type, JsonMapper.INSTANCE.toJson(obj));
						}
						return true;
					};
				case PickUp:
					return dm -> {
						if (manual.get()) {
							NioSpecialDnOrderResponseVo nioSpecialDnOrderResponseVo = NioSpecialDnOrderResponseVo.convert(ApiTypeEnum.NIO_SPECIAL_DN_ORDER_RESPONSE_SYNC.name(), dm);
							if (ObjectUtil.isNotNull(nioSpecialDnOrderResponseVo)) {
								callbackHttpDefine.execute(clientCode, dm.getWarehouseCode(), dm.getOrderNo(), nioSpecialDnOrderResponseVo, ApiTypeEnum.NIO_SPECIAL_DN_ORDER_RESPONSE_SYNC.name(), true);
							}
							log.info("人工单：{},{},dnOrder:{} ，type:{},反馈客户：{}", manual.get(), clientCode, dm.getOrderNo(), type, JsonMapper.INSTANCE.toJson(nioSpecialDnOrderResponseVo));

						} else {
							NioDnOrderResponseVo nioDnOrderResponseVo = NioDnOrderResponseVo.convert(type, dm);
							if (ObjectUtil.isNotNull(nioDnOrderResponseVo)) {
								callbackHttpDefine.execute(clientCode, dm.getWarehouseCode(), dm.getOrderNo(), nioDnOrderResponseVo, type, true);
							}
							log.info("客户单：{},{},dnOrder:{} ，type:{},反馈客户：{}", manual.get(), clientCode, dm.getOrderNo(), type, JsonMapper.INSTANCE.toJson(nioDnOrderResponseVo));
						}
						return true;
					};
				default:
					return dm -> {
						// 其他情况不需要反馈
						return true;
					};
			}
		};
		dnOrderProcessor.dnOrderResponse(clientCode, type, batchNo, function);
	}
	//@formatter:on

	@Override
	public void cancelDnOrder(String clientCode, DnOrderCancelDm dnOrderCancelDm) {
		DnOrderProcessor dnOrderProcessor = SpringContextHolder.getBean(DnOrderProcessor.class);
		dnOrderProcessor.dnOrderCancel(clientCode, dnOrderCancelDm);
	}

	@Override
	public void dnOrderCancelByWebhook(String clientCode, String batchNo) {
		// wms取消订单反馈客户,按照合单号取消，也需要判断母单维度反馈的情况，直接走方法
		DnOrderProcessor dnOrderProcessor = SpringContextHolder.getBean(DnOrderProcessor.class);
		Function<DnOptionFlag, Function<DnOrderResponseDTO, Boolean>> function = x -> {
			switch (x) {
				case Manual:
					return dm -> {
						log.info("{},BatchNo:{},dnOrder:{} 手动上传订单，不需要反馈", clientCode, batchNo, dm.getOrderNo());
						return false;
					};
				case Cancelled:
					return dm -> {
						log.info("{},BatchNo:{},dnOrder:{} 取消订单，不需要反馈", clientCode, batchNo, dm.getOrderNo());
						return false;
					};
				default:
					return dm -> {
						// 其他情况不需要反馈
						return true;
					};
			}
		};
		dnOrderProcessor.dnOrderCancelByWebhook(clientCode, batchNo, function);

	}

}
