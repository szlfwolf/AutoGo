package com.herdsric.oms.nio.dto.dn;

import lombok.Data;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

/**
 * @author zcl
 */
@Data
public class DnOrderDetailDto {

	/**
	 * NIO物料编号
	 */
	@NotNull(message = "nioMaterialNo不能为空")
	private String nioMaterialNo;

	/**
	 * 第三方物料编号
	 */
	private String isvMaterialNo;

	/**
	 * 物料名称
	 */
	private String materialName;

	/**
	 * 批次号
	 */
	private String batchNo;

	/**
	 * 商品的出库数量
	 */
	@NotNull(message = "quantity不能为空")
	private BigDecimal quantity;

	/**
	 * 单位
	 */
	@NotNull(message = "unit不能为空")
	private String unit;

	/**
	 * 商品明细备注
	 */
	private String sellerRemark;

}
