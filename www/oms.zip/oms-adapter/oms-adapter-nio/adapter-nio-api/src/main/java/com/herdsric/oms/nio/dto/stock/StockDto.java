package com.herdsric.oms.nio.dto.stock;

import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.herdsric.oms.common.client.stock.dto.StockDTO;
import com.herdsric.oms.common.core.exception.OmsBusinessException;
import com.herdsric.oms.nio.common.NioConstant;
import com.herdsric.oms.nio.enums.NioResultCode;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @author zcl
 */
@Data
public class StockDto {

	@NotBlank(message = "schema can not be null or empty")
	private String schema;

	@Valid
	@NotNull(message = "param can not be null or empty")
	private NioQueryStock param;

	public static StockDTO convert(StockDto stockDto) {
		NioQueryStock nioQueryStock = stockDto.getParam();
		StockDTO stockDTO = new StockDTO();
		stockDTO.setWarehouseCode(nioQueryStock.getWarehouseNo());
		if (ObjectUtil.isNotNull(nioQueryStock.getCurrentPage()) && ObjectUtil.isNotNull(nioQueryStock.getPageSize())) {
			stockDTO.setCurrent(nioQueryStock.getCurrentPage());
			stockDTO.setSize(nioQueryStock.getPageSize());
		}
		stockDTO.setPartNumbers(nioQueryStock.getNioMaterialNo());
		return stockDTO;
	}

	public void check() {
		if (!StrUtil.equals(NioConstant.STOCK_SCHEMA, this.schema)) {
			throw new OmsBusinessException(NioResultCode.OTHER_ERROR.getValue(),
					StrUtil.format("The schema field must be:{}", NioConstant.STOCK_SCHEMA));
		}
	}

}
