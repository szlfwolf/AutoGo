package com.herdsric.oms.nio.dto.dnCancel;

import lombok.Data;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

/**
 * @author zcl
 */
@Data
public class NioCancelOrderMaterial {

	/**
	 * 被取消的NIO物料号
	 */
	@NotBlank(message = "nioMaterialNo 字段不能为空")
	private String nioMaterialNo;

	/**
	 * 被取消的第三方物料号
	 */
	private String isvMaterialNo;

	/**
	 * 被取消的第三方物料批次
	 */
	private String batchNo;

	/**
	 * 取消数量
	 */
	@NotNull(message = "cancelQuantity 字段不能为空")
	private BigDecimal cancelQuantity;

	/**
	 * 取消原因
	 */
	private String reason;

}
