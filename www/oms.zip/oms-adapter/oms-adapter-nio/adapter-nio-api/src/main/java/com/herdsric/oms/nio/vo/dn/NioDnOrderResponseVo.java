package com.herdsric.oms.nio.vo.dn;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.RandomUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.herdsric.oms.common.client.dn.dto.DnOrderPackageDTO;
import com.herdsric.oms.common.client.dn.dto.DnOrderResponseDTO;
import com.herdsric.oms.common.client.enums.SyncEnum;
import com.herdsric.oms.nio.common.NioConstant;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author zcl
 */
@Data
@JsonPropertyOrder({ "schema", "param" })
public class NioDnOrderResponseVo implements Serializable {

	private String schema;

	private Object param;

	@Data
	@JsonPropertyOrder({ "currentStatus", "expressList", "isvOutboundNo", "isvSource", "mergeShipQty", "nioOrderNo",
			"operateTime", "orderPackageList", "outboundNo", "shipperCode", "shipperName", "shipperNo", "shipperUrl",
			"warehouseNo" })
	public static class NioDnOrderResponseParam {

		/**
		 * 第三方平台代码
		 */
		private String isvSource;

		/**
		 * 蔚来销售指令号--合单号
		 */
		private String nioOrderNo;

		/**
		 * 第三方平台代码
		 */
		private String orderType;

		/**
		 * 出库库房编号
		 */
		private String warehouseNo;

		/**
		 * 第三方出库凭证号，作为唯一凭证
		 */
		private String isvOutboundNo;

		/**
		 * 出库单号
		 */
		private String outboundNo;

		/**
		 * 订单当前状态 （ 已复核:""Reviewed"", 面单已打印: ""Printed"" 拣货中:""Picking"",------不可取消
		 * 拣货完成:""Picked"", 打包中:""Packing"", 打包复核:""RackingCheck"", 打包完成:""Packed"", 订车完成：
		 * 出库中:""Outbounding"", 出库完成:""Outbounded""; ）
		 */
		private String currentStatus;

		/**
		 * 承运商编号
		 */
		private String shipperCode;

		/**
		 * 承运商名称
		 */
		private String shipperName;

		/**
		 * 快递单号，自提没有此信息，其余有快递单号；
		 */
		private String shipperNo;

		/**
		 * 合并发运单数,表明该出库单包含几个订单
		 */
		private int mergeShipQty;

		/**
		 * 操作时间，格式为YYYYMMDD24HIMMSS
		 */
		private long operateTime;

		/**
		 * 预计送达时间
		 */
		private String expectDeliveryDate;

		/**
		 * 发货包裹明细集合
		 */
		private List<NioRequestDnPackage> orderPackageList;

		/**
		 * NIO快递路由信息
		 */
		private List<NioExpress> expressList;

		// H5 链接。展示订单打包信息 shipperUrl =
		// http://auto-europe.lux-mate.cn:8080/dn-view/#/?outOrderNo={}&client={}
		private String shipperUrl;

	}

	private static long convertTime(String time) {
		if (StrUtil.isNotEmpty(time)) {
			// 定义日期时间格式
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern(NioConstant.TIME_FORMAT);
			// 解析字符串为 LocalDateTime 对象
			LocalDateTime dateTime = LocalDateTime.parse(time, formatter);
			// 转换为 long 类型时间戳
			return dateTime.toEpochSecond(java.time.ZoneOffset.UTC) * 1000;
		}
		return 0L;
	}

	public static NioDnOrderResponseVo convert(String type, DnOrderResponseDTO dnOrderResponseDm) {
		NioDnOrderResponseVo nioDnOrderResponseVo = new NioDnOrderResponseVo();
		nioDnOrderResponseVo.setSchema(NioConstant.DN_UPDATE_SCHEMA);
		NioDnOrderResponseParam nioDnOrderResponseParam = new NioDnOrderResponseParam();
		nioDnOrderResponseParam.setIsvSource(NioConstant.ISV_SOURCE);
		nioDnOrderResponseParam.setNioOrderNo(dnOrderResponseDm.getOrderNo());
		// nioDnOrderResponseParam.setOrderType(params.getOrderType());
		nioDnOrderResponseParam.setWarehouseNo(dnOrderResponseDm.getVirtualWarehouseCode());
		nioDnOrderResponseParam
				.setIsvOutboundNo((dnOrderResponseDm.getOrderNo()) + StrUtil.UNDERLINE + RandomUtil.randomString(4));
		nioDnOrderResponseParam.setOutboundNo(dnOrderResponseDm.getOrderNo());
		nioDnOrderResponseParam.setShipperCode(NioConstant.SHIPPER_CODE);
		nioDnOrderResponseParam.setShipperName(NioConstant.SHIPPER_NAME);
		// TODO 这里暂时沿用portal逻辑，用订单号设置shipperNo，后续可能需要按照运输单号
		nioDnOrderResponseParam.setShipperNo(dnOrderResponseDm.getOrderNo());
		nioDnOrderResponseParam.setMergeShipQty(0);
		if (SyncEnum.DN_ORDER_STATUS_PRODUCT_SYNC.name().equals(type)) {
			nioDnOrderResponseParam.setOperateTime(convertTime(String.valueOf(dnOrderResponseDm.getProductTime())));
			nioDnOrderResponseParam.setCurrentStatus(NioConstant.PICKING);
		}
		if (SyncEnum.DN_ORDER_STATUS_RELEASE_SYNC.name().equals(type)) {
			nioDnOrderResponseParam.setOperateTime(convertTime(String.valueOf(dnOrderResponseDm.getReleaseTime())));
			nioDnOrderResponseParam.setCurrentStatus(NioConstant.PACKING);
		}
		if (SyncEnum.DN_ORDER_STATUS_PACKED_SYNC.name().equals(type)) {
			nioDnOrderResponseParam.setOperateTime(convertTime(String.valueOf(dnOrderResponseDm.getPackageTime())));
			nioDnOrderResponseParam.setCurrentStatus(NioConstant.PACKED);
			nioDnOrderResponseParam.setShipperUrl(dnOrderResponseDm.getOrderTracingLink());
		}
		if (SyncEnum.DN_ORDER_STATUS_BOOKED_SYNC.name().equals(type)) {
			nioDnOrderResponseParam.setOperateTime(convertTime(String.valueOf(dnOrderResponseDm.getShipTime())));
			nioDnOrderResponseParam.setCurrentStatus(NioConstant.BOOKED);
			// nioDnOrderResponseParam.setShipperUrl(dnOrderResponseDm.getOrderTracingLink());
			// 正式环境没有用到这个字段
		}
		if (SyncEnum.DN_ORDER_STATUS_OUTBOUND_SYNC.name().equals(type)) {
			nioDnOrderResponseParam.setOperateTime(convertTime(String.valueOf(dnOrderResponseDm.getPickUpTime())));
			nioDnOrderResponseParam.setCurrentStatus(NioConstant.OUTBOUNDED);
			nioDnOrderResponseParam.setShipperUrl(dnOrderResponseDm.getOrderTracingLink());
		}
		if (SyncEnum.DN_ORDER_STATUS_POD_SYNC.name().equals(type)) {
			nioDnOrderResponseParam.setOperateTime(convertTime(String.valueOf(dnOrderResponseDm.getPodTime())));
			nioDnOrderResponseParam.setCurrentStatus(NioConstant.RECEIVED);
			nioDnOrderResponseParam.setShipperUrl(dnOrderResponseDm.getOrderTracingLink());
		}
		// nioDnOrderResponseParam.setExpectDeliveryDate(params.getExpectedDeliveryDate());
		// List<OrderLineDm> orderLines = dnOrderResponseDm.getOrderLines();
		List<DnOrderPackageDTO> packageDetails = dnOrderResponseDm.getPackageDetails();
		if (CollectionUtil.isNotEmpty(packageDetails)
				&& !StrUtil.equalsAny(type, SyncEnum.DN_ORDER_STATUS_PRODUCT_SYNC.name(),
						SyncEnum.DN_ORDER_STATUS_RELEASE_SYNC.name(), SyncEnum.DN_ORDER_STATUS_BOOKED_SYNC.name(),
						SyncEnum.DN_ORDER_STATUS_POD_SYNC.name())
				&& packageDetails.stream().anyMatch(a -> StrUtil.isNotEmpty(a.getPackageTime()))) {

			List<NioRequestDnPackage> nioRequestDnPackages = new ArrayList<>();

			packageDetails.stream().filter(a -> ObjectUtil.isNotNull(a.getQty()) && Double.parseDouble(a.getQty()) > 0)
					.collect(Collectors.groupingBy(x -> x.getBoxNo() + StrUtil.UNDERLINE + x.getPackageTime()
							+ StrUtil.UNDERLINE + x.getPackageType()))
					.forEach((a, b) -> {
						NioRequestDnPackage nioRequestDnPackage = new NioRequestDnPackage();
						nioRequestDnPackage.setPackageNo(b.get(0).getBoxNo());
						// nioRequestDnPackage.setPackageWeight(b.get(0).getWeight());
						// 正式环境没有用到这个字段
						// nioRequestDnPackage.setPackageStatus();
						nioRequestDnPackage.setOperateTime(convertTime(b.get(0).getPackageTime()));
						// nioRequestDnPackage.setOperateUser();
						List<NioRequestDnPackageItem> orderPackageList = new ArrayList<>();
						b.forEach(x -> {

							NioRequestDnPackageItem orderPackage = new NioRequestDnPackageItem();
							orderPackage.setNioMaterialNo(x.getPartNumber());
							// orderPackage.setIsvMaterialNo();
							// orderPackage.setMaterialName();
							// orderPackage.setBatchNo();
							// orderPackage.setProduceDate();
							// orderPackage.setValidity();
							orderPackage.setQuantity(BigDecimal.valueOf(Double.parseDouble(x.getQty())));
							if (Double.parseDouble(x.getQty()) > 0) {
								orderPackageList.add(orderPackage);
							}
						});
						nioRequestDnPackage.setMaterialList(orderPackageList);
						nioRequestDnPackages.add(nioRequestDnPackage);
					});
			if (CollectionUtil.isNotEmpty(nioRequestDnPackages)) {
				nioDnOrderResponseParam.setOrderPackageList(nioRequestDnPackages);
			}
		}

		// pod的时候请求体没有该数据
		if (ObjectUtil.isNotEmpty(dnOrderResponseDm.getTrackingNumber())) {
			List<NioExpress> nioExpressList = new ArrayList<>();
			NioExpress nioExpress = new NioExpress();
			nioExpress.setExpressNo(dnOrderResponseDm.getTrackingNumber());
			nioExpress.setOperateTime(dnOrderResponseDm.getShipTime());
			// nioExpress.setTraceMark(dnOrderResponseDm.getOrderTracingLink());
			// 正式环境没有用到这个字段
			nioExpressList.add(nioExpress);
			if (CollectionUtil.isNotEmpty(nioExpressList)) {
				nioDnOrderResponseParam.setExpressList(nioExpressList);
			}
		}
		if (SyncEnum.DN_ORDER_STATUS_RELEASE_SYNC.name().equals(type)) {
			NioDnOrderPickingResponseVo nioDnOrderPickingResponseVo = BeanUtil.copyProperties(nioDnOrderResponseParam,
					NioDnOrderPickingResponseVo.class);
			nioDnOrderResponseVo.setParam(nioDnOrderPickingResponseVo);
		}
		else {
			nioDnOrderResponseVo.setParam(nioDnOrderResponseParam);
		}
		String jsonString = JSON.toJSONString(nioDnOrderResponseVo);
		return JSON.parseObject(jsonString).toJavaObject(NioDnOrderResponseVo.class);
	}

}
