package com.herdsric.oms.nio.manages;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.herdsric.oms.common.client.asn.AsnBizDefine;
import com.herdsric.oms.common.client.asn.domain.AsnOrderDm;
import com.herdsric.oms.common.client.asn.domain.AsnOrderLineDm;
import com.herdsric.oms.common.client.asn.dto.AsnOrderResponseDTO;
import com.herdsric.oms.common.client.asn.function.AsnOptionFlag;
import com.herdsric.oms.common.client.asn.process.AsnProcessor;
import com.herdsric.oms.common.client.masterdata.domain.SkuDm;
import com.herdsric.oms.common.client.masterdata.process.SkuProcessor;
import com.herdsric.oms.common.core.exception.ErrorCodeEnum;
import com.herdsric.oms.common.core.exception.OmsBusinessException;
import com.herdsric.oms.common.core.util.SpringContextHolder;
import com.herdsric.oms.common.webhook.CallbackHttpDefine;
import com.herdsric.oms.nio.common.NioConstant;
import com.herdsric.oms.nio.enums.ApiTypeEnum;
import com.herdsric.oms.nio.vo.asn.NioAsnResponseVo;
import com.herdsric.oms.nio.vo.asn.NioSpecialAsnResponseVo;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

@Slf4j
@RequiredArgsConstructor
public class AsnOrderManage extends CommonDefine implements AsnBizDefine {

	@Override
	public void save(AsnOrderDm asnOrderDm) {
		AsnProcessor asnProcessor = SpringContextHolder.getBean(AsnProcessor.class);
		List<String> partNumbers = asnOrderDm.getOrderLines().stream().map(AsnOrderLineDm::getPartNumber)
				.collect(Collectors.toList());
		SkuProcessor skuProcessor = SpringContextHolder.getBean(SkuProcessor.class);
		List<SkuDm> skuDmList = skuProcessor.fetchByClientAndPartNumbers(NioConstant.CLIENT_CODE, partNumbers);
		List<SkuDm> mismatchSku = skuDmList
				.stream().filter(a -> !Arrays.stream(a.getVmWarehouseCode().split(StrUtil.COMMA))
						.collect(Collectors.toList()).contains(asnOrderDm.getVmWarehouseCode()))
				.collect(Collectors.toList());
		String mismatchInfo = mismatchSku.stream().map(a -> {
			HashMap<String, String> map = new HashMap<>();
			map.put(a.getPartNumber(), a.getVmWarehouseCode());
			return map;
		}).flatMap(map -> map.entrySet().stream()).map(entry -> entry.getKey() + StrUtil.C_COLON + entry.getValue())
				.collect(Collectors.joining(StrUtil.COMMA));
		if (CollectionUtil.isNotEmpty(mismatchSku)) {
			throw new OmsBusinessException(ErrorCodeEnum.E100002.code,
					StrUtil.format("Mismatch between Order Warehouse Code:{} and Parts Virtual Warehouse Codes: {}",
							asnOrderDm.getVmWarehouseCode(), mismatchInfo));
		}
		asnProcessor.addAsnOrder(asnOrderDm);
	}

	@Override
	public void asnOrderResponseByWebhook(String clientCode, String type, String orderNo) {

		AsnProcessor asnProcessor = SpringContextHolder.getBean(AsnProcessor.class);
		Function<AsnOptionFlag, Function<AsnOrderResponseDTO, Boolean>> function = x -> {
			switch (x) {
				case Manual:
					return dm -> {
						log.info("{},asnOrder:{} 手动上传订单，需要反馈", clientCode, orderNo);
						return true;
					};
				case Responsed:
					return dm -> {
						CallbackHttpDefine callbackHttpDefine = SpringContextHolder.getBean(CallbackHttpDefine.class);
						// 对象处理,特色业务逻辑
						if (StrUtil.equals(dm.getSourceType(), NioConstant.ASN_SOURCE_TYPE)) {
							// 正常入库单反馈
							AsnOrderDm asnOrderDm = asnProcessor.getAsnOrderByOrderNo(clientCode, dm.getOrderNo());
							NioAsnResponseVo nioAsnResponseVo = NioAsnResponseVo.convert(clientCode, type, dm,
									asnOrderDm);
							if (ObjectUtil.isNotNull(nioAsnResponseVo)) {
								callbackHttpDefine.execute(true, clientCode, dm.getWarehouseCode(), dm.getOrderNo(),
										nioAsnResponseVo, type, true);
							}
						}
						else {
							// 特殊入库单反馈
							AsnOrderDm asnOrderDm = asnProcessor.getAsnOrderByOrderNo(clientCode, dm.getOrderNo());
							NioSpecialAsnResponseVo nioSpecialAsnResponseVo = NioSpecialAsnResponseVo.convert(
									clientCode, ApiTypeEnum.NIO_SPECIAL_ASN_ORDER_RESPONSE_SYNC.name(), dm, asnOrderDm);
							if (ObjectUtil.isNotNull(nioSpecialAsnResponseVo)) {
								callbackHttpDefine.execute(true, clientCode, dm.getWarehouseCode(), dm.getOrderNo(),
										nioSpecialAsnResponseVo, ApiTypeEnum.NIO_SPECIAL_ASN_ORDER_RESPONSE_SYNC.name(),
										true);
							}
						}

						return true;
					};
				case Closed:
				default:
					return dm -> {
						// 其他情况不需要反馈
						return true;
					};
			}
		};
		asnProcessor.asnOrderResponse(clientCode, type, orderNo, function);
	}

}
