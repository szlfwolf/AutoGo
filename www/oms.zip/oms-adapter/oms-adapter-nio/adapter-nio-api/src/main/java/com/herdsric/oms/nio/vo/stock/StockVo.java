package com.herdsric.oms.nio.vo.stock;

import cn.hutool.core.collection.CollectionUtil;
import com.herdsric.oms.common.client.stock.domain.StockDm;
import lombok.Data;
import java.util.ArrayList;
import java.util.List;

/**
 * @author zcl
 */
@Data
public class StockVo {

	/**
	 * 第三方平台代码
	 */
	private String isvSource;

	/**
	 * 仓库编号，自营物料库存查询必填，代销物料物流非蔚来运营非必填
	 */
	private String warehouseNo;

	/**
	 * 第三方平台库存查询结果中物料编号列表
	 */
	private List<NioQueryStockResponseMaterial> materialList;

	/**
	 * 预留字段1
	 */
	private List<String> ext1;

	/**
	 * 预留字段2
	 */
	private List<String> ext2;

	/**
	 * 预留字段3
	 */
	private List<String> ext3;

	/**
	 * 预留字段4
	 */
	private List<String> ext4;

	/**
	 * 预留字段5
	 */
	private List<String> ext5;

	/**
	 * 总记录数
	 */
	private Integer recordCount;

	public static StockVo convert(List<StockDm> stockDms, String isvSource) {
		StockVo stockVo = new StockVo();
		stockVo.setIsvSource(isvSource);
		if (CollectionUtil.isNotEmpty(stockDms)) {
			stockVo.setWarehouseNo(stockDms.get(0).getWarehouseCode());
			stockVo.setRecordCount(stockDms.size());
			List<NioQueryStockResponseMaterial> details = new ArrayList<>();
			for (StockDm stockDm : stockDms) {
				NioQueryStockResponseMaterial nioQueryStockResponseMaterial = new NioQueryStockResponseMaterial();
				nioQueryStockResponseMaterial.setNioMaterialNo(stockDm.getPartNumber());
				// nioQueryStockResponseMaterial.setIsvMaterialNo();
				nioQueryStockResponseMaterial.setMaterialName(stockDm.getPartDesc());
				// nioQueryStockResponseMaterial.setBatchNo();
				nioQueryStockResponseMaterial.setTotalQty((double) stockDm.getTotalQty());
				nioQueryStockResponseMaterial.setUsableTotalQty((double) stockDm.getUsableTotalQty());
				nioQueryStockResponseMaterial.setUsableQty((double) stockDm.getUsableQty());
				nioQueryStockResponseMaterial.setLevelAQty(0.0);
				nioQueryStockResponseMaterial.setLevelAUsableQty(0.0);
				nioQueryStockResponseMaterial.setLevelBQty(0.0);
				nioQueryStockResponseMaterial.setLevelBUsableQty(0.0);
				nioQueryStockResponseMaterial.setLevelCQty(0.0);
				nioQueryStockResponseMaterial.setLevelCUsableQty(0.0);
				details.add(nioQueryStockResponseMaterial);
			}
			stockVo.setMaterialList(details);
			return stockVo;
		}
		return null;
	}

}
