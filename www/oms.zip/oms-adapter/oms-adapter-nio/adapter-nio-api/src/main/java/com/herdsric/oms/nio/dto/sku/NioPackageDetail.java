package com.herdsric.oms.nio.dto.sku;

import lombok.Data;
import javax.validation.constraints.NotBlank;

/**
 * @author zcl
 */
@Data
public class NioPackageDetail {

	/**
	 * 物料对应供应商代码
	 */
	private String nioSupplierNo;

	/**
	 * 装箱量
	 */
	private Double boxRegulation;

	/**
	 * 外包装长(mm)
	 */
	private Double length;

	/**
	 * 外包装宽(mm)
	 */
	private Double width;

	/**
	 * 外包装高(mm)
	 */
	private Double height;

	/**
	 * 内包装长(mm)
	 */
	@NotBlank(message = "innerLength 内包装长不能为空")
	private Double innerLength;

	/**
	 * 内包装宽(mm)
	 */
	@NotBlank(message = "innerWidth 内包装宽不能为空")
	private Double innerWidth;

	/**
	 * 内包装高(mm)
	 */
	@NotBlank(message = "innerHeight 内包装高不能为空")
	private Double innerHeight;

}
