package com.herdsric.oms.nio.enums;

/**
 * N销售平台来源代码
 */
public enum NioSalePlatformSourceEnum {

	OFS, MERCURY

}
