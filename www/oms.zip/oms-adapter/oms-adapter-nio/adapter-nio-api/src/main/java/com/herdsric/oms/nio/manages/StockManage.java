package com.herdsric.oms.nio.manages;

import com.herdsric.oms.common.client.asn.process.AsnProcessor;
import com.herdsric.oms.common.client.enums.SyncEnum;
import com.herdsric.oms.common.client.stock.StockDefine;
import com.herdsric.oms.common.client.stock.domain.StockDm;
import com.herdsric.oms.common.client.stock.domain.StockLogDm;
import com.herdsric.oms.common.client.stock.dto.StockDTO;
import com.herdsric.oms.common.client.stock.process.StockProcessor;
import com.herdsric.oms.common.core.util.SpringContextHolder;
import com.herdsric.oms.common.webhook.CallbackHttpDefine;
import com.herdsric.oms.nio.common.NioConstant;

import java.util.List;

/**
 * @author zcl
 */
public class StockManage extends CommonDefine implements StockDefine {

	@Override
	public List<StockDm> queryStock(StockDTO stockDTO) {
		StockProcessor stockProcessor = SpringContextHolder.getBean(StockProcessor.class);
		return stockProcessor.queryPageStock(NioConstant.CLIENT_CODE, stockDTO);
	}

	@Override
	public List<StockLogDm> queryStockLog(String warehouseCode, List<String> partNumbers, String type) {
		return null;
	}

	@Override
	public boolean stockLogSync(String clientCode, String warehouseCode, String refNo, String type) {
		StockProcessor asnProcessor = SpringContextHolder.getBean(StockProcessor.class);
		List<StockLogDm> stockLogDms = asnProcessor.fetchStockLogByRefNo(clientCode, refNo, type);

		CallbackHttpDefine callbackHttpDefine = SpringContextHolder.getBean(CallbackHttpDefine.class);
		for (StockLogDm stockLogDm : stockLogDms) {
			callbackHttpDefine.execute(true, clientCode, warehouseCode, stockLogDm.getRefNo(), stockLogDm,
					SyncEnum.STOCK_LOG_SYNC.name(), false);
		}
		return true;
	}

}
