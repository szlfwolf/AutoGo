package com.herdsric.oms.nio.vo.stock;

import lombok.Data;
import java.math.BigDecimal;
import java.util.List;

/**
 * @author zcl
 */
@Data
public class NioRequestStockChange {

	/**
	 * 库存调整单号
	 */
	private String changeNo;

	/**
	 * 第三方平台代码
	 */
	private String isvSource;

	/**
	 * 库房编号
	 */
	private String warehouseNo;

	/**
	 * 调整类型：(ZSTZ:质损调整)
	 */
	private String changeType;

	/**
	 * 操作时间，格式为YYYYMMDD24HIMMSS
	 */
	private long operateTime;

	/**
	 * 操作人
	 */
	private String operateUser;

	/**
	 * 库存调整原因
	 */
	private String reasonDesc;

	/**
	 * 调整的物料列表
	 */
	private List<NioRequestStockMaterial> fromMaterialList;

	/**
	 * 调整后第三方物料
	 */
	private List<NioRequestStockMaterial> toMaterialList;

	@Data
	public static class NioRequestStockMaterial {

		private static final long serialVersionUID = 1L;

		/**
		 * SAP物料编码
		 */
		private String nioMaterialNo;

		/**
		 * 第三方物料编码
		 */
		private String isvMaterialNo;

		/**
		 * 批次号
		 */
		private String batchNo;

		/**
		 * 良品部分中的调整数量
		 */
		private BigDecimal usableQty;

		/**
		 * A级质损中的调整数量
		 */
		private BigDecimal levelAQty;

		/**
		 * B级质损中的调整数量
		 */
		private BigDecimal levelBQty;

		/**
		 * C级质损中的调整数量
		 */
		private BigDecimal levelCQty;

	}

}
