package com.herdsric.oms.nio.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;
import java.util.Objects;
import java.util.Optional;

/**
 * @author ：范春宇
 * @date ：Created in 2022/10/8 18:38 @description：
 * @modified By：
 */
@Getter
@AllArgsConstructor
public enum NioConsigneePickupTypeEnum {

	/**
	 * 收货类型0：to b
	 */
	TO_B("0", "To B", null),
	/**
	 * 1：to c
	 */
	TO_C("1", "To C", "To C"),
	/**
	 * 2:Self Pick Up
	 */
	SELF_PICK_UP("2", "Self Pick Up", null);

	/**
	 * 收货方式类型
	 */
	private final String consigneePickupType;

	/**
	 * 收货方式
	 */
	private final String consigneePickupName;

	/**
	 * 订单类型
	 */
	private final String orderType;

	/**
	 * @author: 范春宇
	 * @description: 根据收货方式类型获取订单类型
	 * @date 2022/10/8 18:45
	 * @param consigneePickupType:
	 * @param orderType:
	 * @return: null
	 */
	public static String getOrderTypeByConsigneePickupType(String consigneePickupType, String orderType) {
		// 查找收货方式相同并且 orderType不为null
		Optional<NioConsigneePickupTypeEnum> filterEntity = Arrays.stream(NioConsigneePickupTypeEnum.values()).filter(
				x -> consigneePickupType.equals(x.getConsigneePickupType()) && Objects.nonNull(x.getOrderType()))
				.findFirst();
		// 如果Optional 不为null，则返回该实体的类型
		if (filterEntity.isPresent()) {
			return filterEntity.get().orderType;
		}
		// 否则 返回自己的订单类型
		return orderType;
	}

}
