package com.herdsric.oms.nio.vo.dn;

import lombok.Data;

/**
 * @author zcl
 */
@Data
public class NioExpress {

	/**
	 * 快递单号
	 */
	private String expressNo;

	/**
	 * 节点时间 yyyy-MM-dd HH:mm:ss
	 */
	private String operateTime;

	/**
	 * 快递路由的描述
	 */
	private String traceMark;

}
