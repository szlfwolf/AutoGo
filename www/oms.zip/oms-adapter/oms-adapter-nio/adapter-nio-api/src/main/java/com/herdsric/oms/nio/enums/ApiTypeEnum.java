package com.herdsric.oms.nio.enums;

public enum ApiTypeEnum {

	NIO_SPECIAL_DN_ORDER_RESPONSE_SYNC,

	NIO_SPECIAL_ASN_ORDER_RESPONSE_SYNC,;

}
