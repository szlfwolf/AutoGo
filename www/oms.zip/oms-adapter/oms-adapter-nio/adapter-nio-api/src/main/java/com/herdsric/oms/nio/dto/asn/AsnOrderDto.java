package com.herdsric.oms.nio.dto.asn;

import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.herdsric.oms.common.client.asn.domain.AsnOrderDm;
import com.herdsric.oms.common.client.asn.domain.AsnOrderLineDm;
import com.herdsric.oms.common.core.exception.OmsBusinessException;
import com.herdsric.oms.nio.common.NioConstant;
import com.herdsric.oms.nio.enums.NioResultCode;
import com.herdsric.oms.nio.enums.VmWarehouseEnum;
import com.herdsric.oms.nio.enums.WarehouseCodeEnum;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * @author zcl
 */
@Data
public class AsnOrderDto {

	private String schema;

	private NioAsnOrderDto param;

	@Data
	public static class NioAsnOrderDto {

		/**
		 * 第三方平台代码
		 */
		@NotNull(message = "isvSource can not be null or empty")
		private String isvSource;

		/**
		 * 仓库编号，自营物料必填，代销物料物流非蔚来运营非必填
		 */
		private String warehouseNo;

		/**
		 * ASN号码
		 */
		@NotNull(message = "asnNo can not be null or empty")
		private String asnNo;

		/**
		 * 提货单号
		 */
		private String ladingOrder;

		/**
		 * 目的港
		 */
		private String decPort;

		/**
		 * 船名（CARRIER）
		 */
		private String carrier;

		/**
		 * 船名（集装箱号）
		 */
		private String container;

		/**
		 * 预计开船时间(ETD):yyyy-MM-dd HH:mm:ss
		 */
		private String etd;

		/**
		 * 预计到达时间(ETA):yyyy-MM-dd HH:mm:ss
		 */
		private String eta;

		/**
		 * 供应商编号
		 */
		@NotNull(message = "supplierNo can not be null or empty")
		private String supplierNo;

		/**
		 * ASN计划收货时间，格式为YYYYMMDD24HIMMSS； SAP的PO类型的ASN没有这个时间，LOPA取当前时间下发
		 */
		@NotNull(message = "planDeliveryTime can not be null or empty")
		private long planDeliveryTime;

		/**
		 * ASN清单
		 */
		@NotNull(message = "asnDetailList can not be null or empty")
		@Valid
		private List<AsnOrderDetailDto> asnDetailList;

	}

	public void check() {
		if (!StrUtil.equals(NioConstant.ASN_SCHEMA, this.schema)) {
			throw new OmsBusinessException(NioResultCode.OTHER_ERROR.getValue(),
					StrUtil.format("object attribute schema must be:{}", NioConstant.ASN_SCHEMA));
		}
		if (ObjectUtil.isNotNull(this.param)) {
			if (!ObjectUtil.isNotNull(this.param.getWarehouseNo())
					|| !VmWarehouseEnum.match(this.param.getWarehouseNo())) {
				throw new OmsBusinessException(NioResultCode.OTHER_ERROR.getValue(),
						StrUtil.format("Nio vmWarehouse Code: {} is error!", this.param.getWarehouseNo()));
			}
		}
		boolean invalidQty = this.param.asnDetailList.stream().anyMatch(a -> !isQtyValid(a.getAsnQty()));
		if (invalidQty) {
			throw new OmsBusinessException(NioResultCode.OTHER_ERROR.getValue(), StrUtil
					.format("AsnOrder part quantity is less than or equal to zero，or quantity format is wrong!"));
		}
	}

	public static AsnOrderDm convert(AsnOrderDto asnOrderDto) {
		NioAsnOrderDto nioAsnOrderDto = asnOrderDto.getParam();
		AsnOrderDm asnOrderDm = new AsnOrderDm();
		asnOrderDm.setOrderType(NioConstant.ASN_TYPE);
		asnOrderDm.setVmWarehouseCode(nioAsnOrderDto.getWarehouseNo());
		if (VmWarehouseEnum.isNl(nioAsnOrderDto.getWarehouseNo())) {
			asnOrderDm.setWarehouseCode(WarehouseCodeEnum.Holland.code);
		}
		else if (VmWarehouseEnum.isNo(nioAsnOrderDto.getWarehouseNo())) {
			asnOrderDm.setWarehouseCode(WarehouseCodeEnum.Norway.code);
		}
		asnOrderDm.setOrderNo(nioAsnOrderDto.getAsnNo());
		asnOrderDm.setBillLandNum(nioAsnOrderDto.getLadingOrder());
		asnOrderDm.setCarrier(nioAsnOrderDto.getCarrier());
		asnOrderDm.setDestination(nioAsnOrderDto.getDecPort());
		// asnOrderDm.setInvoiceNum();
		// asnOrderDm.setPostDischarge();
		asnOrderDm.setEtaTime(nioAsnOrderDto.getEta());
		// asnOrderDm.setEtdTime(nioAsnOrderDto.getEtd());
		// asnOrderDm.setArrivalTime();
		asnOrderDm.setPickUpTime(dateTimeFormat(nioAsnOrderDto.getPlanDeliveryTime()));
		asnOrderDm.setSupplierCode(nioAsnOrderDto.getSupplierNo());
		// asnOrderDm.setRemark();
		// asnOrderDm.setExtendProps();
		List<AsnOrderLineDm> inboundOrderLines = new ArrayList<>();
		for (AsnOrderDetailDto asnOrderDetailDto : nioAsnOrderDto.getAsnDetailList()) {
			AsnOrderLineDm inboundOrderLine = new AsnOrderLineDm();
			inboundOrderLine.setBatchNo(asnOrderDetailDto.getBatchNo());
			inboundOrderLine.setLineNo(asnOrderDetailDto.getAsnItemNo());
			inboundOrderLine.setPartNumber(asnOrderDetailDto.getNioMaterialNo());
			inboundOrderLine.setQty(String.valueOf(asnOrderDetailDto.getAsnQty().intValue()));
			inboundOrderLine.setUnit(NioConstant.UNIT_PCS);
			// inboundOrderLine.setVin();
			// inboundOrderLine.setRemark();
			HashMap<String, Object> map = new HashMap<>();
			map.put("poNo", asnOrderDetailDto.getPoNo());
			map.put("poLineNo", asnOrderDetailDto.getPoLineNo());
			map.put("poLineQty", asnOrderDetailDto.getPoLineQty());
			inboundOrderLine.setExtendProps(map);
			// inboundOrderLine.setContainerNo();
			// inboundOrderLine.setPalletNo();
			inboundOrderLines.add(inboundOrderLine);
		}
		asnOrderDm.setOrderLines(inboundOrderLines);
		return asnOrderDm;
	}

	private static String dateTimeFormat(long timestamp) {
		// 将时间戳转换为LocalDateTime对象
		LocalDateTime dateTime = LocalDateTime.ofInstant(Instant.ofEpochMilli(timestamp), ZoneId.systemDefault());
		// 定义日期时间格式
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		// 将LocalDateTime对象格式化为字符串时间
		return dateTime.format(formatter);
	}

	private static boolean isQtyValid(BigDecimal qtyValue) {
		try {
			// 检查 qty 是否大于 0
			if (qtyValue.compareTo(BigDecimal.ZERO) > 0) {
				// 检查 qty 是否是整数或具有 ".0" 的小数位
				return qtyValue.stripTrailingZeros().scale() <= 0;
			}
		}
		catch (Exception e) {
			return false;
		}
		return false;
	}

}
