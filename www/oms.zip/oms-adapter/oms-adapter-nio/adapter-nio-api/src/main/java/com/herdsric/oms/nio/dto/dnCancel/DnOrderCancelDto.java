package com.herdsric.oms.nio.dto.dnCancel;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.StrUtil;
import com.herdsric.oms.common.client.dn.domain.DnOrderCancelDm;
import com.herdsric.oms.common.core.exception.OmsBusinessException;
import com.herdsric.oms.nio.common.NioConstant;
import com.herdsric.oms.nio.enums.NioResultCode;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @author zcl
 */
@Data
public class DnOrderCancelDto {

	@NotBlank(message = "schema 字段不能为空")
	private String schema;

	@Valid
	@NotNull(message = "param 不能为空")
	private NioCancelOrder param;

	public void check() {
		if (!StrUtil.equals(NioConstant.CANCEL_ORDER_SCHEMA, this.schema)) {
			throw new OmsBusinessException(NioResultCode.OTHER_ERROR.getValue(),
					StrUtil.format("schema字段必须是:{}", NioConstant.CANCEL_ORDER_SCHEMA));
		}
		// 校验
		if (StrUtil.isEmpty(param.getNioUUID())) {
			throw new OmsBusinessException(NioResultCode.OTHER_ERROR.getValue(), "取消订单的DN号为空");
		}
		if (CollectionUtil.isEmpty(param.getCancelMaterial())) {
			throw new OmsBusinessException(NioResultCode.OTHER_ERROR.getValue(), "订单中被取消的物料明细不能为空");
		}
	}

	public static DnOrderCancelDm convertCancel(DnOrderCancelDto dnOrderCancelDto) {
		NioCancelOrder nioCancelOrder = dnOrderCancelDto.getParam();
		DnOrderCancelDm dnOrderCancelDm = new DnOrderCancelDm();
		dnOrderCancelDm.setOrderNo(nioCancelOrder.getNioUUID());
		// List<DnOrderCancelLineModelDm.DnOrderCancelDetail> dnOrderCancelDetails = new
		// ArrayList<>();
		// nioCancelOrder.getCancelMaterial().forEach(x -> {
		// DnOrderCancelLineModelDm.DnOrderCancelDetail dnOrderCancelDetail = new
		// DnOrderCancelLineModelDm.DnOrderCancelDetail();
		// dnOrderCancelDetail.setPartNumber(x.getNioMaterialNo());
		// dnOrderCancelDetail.setCancelQty(x.getCancelQuantity().intValue());
		// dnOrderCancelDetail.setReason(x.getReason());
		// dnOrderCancelDetails.add(dnOrderCancelDetail);
		// });
		// dnOrderCancelDm.setDnOrderCancelDetails(dnOrderCancelDetails);
		return dnOrderCancelDm;
	}

}
