package com.herdsric.oms.nio.dto.dnCancel;

import lombok.Data;
import javax.validation.constraints.NotBlank;
import java.util.List;

/**
 * @author zcl
 */
@Data
public class NioCancelOrder {

	/**
	 * 蔚来销售指令号，对自营物料发送蔚来物流平台物流单号
	 */
	@NotBlank(message = "nioUUID 字段不能为空")
	private String nioUUID;

	/**
	 * 第三方平台代码
	 */
	@NotBlank(message = "isvSource 字段不能为空")
	private String isvSource;

	/**
	 * 仓库编号，自营物料必填，代销物料物流非蔚来运营非必填
	 */
	private String warehouseNo;

	/**
	 * 订单中被取消的物料明细
	 */
	private List<NioCancelOrderMaterial> cancelMaterial;

}
