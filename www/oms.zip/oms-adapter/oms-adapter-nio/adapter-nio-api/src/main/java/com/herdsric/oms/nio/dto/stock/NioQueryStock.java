package com.herdsric.oms.nio.dto.stock;

import lombok.Data;
import javax.validation.constraints.NotBlank;
import java.util.List;

/**
 * @author zcl
 */
@Data
public class NioQueryStock {

	/**
	 * 第三方平台代码
	 */
	@NotBlank(message = "isvSource can not be null or empty")
	private String isvSource;

	/**
	 * 仓库编号，自营物料库存查询必填，代销物料物流非蔚来运营非必填
	 */
	private String warehouseNo;

	/**
	 * NIO物料编号列表，为空则代表查询所有物料
	 */
	private List<String> nioMaterialNo;

	/**
	 * 第三方平台物料编号列表，为空则代表查询所有物料
	 */
	private List<String> isvMaterialNo;

	/**
	 * 当前页
	 */
	private Integer currentPage;

	/**
	 * 每页记录数
	 */
	private Integer pageSize;

}
