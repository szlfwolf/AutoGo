package com.herdsric.oms.nio.vo.stock;

import lombok.Data;

/**
 * @author zcl
 */
@Data
public class NioQueryStockResponseMaterial {

	/**
	 * NIO物料编号
	 */
	private String nioMaterialNo;

	/**
	 * 第三方物料编号
	 */
	private String isvMaterialNo;

	/**
	 * 物料名称
	 */
	private String materialName;

	/**
	 * 批次号
	 */
	private String batchNo;

	/**
	 * 第三方平台库存查询结果中总库存
	 */
	private Double totalQty;

	/**
	 * 第三方平台库存查询结果中良品总库存
	 */
	private Double usableTotalQty;

	/**
	 * 第三方平台库存查询结果中良品可用库存
	 */
	private Double usableQty;

	/**
	 * 第三方平台库存查询结果中A类质损件总库存
	 */
	private Double levelAQty;

	/**
	 * 第三方平台库存查询结果中A类质损件可用库存
	 */
	private Double levelAUsableQty;

	/**
	 * 第三方平台库存查询结果中B类质损件总库存
	 */
	private Double levelBQty;

	/**
	 * 第三方平台库存查询结果中B类质损件可用库存
	 */
	private Double levelBUsableQty;

	/**
	 * 第三方平台库存查询结果中C类质损件总库存
	 */
	private Double levelCQty;

	/**
	 * 第三方平台库存查询结果中C类质损件可用库存
	 */
	private Double levelCUsableQty;

}
