package com.herdsric.oms.nio.enums;

import cn.hutool.core.util.StrUtil;
import java.util.Arrays;

public enum VmWarehouseEnum {

	NLRDC01("NLRDC01", "PARTS"), NLRDC02("NLRDC02", "NIO LIFE"), NLRDC03("NLRDC03", "APD"), NLRDC04("NLRDC04", "PE"),
	NORDC01("NORDC01", "PARTS"), NORDC02("NORDC02", "NIO LIFE"), NORDC03("NORDC03", "APD"), NORDC04("NORDC04", "PE");

	public String code;

	public String type;

	VmWarehouseEnum(String code, String type) {
		this.code = code;
		this.type = type;
	}

	public static boolean isNl(String value) {
		return Arrays.stream(VmWarehouseEnum.values())
				.filter(x -> StrUtil.equalsAny(x.code, "NLRDC01", "NLRDC02", "NLRDC03", "NLRDC04"))
				.anyMatch(x -> value.equals(x.code));
	}

	public static boolean isNo(String value) {
		return Arrays.stream(VmWarehouseEnum.values())
				.filter(x -> StrUtil.equalsAny(x.code, "NORDC01", "NORDC02", "NORDC03", "NORDC04"))
				.anyMatch(x -> value.equals(x.code));
	}

	public static boolean match(String code) {
		return Arrays.stream(VmWarehouseEnum.values()).filter(x -> StrUtil.equals(x.code, code)).count() > 0;
	}

}
