package com.herdsric.oms.nio.dto.sku;

import lombok.Data;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * @author zcl
 */
@Data
public class NioMaterial {

	/**
	 * 第三方平台代码(不可修改)
	 */
	@NotBlank(message = "isvSource can not be null or empty")
	private String isvSource;

	/**
	 * NIO主物料编码(不可修改)
	 */
	@NotBlank(message = "nioMaterialNo can not be null or empty")
	private String nioMaterialNo;

	/**
	 * 商品标识代码
	 */
	private String commodityCode;

	/**
	 * 其他物料编码
	 */
	private String otherMaterialNo;

	/**
	 * 物料种类（精品，配件，附件，PE）
	 */
	@NotBlank(message = "materialKind can not be null or empty")
	private String materialKind;

	/**
	 * 物料名称
	 */
	@NotBlank(message = "materialName can not be null or empty")
	private String materialName;

	/**
	 * 毛重，单位：克
	 */
	private BigDecimal grossWeight;

	/**
	 * 计量单位(默认值“件”)
	 */
	private String materialUnit;

	/**
	 * 是否有保质期（1否，2是）
	 */
	@NotBlank(message = "hasEXP can not be null or empty")
	private String hasEXP;

	/**
	 * 保质期天数(如果有保质期则必填)
	 */
	private String safeDays;

	/**
	 * 是否易碎品(1否，2是)
	 */
	private String breakable;

	/**
	 * 最小包装数量
	 */
	private String miniPackageQty;

	/**
	 * 物料描述
	 */
	private String materialDesc;

	// /**
	// * 物料物流信息 删除了
	// */
	// @Valid
	// @NotEmpty( message = "logisticDetail 不能为空")
	// private List<NioLogisticDetail> logisticDetail;

	/**
	 * 包装信息 只会有一组数据
	 */
	@NotBlank(message = "packageDetails can not be null or empty")
	private List<NioPackageDetail> packageDetails;

	/**
	 * 物料主数据更新操作时间
	 */
	@NotNull(message = "updateTime can not be null or empty")
	private Date updateTime;

}
