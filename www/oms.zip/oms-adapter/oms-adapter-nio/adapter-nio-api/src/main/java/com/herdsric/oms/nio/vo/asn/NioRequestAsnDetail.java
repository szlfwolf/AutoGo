package com.herdsric.oms.nio.vo.asn;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;

import java.io.Serializable;

@Data
@JsonPropertyOrder({ "applyQty", "asnItemNo", "levelAQty", "levelBQty", "levelCQty", "nioMaterialNo", "realInstoreQty",
		"usableQty" })
public class NioRequestAsnDetail implements Serializable {

	/**
	 * ASN行项目号
	 */
	private String asnItemNo;

	/**
	 * NIO物料编号
	 */
	private String nioMaterialNo;

	/**
	 * 第三方物料编号
	 */
	// private String isvMaterialNo;

	/**
	 * 批次号
	 */
	// private String batchNo;

	/**
	 * 生产日期
	 */
	// private String produceDate;

	/**
	 * 有效期
	 */
	// private String validity;

	/**
	 * 申请入库数量
	 */
	private int applyQty;

	/**
	 * 实际入库数量
	 */
	private int realInstoreQty;

	/**
	 * 可售数量
	 */
	private int usableQty;

	/**
	 * A类质损件收货数量
	 */
	private int levelAQty;

	/**
	 * B类质损件收货数量
	 */
	private int levelBQty;

	/**
	 * C类质损件收货数量
	 */
	private int levelCQty;

	/**
	 * 差异备注
	 */
	// private String remark;

}
