package com.herdsric.oms.nio.vo.dn;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;

/**
 * @author zcl
 */
@Data
@JsonPropertyOrder({ "currentStatus", "isvOutboundNo", "isvSource", "mergeShipQty", "nioOrderNo", "operateTime",
		"outboundNo", "shipperCode", "shipperName", "shipperNo", "warehouseNo" })
public class NioDnOrderPickingResponseVo {

	/**
	 * 订单当前状态 （ 已复核:""Reviewed"", 面单已打印: ""Printed"" 拣货中:""Picking"",------不可取消
	 * 拣货完成:""Picked"", 打包中:""Packing"", 打包复核:""RackingCheck"", 打包完成:""Packed"", 订车完成：
	 * 出库中:""Outbounding"", 出库完成:""Outbounded""; ）
	 */
	private String currentStatus;

	/**
	 * 第三方出库凭证号，作为唯一凭证
	 */
	private String isvOutboundNo;

	/**
	 * 第三方平台代码
	 */
	private String isvSource;

	/**
	 * 合并发运单数,表明该出库单包含几个订单
	 */
	private int mergeShipQty;

	/**
	 * 蔚来销售指令号--合单号
	 */
	private String nioOrderNo;

	/**
	 * 操作时间，格式为YYYYMMDD24HIMMSS
	 */
	private long operateTime;

	/**
	 * 出库单号
	 */
	private String outboundNo;

	/**
	 * 承运商编号
	 */
	private String shipperCode;

	/**
	 * 承运商名称
	 */
	private String shipperName;

	/**
	 * 快递单号，自提没有此信息，其余有快递单号；
	 */
	private String shipperNo;

	/**
	 * 出库库房编号
	 */
	private String warehouseNo;

}
