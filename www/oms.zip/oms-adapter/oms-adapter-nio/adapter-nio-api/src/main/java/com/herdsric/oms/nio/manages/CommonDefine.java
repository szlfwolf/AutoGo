package com.herdsric.oms.nio.manages;

import cn.hutool.core.util.StrUtil;
import com.herdsric.oms.common.client.common.BaseDefine;
import com.herdsric.oms.nio.common.NioConstant;

public class CommonDefine implements BaseDefine {

	@Override
	public boolean isSupport(String clientCode) {
		return StrUtil.equals(NioConstant.CLIENT_CODE, clientCode);
	}

}
