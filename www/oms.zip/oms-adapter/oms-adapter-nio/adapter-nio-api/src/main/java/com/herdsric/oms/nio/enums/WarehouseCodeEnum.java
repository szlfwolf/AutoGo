package com.herdsric.oms.nio.enums;

public enum WarehouseCodeEnum {

	Norway("NIO-Norway-01", "挪威仓库-对接 Freja"),

	/**
	 * 迁移仓库 10 --》 BellsingleWarehouse
	 */
	Holland("BellsingleWarehouse", "荷兰仓库-对接 唯智");

	public final String code;

	public final String desc;

	WarehouseCodeEnum(String code, String desc) {
		this.code = code;
		this.desc = desc;
	}

}
