package com.herdsric.oms.nio.enums;

import com.herdsric.oms.common.core.validation.EnumValidator;

public enum NioResultCode implements EnumValidator {

	SUCCESS("WL-0000", "success"), ISV_SOURCE_ERROR("WL-1000", "Incorrect third party platform code！"),
	UNAUTHORIZED("WL-1001", "Unauthorized access"),
	WAREHOUSE_NO_ERROR("WL-1002", "Warehouse code is incorrect or this warehouse does not support receiving by ASN"),
	CONSIGNEE_INFO_ERROR("WL-1003", "Incorrect consignee information"),
	CONSIGNEE_ADDRESS_ERROR("WL-1008", "Incorrect shipping address"),
	SKU_CODE_ERROR("WL-1009", "Material list is empty or material code is incorrect"),
	ORDER_INFO_ERROR("WL-1010", "Order already exists or order information is incorrect"),
	INVENTORY_ERROR("WL-1011", "Insufficient stock for submission"),
	CHANNEL_ERROR("WL-1014", "Incorrect channel information"), TIME_FORMAT_ERROR("WL-1030", "Time formatting error"),
	ORDER_EXIST_ERROR("WL-0028", "Interface idempotent！"), OTHER_ERROR("WL-1050", "Other exceptions");

	private String code;

	private String msg;

	NioResultCode(String code, String msg) {
		this.code = code;
		this.msg = msg;
	}

	@Override
	public String getValue() {
		return this.code;
	}

	public String getMsg() {
		return this.msg;
	}

}
