package com.herdsric.oms.nio.apis;

import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.herdsric.oms.common.client.dn.domain.DnOrderCancelDm;
import com.herdsric.oms.common.client.dn.domain.DnOrderDm;
import com.herdsric.oms.common.core.constant.SecurityConstants;
import com.herdsric.oms.common.core.exception.OmsBusinessException;
import com.herdsric.oms.common.feign.client.RemoteDnOrderService;
import com.herdsric.oms.common.security.annotation.Inner;
import com.herdsric.oms.nio.common.NioApiResult;
import com.herdsric.oms.nio.common.NioConstant;
import com.herdsric.oms.nio.configs.AdapterConfig;
import com.herdsric.oms.nio.dto.dn.DnOrderDto;
import com.herdsric.oms.nio.dto.dnCancel.DnOrderCancelDto;
import com.herdsric.oms.nio.enums.NioResultCode;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@RestController
@RequestMapping("/apis/nio/dn")
@Tag(name = "DnOrderApis对外接口")
@Validated
@RequiredArgsConstructor
public class DnOrderApis {

	private final RemoteDnOrderService remoteDnOrderService;

	private final AdapterConfig adapterConfig;

	@PostMapping("/receive")
	@Inner(value = false)
	public NioApiResult receive(@RequestBody @Valid DnOrderDto dnOrderDto) {
		try {
			dnOrderDto.check();
			if (StrUtil.equals(dnOrderDto.getParam().getDisposeType(), NioConstant.DISPOSE_TYPE_1)) {
				DnOrderDm dnOrderDm = DnOrderDto.convertCreate(dnOrderDto);

				dnOrderDm.setContactEmail(StrUtil.isBlank(dnOrderDm.getContactEmail()) ? adapterConfig.getDnEmail()
						: dnOrderDm.getContactEmail());

				return new NioApiResult(
						remoteDnOrderService.save(dnOrderDm, NioConstant.CLIENT_CODE, SecurityConstants.FROM_IN));
			}
			if (StrUtil.equals(dnOrderDto.getParam().getDisposeType(), NioConstant.DISPOSE_TYPE_2)) {
				DnOrderCancelDm dnOrderDm = DnOrderDto.convertCancel(dnOrderDto);
				if (ObjectUtil.isNotNull(dnOrderDm)) {
					return new NioApiResult(remoteDnOrderService.cancelDnOrder(dnOrderDm, NioConstant.CLIENT_CODE,
							SecurityConstants.FROM_IN));
				}
				else {
					return new NioApiResult(NioResultCode.OTHER_ERROR.name(),
							"The value of the disposeType attribute is 2. The cancel function is not supported!");
				}
			}
			return new NioApiResult(NioResultCode.OTHER_ERROR.name(), NioResultCode.OTHER_ERROR.getMsg());
		}
		catch (Exception e) {
			if (e instanceof OmsBusinessException) {
				return new NioApiResult(NioResultCode.OTHER_ERROR.getValue(), ((OmsBusinessException) e).getMsg());
			}
			return new NioApiResult(NioResultCode.OTHER_ERROR.getValue(), e.getMessage());
		}
	}

	@PostMapping("/cancel")
	@Inner(value = false)
	public NioApiResult cancel(@RequestBody DnOrderCancelDto dnOrderCancelDto) {
		try {
			dnOrderCancelDto.check();
			DnOrderCancelDm dnOrderCancelDm = DnOrderCancelDto.convertCancel(dnOrderCancelDto);
			return new NioApiResult(remoteDnOrderService.cancelDnOrder(dnOrderCancelDm, NioConstant.CLIENT_CODE,
					SecurityConstants.FROM_IN));
		}
		catch (Exception e) {
			if (e instanceof OmsBusinessException) {
				return new NioApiResult(NioResultCode.OTHER_ERROR.getValue(), ((OmsBusinessException) e).getMsg());
			}
			return new NioApiResult(NioResultCode.OTHER_ERROR.getValue(), e.getMessage());
		}
	}

}
