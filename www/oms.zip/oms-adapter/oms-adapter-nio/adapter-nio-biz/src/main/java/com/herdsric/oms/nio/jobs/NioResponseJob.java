package com.herdsric.oms.nio.jobs;

import cn.hutool.core.util.StrUtil;
import com.herdsric.oms.common.core.constant.CommonConstants;
import com.herdsric.oms.common.core.constant.SecurityConstants;
import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.common.feign.client.RemoteBizRecordService;
import com.herdsric.oms.common.job.common.AbstractCommonTask;
import com.herdsric.oms.nio.common.NioConstant;
import com.herdsric.oms.nio.enums.ApiTypeEnum;
import com.herdsric.oms.nio.jobs.common.JobCommon;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * @author zcl
 */
@Component
@Slf4j
@RequiredArgsConstructor
public class NioResponseJob extends AbstractCommonTask {

	private final RemoteBizRecordService remoteBizRecordService;

	@XxlJob(JobCommon.JobName.DN_SPECIAL_RESPONSE)
	public void syncSpecialDnPickUpResponse() {
		this.execute(JobCommon.TaskEnum.DN_SPECIAL_RESPONSE, x -> {
			R result = remoteBizRecordService.jobTrigger(ApiTypeEnum.NIO_SPECIAL_DN_ORDER_RESPONSE_SYNC.name(),
					NioConstant.CLIENT_CODE, SecurityConstants.FROM_IN);
			if (result.getCode() != CommonConstants.SUCCESS) {
				log.info(StrUtil.format("查询反馈数据feign调用失败,错误信息:{}", result.getMsg()));
			}
		});
	}

	@XxlJob(JobCommon.JobName.ASN_SPECIAL_RESPONSE)
	public void syncSpecialAsnResponse() {
		this.execute(JobCommon.TaskEnum.ASN_SPECIAL_RESPONSE, x -> {
			R result = remoteBizRecordService.jobTrigger(ApiTypeEnum.NIO_SPECIAL_ASN_ORDER_RESPONSE_SYNC.name(),
					NioConstant.CLIENT_CODE, SecurityConstants.FROM_IN);
			if (result.getCode() != CommonConstants.SUCCESS) {
				log.info(StrUtil.format("查询反馈数据feign调用失败,错误信息:{}", result.getMsg()));
			}
		});
	}

}
