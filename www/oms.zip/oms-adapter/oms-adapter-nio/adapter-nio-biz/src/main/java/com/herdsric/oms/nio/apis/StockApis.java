package com.herdsric.oms.nio.apis;

import com.herdsric.oms.common.client.stock.domain.StockDm;
import com.herdsric.oms.common.client.stock.dto.StockDTO;
import com.herdsric.oms.common.core.constant.SecurityConstants;
import com.herdsric.oms.common.core.exception.OmsBusinessException;
import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.common.feign.client.RemoteStockService;
import com.herdsric.oms.common.security.annotation.Inner;
import com.herdsric.oms.nio.common.NioApiResult;
import com.herdsric.oms.nio.common.NioConstant;
import com.herdsric.oms.nio.dto.stock.StockDto;
import com.herdsric.oms.nio.enums.NioResultCode;
import com.herdsric.oms.nio.vo.stock.StockVo;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/apis/nio/stock")
@Tag(name = "StockApis对外接口")
@Validated
@RequiredArgsConstructor
public class StockApis {

	private final RemoteStockService remoteStockService;

	@PostMapping("/query")
	@Inner(value = false)
	public NioApiResult receive(@Validated @RequestBody StockDto stockDto) {
		try {
			stockDto.check();
			StockDTO stockDTO = StockDto.convert(stockDto);
			R<List<StockDm>> listR = remoteStockService.queryStock(stockDTO, NioConstant.CLIENT_CODE,
					SecurityConstants.FROM_IN);
			List<StockDm> stockDms = listR.getData();
			return new NioApiResult(NioResultCode.SUCCESS.getValue(),
					StockVo.convert(stockDms, stockDto.getParam().getIsvSource()));
		}
		catch (Exception e) {
			if (e instanceof OmsBusinessException) {
				return new NioApiResult(NioResultCode.OTHER_ERROR.getValue(), ((OmsBusinessException) e).getMsg());
			}
			return new NioApiResult(NioResultCode.OTHER_ERROR.getValue(), e.getMessage());
		}
	}

}
