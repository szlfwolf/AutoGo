package com.herdsric.oms.nio;

import com.herdsric.oms.common.feign.annotation.EnableOmsFeignClients;
import com.herdsric.oms.common.job.annotation.EnableOmsXxlJob;
import com.herdsric.oms.common.security.annotation.EnableOmsResourceServer;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@EnableOmsXxlJob
@EnableOmsFeignClients
@EnableOmsResourceServer
@EnableDiscoveryClient
@SpringBootApplication
public class AdapterNioBizApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdapterNioBizApplication.class, args);
	}

}
