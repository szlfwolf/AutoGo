package com.herdsric.oms.nio.jobs.common;

import cn.hutool.core.util.StrUtil;
import com.herdsric.oms.common.job.common.JobTask;

public class JobCommon {

	private static final String JOB_KEY_PREFIX = "NIO-JOB-TASK";

	public static class JobName {

		public static final String DN_CREATE_RESPONSE = "DN-CREATE-RESPONSE";

		public static final String DN_RELEASE_RESPONSE = "DN-RELEASE-RESPONSE";

		public static final String DN_PACK_RESPONSE = "DN-PACK-RESPONSE";

		public static final String DN_BOOK_RESPONSE = "DN-BOOK-RESPONSE";

		public static final String DN_OUTBOUND_RESPONSE = "DN-OUTBOUND-RESPONSE";

		public static final String DN_POD_RESPONSE = "DN-POD-RESPONSE";

		public static final String ASN_RESPONSE = "ASN-RESPONSE";

		public static final String DN_SPECIAL_RESPONSE = "DN-SPECIAL-RESPONSE";

		public static final String ASN_SPECIAL_RESPONSE = "ASN-SPECIAL-RESPONSE";

	}

	public enum TaskEnum implements JobTask {

		ASN_RESPONSE(JobName.ASN_RESPONSE, 30, ""), DN_CREATE_RESPONSE(JobName.DN_CREATE_RESPONSE, 30, ""),
		DN_RELEASE_RESPONSE(JobName.DN_RELEASE_RESPONSE, 30, ""), DN_PACK_RESPONSE(JobName.DN_PACK_RESPONSE, 30, ""),
		DN_BOOK_RESPONSE(JobName.DN_BOOK_RESPONSE, 30, ""), DN_OUTBOUND_RESPONSE(JobName.DN_OUTBOUND_RESPONSE, 30, ""),
		DN_POD_RESPONSE(JobName.DN_POD_RESPONSE, 30, ""), DN_SPECIAL_RESPONSE(JobName.DN_SPECIAL_RESPONSE, 30, ""),
		ASN_SPECIAL_RESPONSE(JobName.ASN_SPECIAL_RESPONSE, 30, ""),

		;

		public String name;

		public int expireTime;

		public String desc;

		TaskEnum(String name, int expireTime, String desc) {
			this.name = name;
			this.expireTime = expireTime;
			this.desc = desc;
		}

		public String getDesc() {
			return StrUtil.concat(true, this.desc);
		}

		@Override
		public String getName() {
			return name;
		}

		@Override
		public int expireTime() {
			return expireTime;
		}

		@Override
		public String getDescription() {
			return getDesc();
		}

		public String getKey() {
			return StrUtil.concat(true, JOB_KEY_PREFIX, this.name);
		}

	}

}
