package com.herdsric.oms.nio.apis;

import com.herdsric.oms.common.client.masterdata.domain.SkuDm;
import com.herdsric.oms.common.core.constant.SecurityConstants;
import com.herdsric.oms.common.core.exception.OmsBusinessException;
import com.herdsric.oms.common.feign.client.RemoteSkuService;
import com.herdsric.oms.common.security.annotation.Inner;
import com.herdsric.oms.nio.common.NioApiResult;
import com.herdsric.oms.nio.common.NioConstant;
import com.herdsric.oms.nio.dto.sku.SkuDto;
import com.herdsric.oms.nio.enums.NioResultCode;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/apis/nio/sku")
@Tag(name = "SkuApis对外接口")
@Validated
@RequiredArgsConstructor
@Slf4j
public class SkuApis {

	private final RemoteSkuService remoteSkuService;

	@PostMapping("/receive")
	@Inner(value = false)
	public NioApiResult receive(@RequestBody SkuDto skuDto) {
		try {
			skuDto.check();
			List<SkuDm> skuDms = SkuDto.convert(skuDto);
			return new NioApiResult(
					remoteSkuService.saveBatch(skuDms, NioConstant.CLIENT_CODE, SecurityConstants.FROM_IN));
		}
		catch (Exception e) {
			if (e instanceof OmsBusinessException) {
				return new NioApiResult(NioResultCode.OTHER_ERROR.getValue(), ((OmsBusinessException) e).getMsg());
			}
			return new NioApiResult(NioResultCode.OTHER_ERROR.getValue(), e.getMessage());
		}
	}

}
