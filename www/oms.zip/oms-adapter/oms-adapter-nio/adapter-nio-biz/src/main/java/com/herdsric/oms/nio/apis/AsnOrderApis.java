package com.herdsric.oms.nio.apis;

import com.herdsric.oms.common.client.asn.domain.AsnOrderDm;
import com.herdsric.oms.common.core.constant.SecurityConstants;
import com.herdsric.oms.common.core.exception.OmsBusinessException;
import com.herdsric.oms.common.feign.client.RemoteAsnOrderService;
import com.herdsric.oms.common.security.annotation.Inner;
import com.herdsric.oms.nio.common.NioApiResult;
import com.herdsric.oms.nio.common.NioConstant;
import com.herdsric.oms.nio.dto.asn.AsnOrderDto;
import com.herdsric.oms.nio.enums.NioResultCode;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@RestController
@RequestMapping("/apis/nio/asn")
@Tag(name = "AsnOrderApis对外接口")
@Validated
@RequiredArgsConstructor
@Slf4j
public class AsnOrderApis {

	private final RemoteAsnOrderService remoteAsnOrderService;

	@PostMapping("/receive")
	@Inner(value = false)
	public NioApiResult receive(@RequestBody @Valid AsnOrderDto asnOrderDto) {
		// 基础参数校验
		try {
			asnOrderDto.check();
			AsnOrderDm asnOrderDm = AsnOrderDto.convert(asnOrderDto);
			return new NioApiResult(
					remoteAsnOrderService.save(asnOrderDm, NioConstant.CLIENT_CODE, SecurityConstants.FROM_IN));
		}
		catch (Exception e) {
			if (e instanceof OmsBusinessException) {
				return new NioApiResult(NioResultCode.OTHER_ERROR.getValue(), ((OmsBusinessException) e).getMsg());
			}
			return new NioApiResult(NioResultCode.OTHER_ERROR.getValue(), e.getMessage());
		}
	}

}
