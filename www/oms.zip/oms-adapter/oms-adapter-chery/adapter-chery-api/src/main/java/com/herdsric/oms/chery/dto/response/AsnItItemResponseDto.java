package com.herdsric.oms.chery.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.util.List;

/**
 * @author tyy
 * @createDate 2025/1/17 17:51
 */
@Data
public class AsnItItemResponseDto {

	@Schema(description = "采购订单号（ASN 号）")
	@JsonProperty("EBELN")
	private String ebeln;

	@Schema(description = "商业发票号码")
	@JsonProperty("ZX_3PL_INV")
	private String zx3plInv;

	@Schema(description = "ASN 行项目列表")
	@JsonProperty("ITEM")
	private List<AsnItemResponseDto> item;

	@Schema(description = "SAP 采购订单类型")
	@JsonProperty("BSART")
	private String bsart;

	@Schema(description = "供应商编码")
	@JsonProperty("LIFNR")
	private String lifnr;

	@Schema(description = "SAP 工厂代码")
	@JsonProperty("WERKS")
	private String werks;

	@Schema(description = "传输日期（格式：YYYYMMDD）")
	@JsonProperty("ZCDATE")
	private String zcDate;

	@Schema(description = "传输时间（格式：HHMMSS）")
	@JsonProperty("ZCTIME")
	private String zcTime;

	@Schema(description = "第三方物流确认日期（格式：YYYYMMDD）")
	@JsonProperty("ZCDATE1")
	private String zcDate1;

	@Schema(description = "预留字段")
	@JsonProperty("ZTEXT1")
	private String zText1;

	@Schema(description = "预留字段")
	@JsonProperty("ZTEXT2")
	private String zText2;

	@Schema(description = "预留字段")
	@JsonProperty("ZTEXT3")
	private String zText3;

	@Schema(description = "预留字段")
	@JsonProperty("ZTEXT4")
	private String zText4;

	@Schema(description = "预留字段")
	@JsonProperty("ZTEXT5")
	private String zText5;

}
