package com.herdsric.oms.chery.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.herdsric.oms.common.core.validation.RegexpConstants;
import com.herdsric.oms.common.core.validation.constraints.PatternOrEmpty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.util.List;

/**
 * @author tyy
 * @createDate 2025/1/16 16:33
 */
@Data
public class DnItItemDto {

	@JsonProperty("NUMRANGE")
	private String numrange;

	@NotBlank(message = "交货单号,不能为空")
	@Schema(description = "交货单号")
	@JsonProperty("VBELN")
	private String vbeln;

	@Schema(description = "原始单据号（参考 LIPS 表）")
	@JsonProperty("VBELV")
	private String vbelv;

	@Schema(description = "经销商 PO 号")
	@JsonProperty("BSTKD")
	private String bstkd;

	@NotBlank(message = "SAP 工厂代码,不能为空")
	@Schema(description = "SAP 工厂代码")
	@JsonProperty("WERKS")
	private String werks;

	@NotBlank(message = "单据类型不能为空")
	@Schema(description = "SAP 单据类型")
	@JsonProperty("LFART")
	private String lfart;

	@NotNull(message = "业务合作伙伴信息列表不能为空")
	@Valid
	@JsonProperty("IT_KUNNR")
	private List<DnItKunnrDto> IT_KUNNR;

	@PatternOrEmpty(regexp = RegexpConstants.YYYYMMDD, message = "SAP 货物发布日期输入有误,格式:YYYYMMDD")
	@Schema(description = "SAP 货物发布日期（格式：YYYYMMDD）")
	@JsonProperty("WADAT_IST")
	private String wadatIst;

	@NotNull(message = "交货单行项目列表,不能为空")
	@Valid
	@JsonProperty("ITEM")
	private List<DnItemDto> item;

}
