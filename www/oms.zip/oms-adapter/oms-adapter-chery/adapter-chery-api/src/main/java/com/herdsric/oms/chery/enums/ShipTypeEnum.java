package com.herdsric.oms.chery.enums;

import com.herdsric.oms.common.core.validation.EnumValidator;
import org.apache.commons.lang3.StringUtils;

/**
 * @author 王涛
 */

public enum ShipTypeEnum implements EnumValidator {

	SEA("Sea", "By Sea", "海运"), AIR("AirAndSeaBulk", "By Air", "空运"), LOCAL("Local", "By Express", "本地采购"),
	TRAIN("Train", "By RailWay", "铁路运输"), LOCAL_2("Local", "Land Transportation", "本地采购");

	public String key;

	public String value;

	public String desc;

	ShipTypeEnum(String value, String key, String desc) {
		this.value = value;
		this.key = key;
		this.desc = desc;
	}

	@Override
	public Object getValue() {
		return this.value;
	}

	/**
	 * 根据key获取value
	 * @param key
	 * @return
	 */
	public static String getValueByKey(String key) {
		if (StringUtils.isEmpty(key)) {
			return null;
		}
		for (ShipTypeEnum enums : ShipTypeEnum.values()) {
			if (enums.key.equals(key)) {
				return enums.value;
			}
		}

		return null;
	}

	/**
	 * 根据value获取key
	 * @param value
	 * @return
	 */
	public static String getKeyByValue(String value) {
		if (StringUtils.isEmpty(value)) {
			return null;
		}
		for (ShipTypeEnum enums : ShipTypeEnum.values()) {
			if (enums.value.equals(value)) {
				return enums.key;
			}
		}

		return null;
	}

}
