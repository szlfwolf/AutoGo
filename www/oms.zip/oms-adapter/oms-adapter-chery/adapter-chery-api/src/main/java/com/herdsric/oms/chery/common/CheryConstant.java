package com.herdsric.oms.chery.common;

public interface CheryConstant {

	// 客户代码
	String CLIENT_CODE = "CHERY";

	// 语言代码 EN英文
	String EN = "EN";

	// SKU 类型
	String Package_Type = "1";

	// Sku 包装数量
	String Package_Moq = "1";

	// SAP 预留字段（墨西哥 DHL 使用，其他第三方物流忽略）
	String NUMRANGE = "NUMRANGE";

	// SAP 工厂代码
	String WERKS = "WERKS";

	// 物料删除指示（X: 删除）
	String LVORM = "LVORM";

	String ASN_ORDER_TYPE = "ZGJ1";

	// 库存地点（沙特备件固定为 SA12）
	String LGORT = "LGORT";

	// 集装箱编号
	String ZX_CONTAINER = "ZX_CONTAINER";

	String ZPAKORD = "ZPAKORD";

	String ZLABORD = "ZLABORD";

	String ZX_3PL_INV = "ZX_3PL_INV";

	// 配送类型 固定值：0 确定送货上门
	String DN_DELIVERY_TYPE = "0";

	// 参考单据号（销售订单号）
	String VGBEL = "VGBEL";

	// 参考单据行号（销售订单行号）
	String VGPOS = "VGPOS";

	// 序列号（车辆接口必填）
	String SERNR = "SERNR";

	// SAP 单据类型
	String LFART = "LFART";

	// Sku删除标识
	String C = "C";

	// DN 计划数量
	String LFIMG = "LFIMG";

	// DN 计量单位
	String MEINS = "MEINS";

	// SAP采购类型
	String BSART = "BSART";

	String Success = "Success";

	Integer Success_Code = 200;

	Integer Faild_Code = 400;

	String Failure = "Failure";

	// SAP合作伙伴功能-固定WE
	String WE = "WE";

	// 日期过滤
	String DATE = "--";

	// 仓库代码
	String WAREHOUSE_CODE = "10";

	// CHERY客户Asn源订单号
	String ASN_ORDER = "asnOrder";

	// OMS固定单位 PCS
	String PCS_UNIT = "PCS";

}
