package com.herdsric.oms.chery.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author tyy
 * @createDate 2025/1/16 16:36
 */
@Data
public class DnItKunnrDto {

	@NotBlank(message = "送达方/售达方名称,不能为空")
	@Schema(description = "送达方/售达方名称")
	@JsonProperty("NAME1")
	private String name1;

	@NotBlank(message = "送达方/售达方代码,不能为空")
	@Schema(description = "送达方/售达方代码")
	@JsonProperty("KUNNR")
	private String kunnr;

	@NotBlank(message = "送达方/售达方地址,不能为空")
	@Schema(description = "送达方/售达方地址")
	@JsonProperty("STRAS")
	private String stras;

	@NotBlank(message = "送达方/售达方城市,不能为空")
	@Schema(description = "送达方/售达方城市")
	@JsonProperty("ORT01")
	private String ort01;

	@Schema(description = "送达方/售达方邮政编码")
	@JsonProperty("PSTLZ")
	private String pstlz;

	@NotBlank(message = "送达方/售达方国家代码,不能为空")
	@Schema(description = "送达方/售达方国家代码")
	@JsonProperty("LAND1")
	private String land1;

	@Schema(description = "SAP 合作伙伴功能（WE: 送达方, AG: 售达方）")
	@JsonProperty("PARVW")
	private String parvw;

}
