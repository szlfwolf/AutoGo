package com.herdsric.oms.chery.dto;

import cn.hutool.core.util.StrUtil;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.herdsric.oms.chery.common.CheryConstant;
import com.herdsric.oms.chery.enums.ShipTypeEnum;
import com.herdsric.oms.chery.util.TimeUtils;
import com.herdsric.oms.common.client.asn.domain.AsnOrderDm;
import com.herdsric.oms.common.client.asn.domain.AsnOrderLineDm;
import com.herdsric.oms.common.core.util.JsonMapper;
import com.herdsric.oms.common.core.validation.RegexpConstants;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author tyy
 * @createDate 2025/1/16 15:26
 */
@Data
@Slf4j
public class AsnOrderDto {

	@Valid
	@NotNull(message = "Asn 采购订单条目列表,不能为空")
	@JsonProperty("IT_TAB")
	private List<ItTabDto> itTab;

	/***
	 * 基础效验方法
	 */
	public void check() {
		// 只支持单条数据下发
		if (itTab.size() > 1) {
			throw new RuntimeException("Asn 采购不支持批量下单");
		}

		ItTabDto itTabDto = itTab.get(0);

		if (!StrUtil.equals(itTabDto.getBsart(), CheryConstant.ASN_ORDER_TYPE)) {
			throw new RuntimeException("Asn 采购订单条目列表,入库类型不正确");
		}

		// 效验partnumber加lineno唯一
		HashMap<String, String> map = new HashMap<>();
		itTabDto.getItem().forEach(item -> {
			if (map.containsKey(itTabDto.getEbeln() + item.getEbelp())) {
				throw new RuntimeException(StrUtil.format("Asn 采购订单条目列表,采购订单行号:{} 重复", item.getEbelp()));
			}
			map.put(itTabDto.getEbeln() + item.getEbelp(), null);
		});

		// AsnItemDto asnItemDto = itTabDto.getItem().get(0);
		//
		// // 判断时间格式是否正确
		// if (StrUtil.isNotBlank(asnItemDto.getZEta()) &&
		// !asnItemDto.getZEta().matches(RegexpConstants.YYYYMMDD)) {
		// throw new RuntimeException(StrUtil.format("预计到达时间:{},格式不正确",
		// asnItemDto.getZEta()));
		// }
	}

	public AsnOrderDm convert(AsnOrderDto asnOrderDto) {
		// 客户下发过来的入参
		ItTabDto asnOrder = asnOrderDto.getItTab().get(0);
		AsnItemDto asnItemDto = asnOrder.getItem().get(0);
		log.info("客户:chery,下发Asn订单入参为:{}", JsonMapper.INSTANCE.toJson(asnOrder));

		AsnOrderDm asnOrderDm = new AsnOrderDm();

		Map<String, Object> extendProps = new HashMap<>();

		List<AsnOrderLineDm> asnOrderLineList = new ArrayList<>();

		// 默认只有一种入库类型, ZCRK正常入库
		// 入库类型
		asnOrderDm.setOrderType("ZCRK");
		asnOrderDm.setOrderNo(asnOrder.getEbeln());
		asnOrderDm.setWarehouseCode(CheryConstant.WAREHOUSE_CODE);
		// 运输类型映射
		asnOrderDm.setShipType(ShipTypeEnum.getValueByKey(asnItemDto.getZtransType()));
		asnOrderDm.setCarrier(asnItemDto.getZshpNam());
		asnOrderDm.setDestination(asnItemDto.getZendDest());
		asnOrderDm.setInvoiceNum(asnOrder.getZx3PlInv());
		asnOrderDm.setPostDischarge(asnItemDto.getZendDest());
		asnOrderDm.setEtaTime(TimeUtils.getDateTimeInFullFormat(asnItemDto.getZEta()));
		asnOrderDm.setSupplierCode(asnOrder.getName1());

		asnOrder.getItem().forEach(item -> {
			AsnOrderLineDm asnOrderLine = new AsnOrderLineDm();
			Map<String, Object> extendLineProps = new HashMap<>();

			// todo 暂时不转换
			// item.setMeins(ConvertUntilEnum.EA.value);

			asnOrderLine.setLineNo(item.getEbelp());
			asnOrderLine.setPartNumber(item.getMatnr());
			asnOrderLine.setQty(item.getMenge());
			// 默认单位为PCS, 客户单位存入扩展字段
			asnOrderLine.setUnit(CheryConstant.PCS_UNIT);
			asnOrderLine.setVin(item.getSernr());
			asnOrderLine.setContainerNo(item.getZContainer());

			// 存入扩展字段数据
			extendLineProps.put(CheryConstant.LGORT, item.getLgort());
			extendLineProps.put(CheryConstant.ZX_CONTAINER, item.getZxContainer());
			extendLineProps.put(CheryConstant.ZPAKORD, item.getZpakord());
			extendLineProps.put(CheryConstant.ZLABORD, item.getZlabord());
			extendLineProps.put(CheryConstant.MEINS, item.getMeins());

			asnOrderLine.setExtendProps(extendLineProps);

			asnOrderLineList.add(asnOrderLine);
		});

		extendProps.put(CheryConstant.WERKS, asnOrder.getWerks());
		extendProps.put(CheryConstant.ZX_3PL_INV, asnOrder.getZx3PlInv());
		extendProps.put(CheryConstant.BSART, asnOrder.getBsart());
		extendProps.put(CheryConstant.ASN_ORDER, asnOrder.getEbeln());

		asnOrderDm.setExtendProps(extendProps);
		asnOrderDm.setOrderLines(asnOrderLineList);

		return asnOrderDm;
	}

}
