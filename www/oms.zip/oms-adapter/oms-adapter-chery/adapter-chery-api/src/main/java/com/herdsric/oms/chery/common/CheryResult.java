
package com.herdsric.oms.chery.common;

import com.herdsric.oms.common.core.constant.CommonConstants;
import com.herdsric.oms.common.core.util.R;
import lombok.Data;

/**
 * <p>
 * NIO ASN
 * </p>
 *
 * @author zcl
 */
@Data
public class CheryResult {

	public static CheryResult ok() {
		return restResult(CheryConstant.Success, CheryConstant.Success_Code, CheryConstant.Success);
	}

	public static CheryResult faild(String message) {
		return restResult(CheryConstant.Failure, CheryConstant.Faild_Code, message);
	}

	public static CheryResult restResult(String result, int code, String message) {
		CheryResult apiResult = new CheryResult();
		apiResult.setCode(code);
		apiResult.setMessage(message);
		apiResult.setResult(result);
		return apiResult;
	}

	private Integer code;

	private String message;

	private String result;

}
