package com.herdsric.oms.chery.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

/**
 * @author tyy
 * @createDate 2025/1/20 16:55
 */
@Data
public class StockResponseDto {

	@JsonProperty("IT_ITEM")
	private List<StockItItemResponseDto> itItem;

}
