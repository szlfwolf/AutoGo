package com.herdsric.oms.chery.manages;

import cn.hutool.core.bean.BeanUtil;
import com.herdsric.oms.chery.common.CheryConstant;
import com.herdsric.oms.chery.dto.response.AsnItItemResponseDto;
import com.herdsric.oms.chery.dto.response.AsnItemResponseDto;
import com.herdsric.oms.chery.dto.response.AsnOrderResponseDto;
import com.herdsric.oms.chery.util.TimeUtils;
import com.herdsric.oms.common.client.asn.AsnBizDefine;
import com.herdsric.oms.common.client.asn.domain.*;
import com.herdsric.oms.common.client.asn.dto.AsnOrderResponseDTO;
import com.herdsric.oms.common.client.asn.function.AsnOptionFlag;
import com.herdsric.oms.common.client.asn.process.AsnProcessor;
import com.herdsric.oms.common.client.enums.SyncEnum;
import com.herdsric.oms.common.core.util.JsonMapper;
import com.herdsric.oms.common.core.util.SpringContextHolder;
import com.herdsric.oms.common.webhook.CallbackHttpDefine;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

@Slf4j
@RequiredArgsConstructor
public class AsnOrderManage extends CommonDefine implements AsnBizDefine {

	@Override
	public void save(AsnDm asnDm) {

	}

	@Override
	public boolean asnResponseByWebhook(String url, AsnDm asnDm) {
		return false;
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public void save(AsnOrderDm asnOrderDm) {
		log.info("处理客户下发的ASNOrder,当前单号:" + asnOrderDm.getOrderNo());

		AsnProcessor asnProcessor = SpringContextHolder.getBean(AsnProcessor.class);

		asnProcessor.addAsnOrder(asnOrderDm);

	}

	@Override
	public void asnOrderResponseByWebhook(String clientCode, String type, String orderNo) {
		AsnProcessor asnProcessor = SpringContextHolder.getBean(AsnProcessor.class);
		Function<AsnOptionFlag, Function<AsnOrderResponseDTO, Boolean>> function = x -> {
			switch (x) {
				case Manual:
					return dm -> {
						log.info("{},AsnOrder:{}, 手动上传订单，不需要反馈", clientCode, orderNo);
						return false;
					};
				case Responsed:
					return dm -> {
						CallbackHttpDefine callbackHttpDefine = SpringContextHolder.getBean(CallbackHttpDefine.class);

						// 进行封装Asn反馈参数
						AsnOrderResponseDto asnOrderResponseDto = convertAsnResponsed(dm);

						callbackHttpDefine.execute(true, clientCode, dm.getWarehouseCode(), dm.getOrderNo(),
								asnOrderResponseDto, SyncEnum.ASN_ORDER_RESPONSED_SYNC.name(), true);

						return true;
					};
				case Closed:
					return dm -> {
						log.info("{},AsnOrder:{}, 关闭订单，执行关闭逻辑......", clientCode, orderNo);

						return true;
					};
				default:
					return dm -> {
						// 其他情况不需要反馈
						return true;
					};
			}
		};
		asnProcessor.asnOrderResponse(clientCode, type, orderNo, function);
	}

	private AsnOrderResponseDto convertAsnResponsed(AsnOrderResponseDTO dm) {

		AsnOrderResponseDto asnOrderResponseDto = new AsnOrderResponseDto();
		List<AsnItItemResponseDto> asnItItemResponseList = new ArrayList<>();
		AsnItItemResponseDto asnItItemResponse = new AsnItItemResponseDto();
		List<AsnItemResponseDto> asnItemResponseDtoList = new ArrayList<>();

		List<AsnOrderResponseLineDm> orderLines = dm.getOrderLines();

		asnItItemResponse.setEbeln(dm.getValue(CheryConstant.ASN_ORDER, String.class));
		asnItItemResponse.setZx3plInv(dm.getValue(CheryConstant.ZX_3PL_INV, String.class));

		for (AsnOrderResponseLineDm orderLine : orderLines) {
			AsnItemResponseDto asnItemResponseDto = new AsnItemResponseDto();
			asnItemResponseDto.setEbelp(orderLine.getLineNo());
			asnItemResponseDto.setMatnr(orderLine.getPartNumber());
			asnItemResponseDto.setMenge(String.valueOf(orderLine.getQty()));
			asnItemResponseDto.setMeins(orderLine.getValue(CheryConstant.MEINS, String.class));
			asnItemResponseDto.setLgort(orderLine.getValue(CheryConstant.LGORT, String.class));
			asnItemResponseDto.setCharg(orderLine.getBatchNo());
			asnItemResponseDto.setZpakord(orderLine.getValue(CheryConstant.ZPAKORD, String.class));
			asnItemResponseDto.setZlabord(orderLine.getValue(CheryConstant.ZLABORD, String.class));
			asnItemResponseDto.setSernr(orderLine.getVin());
			asnItemResponseDto.setZxContainer(dm.getValue(CheryConstant.ZX_CONTAINER, String.class));

			asnItemResponseDtoList.add(asnItemResponseDto);
		}

		// todo 目前只有一种类型
		asnItItemResponse.setBsart(dm.getValue(CheryConstant.BSART, String.class));
		asnItItemResponse.setWerks(dm.getValue(CheryConstant.WERKS, String.class));
		asnItItemResponse.setZcDate(TimeUtils.convertDateYYYYMMDD(dm.getOperateTime()));
		asnItItemResponse.setZcTime(TimeUtils.convertDateTimeHHmmss(dm.getOperateTime()));
		asnItItemResponse.setZcDate1(TimeUtils.convertDateYYYYMMDD(dm.getOperateTime()));

		asnItItemResponse.setItem(asnItemResponseDtoList);

		asnItItemResponseList.add(asnItItemResponse);

		asnOrderResponseDto.setItItem(asnItItemResponseList);

		return asnOrderResponseDto;
	}

}
