package com.herdsric.oms.chery.util;

import cn.hutool.core.util.ObjectUtil;
import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * @author tyy
 * @createDate 2024/9/5 14:55
 */
@Slf4j
public class CommonUtil {

	/**
	 * 毫米转换成厘米
	 * @param mm
	 * @return
	 */
	public static String mmConvertToCm(BigDecimal mm) {
		try {
			if (ObjectUtil.isEmpty(mm)) {
				return "0";
			}
			// 将毫米值除以 10 转换为厘米
			BigDecimal cm = mm.divide(new BigDecimal("10"), 2, RoundingMode.HALF_UP);
			// 格式化为字符串
			return cm.stripTrailingZeros().toPlainString();
		}
		catch (Exception e) {
			log.error("Error:", e);
			return "0";
		}
	}

	/***
	 * 厘米转换成毫米
	 * @param cm
	 * @return
	 */
	public static String convertLaengToMm(String cm) {
		try {
			double cmValue = Double.parseDouble(cm);
			double mmValue = cmValue * 10;
			return String.valueOf(mmValue);
		}
		catch (NumberFormatException e) {
			// Handle the case where laeng is not a valid number
			return "Invalid value";
		}
	}

}
