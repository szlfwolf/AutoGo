package com.herdsric.oms.chery.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * @author tyy
 * @createDate 2025/1/16 11:56
 */
@Data
public class ItItemDto {

	@JsonProperty("NUMRANGE")
	private String numRange;

	@Schema(description = "物料编号")
	@NotEmpty(message = "物料编号,不能为空")
	@JsonProperty("MATNR")
	private String matnr;

	@Schema(description = "物料类型（FERT: 成品, HALB: 半成品, ROA: 原材料)")
	@NotEmpty(message = "物料类型不能为空 ")
	@JsonProperty("MTART")
	private String mtart;

	/***
	 * EMP 暂时只支持PCS
	 */
	@Schema(description = "计量单位（EA: 件, KG: 千克, CM: 厘米, L: 升）")
	@NotEmpty(message = "计量单位,不能为空")
	@JsonProperty("MEINS")
	private String meins;

	@Schema(description = "物料描述")
	@NotNull(message = "物料描述,不能为空")
	@JsonProperty("IT_MAKTX")
	private List<ItMaktxDto> itMaktx;

	@Schema(description = "毛重")
	@JsonProperty("BRGEW")
	private String brgew;

	@Schema(description = "净重")
	@JsonProperty("NTGEW")
	private String ntgew;

	@Schema(description = "重量单位")
	@JsonProperty("GEWEI")
	private String gewei;

	@Schema(description = "长度")
	@JsonProperty("LAENG")
	private String laeng;

	@Schema(description = "宽度")
	@JsonProperty("BREIT")
	private String breit;

	@Schema(description = "高度")
	@JsonProperty("HOEHE")
	private String hoehe;

	@Schema(description = "尺寸单位")
	@JsonProperty("MEABM")
	private String meabm;

	@Schema(description = "尺寸（长宽高）")
	@JsonProperty("GROES")
	private String groes;

	@NotEmpty(message = "SAP 工厂代码,不能为空")
	@Schema(description = "SAP 工厂代码")
	@JsonProperty("WERKS")
	private String werks;

	@Schema(description = "物料删除指示（X: 已删除, 空：未删除）")
	@JsonProperty("LVORM")
	private String lvorm;

	@Schema(description = "批次管理指示（X: 激活批次管理）")
	@JsonProperty("XCHAR")
	private String xchar;

}
