package com.herdsric.oms.chery.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.List;

/**
 * @author tyy
 * @createDate 2025/1/20 14:34
 */
@Data
public class DnItItemResponseDto {

	@Schema(description = "交货单号")
	@JsonProperty("VBELN")
	private String vbeln;

	@Schema(description = "SAP 单据类型")
	@JsonProperty("LFART")
	private String lfart;

	@Schema(description = "SAP 工厂代码")
	@JsonProperty("WERKS")
	private String werks;

	@Schema(description = "货件编号（由第三方物流生成）")
	@JsonProperty("ZSHIPNUM")
	private String zShipNum;

	@Schema(description = "出库日期（格式：YYYYMMDD）")
	@JsonProperty("ZCDATE")
	private String zcDate;

	@Schema(description = "出库时间（格式：HHMMSS）")
	@JsonProperty("ZCTIME")
	private String zcTime;

	@Schema(description = "预留字段")
	@JsonProperty("ZNUM1")
	private String zNum1;

	@Schema(description = "预留字段")
	@JsonProperty("ZNUM2")
	private String zNum2;

	@Schema(description = "预留字段")
	@JsonProperty("ZNUM3")
	private String zNum3;

	@Schema(description = "预留字段")
	@JsonProperty("ZTEXT1")
	private String zText1;

	@Schema(description = "预留字段")
	@JsonProperty("ZTEXT2")
	private String zText2;

	@Schema(description = "预留字段")
	@JsonProperty("ZTEXT3")
	private String zText3;

	@Schema(description = "预留字段")
	@JsonProperty("ZTEXT4")
	private String zText4;

	@Schema(description = "预留字段")
	@JsonProperty("ZTEXT5")
	private String zText5;

	@Schema(description = "交货单行项目列表")
	@JsonProperty("ITEM")
	private List<DnItemResponseDto> item;

}
