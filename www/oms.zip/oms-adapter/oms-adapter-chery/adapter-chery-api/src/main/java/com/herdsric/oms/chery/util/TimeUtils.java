package com.herdsric.oms.chery.util;

import cn.hutool.core.util.StrUtil;
import com.herdsric.oms.chery.common.CheryConstant;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

/**
 * @Description: 数据工具
 * @author: Dzx
 * @date: 2022.11.01
 */
@Slf4j
public class TimeUtils {

	/**
	 * 时间转换
	 * @param dateTime
	 * @return
	 */
	public static String convertDateYYYYMMDD(String dateTime) {
		if (dateTime == null || dateTime.isEmpty()) {
			return null; // 或者返回一个默认值
		}

		DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("yyyyMMdd");

		try {
			LocalDateTime dateTimeObj = LocalDateTime.parse(dateTime, inputFormatter);
			return dateTimeObj.format(outputFormatter);
		}
		catch (DateTimeParseException e) {
			throw new RuntimeException("日期格式不正确");
		}
	}

	/**
	 * 时间转换
	 * @param dateTime
	 * @return
	 */
	public static String convertDateTimeHHmmss(String dateTime) {
		if (dateTime == null || dateTime.isEmpty()) {
			return null; // 或者返回一个默认值
		}

		DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("HHmmss");

		try {
			LocalDateTime dateTimeObj = LocalDateTime.parse(dateTime, inputFormatter);
			return dateTimeObj.format(outputFormatter);
		}
		catch (DateTimeParseException e) {
			throw new RuntimeException("日期格式不正确");
		}
	}

	public static void main(String[] args) {
		System.out.println(getCurrentDateHHMMSS()); // 输出: 094426
	}

	public static String getCurrentDateYYYYMMDD() {
		LocalDate currentDate = LocalDate.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
		return currentDate.format(formatter);
	}

	// 将 DateTimeFormatter 定义为静态常量以提高性能
	private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("HHmmss");

	public static String getCurrentDateHHMMSS() {
		// 使用 LocalDateTime 来获取当前日期和时间
		LocalDateTime currentDateTime = LocalDateTime.now();
		return currentDateTime.format(FORMATTER);
	}

	public static String getDateTimeInFullFormat(String dateTime) {
		if (StrUtil.isBlank(dateTime) || StrUtil.equals(CheryConstant.DATE, dateTime)) {
			return null; // 或者返回一个默认值
		}

		DateTimeFormatter inputFormatter1 = DateTimeFormatter.ofPattern("yyyyMMdd");
		DateTimeFormatter inputFormatter2 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

		try {
			LocalDate date;
			if (dateTime.contains("-")) {
				date = LocalDate.parse(dateTime, inputFormatter2);
			}
			else {
				date = LocalDate.parse(dateTime, inputFormatter1);
			}
			LocalDateTime dateTimeWithTime = date.atStartOfDay(); // 设置时间为当天的开始时间 00:00:00
			return dateTimeWithTime.format(outputFormatter);
		}
		catch (DateTimeParseException e) {
			throw new RuntimeException("日期格式不正确");
		}
	}

}
