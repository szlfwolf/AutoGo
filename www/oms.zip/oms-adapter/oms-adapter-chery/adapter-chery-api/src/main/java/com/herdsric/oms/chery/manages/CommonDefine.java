package com.herdsric.oms.chery.manages;

import cn.hutool.core.util.StrUtil;
import com.herdsric.oms.chery.common.CheryConstant;
import com.herdsric.oms.common.client.common.BaseDefine;

public class CommonDefine implements BaseDefine {

	@Override
	public boolean isSupport(String clientCode) {
		return StrUtil.equals(CheryConstant.CLIENT_CODE, clientCode);
	}

}
