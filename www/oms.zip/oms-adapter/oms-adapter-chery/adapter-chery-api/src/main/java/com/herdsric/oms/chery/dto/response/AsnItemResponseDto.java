package com.herdsric.oms.chery.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * @author tyy
 * @createDate 2025/1/17 17:52
 */
@Data
public class AsnItemResponseDto {

	@Schema(description = "采购订单行号")
	@JsonProperty("EBELP")
	private String ebelp;

	@Schema(description = "物料编号")
	@JsonProperty("MATNR")
	private String matnr;

	@Schema(description = "计划交货数量")
	@JsonProperty("MENGE")
	private String menge;

	@Schema(description = "计量单位（EA: 件）")
	@JsonProperty("MEINS")
	private String meins;

	@Schema(description = "SAP 存储位置")
	@JsonProperty("LGORT")
	private String lgort;

	@Schema(description = "SAP 存储位置")
	@JsonProperty("CHARG")
	private String charg;

	@Schema(description = "装箱单中的订单号")
	@JsonProperty("ZPAKORD")
	private String zpakord;

	@Schema(description = "标签中的订单编号")
	@JsonProperty("ZLABORD")
	private String zlabord;

	@Schema(description = "检验标识")
	@JsonProperty("INSMK")
	private String insmk;

	@Schema(description = "车辆 VIN 码")
	@JsonProperty("SERNR")
	private String sernr;

	@Schema(description = "集装箱编号")
	@JsonProperty("ZX_CONTAINER")
	private String zxContainer;

}
