package com.herdsric.oms.chery.enums;

import com.herdsric.oms.common.core.validation.EnumValidator;
import org.apache.commons.lang3.StringUtils;

/**
 * @author 王涛
 */

public enum ConvertUntilEnum implements EnumValidator {

	EA("EA", "PCS");

	public String key;

	public String value;

	ConvertUntilEnum(String value, String key) {
		this.value = value;
		this.key = key;
	}

	@Override
	public Object getValue() {
		return this.value;
	}

	/**
	 * 根据key获取value
	 * @param key
	 * @return
	 */
	public static String getValueByKey(String key) {
		if (StringUtils.isEmpty(key)) {
			return null;
		}
		for (ConvertUntilEnum enums : ConvertUntilEnum.values()) {
			if (enums.key.equals(key)) {
				return enums.value;
			}
		}

		return null;
	}

	/**
	 * 根据value获取key
	 * @param value
	 * @return
	 */
	public static String getKeyByValue(String value) {
		if (StringUtils.isEmpty(value)) {
			return null;
		}
		for (ConvertUntilEnum enums : ConvertUntilEnum.values()) {
			if (enums.value.equals(value)) {
				return enums.key;
			}
		}

		return null;
	}

}
