package com.herdsric.oms.chery.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.herdsric.oms.common.core.validation.RegexpConstants;
import com.herdsric.oms.common.core.validation.constraints.PatternOrEmpty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

/**
 * @author tyy
 * @createDate 2025/1/16 15:31
 */
@Schema(title = "ASN条目")
@Data
public class AsnItemDto {

	@NotBlank(message = "采购订单行号,不能为空")
	@Schema(description = "采购订单行号")
	@JsonProperty("EBELP")
	private String ebelp;

	@NotBlank(message = "物料编号,不能为空")
	@Schema(description = "物料编号")
	@JsonProperty("MATNR")
	private String matnr;

	@NotBlank(message = "物料描述,不能为空")
	@Schema(description = "物料描述")
	@JsonProperty("MAKTX")
	private String maktx;

	@NotBlank(message = "计划交货数量,不能为空")
	@Schema(description = "计划交货数量")
	@JsonProperty("MENGE")
	private String menge;

	@NotBlank(message = "计量单位,不能为空")
	@Schema(description = "计量单位（EA: 件）")
	@JsonProperty("MEINS")
	private String meins;

	@NotBlank(message = "库存地点,不能为空")
	@Schema(description = "库存地点")
	@JsonProperty("LGORT")
	private String lgort;

	@Schema(description = "采购订单项删除指示（L: 删除）")
	@JsonProperty("LOEKZ")
	private String loekz;

	@Schema(description = "批号")
	@JsonProperty("CHARG")
	private String charg;

	@Schema(description = "车辆 VIN 码")
	@JsonProperty("SERNR")
	private String sernr;

	@Schema(description = "集装箱编号")
	@JsonProperty("ZX_CONTAINER")
	private String zxContainer;

	@Schema(description = "装箱单中的订单号")
	@JsonProperty("ZPAKORD")
	private String zpakord;

	@Schema(description = "标签中的订单编号")
	@JsonProperty("ZLABORD")
	private String zlabord;

	@Schema(description = "代码")
	@JsonProperty("ZCODE")
	private String zCode;

	@Schema(description = "品牌代码")
	@JsonProperty("ZBRANDCODE")
	private String zbRandCode;

	@Schema(description = "变速箱编码")
	@JsonProperty("ZTRANSMSN")
	private String ztRansmsn;

	@Schema(description = "产品类别代码")
	@JsonProperty("ZPRDCATCOD")
	private String zprdCatCod;

	@Schema(description = "运输类型")
	@JsonProperty("ZTRANSTYPE")
	private String ztransType;

	@Schema(description = "船名字")
	@JsonProperty("ZSHPNAM")
	private String zshpNam;

	@Schema(description = "实际出发日期")
	@JsonProperty("ZACTDPTDT")
	private String zactDptdt;

	@Schema(description = "出发港")
	@JsonProperty("ZSTARTDEST")
	private String zstartDest;

	@Schema(description = "目的港")
	@JsonProperty("ZENDDEST")
	private String zendDest;

	@PatternOrEmpty(regexp = RegexpConstants.YYYYMMDD, message = "采购订单创建日期输入有误,格式:yyyyMMdd")
	@Schema(description = "预计到达时间")
	@JsonProperty("ZETA")
	private String zEta;

	@Schema(description = "预计出发时间")
	@JsonProperty("ZETD")
	private String zEtd;

	@Schema(description = "集装箱号")
	@JsonProperty("ZCONTAINER")
	private String zContainer;

	@Schema(description = "经销商代码")
	@JsonProperty("ZDEALER")
	private String zDealer;

	@Schema(description = "预留字段1")
	@JsonProperty("ZLRSV1")
	private String zLrsv1;

	@Schema(description = "预留字段2")
	@JsonProperty("ZLRSV2")
	private String zLrsv2;

	@Schema(description = "预留字段3")
	@JsonProperty("ZLRSV3")
	private String zLrsv3;

	@Schema(description = "预留字段4")
	@JsonProperty("ZLRSV4")
	private String zLrsv4;

	@Schema(description = "预留字段5")
	@JsonProperty("ZLRSV5")
	private String zLrsv5;

	@Schema(description = "预留字段6")
	@JsonProperty("ZLRSV6")
	private String zLrsv6;

	@Schema(description = "预留字段7")
	@JsonProperty("ZLRSV7")
	private String zLrsv7;

	@Schema(description = "预留字段8")
	@JsonProperty("ZLRSV8")
	private String zLrsv8;

	@Schema(description = "预留字段9")
	@JsonProperty("ZLRSV9")
	private String zLrsv9;

}
