package com.herdsric.oms.chery.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotEmpty;

/**
 * @author tyy
 * @createDate 2025/1/16 11:50
 */
@Data
public class ItMaktxDto {

	@NotEmpty(message = "语言代码,不能为空")
	@Schema(description = "语言代码")
	@JsonProperty("SPRAS")
	private String spras;

	@NotEmpty(message = "物料描述,不能为空")
	@Schema(description = "物料描述")
	@JsonProperty("MAKTX")
	private String maktx;

}
