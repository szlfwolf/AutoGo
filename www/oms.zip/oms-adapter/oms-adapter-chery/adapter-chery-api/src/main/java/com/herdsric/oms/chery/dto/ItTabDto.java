package com.herdsric.oms.chery.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.herdsric.oms.common.core.validation.RegexpConstants;
import com.herdsric.oms.common.core.validation.constraints.PatternOrEmpty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.util.List;

/**
 * @author tyy
 * @createDate 2025/1/16 15:27
 */
@Data
public class ItTabDto {

	@JsonProperty("NUMRANGE")
	private String numrange;

	@NotBlank(message = "采购订单号不能为空")
	@Schema(description = "采购订单号")
	@JsonProperty("EBELN")
	private String ebeln;

	@Valid
	@NotNull(message = "Asn 采购订单行项目列表不能为空")
	@JsonProperty("ITEM")
	private List<AsnItemDto> item;

	@NotBlank(message = "工厂代码,不能为空")
	@Schema(description = "工厂代码")
	@JsonProperty("WERKS")
	private String werks;

	@NotBlank(message = "SAP 采购订单类型,不能为空")
	@Schema(description = "SAP 采购订单类型")
	@JsonProperty("BSART")
	private String bsart;

	@Schema(description = "SAP 交付日期")
	@JsonProperty("EINDT")
	private String eindt;

	@NotBlank(message = "供应商名称,不能为空")
	@Schema(description = "供应商名称")
	@JsonProperty("NAME1")
	private String name1;

	@NotBlank(message = "供应商地址,不能为空")
	@Schema(description = "供应商地址")
	@JsonProperty("STRAS")
	private String stras;

	@Schema(description = "采购订单创建日期")
	@JsonProperty("AEDAT")
	private String aedat;

	@Schema(description = "公司代码")
	@JsonProperty("BUKRS")
	private String bukrs;

	@NotBlank(message = "供应商城市,不能为空")
	@Schema(description = "供应商城市")
	@JsonProperty("ORT01")
	private String orto1;

	@Schema(description = "省份")
	@JsonProperty("BEZEI")
	private String bezei;

	@NotBlank(message = "供应商邮政编码,不能为空")
	@Schema(description = "供应商邮政编码")
	@JsonProperty("PSTLZ")
	private String pstlz;

	@NotBlank(message = "供应商国家,不能为空")
	@Schema(description = "供应商国家")
	@JsonProperty("LAND1")
	private String land1;

	@NotBlank(message = "商业发票号码,不能为空")
	@Schema(description = "商业发票号码")
	@JsonProperty("ZX_3PL_INV")
	private String zx3PlInv;

	@Schema(description = "预留字段")
	@JsonProperty("ZTEXT1")
	private String ztext1;

	@Schema(description = "预留字段")
	@JsonProperty("ZTEXT2")
	private String ztext2;

	@Schema(description = "预留字段")
	@JsonProperty("ZTEXT3")
	private String ztext3;

	@Schema(description = "预留字段")
	@JsonProperty("ZTEXT4")
	private String ztext4;

	@Schema(description = "预留字段")
	@JsonProperty("ZTEXT5")
	private String ztext5;

}
