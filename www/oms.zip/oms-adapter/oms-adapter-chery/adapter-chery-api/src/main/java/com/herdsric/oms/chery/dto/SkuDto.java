package com.herdsric.oms.chery.dto;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.StrUtil;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.herdsric.oms.chery.common.CheryConstant;
import com.herdsric.oms.chery.util.CommonUtil;
import com.herdsric.oms.common.client.masterdata.domain.SkuDm;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author tyy
 * @createDate 2025/1/16 11:15
 */
@Data
public class SkuDto {

	@NotNull(message = "物料主数据条目列表")
	@Valid
	@JsonProperty("IT_ITEM")
	private List<ItItemDto> itItem;

	public static List<SkuDm> convert(SkuDto skuDto) {
		List<SkuDm> skuDmList = new ArrayList<>();
		for (ItItemDto itItemDto : skuDto.getItItem()) {
			Map<String, Object> extendProps = new HashMap<>();
			SkuDm skuDm = new SkuDm();
			skuDm.setBrand(CheryConstant.CLIENT_CODE);
			skuDm.setSupplierCode(CheryConstant.CLIENT_CODE);
			skuDm.setSupplierName(CheryConstant.CLIENT_CODE);
			skuDm.setPartNumber(itItemDto.getMatnr());

			List<ItMaktxDto> itMakts = itItemDto.getItMaktx().stream()
					.filter(x -> StrUtil.equals(x.getSpras(), CheryConstant.EN)).collect(Collectors.toList());

			skuDm.setNameCn(CollectionUtil.isNotEmpty(itMakts) ? itMakts.get(0).getMaktx()
					: itItemDto.getItMaktx().get(0).getMaktx());
			skuDm.setNameEn(CollectionUtil.isNotEmpty(itMakts) ? itMakts.get(0).getMaktx()
					: itItemDto.getItMaktx().get(0).getMaktx());
			skuDm.setPartDesc(CollectionUtil.isNotEmpty(itMakts) ? itMakts.get(0).getMaktx()
					: itItemDto.getItMaktx().get(0).getMaktx());

			skuDm.setStatus(
					(StrUtil.isNotBlank(itItemDto.getLvorm()) && StrUtil.equalsIgnoreCase("X", itItemDto.getLvorm()))
							? CheryConstant.C : null);

			SkuDm.PackageUnit packageUnit = new SkuDm.PackageUnit();
			packageUnit.setType(CheryConstant.Package_Type);
			// 如果为空则设置默认值0
			// TODO 转换单位 cm->mm kg->kg
			packageUnit.setLength(
					StrUtil.isNotBlank(itItemDto.getLaeng()) ? CommonUtil.convertLaengToMm(itItemDto.getLaeng()) : "0");
			packageUnit.setWidth(
					StrUtil.isNotBlank(itItemDto.getBreit()) ? CommonUtil.convertLaengToMm(itItemDto.getBreit()) : "0");
			packageUnit.setHeight(
					StrUtil.isNotBlank(itItemDto.getHoehe()) ? CommonUtil.convertLaengToMm(itItemDto.getHoehe()) : "0");

			packageUnit.setGrossWeight(StrUtil.isNotBlank(itItemDto.getBrgew()) ? itItemDto.getBrgew() : "0");
			packageUnit.setNetWeight(StrUtil.isNotBlank(itItemDto.getNtgew()) ? itItemDto.getNtgew() : "0");

			extendProps.put(CheryConstant.MEINS, itItemDto.getMeins());
			// EMP 暂时只支持PCS
			// itItemDto.setMeins(ConvertUntilEnum.EA.key);
			packageUnit.setUnit(itItemDto.getMeins());
			packageUnit.setMoq(CheryConstant.Package_Moq);

			extendProps.put(CheryConstant.NUMRANGE, itItemDto.getNumRange());
			extendProps.put(CheryConstant.NUMRANGE, itItemDto.getNumRange());
			extendProps.put(CheryConstant.WERKS, itItemDto.getWerks());
			extendProps.put(CheryConstant.LVORM, itItemDto.getLvorm());
			packageUnit.setExtendProps(extendProps);

			skuDm.setPackageList(Arrays.asList(packageUnit));

			skuDm.setExtendProps(extendProps);

			skuDmList.add(skuDm);
		}

		return skuDmList;
	}

	public void check() {

		Map<String, List<ItItemDto>> groupMatnr = this.itItem.stream()
				.collect(Collectors.groupingBy(x -> x.getMatnr()));

		if (groupMatnr.size() != this.itItem.size()) {
			throw new RuntimeException("物料主数据条目列表,物料编码不能重复");
		}

	}

}
