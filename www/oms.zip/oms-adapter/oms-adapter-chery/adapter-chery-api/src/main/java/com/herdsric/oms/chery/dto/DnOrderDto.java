package com.herdsric.oms.chery.dto;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.StrUtil;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.herdsric.oms.chery.common.CheryConstant;
import com.herdsric.oms.chery.util.TimeUtils;
import com.herdsric.oms.common.client.dn.domain.DnOrderDm;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author tyy
 * @createDate 2025/1/16 16:32
 */
@Data
public class DnOrderDto {

	@NotNull(message = "头列表不能为空")
	@Valid
	@JsonProperty("IT_ITEM")
	private List<DnItItemDto> itItem;

	/***
	 * 基础数据效验
	 */
	public void check() {

		// 只支持单条数据下发
		if (this.itItem.size() > 1) {
			throw new RuntimeException("Dn 交货不支持批量下单");
		}

		DnItItemDto dnItItemDto = this.itItem.get(0);

		// 效验partnumber加lineno唯一
		HashMap<String, String> map = new HashMap<>();
		dnItItemDto.getItem().forEach(item -> {
			if (map.containsKey(dnItItemDto.getVbeln() + item.getPosnr())) {
				throw new RuntimeException(StrUtil.format("Dn 交货单行项目列表,交货单行项目号:{} 重复", item.getPosnr()));
			}
			map.put(dnItItemDto.getVbeln() + item.getPosnr(), null);
		});

		List<DnItKunnrDto> parvw = dnItItemDto.getIT_KUNNR().stream().filter(
				itkun -> StrUtil.isNotBlank(itkun.getParvw()) && StrUtil.equals(CheryConstant.WE, itkun.getParvw()))
				.collect(Collectors.toList());

		if (CollectionUtil.isEmpty(parvw)) {
			throw new RuntimeException("SAP 合作伙伴字段(PARVW),填写异常,缺少固定值:WE");
		}

	}

	public DnOrderDm convert(DnOrderDto dnOrderDto) {
		DnOrderDm dnOrderDm = new DnOrderDm();
		List<DnOrderDm.OrderLine> orderLines = new ArrayList<>();
		Map<String, Object> extendProps = new HashMap<>();

		// 只支持单条数据下发
		DnItItemDto dnItItemDto = dnOrderDto.getItItem().get(0);

		// 封装收件人信息
		for (DnItKunnrDto dnItKunnrDto : dnItItemDto.getIT_KUNNR()) {
			// 合作伙伴类型为WE时，表示收货人信息
			if (StrUtil.equals(dnItKunnrDto.getParvw(), CheryConstant.WE)) {
				dnOrderDm.setCountryCode(dnItKunnrDto.getLand1());
				dnOrderDm.setCityCode(dnItKunnrDto.getOrt01());
				dnOrderDm.setAddress(dnItKunnrDto.getStras());
				dnOrderDm.setZipCode(dnItKunnrDto.getPstlz());
				dnOrderDm.setContactName(dnItKunnrDto.getName1());
				break;
			}
		}

		dnOrderDm.setWarehouseCode(CheryConstant.WAREHOUSE_CODE);
		dnOrderDm.setOrderType(dnItItemDto.getLfart());
		dnOrderDm.setOrderNo(dnItItemDto.getVbeln());

		dnOrderDm.setContactCompany(CheryConstant.CLIENT_CODE);

		// todo 待确认
		dnOrderDm.setContactPhone("+31630403516");
		dnOrderDm.setContactEmail("dwayne.belfor@omodaauto.nl");

		// LocalDateTime thisDate = LocalDateTime.now();
		// DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd
		// HH:mm:ss");
		// String formattedDate = thisDate.format(formatter);

		dnOrderDm.setDeliveryType(CheryConstant.DN_DELIVERY_TYPE);
		dnOrderDm.setDnDate(StrUtil.isNotBlank(dnItItemDto.getWadatIst())
				? TimeUtils.getDateTimeInFullFormat(dnItItemDto.getWadatIst()) : null);

		for (DnItemDto dnItemDto : dnItItemDto.getItem()) {
			DnOrderDm.OrderLine orderLine = new DnOrderDm.OrderLine();
			Map<String, Object> extendLineProps = new HashMap<>();

			orderLine.setLineNo(dnItemDto.getPosnr());
			orderLine.setPartNumber(dnItemDto.getMatnr());
			orderLine.setQty(Double.valueOf(dnItemDto.getLfimg()));
			// 默认使用固定单位,客户下发单位存入扩展字段
			orderLine.setUnit(CheryConstant.PCS_UNIT);
			orderLine.setVin(dnItemDto.getSernr());

			extendLineProps.put(CheryConstant.LGORT, dnItemDto.getLgort());
			extendLineProps.put(CheryConstant.VGBEL, dnItemDto.getVgbel());
			extendLineProps.put(CheryConstant.VGPOS, dnItemDto.getVgpos());
			extendLineProps.put(CheryConstant.SERNR, dnItemDto.getSernr());
			extendLineProps.put(CheryConstant.LFIMG, dnItemDto.getLfimg());
			extendLineProps.put(CheryConstant.MEINS, dnItemDto.getMeins());

			orderLine.setExtendProps(extendLineProps);

			orderLines.add(orderLine);
		}

		extendProps.put(CheryConstant.WERKS, dnItItemDto.getWerks());
		extendProps.put(CheryConstant.LFART, dnItItemDto.getLfart());

		dnOrderDm.setExtendProps(extendProps);
		dnOrderDm.setOrderLines(orderLines);
		return dnOrderDm;
	}

}
