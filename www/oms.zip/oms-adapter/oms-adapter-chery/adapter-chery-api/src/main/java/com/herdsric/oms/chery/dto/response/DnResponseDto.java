package com.herdsric.oms.chery.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.List;

/**
 * @author tyy
 * @createDate 2025/1/20 14:33
 */
@Data
public class DnResponseDto {

	@Schema(description = "交货单条目列表")
	@JsonProperty("IT_ITEM")
	private List<DnItItemResponseDto> itItem;

}
