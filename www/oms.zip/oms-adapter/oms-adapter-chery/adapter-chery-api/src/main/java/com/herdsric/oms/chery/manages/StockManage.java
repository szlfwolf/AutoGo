package com.herdsric.oms.chery.manages;

import cn.hutool.core.collection.CollectionUtil;
import com.herdsric.oms.chery.dto.response.StockItItemResponseDto;
import com.herdsric.oms.chery.dto.response.StockResponseDto;
import com.herdsric.oms.chery.util.TimeUtils;
import com.herdsric.oms.common.client.enums.SyncEnum;
import com.herdsric.oms.common.client.stock.StockDefine;
import com.herdsric.oms.common.client.stock.domain.StockDm;
import com.herdsric.oms.common.client.stock.dto.StockDTO;
import com.herdsric.oms.common.client.stock.process.StockProcessor;
import com.herdsric.oms.common.core.util.SpringContextHolder;
import com.herdsric.oms.common.security.util.SecurityUtils;
import com.herdsric.oms.common.webhook.CallbackHttpDefine;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.List;

@Slf4j
public class StockManage extends CommonDefine implements StockDefine {

	@Override
	public List<StockDm> queryStock(StockDTO stockDTO) {
		CallbackHttpDefine callbackHttpDefine = SpringContextHolder.getBean(CallbackHttpDefine.class);

		StockProcessor stockProcessor = SpringContextHolder.getBean(StockProcessor.class);
		String clientCode = SecurityUtils.getTokenSupportClient();
		List<StockDm> stockDms = stockProcessor.listStock(clientCode, stockDTO);
		if (CollectionUtil.isNotEmpty(stockDms)) {
			StockResponseDto stockResponseDto = new StockResponseDto();
			List<StockItItemResponseDto> stockItItemResponseDtoList = new ArrayList<>();
			for (StockDm stockDm : stockDms) {
				StockItItemResponseDto stockItItemResponseDto = new StockItItemResponseDto();
				// stockItItemResponseDto.setMandt();
				// TODO 工厂代码:2803 库位:NL14 固定值
				stockItItemResponseDto.setWerks("2803");
				stockItItemResponseDto.setMatnr(stockDm.getPartNumber());
				stockItItemResponseDto.setLgort("NL14");
				// 当前时间
				stockItItemResponseDto.setZdate(TimeUtils.getCurrentDateYYYYMMDD());
				// 当前时间
				stockItItemResponseDto.setZTime(TimeUtils.getCurrentDateHHMMSS());
				stockItItemResponseDto.setLabst(String.valueOf(stockDm.getUsableQty()));
				stockItItemResponseDto.setMeins(stockDm.getUnit());

				stockItItemResponseDtoList.add(stockItItemResponseDto);
			}

			stockResponseDto.setItItem(stockItItemResponseDtoList);

			// todo 向CHERY同步库存快照信息
			callbackHttpDefine.execute(false, clientCode, stockDTO.getWarehouseCode(), stockDms.get(0).getPartNumber(),
					stockResponseDto, SyncEnum.STOCK_SNAPSHOT_SYNC.name(), true);

		}
		return stockDms;
	}

}
