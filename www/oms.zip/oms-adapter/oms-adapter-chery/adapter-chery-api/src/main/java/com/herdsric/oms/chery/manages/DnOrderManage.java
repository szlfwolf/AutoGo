package com.herdsric.oms.chery.manages;

import com.herdsric.oms.chery.common.CheryConstant;
import com.herdsric.oms.chery.dto.response.DnItItemResponseDto;
import com.herdsric.oms.chery.dto.response.DnItemResponseDto;
import com.herdsric.oms.chery.dto.response.DnResponseDto;
import com.herdsric.oms.chery.util.TimeUtils;
import com.herdsric.oms.common.client.dn.DnBizDefine;
import com.herdsric.oms.common.client.dn.domain.DnOrderDm;
import com.herdsric.oms.common.client.dn.domain.OrderLineDm;
import com.herdsric.oms.common.client.dn.dto.DnOrderResponseDTO;
import com.herdsric.oms.common.client.dn.enums.OrderSplitTypeEnum;
import com.herdsric.oms.common.client.dn.function.DnOptionFlag;
import com.herdsric.oms.common.client.dn.handle.DnOrderSplitFunction;
import com.herdsric.oms.common.client.dn.handle.SplitStrategy;
import com.herdsric.oms.common.client.dn.process.DnOrderProcessor;
import com.herdsric.oms.common.client.enums.PfepTypeEnum;
import com.herdsric.oms.common.client.enums.SyncEnum;
import com.herdsric.oms.common.core.util.SpringContextHolder;
import com.herdsric.oms.common.security.util.SecurityUtils;
import com.herdsric.oms.common.webhook.CallbackHttpDefine;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

@Slf4j
@RequiredArgsConstructor
public class DnOrderManage extends CommonDefine implements DnBizDefine {

	@Override
	public void save(DnOrderDm dnOrderDm) {
		dnOrderDm.setTypeEnum(OrderSplitTypeEnum.OS_00);
		dnOrderDm.setPfepTypeEnum(PfepTypeEnum.NO_BY_WAREHOUSE_CODE);
		DnOrderSplitFunction dnOrderSplitFunction = SplitStrategy.getStrategyFunction(dnOrderDm.getTypeEnum());
		dnOrderSplitFunction.preHandle(SecurityUtils.getTokenSupportClient(), dnOrderDm);
	}

	@Override
	public void dnOrderResponseByWebhook(String clientCode, String type, String batchNo) {
		CallbackHttpDefine callbackHttpDefine = SpringContextHolder.getBean(CallbackHttpDefine.class);
		DnOrderProcessor dnOrderProcessor = SpringContextHolder.getBean(DnOrderProcessor.class);

		Function<DnOptionFlag, Function<DnOrderResponseDTO, Boolean>> function = x -> {
			switch (x) {
				case Manual:
					return dm -> {
						log.info("{},BatchNo:{},dnOrder:{} 手动上传订单，不需要反馈", clientCode, batchNo, dm.getOrderNo());
						return false;
					};
				case Cancelled:
					return dm -> {
						log.info("{},BatchNo:{},dnOrder:{} 客户取消订单", clientCode, batchNo, dm.getOrderNo());
						// * 0:取消拣货，或者短拣 导致合单中某一个DN 一个零件数都没有则设置未整单无库存
						// * 2:仓库发起取消操作
						DnResponseDto dnResponseDto = convertDnCancelResponse(dm);
						// 向Chery反馈发货信息
						callbackHttpDefine.execute(false, clientCode, dm.getWarehouseCode(), dm.getOrderNo(),
								dnResponseDto, SyncEnum.DN_ORDER_CANCEL_SYNC.name(), true);

						return true;
					};
				case Released:
				case Packed:
				case Booked:
				case Delivery:
					return dm -> {
						log.info("{},BatchNo:{},dnOrder:{} ，不需要反馈", clientCode, batchNo, dm.getOrderNo(), x);
						return false;
					};
				case PickUp:
					return dm -> {

						DnResponseDto dnResponseDto = convertDnResponse(dm);

						// 向Chery反馈发货信息
						callbackHttpDefine.execute(false, clientCode, dm.getWarehouseCode(), dm.getOrderNo(),
								dnResponseDto, SyncEnum.DN_ORDER_STATUS_OUTBOUND_SYNC.name(), true);

						return true;
					};

				default:
					return dm -> {
						// 其他情况不需要反馈
						return true;
					};
			}
		};
		dnOrderProcessor.dnOrderResponse(clientCode, type, batchNo, function);
	}

	private DnResponseDto convertDnResponse(DnOrderResponseDTO dm) {
		DnResponseDto dnResponseDto = new DnResponseDto();
		List<DnItItemResponseDto> dnItItemResponseDtoList = new ArrayList<>();
		List<DnItemResponseDto> dnItemResponseDtoList = new ArrayList<>();

		DnItItemResponseDto dnItItemResponseDto = new DnItItemResponseDto();

		dnItItemResponseDto.setVbeln(dm.getOrderNo());
		dnItItemResponseDto.setLfart(dm.getValue(CheryConstant.LFART, String.class));
		dnItItemResponseDto.setWerks(dm.getValue(CheryConstant.WERKS, String.class));
		dnItItemResponseDto.setZShipNum(dm.getTrackingNumber());
		dnItItemResponseDto.setZcDate(TimeUtils.convertDateYYYYMMDD(dm.getPickUpTime()));
		dnItItemResponseDto.setZcTime(TimeUtils.convertDateTimeHHmmss(dm.getPickUpTime()));

		// 根据行号和零件号进行分组计算实际出库零件数量总和
		Map<String, List<OrderLineDm>> groupOrderLines = dm.getOrderLines().stream()
				.collect(Collectors.groupingBy(x -> x.getLineNo() + "_" + x.getPartNumber()));

		groupOrderLines.forEach((key, orderLine) -> {

			double sumQty = orderLine.stream().map(OrderLineDm::getQty).mapToDouble(Double::valueOf).sum();

			OrderLineDm orderLineDm = orderLine.get(0);
			DnItemResponseDto dnItemResponseDto = new DnItemResponseDto();
			dnItemResponseDto.setPosnr(orderLineDm.getLineNo());
			dnItemResponseDto.setLfimg(orderLineDm.getValue(CheryConstant.LFIMG, String.class));
			dnItemResponseDto.setMatnr(orderLineDm.getPartNumber());
			dnItemResponseDto.setMeins(orderLineDm.getValue(CheryConstant.MEINS, String.class));
			// 数量求和
			dnItemResponseDto.setZsjShs(String.valueOf(sumQty));
			dnItemResponseDto.setLgort(orderLineDm.getValue(CheryConstant.LGORT, String.class));
			dnItemResponseDto.setVgpos(orderLineDm.getValue(CheryConstant.VGPOS, String.class));
			dnItemResponseDto.setVgbel(orderLineDm.getValue(CheryConstant.VGBEL, String.class));
			dnItemResponseDto.setSernr(orderLineDm.getValue(CheryConstant.SERNR, String.class));

			dnItemResponseDtoList.add(dnItemResponseDto);
		});

		dnItItemResponseDto.setItem(dnItemResponseDtoList);

		dnItItemResponseDtoList.add(dnItItemResponseDto);

		dnResponseDto.setItItem(dnItItemResponseDtoList);

		return dnResponseDto;
	}

	@Override
	public void dnOrderCancelByWebhook(String clientCode, String batchNo) {
		CallbackHttpDefine callbackHttpDefine = SpringContextHolder.getBean(CallbackHttpDefine.class);
		DnOrderProcessor dnOrderProcessor = SpringContextHolder.getBean(DnOrderProcessor.class);
		Function<DnOptionFlag, Function<DnOrderResponseDTO, Boolean>> function = x -> {
			switch (x) {
				case Manual:
					return dm -> {
						log.info("{},BatchNo:{},dnOrder:{} 手动上传订单，不需要反馈", clientCode, batchNo, dm.getOrderNo());
						return false;
					};
				case Cancelled:
					return dm -> {
						log.info("{},BatchNo:{},dnOrder:{} 仓库发起取消订单", clientCode, batchNo, dm.getOrderNo());
						DnResponseDto dnResponseDto = convertDnCancelResponse(dm);
						// 向Chery反馈发货信息
						callbackHttpDefine.execute(false, clientCode, dm.getWarehouseCode(), dm.getOrderNo(),
								dnResponseDto, SyncEnum.DN_ORDER_CANCEL_SYNC.name(), true);
						return true;
					};
				default:
					return dm -> {
						// 其他情况不需要反馈
						return true;
					};
			}
		};

		dnOrderProcessor.dnOrderCancelByWebhook(clientCode, batchNo, function);
	}

	private DnResponseDto convertDnCancelResponse(DnOrderResponseDTO dm) {
		log.info("dn:{},取消反馈客户chery,参数:{}", dm.getOrderNo(), dm);
		LocalDateTime dateTime = LocalDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		String formatTime = dateTime.format(formatter);

		DnResponseDto dnResponseDto = new DnResponseDto();
		List<DnItItemResponseDto> dnItItemResponseDtoList = new ArrayList<>();
		List<DnItemResponseDto> dnItemResponseDtoList = new ArrayList<>();

		DnItItemResponseDto dnItItemResponseDto = new DnItItemResponseDto();

		dnItItemResponseDto.setVbeln(dm.getOrderNo());
		dnItItemResponseDto.setLfart(dm.getValue(CheryConstant.LFART, String.class));
		dnItItemResponseDto.setWerks(dm.getValue(CheryConstant.WERKS, String.class));
		dnItItemResponseDto.setZShipNum(dm.getTrackingNumber());
		dnItItemResponseDto.setZcDate(TimeUtils.convertDateYYYYMMDD(formatTime));
		dnItItemResponseDto.setZcTime(TimeUtils.convertDateTimeHHmmss(formatTime));

		for (OrderLineDm orderLine : dm.getOrderLines()) {

			DnItemResponseDto dnItemResponseDto = new DnItemResponseDto();
			dnItemResponseDto.setPosnr(orderLine.getLineNo());
			dnItemResponseDto.setLfimg(orderLine.getValue(CheryConstant.LFIMG, String.class));
			dnItemResponseDto.setMatnr(orderLine.getPartNumber());
			dnItemResponseDto.setMeins(orderLine.getValue(CheryConstant.MEINS, String.class));
			dnItemResponseDto.setZsjShs("0");
			dnItemResponseDto.setLgort(orderLine.getValue(CheryConstant.LGORT, String.class));
			dnItemResponseDto.setVgpos(orderLine.getValue(CheryConstant.VGPOS, String.class));
			dnItemResponseDto.setVgbel(orderLine.getValue(CheryConstant.VGBEL, String.class));
			dnItemResponseDto.setSernr(orderLine.getValue(CheryConstant.SERNR, String.class));

			dnItemResponseDtoList.add(dnItemResponseDto);
		}

		dnItItemResponseDto.setItem(dnItemResponseDtoList);

		dnItItemResponseDtoList.add(dnItItemResponseDto);

		dnResponseDto.setItItem(dnItItemResponseDtoList);

		return dnResponseDto;
	}

}
