package com.herdsric.oms.chery.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * @author tyy
 * @createDate 2025/1/16 16:55
 */
@Data
public class StockItItemDto {

	@Schema(description = "客户端（SAP 客户端固定）")
	@JsonProperty("MANDT")
	private String mandt;

	@Schema(description = "工厂代码")
	@JsonProperty("WERKS")
	private String werks;

	@Schema(description = "物料编码")
	@JsonProperty("MATNR")
	private String matnr;

	@Schema(description = "SAP 存储位置")
	@JsonProperty("LGORT")
	private String lgort;

	@Schema(description = "传输日期（格式：YYYYMMDD）")
	@JsonProperty("ZDATE")
	private String zdate;

	@Schema(description = "传输时间（格式：HHMMSS）")
	@JsonProperty("ZTIME")
	private String zTime;

	@Schema(description = "批号")
	@JsonProperty("CHARG")
	private String charg;

	@Schema(description = "第三方物流的非限制库存数量")
	@JsonProperty("LABST")
	private String labst;

	@Schema(description = "SAP 库存数量")
	@JsonProperty("LABST2")
	private String labst2;

	@Schema(description = "基本计量单位（EA: 件）")
	@JsonProperty("MEINS")
	private String meins;

	@Schema(description = "检验标识")
	@JsonProperty("INSMK")
	private String insmk;

	@Schema(description = "车辆 VIN 码")
	@JsonProperty("SERNR")
	private String sernr;

	@Schema(description = "出港日期")
	@JsonProperty("ZPORTEXITDT")
	private String zPortExitdt;

	@Schema(description = "入库日期")
	@JsonProperty("ZENTRYDT")
	private String zentrydt;

	@Schema(description = "PDI 日期")
	@JsonProperty("ZPDIDT")
	private String zpDidt;

	@Schema(description = "修车日期（如已修复）")
	@JsonProperty("ZBDSHPDT")
	private String zbdshpdt;

	@Schema(description = "出库日期")
	@JsonProperty("ZEXITDT")
	private String zexitdt;

	@Schema(description = "经销商到达日期")
	@JsonProperty("ZDEALERDT")
	private String zdealErdt;

	@Schema(description = "预留字段")
	@JsonProperty("ZTEXT1")
	private String ztext1;

	@Schema(description = "预留字段")
	@JsonProperty("ZTEXT2")
	private String ztext2;

	@Schema(description = "预留字段")
	@JsonProperty("ZTEXT3")
	private String ztext3;

	@Schema(description = "预留字段")
	@JsonProperty("ZTEXT4")
	private String ztext4;

	@Schema(description = "预留字段")
	@JsonProperty("ZTEXT5")
	private String ztext5;

	@Schema(description = "预留字段")
	@JsonProperty("ZTEXT6")
	private String ztext6;

	@Schema(description = "预留字段")
	@JsonProperty("ZTEXT7")
	private String ztext7;

	@Schema(description = "预留字段")
	@JsonProperty("ZTEXT8")
	private String ztext8;

	@Schema(description = "预留字段")
	@JsonProperty("ZTEXT9")
	private String ztext9;

	@Schema(description = "预留字段")
	@JsonProperty("ZTEXTA")
	private String ztexta;

}
