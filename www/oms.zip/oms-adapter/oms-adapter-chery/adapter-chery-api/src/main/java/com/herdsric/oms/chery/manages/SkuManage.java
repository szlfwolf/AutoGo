package com.herdsric.oms.chery.manages;

import com.herdsric.oms.common.client.masterdata.SkuDefine;
import com.herdsric.oms.common.client.masterdata.domain.SkuDm;
import com.herdsric.oms.common.client.masterdata.process.SkuProcessor;
import com.herdsric.oms.common.core.util.SpringContextHolder;
import com.herdsric.oms.common.security.util.SecurityUtils;

import java.util.List;

public class SkuManage extends CommonDefine implements SkuDefine {

	@Override
	public void save(SkuDm skuDm) {
		// 调用OMS-SERVICE 入库接口
		SkuProcessor skuProcessor = SpringContextHolder.getBean(SkuProcessor.class);
		skuProcessor.save(SecurityUtils.getTokenSupportClient(), skuDm);
	}

	@Override
	public void saveBatch(List<SkuDm> skuDms) {
		// 调用OMS-SERVICE 入库接口
		SkuProcessor skuProcessor = SpringContextHolder.getBean(SkuProcessor.class);

		skuProcessor.saveBatch(SecurityUtils.getTokenSupportClient(), skuDms);
	}

}
