package com.herdsric.oms.chery.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.herdsric.oms.chery.dto.ItTabDto;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * @author tyy
 * @createDate 2025/1/17 17:48
 */
@Data
public class AsnOrderResponseDto {

	@JsonProperty("IT_ITEM")
	private List<AsnItItemResponseDto> itItem;

}
