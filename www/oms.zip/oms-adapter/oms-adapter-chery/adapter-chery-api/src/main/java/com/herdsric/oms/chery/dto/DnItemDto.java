package com.herdsric.oms.chery.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author tyy
 * @createDate 2025/1/16 16:42
 */
@Data
public class DnItemDto {

	@NotBlank(message = "交货单行项目号,不能为空")
	@Schema(description = "交货单行项目号")
	@JsonProperty("POSNR")
	private String posnr;

	@NotBlank(message = "物料编号,不能为空")
	@Schema(description = "物料编号")
	@JsonProperty("MATNR")
	private String matnr;

	@NotBlank(message = "物料描述,不能为空")
	@Schema(description = "物料描述")
	@JsonProperty("ARKTX")
	private String arktx;

	@NotBlank(message = "计划交货数量,不能为空")
	@Schema(description = "计划交货数量")
	@JsonProperty("LFIMG")
	private String lfimg;

	@NotBlank(message = "计量单位,不能为空")
	@Schema(description = "计量单位（EA: 件）")
	@JsonProperty("MEINS")
	private String meins;

	@Schema(description = "毛重")
	@JsonProperty("BRGEW")
	private String brgew;

	@Schema(description = "批号")
	@JsonProperty("CHARG")
	private String charg;

	@NotBlank(message = "库存地点不能为空")
	@Schema(description = "库存地点（沙特备件固定为 SA12）")
	@JsonProperty("LGORT")
	private String lgort;

	@NotBlank(message = "参考单据号（销售订单号）,不能为空")
	@Schema(description = "参考单据号（销售订单号）")
	@JsonProperty("VGBEL")
	private String vgbel;

	@NotBlank(message = "参考单据行号（销售订单行号）,不能为空")
	@Schema(description = "参考单据行号（销售订单行号）")
	@JsonProperty("VGPOS")
	private String vgpos;

	@Schema(description = "序列号（车辆接口必填）")
	@JsonProperty("SERNR")
	private String sernr;

	// @NotBlank(message = "交货日期注释,不能为空")
	@Schema(description = "交货日期注释（WADAT_IST + 1 周）")
	@JsonProperty("ZTEXT1")
	private String ztext1;

	@Schema(description = "分割毛重")
	@JsonProperty("KCBRGEW")
	private String kcbrgew;

}
