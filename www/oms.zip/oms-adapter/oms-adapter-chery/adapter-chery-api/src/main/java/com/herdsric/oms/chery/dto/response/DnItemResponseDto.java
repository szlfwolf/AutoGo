package com.herdsric.oms.chery.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * @author tyy
 * @createDate 2025/1/20 15:07
 */
@Data
public class DnItemResponseDto {

	@Schema(description = "交货单行项目号")
	@JsonProperty("POSNR")
	private String posnr;

	@Schema(description = "计划交货数量")
	@JsonProperty("LFIMG")
	private String lfimg;

	@Schema(description = "物料编号")
	@JsonProperty("MATNR")
	private String matnr;

	@Schema(description = "计量单位（EA: 件）")
	@JsonProperty("MEINS")
	private String meins;

	@Schema(description = "第三方物流确认交货数量")
	@JsonProperty("ZSJSHS")
	private String zsjShs;

	@Schema(description = "批号")
	@JsonProperty("CHARG")
	private String charg;

	@Schema(description = "SAP 存储位置")
	@JsonProperty("LGORT")
	private String lgort;

	@Schema(description = "参考单据行号（销售订单行号）")
	@JsonProperty("VGPOS")
	private String vgpos;

	@Schema(description = "参考单据号（销售订单号）")
	@JsonProperty("VGBEL")
	private String vgbel;

	@Schema(description = "车辆 VIN 码")
	@JsonProperty("SERNR")
	private String sernr;

}
