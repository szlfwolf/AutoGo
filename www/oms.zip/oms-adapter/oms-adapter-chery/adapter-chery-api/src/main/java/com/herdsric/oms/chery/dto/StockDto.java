package com.herdsric.oms.chery.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.List;

/**
 * @author tyy
 * @createDate 2025/1/16 16:53
 */
@Data
public class StockDto {

	@Schema(description = "库存条目列表")
	private List<StockItItemDto> items;

}
