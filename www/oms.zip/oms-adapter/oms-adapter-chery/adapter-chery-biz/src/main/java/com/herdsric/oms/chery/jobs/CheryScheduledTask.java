package com.herdsric.oms.chery.jobs;

import com.herdsric.oms.chery.common.CheryConstant;
import com.herdsric.oms.chery.jobs.common.JobCommon;
import com.herdsric.oms.common.client.stock.dto.StockDTO;
import com.herdsric.oms.common.core.constant.SecurityConstants;
import com.herdsric.oms.common.feign.client.RemoteStockService;
import com.herdsric.oms.common.job.common.AbstractCommonTask;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * @Description: Lotus定时任务
 * @author: Dzx
 * @date: 2022.10.28
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class CheryScheduledTask extends AbstractCommonTask {

	private final RemoteStockService remoteStockService;

	/**
	 * CHERY库存快照同步EMP-Portal
	 */
	// @Scheduled(cron = "0/5 * * * * ?")
	@XxlJob(JobCommon.JobName.JOB_CHERY_STOCK_SYNC_SYNCHRONIZATION)
	public void stockSync() {
		this.execute(JobCommon.TaskEnum.JOB_CHERY_STOCK_SYNC_SYNCHRONIZATION, x -> {

			log.info("开始执行CHERY库存快照同步EMP-Portal,客户:Chery,已配置的仓库:{}", CheryConstant.WAREHOUSE_CODE);
			try {
				StockDTO stockDTO = new StockDTO();
				stockDTO.setWarehouseCode(CheryConstant.WAREHOUSE_CODE);
				remoteStockService.queryStock(stockDTO, CheryConstant.CLIENT_CODE, SecurityConstants.FROM_IN);
			}
			catch (Exception e) {
				log.error("CHERY库存快照同步EMP-Portal失败", e.getMessage(), e);
			}
		});
	}

}
