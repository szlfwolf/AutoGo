package com.herdsric.oms.chery.apis;

import cn.hutool.core.collection.CollectionUtil;
import com.herdsric.oms.chery.common.CheryConstant;
import com.herdsric.oms.chery.common.CheryResult;
import com.herdsric.oms.chery.dto.DnOrderDto;
import com.herdsric.oms.common.client.dn.domain.DnOrderDm;
import com.herdsric.oms.common.core.constant.SecurityConstants;
import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.common.feign.client.RemoteDnOrderService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import java.util.Set;

@RestController
@RequestMapping("/apis")
@Tag(name = "DnOrderApis对外接口")
@Validated
@RequiredArgsConstructor
@Slf4j
public class DnOrderApis {

	private final RemoteDnOrderService remoteDnOrderService;

	private final Validator validator;

	@PostMapping("/dn-order")
	public CheryResult receive(@RequestBody DnOrderDto dnOrderDto) {
		try {
			Set<ConstraintViolation<DnOrderDto>> validate = validator.validate(dnOrderDto);

			if (CollectionUtil.isNotEmpty(validate)) {
				return CheryResult.faild(validate.stream().findFirst().map(ConstraintViolation::getMessage).get());
			}

			dnOrderDto.check();

			DnOrderDm dnOrder = dnOrderDto.convert(dnOrderDto);

			R dnResult = remoteDnOrderService.save(dnOrder, CheryConstant.CLIENT_CODE, SecurityConstants.FROM_IN);

			if (dnResult.getCode() == 0) {
				return CheryResult.ok();
			}
			else {
				return CheryResult.faild(dnResult.getMsg());
			}
		}
		catch (Exception e) {
			log.error("dnOrderDto接收异常", e.getMessage(), e);
			return CheryResult.faild(e.getMessage());
		}

	}

}
