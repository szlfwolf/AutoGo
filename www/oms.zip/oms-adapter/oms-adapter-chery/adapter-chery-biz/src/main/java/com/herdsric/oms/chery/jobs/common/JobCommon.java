package com.herdsric.oms.chery.jobs.common;

import cn.hutool.core.util.StrUtil;
import com.herdsric.oms.common.job.common.JobTask;

public class JobCommon {

	private static final String JOB_KEY_PREFIX = "CHERY-JOB-TASK";

	public static class JobName {

		/**
		 * EMP-Portal 库存快照同步CHERY
		 */
		public static final String JOB_CHERY_STOCK_SYNC_SYNCHRONIZATION = "chery_stock_sync_synchronization";

	}

	public enum TaskEnum implements JobTask {

		/**
		 * 拉取lotus主数据同步到OMS
		 */
		JOB_CHERY_STOCK_SYNC_SYNCHRONIZATION(JobName.JOB_CHERY_STOCK_SYNC_SYNCHRONIZATION, 30,
				"EMP-Portal 库存快照同步CHERY");

		public String name;

		public int expireTime;

		public String desc;

		TaskEnum(String name, int expireTime, String desc) {
			this.name = name;
			this.expireTime = expireTime;
			this.desc = desc;
		}

		public String getDesc() {
			return StrUtil.concat(true, this.desc);
		}

		@Override
		public String getName() {
			return name;
		}

		@Override
		public int expireTime() {
			return expireTime;
		}

		@Override
		public String getDescription() {
			return desc;
		}

		public String getKey() {
			return StrUtil.concat(true, JOB_KEY_PREFIX, this.name);
		}

	}

}
