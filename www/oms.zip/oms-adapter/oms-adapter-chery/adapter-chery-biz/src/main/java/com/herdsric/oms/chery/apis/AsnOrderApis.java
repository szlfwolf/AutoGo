package com.herdsric.oms.chery.apis;

import cn.hutool.core.collection.CollectionUtil;
import com.herdsric.oms.chery.common.CheryConstant;
import com.herdsric.oms.chery.common.CheryResult;
import com.herdsric.oms.chery.dto.AsnOrderDto;
import com.herdsric.oms.common.client.asn.domain.AsnOrderDm;
import com.herdsric.oms.common.core.constant.SecurityConstants;
import com.herdsric.oms.common.core.util.R;
import com.herdsric.oms.common.feign.client.RemoteAsnOrderService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import java.util.Set;

@RestController
@RequestMapping("/apis")
@Tag(name = "AsnOrderApis对外接口")
@Validated
@RequiredArgsConstructor
@Slf4j
public class AsnOrderApis {

	private final RemoteAsnOrderService remoteAsnOrderService;

	private final Validator validator;

	@PostMapping("/asn-order")
	public CheryResult receive(@RequestBody AsnOrderDto asnOrderDto) {
		try {
			Set<ConstraintViolation<AsnOrderDto>> validate = validator.validate(asnOrderDto);

			if (CollectionUtil.isNotEmpty(validate)) {
				return CheryResult.faild(validate.stream().findFirst().map(ConstraintViolation::getMessage).get());
			}
			asnOrderDto.check();
			AsnOrderDm asnOrderDm = asnOrderDto.convert(asnOrderDto);
			R asnResult = remoteAsnOrderService.save(asnOrderDm, CheryConstant.CLIENT_CODE, SecurityConstants.FROM_IN);

			if (asnResult.getCode() == 0) {
				return CheryResult.ok();
			}
			else {
				return CheryResult.faild(asnResult.getMsg());
			}
		}
		catch (Exception e) {
			log.error("接收asn订单失败", e.getMessage(), e);
			return CheryResult.faild(e.getMessage());
		}

	}

}
