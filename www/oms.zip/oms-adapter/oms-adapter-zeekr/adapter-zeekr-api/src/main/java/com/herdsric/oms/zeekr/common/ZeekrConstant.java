package com.herdsric.oms.zeekr.common;

public interface ZeekrConstant {

	String CLIENT_CODE = "ZEEKR";

	String COMMON_ONE = "1";

	String COMMON_ZERO = "0";

}
