package com.herdsric.oms.zeekr.dto;

import lombok.Data;

@Data
public class AmqpMessageDto {

	private String dataJson;

	private String messageId;

	private Object properties;

	private String source;

}
