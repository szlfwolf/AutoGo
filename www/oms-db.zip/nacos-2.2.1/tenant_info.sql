/*
 Navicat Premium Dump SQL

 Source Server         : local-oms
 Source Server Type    : MySQL
 Source Server Version : 50718 (5.7.18)
 Source Host           : localhost:23306
 Source Schema         : car_oms_prod

 Target Server Type    : MySQL
 Target Server Version : 50718 (5.7.18)
 File Encoding         : 65001

 Date: 21/05/2025 21:33:24
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for tenant_info
-- ----------------------------
DROP TABLE IF EXISTS `tenant_info`;
CREATE TABLE `tenant_info`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `kp` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT 'kp',
  `tenant_id` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT '' COMMENT 'tenant_id',
  `tenant_name` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT '' COMMENT 'tenant_name',
  `tenant_desc` varchar(256) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT 'tenant_desc',
  `create_source` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT 'create_source',
  `gmt_create` bigint(20) NOT NULL COMMENT '创建时间',
  `gmt_modified` bigint(20) NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `uk_tenant_info_kptenantid`(`kp`, `tenant_id`) USING BTREE,
  INDEX `idx_tenant_id`(`tenant_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8 COLLATE = utf8_bin COMMENT = 'tenant_info' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of tenant_info
-- ----------------------------
INSERT INTO `tenant_info` VALUES (1, '1', 'c02692fa-6bba-414b-b09c-13afbdc3c6aa', 'test', 'test 环境', 'nacos', 1661854412570, 1679117221805);
INSERT INTO `tenant_info` VALUES (2, '1', '685822b0-698f-4742-80db-6f177181f31d', 'dev', '本地连接测试环境', 'nacos', 1679657587782, 1691553703581);
INSERT INTO `tenant_info` VALUES (7, '1', '654623ac-dcb7-4ac1-8eae-9595f0e8a438', 'luxmate-ry', 'luxmate-ry', 'nacos', 1734417262827, 1734417262827);
INSERT INTO `tenant_info` VALUES (8, '1', 'd7c498e6-13d6-4d08-8211-bc3738616eed', 'zhr-dev', '本地开发环境', 'nacos', 1744273826739, 1744273826739);

SET FOREIGN_KEY_CHECKS = 1;
