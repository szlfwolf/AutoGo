<template>
  <div class="content">
    <el-card style="margin-bottom: 10px;">
      <p style="white-space: nowrap; text-align: left;position: relative;">
        <span style="font-size: 20px; margin-left: 5px;color: rgba(0,0,0,0.85);">Asn Alert</span>
        <span class="tubiao"></span>
      </p>
      <el-row :gutter="30">
        <el-col :span="6">
          <div class="grid-content bg-purple" style="width: 275px; height: 136px;display: flex;justify-content: center;
            align-items: center;background: #EFF6FF;border-radius: 8px;cursor: pointer;"
            @click="toIconDetails('Finished')">
            <img src="../../public/icon/bj_nfd.png" alt="" style="position: absolute;width: 275px; height: 136px;">
            <img src="../../public/icon/icon_nf.png" style="width: 78px;height: 78px;z-index: 99;" />
            <div
              style="display: flex;flex-direction: column;justify-content: space-between;height: 78px;margin-left: 20px;z-index: 99;">
              <div style="font-weight: 700;font-size: 32px;color: #1A8ECE;">{{ todo.asnTodo.notFinishedQuantity }}</div>
              <div style="font-size: 14px;"> Not&nbsp;Finished</div>
            </div>
          </div>
        </el-col>
        <el-col :span="6">
          <div class="grid-content bg-purple" style="width: 275px; height: 136px;display: flex;justify-content: center;
            align-items: center;background: #F6F3FE;border-radius: 8px;cursor: pointer;"
            @click="toIconDetails('Mapping')">
            <img src="../../public/icon/bj_nmj.png" alt="" style="position: absolute;width: 275px; height: 136px;">
            <img src="../../public/icon/icon_nm.png" style="width: 78px;height: 78px;z-index: 99;" />
            <div
              style="display: flex;flex-direction: column;justify-content: space-between;height: 78px;margin-left: 20px;z-index: 99;">
              <div style="font-weight: 700; font-size: 32px;color: #5C50B4;"> {{ todo.asnTodo.notMappingQuantity }}
              </div>
              <div style="font-weight: 500;font-size: 14px;"> Not&nbsp;Mapping</div>
            </div>
          </div>
        </el-col>
        <el-col :span="6">
          <div class="grid-content bg-purple" style="width: 275px; height: 136px;display: flex;justify-content: center;
            align-items: center;background: #FCF1EA;border-radius: 8px;cursor: pointer;"
            @click="toIconDetails('Responsed')">
            <img src="../../public/icon/bj_nr.png" alt="" style="position: absolute;width: 275px; height: 136px;">
            <img src="../../public/icon/icon_nr.png" style="width: 78px;height: 78px;z-index: 99;" />
            <div
              style="display: flex;flex-direction: column;justify-content: space-between;height: 78px;margin-left: 20px;z-index: 99;">
              <div style="font-weight: 700; font-size: 32px;color: #F15F22;">{{ todo.asnTodo.notResponsedQuantity }}</div>
              <div style="font-weight: 500;font-size: 14px;"> Not&nbsp;Responsed</div>
            </div>
          </div>
        </el-col>
      </el-row>
    </el-card>
    <el-card style="">
      <p style="white-space: nowrap; text-align: left;position: relative;">
        <span style="font-size: 20px; margin-left: 5px;color: rgba(0,0,0,0.85);"> Dn Alert</span>
        <span class="tubiao"></span>
      </p>
      <el-row :gutter="30">
        <el-col :span="6">
          <div class="grid-content bg-purple" style="width: 275px; height: 136px;display: flex;justify-content: center;
            align-items: center;background: #EFF6FF;border-radius: 8px;cursor: pointer;"
            @click="toIconDetails('Packed')">
            <img src="../../public/icon/bj_np.png" alt="" style="position: absolute;width: 275px; height: 136px;">
            <img src="../../public/icon/icon_np.png" style="width: 78px;height: 78px;z-index: 99;" />
            <div
              style="display: flex;flex-direction: column;justify-content: space-between;height: 78px;margin-left: 20px;z-index: 99;">
              <div style="font-weight: 700; font-size: 32px;color: #1A8ECE;"> {{ todo.dnTodo.notPackedQuantity }}
              </div>
              <div style="font-weight: 500;font-size: 14px;"> Not&nbsp;Packed</div>
            </div>
          </div>
        </el-col>
        <el-col :span="6">
          <div class="grid-content bg-purple" style="width: 275px; height: 136px;display: flex;justify-content: center;
            align-items: center;background: #F6F3FE;border-radius: 8px;cursor: pointer;"
            @click="toIconDetails('Booked')">
            <img src="../../public/icon/bj_nb.png" alt="" style="position: absolute;width: 275px; height: 136px;">
            <img src="../../public/icon/icon_nb.png" style="width: 78px;height: 78px;z-index: 99;" />
            <div
              style="display: flex;flex-direction: column;justify-content: space-between;height: 78px;margin-left: 20px;z-index: 99;">
              <div style="font-weight: 700; font-size: 32px;color: #5C50B4;"> {{ todo.dnTodo.notBookedQuantity }}
              </div>
              <div style="font-weight: 500;font-size: 14px;"> Not&nbsp;Booked</div>
            </div>
          </div>
        </el-col>
        <el-col :span="6">
          <div class="grid-content bg-purple" style="width: 275px; height: 136px;display: flex;justify-content: center;
            align-items: center;background: #FCF1EA;border-radius: 8px;cursor: pointer;"
            @click="toIconDetails('Outbound')">
            <img src="../../public/icon/bj_no.png" alt="" style="position: absolute;width: 275px; height: 136px;">
            <img src="../../public/icon/icon_no.png" style="width: 78px;height: 78px;z-index: 99;" />
            <div
              style="display: flex;flex-direction: column;justify-content: space-between;height: 78px;margin-left: 20px;z-index: 99;">
              <div style="font-weight: 700; font-size: 32px;color: #F15F22;"> {{ todo.dnTodo.notOutboundQuantity }}
              </div>
              <div style="font-weight: 500; font-size: 14px;"> Not&nbsp;Outbound</div>
            </div>
          </div>
        </el-col>
        <el-col :span="6">
          <div class="grid-content bg-purple" style="width: 275px; height: 136px;display: flex;justify-content: center;
            align-items: center;background: #E6F5EA;border-radius: 8px;cursor: pointer;" @click="toIconDetails('Pod')">
            <img src="../../public/icon/bj_npo.png" alt="" style="position: absolute;width: 275px; height: 136px;">
            <img src="../../public/icon/icon_npo.png" style="width: 78px;height: 78px;z-index: 99;" />
            <div
              style="display: flex;flex-direction: column;justify-content: space-between;height: 78px;margin-left: 20px;z-index: 99;">
              <div style="font-weight: 700; font-size: 32px;color: #4E8A56;"> {{ todo.dnTodo.notPodQuantity }}
              </div>
              <div style="font-weight: 500;font-size: 14px;"> Not&nbsp;Pod</div>
            </div>
          </div>
        </el-col>
      </el-row>
    </el-card>
  </div>
</template>

<script>
import alert from '../../public/icon/alert.png'
import asn_finished from '../../public/icon/asn_finished.png'
import asn_responsed from '../../public/icon/asn_responsed.png'
import booked from '../../public/icon/booked.png'
import mapping from '../../public/icon/mapping.png'
import packed from '../../public/icon/packed.png'
import pickup from '../../public/icon/pickup.png'
import pod from '../../public/icon/pod.png'
import warn_alert from '../../public/icon/warn-alert.png'
import { mapGetters } from 'vuex';
import { getAsnTodoQuantity } from "@/api/inbound/asn"
import { getDnTodoQuantity } from '@/api/dn'
import store from "@/store"; // progress bar style

export default {
  name: 'wel',
  data() {
    return {
      icon: {
        alert: alert,
        asn_finished: asn_finished,
        asn_responsed: asn_responsed,
        booked: booked,
        mapping: mapping,
        packed: packed,
        pickup: pickup,
        pod: pod,
        warn_alert: warn_alert,
      },
      todo: {
        asnTodo: {},
        dnTodo: {}
      },
      activeNames: ['1', '2', '3', '4'],
      DATA: [],
      text: '',
      actor: '',
      count: 0,
      isText: false
    }
  },
  created() {
    this.initTodoFunc();
  },
  computed: {
    ...mapGetters(['website'])
  },
  methods: {

    initTodoFunc() {
      let clientCode = store.getters.commandName;
      if (clientCode === '') {
        setTimeout(() => {
          this.listAsnTodoNums();
          this.listDnTodoNums();
        }, 1000);
      } else {
        this.listAsnTodoNums();
        this.listDnTodoNums();
      }
    },

    listAsnTodoNums() {
      getAsnTodoQuantity({}).then(response => {
        if (response.data.code === 0) {
          this.todo.asnTodo = response.data.data;
        } else {
          this.$message.error(response.data.msg);
        }
      })
      console.log(this.todo);
    },
    listDnTodoNums() {
      getDnTodoQuantity({}).then(response => {
        if (response.data.code === 0) {
          this.todo.dnTodo = response.data.data;
        } else {
          this.$message.error(response.data.msg);
        }
      })

      console.log(this.todo);
    },

    //跳转到明细中
    toIconDetails(type) {
      let path;
      if (type === 'Packed' || type === 'Booked' || type === 'Outbound' || type === 'Pod') {
        path = `/outbound/dn/index`
      }
      if (type === 'Mapping' || type === 'Finished') {
        path = `/inbound/asn/index`;
      }
      if (type === 'Responsed') {
        path = `/inbound/order/index`;
      }

      this.$router.push({
        path: path,
        query: {
        },
      });
    },
    getData() {
      if (this.count < this.DATA.length - 1) {
        this.count++
      } else {
        this.count = 0
      }
      this.isText = true
      this.actor = this.DATA[this.count]
    },
    setData() {
      let num = 0
      let count = 0
      let active = false
      let timeoutstart = 5000
      let timeoutend = 1000
      let timespeed = 10
      setInterval(() => {
        if (this.isText) {
          if (count == this.actor.length) {
            active = true
          } else {
            active = false
          }
          if (active) {
            num--
            this.text = this.actor.substr(0, num)
            if (num == 0) {
              this.isText = false
              setTimeout(() => {
                count = 0
                this.getData()
              }, timeoutend)
            }
          } else {
            num++
            this.text = this.actor.substr(0, num)
            if (num == this.actor.length) {
              this.isText = false
              setTimeout(() => {
                this.isText = true
                count = this.actor.length
              }, timeoutstart)
            }
          }
        }
      }, timespeed)
    }
  }
}
</script>

<style scoped="scoped" lang="scss">
.content {
  padding: 0 10px;
  font-family: FZLanTingHeiS-B-GB-Regular, FZLanTingHeiS-B-GB;

  .tubiao {
    width: 44px;
    height: 8px;
    background: linear-gradient(90deg, #1A8ECE 0%, rgba(26, 142, 206, 0.2) 100%);
    border-radius: 0px 0px 0px 0px;
    opacity: 1;
    position: absolute;
    left: 4px;
    bottom: 4px;
  }
}

.wel-contailer {
  position: relative;
}

.banner-text {
  position: relative;
  padding: 0 20px;
  font-size: 20px;
  text-align: center;
  color: #333;
}

.banner-img {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  opacity: 0.8;
  display: none;
}

.actor {
  height: 250px;
  overflow: hidden;
  font-size: 18px;
  color: #333;
}

.actor:after {
  content: '';
  width: 3px;
  height: 25px;
  vertical-align: -5px;
  margin-left: 5px;
  background-color: #333;
  display: inline-block;
  animation: blink 0.4s infinite alternate;
}

.typeing:after {
  animation: none;
}

@keyframes blink {
  to {
    opacity: 0;
  }
}

.el-row {
  margin-bottom: 20px;

  &:last-child {
    margin-bottom: 0;
  }
}

.el-col {
  border-radius: 4px;
}

.bg-purple-dark {
  background: #99a9bf;
}

.bg-purple {
  background: #d3dce6;
}

.bg-purple-light {
  background: #e5e9f2;
}

.grid-content {
  border-radius: 4px;
  min-height: 36px;
}

.row-bg {
  padding: 10px 0;
  background-color: #f9fafc;
}
</style>