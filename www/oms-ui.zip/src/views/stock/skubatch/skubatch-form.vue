<template>
  <el-dialog
    :title="!dataForm.id ? '新增' : '修改'"
    append-to-body
    :close-on-click-modal="false"
    @close="closeDialog()"
    :visible.sync="visible">
    <el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="dataFormSubmit()" label-width="80px">
    <el-form-item label="主键" prop="id" v-if="dataForm.id">
        <el-input v-model="dataForm.id" placeholder="主键" disabled></el-input>
    </el-form-item>
    <el-form-item label="批次号" prop="batchNo">
        <el-input v-model="dataForm.batchNo" placeholder="批次号"></el-input>
    </el-form-item>
    <el-form-item label="客户代码" prop="clientCode">
        <el-input v-model="dataForm.clientCode" placeholder="客户代码"></el-input>
    </el-form-item>
    <el-form-item label="仓库代码" prop="warehouseCode">
        <el-input v-model="dataForm.warehouseCode" placeholder="仓库代码"></el-input>
    </el-form-item>
    <el-form-item label="零件号" prop="partNumber">
        <el-input v-model="dataForm.partNumber" placeholder="零件号"></el-input>
    </el-form-item>
    <el-form-item label="数量" prop="num">
        <el-input v-model="dataForm.num" placeholder="数量"></el-input>
    </el-form-item>
    <el-form-item label="批次总数" prop="totalNum">
        <el-input v-model="dataForm.totalNum" placeholder="批次总数"></el-input>
    </el-form-item>
    <el-form-item label="单位 pce/pcs" prop="unit">
        <el-input v-model="dataForm.unit" placeholder="单位 pce/pcs"></el-input>
    </el-form-item>
    <el-form-item label="创建时间" prop="createTime" v-if="dataForm.id">
        <el-input v-model="dataForm.createTime" placeholder="创建时间" disabled></el-input>
    </el-form-item>
    <el-form-item label="创建人" prop="createBy" v-if="dataForm.id">
        <el-input v-model="dataForm.createBy" placeholder="创建人" disabled></el-input>
    </el-form-item>
    <el-form-item label="更新时间" prop="updateTime" v-if="dataForm.id">
        <el-input v-model="dataForm.updateTime" placeholder="更新时间" disabled></el-input>
    </el-form-item>
    <el-form-item label="更新人" prop="updateBy" v-if="dataForm.id">
        <el-input v-model="dataForm.updateBy" placeholder="更新人" disabled></el-input>
    </el-form-item>
    <el-form-item label="删除标识0：未删除，1：已删除" prop="isDelete">
        <el-input v-model="dataForm.isDelete" placeholder="删除标识0：未删除，1：已删除"></el-input>
    </el-form-item>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="visible = false">取消</el-button>
      <el-button type="primary" @click="dataFormSubmit()" v-if="canSubmit">确定</el-button>
    </span>
  </el-dialog>
</template>

<script>
    import {getObj, addObj, putObj} from '@/api/skubatch'

    export default {
    data () {
      return {
        visible: false,
        canSubmit: false,
        dataForm: {
          id: '',
          batchNo: '',
          clientCode: '',
          warehouseCode: '',
          partNumber: '',
          num: '',
          totalNum: '',
          unit: '',
          createTime: '',
          createBy: '',
          updateTime: '',
          updateBy: '',
          isDelete: '',
        },
        dataRule: {
          batchNo: [
            { required: true, message: '批次号不能为空', trigger: 'blur' }
          ],

          clientCode: [
            { required: true, message: '客户代码不能为空', trigger: 'blur' }
          ],

          warehouseCode: [
            { required: true, message: '仓库代码不能为空', trigger: 'blur' }
          ],

          partNumber: [
            { required: true, message: '零件号不能为空', trigger: 'blur' }
          ],

          num: [
            { required: true, message: '数量不能为空', trigger: 'blur' }
          ],

          totalNum: [
            { required: true, message: '批次总数不能为空', trigger: 'blur' }
          ],

          unit: [
            { required: true, message: '单位 pce/pcs不能为空', trigger: 'blur' }
          ],

          isDelete: [
            { required: true, message: '删除标识0：未删除，1：已删除不能为空', trigger: 'blur' }
          ],

        }
      }
    },
    methods: {
      init (id) {
        this.visible = true;
        this.canSubmit = true;
        this.$nextTick(() => {
            this.$refs['dataForm'].resetFields()
            if (id) {
            getObj(id).then(response => {
                this.dataForm = response.data.data
            })
          }
        })
      },
      // 表单提交
      dataFormSubmit () {
        this.$refs['dataForm'].validate((valid) => {
          if (valid) {
            this.canSubmit = false;
            if (this.dataForm.id) {
                putObj(this.dataForm).then(data => {
                    this.$notify.success('修改成功')
                    this.visible = false
                    this.$emit('refreshDataList')
                }).catch(() => {
                    this.canSubmit = true;
                });
            } else {
                addObj(this.dataForm).then(data => {
                    this.$notify.success('添加成功')
                    this.visible = false
                    this.$emit('refreshDataList')
                }).catch(() => {
                    this.canSubmit = true;
                });
            }
          }
        })
      },
      //重置表单
      closeDialog() {
          this.$refs["dataForm"].resetFields()
      }
    }
  }
</script>
