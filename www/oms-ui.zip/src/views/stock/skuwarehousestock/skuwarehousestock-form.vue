<template>
  <el-dialog
    :title="!dataForm.id ? '新增' : '修改'"
    append-to-body
    :close-on-click-modal="false"
    @close="closeDialog()"
    :visible.sync="visible">
    <el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="dataFormSubmit()" label-width="80px">
    <el-form-item label="主键" prop="id" v-if="dataForm.id">
        <el-input v-model="dataForm.id" placeholder="主键" disabled></el-input>
    </el-form-item>
    <el-form-item label="clientCode" prop="clientCode">
        <el-input v-model="dataForm.clientCode" placeholder="clientCode"></el-input>
    </el-form-item>
    <el-form-item label="warehouseCode" prop="warehouseCode">
        <el-input v-model="dataForm.warehouseCode" placeholder="warehouseCode"></el-input>
    </el-form-item>
    <el-form-item label="partNumber" prop="partNumber">
        <el-input v-model="dataForm.partNumber" placeholder="partNumber"></el-input>
    </el-form-item>
    <el-form-item label="totalNum" prop="totalNum">
        <el-input v-model="dataForm.totalNum" placeholder="totalNum"></el-input>
    </el-form-item>
    <el-form-item label="blockNum" prop="blockNum">
        <el-input v-model="dataForm.blockNum" placeholder="blockNum"></el-input>
    </el-form-item>
    <el-form-item label="holdNum" prop="holdNum">
        <el-input v-model="dataForm.holdNum" placeholder="holdNum"></el-input>
    </el-form-item>
    <el-form-item label="qualityNum" prop="qualityNum">
        <el-input v-model="dataForm.qualityNum" placeholder="qualityNum"></el-input>
    </el-form-item>
    <el-form-item label="damageNum" prop="damageNum">
        <el-input v-model="dataForm.damageNum" placeholder="damageNum"></el-input>
    </el-form-item>
    <el-form-item label="待销毁" prop="scrapNum">
        <el-input v-model="dataForm.scrapNum" placeholder="待销毁"></el-input>
    </el-form-item>
    <el-form-item label="spare1" prop="spare1">
        <el-input v-model="dataForm.spare1" placeholder="spare1"></el-input>
    </el-form-item>
    <el-form-item label="spare2" prop="spare2">
        <el-input v-model="dataForm.spare2" placeholder="spare2"></el-input>
    </el-form-item>
    <el-form-item label="spare3" prop="spare3">
        <el-input v-model="dataForm.spare3" placeholder="spare3"></el-input>
    </el-form-item>
    <el-form-item label="创建时间" prop="createTime" v-if="dataForm.id">
        <el-input v-model="dataForm.createTime" placeholder="创建时间" disabled></el-input>
    </el-form-item>
    <el-form-item label="创建人" prop="createBy" v-if="dataForm.id">
        <el-input v-model="dataForm.createBy" placeholder="创建人" disabled></el-input>
    </el-form-item>
    <el-form-item label="更新时间" prop="updateTime" v-if="dataForm.id">
        <el-input v-model="dataForm.updateTime" placeholder="更新时间" disabled></el-input>
    </el-form-item>
    <el-form-item label="更新人" prop="updateBy" v-if="dataForm.id">
        <el-input v-model="dataForm.updateBy" placeholder="更新人" disabled></el-input>
    </el-form-item>
    <el-form-item label="删除标识0：未删除，1：已删除" prop="isDelete">
        <el-input v-model="dataForm.isDelete" placeholder="删除标识0：未删除，1：已删除"></el-input>
    </el-form-item>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="visible = false">取消</el-button>
      <el-button type="primary" @click="dataFormSubmit()" v-if="canSubmit">确定</el-button>
    </span>
  </el-dialog>
</template>

<script>
    import {getObj, addObj, putObj} from '@/api/skuwarehousestock'

    export default {
    data () {
      return {
        visible: false,
        canSubmit: false,
        dataForm: {
          id: '',
          clientCode: '',
          warehouseCode: '',
          partNumber: '',
          totalNum: '',
          blockNum: '',
          holdNum: '',
          qualityNum: '',
          damageNum: '',
          scrapNum: '',
          spare1: '',
          spare2: '',
          spare3: '',
          createTime: '',
          createBy: '',
          updateTime: '',
          updateBy: '',
          isDelete: '',
        },
        dataRule: {
          clientCode: [
            { required: true, message: 'clientCode不能为空', trigger: 'blur' }
          ],

          warehouseCode: [
            { required: true, message: 'warehouseCode不能为空', trigger: 'blur' }
          ],

          partNumber: [
            { required: true, message: 'partNumber不能为空', trigger: 'blur' }
          ],

          totalNum: [
            { required: true, message: 'totalNum不能为空', trigger: 'blur' }
          ],

          blockNum: [
            { required: true, message: 'blockNum不能为空', trigger: 'blur' }
          ],

          holdNum: [
            { required: true, message: 'holdNum不能为空', trigger: 'blur' }
          ],

          qualityNum: [
            { required: true, message: 'qualityNum不能为空', trigger: 'blur' }
          ],

          damageNum: [
            { required: true, message: 'damageNum不能为空', trigger: 'blur' }
          ],

          scrapNum: [
            { required: true, message: '待销毁不能为空', trigger: 'blur' }
          ],

          spare1: [
            { required: true, message: 'spare1不能为空', trigger: 'blur' }
          ],

          spare2: [
            { required: true, message: 'spare2不能为空', trigger: 'blur' }
          ],

          spare3: [
            { required: true, message: 'spare3不能为空', trigger: 'blur' }
          ],

          isDelete: [
            { required: true, message: '删除标识0：未删除，1：已删除不能为空', trigger: 'blur' }
          ],

        }
      }
    },
    methods: {
      init (id) {
        this.visible = true;
        this.canSubmit = true;
        this.$nextTick(() => {
            this.$refs['dataForm'].resetFields()
            if (id) {
            getObj(id).then(response => {
                this.dataForm = response.data.data
            })
          }
        })
      },
      // 表单提交
      dataFormSubmit () {
        this.$refs['dataForm'].validate((valid) => {
          if (valid) {
            this.canSubmit = false;
            if (this.dataForm.id) {
                putObj(this.dataForm).then(data => {
                    this.$notify.success('修改成功')
                    this.visible = false
                    this.$emit('refreshDataList')
                }).catch(() => {
                    this.canSubmit = true;
                });
            } else {
                addObj(this.dataForm).then(data => {
                    this.$notify.success('添加成功')
                    this.visible = false
                    this.$emit('refreshDataList')
                }).catch(() => {
                    this.canSubmit = true;
                });
            }
          }
        })
      },
      //重置表单
      closeDialog() {
          this.$refs["dataForm"].resetFields()
      }
    }
  }
</script>
