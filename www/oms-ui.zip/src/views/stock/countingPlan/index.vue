<template>
  <div class="content" v-loading="countingPlan">
    <el-card class="box-card">
      <el-row style="width: 200px; display: flex">
        <el-col>
          <el-button type="primary" icon="el-icon-search" @click="getSearchlist">Query</el-button>
        </el-col>
        <el-col>
          <el-button icon="el-icon-refresh-left" @click="getReset">Reset</el-button>
        </el-col>
      </el-row>
      <el-form ref="form" :model="form" style="margin: 20px 0" @keyup.enter.native="getSearchlist">
        <el-row :gutter="20">
          <el-col>
            <el-radio-group v-model="form.warehouseCode" v-for="(ite, index) in warehouseCode" :key="index">
              <el-radio :label="ite.warehouseCode" style="margin-right:10px" @change="getRadio">{{ ite.warehouseName
                              }}</el-radio>
            </el-radio-group>
          </el-col>
          <el-col :span="4" style="margin-top: 10px">
            <el-input v-model="form.partNumber" placeholder="Sku no"></el-input>
          </el-col>
          <el-col :span="4" style="margin-top: 10px">
            <el-select filterable v-model="form.countType" placeholder="Yearly A/B/C" filterable clearable>
              <el-option v-for="item in countType" :key="item.value" :label="item.label" :value="item.value">
              </el-option>
            </el-select>
          </el-col>
          <el-col :span="4" style="margin-top: 10px">
            <el-date-picker v-model="time.planCountingDateTime" type="daterange" start-placeholder="planCountingDateTime"
              end-placeholder="planCountingDateEndTime" value-format="yyyy-MM-dd" @change="changePlanCountingDateTime" />
          </el-col>
        </el-row>
      </el-form>
      <div class="down">
        <div>
          <el-button type="primary" v-if="permissions.stock_skubatch_export" @click="runClick" style="padding: 9px 15px">
            <span style="display: flex; align-items: center">
              <i class="iconfont icon-1huojian" style="margin-right: 5px; font-size: 12px"></i>Run
            </span>
          </el-button>
        </div>
        <el-button icon="el-icon-download" v-if="permissions.stock_skubatch_export" @click="exportExcel"></el-button>
      </div>
      <el-table border ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%"
        v-loading="dataListLoading" :header-cell-style="{ background: '#f5f7fa', color: '#606266' }">
        <el-table-column label="Owner" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.clientCode || "-" }}</template>
        </el-table-column>
        <el-table-column label="WarehouseName" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.warehouseName || "-" }}</template>
        </el-table-column>
        <!-- <el-table-column label="Warehouse" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.warehouseCode || "-" }}</template>
        </el-table-column> -->
        <el-table-column label="Sku" min-width="140" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.partNumber || "-" }}</template>
        </el-table-column>
        <el-table-column label="Yearly A/B/C" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.countType || "-" }}</template>
        </el-table-column>
        <el-table-column label="Plan Counting Date" min-width="140" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.planCountingDate || "-" }}</template>
        </el-table-column>
        <el-table-column label="CreateTime" min-width="140" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.createTime || "-" }}</template>
        </el-table-column>
        <el-table-column label="Opearter" align="center"
          v-if="permissions.master_emailconfig_update || permissions.master_emailconfig_del">
          <template slot-scope="scope">
            <el-button :disabled="scope.row.isEdit !== 'Y'" style="font-size: 18px;color: #65beff;padding:0;border:0"
              :style="{ 'color': scope.row.isEdit !== 'Y' ? '' : '#65beff' }" class="el-icon-edit"
              @click="countingEdit(scope.row, scope.$index)" v-if="permissions.master_emailconfig_update"></el-button>
            <el-button :disabled="scope.row.isEdit !== 'Y'"
              style="font-size: 18px;color: #65beff;padding:0;border:0;margin-left:10px"
              :style="{ 'color': scope.row.isEdit !== 'Y' ? '' : '#65beff' }" class="el-icon-delete"
              @click="countingDelete(scope.row, scope.$index)" v-if="permissions.master_emailconfig_del"></el-button>
          </template>
        </el-table-column>
      </el-table>
      <Pagination @handleSizeChange="handleSizeChange" @handleCurrentChange="handleCurrentChange" :pageNum="page.current"
        :pageSize="page.size" :total="total"></Pagination>
      <el-dialog :title="title" :visible.sync="formDialog.centerDialogVisible" width="35%" style="font-weight: 700"
        @close="getClose" :close-on-click-modal="false" v-loading="formDialogLoading">
        <div v-if="title === 'Add'">
          <el-form :model="formDialog" ref="runForm" :rules="runRules" label-width="100px">
            <el-table border ref="multipleTable" :data="formDialog.tableData" tooltip-effect="dark" style="width: 100%"
              max-height="300" header-cell-class-name="header-cell-class"
              :header-cell-style="{ background: '#f5f7fa', color: '#606266' }">
              <el-table-column label="warehouse" align="center" min-width="140">
                <template slot-scope="scope">
                  <el-form-item :prop="'tableData.' + scope.$index + '.warehouseCode'" :rules="runRules.warehouseCode"
                    style="margin-bottom: 0; margin-left: -100px">
                    <el-select filterable v-model="scope.row.warehouseCode" clearable filterable>
                      <el-option v-for="item in warehouseCode" :key="item.warehouseCode" :label="item.warehouseName"
                        :value="item.warehouseCode">
                      </el-option>
                    </el-select>
                  </el-form-item>
                </template>
              </el-table-column>
              <el-table-column label="Sku no" align="center" min-width="120">
                <template slot-scope="scope">
                  <el-form-item :prop="'tableData.' + scope.$index + '.partNumber'" :rules="runRules.partNumber"
                    style="margin-bottom: 0; margin-left: -100px">
                    <el-input v-model="scope.row.partNumber" @blur="changeInput(scope.row)" placeholder="sku"></el-input>
                  </el-form-item>
                </template>
              </el-table-column>
              <el-table-column label="Half-yearly A/B/C" align="center" min-width="140">
                <!-- :prop="'tableData.' + scope.$index + '.countType'" :rules="runRules.countType" -->
                <template slot-scope="scope">
                  <el-form-item style="margin-bottom: 0; margin-left: -100px">
                    <el-input v-model="scope.row.countType" disabled></el-input>
                    <!--  <el-select filterable v-model="scope.row.countType" clearable filterable disabled> 
                      <el-option v-for="item in countType" :key="item.value" :label="item.label" :value="item.value">
                      </el-option>
                    </el-select> -->
                  </el-form-item>
                </template>
              </el-table-column>
              <!-- <el-table-column label="Plan Counting Date" align="center" min-width="140">
                <template slot-scope="scope">
                  <el-form-item :prop="'tableData.' + scope.$index + '.planCountingDate'"
                    :rules="runRules.planCountingDate" style="margin-bottom: 0; margin-left: -100px">
                    <el-date-picker v-model="scope.row.planCountingDate" type="date" value-format="yyyy-MM-dd"
                      :picker-options="{ disabledDate }">
                    </el-date-picker>
                  </el-form-item>
                </template>
              </el-table-column> -->
              <el-table-column label="Opearter" align="center">
                <template slot-scope="scope">
                  <i style="font-size: 18px; cursor: pointer" class="el-icon-delete"
                    @click="handleDelete(scope.$index, formDialog.tableData)"></i>
                </template>
              </el-table-column>
            </el-table>
          </el-form>
          <span style=" font-size: 24px; color: #59a6f9; margin: 20px 10px 0 0; display: flex; justify-content: center; ">
            <div>
              <i class="el-icon-circle-plus-outline" style="margin-right: 20px; cursor: pointer" @click="addRows()"></i>
            </div>
            <!-- @click="changeType" -->
            <div>
              <!-- form2.fromType ||  -->
              <i class="el-icon-upload" style="cursor: pointer" @click="$refs.excelUpload.show()"
                v-if="permissions.stock_skuwarehousestock_import"></i>
            </div>
          </span>
        </div>
        <el-form v-else :model="editForm" ref="editForm" :rules="editRules" label-width="160px">
          <el-form-item label="Warehouse:" prop="warehouseCode">
            <el-select filterable v-model="editForm.warehouseCode" disabled>
              <el-option v-for="item in warehouseCode" :key="item.value" :label="item.label" :value="item.value">
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="Sku no:" prop="partNumber">
            <el-input v-model="editForm.partNumber" disabled></el-input>
          </el-form-item>
          <el-form-item label="Yearly A/B/C:" prop="countType">
            <el-input v-model="editForm.countType" disabled></el-input>
          </el-form-item>
          <el-form-item label="Plan Counting Date:" prop="planCountingDate">
            <el-date-picker v-model="editForm.planCountingDate" type="date" value-format="yyyy-MM-dd">
            </el-date-picker>
          </el-form-item>
        </el-form>
        <span slot="footer" class="dialog-footer">
          <el-button type="info" @click="getClose">Cancel</el-button>
          <el-button type="primary" @click="dialogButton">Confirm</el-button>
        </span>
      </el-dialog>
      <!--excel 模板导入 -->
      <excel-upload ref="excelUpload" title="upload" url="/stock/countingplan/uploadCountPlanExcel"
        temp-name="partNumber-countingPlan-template.xlsx"
        temp-url="/admin/sys-file/local/partNumber-countingPlan-template.xlsx"
        @refreshDataList="handleRefreshChange"></excel-upload>
    </el-card>
  </div>
</template>
<script>
import Pagination from "@/components/pagination/pagination.vue";
import ExcelUpload from "@/components/upload/excel";
import { mapGetters } from "vuex";
import { getWarehouse } from "@/api/stock/analysis";
import { pageQuery, getSku, countPlanSubmit, updateCountingPlan, deleteCountingPlan } from "@/api/stock/countingPlan";
import { remote } from "@/api/admin/dict";

let formParams = {
  partNumber: undefined,
  warehouseCode: undefined,
  countType: undefined,
};
export default {
  name: "CountingPlan",
  data() {
    return {
      form: Object.assign({}, formParams),
      total: 0,
      page: {
        size: 10,
        current: 1,
      },
      formDialog: {
        centerDialogVisible: false,
        tableData: [
          // {
          //   warehouseCode: '',
          //   partNumber: '',
          //   countType: '',
          //   planCountingDate: ''
          // },
        ],
      },
      editForm: {
        warehouseCode: "",
        partNumber: "",
        countType: "",
        planCountingDate: "",
      },
      runRules: {
        partNumber: [
          { required: true, message: "此区域为必填项", trigger: "blur" },
          // { pattern:/^([1-9]{1}\d*)$/, trigger: 'blur' },
          // {validator: (rule, value, callback) => {
          //   console.log(rule, value,);
          // },trigger:'change'}
        ],
        countType: [
          { required: true, message: "此区域为必填项", trigger: "change" },
        ],
        warehouseCode: { required: true, message: "此区域为必填项", trigger: "change" },
        planCountingDate: { required: true, message: "此区域为必填项", trigger: "change" },
      },
      time: {
        planCountingDateTime: "",
      },
      dataListLoading: false,
      tableData: [],
      warehouseCode: [],
      age: [],
      countType: [
        {
          label: "A",
          value: "A",
        },
        {
          label: "B",
          value: "B",
        },
        {
          label: "C",
          value: "C",
        },
      ],
      countingPlan: false,
      title: "",
      editRules: {},
      formDialogLoading:false
    };
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  components: {
    Pagination,
    ExcelUpload,
  },
  async created() {
    await this.getWarehouseByClient();
  },
  methods: {
    //时间参数
    changePlanCountingDateTime(val) {
      if (val !== undefined && val !== null && val !== "" && val.length > 0) {
        this.$set(this.form, "beginPlanCountingTime", val[0]);
        this.$set(this.form, "endPlanCountingTime", val[1]);
      } else {
        this.$set(this.form, "beginPlanCountingTime", undefined);
        this.$set(this.form, "endPlanCountingTime", undefined);
      }
    },
    //禁止选择未来/过去的时间
    disabledDate(time) {
      //  - 8.64e7
      return time.getTime() < Date.now();  // 可选历史天、可选当前天、不可选未来天
    },
    //导入
    handleRefreshChange(e) {
      if (e === "loading") {
        this.formDialogLoading = true;
        return;
      }
      this.formDialogLoading = false;

      
      // if (this.formDialog.tableData.length) {
        this.formDialog.tableData = this.formDialog.tableData.concat(e.data)
        console.log(this.formDialog.tableData);
      // } else {
      //   this.formDialog.tableData = e.data
      // }
    },
    //导出
    exportExcel() {
      this.countingPlan = true
      this.downBlobFile("/stock/countingplan/export", this.form, "countingPlan.xlsx", () => this.countingPlan = false);
    },
    //条数
    handleSizeChange(val) {
      this.page.current = 1;
      this.page.size = val;
      this.getList(this.form);
    },
    //当前页数
    handleCurrentChange(val) {
      this.page.current = val;
      this.getList(this.form);
    },
    //清空
    getReset() {
      this.form = Object.assign({}, formParams);
      this.time = this.$options.data().time;
      this.page = this.$options.data().page;
      this.form.warehouseCode = this.warehouseCode[0].warehouseCode
      this.getList(this.form);
    },
    //仓库选泽
    getRadio() {
      this.getSearchlist()
    },
    //查询
    getSearchlist() {
      this.page.current = 1;
      for (let key in this.form) {
        if (this.form[key] === "" || this.form[key] === null) {
          this.form[key] = undefined;
        }
      }
      this.getList(this.form);
    },
    //数据列表
    getList(params) {
      this.dataListLoading = true;
      pageQuery(Object.assign({ ...this.page }, params)).then((res) => {
        console.log(res);
        if (res.data.code === 0) {
          res.data.data.records.forEach((item) => {
            this.warehouseCode.forEach((ite) => {
              if (item.warehouseCode === ite.warehouseCode) {
                this.$set(item, "warehouseName", ite.warehouseName);
              }
            });
          });
          this.tableData = res.data.data.records;
          this.total = res.data.data.total;
          this.dataListLoading = false;
        } else {
          this.$message.error(res.data.msg);
          this.dataListLoading = false;
        }
      }).catch(() => {
        this.$message.error("request was aborted");
        this.dataListLoading = false;
      });
    },
    //单条数据查询
    changeInput(row, index) {
      console.log(row);
      if (row.partNumber) {
        getSku(Object.assign({ skuNo: row.partNumber })).then((res) => {
          console.log(res);
          if (res.data.code === 0) {
            row.countType = res.data.data.halfYearlyType
          } else {
            this.$message(res.data.msg);
          }
        });
      }
    },
    //操作Run
    runClick() {
      this.title = "Add";
      this.formDialog.centerDialogVisible = true;
    },
    //操作
    dialogButton() {
      if (this.title === "Add") {
        if(!this.formDialog.tableData.length){
          return 
        }
        this.$refs.runForm.validate((valid) => {
          if (!valid) return false;
          this.formDialogLoading = true
          countPlanSubmit(this.formDialog.tableData).then((res) => {
            this.formDialogLoading = false
            if (res.data.code === 0) {
              this.formDialog.centerDialogVisible = false;
              this.$message.success("Successfully added")
              this.getList(this.form);
            } else {
              this.$message.error(res.data.msg);
              this.formDialog.centerDialogVisible = false;
            }
          }).catch(() => {
            this.formDialogLoading = false
            this.formDialog.centerDialogVisible = false;
          });
        });
      } else {
        // this.$refs.editForm.validate((valid) => {
        //     if (!valid) return false;
        updateCountingPlan({
          id: this.editForm.id,
          warehouseCode: this.editForm.warehouseCode,
          partNumber: this.editForm.partNumber,
          countType: this.editForm.countType,
          planCountingDate: this.editForm.planCountingDate,
        }).then(res => {
          if (res.data.code === 0) {
            this.formDialog.centerDialogVisible = false;
            this.getList(this.form);
            this.$message.success("Update succeeded");
          } else {
            this.$message.error(res.data.msg);
            this.formDialog.centerDialogVisible = false;
          }
        }).catch(() => {
          this.formDialog.centerDialogVisible = false;
        });
        // })
      }
    },
    //添加行
    addRows() {
      console.log(this.formRef, "this.formRef");
      this.formDialog.tableData.push({
        warehouseCode: "",
        partNumber: "",
        countType: "",
        planCountingDate: ""
      });
    },
    //删除行
    handleDelete(index, rows) {
      // if (this.formDialog.tableData.length > 1) {
        rows.splice(index, 1);
      // }
    },
    //关闭弹窗
    getClose() {
      if (this.title === "Add") {
        this.$refs.runForm.resetFields();
        this.formDialog = this.$options.data().formDialog;
      } else {
        this.formDialog.centerDialogVisible = false;
      }
      // this.formDialog.centerDialogVisible = false
    },
    //编辑
    countingEdit(row, index) {
      this.title = "Edit";
      this.formDialog.centerDialogVisible = true;
      this.editForm = Object.assign({}, row);
    },
    //删除
    countingDelete(row, index) {
      this.$confirm("This operation will permanently delete this data. Do you want to continue?", "Tips", {
        confirmButtonText: "submit",
        cancelButtonText: "cancel",
        type: "warning",
      }
      ).then(() => {
        deleteCountingPlan(row.id).then((res) => {
          if (res.data.code === 0) {
            this.getList(this.form);
            this.$message.success("Deleted succeeded");
          } else {
            this.$message.error(res.data.msg);
          }
        });
      }).catch(() => {
        this.$message({
          type: "info",
          message: "Destruction",
        });
      });
    },
    //warehouseCode下拉数据
    getWarehouseByClient() {
      getWarehouse().then((res) => {
        console.log(res);
        if (res.data.code === 0) {
          this.warehouseCode = res.data.data;
          this.form.warehouseCode = res.data.data[0].warehouseCode
          this.getList(this.form)
        }
      });
      remote("sku_age").then((res) => {
        console.log(res);
        if (res.data.code === 0) {
          this.age = res.data.data;
        }
      });
    },
  },
};
</script>
<style lang="scss" scoped>
.content {
  padding: 0 10px;

  // box-sizing: border-box;
  .text {
    font-size: 14px;
  }

  .item {
    padding: 18px 0;
  }

  .box-card {
    width: 100%;
  }

  .down {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    border-top: 1px solid #999;
    padding-top: 20px;
    box-sizing: border-box;
  }

  .underLine {
    color: #599af8;
    text-decoration: underline;
  }

  ::v-deep .el-dialog {
    border-radius: 8px !important;
  }

  ::v-deep .el-select--small {
    display: block;
  }

  ::v-deep .el-date-editor--daterange.el-input,
  ::v-deep .el-date-editor--daterange.el-input__inner,
  ::v-deep .el-date-editor--timerange.el-input,
  ::v-deep .el-date-editor--timerange.el-input__inner {
    width: 100% !important;
  }

  ::v-deep .el-date-editor.el-input,
  ::v-deep .el-date-editor.el-input__inner {
    width: 100% !important;
  }
}
</style>
