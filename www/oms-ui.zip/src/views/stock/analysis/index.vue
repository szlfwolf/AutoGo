<template>
  <div class="content" v-loading="analysisLoading">
    <el-card class="box-card">
      <el-row style="width:200px;display:flex">
        <el-col>
          <el-button type="primary" icon="el-icon-search" @click="getSearchlist">Query</el-button>
        </el-col>
        <el-col>
          <el-button icon="el-icon-refresh-left" @click="getReset">Reset</el-button>
        </el-col>
      </el-row>
      <el-form ref="form" :model="form" style="margin: 20px 0" @keyup.enter.native="getSearchlist">
        <el-row :gutter="20">
          <el-col :span="4">
            <el-input v-model="form.partNumber" placeholder="Sku no"></el-input>
          </el-col>
          <el-col :span="4">
            <el-input v-model="form.batchNo" placeholder="Batch no"></el-input>
          </el-col>
          <el-col :span="4">
            <el-select filterable v-model="form.warehouseCode" placeholder="Warehouse" filterable clearable>
              <el-option v-for="item in warehouseCode" :key="item.value" :label="item.warehouseName"
                :value="item.warehouseCode">
              </el-option>
            </el-select>
          </el-col>
          <el-col :span="4">
            <el-select filterable v-model="form.age" placeholder="Age" filterable clearable>
              <el-option v-for="item in age" :key="item.value" :label="item.label" :value="item.value">
              </el-option>
            </el-select>
          </el-col>
        </el-row>
      </el-form>
      <div class="down">
        <div></div>
        <el-button icon="el-icon-download" v-if="permissions.stock_skubatch_export" @click="exportExcel"></el-button>
      </div>
      <el-table border ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%"
        v-loading="dataListLoading" :header-cell-style="{ background: '#f5f7fa', color: '#606266' }">
        <el-table-column label="Owner" align="center">
          <template slot-scope="scope">{{ scope.row.clientCode || '-' }}</template>
        </el-table-column>
        <el-table-column label="WarehouseName" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.warehouseName || '-' }}</template>
        </el-table-column>
        <el-table-column label="WarehouseCode" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.warehouseCode || '-' }}</template>
        </el-table-column>
        <el-table-column label="Sku no" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.partNumber || '-' }}</template>
        </el-table-column>
        <el-table-column label="Batch no" width="200px" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.batchNo || '-' }}</template>
        </el-table-column>
        <el-table-column label="Qty" align="center">
          <template slot-scope="scope">{{ scope.row.num || '-' }}</template>
        </el-table-column>
        <el-table-column label="CreateTime" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.createTime || '-' }}</template>
        </el-table-column>
        <el-table-column label="Age(Day)" align="center">
          <template slot-scope="scope">{{ scope.row.age || '0' }}</template>
        </el-table-column>
      </el-table>
      <Pagination @handleSizeChange="handleSizeChange" @handleCurrentChange="handleCurrentChange" :pageNum="page.current"
        :pageSize="page.size" :total="total"></Pagination>
    </el-card>
  </div>
</template>
<script>
import Pagination from "@/components/pagination/pagination.vue"
import { mapGetters } from "vuex"
import {pageQuery, getWarehouse} from "@/api/stock/analysis"
import {remote} from "@/api/admin/dict"

let formParams = {
  partNumber: undefined,
  warehouseCode: undefined,
  age: undefined,
  batchNo:undefined
}
export default {
  name: "Analysis",
  data() {
    return {
      form: Object.assign({}, formParams),
      total: 0,
      page:{
        size: 10,
        current: 1,
      },
      formDialog: {
        warehouse: "",
        remark: "",
      },
      dataListLoading: false,
      tableData: [],
      warehouseCode:[],
      age:[],
      analysisLoading:false
    }
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  components: {
    Pagination,
  },
  async created() {
    await this.getWarehouseByClient()
    await this.getList()
  },
  methods: {
    //导出
    exportExcel() {
      this.analysisLoading = true
      this.downBlobFile("/stock/skubatch/export", this.form , "skubatch.xlsx",()=> this.analysisLoading = false)
    },
    //条数
    handleSizeChange(val) {
      this.page.current = 1
      this.page.size = val
      this.getList(this.form)
    },
    //当前页数
    handleCurrentChange(val) {
      this.page.current = val
      this.getList(this.form)
    },
    //清空
    getReset() {
      this.form = Object.assign({}, formParams)
      this.page = this.$options.data().page
      this.getList()
    },
    //查询
    getSearchlist() {
      this.page.current = 1
      for (let key in this.form) {
        if(this.form[key] === '' || this.form[key] === null){
          this.form[key] = undefined
        }
      }
      this.getList(this.form)
    },
    //数据列表
    getList(params){
      this.dataListLoading = true
      pageQuery(Object.assign({...this.page},params)).then(res=>{
        console.log(res)
        if(res.data.code === 0){
          this.tableData = res.data.data.records
          this.tableData.forEach(item=>{
            this.warehouseCode.forEach(i=>{
              if(item.warehouseCode === i.warehouseCode){
                item.warehouseName = i.warehouseName           
              }
            })
          })
          this.total = res.data.data.total
          this.dataListLoading = false
        }else{
          this.$message.error(res.data.msg)
          this.dataListLoading = false
        }
      }).catch(()=>{
        this.$message.error('request was aborted')
        this.dataListLoading = false
      })
    },
    //warehouseCode下拉数据
    getWarehouseByClient(){
      getWarehouse().then(res=>{
        console.log(res) 
        if(res.data.code === 0){
         this.warehouseCode = res.data.data
        }
      })
      remote('sku_age').then(res=>{
        console.log(res) 
       if(res.data.code === 0){
        this.age = res.data.data
       }
      })
    },
  },
} 
</script>
<style lang="scss" scoped>
.content {
  padding: 0 10px;

  // box-sizing: border-box;
  .text {
    font-size: 14px;
  }

  .item {
    padding: 18px 0;
  }

  .box-card {
    width: 100%;
  }

  .down {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    border-top: 1px solid #999;
    padding-top: 20px;
    box-sizing: border-box;
  }

  .underLine {
    color: #599af8;
    text-decoration: underline;
  }

  ::v-deep .el-select--small {
    display: block;
  }
}
</style>
