<template>
  <div class="contentIn" v-loading="overLoading">
    <el-row style="width:200px;display:flex">
      <el-col>
        <el-button type="primary" icon="el-icon-search" @click="getSearchlist">Query</el-button>
      </el-col>
      <el-col>
        <el-button icon="el-icon-refresh-left" @click="getReset">Reset</el-button>
      </el-col>
    </el-row>
    <el-form ref="form" :model="form" style="margin: 20px 0" @keyup.enter.native="getSearchlist">
      <el-row>
        <el-col :span="4">
          <el-input v-model="form.skuNo" placeholder="Sku no" clearable></el-input>
        </el-col>
      </el-row>
    </el-form>
    <div class="down">
      <div></div>
      <el-button icon="el-icon-download" @click="exportExcel" v-if="permissions.stock_skuwarehousestock_export_summary"></el-button>
    </div>
    <el-table
      border
      ref="multipleTable"
      :data="tableData"
      tooltip-effect="dark"
      style="width: 100%"
      v-loading="dataListLoading"
      :header-cell-style="{ background: '#f5f7fa', color: '#606266' }"
    >
      <el-table-column type="selection" width="55" align="center"> </el-table-column>
      <el-table-column label="Owner" align="center">
        <template slot-scope="scope">{{ scope.row.clientCode || '-'}}</template>
      </el-table-column>
      <el-table-column label="Sku no" width="140px" align="center">
        <template slot-scope="scope">{{ scope.row.partNumber || '-'}}</template>
      </el-table-column>
      <el-table-column label="Total Qty" width="140" align="center">
        <template slot-scope="scope">
          <div class="underLine" @click="handleDetail(scope.$index, scope.row, 'total')">
            {{ scope.row.totalNum || '0'}}
          </div>
        </template>
      </el-table-column>
      <el-table-column label="Available Qty" width="140px" align="center">
        <template slot-scope="scope">{{ scope.row.availableQty || '0'}}</template>
      </el-table-column>
      <el-table-column label="Booked Qty" width="140px" align="center">
        <template slot-scope="scope">
          <div class="underLine" @click="handleDetail(scope.$index, scope.row, 'book')">
            {{ scope.row.bookedQty || '0'}}
          </div>
        </template>
      </el-table-column>
      <el-table-column label="Block Qty" align="center">
        <template slot-scope="scope">{{scope.row.blockNum|| '0'}}</template>
      </el-table-column>
      <el-table-column label="Hold Qty" align="center">
        <template slot-scope="scope">{{ scope.row.holdNum || '0'}}</template>
      </el-table-column>
      <el-table-column label="Quality Qty" width="140px" align="center">
        <template slot-scope="scope">{{ scope.row.qualityNum || '0'}}</template>
      </el-table-column>
      <el-table-column label="Damage Qty" width="140px" align="center">
        <template slot-scope="scope">{{ scope.row.damageNum || '0'}}</template>
      </el-table-column>
      <el-table-column label="Scrap Qty" align="center">
        <template slot-scope="scope">{{ scope.row.scrapNum || '0'}}</template>
      </el-table-column>
      <el-table-column label="Spare1 Qty" width="140px" align="center">
        <template slot-scope="scope">{{ scope.row.spare1 || '0'}}</template>
      </el-table-column>
      <el-table-column label="Spare2 Qty" width="140px" align="center">
        <template slot-scope="scope">{{ scope.row.spare2 || '0'}}</template>
      </el-table-column>
      <el-table-column label="Spare3 Qty" width="140px" align="center">
        <template slot-scope="scope">{{ scope.row.spare3 || '0'}}</template>
      </el-table-column>
      <el-table-column label="Transfer Lost Qty" min-width="140" align="center">
        <template slot-scope="scope">
          <div class="underLine" @click="handleDetail(scope.$index, scope.row, 'Transfer Lost List')"
            v-if="permissions.stock_skuwarehousestock_booked">{{ scope.row.transferLostNum || '0' }}</div>
          <div v-else>{{ scope.row.transferLostNum || '0' }}</div>
        </template>
      </el-table-column>
    </el-table>
    <Pagination 
      @handleSizeChange="handleSizeChange"
      @handleCurrentChange="handleCurrentChange"
      :pageNum="page.current" 
      :pageSize="page.size" 
      :total="total"
    ></Pagination>
    <Dialog
      :title="title" 
      :dialogView="dialogView"
      :BatchByQuery="BatchByQuery"
      :titleForm="titleForm"
      @close="getClose"
      @handleDetail="handleDetailDialog"
      :info="info"
    ></Dialog>
  </div>
</template>
<script>
import { mapGetters } from "vuex"
import Pagination from "@/components/pagination/pagination.vue"
import Dialog from "./dialog/dialog.vue"
import {getSummaryStockByQuery, getBatchByQuery, getBookedDNByQuery, getTransferLogs} from "@/api/stock/subwarehouse"
export default {
  name: "Overview",
  data() {
    return {
      info: {},
      form: {
        skuNo: undefined,
      },
      page:{
        size: 10,
        current: 1,
      },
      total:0,
      formDialog: {
        warehouse: "",
        remark: "",
      },
      dataListLoading: false,
      tableData: [],
      dialogView: false, //表格
      title:'',
      BatchByQuery:{},//批次Total数据
      titleForm:{},//Booked表单数据
      overLoading:false
    }
  },
  created() {
    this.getList()
  },
  components:{
    Pagination,
    Dialog,
  },
  computed: {
    ...mapGetters(["permissions"])
  },
  mounted(){
    this.exportExcel = this.$btn(this.exportExcel,500)
  },
  methods: {
    //导出
    exportExcel() {
      this.overLoading = true
      this.downBlobFile("/stock/skuwarehousestock/exportBySummaryStockStock", {partNumber:this.form.skuNo} , `${this.$store.state.common.commandName}-skuwarehousesumstock-${this.toDateFormat(new Date(), true)}.xlsx`, ()=> this.overLoading = false)
    },
    //条数
    handleSizeChange(val) {
      this.page.current = 1
      this.page.size = val
      this.getList()
    },
    //当前页数
    handleCurrentChange(val) {
      this.page.current = val
      this.getList()
    },
    //清空
    getReset(){
      this.form.skuNo = undefined
      this.page = this.$options.data().page
      this.getList()
    },
    //查询
    getSearchlist(){
      this.page.current = 1
      if(this.form.skuNo === '' || this.form.skuNo === null){
        this.form.skuNo = undefined
      }
      this.getList(this.form)
    },
    //数据列表
    getList(params){
      this.dataListLoading = true
      getSummaryStockByQuery(Object.assign({...this.page},params)).then(res=>{
        if(res.data.code === 0){
          this.tableData = res.data.data.records
          this.total = res.data.data.total
          this.dataListLoading = false
        }else{
          this.$message.error(res.data.msg)
          this.dataListLoading = false
        }
      }).catch(err=>{
        this.$message.error('request was aborted')
        this.dataListLoading = false
      })
    },
    //打开表格dialog
    handleDetail(index, row, type) {
      this.info = {...row,current:1,size:10}
      if (type === "total") {
        this.title = "Batch Info"
        getBatchByQuery({current: row.current || 1,size: row.size || 10,warehouseCode:row.warehouseCode,skuNo:row.partNumber,clientCode:row.clientCode}).then(res=>{
          if(res.data.code === 0 && res.data.data.records.length > 0){
            this.dialogView = true
            this.BatchByQuery = res.data.data
          }else{
            this.$message.warning('No data')
          }
        })
      } else if (type == 'book') {
        this.title = "Booked DN"
        this.titleForm = row
        getBookedDNByQuery({current: row.current || 1,size: row.size || 10,warehouseCode:row.warehouseCode,skuNo:row.partNumber,clientCode:row.clientCode}).then(res=>{
          if(res.data.code === 0 && res.data.data.records.length > 0){
            this.dialogView = true
            this.BatchByQuery = res.data.data
          }else{
            this.$message.warning('No data')
          }
        })
      } else {
        this.title = "Transfer Lost List"
        this.titleForm = row
        getTransferLogs({ warehouseCode: row.warehouseCode, partNumber: row.partNumber, clientCode: row.clientCode }).then(res => {
          console.log(res);
          if (res.data.code === 0 && res.data.data.skuTransferLogs.length > 0) {
            this.dialogView = true
            this.BatchByQuery = res.data.data
            // this.exportData = { warehouseCode: row.warehouseCode, partNumber: row.partNumber, clientCode: row.clientCode }
          } else {
            this.$message.warning('No data')
          }
        })
      }
    },
    //子传父改变表单dialog状态
    formClose() {
      this.dialogStyleView = false
    },
    //调父方法
    handleDetailDialog(e){
      console.log('448', e)
      this.handleDetail('',e.info,e.title)
    },
    //子传父改变表格dialog状态
    getClose(e) {
      this.dialogView = e
    },
  },
}
</script>
<style lang="scss" scoped>
.contentIn {
  .down {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    border-top: 1px solid #999;
    padding-top: 20px;
    box-sizing: border-box;
  }
  .underLine {
    cursor: pointer;
    color: #599af8;
    text-decoration: underline;
  }
}
</style>
