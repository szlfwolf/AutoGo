<template>
  <div>
    <el-dialog :title="title" :visible="dialogView" width="50%" style="font-weight: 700" @close="getClose" v-loading="globalLoaing">
      <el-row style="padding: 0 20px; box-sizing: border-box" v-if="title === 'Booked DN'">
        <el-col :span="12">
          <label for="">Sku no:</label>
          <span>{{ titleForm.partNumber || "0" }}</span>
        </el-col>
        <el-col :span="12">
          <label for="">Booked Qty:</label>
          <span>{{ titleForm.bookedQty || "0" }}</span>
        </el-col>
      </el-row>
      <el-row
        style="padding: 0 20px; box-sizing: border-box"
        v-if="title === 'Intransit ASN'"
      >
        <el-col :span="12">
          <label for="">Sku no:</label>
          <span>{{ titleForm.partNumber || "0" }}</span>
        </el-col>
        <el-col :span="12">
          <label for="">Intransit Qty:</label>
          <span>{{ titleForm.intransitQty || "0" }}</span>
        </el-col>
        <el-col :span="12">
          <label for="">Shipped Qty:</label>
          <span>{{ titleForm.shippedQty || "0" }}</span>
        </el-col>
        <el-col :span="12">
          <label for="">Not Inbound Qty:</label>
          <span>{{ titleForm.notArrivedQty || "0" }}</span>
        </el-col>
      </el-row>

      <el-row style="padding: 0 20px; box-sizing: border-box" v-if="title === 'Transfer Lost List'">
        <el-col :span="12">
          <label>Sku no:</label>
          <span>{{ titleForm.partNumber || "0" }}</span>
        </el-col>
        <el-col :span="12">
          <label>Transfer Lost List:</label>
          <span>{{ BatchByQuery.transferLostQty || "0" }}</span>
        </el-col>
      </el-row>

      <el-row type="flex" justify="end" >
        <el-button style="margin-bottom:10px;"
          icon="el-icon-download"
          @click="exportExcel"
          v-if="title === 'Batch Info' || title === 'Booked DN' || title == 'Transfer Lost List'"
        ></el-button>
        <el-button style="margin-bottom:10px;"
          icon="el-icon-download"
          @click="exportExcel"
          v-if=" title === 'Intransit ASN' && permissions.stock_intransitDetail_export"
        ></el-button>
      </el-row>

      <el-table
        ref="multipleTable"
        :data="BatchByQuery.records"
        tooltip-effect="dark"
        style="width: 100%"
        v-if="title === 'Batch Info'"
        :header-cell-style="{ background: '#f5f7fa', color: '#606266' }"
        border
      >
        <el-table-column label="Owner" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.clientCode || "-" }}</template>
        </el-table-column>
        <el-table-column label="Warehouse" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.warehouseCode || "-" }}</template>
        </el-table-column>
        <el-table-column label="Sku no" min-width="180" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.partNumber || "-" }}</template>
        </el-table-column>
        <el-table-column label="Batch no" min-width="180" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.batchNo || "-" }}</template>
        </el-table-column>
        <el-table-column label="Qty" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.num || "-" }}</template>
        </el-table-column>
        <el-table-column label="Inbound Date" min-width="180" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.createTime || "-" }}</template>
        </el-table-column>
        <el-table-column label="Age(Day)" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.warehousingDay || "-" }}</template>
        </el-table-column>
      </el-table>

      <el-table ref="multipleTable" :data="BatchByQuery.records" tooltip-effect="dark" style="width: 100%"
        v-if="title === 'Booked DN'" :header-cell-style="{ background: '#f5f7fa', color: '#606266' }" border>
        <el-table-column label="Warehouse" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.warehouseCode || "-" }}</template>
        </el-table-column>
        <el-table-column label="Order no" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.orderNo || "-" }}</template>
        </el-table-column>
        <el-table-column label="DN no" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.dnNo || "-" }}</template>
        </el-table-column>
        <el-table-column label="Qty" align="center">
          <template slot-scope="scope">{{ scope.row.qty || "-" }}</template>
        </el-table-column>
      </el-table>

      <el-table
        ref="multipleTable"
        :data="BatchByQuery.data"
        tooltip-effect="dark"
        style="width: 100%"
        v-if="title === 'Intransit ASN'"
        :header-cell-style="{ background: '#f5f7fa', color: '#606266' }"
        border
      >
        <el-table-column label="Warehouse" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.warehouseCode || "-" }}</template>
        </el-table-column>
        <el-table-column label="Job" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.blNo || "-" }}</template>
        </el-table-column>
        <el-table-column label="Container no" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.containerNo || "-" }}</template>
        </el-table-column>
        <el-table-column label="Qty" align="center">
          <template slot-scope="scope">{{ scope.row.qty || "-" }}</template>
        </el-table-column>
        <el-table-column label="Type" align="center">
          <template slot-scope="scope">{{ scope.row.type || "-" }}</template>
        </el-table-column>
      </el-table>

      <el-table
        ref="multipleTable"
        :data="BatchByQuery.skuTransferLogs"
        tooltip-effect="dark"
        style="width: 100%"
        v-if="title === 'Transfer Lost List'"
        :header-cell-style="{ background: '#f5f7fa', color: '#606266' }"
        border
      >
        <el-table-column label="From Warehouse" align="center" min-width="130" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.transferInWarehouseCode || "-" }}</template>
        </el-table-column>
        <el-table-column label="To Warehosue" align="center" min-width="120" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.transferOutWarehouseCode || "-" }}</template>
        </el-table-column>
        <el-table-column label="DnNo" align="center" min-width="160" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.dnNo || "-" }}</template>
        </el-table-column>
        <el-table-column label="DeliveryQty" align="center" min-width="120" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.deliveryQty || "0" }}</template>
        </el-table-column>
        <el-table-column label="AsnNo" align="center" min-width="140" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.asnNo || "-" }}</template>
        </el-table-column>
        <el-table-column label="ReceiveQty" align="center" min-width="120" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.receiveQty || "0" }}</template>
        </el-table-column>
        <el-table-column label="Date Time" align="center" min-width="140" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.createTime || "-" }}</template>
        </el-table-column>
      </el-table>

      <Pagination
        v-if="dialogView && title !== 'Intransit ASN'"
        @handleSizeChange="handleSizeChange"
        @handleCurrentChange="handleCurrentChange"
        :pageNum="page.current"
        :pageSize="page.size"
        :total="BatchByQuery.total"
      ></Pagination>
    </el-dialog>
  </div>
</template>
<script>
import Pagination from "@/components/pagination/pagination.vue";
import { mapGetters } from "vuex"
export default {
  name: "Dialog",
  data() {
    return {
      page: {
        size: 10,
        current: 1,
      },
      total: 0,
      globalLoaing: false
    };
  },
  props: {
    title: {
      type: String,
    },
    dialogView: {
      type: Boolean,
    },
    BatchByQuery: {
      type: Object,
    },
    exportData: {
      type: Object,
    },
    info: {
      type: Object,
    },
    titleForm: {
      type: Object,
    },
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  components: {
    Pagination,
  },
  created() {
    console.log(this.titleForm,this.BatchByQuery);
  },
  methods: {
    //导出 partNumber:this.form.skuNo,warehouseCode:this.form.warehouseCode 
    exportExcel() {
      this.globalLoaing = true
      if (this.title === "Batch Info") {
        this.downBlobFile("/stock/skubatch/exportBatchByQuery", { ...this.exportData }, "skubatch.xlsx", ()=>{ this.globalLoaing = false})
      } else if (this.title === "Intransit ASN"){
        this.downBlobFile("/stock/skuwarehousestock/exportIntransitDetail", { ...this.exportData }, "Intransit.xlsx", ()=>{ this.globalLoaing = false})
      } else if(this.title == 'Transfer Lost List'){
        this.downBlobFile("/stock/skutransferlog/export", { ...this.exportData }, "TransferLostList.xlsx", ()=>{ this.globalLoaing = false})
      } else {
        this.downBlobFile("/stock/skuwarehousestock/exportByBookedDNB", { ...this.exportData }, "booked.xlsx", ()=>{ this.globalLoaing = false})
      }
    },
    getClose() {
      this.$emit("close", false);
      this.page.current = 1;
      this.page.size = 10;
    },
    //条数
    handleSizeChange(val) {
      this.page.current = 1;
      this.page.size = val;
      if (this.title === "Batch Info") {
        let obj = {
          info: Object.assign(this.info, {
            size: this.page.size,
            current: this.page.current,
          }),
          title: "total",
        };
        this.$emit("handleDetail", obj);
      } else if(this.title === 'Booked DN') {
        let obj = {
          // info:{...this.info,size:this.page.size,current:this.page.current},
          info: Object.assign(this.info, {
            size: this.page.size,
            current: this.page.current,
          }),
          title: "book",
        };
        this.$emit("handleDetail", obj);
      }
    },
    //当前页数
    handleCurrentChange(val) {
      this.page.current = val;
      if (this.title === "Batch Info") {
        let obj = {
          info: Object.assign(this.info, {
            size: this.page.size,
            current: this.page.current,
          }),
          title: "total",
        };
        this.$emit("handleDetail", obj);
      } else if(this.title === 'Booked DN') {
        let obj = {
          info: Object.assign(this.info, {
            size: this.page.size,
            current: this.page.current,
          }),
          title: "book",
        };
        this.$emit("handleDetail", obj);
      }
    },
  },
};
</script>
<style lang="scss" scoped>

</style>
