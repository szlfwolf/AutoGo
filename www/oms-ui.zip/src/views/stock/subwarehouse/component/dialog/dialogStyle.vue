<template>
  <div v-loading="stcokLoading">
    <el-dialog :title="titleName" :visible="dialogStyleView" width="30%" style="font-weight: 700" @close="getClose"
      :close-on-click-modal="false">
      <!-- Transfer -->
      <div v-if="titleName === 'Transfer' || titleName === 'Convert'">
        <el-row>
          <el-col style="padding: 0 0 15px 19px; box-sizing: border-box">
            <label v-if="titleName === 'Transfer'" style="margin: 0 12px 0 1px" for="">Owner:</label>
            <label v-if="titleName === 'Convert'" style="margin: 0 12px 0 31px" for="">Owner:</label>
            <span>{{ clientCode }}</span>
          </el-col>
        </el-row>
        <el-form ref="transferForm" :rules="ruleTransfer" :model="form" label-width="80px"
          v-if="titleName === 'Transfer'">
          <el-row>
            <el-col :span="12">
              <el-form-item label="From:">
                <el-select filterable v-model="form.fromWarehouseCode" placeholder="From" disabled>
                  <el-option v-for="item in warehouseByClient2" :key="item.value" :label="item.warehouseName"
                    :value="item.warehouseCode">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="To:" prop="toWarehouseCode">
                <el-select filterable v-model="form.toWarehouseCode" placeholder="to" clearable>
                  <el-option v-for="item in warehouseByClient" :key="item.value" :label="item.warehouseName"
                    :value="item.warehouseCode">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-form-item label="Remark:" prop="remark">
            <el-input type="textarea" v-model="form.remark" placeholder="Remark"></el-input>
          </el-form-item>
        </el-form>
        <el-form ref="convertForm" :rules="ruleConvert" :model="form2" label-width="100px" v-if="titleName === 'Convert'">
          <el-form-item label="Warehouse:" style="margin-left:10px">
            <el-input v-model="form2.warehouseCode" placeholder="Warehouse" disabled></el-input>
          </el-form-item>
          <el-form-item label="FromType:" style="margin-left: 11px" prop="fromType">
            <el-select filterable v-model="form2.fromType" placeholder="Fromtype" clearable filterable
              @change="changeTypeSelect">
              <el-option v-for="item in type" :key="item.value" :label="item.label" :value="item.value">
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="ToType:" style="margin-left: 11px" prop="toType">
            <el-select filterable v-model="form2.toType" placeholder="Totype" clearable filterable
              @change="changeTypeSelect2">
              <el-option v-for="item in type2" :key="item.value" :label="item.label" :value="item.value">
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="Remark:" style="margin-left: 11px" prop="remark">
            <el-input type="textarea" v-model="form2.remark" placeholder="Remark"></el-input>
          </el-form-item>
        </el-form>
      </div>
      <div v-if="titleName === 'Kit' || titleName === 'Disassemble'">
        <el-row>
          <el-col style="padding-left: 39px">
            <label for="">Owner:</label>
            <span style="margin-left: 10px">{{ kitForm.clientCode }}</span>
          </el-col>
          <el-col style="padding-left: 55px">
            <label for="">SKU:</label>
            <span style="margin-left: 10px">{{ kitForm.partNumber }}</span>
          </el-col>
          <el-col style="padding-left: 10px">
            <label for="">Warehouse:</label>
            <span style="margin-left: 10px">{{ kitForm.warehouseCode }}</span>
          </el-col>
        </el-row>
        <el-form ref="form3" :rules="form3Rules" :model="form3" label-width="100px">
          <el-form-item label="Qty:" prop="qty">
            <el-input v-model="form3.qty" placeholder="Qty" @input="inputChangeValue"></el-input>
          </el-form-item>
          <el-form-item label="Remark:">
            <el-input v-model="form3.remark" placeholder="Remark"></el-input>
          </el-form-item>
        </el-form>
      </div>
      <!-- Transfer / Convert -->
      <el-form ref="formRef" :model="formRef">
        <el-table ref="multipleTable" :data="formRef.tableDataTransfer" tooltip-effect="dark" style="width: 100%"
          v-if="titleName === 'Transfer' || titleName === 'Convert'">
          <el-table-column label="Sku" align="center">
            <template slot-scope="scope" prop="skuNo">
              <el-form-item :prop="'tableDataTransfer.' + scope.$index + '.sku'" :rules="formQtyFn(scope.row,'sku')"
                style="margin-bottom: 0">
                <el-input v-model="scope.row.skuNo" placeholder="sku" @blur="changeInpt(scope.row)"></el-input>
              </el-form-item>
            </template>
          </el-table-column>
          <el-table-column label="Available Qty" min-width="120px" align="center">
            <template slot-scope="scope">{{ scope.row.availableQty || "0" }}</template>
          </el-table-column>
          <el-table-column label="Qty" align="center">
            <template slot-scope="scope">
              <el-form-item :prop="'tableDataTransfer.' + scope.$index + '.qty'" :rules="formQtyFn(scope.row,'qty')"
                style="margin-bottom: 0">
                <el-input v-model="scope.row.qty" @input="qtyInput" placeholder="Qty"></el-input>
              </el-form-item>
            </template>
          </el-table-column>
          <el-table-column label="Opearter" align="center">
            <template slot-scope="scope">
              <i style="font-size: 18px; cursor: pointer" class="el-icon-delete"
                @click="handleDelete(scope.$index, formRef.tableDataTransfer)"></i>
            </template>
          </el-table-column>
        </el-table>
      </el-form>
      <!-- Kit -->
      <div style="display: flex" v-if="titleName === 'Kit'">
        <span style="margin-top: 10px"> Kit Stock:</span>
        <el-table ref="multipleTable" :data="kitTableList" tooltip-effect="dark" style="width: 100%" flex:1>
          <el-table-column label="SKU" align="center" min-width="140px" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.partNumber || 0 }}</template>
          </el-table-column>
          <el-table-column label="Qty" align="center">
            <template slot-scope="scope">{{ scope.row.num || 0 }}</template>
          </el-table-column>
          <el-table-column label="Kit Stock" align="center">
            <template slot-scope="scope">{{ "-" + scope.row.sum || 0 }}</template>
          </el-table-column>
        </el-table>
      </div>
      <!-- Disassemble  -->
      <div style="display: flex" v-if="titleName === 'Disassemble'">
        <span style="margin-top: 10px"> Disassemble Stock:</span>
        <el-table ref="multipleTable" :data="kitTableList" tooltip-effect="dark" style="width: 100%" flex:1>
          <el-table-column label="SKU" align="center" min-width="140px" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.partNumber || 0 }}</template>
          </el-table-column>
          <el-table-column label="Qty" align="center">
            <template slot-scope="scope">{{ scope.row.num || 0 }}</template>
          </el-table-column>
          <el-table-column label="Disassemble Stock" align="center" min-width="140px">
            <template slot-scope="scope">{{ "+" + scope.row.sum || 0 }}</template>
          </el-table-column>
        </el-table>
      </div>
      <span v-if="titleName === 'Transfer' || titleName === 'Convert'" slot="footer" class="dialog-footer box"
        style="font-size: 24px; color: #59a6f9; margin-bottom: 10px">
        <div>
          <i class="el-icon-circle-plus-outline" style="margin-right: 20px; cursor: pointer" @click="addRows()"></i>
        </div>
        <!-- @click="changeType" -->
        <div>
          <!-- form2.fromType ||  -->
          <i :class="titleName === 'Transfer' || titleName === 'Convert' ? '' : 'cover'" class="el-icon-upload"
            style="cursor: pointer" @click="$refs.excelUpload.show()" v-if="permissions.stock_skuwarehousestock_import">
          </i>
        </div>
      </span>
      <span slot="footer" class="dialog-footer box">
        <el-button type="info" @click="getClose">Cancel</el-button>
        <el-button type="primary" @click="handleClick">Confrim</el-button>
      </span>
    </el-dialog>
    <!--excel 模板导入 -->
    <excel-upload ref="excelUpload" :title="uploadTitle" :url="url" temp-name="partNumber-available-qty-template.xlsx"
      temp-url="/admin/sys-file/local/partNumber-available-qty-template.xlsx"
      @refreshDataList="handleRefreshChange"></excel-upload>
  </div>
</template>
<script>
import { mapGetters } from "vuex";
import ExcelUpload from "@/components/upload/excel";
import { skuStockTransfer, updateSkuQtyByType, skuKitBaleOrUnpacking, getWarehouseByClient, getSkuAvailableQtyQuery} from "@/api/stock/subwarehouse";
import { remote } from "@/api/admin/dict";
export default {
  name: "DialogStyle",
  data() {
    return {
      form: {
        fromWarehouseCode: this.warehouseCode,
        toWarehouseCode: undefined,
        remark: undefined,
      },
      form2: {
        remark: undefined,
        warehouseCode: undefined,
        type: undefined,
        toType: undefined,
      },
      form3: {
        qty: 1,
        remark: undefined,
      },
      formRef: {
        tableDataTransfer: [
          {
            skuNo: undefined,
            availableQty: undefined,
            qty: undefined,
          },
        ],
      },
      warehouseByClient: [],
      warehouseByClient2: [],
      tableDataKit: [],
      tableDataDisassemble: [],
      type: [],
      type2: [],
      stcokLoading:false,
      url: `/stock/skuwarehousestock/uploadSkuNoByExcel?warehouseCode=${this.warehouseCode}`,
      toType: "",
      availableQty: 0,
      qtyNumber: 0,
      ruleTransfer: {
        toWarehouseCode: [
          { required: true, message: "请选择仓库", trigger: "change" },
        ],
        remark: [
          { required: true, message: "请输入备注", trigger: "blur" },
          { max: 255, message: "长度最大 255 个字", trigger: "blur" },
        ],
      },
      ruleConvert: {
        fromType: [
          { required: true, message: "请选择FromType", trigger: "change" },
        ],
        toType: [
          { required: true, message: "请选择ToType", trigger: "change" },
        ],
        remark: [
          { required: true, message: "请输入备注", trigger: "blur" },
          { max: 255, message: "长度最大 255 个字", trigger: "blur" },
        ],
      },
      form3Rules:{
        qty:[
          { required: true, message: "请输入qty的值", trigger: "blur" },
          { validator: (rule, value, callback) => {
            let reg = /^([1-9]{1}\d*)$/  
            console.log(reg.test(value));
            if(value && value <= 0 || !reg.test(value)){
              callback(new Error('qty的值只能为正整数'));
            }else{
              callback()
            }
          },
            trigger:'change'
          }
        ]
      },
    };
  },
  props: {
    titleName: {
      type: String,
    },
    dialogStyleView: {
      type: Boolean,
    },
    kitForm: {
      type: Object,
    },
    kitTableList: {
      type: Array,
    },
    warehouseCode: {
      type: String,
    },
    clientCode: {
      type: String,
    },
    uploadTitle: {
      type: String,
    },
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  components: {
    ExcelUpload,
  },
  created() {
    if (this.titleName === "Transfer") {
      this.getWarehouseByClient();
    }else if(this.titleName === "Convert"){
      this.getRemote();
    }
    // this.getWarehouseByClient();
    // this.getRemote();
    this.form2.warehouseCode = this.warehouseCode;
  },
  mounted(){
    this.handleClick = this.$btn(this.handleClick,500)
  },
  methods: {
    formQtyFn(row, type) {
      if(type === 'sku'){
        if (!row.skuNo) {
          return { required: true, trigger: "change" };
        } 
      }else{
        if (!row.qty) {
          return { required: true, trigger: "change" };
        } else {
          if (row.availableQty < Number(row.qty)) {
            return {
              validator: (rule, value, callback) => {
                callback(new Error());
              },
              trigger: "change",
            };
          }
          return [{ required: false, trigger: "change" },
          { pattern:/^([1-9]{1}\d*)$/, trigger: 'change' },];
        }
      }
    },
    // changeType() {
    //   if (this.titleName === "Convert") {
    //     if (this.form2.fromType) {
    //       console.log(this.form2.fromType);
    //       return;
    //     }
    //     this.$message.warning("Please select a Type first");
    //   }
    // },
    //导入
    handleRefreshChange(e) {
      console.log(e);
      // this.$emit("formClose", false,)
      if(e === 'loading'){
        this.stcokLoading = true
        return
      }
      // this.stcokLoading = false
      if (e) {
        e.data.forEach(item=> {
          item.skuNo = item.partNumber
        })
        this.formRef.tableDataTransfer = e.data;
        // this.formRef.tableDataTransfer.forEach((ite) => {
        //   ite.skuNo = ite.partNumber
        //   // ite.qty = ite.num;
        // });
        let type = this.form2.fromType;
        if (type) {
          this.formRef.tableDataTransfer.forEach((ite) => {
            for (let key in ite) {
              if (key.includes(type)) {
                // console.log(key);
                // console.log(ite[key]);
                ite.availableQty = ite[key];
              }
            }
          })
        }
      }
    },
    //qty值改变
    inputChangeValue(e) {
      this.kitTableList.forEach((ite) => {
        this.$set(ite, "sum", e * ite.num);
      });
    },
    //sku
    changeInpt(data) {
      console.log(this.form2.fromType);
      let type = this.form2.fromType;
      // console.log(data,'data00000');
      if (data.skuNo) {
        getSkuAvailableQtyQuery({
          skuNo: data.skuNo,
          warehouseCode: this.warehouseCode,
        }).then((res) => {
          console.log(res);
          if (res.data.code === 0) {
            const dataType = res.data.data;
            if (type) {
              for (let key in dataType) {
                if (key.includes(type)) {
                  data.availableQty = dataType[key];
                  this.availableQty = data.availableQty;
                  console.log(this.availableQty);
                }
              }
            } else {
              data.availableQty = res.data.data.availableQty;
              this.availableQty = data.availableQty;
              console.log(this.availableQty);
            }
            data.skuNo = dataType.partNumber;
          }
        });
      }
    },
    //判断Qty值
    qtyInput(e) {
      console.log(e);
      this.qtyNumber = e;
    },
    //添加行
    addRows() {
      console.log(this.formRef, "this.formRef");
      this.formRef.tableDataTransfer.push({
        availableQty: "",
      });
    },
    //删除行
    handleDelete(index, rows) {
      rows.splice(index, 1);
    },
    getClose() {
      this.$emit("formClose", false, "cancel");
      // this.form = Object.assign({}, {fromWarehouseCode: this.warehouseCode,toWarehouseCode: undefined,remark: undefined});
      // this.form2 = Object.assign( {}, {remark: undefined, warehouseCode: this.warehouseCode,type: undefined});
      // this.form3 = Object.assign({}, { qty: 1, remark: undefined });
      // this.formRef.tableDataTransfer.forEach(ite=>{
      //  ite.warehouseCode= undefined,ite.availableQty=undefined,ite.qty= undefined,ite.skuNo=undefined
      // })
      // // this.formRef.tableDataTransfer = [{warehouseCode:undefined,availableQty:undefined,qty:undefined,skuNo:undefined}]
      // if (this.titleName === "Transfer") {
      //   this.$refs.transferForm.resetFields();
      //   this.$refs.formRef.resetFields();
      // } else if (this.titleName === "Convert") {
      //   this.$refs.convertForm.resetFields();
      //   this.$refs.formRef.resetFields();
      // }
    },
    //查询仓库..
    getWarehouseByClient() {
      getWarehouseByClient().then((res) => {
        if (res.data.code === 0) {
          let data = res.data.data;
          this.warehouseByClient = data.filter((ite) => {
            return ite.warehouseCode !== this.warehouseCode;
          });
          this.warehouseByClient2 = data.filter((ite) => {
            return ite.warehouseCode == this.warehouseCode;
          });
        }
      });
    },
    //confirm
    handleClick() {
      if (this.titleName === "Transfer") {
        this.$refs.transferForm.validate((valid) => {
          if (!valid) return false;
          this.$refs.formRef.validate((valid) => {
            if (!valid) return false;
            skuStockTransfer(
              Object.assign(
                { updateSkuList: this.formRef.tableDataTransfer },
                this.form
              )
            ).then((res) => {
              if (res.data.code === 0) {
                this.$message.success("Transfer success");
                this.$emit("formClose", false);
              } else {
                this.$message.error(res.data.msg);
                this.$emit("formClose", false);
              }
            });
          });
        });
      } else if (this.titleName === "Convert") {
        this.$refs.convertForm.validate((valid) => {
          if (!valid) return false;
          this.$refs.formRef.validate((valid) => {
            if (!valid) return false;
            updateSkuQtyByType(
              Object.assign(
                { skuList: this.formRef.tableDataTransfer },
                this.form2
              )
            ).then((res) => {
              if (res.data.code === 0) {
                this.$message.success("Convert success");
                this.$emit("formClose", false);
              } else {
                this.$message.error(res.data.msg);
                this.$emit("formClose", false);
              }
            });
          });
        });
      } else if (this.titleName === "Kit") {
        this.$refs.form3.validate((valid) => {
          if (!valid) return false;
          skuKitBaleOrUnpacking(
            Object.assign(
              {
                baleOrUnpacking: "bale",
                warehouseCode: this.kitForm.warehouseCode,
                skuNo: this.kitForm.partNumber,
              },
              this.form3
            )
          ).then((res) => {
            console.log(res);
            if (res.data.code === 0) {
              this.$message.success("Kit success");
              this.$emit("formClose", false);
            } else {
              this.$message.error(res.data.msg);
              this.$emit("formClose", false);
            }
          });
        })
      } else {
        this.$refs.form3.validate((valid) => {
          if (!valid) return false;
          skuKitBaleOrUnpacking(
            Object.assign(
              {
                baleOrUnpacking: "unpacking",
                warehouseCode: this.kitForm.warehouseCode,
                skuNo: this.kitForm.partNumber,
              },
              this.form3
            )
          ).then((res) => {
            console.log(res);
            if (res.data.code === 0) {
              this.$message.success("Disassemble success");
              this.$emit("formClose", false);
            } else {
              this.$message.error(res.data.msg);
              this.$emit("formClose", false);
            }
          });
        })
      }
    },
    //type下拉
    getRemote() {
      remote("inventory_type").then((res) => {
        if (res.data.code === 0) {
          this.type = res.data.data;
          console.log(this.type);
        }
      });
    },
    //Convert选择触发事件
    changeTypeSelect(e) {
      // this.form2.toType = "";
      if (e !== "available") {
        this.form2.type = e;
        this.type2 = this.type.filter((ite) => ite.value === "available");
        this.form2.status = "deduct";
      } else {
        this.type2 = this.type.filter((ite) => ite.value !== "available");
        this.toType = e;
        this.form2.status = "add";
        this.form2.toType = "";
      }
      if(this.formRef.tableDataTransfer.length>0){
        this.formRef.tableDataTransfer.forEach(ite=>{
          this.changeInpt(ite)
        })
      }
    },
    changeTypeSelect2(e) {
      if (this.toType) {                                                          
        this.form2.type = e;
      }
    },
  },
};
</script>
<style lang="scss" scoped>
.box {
  display: flex;
  justify-content: center;
}

.cover {
  pointer-events: none;
  cursor: default;
}
</style>
