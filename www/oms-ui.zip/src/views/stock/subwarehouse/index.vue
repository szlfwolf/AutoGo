<template>
  <div class="content">
    <el-tabs type="border-card" v-model="activeName" @tab-click="handleClick">
      <el-tab-pane label="Warehouse view" name="Warehouse" v-if="permissions.stock_skuwarehousestock_part"
        v-loading="stcokLoading">
        <el-row style="width:200px;display:flex">
          <el-col>
            <el-button type="primary" icon="el-icon-search" @click="getSearchlist">Query</el-button>
          </el-col>
          <el-col>
            <el-button icon="el-icon-refresh-left" @click="getReset">Reset</el-button>
          </el-col>
        </el-row>
        <el-form ref="form" :model="form" style="margin: 20px 0" @keyup.enter.native="getSearchlist">
          <el-row>
            <el-col>
              <el-radio-group v-model="form.warehouseCode" v-for="(ite, index) in warehouseByClient" :key="index">
                <el-radio :label="ite.warehouseCode" style="margin-right:10px"
                  @change="getRadio">{{ ite.warehouseName }}</el-radio>
              </el-radio-group>
            </el-col>
            <el-col :span="4" style="margin-top: 10px">
              <el-input v-model="form.skuNo" placeholder="Sku no"></el-input>
            </el-col>
          </el-row>
        </el-form>
        <div class="down">
          <div>
            <el-button type="primary" icon="el-icon-document-remove" @click="changeStyle('Transfer')"
              v-if="permissions.stock_skuwarehousestock_transfer">Transfer</el-button>
            <!-- :disabled="multipleSelection.length !== 1 || isKit.totalNum <= 0" -->
            <el-button type="primary" class="iconfont icon-shuyi_qiehuan" style="font-size:12px;height:33px"
              @click="changeStyle('Convert')" v-if="permissions.stock_skuwarehousestock_transfer">Convert</el-button>
            <!-- :disabled="multipleSelection.length !== 1 || isKit.totalNum <= 0" -->
            <el-button type="primary" icon="el-icon-heavy-rain" @click="changeDestory"
              :disabled="multipleSelection.length !== 1 || isKit.scrapNum <= 0"
              v-if="permissions.stock_skuwarehousestock_skuStockDestroy">Destory</el-button>
            <el-button type="primary" icon="el-icon-s-goods" @click="changeStyle('Kit')"
              :disabled="multipleSelection.length !== 1 || isKit.isKit !== 'y'"
              v-if="permissions.master_skukitmapping_get">kit</el-button>
            <el-button type="primary" icon="el-icon-s-unfold" @click="changeStyle('Disassemble')"
              :disabled="multipleSelection.length !== 1 || isKit.isKit !== 'y'"
              v-if="permissions.master_skukitmapping_get">Disassemble</el-button>
          </div>
          <div>
            <el-button icon="el-icon-upload2" @click="$refs.excelUpload.show()"
              v-if="permissions.stock_skuwarehousestock_uploadYearAndReportByExcel">Year end report</el-button>
            <el-button icon="el-icon-download" @click="exportExcel"
              v-if="permissions.stock_skuwarehousestock_export_part"></el-button>
          </div>
        </div>
        <el-table border ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%"
          v-loading="dataListLoading" @selection-change="handleSelectionChange"
          :header-cell-style="{ background: '#f5f7fa', color: '#606266' }">
          <el-table-column type="selection" min-width="55" align="center"> </el-table-column>
          <el-table-column label="Owner" align="center">
            <template slot-scope="scope">{{ scope.row.clientCode || '-' }}</template>
          </el-table-column>
          <el-table-column label="Warehouse" min-width="120" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.warehouseCode || '-' }}</template>
          </el-table-column>
          <el-table-column label="Sku no" min-width="140" align="center">
            <template slot-scope="scope">{{ scope.row.partNumber || '-' }}</template>
          </el-table-column>
          <el-table-column label="Total Qty" min-width="120" align="center">
            <template slot-scope="scope">
              <div class="underLine" @click="handleDetail(scope.$index, scope.row, 'total')"
                v-if="permissions.stock_skubatch_getBatchByQuery">{{ scope.row.totalNum || '0' }}</div>
              <div v-else>{{ scope.row.totalNum || '0' }}</div>
            </template>
          </el-table-column>
          <el-table-column label="Available Qty" min-width="120" align="center">
            <template slot-scope="scope">{{ scope.row.availableQty < 0 ? '0' : scope.row.availableQty || '0' }}</template>
          </el-table-column>
          <el-table-column label="Booked Qty" min-width="120" align="center">
            <template slot-scope="scope">
              <div class="underLine" @click="handleDetail(scope.$index, scope.row, 'book')"
                v-if="permissions.stock_skuwarehousestock_booked">{{ scope.row.bookedQty || '0' }}</div>
              <div v-else>{{ scope.row.bookedQty || '0' }}</div>
            </template>
          </el-table-column>
          <el-table-column label="Block Qty" min-width="120" align="center">
            <template slot-scope="scope">{{ scope.row.blockNum || '0' }}</template>
          </el-table-column>
          <el-table-column label="Hold Qty" min-width="120" align="center">
            <template slot-scope="scope">{{ scope.row.holdNum || '0' }}</template>
          </el-table-column>
          <el-table-column label="Quality Qty" min-width="120" align="center">
            <template slot-scope="scope">{{ scope.row.qualityNum || '0' }}</template>
          </el-table-column>
          <el-table-column label="Damage Qty" min-width="120" align="center">
            <template slot-scope="scope">{{ scope.row.damageNum || '0' }}</template>
          </el-table-column>
          <el-table-column label="Scrap Qty" min-width="120" align="center">
            <template slot-scope="scope">{{ scope.row.scrapNum || '0' }}</template>
          </el-table-column>
          <el-table-column label="Reserve" min-width="120" align="center">
            <template slot-scope="scope">{{ scope.row.reserveNum || '0' }}</template>
          </el-table-column>
          <!-- <el-table-column label="Client Stock Total" min-width="120" align="center">
            <template slot-scope="scope">{{ scope.row.spare2 || '0' }}</template>
          </el-table-column>
          <el-table-column label="Wms Stock Total" min-width="120" align="center">
            <template slot-scope="scope">{{ scope.row.spare3 || '0' }}</template>
          </el-table-column> -->
          <el-table-column label="Intransit Qty" min-width="120" align="center">
            <template slot-scope="scope">
              <div class="underLine" @click="handleDetail(scope.$index, scope.row, 'intransit')"
                v-if="permissions.stock_skuwarehousestock_getIntransitDetail">{{ scope.row.intransitQty || '0' }}</div>
              <div v-else>{{ scope.row.intransitQty || '0' }}</div>
            </template>
          </el-table-column>
          <el-table-column label="Shipped Qty" min-width="120" align="center">
            <template slot-scope="scope">{{ scope.row.shippedQty || 0 }}</template>
          </el-table-column>
          <el-table-column label="Not Inbound Qty" min-width="140" align="center">
            <template slot-scope="scope">{{ scope.row.notArrivedQty || 0 }}</template>
          </el-table-column>
          <el-table-column label="Not Finished Qty" min-width="140" align="center">
            <template slot-scope="scope">{{ scope.row.notFinishedQty || 0 }}</template>
          </el-table-column>
          <el-table-column label="GR Discrepancy Qty" min-width="140" align="center">
            <template slot-scope="scope">{{ scope.row.grDisc || 0 }}</template>
          </el-table-column>
          <el-table-column label="Transfer Lost Qty" min-width="140" align="center">
            <template slot-scope="scope">
              <div class="underLine" @click="handleDetail(scope.$index, scope.row, 'lostQty')"
                v-if="permissions.stock_skuwarehousestock_booked">{{ scope.row.transferLostNum || '0' }}</div>
              <div v-else>{{ scope.row.transferLostNum || '0' }}</div>
            </template>
          </el-table-column>
          <el-table-column fixed="right" label="Opearter" align="center"
            v-if="permissions.stock_skuwarehousestock_updateTotalStock">
            <template slot-scope="scope">
              <i style="font-size: 18px; cursor: pointer; color: #65beff" class="el-icon-edit"
                @click="handleEdit(scope.$index, scope.row)"
                v-if="permissions.stock_skuwarehousestock_updateTotalStock"></i>
            </template>
          </el-table-column>
        </el-table>
        <Pagination @handleSizeChange="handleSizeChange" @handleCurrentChange="handleCurrentChange"
          :pageNum="page.current" :pageSize="page.size" :total="total"></Pagination>
        <Dialog ref="dialog" :title="title" :dialogView="dialogView" :BatchByQuery="BatchByQuery" :exportData="exportData"
          :info="info" :titleForm="titleForm" @close="getClose" @handleDetail="handleDetailDialog"></Dialog>
        <DialogStyle v-if="showDialog" :titleName="titleName" :uploadTitle="uploadTitle"
          :dialogStyleView="dialogStyleView" :kitForm="kitForm" :kitTableList="kitTableList"
          :warehouseCode="warehouseCodeNum" :clientCode="clientCode" ref="dialogRaidio" @formClose="formClose">
        </DialogStyle>
        <el-dialog title="Edit" :visible.sync="remarkDialogVisible" width="35%" style="font-weight: 700"
          @close="remarkClose" :close-on-click-modal="false">
          <el-form :model="remarkDialog" ref="remarkDialog" :rules="remarkRules" label-width="140px">
            <el-form-item label="Sku No:">
              <el-input v-model="remarkDialog.skuNo" disabled></el-input>
            </el-form-item>
            <el-form-item label="Adjust inventory:" prop="adjustInventory">
              <el-input v-model="remarkDialog.adjustInventory"></el-input>
            </el-form-item>
            <el-form-item label="Remark:" prop="remark">
              <el-input type="textarea" v-model="remarkDialog.remark"></el-input>
            </el-form-item>
          </el-form>
          <span slot="footer" class="dialog-footer">
            <el-button type="info" @click="remarkDialogVisible = false">Cancel</el-button>
            <el-button type="primary" @click="dialogButton">Submit</el-button>
          </span>
        </el-dialog>
      </el-tab-pane>
      <el-tab-pane label="Overview" name="Overview" v-if="permissions.stock_skuwarehousestock_summary">
        <Overview v-if="show"></Overview>
      </el-tab-pane>
    </el-tabs>
    <!--excel 模板导入 -->
    <excel-upload ref="excelUpload" title="Year end inventory upload"
      url="/stock/skuwarehousestock/uploadYearAndReportByExcel" temp-name="year-end-report-template.xlsx"
      temp-url="/admin/sys-file/local/year-end-report-template.xlsx"
      @refreshDataList="handleRefreshChange"></excel-upload>
    <!-- :typeStatus="typeStatus"
    @optionStatus="optionStatus" -->
  </div>
</template>
<script>
import { mapGetters } from "vuex"
import Pagination from "@/components/pagination/pagination.vue"
import Overview from "./component/Overview.vue"
import Dialog from "./component/dialog/dialog.vue"
import DialogStyle from "./component/dialog/dialogStyle.vue"
import ExcelUpload from "@/components/upload/excel"
import { getWarehouseByClient, getStockByQuery, getBatchByQuery, getBookedDNByQuery, 
getKitByPartNumber, skuStockDestroy, getIntransitDetail, updateTotalStock, getTransferLogs } from "@/api/stock/subwarehouse"
let formParams = {
  skuNo: undefined,
  warehouseCode: undefined,
}
export default {
  name: "Order",
  data() {
    return {
      info: {},
      form: Object.assign({}, formParams),
      total: 0,
      page: {
        size: 10,
        current: 1,
      },
      dataListLoading: false,
      title: "", //表格dialog标题
      titleName: "", //表单
      dialogStyleView: false, //表单
      dialogView: false, //表格
      formDialog: {
        warehouse: "",
        remark: "",
      },
      activeName: "Warehouse",
      options: [],
      tableData: [],
      multipleSelection: [],
      show: false,
      warehouseByClient: [],
      BatchByQuery: {},//批次Total数据
      exportData: {},//下载传参
      titleForm: {},//Booked表单数据
      isKit: '',//Kit状态
      kitForm: {},//kit表单数据
      kitTableList: [],//kit表格数据
      showDialog: false,
      warehouseCodeNum: '',
      clientCode: '',
      // url:'',
      typeStatus: 'open',
      uploadTitle: "",
      stcokLoading: false,
      remarkRules: {
        adjustInventory: [
          { required: true, message: "请输入TotalQty", trigger: "blur" },
          { pattern: /^-?[0-9]\d*$/, message: "请输入整数", trigger: 'blur' }],
        remark: [
          { required: true, message: "请输入备注", trigger: "blur" },
          { max: 255, message: "长度最大 255 个字符", trigger: "blur" },
        ],
      },
      remarkDialog: {
        skuNo: '',
        remark: ""
      },
      remarkDialogVisible: false
    }
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  mounted() {
    this.exportExcel = this.$btn(this.exportExcel, 500)
  },
  components: {
    Pagination,
    Overview,
    Dialog,
    DialogStyle,
    ExcelUpload,
  },
  created() {
    this.getWarehouseByClient()//查询仓库
  },
  methods: {
    //获取导入的下拉值
    // optionStatus(e){
    //   this.url = `/stock/skuwarehousestock/uploadYearAndReportByExcel?warehouseCode=${e}`
    // },
    //导入
    handleRefreshChange(e) {
      console.log(e);
      if (e === 'loading') {
        this.stcokLoading = true
        return
      }
      this.stcokLoading = false
      this.getList()
    },
    //切换
    handleClick() {
      if (this.activeName === "Overview") {
        this.show = true
      } else {
        this.show = false
        this.getList()
      }
    },
    //查询仓库..
    getWarehouseByClient() {
      // if(this.permissions.stock_skuwarehousestock_summar){
      getWarehouseByClient().then(res => {
        console.log(res)
        if (res.data.code === 0) {
          this.warehouseByClient = res.data.data
          this.form.warehouseCode = this.warehouseByClient[0].warehouseCode
          this.getList()
        }
      })
      // }else{
      //   this.$message.error('当前暂无权限')
      // }
    },
    //导出
    exportExcel() {
      this.stcokLoading = true
      this.downBlobFile("/stock/skuwarehousestock/exportByStock", { partNumber: this.form.skuNo, warehouseCode: this.form.warehouseCode }, `${this.$store.state.common.commandName}-skuwarehousestock-${this.toDateFormat(new Date(), true)}.xlsx`, () => this.stcokLoading = false)
    },
    //条数
    handleSizeChange(val) {
      this.page.current = 1
      this.page.size = val
      this.getList(this.form)
    },
    //当前页数
    handleCurrentChange(val) {
      this.page.current = val
      this.getList(this.form)
    },
    //清空
    getReset() {
      this.form = Object.assign({}, formParams)
      this.form.warehouseCode = this.warehouseByClient[0].warehouseCode
      this.page = this.$options.data().page
      this.getList()
    },
    //仓库选泽
    getRadio() {
      this.showDialog = false
      this.getSearchlist()
    },
    //查询
    getSearchlist() {
      this.page.current = 1
      if (this.form.skuNo === '' || this.form.skuNo === null) {
        this.form.skuNo = undefined
      }
      this.getList(this.form)
    },
    //数据列表
    getList(params) {
      this.dataListLoading = true
      getStockByQuery(Object.assign({ ...this.page, warehouseCode: this.form.warehouseCode }, params)).then(res => {
        console.log(res)
        if (res.data.code === 0) {
          this.tableData = res.data.data.records
          this.total = res.data.data.total
          if (this.tableData.length > 0) {
            this.clientCode = this.tableData[0].clientCode
          }
          this.dataListLoading = false
        } else {
          this.$message.error(res.data.msg)
          this.dataListLoading = false
        }
      }).catch(() => {
        this.$message.error('request was aborted')
        this.dataListLoading = false
      })
    },
    //单选
    handleSelectionChange(val) {
      this.multipleSelection = val
      if (val.length > 0) {
        this.isKit = val[0]
      }
      // if(this.multipleSelection.length>1){
      //   this.$message.warning('Only one can be selected')
      // }  
      if (val.length > 1) {
        this.$refs.multipleTable.clearSelection()
        this.$refs.multipleTable.toggleRowSelection(val.pop())
      }
    },
    //销毁
    changeDestory() {
      this.dialogStyleView = false
      this.$confirm('This operation will permanently delete this data. Do you want to continue?', 'Tips', {
        confirmButtonText: 'submit',
        cancelButtonText: 'cancel',
        type: 'warning'
      }).then(() => {
        skuStockDestroy({ warehouseCode: this.multipleSelection[0].warehouseCode, skuNo: this.multipleSelection[0].partNumber }).then(res => {
          if (res.data.code === 0) {
            this.getList(this.form)
            this.$message.success('Destruction succeeded!')
          } else {
            this.$message.error(res.data.msg)
          }
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: 'Destruction cancelled'
        })
      })
    },
    //打开表单dialogStyle
    changeStyle(type) {
      this.showDialog = true
      this.titleName = type
      if (type === 'Transfer') {
        this.warehouseCodeNum = this.form.warehouseCode
        this.uploadTitle = 'Transfer Information import upload'
        this.dialogStyleView = true
      } else if (type === 'Convert') {
        this.uploadTitle = 'Convert Information import upload'
        this.warehouseCodeNum = this.form.warehouseCode
        this.dialogStyleView = true
      } else if (type === "Kit") {
        this.kitForm = this.multipleSelection[0]
        getKitByPartNumber({ partNumber: this.multipleSelection[0].partNumber }).then(res => {
          console.log(res)
          if (res.data.code === 0) {
            this.dialogStyleView = true
            this.kitTableList = res.data.data
            this.kitTableList.forEach(ite => {
              this.$set(ite, 'sum', ite.num)
            })
          }
        })
      } else {
        this.kitForm = this.multipleSelection[0]
        getKitByPartNumber({ partNumber: this.multipleSelection[0].partNumber }).then(res => {
          console.log(res)
          if (res.data.code === 0) {
            this.dialogStyleView = true
            this.kitTableList = res.data.data
            this.kitTableList.forEach(ite => {
              this.$set(ite, 'sum', ite.num)
            })
          }
        })
      }
    },
    //打开表格dialog
    handleDetail(index, row, type, e) {
      this.info = { ...row, current: 1, size: 10 }
      // this.info = row
      if (type === "total") {
        this.title = "Batch Info"
        getBatchByQuery({ current: row.current || 1, size: row.size || 10, warehouseCode: row.warehouseCode, skuNo: row.partNumber, clientCode: row.clientCode }).then(res => {
          if (res.data.code === 0 && res.data.data.records.length > 0) {
            this.dialogView = true
            this.BatchByQuery = res.data.data
            this.exportData = { warehouseCode: row.warehouseCode, skuNo: row.partNumber, clientCode: row.clientCode }
          } else {
            this.$message.warning('No data')
          }
        })
      } else if (type === "book") {
        this.title = "Booked DN"
        this.titleForm = row
        getBookedDNByQuery({ current: row.current || 1, size: row.size || 10, warehouseCode: row.warehouseCode, skuNo: row.partNumber, clientCode: row.clientCode }).then(res => {
          if (res.data.code === 0 && res.data.data.records.length > 0) {
            this.dialogView = true
            this.BatchByQuery = res.data.data
            this.exportData = { warehouseCode: row.warehouseCode, skuNo: row.partNumber, clientCode: row.clientCode }
          } else {
            this.$message.warning('No data')
          }
        })
      } else if (type === "intransit") {
        this.title = "Intransit ASN"
        console.log(row);
        this.titleForm = row
        getIntransitDetail({ warehouseCode: row.warehouseCode, partNumber: row.partNumber, clientCode: row.clientCode }).then(res => {
          console.log(res);
          if (res.data.code === 0 && res.data.data.length > 0) {
            this.dialogView = true
            this.BatchByQuery = res.data
            this.exportData = { warehouseCode: row.warehouseCode, partNumber: row.partNumber, clientCode: row.clientCode }
          } else {
            this.$message.warning('No data')
          }
        })
      } else {
        this.title = "Transfer Lost List"
        this.titleForm = row
        getTransferLogs({ warehouseCode: row.warehouseCode, partNumber: row.partNumber, clientCode: row.clientCode }).then(res => {
          console.log(res);
          if (res.data.code === 0 && res.data.data.skuTransferLogs.length > 0) {
            this.dialogView = true
            this.BatchByQuery = res.data.data
            this.exportData = { warehouseCode: row.warehouseCode, partNumber: row.partNumber, clientCode: row.clientCode }
          } else {
            this.$message.warning('No data')
          }
        })
      }
    },
    //子传父改变表单dialogView状态
    formClose(e, type) {
      console.log(e, type);
      if (!type) {
        this.getList(this.form)
        console.log(e, type);
      }
      this.dialogStyleView = e
      //销毁dialogStyle
      this.showDialog = false
    },
    //调父方法
    handleDetailDialog(e) {
      console.log('448', e)
      this.handleDetail('', e.info, e.title)
    },
    //子传父改变表格dialog状态
    getClose(e) {
      this.dialogView = e
    },
    //编辑
    handleEdit(index, row) {
      this.remarkDialogVisible = true
      // this.remarkDialog = Object.assign({},{id:row.id,adjustInventory:row.adjustQty,remark:row.remark})
      this.remarkDialog = Object.assign({}, { id: row.id, skuNo: row.partNumber })
    },
    dialogButton() {
      this.$refs.remarkDialog.validate((valid) => {
        if (!valid) return false
        updateTotalStock(this.remarkDialog).then(res => {
          if (res.data.code == 0) {
            this.remarkDialogVisible = false
            this.$message.success('Update succeeded')
            this.getList(this.form)
          } else {
            this.remarkDialogVisible = false
            this.$message.error(res.data.msg)
          }
        }).catch(() => {
          this.remarkDialogVisible = false
        })
      })
    },
    remarkClose() {
      this.$refs.remarkDialog.resetFields();
    }
  },
} 
</script>
<style lang="scss" scoped>
.content {
  padding: 0 10px;

  // box-sizing: border-box;
  .down {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    border-top: 1px solid #999;
    padding-top: 20px;
    box-sizing: border-box;
  }

  .underLine {
    cursor: pointer;
    color: #599af8;
    text-decoration: underline;
  }

  ::v-deep .el-dialog {
    border-radius: 8px !important;
  }

  ::v-deep .el-select--small {
    display: block;
  }

  ::v-deep .el-table__header-wrapper .el-checkbox {
    //找到表头那一行，然后把里面的复选框隐藏掉
    display: none
  }

  ::v-deep .icon-shuyi_qiehuan:before {
    content: "\E660";
    margin-right: 5px;
  }
}
</style>

