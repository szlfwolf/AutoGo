<template>
  <div class="content">
    <el-tabs type="border-card">
      <el-row style="width: 200px; display: flex">
        <el-col>
          <el-button type="primary" icon="el-icon-search" @click="search()">Query</el-button>
        </el-col>
        <el-col>
          <el-button @click="resetForm('queryParam')" type="info" plain icon="el-icon-refresh-left">Reset</el-button>
        </el-col>
      </el-row>

      <el-form :model="queryParam" style="margin: 20px 0">
        <el-row :gutter="20">
          <el-col :span="4">
            <el-select v-model="queryParam.source" placeholder="Source" size="small" class="search" clearable filterable>
              <el-option v-for="item in sourceTypeList" :key="item.value" :label="item.value" :value="item.value">
              </el-option>
            </el-select>
          </el-col>

          <el-col :span="4">
            <el-select v-model="queryParam.target" placeholder="Target" size="small" class="search" clearable filterable>
              <el-option v-for="item in destinationList" :key="item.value" :label="item.value" :value="item.value">
              </el-option>
            </el-select>
          </el-col>

          <el-col :span="4">
            <el-select v-model="queryParam.bizType" placeholder="Biz Type" size="small" class="search" clearable
              filterable>
              <el-option v-for="item in msgTypeList" :key="item.value" :label="item.value" :value="item.value">
              </el-option>
            </el-select>
          </el-col>

          <el-col :span="4">
            <el-select v-model="queryParam.status" placeholder="Status" size="small" class="search" clearable filterable>
              <el-option v-for="item in statusList" :key="item.value" :label="item.label" :value="item.value">
              </el-option>
            </el-select>
          </el-col>

          <el-col :span="4">
            <el-input v-model="queryParam.bizNo" placeholder="Biz No" size="small" class="search"></el-input>
          </el-col>
          <el-col :span="4">
            <el-button style="margin-left: 20px; float: right" type="primary" @click="about"
              :icon="show ? 'el-icon-arrow-up' : 'el-icon-arrow-down'">
              <label for="">{{ show ? "收起" : "更多" }}</label>
            </el-button>
          </el-col>
        </el-row>

        <el-row v-show="show" :gutter="20">
          <el-col :span="4">
            <el-input v-model="queryParam.url" placeholder="Url" size="small" class="search"></el-input>
          </el-col>

          <el-col :span="4">
            <el-date-picker v-model="queryParam.optionTime" type="daterange" start-placeholder="StartDate"
              end-placeholder="EndDate" :default-time="['00:00:00', '23:59:59']" value-format="yyyy-MM-dd HH:mm:ss"
              @change="changeDateTimePicker">
            </el-date-picker>
          </el-col>
          <el-col :span="4">
            <el-date-picker v-model="queryParam.optionTime2" type="daterange" start-placeholder="RecallStartDate"
              end-placeholder="RecallEndDate" :default-time="['00:00:00', '23:59:59']" value-format="yyyy-MM-dd HH:mm:ss"
              @change="changeDateTimePicker2">
            </el-date-picker>
          </el-col>
        </el-row>
      </el-form>

      <!-- 数据表 -->
      <el-table :data="tableData.records" tooltip-effect="dark" stripe border ref="multipleTable" style="width: 100%"
        header-cell-class-name="header-cell-class" :header-cell-style="{
          background: '#f5f7fa',
          color: '#606266',
          'text-align': 'center',
        }">
        <el-table-column prop="source" label="Source" min-width="100px" align="center"
          show-overflow-tooltip></el-table-column>
        <el-table-column prop="target" label="Target" min-width="100px" align="center"
          show-overflow-tooltip></el-table-column>
        <el-table-column prop="bizNo" label="BizNo" min-width="200px" show-overflow-tooltip align="center"
          fixed="left"></el-table-column>
        <el-table-column prop="bizType" label="BizType" width="120px" align="center"
          show-overflow-tooltip></el-table-column>
        <el-table-column prop="url" label="Url" min-width="280px" show-overflow-tooltip></el-table-column>
        <el-table-column prop="protocolType" label="Protocol" width="120px" align="center"
          show-overflow-tooltip></el-table-column>
        <el-table-column prop="methodType" label="Method" width="120px" align="center"
          show-overflow-tooltip></el-table-column>
        <el-table-column prop="operateTime" label="Date/Time" width="160px" align="center"
          show-overflow-tooltip></el-table-column>
        <el-table-column prop="status" label="Status" width="90px" align="center">
          <template slot-scope="scope">
            <el-tag :type="scope.row.status === 'Y' ? 'success' : 'danger'">{{ formatStatue(scope.row.status) }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="costTime" label="CostTime" width="100px" align="center"></el-table-column>
        <el-table-column prop="retryNum" label="RetryNum" width="100px" align="center"></el-table-column> <el-table-column
          prop="createTime" label="CreateTime" width="140px" align="center" show-overflow-tooltip></el-table-column>
        <el-table-column prop="createBy" label="MsgId" width="140px" align="center"
          show-overflow-tooltip></el-table-column>
        <el-table-column prop="updateTime" label="UpdateTime" width="140px" align="center"
          show-overflow-tooltip></el-table-column>
        <el-table-column prop="updateBy" label="UpdateBy" width="140px" align="center"
          show-overflow-tooltip></el-table-column>
        <el-table-column label="Msg in" width="100px" align="center" fixed="right">
          <template slot-scope="scope">
            <el-button round type="text" icon="el-icon-view" size="medium"
              @click="msgView(scope.row, scope.row.requestId)" title="view Msg in" />
          </template>
        </el-table-column>

        <el-table-column label="Msg out" width="100px" align="center" fixed="right">
          <template slot-scope="scope">
            <el-button round type="text" icon="el-icon-view" size="medium"
              @click="msgView(scope.row, scope.row.responseId)" title="view Msg out" />
          </template>
        </el-table-column>

        <el-table-column label="Operate" width="100px" align="center" v-if="permissions.log_logmsg_recall" fixed="right">
          <template slot-scope="scope">
            <el-button type="text" icon="el-icon-refresh-left" size="medium" @click="msgOperation(scope.row)"
              title="Operate">Retry</el-button>
          </template>
        </el-table-column>
      </el-table>

      <Pagination @handleSizeChange="handleSizeChange" @handleCurrentChange="handleCurrentChange"
        :pageNum="tableData.current" :pageSize="tableData.size" :total="tableData.total"></Pagination>

      <!-- Add弹框 -->
      <!-- 日志Request/Response明细 -->
      <el-dialog title="Message Detail" width="80%" :visible.sync="categoryUpdateDialog">
        <el-card>
          <el-form :model="msgLogData" ref="msgLogData">
            <el-row>
              <el-col :span="4">
                <el-form-item label="Protocol" prop="Protocol">
                  <span class="span">{{ msgLogData.protocolType }}</span>
                </el-form-item>
              </el-col>
              <el-col :span="4">
                <el-form-item label="Source" prop="source">
                  <span class="span">{{ msgLogData.source }}</span>
                </el-form-item>
              </el-col>
              <el-col :span="4">
                <el-form-item label="Msg Type" prop="type">
                  <span class="span">{{ msgLogData.msgDetailData.type }}</span>
                </el-form-item>
              </el-col>
              <el-col :span="4">
                <el-form-item label="Status" prop="status">
                  <el-tag :type="msgLogData.status === 'Y' ? 'success' : 'danger'">{{ formatStatue(msgLogData.status)
                  }}</el-tag>
                </el-form-item>
              </el-col>

              <el-col :span="4">
                <el-form-item label="Date/Time" prop="operateTime">
                  <span class="span">{{
                    msgLogData.operateTime
                  }}</span>
                </el-form-item>
              </el-col>
            </el-row>

            <el-row v-show="
                //根据切换元素显示的状态
                msgLogData.protocolType == 'FTP' ||
                msgLogData.protocolType == 'SFTP'
                ">
              <el-col :span="10">
                <el-form-item label="Directory" prop="filePath">
                  <span class="span">{{
                    msgLogData.msgDetailData.filePath
                  }}</span>
                </el-form-item>
              </el-col>
              <el-col :span="10">
                <el-form-item label="Filename" prop="fileName">
                  <span class="span">{{
                    msgLogData.msgDetailData.fileName
                  }}</span>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="24">
                <el-form-item label="Content" prop="content">
                  <el-input class="textarea" type="textarea" v-model="text" :rows="20" readonly disabled></el-input>
                </el-form-item>
              </el-col>
            </el-row>
          </el-form>
        </el-card>
      </el-dialog>
    </el-tabs>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import store from "@/store";
import Pagination from "@/components/pagination/pagination.vue";
//添加方法
import {
  fetchList,
  getMsgDetail,
  retry,
  distinctDictList,
} from "@/api/log/logmsg";


let queryParam = {
  source: undefined,
  targent: undefined,
  url: undefined,
  bizType: undefined,
  status: undefined,
  bizNo: undefined,
  startTime: undefined,
  endTime: undefined,
  startRecallTime: undefined,
  endStartRecallTime: undefined,
  optionTime: undefined,
  optionTime2: undefined,
  clientCode: store.getters.commandName,
};



export default {
  data() {
    return {
      tableData: {},
      loading: false,
      page: {
        total: 0, // 总页数
        currentPage: 1, // 当前页数
        pageSize: 10, // 每页显示多少条
      },
      queryParam: Object.assign({}, queryParam),
      //判断是否成功还是失败
      statusList: [
        {
          value: "Y",
          label: "SUCCESS",
        },
        {
          value: "N",
          label: "ERROR",
        },
      ],
      msgLogData: {
        msgDetailData: {},
      },
      categoryUpdateDialog: false,
      show: false,
      text: "",
      msgTypeList: [],
      destinationList: [],
      sourceTypeList: []
    };
  },
  components: {
    Pagination,
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  created() {
    this.pageList(this.page);
    this.listDictByType();
  },
  methods: {
    pageList(page) {
      this.loading = true;
      const obj = Object.assign(
        {
          current: page.currentPage,
          size: page.pageSize,
        },
        this.queryParam
      );
      fetchList(obj).then((response) => {
        if (response.data.code === 0) {
          this.tableData = response.data.data;
          this.page.total = response.data.data.total;
          this.loading = false;
        } else {
          this.$message.error(response.data.msg);
        }
      });
    },
    msgView(row, id) {
      getMsgDetail({
        id: id,
        clientCode: queryParam.clientCode,
        createTime: row.createTime,
      }).then((response) => {
        if (response.data.code === 0) {
          this.msgLogData = row;
          this.msgLogData.msgDetailData = response.data.data;
          this.categoryUpdateDialog = true;
          this.text = response.data.data.context;
        } else {
          this.$message.error(response.data.msg);
        }
      });
    },
    msgOperation(row) {
      this.$confirm("Whether to resend?", "hint", {
        confirmButtonText: "Yes",
        cancelButtonText: "No",
        type: "warning",
      })
        .then(function () {
          return retry({
            id: row.id,
            clientCode: queryParam.clientCode,
            createTime: row.createTime,
          });
        })
        .then((data) => {
          if (data.data.code === 0) {
            this.$message.success("Resend success");
            this.pageList(this.page);
          } else {
            this.$message.error(data.data.msg);
          }
        });
    },
    handleSizeChange(pageSize) {
      this.page.pageSize = pageSize;
      this.pageList(this.page);
    },
    handleCurrentChange(currentPage) {
      this.page.currentPage = currentPage;
      this.pageList(this.page);
    },

    listDictByType() {
      //source
      distinctDictList("source").then((res) => {
        if (res.data.code === 0) {
          this.sourceTypeList = res.data.data;
        }
      });
      //target
      distinctDictList("target").then((res) => {
        if (res.data.code === 0) {
          this.destinationList = res.data.data;
        }
      });
      //biz_type
      distinctDictList("biz_type").then((res) => {
        if (res.data.code === 0) {
          this.msgTypeList = res.data.data;
        }
      });
    },
    // 重置
    resetForm(rule) {
      this.queryParam = Object.assign({}, queryParam);
    },

    //展开
    about() {
      this.show = !this.show;
    },

    search() {
      this.page.currentPage = 1;
      this.pageList(this.page);
    },

    formatStatue(cellValue) {
      let val = cellValue;
      this.statusList.forEach((item, index) => {
        if (item.value === cellValue) {
          val = item.label;
        }
      });
      return val;
    },
    //时间范围change监听
    changeDateTimePicker(value) {
      this.queryParam.startTime = undefined;
      this.queryParam.endTime = undefined;
      if (value && value.length > 0) {
        if (value.length == 1) {
          this.queryParam.startTime = value[0];
        }
        if (value.length == 2) {
          this.queryParam.startTime = value[0];
          this.queryParam.endTime = value[1];
        }
      }
    },
    changeDateTimePicker2(value) {
      this.queryParam.startRecallTime = undefined;
      this.queryParam.endStartRecallTime = undefined;
      if (value && value.length > 0) {
        if (value.length == 1) {
          this.queryParam.startRecallTime = value[0];
        }
        if (value.length == 2) {
          this.queryParam.startRecallTime = value[0];
          this.queryParam.endStartRecallTime = value[1];
        }
      }
    },
  },
};
</script>
<style lang="scss" scoped>
::v-deep .el-select--small {
  display: block;
}

.dialog-footer-add {
  display: flex;
  justify-content: center;
  color: rgb(64, 149, 229);
  font-size: 25px;
  margin: 20px 0;
}

.dialog-footer-box {
  display: flex;
  justify-content: center;
  margin-top: 100px;
}

.content {
  padding: 0 10px;

  .down {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    border-top: 1px solid #999;
    padding-top: 20px;
    box-sizing: border-box;
  }

  .underLine {
    color: #599af8;
    text-decoration: underline;

    .underIcon {
      background-color: green;
      color: #fff;
      border-radius: 50%;
      margin-right: 5px;
    }
  }
}

.operate-icon-wrap {
  display: flex;
  column-gap: 15px;
}

.operate-icon-box {
  display: flex;
  align-items: center;
  cursor: pointer;
  color: #4095e5;
}

.header-cell-class {
  background-color: #ccc;
}

.foot {
  display: flex;
  justify-content: flex-end;
  margin-top: 20px;
}

.btn-bgc {
  background-color: rgb(31, 99, 255);
  color: #fff;
}

.confrim-bgc {
  background-color: #1376c7;
  color: #fff;
}

.cursor-on {
  cursor: pointer;
}

::v-deep .el-dialog__wrapper .el-dialog {
  border-radius: 8px;
}

::v-deep .el-date-editor--daterange.el-input,
::v-deep .el-date-editor--daterange.el-input__inner,
::v-deep .el-date-editor--timerange.el-input,
::v-deep .el-date-editor--timerange.el-input__inner {
  width: 100% !important;
}
</style>
