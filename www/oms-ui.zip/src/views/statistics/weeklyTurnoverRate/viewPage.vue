<template>
    <div v-loading="dataListLoading">
      <!-- <el-row style="width:200px;display:flex">
        <el-col>
          <el-button type="primary" icon="el-icon-search" @click="getSearchlist">Query</el-button>
        </el-col>
        <el-col>
          <el-button icon="el-icon-refresh-left" @click="getReset">Reset</el-button>
        </el-col>
      </el-row> -->
      <!-- <el-form ref="form" :model="form" style="margin: 20px 0" @keyup.enter.native="getSearchlist">
        <el-row>
          <el-col>
            <el-radio-group v-model="form.warehouseCode" v-for="(ite, index) in warehouseByClient" :key="index">
              <el-radio :label="ite.warehouseCode" style="margin-right:10px"
                @change="getRadio">{{ ite.warehouseName }}</el-radio>
            </el-radio-group>
          </el-col>
          <el-col :span="4" style="margin-top: 10px"> 
            <el-date-picker v-model="form.year" type="year" value-format="yyyy" format="yyyy年"
              placeholder="Statistics Date (By Year)"></el-date-picker>
          </el-col>
        </el-row>
      </el-form> -->
      <div class="echarts">
        <div id="inventory"></div>
        <div id="turnOverRate"></div>
      </div>
    </div>
</template>
<script>
// import { pageQuery } from "@/api/statistics/weeklyTurnoverRate"
// import { getWarehouseByClient } from "@/api/stock/subwarehouse"
import store from "@/store";
let formParams = {
  year: undefined,
  warehouseCode: undefined,
}
export default {
  data() {
    return {
      form: Object.assign({}, formParams),  
      warehouseByClient: [],
      page: {
        size: 12,
        current: 1,
        clientCode: store.getters.commandName,
      },
      // annuallyEfficiency:[],
      // monthlyEfficiency:[],
      // month:[],
      // dataListLoading:false,
      // totalVom:[],
      // inVom:[],
      // outVom:[]
    }
  },
  props:{
    annuallyEfficiency:{
      type: Array
    },
    monthlyEfficiency:{
      type: Array
    },
    month:{
      type: Array
    },
    totalVom:{
      type: Array
    },
    inVom:{
      type: Array
    },
    inVom:{
      type: Array
    },
  },
  created(){
    // this.getWarehouseByClient()
    // this.getList()
  },
  mounted() {
    // this.getEcharts()
  },
  methods:{
    //仓库选泽
    // getRadio() {
    //   this.getSearchlist()
    // },
    //查询仓库..
    // getWarehouseByClient() {
    //   getWarehouseByClient().then(res => {
    //     console.log(res)
    //     if (res.data.code === 0) {
    //       this.warehouseByClient = res.data.data
    //     }
    //   })
    // },
    //查询
    getSearchlist() {
      for (let key in this.form) {
        if (this.form[key] === "" || this.form[key] === null) {
          this.form[key] = undefined;
        }
      }
      this.getList(this.form)
    },
    //数据列表
    // getList(params) {
    //   this.dataListLoading = true
    //   pageQuery(Object.assign({ ...this.page, warehouseCode: this.form.warehouseCode }, params)).then(res => {
    //     console.log(res)
    //     if (res.data.code === 0) {
    //       this.dataListLoading = false
    //       this.monthlyEfficiency = []
    //       this.annuallyEfficiency = []
    //       this.totalVom = []
    //       this.inVom = []
    //       this.outVom = []
    //       this.month = []
    //       res.data.data.records.forEach(item=>{
    //         let idx = item.monthlyEfficiency.indexOf('%')
    //         let idx2 = item.annuallyEfficiency.indexOf('%')
    //         item.monthlyEfficiency = item.monthlyEfficiency.substring(0,idx)/100
    //         item.annuallyEfficiency = item.annuallyEfficiency.substring(0,idx2)/100
    //         this.monthlyEfficiency.push(item.monthlyEfficiency)
    //         this.annuallyEfficiency.push(item.annuallyEfficiency)
    //         this.totalVom.push(item.totalVom)
    //         this.inVom.push(item.inVom)
    //         this.outVom.push(item.outVom)
    //         this.month.push(item.statisticsMonthly)
    //       })
    //       this.getEcharts()
    //     } else {
    //       this.$message.error(res.data.msg)
    //       this.dataListLoading = false
    //     }
    //   }).catch(() => {
    //     this.$message.error('request was aborted')
    //     this.dataListLoading = false
    //   })
    // },
    //清空
    getReset() {
      this.form = Object.assign({}, formParams)
      this.getList(this.form)
    },
    getEcharts(){
      var myChart = this.$echarts.init(document.getElementById('inventory'));
      var option = {
        title: {
          text: 'Inventory trend chart (m³)',
          left: 'center'
        },
        legend: {
          data: ['Stock', 'In', 'Out'],
          bottom: '0%',
          left:'center',
        },
        tooltip: {
          trigger: 'axis',
        },
        grid: {
          left: '3%',
          right: '4%',
          bottom: '10%',
          containLabel: true
        },
        xAxis: {
          type: 'category',
          data: this.month,
          // ['Mon In Out', 'Tue In Out', 'Wed In Out', 'Thu In Out', 'Fri In Out', 'Sat In Out', 'Sun In Out']
        },
        yAxis: {
          type: 'value'
        },
        series: [
          {
            name:'Stock',
            data: this.totalVom,
            type: 'bar',
            itemStyle:{
              color: '#4472C4',
            },
            label: {
              normal: {
                show: true,
                color:'#000'
              }
            }
          },
          {
            name:'In',
            data: this.inVom,
            type: 'bar',
            itemStyle:{
              color: '#ED7D31',
            },
            label: {
              normal: {
                show: true,
                color:'#000'
              }
            }
          },
          {
            name:'Out',
            data: this.outVom,
            type: 'bar',
            itemStyle:{
              color: '#A5A5A5',
            },
            label: {
              normal: {
                show: true,
                color:'#000'
              }
            }
          }
        ],
        toolbox: {
          show : true,
          feature : {
            mark : {show: true},
            // restore : {show: true},
            saveAsImage : {
              show: true,
              pixelRatio: 1,
              title : '保存为图片',
              type : 'png',
              lang : ['点击保存']         
            }
          }
        },
      };
      option && myChart.setOption(option);

      var myChart2 = this.$echarts.init(document.getElementById('turnOverRate'));
      var option2 = {
        title: {
          text: 'Turnover rate by volume',
          left: 'center'
        },
        tooltip: {
          trigger: 'axis',
          formatter:function(params) {
            var str = params[0].name + '<br>'
            for(let item of params) {
              str += item.seriesName + ' : ' + (item.value*100).toFixed(0) + '%<br>'
            }
            return str;
          }
        },
        legend: {
          data: ['Monthly turnover rate', 'Annualized turnover rate'],
          bottom: '0%',
          left:'center',
        },
        grid: {
          left: '3%',
          right: '4%',
          bottom: '10%',
          containLabel: true
        },
        xAxis: {
          type: 'category',
          data: this.month,
          splitLine:{
            show:true
          }
          // ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
        },
        yAxis: {
          type: 'value',
          // max: 1.5,  //最大值
          // min: 0,  //最小值
          splitNumber: 3, 
          splitLine: {
            show:false
            // lineStyle: {
            //   // 使用深浅的间隔色
            //   color: ["#fff"],
            // },
          },
        },
        series: [
          {
            name: 'Monthly turnover rate',
            data: this.monthlyEfficiency,
            type: 'line',
            itemStyle:{
              color: '#4472C4',
            }
          },
          {
            name: 'Annualized turnover rate',
            data: this.annuallyEfficiency,
            type: 'line',
            itemStyle:{
              color: '#ED7D31',
            }
          }
        ],
        toolbox: {
          show : true,
          feature : {
            mark : {show: true},
            // restore : {show: true},
            saveAsImage : {
              show: true,
              pixelRatio: 1,
              title : '保存为图片',
              type : 'png',
              lang : ['点击保存']         
            }
          }
        },
      };
      option2 && myChart2.setOption(option2);
    },
  },
}
</script>
<style lang="scss" scoped>
.echarts{
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  #inventory{
    width: 100%;
    height: 250px;
    margin-bottom: 20px;
  }
  #turnOverRate{
    width: 100%;
    height: 300px;
  }
}
</style>