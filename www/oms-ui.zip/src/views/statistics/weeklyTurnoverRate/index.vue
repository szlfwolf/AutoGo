<template>
  <div class="content" v-loading="weekLoading">
    <el-card class="box-card">
      <el-row style="width:200px;display:flex">
        <el-col>
          <el-button type="primary" icon="el-icon-search" @click="getSearchlist">Query</el-button>
        </el-col>
        <el-col>
          <el-button icon="el-icon-refresh-left" @click="getReset">Reset</el-button>
        </el-col>
      </el-row>
      <el-form ref="form" :model="form" style="margin: 20px 0" @keyup.enter.native="getSearchlist">
          <el-row>
            <el-col>
              <el-radio-group v-model="form.warehouseCode" v-for="(ite, index) in warehouseByClient" :key="index">
                <el-radio :label="ite.warehouseCode" style="margin-right:10px"
                  @change="getRadio">{{ ite.warehouseName }}</el-radio>
              </el-radio-group>
            </el-col>
            <!-- <el-col :span="4" style="margin-top: 10px">
              <el-date-picker v-model="form.statisticsMonthly" type="month" value-format="yyyy-MM"
                placeholder="Statistics Date (By Month)"></el-date-picker>
            </el-col> -->
            <el-col :span="4" style="margin-top: 10px"> 
              <el-date-picker v-model="form.year" type="year" value-format="yyyy" format="yyyy年"
                placeholder="Statistics Date (By Year)"></el-date-picker>
            </el-col>
          </el-row>
      </el-form>
      <div class="echarts">
        <div id="inventory"></div>
        <div id="turnOverRate"></div>
      </div>
      <div class="down">
        <div></div>
        <div>
          <el-button icon="el-icon-download" @click="exportExcel"
            v-if="permissions.statistics_warehouseturnoverefficiency_export"></el-button>
        </div>
      </div>
      <el-table border ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%"
        v-loading="dataListLoading" :header-cell-style="{ background: '#f5f7fa', color: '#606266' }">
        <el-table-column label="Owner" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.clientCode || '-' }}</template>
        </el-table-column>
        <el-table-column label="Warehouse" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.warehouseCode || '-' }}</template>
        </el-table-column>
        <el-table-column label="Statistics Date" min-width="140" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.statisticsMonthly || '-' }}</template>
        </el-table-column>
        <el-table-column label="Stock Vom (m³)" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.totalVom ? scope.row.totalVom : scope.row.totalVom == 0 ? 0 : '-'
          }}</template>
        </el-table-column>
        <el-table-column label="In Vom (m³)" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.inVom ? scope.row.inVom : scope.row.inVom == 0 ? 0 : '-' }}</template>
        </el-table-column>
        <el-table-column label="Out Vom (m³)" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.outVom ? scope.row.outVom : scope.row.outVom == 0 ? 0 : '-'
          }}</template>
        </el-table-column>
        <el-table-column label="Monthly TurnOver Rate" min-width="160" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.monthlyEfficiency ? scope.row.monthlyEfficiency :
            scope.row.monthlyEfficiency == 0 ? 0 : '-' }}</template>
        </el-table-column>
        <el-table-column label="Annualized TurnOver Rate" min-width="170" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.annuallyEfficiency ? scope.row.annuallyEfficiency :
            scope.row.annuallyEfficiency == 0 ? 0 : '-' }}</template>
        </el-table-column>
      </el-table>
      <Pagination @handleSizeChange="handleSizeChange" @handleCurrentChange="handleCurrentChange" :pageNum="page.current"
        :pageSize="page.size" :total="total"></Pagination>
    </el-card>
  </div>
</template>
<script>
import { mapGetters } from "vuex"
import Pagination from "@/components/pagination/pagination.vue"
import { pageQuery } from "@/api/statistics/weeklyTurnoverRate"
import { getWarehouseByClient, getStockByQuery } from "@/api/stock/subwarehouse"
import {deepClone} from "@/util/util"
import store from "@/store";
let formParams = {
  statisticsMonthly: undefined,
  warehouseCode: undefined,
  year: undefined
}
export default {
  name: "WeeklyVolumeRate",
  data() {
    return {
      form: Object.assign({}, formParams),
      total: 0,
      page: {
        size: 20,
        current: 1,
        clientCode: store.getters.commandName,
      },
      dataListLoading: false,
      tableData: [],
      warehouseByClient: [],
      weekLoading: false,
      isShow:false,
      annuallyEfficiency:[],
      monthlyEfficiency:[],
      month:[],
      totalVom:[],
      inVom:[],
      outVom:[]
    }
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  mounted() {
    this.exportExcel = this.$btn(this.exportExcel, 500)
  },
  components: {
    Pagination,
  },
  created() {
    this.form.year = `${new Date().getFullYear()}`
    console.log(new Date().getFullYear());
    this.getWarehouseByClient()
  },
  methods: {
    //查询仓库..
    getWarehouseByClient() {
      getWarehouseByClient().then(res => {
        console.log(res)
        if (res.data.code === 0) {
          this.warehouseByClient = res.data.data
          this.form.warehouseCode = this.warehouseByClient[0].warehouseCode
          this.getSearchlist()
        }
      })
    },
    //导出
    exportExcel() {
      this.weekLoading = true
      this.downBlobFile("/statistics/warehouseTurnoverEfficiency/export", { ...this.form, warehouseCode: this.form.warehouseCode, clientCode: store.getters.commandName, },
        `${this.$store.state.common.commandName}-WarehouseTurnOverEfficiency-${this.toDateFormat(new Date(), true)}.xlsx`, () => this.weekLoading = false)
    },
    //条数
    handleSizeChange(val) {
      this.page.current = 1
      this.page.size = val
      this.getList(this.form)
    },
    //当前页数
    handleCurrentChange(val) {
      this.page.current = val
      this.getList(this.form)
    },
    //清空
    getReset() {
      this.form = Object.assign({}, formParams)
      this.page = this.$options.data().page
      this.form.warehouseCode = this.warehouseByClient[0].warehouseCode
      this.form.year = `${new Date().getFullYear()}`
      this.getSearchlist()
    },
    //仓库选泽
    getRadio() {
      this.getSearchlist()
    },
    //查询
    getSearchlist() {
      this.page.current = 1
      for (let key in this.form) {
        if (this.form[key] === "" || this.form[key] === null) {
          this.form[key] = undefined;
        }
      }
      this.getList(this.form)
    },
    //数据列表
    getList(params) {
      this.weekLoading = true
      pageQuery(Object.assign({ ...this.page, warehouseCode: this.form.warehouseCode }, params)).then(res => {
        console.log(res)
        if (res.data.code === 0) {
          let dataList = deepClone(res.data.data.records)
          this.tableData = res.data.data.records
          this.total = res.data.data.total
          this.weekLoading = false

          this.monthlyEfficiency = []
          this.annuallyEfficiency = []
          this.totalVom = []
          this.inVom = []
          this.outVom = []        
          this.month = []
          dataList.forEach(item=>{
            // item.monthlyEfficiency = item.monthlyEfficiency.replace(',','')
            // item.annuallyEfficiency = item.annuallyEfficiency.replace(',','')
            let idx = item.monthlyEfficiency.indexOf('%')
            let idx2 = item.annuallyEfficiency.indexOf('%')
            item.monthlyEfficiency = item.monthlyEfficiency.substring(0,idx)/100
            item.annuallyEfficiency = item.annuallyEfficiency.substring(0,idx2)/100
            this.monthlyEfficiency.push(item.monthlyEfficiency)
            this.annuallyEfficiency.push(item.annuallyEfficiency)
            this.totalVom.push(item.totalVom)
            this.inVom.push(item.inVom)
            this.outVom.push(item.outVom)
            this.month.push(item.statisticsMonthly) 
          })
          // this.monthlyEfficiency.unshift(item.monthlyEfficiency)
          // this.monthlyEfficiency = this.monthlyEfficiency.reverse()
          this.getEcharts()
        } else {
          this.$message.error(res.data.msg)
          this.weekLoading = false
        }
      }).catch(() => {
        this.$message.error('request was aborted')
        this.weekLoading = false
      })
    },
    getEcharts(){
      var myChart = this.$echarts.init(document.getElementById('inventory'));
      window.addEventListener('resize', function () { myChart.resize() })
      var option = {
        title: {
          text: 'Inventory trend chart (m³)',
          left: 'center'
        },
        legend: {
          data: ['Stock', 'In', 'Out'],
          bottom: '0%',
          left:'center',
        },
        tooltip: {
          trigger: 'axis',
        },
        grid: {
          left: '3%',
          right: '4%',
          bottom: '10%',
          containLabel: true
        },
        xAxis: {
          type: 'category',
          data: this.month,
        },
        yAxis: {
          type: 'value'
        },
        series: [
          {
            name:'Stock',
            // stack: 'Total',
            data: this.totalVom,
            type: 'bar',
            itemStyle:{
              color: '#4472C4',
            },
            label: {
              normal: {
                show: true,
                color:'#000',
              }
            },
          },
          {
            name:'In',
            // stack: 'Total',
            data: this.inVom,
            type: 'bar',
            itemStyle:{
              color: '#ED7D31',
            },
            label: {
              normal: {
                show: true,
                color:'#000'
              }
            },
            // itemStyle: {
            //   borderColor: 'transparent',
            //   color: 'transparent'
            // },
            // emphasis: {
            //   itemStyle: {
            //     borderColor: 'transparent',
            //     color: 'transparent'
            //   }
            // },
          },
          {
            name:'Out',
            // stack: 'Total',
            data: this.outVom,
            type: 'bar',
            itemStyle:{
              color: '#A5A5A5',
            },
            label: {
              normal: {
                show: true,
                color:'#000'
              }
            }
          }
        ],
        // series: [{
				// 		name:'Stock',
				// 		type: 'bar',
				// 		stack: '总量',
				// 		itemStyle: {
				// 			normal: {
				// 				barBorderColor: 'rgba(0,0,0,0)',
				// 				color: 'rgba(0,0,0,0)'
				// 			},
				// 			emphasis: {
				// 				barBorderColor: 'rgba(0,0,0,0)',
				// 				color: 'rgba(0,0,0,0)'
				// 			}
				// 		},
				// 		data: this.totalVom,
				// 	},
				// 	{
				// 		name: '收入',
				// 		type: 'bar',
				// 		stack: '总量',
				// 		label: {
				// 			normal: {
				// 				show: true,
				// 				position: 'top'
				// 			}
				// 		},
				// 		data: [900, 345, 393, '-', '-', 135, 178, 286, '-', '-', '-']
				// 	},
				// 	{
				// 		name: '支出',
				// 		type: 'bar',
				// 		stack: '总量',
				// 		label: {
				// 			normal: {
				// 				show: true,
				// 				position: 'bottom'
				// 			}
				// 		},
				// 		data: ['-', '-', '-', 108, 154, '-', '-', '-', 119, 361, 203]
				// 	}
				// ],
        toolbox: {
          show : true,
          feature : {
            mark : {show: true},
            // restore : {show: true},
            saveAsImage : {
              show: true,
              pixelRatio: 1,
              title : '保存为图片',
              type : 'png',
              lang : ['点击保存']         
            }
          }
        },
      };
      option && myChart.setOption(option);

      var myChart2 = this.$echarts.init(document.getElementById('turnOverRate'));
      window.addEventListener('resize', function () { myChart2.resize() })
      var option2 = {
        title: {
          text: 'Turnover rate by volume',
          left: 'center'
        },
        tooltip: {
          trigger: 'axis',
          formatter:function(params) {
            var str = params[0].name + '<br>'
            for(let item of params) {
              str += item.seriesName + ' : ' + (item.value*100).toFixed(0) + '%<br>'
            }
            return str;
          }
        },
        legend: {
          data: ['Monthly turnover rate', 'Annualized turnover rate'],
          bottom: '0%',
          left:'center',
        },
        grid: {
          left: '3%',
          right: '4%',
          bottom: '10%',
          containLabel: true
        },
        xAxis: {
          type: 'category',
          data: this.month,
          splitLine:{
            show:true
          }
        },
        yAxis: {
          type: 'value',
          // max: 1.5,  //最大值
          // min: 0,  //最小值
          splitNumber: 3, 
          splitLine: {
            show:false
            // lineStyle: {
            //   // 使用深浅的间隔色
            //   color: ["#fff"],
            // },
          },
        },
        series: [
          {
            name: 'Monthly turnover rate',
            data: this.monthlyEfficiency,
            type: 'line',
            itemStyle:{
              color: '#4472C4',
            }
          },
          {
            name: 'Annualized turnover rate',
            data: this.annuallyEfficiency,
            type: 'line',
            itemStyle:{
              color: '#ED7D31',
            }
          }
        ],
        toolbox: {
          show : true,
          feature : {
            mark : {show: true},
            // restore : {show: true},
            saveAsImage : {
              show: true,
              pixelRatio: 1,
              title : '保存为图片',
              type : 'png',
              lang : ['点击保存']         
            }
          }
        },
      };
      option2 && myChart2.setOption(option2);
    },
  },
} 
</script>
<style lang="scss" scoped>
.content {
  padding: 0 10px;
  // width: 100vw;

  .text {
    font-size: 14px;
  }

  .item {
    padding: 18px 0;
  }

  .box-card {
    width: 100%;
  }

  .down {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    // border-top: 1px solid #999;
    padding-top: 20px;
    box-sizing: border-box;
  }

  .underLine {
    cursor: pointer;
    color: #599af8;
    text-decoration: underline;
  }

  ::v-deep .el-dialog {
    border-radius: 8px !important;
  }

  ::v-deep .el-select--small {
    display: block;
  }

  ::v-deep .el-date-editor.el-input,
  .el-date-editor.el-input__inner {
    width: 100%;
  }
  .echarts{
    width: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    #inventory{
      width: 100%;
      height: 250px;
      margin-bottom: 20px;
    }
    #turnOverRate{
      width: 100%;
      height: 300px;
    }
  }
}
</style>
