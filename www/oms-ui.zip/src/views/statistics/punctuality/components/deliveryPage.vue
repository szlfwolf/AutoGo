<template>
  <div class="packingPage" v-loading="deliveryLoading">
    <el-row style="width:200px;display:flex" v-if="!switchStatus">
      <el-col>
        <el-button type="primary" icon="el-icon-search" @click="getSearchlist">Query</el-button>
      </el-col>
      <el-col>
        <el-button icon="el-icon-refresh-left" @click="getReset">Reset</el-button>
      </el-col>
    </el-row>
    <el-form ref="form" :model="form" style="margin: 20px 0" @keyup.enter.native="getSearchlist">
      <el-row :gutter="20">
        <el-col>
          <el-radio-group v-model="form.urgentType" v-for="(ite, index) in warehouseByClient" :key="index">
            <el-radio :label="ite.value" style="margin-right:10px"
              @change="getRadio">{{ ite.label }}</el-radio>
          </el-radio-group>
        </el-col>
        <el-col :span="4" style="margin-top: 10px" v-if="!switchStatus">
          <el-input v-model="form.orderNo" placeholder="Order no"></el-input>
        </el-col>
        <el-col :span="4" style="margin-top: 10px" v-if="!switchStatus">
          <el-select v-model="form.deliveryOnTime" placeholder="Delivery on-time" filterable clearable>
            <el-option v-for="item in importOnTime" :key="item.value" :label="item.label" :value="item.value">
            </el-option>
          </el-select>
        </el-col>
      </el-row>
    </el-form>
    <div class="down">
      <div></div>
      <div>
        <el-button icon="el-icon-download" @click="exportExcel"
          v-if="permissions.statistics_dnhead_dnpunctuality_export && !switchStatus">
        </el-button>
        <el-button icon="el-icon-download" @click="exportExcel"
          v-else-if="permissions.statistics_dnhead_delivery_punctuality_overview_export && switchStatus">
        </el-button>
      </div>
    </div>
    <el-table border ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%"
      v-loading="dataListLoading" :header-cell-style="{ background: '#f5f7fa', color: '#606266' }" v-show="!switchStatus">
      <el-table-column label="Owner" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.clientCode || '-' }}</template>
      </el-table-column>
      <el-table-column label="Warehouse" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.warehouseCode || '-' }}</template>
      </el-table-column>
      <el-table-column label="Statistics Date" min-width="140" align="center">
        <template slot-scope="scope">{{ scope.row.statisticsDate || '-' }}</template>
      </el-table-column>
      <el-table-column label="Order no" min-width="140" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.orderNo || '-' }}</template>
      </el-table-column>
      <el-table-column label="Dn no" min-width="140" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.dnNo || '-' }}</template>
      </el-table-column>
      <el-table-column label="Urgent Type" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.urgentType || '-' }}</template>
      </el-table-column>
      <el-table-column label="Ship-out Time" min-width="140" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.shipOutTime || '-' }}</template>
      </el-table-column>
      <el-table-column label="Pod time" min-width="140" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.podTime || '-' }}</template>
      </el-table-column>
      <el-table-column label="Country Code" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.countryCode || '-' }}</template>
      </el-table-column>
      <el-table-column label="Pkg Type" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.packageType || '-' }}</template>
      </el-table-column>
      <el-table-column label="Delivery days" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.deliveryDays ? scope.row.deliveryDays : scope.row.deliveryDays == 0 ? 0
          : '-' }}</template>
      </el-table-column>
      <el-table-column label="Delivery KPI" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.deliveryKpi ? scope.row.deliveryKpi : scope.row.deliveryKpi == 0 ? 0 :
          '-' }}</template>
      </el-table-column>
      <el-table-column label="Delivery on-time" min-width="140" align="center">
        <template slot-scope="scope"><i
            :class="scope.row.deliveryDays == null ? 'el-icon-error error' : scope.row.deliveryDays <= scope.row.deliveryKpi ? 'el-icon-success success' : 'el-icon-error error'"></i></template>
      </el-table-column>
      <el-table-column label="Delay Remark" align="center" min-width="120" v-if="permissions.statistics_dnhead_dnpunctuality_update">
        <template slot-scope="scope">
          <i style="font-size: 18px;cursor: pointer;color:#65BEFF;margin-right:10px" class="el-icon-edit"
            v-if="permissions.statistics_dnhead_dnpunctuality_update" @click="editClick(scope.row, scope.$index)"></i>
        </template>
      </el-table-column>
    </el-table>
    <el-table border ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%"
      v-loading="dataListLoading" :header-cell-style="{ background: '#f5f7fa', color: '#606266' }" v-show="switchStatus">
      <el-table-column label="Country" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.countryCode || '-' }}</template>
      </el-table-column>
      <el-table-column label="0" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.deliveryDay0 ? scope.row.deliveryDay0 : scope.row.deliveryDay0 == 0 ? 0 : '-' }}</template>
      </el-table-column>
      <el-table-column label="1" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.deliveryDay1 ? scope.row.deliveryDay1 : scope.row.deliveryDay1 == 0 ? 0 : '-' }}</template>
      </el-table-column>
      <el-table-column label="2" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.deliveryDay2 ? scope.row.deliveryDay2 : scope.row.deliveryDay2 == 0 ? 0 : '-' }}</template>
      </el-table-column>
      <el-table-column label="3" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.deliveryDay3 ? scope.row.deliveryDay3 : scope.row.deliveryDay3 == 0 ? 0 : '-' }}</template>
      </el-table-column>
      <el-table-column label="4" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.deliveryDay4 ? scope.row.deliveryDay4 : scope.row.deliveryDay4 == 0 ? 0 : '-' }}</template>
      </el-table-column>
      <el-table-column label="5" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.deliveryDay5 ? scope.row.deliveryDay5 : scope.row.deliveryDay5 == 0 ? 0 : '-' }}</template>
      </el-table-column>
      <el-table-column label=">5" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.deliveryDay6 ? scope.row.deliveryDay6 : scope.row.deliveryDay6 == 0 ? 0 : '-' }}</template>
      </el-table-column>
      <el-table-column label="Not Arrive" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.notArrive || '-' }}</template>
      </el-table-column>
      <el-table-column label="Delivery KPI" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.deliveryKpi || '-' }}</template>
      </el-table-column>
      <el-table-column label="Deliver On Time Rate" min-width="160" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.deliveryOnTimeRate ? scope.row.deliveryOnTimeRate : scope.row.deliveryOnTimeRate == 0 ? 0 : '-' }}</template>
      </el-table-column>
    </el-table>
    <Pagination @handleSizeChange="handleSizeChange" @handleCurrentChange="handleCurrentChange" :pageNum="page.current"
    :pageSize="page.size" :total="total"></Pagination>
    <Dialog v-if="dialogShow" :dialogShow="dialogShow" :title="title" @getClose="getClose" :row="row"></Dialog>
  </div>
</template>
<script>
import { mapGetters } from "vuex"
import Pagination from "@/components/pagination/pagination.vue"
import Dialog from "./dialog.vue"
import { dnPageQuery, deliveryOverView } from "@/api/statistics/punctuality"
import { remote } from "@/api/admin/dict"
import store from "@/store";
let formParams = {
  orderNo: undefined,
  statisticsDate: undefined,
  deliveryOnTime: undefined,
  warehouseCode: undefined,
  urgentType: 'All'
}
export default {
  name: "DeliveryPage",
  data() {
    return {
      form: Object.assign({}, formParams),
      total: 0,
      page: {
        size: 10,
        current: 1,
        remark: "delivery",
        clientCode: store.getters.commandName
      },
      dataListLoading: false,
      tableData: [],
      warehouseByClient: [],
      importOnTime: [
        {
          label: 'Y',
          value: "1"
        },
        {
          label: 'N',
          value: "0"
        },
      ],
      dialogShow: false,//弹窗
      title: "",
      row: {},
      deliveryLoading: false,
      timeDate:""
    }
  },
  computed: {
    ...mapGetters(["permissions"]),
    changeData() {
      const { statisticsDate, warehouse } = this
      return { statisticsDate, warehouse }
    }
  },
  mounted() {
    this.exportExcel = this.$btn(this.exportExcel, 500)
  },
  props:{
    switchStatus: Boolean,
    warehouse:{
      type: String
    },
    statisticsDate:{
      type: String
    }
  },
  components: {
    Pagination,
    Dialog
  },
  watch:{
    changeData:function(val){
      this.form.warehouseCode = val.warehouse
      this.form.statisticsDate = val.statisticsDate
      this.getList(this.form)
    },
    switchStatus:function(newV,oldV){
      this.getList(this.form)
    }
  },
  created() {
    let year = new Date().getFullYear()
    let month = (new Date()).getMonth()
    if (month < 10) {
      month = '0' + month
    }
    this.timeDate = year + '-' + month
    this.form.statisticsDate = this.statisticsDate
    this.form.warehouseCode = this.warehouse
    
    this.getList(this.form)
    this.getRemote()
  },
  methods: {
    //导出
    exportExcel() {
      this.deliveryLoading = true
      if(!this.switchStatus){
        this.downBlobFile("/statistics/dnHead/export", {
          ...this.form, remark: "delivery",
          clientCode: store.getters.commandName
        }, `${this.$store.state.common.commandName}-Delivery-${this.toDateFormat(new Date(), true)}.xlsx`, () => this.deliveryLoading = false)
      }else{
        this.downBlobFile("/statistics/dnHead/dnDeliveryPunctualityOverviewExport", {
          urgentType:this.form.urgentType,warehouseCode:this.form.warehouseCode,statisticsDate:this.form.statisticsDate,
          clientCode: store.getters.commandName
        }, `${this.$store.state.common.commandName}-DeliveryDetail-${this.toDateFormat(new Date(), true)}.xlsx`, () => this.deliveryLoading = false)
      }
    },
    //条数
    handleSizeChange(val) {
      this.page.current = 1
      this.page.size = val
      this.getList(this.form)
    },
    //当前页数
    handleCurrentChange(val) {
      this.page.current = val
      this.getList(this.form)
    },
    //清空
    getReset() {
      this.$emit('getClear')
      this.form = Object.assign({}, formParams)
      this.page = this.$options.data().page
      this.form.warehouseCode = this.warehouse
      this.form.statisticsDate = this.timeDate
      
      if(this.statisticsDate != this.form.statisticsDate || this.warehouse != this.form.warehouseCode){
        return
      }
      this.getList(this.form)
    },
    //仓库选泽
    getRadio() {
      this.getSearchlist()
    },
    //查询
    getSearchlist() {
      this.page.current = 1
      for (let key in this.form) {
        if (this.form[key] === "" || this.form[key] === null) {
          this.form[key] = undefined;
        }
      }
      this.getList(this.form)
    },
    //数据列表
    getList(params) {
      this.dataListLoading = true
      if(!this.switchStatus){
        dnPageQuery(Object.assign({ ...this.page, warehouseCode: this.form.warehouseCode }, params)).then(res => {
          console.log(res)
          if (res.data.code === 0) {
            this.tableData = res.data.data.records
            this.total = res.data.data.total
            this.dataListLoading = false
          } else {
            this.$message.error(res.data.msg)
            this.dataListLoading = false
          }
        }).catch(() => {
          this.$message.error('request was aborted')
          this.dataListLoading = false
        })
      }else{
        deliveryOverView({urgentType:this.form.urgentType,warehouseCode: this.form.warehouseCode,
        statisticsDate: this.form.statisticsDate,size:this.page.size,current:this.page.current,clientCode: store.getters.commandName}).then(res=>{
          console.log(res);
          if(res.data.code === 0){
            this.tableData = res.data.data.records
            this.total = res.data.data.total
            // this.strictInboundOnTimeRate = res.data.data.strictInboundOnTimeRate
            this.dataListLoading = false
          } else {
            this.$message.error(res.data.msg)
            this.dataListLoading = false
          }
        }).catch(() => {
          this.$message.error('request was aborted')
          this.dataListLoading = false
        })
      }
    },
    getRemote(){
      //urgentType
      remote("urgent_level").then((res) => {
        if (res.data.code === 0) {
          res.data.data.unshift({value:'All',label:'All'})
          this.warehouseByClient = res.data.data;
        }
      });
    },
    //编辑
    editClick(row, index) {
      this.dialogShow = true
      this.title = 'Delivery'
      this.row = row
    },
    //子传父关闭弹窗
    getClose(e, type) {
      this.dialogShow = e
      if (type) {
        this.getList()
      }
    }
  },
} 
</script>
<style lang="scss" scoped>
.packingPage {
  .down {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    border-top: 1px solid #999;
    padding-top: 20px;
    box-sizing: border-box;
  }

  .underLine {
    cursor: pointer;
    color: #599af8;
    text-decoration: underline;
  }

  .success {
    color: rgb(137, 234, 137);
    font-size: 18px;
  }

  .error {
    color: rgb(238, 99, 99);
    font-size: 18px;
  }

  ::v-deep .el-dialog {
    border-radius: 8px !important;
  }

  ::v-deep .el-select--small {
    display: block;
  }

  ::v-deep .el-date-editor.el-input,
  .el-date-editor.el-input__inner {
    width: 100%;
  }
}
</style>
