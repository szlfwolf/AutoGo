<template>
  <div class="inboundPage" v-loading="inboundLoading">
    <el-row style="width:200px;display:flex" v-if="!switchStatus">
      <el-col>
        <el-button type="primary" icon="el-icon-search" @click="getSearchlist">Query</el-button>
      </el-col>
      <el-col>
        <el-button icon="el-icon-refresh-left" @click="getReset">Reset</el-button>
      </el-col>
    </el-row>
    <el-form ref="form" :model="form" style="margin: 20px 0" @keyup.enter.native="getSearchlist">
      <el-row :gutter="20">
        <el-col>
          <el-radio-group v-model="form.shipType" v-for="(ite, index) in warehouseByClient" :key="index">
            <el-radio :label="ite.value" style="margin-right:10px"
              @change="getRadio">{{ ite.value }}</el-radio>
          </el-radio-group>
        </el-col>
        <el-col :span="4" style="margin-top: 10px" v-if="!switchStatus">
          <el-input v-model="form.orderNo" placeholder="ASN Order no"></el-input>
        </el-col>
        <el-col :span="4" style="margin-top: 10px" v-if="!switchStatus">
          <el-select v-model="form.inboundOnTime" placeholder="Inbound on-time" filterable clearable>
            <el-option v-for="item in importOnTime" :key="item.value" :label="item.label" :value="item.value">
            </el-option>
          </el-select>
        </el-col>
      </el-row>
    </el-form>
    <div class="down">
      <div></div>
      <div>
        <el-button icon="el-icon-download" @click="exportExcel"
          v-if="permissions.statistics_asnhead_asnpunctuality_export && !switchStatus"></el-button>
        <el-button icon="el-icon-download" @click="exportExcel"
          v-else-if="permissions.statistics_asnhead_asnpunctuality_inbound_overview_export && switchStatus"></el-button>
      </div>
    </div>
    <el-table border ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%"
        v-loading="dataListLoading" :header-cell-style="{ background: '#f5f7fa', color: '#606266' }" v-show="!switchStatus">
      <el-table-column label="Owner" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.clientCode || '-' }}</template>
      </el-table-column>
      <el-table-column label="Warehouse" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.warehouseCode || '-' }}</template>
      </el-table-column>
      <el-table-column label="Statistics Date" min-width="140" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.statisticsDate || '-' }}</template>
      </el-table-column>
      <el-table-column label="Order no" min-width="140" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.orderNo || '-' }}</template>
      </el-table-column>
      <el-table-column label="ContainerNo" min-width="140" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.asnNo || '-' }}</template>
      </el-table-column>
      <el-table-column label="Ship Type" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.shipType || '-' }}</template>
      </el-table-column>
      <el-table-column label="ATA WH" min-width="140" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.ataWh || '-' }}</template>
      </el-table-column>
      <el-table-column label="Finish date" min-width="140" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.ataPort || '-' }}</template>
      </el-table-column>
      <el-table-column label="Inbound days" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.inboundDays ? scope.row.inboundDays : scope.row.inboundDays == 0 ? 0 :
          '-' }}</template>
      </el-table-column>
      <el-table-column label="Inbound KPI" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.inboundKpi ? scope.row.inboundKpi : scope.row.inboundKpi == 0 ? 0 : '-'
        }}</template>
      </el-table-column>
      <el-table-column label="Inbound on-time" min-width="120" align="center">
        <template slot-scope="scope"><i
            :class="scope.row.inboundDays == null ? 'el-icon-error error' : scope.row.inboundDays <= scope.row.inboundKpi ? 'el-icon-success success' : 'el-icon-error error'"></i></template>
      </el-table-column>
      <el-table-column label="Delay Remark" align="center" min-width="120" v-if="permissions.statistics_asnhead_asnpunctuality_update">
        <template slot-scope="scope">
          <i style="font-size: 18px;cursor: pointer;color:#65BEFF;margin-right:10px" class="el-icon-edit"
            v-if="permissions.statistics_asnhead_asnpunctuality_update" @click="editClick(scope.row, scope.$index)"></i>
        </template>
      </el-table-column>
    </el-table>
    <el-table border ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%" show-summary :summary-method="getSummaries"
        v-loading="dataListLoading" :header-cell-style="{ background: '#f5f7fa', color: '#606266' }" v-show="switchStatus">
      <el-table-column label="Owner" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.clientCode || '-' }}</template>
      </el-table-column>
      <el-table-column label="Warehouse" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.warehouseCode || '-' }}</template>
      </el-table-column>
      <el-table-column label="Days" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.inboundDays ? scope.row.inboundDays : scope.row.inboundDays == 0 ? 0 : '-' }}</template>
      </el-table-column>
      <el-table-column prop="asnNum" label="AsnNum" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.asnNum ? scope.row.asnNum : scope.row.asnNum == 0 ? 0 : '-' }}</template>
      </el-table-column>
      <el-table-column prop="inboundOnTimeRate" label="Rate" min-width="160" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.inboundOnTimeRate ? scope.row.inboundOnTimeRate : scope.row.inboundOnTimeRate == 0 ? 0 : '-' }}</template>
      </el-table-column>
    </el-table>
    <div style="margin-top: 20px;margin-right:100px;display:flex;justify-content: flex-end;" v-if="switchStatus">
      <label>Strict Inbound On Time:</label>
      <div style="margin-left:5px">{{strictInboundOnTimeRate}}</div>
    </div>
    <Pagination @handleSizeChange="handleSizeChange" @handleCurrentChange="handleCurrentChange" :pageNum="page.current"
    :pageSize="page.size" :total="total" v-if="!switchStatus"></Pagination>
    <Dialog v-if="dialogShow" :dialogShow="dialogShow" :title="title" @getClose="getClose" :row="row"></Dialog>
  </div>
</template>
<script>
import { mapGetters } from "vuex"
import Pagination from "@/components/pagination/pagination.vue"
import Dialog from "./dialog.vue"
import { pageQuery, inboundOverView } from "@/api/statistics/punctuality"
import store from "@/store";
import { remote } from "@/api/admin/dict"
import { deepClone } from '@/util/util'
let formParams = {
  orderNo: undefined,
  inboundOnTime: undefined,
  warehouseCode: undefined,
  statisticsDate: undefined,
  shipType: 'All'
}
export default {
  name: "InboundPage",
  data() {
    return {
      form: Object.assign({}, formParams),
      total: 0,
      page: {
        size: 10,
        current: 1,
        // remark: "inbound",
        clientCode: store.getters.commandName
      },
      dataListLoading: false,
      tableData: [],
      warehouseByClient: [],
      importOnTime: [
        {
          label: 'Y',
          value: "1"
        },
        {
          label: 'N',
          value: "0"
        },
      ],
      dialogShow: false,//弹窗
      title: "",
      row: {},
      inboundLoading: false,
      timeDate:"",
      strictInboundOnTimeRate:"",
      isCheck:true
    }
  },
  props:{
    switchStatus: Boolean,
    warehouse:{
      type: String
    },
    statisticsDate:{
      type: String
    }
  },
  computed: {
    ...mapGetters(["permissions"]),
    changeData() {
      const { statisticsDate, warehouse } = this
      return { statisticsDate, warehouse }
    }
  },
  mounted() {
    this.exportExcel = this.$btn(this.exportExcel, 500)
  },
  components: {
    Pagination,
    Dialog
  },
  watch:{
    changeData:function(val){
      this.form.warehouseCode = val.warehouse
      this.form.statisticsDate = val.statisticsDate
      this.getList(this.form)
    },
    // warehouse:function(newV,oldV){
    //   this.form.warehouseCode = newV
    //   this.getList(this.form)
    // },
    // statisticsDate:function(newV,oldV){
    //   this.form.statisticsDate = newV
    //   this.getList(this.form)
    // },
    switchStatus:function(newV,oldV){
      // this.switchStatus = newV
      this.getList(this.form)
    }
  },
  created() {
    let year = new Date().getFullYear()
    let month = (new Date()).getMonth()
    if (month < 10) {
      month = '0' + month
    }
    this.timeDate = year + '-' + month
    this.form.statisticsDate = this.statisticsDate
    this.form.warehouseCode = this.warehouse
    this.getList(this.form)

    this.getRemote()
  },
  methods: {
    //导出
    exportExcel() {
      this.inboundLoading = true
      if(!this.switchStatus){
        this.downBlobFile("/statistics/asnHead/export", {
          ...this.form, remark: "inbound",
          clientCode: store.getters.commandName
        }, `${this.$store.state.common.commandName}-Inbound-${this.toDateFormat(new Date(), true)}.xlsx`, () => this.inboundLoading = false)
      }else{
        this.downBlobFile("/statistics/asnHead/asnPunctualityInboundOverviewExport", {
          shipType:this.form.shipType,warehouseCode:this.form.warehouseCode,statisticsDate:this.form.statisticsDate,
          clientCode: store.getters.commandName
        }, `${this.$store.state.common.commandName}-InboundDetail-${this.toDateFormat(new Date(), true)}.xlsx`, () => this.inboundLoading = false)
      }
    },
    //条数
    handleSizeChange(val) {
      this.page.current = 1
      this.page.size = val
      this.getList(this.form)
    },
    //当前页数
    handleCurrentChange(val) {
      this.page.current = val
      this.getList(this.form)
    },
    //清空
    getReset() {
      this.$emit('getClear')
      this.form = Object.assign({}, formParams)
      this.form.warehouseCode = this.warehouse
      this.form.statisticsDate = this.timeDate
      this.page = this.$options.data().page
      if(this.statisticsDate != this.form.statisticsDate || this.warehouse != this.form.warehouseCode){
        return
      }
      this.getList(this.form)
    },
    //仓库选泽
    getRadio() {
      this.getSearchlist()
    },
    //查询
    getSearchlist() {
      this.page.current = 1
      for (let key in this.form) {
        if (this.form[key] === "" || this.form[key] === null) {
          this.form[key] = undefined;
        }
      }
      this.getList(this.form)
    },
    //数据列表
    getList(params) {
      this.dataListLoading = true
      if(!this.switchStatus){
        pageQuery(Object.assign({ ...this.page, warehouseCode: this.form.warehouseCode }, params)).then(res => {
          console.log(res)
          if (res.data.code === 0) {
            this.tableData = res.data.data.records
            this.total = res.data.data.total
            this.dataListLoading = false
          } else {
            this.$message.error(res.data.msg)
            this.dataListLoading = false
          }
        }).catch(() => {
          this.$message.error('request was aborted')
          this.dataListLoading = false
        })
      }else{
        inboundOverView({shipType:this.form.shipType,warehouseCode: this.form.warehouseCode,statisticsDate: this.form.statisticsDate,clientCode: store.getters.commandName}).then(res=>{
          console.log(res);
          if(res.data.code === 0){
            this.tableData = res.data.data.asnPunctualityInboundOverviews
            this.strictInboundOnTimeRate = res.data.data.strictInboundOnTimeRate
            this.dataListLoading = false
          } else {
            this.$message.error(res.data.msg)
            this.dataListLoading = false
          }
        }).catch(() => {
          this.$message.error('request was aborted')
          this.dataListLoading = false
        })
      }
    },
    getRemote(){
      //shipType
      remote("bl_ship_type").then((res) => {
        if (res.data.code === 0) {
          res.data.data.unshift({value:'All',label:'All'})
          this.warehouseByClient = res.data.data;
        }
      });
    },
    //编辑
    editClick(row, index) {
      this.dialogShow = true
      this.title = 'Inbound'
      this.row = row
    },
    //子传父关闭弹窗
    getClose(e, type) {
      this.dialogShow = e
      if (type) {
        this.getList(this.form)
      }
    },
    //计算列总和
    getSummaries(param) {
      const { columns, data } = param;
      const sums = [];
      let dataList = deepClone(data)
      dataList.forEach(ite=>{
        for (const key in ite) {
          if(key == 'inboundOnTimeRate'){
            let index = (ite.inboundOnTimeRate).indexOf('%')
            ite.inboundOnTimeRate = ite.inboundOnTimeRate.substring(0,index)
          }
        }
      })
      columns.forEach((column, index) => {
        if (index === 0) {
          sums[index] = 'Total';
          return;
        }
        const values = dataList.map(item => Number(item[column.property]));
        if (!values.every(value => isNaN(value))) {
          sums[index] = values.reduce((prev, curr) => {
            const value = Number(curr);
            if (!isNaN(value)) {
              return Number(prev + curr);
            } else {
              return prev;
            }
          }, 0);
          if(index === 4){
            sums[index] = sums[index].toFixed(0) + '%'
          }
        } else {
          sums[index] = '';
        }
      });
      return sums;
    }
  },
} 
</script>
<style lang="scss" scoped>
.inboundPage {
  .down {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    border-top: 1px solid #999;
    padding-top: 20px;
    box-sizing: border-box;
  }

  .underLine {
    cursor: pointer;
    color: #599af8;
    text-decoration: underline;
  }

  .success {
    color: rgb(137, 234, 137);
    font-size: 18px;
  }

  .error {
    color: rgb(238, 99, 99);
    font-size: 18px;
  }

  ::v-deep .el-dialog {
    border-radius: 8px !important;
  }

  ::v-deep .el-select--small {
    display: block;
  }

  ::v-deep .el-date-editor.el-input,
  .el-date-editor.el-input__inner {
    width: 100%;
  }
}
</style>
