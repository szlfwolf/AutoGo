<template>
  <div class="packingPage" v-loading="packingLoading">
    <el-row style="width:200px;display:flex" v-if="!switchStatus">
      <el-col>
        <el-button type="primary" icon="el-icon-search" @click="getSearchlist">Query</el-button>
      </el-col>
      <el-col>
        <el-button icon="el-icon-refresh-left" @click="getReset">Reset</el-button>
      </el-col>
    </el-row>
    <el-form ref="form" :model="form" style="margin: 20px 0" @keyup.enter.native="getSearchlist">
      <el-row :gutter="20">
        <el-col>
          <el-radio-group v-model="form.urgentType" v-for="(ite, index) in warehouseByClient" :key="index">
            <el-radio :label="ite.value" style="margin-right:10px"
              @change="getRadio">{{ ite.label }}</el-radio>
          </el-radio-group>
        </el-col>
        <el-col :span="4" style="margin-top: 10px" v-if="!switchStatus">
          <el-input v-model="form.orderNo" placeholder="DN Order no"></el-input>
        </el-col>
        <el-col :span="4" style="margin-top: 10px" v-if="!switchStatus">
          <el-select v-model="form.packingOnTime" placeholder="Packing on-time" filterable clearable>
            <el-option v-for="item in importOnTime" :key="item.value" :label="item.label" :value="item.value">
            </el-option>
          </el-select>
        </el-col>
      </el-row>
    </el-form>
    <div class="down">
      <div></div>
      <div>
        <el-button icon="el-icon-download" @click="exportExcel"
          v-if="permissions.statistics_dnhead_dnpunctuality_export && !switchStatus"></el-button>
        <el-button icon="el-icon-download" @click="exportExcel"
          v-else-if="permissions.statistics_dnhead_pack_punctuality_overview_export && switchStatus"></el-button>
      </div>
    </div>
    <el-table border ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%"
      v-loading="dataListLoading" :header-cell-style="{ background: '#f5f7fa', color: '#606266' }" v-show="!switchStatus">
      <el-table-column label="Owner" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.clientCode || '-' }}</template>
      </el-table-column>
      <el-table-column label="Warehouse" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.warehouseCode || '-' }}</template>
      </el-table-column>
      <el-table-column label="Statistics Date" min-width="140" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.statisticsDate || '-' }}</template>
      </el-table-column>
      <el-table-column label="Order no" min-width="140" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.orderNo || '-' }}</template>
      </el-table-column>
      <el-table-column label="Dn no" min-width="140" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.dnNo || '-' }}</template>
      </el-table-column>
      <el-table-column label="Urgent Type" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.urgentType || '-' }}</template>
      </el-table-column>
      <el-table-column label="Release Time" min-width="140" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.releaseTime || '-' }}</template>
      </el-table-column>
      <el-table-column label="Packed Time" min-width="140" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.packedTime || '-' }}</template>
      </el-table-column>
      <el-table-column label="Cut off time" min-width="140" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.packingCutOffTime || '-' }}</template>
      </el-table-column>
      <el-table-column label="Packing days" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.packingDays ? scope.row.packingDays : scope.row.packingDays == 0 ? 0 :
          '-' }}</template>
      </el-table-column>
      <el-table-column label="Packing KPI" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.packingKpi ? scope.row.packingKpi : scope.row.packingKpi == 0 ? 0 : '-'
        }}</template>
      </el-table-column>
      <el-table-column label="Packing on-time" min-width="120" align="center">
        <template slot-scope="scope"><i
            :class=" scope.row.packingDays == null ? 'el-icon-error error' : scope.row.packingDays <= scope.row.packingKpi ? 'el-icon-success success' : 'el-icon-error error'"></i></template>
      </el-table-column>
      <el-table-column label="Delay Remark" align="center" min-width="120" v-if="permissions.statistics_dnhead_dnpunctuality_update">
        <template slot-scope="scope">
          <i style="font-size: 18px;cursor: pointer;color:#65BEFF;margin-right:10px" class="el-icon-edit"
            v-if="permissions.statistics_dnhead_dnpunctuality_update" @click="editClick(scope.row, scope.$index)"></i>
        </template>
      </el-table-column>
    </el-table>
    <el-table border ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%" show-summary :summary-method="getSummaries"
      v-loading="dataListLoading" :header-cell-style="{ background: '#f5f7fa', color: '#606266' }" v-show="switchStatus">
      <el-table-column label="Owner" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.clientCode || '-' }}</template>
      </el-table-column>
      <el-table-column label="Warehouse" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.warehouseCode || '-' }}</template>
      </el-table-column>
      <el-table-column label="Days" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.packDays ? scope.row.packDays : scope.row.packDays == 0 ? 0 : '-' }}</template>
      </el-table-column>
      <el-table-column prop="orderNum" label="OrderNum" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.orderNum ? scope.row.orderNum : scope.row.orderNum == 0 ? 0 : '-' }}</template>
      </el-table-column>
      <el-table-column prop="packOnTimeRate" label="Rate" min-width="160" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.packOnTimeRate ? scope.row.packOnTimeRate : scope.row.packOnTimeRate == 0 ? 0 : '-' }}</template>
      </el-table-column>
    </el-table>
    <div style="margin-top: 20px;margin-right:100px;display:flex;justify-content: flex-end;" v-if="switchStatus">
      <label>Strict Packing On Time:</label>
      <div style="margin-left:5px">{{strictPackOnTimeRate}}</div>
    </div>
    <Pagination @handleSizeChange="handleSizeChange" @handleCurrentChange="handleCurrentChange" :pageNum="page.current"
    :pageSize="page.size" :total="total" v-if="!switchStatus"></Pagination>
    <Dialog v-if="dialogShow" :dialogShow="dialogShow" :title="title" @getClose="getClose" :row="row"></Dialog>
  </div>
</template>
<script>
import { mapGetters } from "vuex"
import Pagination from "@/components/pagination/pagination.vue"
import Dialog from "./dialog.vue"
import { dnPageQuery, packingOverView } from "@/api/statistics/punctuality"
import { remote } from "@/api/admin/dict"
import store from "@/store";
import { deepClone } from '@/util/util';
let formParams = {
  orderNo: undefined,
  packingOnTime: undefined,
  warehouseCode: undefined,
  statisticsDate: undefined,
  urgentType: 'All'
}
export default {
  name: "PackingPage",
  data() {
    return {
      form: Object.assign({}, formParams),
      total: 0,
      page: {
        size: 10,
        current: 1,
        remark: "packing",
        clientCode: store.getters.commandName
      },
      dataListLoading: false,
      tableData: [],
      warehouseByClient: [],
      importOnTime: [
        {
          label: 'Y',
          value: "1"
        },
        {
          label: 'N',
          value: "0"
        },
      ],
      dialogShow: false,//弹窗
      title: "",
      row: {},
      packingLoading: false,
      timeDate:"",
      strictPackOnTimeRate:""
    }
  },
  computed: {
    ...mapGetters(["permissions"]),
    changeData() {
      const { statisticsDate, warehouse } = this
      return { statisticsDate, warehouse }
    }
  },
  mounted() {
    this.exportExcel = this.$btn(this.exportExcel, 500)
  },
  props:{
    switchStatus: Boolean,
    warehouse:{
      type: String
    },
    statisticsDate:{
      type: String,
    }
  },
  components: {
    Pagination,
    Dialog
  },
  watch:{
    changeData:function(val){
      this.form.warehouseCode = val.warehouse
      this.form.statisticsDate = val.statisticsDate
      this.getList(this.form)
    },
    switchStatus:function(newV,oldV){
      this.getList(this.form)
    }
  },
  created() {
    let year = new Date().getFullYear()
    let month = (new Date()).getMonth()
    if (month < 10) {
      month = '0' + month
    }
    this.timeDate = year + '-' + month
    this.form.statisticsDate = this.statisticsDate
    this.form.warehouseCode = this.warehouse
    this.getList(this.form)
    this.getRemote()
  },
  methods: {
    //导出
    exportExcel() {
      this.packingLoading = true
      if(!this.switchStatus){
        this.downBlobFile("/statistics/dnHead/export", {
          ...this.form, remark: "packing",
          clientCode: store.getters.commandName
        }, `${this.$store.state.common.commandName}-Packing-${this.toDateFormat(new Date(), true)}.xlsx`, () => this.packingLoading = false)
      }else{
        this.downBlobFile("/statistics/dnHead/dnPackPunctualityOverviewExport", {
          urgentType:this.form.urgentType,warehouseCode:this.form.warehouseCode,statisticsDate:this.form.statisticsDate,
          clientCode: store.getters.commandName
        }, `${this.$store.state.common.commandName}-PackingDetail-${this.toDateFormat(new Date(), true)}.xlsx`, () => this.packingLoading = false)
      }
    },
    //条数
    handleSizeChange(val) {
      this.page.current = 1
      this.page.size = val
      this.getList(this.form)
    },
    //当前页数
    handleCurrentChange(val) {
      this.page.current = val
      this.getList(this.form)
    },
    //清空
    getReset() {
      this.$emit('getClear')
      this.form = Object.assign({}, formParams)
      this.page = this.$options.data().page
      this.form.warehouseCode = this.warehouse
      this.form.statisticsDate = this.timeDate
      
      if(this.statisticsDate != this.form.statisticsDate || this.warehouse != this.form.warehouseCode){
        return
      }
      this.getList(this.form)
    },
    //仓库选泽
    getRadio() {
      this.getSearchlist()
    },
    //查询
    getSearchlist() {
      this.page.current = 1
      for (let key in this.form) {
        if (this.form[key] === "" || this.form[key] === null) {
          this.form[key] = undefined;
        }
      }
      this.getList(this.form)
    },
    //数据列表
    getList(params) {
      this.dataListLoading = true
      if(!this.switchStatus){
        dnPageQuery(Object.assign({ ...this.page, warehouseCode: this.form.warehouseCode }, params)).then(res => {
          console.log(res)
          if (res.data.code === 0) {
            this.tableData = res.data.data.records
            this.total = res.data.data.total
            this.dataListLoading = false
          } else {
            this.$message.error(res.data.msg)
            this.dataListLoading = false
          }
        }).catch(() => {
          this.$message.error('request was aborted')
          this.dataListLoading = false
        })
      }else{
        packingOverView({urgentType:this.form.urgentType,warehouseCode: this.form.warehouseCode,statisticsDate: this.form.statisticsDate,clientCode: store.getters.commandName}).then(res=>{
          console.log(res);
          if(res.data.code === 0){
            this.tableData = res.data.data.dnPunctualityPackOverviews
            this.strictPackOnTimeRate = res.data.data.strictPackOnTimeRate
            this.dataListLoading = false
          } else {
            this.$message.error(res.data.msg)
            this.dataListLoading = false
          }
        }).catch(() => {
          this.$message.error('request was aborted')
          this.dataListLoading = false
        })
      }
    },
    getRemote(){
      //urgentType
      remote("urgent_level").then((res) => {
        if (res.data.code === 0) {
          res.data.data.unshift({value:'All',label:'All'})
          this.warehouseByClient = res.data.data;
        }
      });
    },
    //编辑
    editClick(row, index) {
      this.dialogShow = true
      this.title = 'Packing'
      this.row = row
    },
    //子传父关闭弹窗
    getClose(e, type) {
      this.dialogShow = e
      if (type) {
        this.getList(this.form)
      }
    },
    //计算列总和
    getSummaries(param) {
      const { columns, data } = param;
      const sums = [];
      let dataList = deepClone(data)
      dataList.forEach(ite=>{
        for (const key in ite) {
          if(key == 'packOnTimeRate'){
            let index = (ite.packOnTimeRate).indexOf('%')
            ite.packOnTimeRate = ite.packOnTimeRate.substring(0,index)
          }
        }
      })
      columns.forEach((column, index) => {
        if (index === 0) {
          sums[index] = 'Total';
          sums[1] = '';
          return;
        }
        const values = dataList.map(item => Number(item[column.property]));
        if (!values.every(value => isNaN(value))) {
          sums[index] = values.reduce((prev, curr) => {
            const value = Number(curr);
            if (!isNaN(value)) {
              return Number(prev + curr);
            } else {
              return prev;
            }
          }, 0);
          if(index === 4){
            sums[index] = sums[index].toFixed(0) + '%'
          }
        } else {
          sums[index] = '';
        }
      });
      return sums;
    }
  },
} 
</script>
<style lang="scss" scoped>
.packingPage {
  .down {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    border-top: 1px solid #999;
    padding-top: 20px;
    box-sizing: border-box;
  }

  .underLine {
    cursor: pointer;
    color: #599af8;
    text-decoration: underline;
  }

  .success {
    color: rgb(137, 234, 137);
    font-size: 18px;
  }

  .error {
    color: rgb(238, 99, 99);
    font-size: 18px;
  }

  ::v-deep .el-dialog {
    border-radius: 8px !important;
  }

  ::v-deep .el-select--small {
    display: block;
  }

  ::v-deep .el-date-editor.el-input,
  .el-date-editor.el-input__inner {
    width: 100%;
  }
}
</style>
