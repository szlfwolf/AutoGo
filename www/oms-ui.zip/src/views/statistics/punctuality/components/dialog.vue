<template>
  <div>
    <el-dialog
      :title="title"
      :visible="dialogShow"
      width="35%"
      style="font-weight: 700"
      @close="getClose"
    >
      <el-form :model="formDialog" ref="form" :rules="rules" label-width="100px">
        <el-form-item label="Remark:" prop="delayRemark">
          <el-input type="textarea" v-model="formDialog.delayRemark " placeholder="请输入..." clearable></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button type="info" @click="getClose">Cancel</el-button>
        <el-button type="primary" @click="dialogButton">Submit</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script>
import { punctualRemark, dnPunctualRemark, asnPunctualityImportUpdate } from "@/api/statistics/punctuality"
export default {
  data() {
    return {
      formDialog:{
        delayRemark :"",
        remark:""
      },
      rules:{
        delayRemark :[{ required: true, message: '请输入备注', trigger: 'blur' },
        { max: 255, message: '长度最大 255 个字符', trigger: 'blur' }]
      }
    };
  },
  props:{
    title:{
      type: String
    },
    dialogShow:{
      type: Boolean
    },
    row:{
      type: Object
    }
  },
  created() {
    console.log(this.row);
    if(this.title === 'Import'){
      this.formDialog.delayRemark = this.row.importDelayRemark
      this.formDialog.remark = 'import'
    }else if(this.title === 'Inbound'){
      this.formDialog.delayRemark = this.row.inboundDelayRemark
      this.formDialog.remark = 'inbound'
    }else if(this.title === 'Packing'){
      this.formDialog.delayRemark = this.row.packingDelayRemark
      this.formDialog.remark = 'packing'
    }else if(this.title === 'Ship-Out'){
      this.formDialog.delayRemark = this.row.shipOutDelayRemark
      this.formDialog.remark = 'shipOut'
    }else{
      this.formDialog.delayRemark = this.row.deliveryDelayRemark
      this.formDialog.remark = 'delivery'
    }
  },
  methods: {
    //关闭弹窗
    getClose(){
      this.$emit('getClose',false)
      this.$refs.form.resetFields();
    },
    dialogButton(){
      if(this.title === 'Import'){
        this.$refs.form.validate((valid) => {
          if (!valid) return false
          asnPunctualityImportUpdate(Object.assign({id:this.row.id},this.formDialog)).then(res=>{
            if(res.data.code === 0){
              this.$emit('getClose',false,'refresh')
              this.$message.success("Update succeeded")
            }else{
              this.$emit('getClose',false)
              this.$message.error(res.data.msg)
            }
          }).catch(()=>{
            this.$emit('getClose',false)
          })
        })
      }else if(this.title === 'Inbound'){
        this.$refs.form.validate((valid) => {
          if (!valid) return false
          punctualRemark(Object.assign({id:this.row.id},this.formDialog)).then(res=>{
            if(res.data.code === 0){
              this.$emit('getClose',false,'refresh')
              this.$message.success("Update succeeded")
            }else{
              this.$emit('getClose',false)
              this.$message.error(res.data.msg)
            }
          }).catch(()=>{
            this.$emit('getClose',false)
          })
        })
      }else{
        this.$refs.form.validate((valid) => {
          if (!valid) return false
          dnPunctualRemark(Object.assign({id:this.row.id},this.formDialog)).then(res=>{
            if(res.data.code === 0){
              this.$emit('getClose',false,'refresh')
              this.$message.success("Update succeeded")
            }else{
                this.$emit('getClose',false)
                this.$message.error(res.data.msg)
            }
          }).catch(()=>{
              this.$emit('getClose',false)
          })
        })
      }
    }
  },
};
</script>
<style lang="scss" scoped></style>
