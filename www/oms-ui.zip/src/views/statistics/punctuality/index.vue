<template>
  <div>
    <TopPage @calendar="calendar" @getRadio="getRadio" :type="false" :status="true" @getSwitch="getSwitch" ref="topPage"></TopPage>
    <div class="content">
      <el-tabs type="border-card" v-model="activeName" @tab-click="handleClick">
        <el-tab-pane label="Import" name="Import" v-loading="importLoading">
          <el-row style="width:200px;display:flex" v-if="!switchStatus">
            <el-col>
              <el-button type="primary" icon="el-icon-search" @click="getSearchlist">Query</el-button>
            </el-col>
            <el-col>
              <el-button icon="el-icon-refresh-left" @click="getReset">Reset</el-button>
            </el-col>
          </el-row>
          <el-form ref="form" :model="form" style="margin: 20px 0" @keyup.enter.native="getSearchlist">
            <el-row :gutter="20">
              <el-col>
                <el-radio-group v-model="form.shipType" v-for="(ite, index) in warehouseByClient" :key="index">
                  <el-radio :label="ite.value" style="margin-right:10px"
                    @change="getTransportType">{{ ite.value }}</el-radio>
                </el-radio-group>
              </el-col>
              <el-col :span="4" style="margin-top: 10px" v-if="!switchStatus">
                <el-input v-model="form.blNo" placeholder="BL no"></el-input>
              </el-col>
              <el-col :span="4" style="margin-top: 10px" v-if="!switchStatus">
                <el-select v-model="form.importOnTime" placeholder="Import on-time" filterable clearable>
                  <el-option v-for="item in importOnTime" :key="item.value" :label="item.label" :value="item.value">
                  </el-option>
                </el-select>
              </el-col>
            </el-row>
          </el-form>
          <div class="down">
            <div></div>
            <div>
              <el-button icon="el-icon-download" @click="exportExcel"
                v-if="permissions.statistics_asnhead_asnpunctuality_import_export && !switchStatus "></el-button>
              <el-button icon="el-icon-download" @click="exportExcel"
                v-else-if="permissions.statistics_asnhead_asnpunctuality_import_overview_export && switchStatus"></el-button>
            </div>
          </div>
          <el-table border ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%"
            v-loading="dataListLoading" :header-cell-style="{ background: '#f5f7fa', color: '#606266' }" v-show="!switchStatus">
            <el-table-column label="Owner" min-width="120" align="center" show-overflow-tooltip>
              <template slot-scope="scope">{{ scope.row.clientCode || '-' }}</template>
            </el-table-column>
            <el-table-column label="Warehouse" min-width="120" align="center" show-overflow-tooltip>
              <template slot-scope="scope">{{ scope.row.warehouseCode || '-' }}</template>
            </el-table-column>
            <el-table-column label="Statistics Date" min-width="140" align="center" show-overflow-tooltip>
              <template slot-scope="scope">{{ scope.row.statisticsDate || '-' }}</template>
            </el-table-column>
            <el-table-column label="BL no" min-width="120" align="center" show-overflow-tooltip>
              <template slot-scope="scope">{{ scope.row.blNo || '-' }}</template>
            </el-table-column>
            <el-table-column label="ContainerNo" min-width="140" align="center" show-overflow-tooltip>
              <template slot-scope="scope">{{ scope.row.asnNo || '-' }}</template>
            </el-table-column>
            <el-table-column label="Ship Type" min-width="120" align="center" show-overflow-tooltip>
              <template slot-scope="scope">{{ scope.row.shipType || '-' }}</template>
            </el-table-column>
            <el-table-column label="ATA Port" min-width="140" align="center" show-overflow-tooltip>
              <template slot-scope="scope">{{ scope.row.arrivedTime || '-' }}</template>
            </el-table-column>
            <el-table-column label="ATA WH" min-width="140" align="center" show-overflow-tooltip>
              <template slot-scope="scope">{{ scope.row.releaseTime || '-' }}</template>
            </el-table-column>
            <el-table-column label="Port Transit Leadtime" min-width="160" align="center" show-overflow-tooltip>
              <template slot-scope="scope">{{ scope.row.importDays ? scope.row.importDays : scope.row.importDays == 0 ? 0 :
                '-' }}</template>
            </el-table-column>
            <el-table-column label="Import KPI" min-width="120" align="center" show-overflow-tooltip>
              <template slot-scope="scope">{{ scope.row.importKpi ? scope.row.importKpi : scope.row.importKpi == 0 ? 0 : '-'
              }}</template>
            </el-table-column>
            <el-table-column label="Import on-time" min-width="120" align="center">
              <template slot-scope="scope"><i
                  :class="scope.row.importDays == null? 'el-icon-error error' : scope.row.importDays <= scope.row.importKpi ? 'el-icon-success success' : 'el-icon-error error'"></i></template>
            </el-table-column>
            <el-table-column label="Delay Remark" align="center" min-width="120" v-if="permissions.statistics_asnhead_asnpunctuality_import_update"> 
              <template slot-scope="scope">
                <i style="font-size: 18px;cursor: pointer;color:#65BEFF;margin-right:10px" class="el-icon-edit"
                  v-if="permissions.statistics_asnhead_asnpunctuality_import_update"
                  @click="editClick(scope.row, scope.$index)"></i>
              </template>
            </el-table-column>
          </el-table>
          <el-table border ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%"
            v-loading="dataListLoading" :header-cell-style="{ background: '#f5f7fa', color: '#606266' }" v-show="switchStatus">
            <el-table-column label="Owner" min-width="120" align="center" show-overflow-tooltip>
              <template slot-scope="scope">{{ scope.row.clientCode || '-' }}</template>
            </el-table-column>
            <el-table-column label="Warehouse" min-width="120" align="center" show-overflow-tooltip>
              <template slot-scope="scope">{{ scope.row.warehouseCode || '-' }}</template>
            </el-table-column>
            <el-table-column label="Ship Type" min-width="120" align="center" show-overflow-tooltip>
              <template slot-scope="scope">{{ scope.row.shipType || '-' }}</template>
            </el-table-column>
            <el-table-column label="AsnNum" min-width="120" align="center" show-overflow-tooltip>
              <template slot-scope="scope">{{ scope.row.asnNum ? scope.row.asnNum : scope.row.asnNum == 0 ? 0 : '-' }}</template>
            </el-table-column>
            <el-table-column label="Kpi Requested" min-width="120" align="center" show-overflow-tooltip>
              <template slot-scope="scope">{{ scope.row.kpiRequested ? scope.row.kpiRequested : scope.row.kpiRequested == 0 ? 0 : '-' }}</template>
            </el-table-column>
            <el-table-column label="Import on time rate" min-width="160" align="center" show-overflow-tooltip>
              <template slot-scope="scope">{{ scope.row.importOnTimeRate ? scope.row.importOnTimeRate : scope.row.importOnTimeRate == 0 ? 0 : '-' }}</template>
            </el-table-column>
          </el-table>
          <Pagination @handleSizeChange="handleSizeChange" @handleCurrentChange="handleCurrentChange"
           :pageNum="page.current" :pageSize="page.size" :total="total" v-if="!switchStatus"></Pagination>
          <Dialog v-if="dialogShow" :dialogShow="dialogShow" :title="title" @getClose="getClose" :row="row"></Dialog>
        </el-tab-pane>
        <el-tab-pane label="Inbound" name="Inbound">
          <InboundPage v-if="inbound" :switchStatus="switchStatus" :warehouse="form.warehouseCode" :statisticsDate="form.statisticsDate" @getClear="getClear"></InboundPage>
        </el-tab-pane>
        <el-tab-pane label="Packing" name="Packing">
          <PackingPage v-if="packing" :switchStatus="switchStatus" :warehouse="form.warehouseCode" :statisticsDate="form.statisticsDate" @getClear="getClear"></PackingPage>
        </el-tab-pane>
        <el-tab-pane label="Ship-out" name="Ship-out">
          <ShipoutPage v-if="shipOut" :switchStatus="switchStatus" :warehouse="form.warehouseCode" :statisticsDate="form.statisticsDate" @getClear="getClear"></ShipoutPage>
        </el-tab-pane>
        <el-tab-pane label="Delivery" name="Delivery">
          <DeliveryPage v-if="delivery" :switchStatus="switchStatus" :warehouse="form.warehouseCode" :statisticsDate="form.statisticsDate" @getClear="getClear"></DeliveryPage>
        </el-tab-pane>
      </el-tabs>
    </div>  
  </div>
</template>
<script>
import TopPage from "../components/index.vue";
import { mapGetters } from "vuex"
import Pagination from "@/components/pagination/pagination.vue"
import InboundPage from "./components/inboundPage.vue"
import PackingPage from "./components/packingPage.vue"
import ShipoutPage from "./components/shipoutPage.vue"
import DeliveryPage from "./components/deliveryPage.vue"
import Dialog from "./components/dialog.vue"
import { asnPunctualityImportPage, punctualRemark, importOverView } from "@/api/statistics/punctuality"
import { getWarehouseByClient } from "@/api/stock/subwarehouse";
import { remote } from "@/api/admin/dict"
import store from "@/store"
let formParams = {
  blNo: undefined,
  importOnTime: undefined,
  warehouseCode: undefined,
  statisticsDate: undefined,
  shipType: 'All'
}
export default {
  name: "Order",
  data() {
    return {
      info: {},
      form: Object.assign({}, formParams),
      total: 0,
      page: {
        size: 10,
        current: 1,
        clientCode: store.getters.commandName
      },
      dataListLoading: false,
      activeName: "Import",
      options: [],
      tableData: [],
      show: false,
      warehouseByClient: [],
      importOnTime: [
        {
          label: 'Y',
          value: "1"
        },
        {
          label: 'N',
          value: "0"
        },
      ],
      inbound: false,
      packing: false,
      shipOut: false,
      delivery: false,
      dialogShow: false,//弹窗
      title: "",
      row: {},
      importLoading: false,
      switchStatus: false,
      timeDate:'',
      warehouseInit:[]
    }
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  mounted() {
    this.exportExcel = this.$btn(this.exportExcel, 500)
  },
  components: {
    Pagination,
    InboundPage,
    PackingPage,
    ShipoutPage,
    DeliveryPage,
    Dialog,
    TopPage
  },
  created() {
    let year = new Date().getFullYear()
    let month = (new Date()).getMonth()
    //  + 1
    if (month < 10) {
      month = '0' + month
    }
    this.timeDate = year + '-' + month
    this.form.statisticsDate = year + '-' + month
    // this.getWarehouseByClient()
    // this.getList(this.form)
    this.getRemote()
  },
  methods: {
    //切换
    handleClick() {
      if (this.activeName === 'Inbound') {
        this.inbound = true
        this.packing = false
        this.shipOut = false
        this.delivery = false
      } else if (this.activeName === 'Packing') {
        this.inbound = false
        this.packing = true
        this.shipOut = false
        this.delivery = false
      } else if (this.activeName === 'Ship-out') {
        this.inbound = false
        this.packing = false
        this.shipOut = true
        this.delivery = false
      } else if (this.activeName === 'Delivery') {
        this.inbound = false
        this.packing = false
        this.shipOut = false
        this.delivery = true
      } else {
        this.inbound = false
        this.packing = false
        this.shipOut = false
        this.delivery = false
        this.getSearchlist()//table数据
      }
    },
    // 单选
    getRadio(e) {
      console.log("当前选择的仓库", e);
      this.form.warehouseCode = e
      if (this.activeName === 'Import') {
        this.getList(this.form)
      }
    },
    // 子组件传过来的日期
    calendar(e) {
      this.form.statisticsDate = e.year + '-' + e.month
      if (this.activeName === 'Import') {
        this.getList(this.form)
      }
    },
    getSwitch(e){
      this.switchStatus = e
      if (this.activeName === 'Import') {
        this.getList(this.form)
      }
    },
    //运输类型选择
    getTransportType(e){
      console.log(e);
      this.form.shipType = e
      this.getSearchlist()
    },
    //查询仓库..
    getWarehouseByClient() {
      getWarehouseByClient().then((res) => {
        console.log(res);
        if (res.data.code === 0) {
          this.warehouseInit = res.data.data
          this.form.warehouseCode =  res.data.data[0].warehouseCode
          this.getList(this.form)
        }
      });
    },
    //导出
    exportExcel() {
      this.importLoading = true
      if(!this.switchStatus){
        this.downBlobFile("/statistics/asnHead/asnPunctualityImportExport", {
          ...this.form,
          clientCode: store.getters.commandName
        }, `${this.$store.state.common.commandName}-Import-${this.toDateFormat(new Date(), true)}.xlsx`, () => this.importLoading = false)
      }else{
        this.downBlobFile("/statistics/asnHead/asnPunctualityImportOverviewExport", {
          shipType:this.form.shipType,warehouseCode:this.form.warehouseCode,statisticsDate:this.form.statisticsDate,
          clientCode: store.getters.commandName
        }, `${this.$store.state.common.commandName}-ImportDetail-${this.toDateFormat(new Date(), true)}.xlsx`, () => this.importLoading = false)
      }
    },
    //条数
    handleSizeChange(val) {
      this.page.current = 1
      this.page.size = val
      this.getList(this.form)
    },
    //当前页数  
    handleCurrentChange(val) {
      this.page.current = val
      this.getList(this.form)
    },
    //清空
    getReset() {
      this.form = Object.assign({}, formParams)
      this.page = this.$options.data().page

      this.form.shipType = this.warehouseByClient[0].value
      // this.form.warehouseCode = this.warehouseInit[0].warehouseCode
      this.form.statisticsDate = this.timeDate
      this.getClear()
      // this.getList(this.form)
    },
    //查询
    getSearchlist() {
      this.page.current = 1
      for (let key in this.form) {
        if (this.form[key] === "" || this.form[key] === null) {
          this.form[key] = undefined;
        }
      }
      this.getList(this.form)
    },
    //数据列表
    getList(params) {
      this.dataListLoading = true
      if(!this.switchStatus){
        asnPunctualityImportPage(Object.assign({ ...this.page, warehouseCode: this.form.warehouseCode }, params)).then(res => {
          console.log(res)
          if (res.data.code === 0) {
            this.tableData = res.data.data.records
            this.total = res.data.data.total
            this.dataListLoading = false
          } else {
            this.$message.error(res.data.msg)
            this.dataListLoading = false
          }
        }).catch(() => {
          this.$message.error('request was aborted')
          this.dataListLoading = false
        })
      }else{
        importOverView({shipType:this.form.shipType,warehouseCode: this.form.warehouseCode,statisticsDate: this.form.statisticsDate,clientCode: store.getters.commandName}).then(res=>{
          console.log(res);
          if (res.data.code === 0) {
            this.tableData = res.data.data
            this.dataListLoading = false
          } else {
            this.$message.error(res.data.msg)
            this.dataListLoading = false
          }
        }).catch(() => {
          this.$message.error('request was aborted')
          this.dataListLoading = false
        })
      }
      
    },
    getRemote(){
      //shipType
      remote("bl_ship_type").then((res) => {
        if (res.data.code === 0) {
          res.data.data.unshift({value:'All',label:'All'})
          this.warehouseByClient = res.data.data;
        }
      });
    },
    //编辑
    editClick(row, index) {
      this.dialogShow = true
      this.title = 'Import'
      this.row = row
    },
    //子传父关闭弹窗
    getClose(e, type) {
      this.dialogShow = e
      if (type) {
        this.getList(this.form)
      }
    },
    getClear(){
      this.$refs.topPage.getRest()
    }
  },
} 
</script>
<style lang="scss" scoped>
.content {
  padding: 0 10px;
  margin-top: 20px;
  // box-sizing: border-box;
  .down {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    border-top: 1px solid #999;
    padding-top: 20px;
    box-sizing: border-box;
  }

  .underLine {
    cursor: pointer;
    color: #599af8;
    text-decoration: underline;
  }

  .success {
    color: rgb(137, 234, 137);
    font-size: 18px;
  }

  .error {
    color: rgb(238, 99, 99);
    font-size: 18px;
  }

  ::v-deep .el-dialog {
    border-radius: 8px !important;
  }

  ::v-deep .el-select--small {
    display: block;
  }

  ::v-deep .el-date-editor.el-input,
  .el-date-editor.el-input__inner {
    width: 100%;
  }
}
</style>
