<!-- //在Echarts.vue文件中 -->
<template>
    <div style="background-color:#f0f2f5;">
        <TopPage @calendar=calendar></TopPage>
        <div class="efficiency">
            <div class="Echarts">
                <div class="title">
                    <label class="title-text"> Warehouse Efficiency</label>
                </div>
                <el-row>
                    <el-col :span="8">
                        <div class="mainStyle">
                            <div id="main" style="width: 100%;height: 100%;">
                            </div>
                            <p>库容率</p>
                        </div>
                    </el-col>
                    <el-col :span="8">
                        <div class="mainStyle">
                            <div id="main2" style="width: 100%;height: 100%;">
                            </div>
                        </div>
                    </el-col>
                    <el-col :span="8">
                        <div class="mainStyle">
                            <div id="main1" style="width: 100%;height: 100%;">
                            </div>
                            <p>年度周转率</p>
                        </div>
                    </el-col>
                </el-row>
            </div>
        </div>
        <div class="efficiency" style="margin-top:30px;">
            <div class="Echarts">
                <div class="title">
                    <label class="title-text"> Within time limit</label>
                </div>
                <el-row>
                    <el-col :span="6">
                        <div class="mainStyle1">
                            <div id="main01" style="width: 100%;height:  100%;">
                            </div>
                            <p>Import</p>
                        </div>
                    </el-col>
                    <el-col :span="6">
                        <div class="mainStyle1">
                            <div id="main02" style="width: 100%;height:  100%;">
                            </div>
                            <p>Inbound</p>
                        </div>
                    </el-col>
                    <el-col :span="6">
                        <div class="mainStyle1">
                            <div id="main03" style="width: 100%;height:  100%;">
                            </div>
                            <p>Outbound</p>
                        </div>
                    </el-col>
                    <el-col :span="6">
                        <div class="mainStyle1">
                            <div id="main04" style="width: 100%;height:  100%;">
                            </div>
                            <p>Ship</p>
                        </div>
                    </el-col>
                </el-row>
            </div>
        </div>
    </div>
</template>
 
<script>
import TopPage from '../components/index.vue'
export default {
    name: 'Echarts',
    data() {
        return {

        }
    },
    mounted() {
        this.myEcharts();
    },
    components: {
        TopPage
    },
    methods: {
        myEcharts() {
            var myChart = this.$echarts.init(document.getElementById('main'));
            var myChart1 = this.$echarts.init(document.getElementById('main1'));
            var myChart2 = this.$echarts.init(document.getElementById('main2'));

            var myChart01 = this.$echarts.init(document.getElementById('main01'));
            var myChart02 = this.$echarts.init(document.getElementById('main02'));
            var myChart03 = this.$echarts.init(document.getElementById('main03'));
            var myChart04 = this.$echarts.init(document.getElementById('main04'));
            var option = {
                series: [
                    {
                        type: 'gauge',
                        progress: {
                            show: true,
                            width: 10
                        },
                        axisLine: {
                            lineStyle: {
                                width: 10
                            }
                        },
                        axisTick: {
                            show: false
                        },
                        splitLine: {
                            length: 6,
                            lineStyle: {
                                width: 2,
                                color: '#999'
                            }
                        },
                        axisLabel: {
                            distance: 15,
                            color: '#999',
                            fontSize: 12
                        },
                        anchor: {
                            show: true,
                            showAbove: true,
                            size: 15,
                            itemStyle: {
                                borderWidth: 5
                            }
                        },
                        title: {
                            show: false
                        },
                        detail: {
                            valueAnimation: true,
                            fontSize: 30,
                            offsetCenter: [0, '70%']
                        },
                        data: [
                            {
                                value: 70
                            },

                        ]
                    }
                ]
            };
            var option2 = {
                title: {
                    // text: 'Accumulated Waterfall Chart'
                },
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        type: 'shadow'
                    },
                    formatter: function (params) {
                        let tar;
                        if (params[1] && params[1].value !== '-') {
                            tar = params[1];
                        } else {
                            tar = params[2];
                        }
                        return tar && tar.name + '<br/>' + tar.seriesName + ' : ' + tar.value;
                    }
                },
                legend: {
                    data: ['年度周转率']
                },
                grid: {
                    left: '3%',
                    right: '4%',
                    bottom: '3%',
                    containLabel: true
                },
                xAxis: {
                    type: 'category',
                    data: (function () {
                        let list = [];
                        for (let i = 1; i <= 11; i++) {
                            list.push(i + '月');
                        }
                        return list;
                    })()
                },
                yAxis: {
                    type: 'value'
                },
                series: [
                    {
                        name: 'Placeholder',
                        type: 'bar',
                        stack: 'Total',
                        silent: true,
                        itemStyle: {
                            borderColor: 'transparent',
                            color: 'transparent'
                        },
                        emphasis: {
                            itemStyle: {
                                borderColor: 'transparent',
                                color: 'transparent'
                            }
                        },
                        data: [0, 0.3, 0.6, 0.9, 1.2, 1.5]
                    },
                    {
                        name: '年度周转率',
                        type: 'bar',
                        stack: 'Total',
                        label: {
                            show: true,
                            position: 'top'
                        },
                        data: [0.1, 0.12, 0.13, 0.14, 0.09, 0.15,]
                    },

                ]
            };
            //---------------
            var option01 = {
                tooltip: {
                    trigger: 'item'
                },
                legend: {
                    top: '5%',
                    left: 'center'
                },
                series: [
                    {
                        name: 'Access From',
                        type: 'pie',
                        radius: ['40%', '70%'],
                        avoidLabelOverlap: false,
                        itemStyle: {
                            borderRadius: 10,
                            borderColor: '#fff',
                            borderWidth: 2
                        },
                        label: {
                            show: false,
                            position: 'center'
                        },
                        emphasis: {
                            label: {
                                show: true,
                                fontSize: '20',
                                fontWeight: 'bold'
                            }
                        },
                        labelLine: {
                            show: false
                        },
                        data: [
                            { value: 1048, name: 'In time' },
                            { value: 10, name: 'Out Time' },

                        ]
                    }
                ]
            };
            var option02 = {
                tooltip: {
                    trigger: 'item'
                },
                legend: {
                    top: '5%',
                    left: 'center'
                },
                series: [
                    {
                        name: 'Access From',
                        type: 'pie',
                        radius: ['40%', '70%'],
                        avoidLabelOverlap: false,
                        itemStyle: {
                            borderRadius: 10,
                            borderColor: '#fff',
                            borderWidth: 2
                        },
                        label: {
                            show: false,
                            position: 'center'
                        },
                        emphasis: {
                            label: {
                                show: true,
                                fontSize: '20',
                                fontWeight: 'bold'
                            }
                        },
                        labelLine: {
                            show: false
                        },
                        data: [
                            { value: 1048, name: 'In time' },
                            { value: 10, name: 'Out Time' },

                        ]
                    }
                ]
            };
            var option03 = {
                tooltip: {
                    trigger: 'item'
                },
                legend: {
                    top: '5%',
                    left: 'center'
                },
                series: [
                    {
                        name: 'Access From',
                        type: 'pie',
                        radius: ['40%', '70%'],
                        avoidLabelOverlap: false,
                        itemStyle: {
                            borderRadius: 10,
                            borderColor: '#fff',
                            borderWidth: 2
                        },
                        label: {
                            show: false,
                            position: 'center'
                        },
                        emphasis: {
                            label: {
                                show: true,
                                fontSize: '20',
                                fontWeight: 'bold'
                            }
                        },
                        labelLine: {
                            show: false
                        },
                        data: [
                            { value: 1048, name: 'In time' },
                            { value: 10, name: 'Out Time' },

                        ]
                    }
                ]
            };
            var option04 = {
                tooltip: {
                    trigger: 'item'
                },
                legend: {
                    top: '5%',
                    left: 'center'
                },
                series: [
                    {
                        name: 'Access From',
                        type: 'pie',
                        radius: ['40%', '70%'],
                        avoidLabelOverlap: false,
                        itemStyle: {
                            borderRadius: 10,
                            borderColor: '#fff',
                            borderWidth: 2
                        },
                        label: {
                            show: false,
                            position: 'center'
                        },
                        emphasis: {
                            label: {
                                show: true,
                                fontSize: '20',
                                fontWeight: 'bold'
                            }
                        },
                        labelLine: {
                            show: false
                        },
                        data: [
                            { value: 1048, name: 'In time' },
                            { value: 10, name: 'Out Time' },

                        ]
                    }
                ]
            };

            myChart.setOption(option);
            myChart1.setOption(option);
            myChart2.setOption(option2);

            myChart01.setOption(option01);
            myChart02.setOption(option02);
            myChart03.setOption(option03);
            myChart04.setOption(option04);
        },
        // 子组件传过来的日期
        calendar(e) {
            console.log('日历', JSON.parse(JSON.stringify(e)))
        },
    },

}
</script>
 
<style lang="scss" scoped>
.efficiency {
    width: 90%;
    height: 350px;
    border-color: rgb(236, 235, 235);
    border-width: 1px;
    border-style: solid;
    box-shadow: rgb(7 17 27 / 10%) 0px 8px 16px 0px;
    border-radius: 12px;
    padding: 0px;
    text-align: center;
    background: rgb(255, 255, 255);
    padding: 20px 20px;
    margin: 0 auto;
}

.title-text {
    font-family: SourceHanSansSC;
    font-weight: 700;
    color: rgb(16, 16, 16);
    font-style: normal;
    letter-spacing: 0px;
    line-height: 20px;
    text-decoration: none;
}

.title {
    width: 100%;
    height: 30px;
    line-height: 30px;
    display: flex;
    margin-bottom: 10px;
}

.mainStyle {
    width: 460px;
    height: 306.6px;
    display: flex;
    justify-content: center;
    flex-direction: column;
}

.mainStyle1 {
    width: 360px;
    height: 329px;
    display: flex;
    justify-content: center;
    flex-direction: column;
}
</style>