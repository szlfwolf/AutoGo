<template>
  <div class="content" v-loading="efficiencyLoading">
    <el-card class="box-card">
      <el-row style="width: 200px; display: flex">
        <el-col>
          <el-button type="primary" icon="el-icon-search" @click="getSearchlist">Query</el-button>
        </el-col>
        <el-col>
          <el-button icon="el-icon-refresh-left" @click="getReset">Reset</el-button>
        </el-col>
      </el-row>
      <el-form ref="form" :model="form" style="margin: 20px 0" @keyup.enter.native="getSearchlist">
        <el-row :gutter="20">
          <el-col style="margin-bottom: 20px">
            <el-radio-group v-model="form.warehouseCode" v-for="(ite, index) in warehouseByClient" :key="index">
              <el-radio :label="ite.warehouseCode" style="margin-right: 10px" @change="getRadio">{{ ite.warehouseName
                              }}</el-radio>
            </el-radio-group>
          </el-col>
          <el-col :span="4">
            <el-date-picker v-model="form.planCountingDate" type="date" value-format="yyyy-MM-dd"
              placeholder="Plan Counting Date">
            </el-date-picker>
          </el-col>
          <el-col :span="4">
            <el-input v-model="form.partNumber" placeholder="Sku no"></el-input>
          </el-col>
          <el-col :span="4">
            <el-select filterable v-model="form.isDiscrepancy" placeholder="Has difference" filterable clearable>
              <el-option v-for="item in differenceList" :key="item.value" :label="item.label" :value="item.value">
              </el-option>
            </el-select>
          </el-col>
          <!-- <el-col :span="8" style="height:32px;line-height:32px;color:#606266">
            <label>准确率 (By金额):</label>
            <span style="margin-left:20px">{{ inventoryCountingRate }}</span>
          </el-col> -->
        </el-row>
      </el-form>
      <div class="down">
        <div style="flex:1">
          <el-row>
            <el-col :span="6">
              <span style="display:inline-block;width:80px;text-align:right">当天</span> :&nbsp;&nbsp;&nbsp; 准确率(By金额) :
              {{currentInventoryCountingRate}}
            </el-col>
            <el-col :span="4">
              盘亏 : {{currentInventoryLosses}}EUR
            </el-col>
            <el-col :span="4">
              盘盈 : {{currentInventoryProfit}}EUR
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="6">
              <span style="display:inline-block;width:80px;text-align:right">截至当天</span> :&nbsp;&nbsp;&nbsp; 准确率(By金额) :
              {{toCurrentInventoryCountingRate}}
            </el-col>
            <el-col :span="4">
              盘亏 : {{toCurrentInventoryLosses}}EUR
            </el-col>
            <el-col :span="4">
              盘盈 : {{toCurrentInventoryProfit}}EUR
            </el-col>
          </el-row>
        </div>
        <div>
          <el-button icon="el-icon-download" @click="exportExcel"
            v-if="permissions.statistics_inventorycounting_export"></el-button>
        </div>
      </div>
      <el-table border ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%"
        v-loading="dataListLoading" :header-cell-style="{ background: '#f5f7fa', color: '#606266' }">
        <el-table-column label="Owner" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.clientCode || "-" }}</template>
        </el-table-column>
        <el-table-column label="Warehouse" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.warehouseCode || "-" }}</template>
        </el-table-column>
        <el-table-column label="Sku" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.partNumber || "-" }}</template>
        </el-table-column>
        <el-table-column label="Half-yearly A/B/C" min-width="160" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.halfYearlyType ? scope.row.halfYearlyType : scope.row.halfYearlyType
                      == 0 ? 0 : '-' }}</template>
        </el-table-column>
        <el-table-column label="Plan Counting Date" min-width="160" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.planCountingDate ? scope.row.planCountingDate :
                      scope.row.planCountingDate == 0 ? 0 : '-' }}</template>
        </el-table-column>
        <el-table-column label="Actual Qty" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.actualQty ? scope.row.actualQty : scope.row.actualQty
                      == 0 ? 0 : '-' }}</template>
        </el-table-column>
        <el-table-column label="Plan Qty" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.planQty ? scope.row.planQty : scope.row.planQty == 0 ? 0 : '-'
                      }}</template>
        </el-table-column>
        <el-table-column label="Difference Qty" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.discrepancyQty ? scope.row.discrepancyQty : scope.row.discrepancyQty
                      == 0 ? 0 : '-' }}</template>
        </el-table-column>
        <el-table-column label="Buy Price" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.skuPrice ? scope.row.skuPrice : scope.row.skuPrice == 0 ? 0 : '-'
                      }}</template>
        </el-table-column>
        <el-table-column label="Difference Price" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.differencePrice ? scope.row.differencePrice :
                      scope.row.differencePrice == 0 ? 0 : '-' }}</template>
        </el-table-column>
      </el-table>
      <Pagination @handleSizeChange="handleSizeChange" @handleCurrentChange="handleCurrentChange" :pageNum="page.current"
        :pageSize="page.size" :total="total"></Pagination>
    </el-card>
  </div>
</template>
<script>
import { mapGetters } from "vuex";
import Pagination from "@/components/pagination/pagination.vue";
import { pageQuery } from "@/api/statistics/inventoryCountingJob";
import { getWarehouseByClient, } from "@/api/stock/subwarehouse";
import store from "@/store";
let formParams = {
  planCountingDate: undefined,
  partNumber: undefined,
  isDiscrepancy: undefined,
};
export default {
  name: "WeeklyVolumeRate",
  data() {
    return {
      form: Object.assign({}, formParams),
      total: 0,
      page: {
        size: 10,
        current: 1,
        clientCode: store.getters.commandName,
      },
      differenceList: [
        {
          value: 1,
          label: "Y",
        },
        {
          value: 0,
          label: "N",
        },
      ],
      dataListLoading: false,
      tableData: [],
      warehouseByClient: [],
      efficiencyLoading: false,
      currentInventoryCountingRate : 0,
      currentInventoryProfit : 0,
      currentInventoryLosses : 0,
      toCurrentInventoryCountingRate :0 ,
      toCurrentInventoryProfit : 0,
      toCurrentInventoryLosses : 0,
    };
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  mounted() {
    this.exportExcel = this.$btn(this.exportExcel, 500);
  },
  components: {
    Pagination,
  },
  created() {
    this.form.planCountingDate = this.toDateFormat(new Date(),true);
    this.getWarehouseByClient();
  },
  methods: {
    //查询仓库..
    getWarehouseByClient() {
      getWarehouseByClient().then((res) => {
        console.log(res);
        if (res.data.code === 0) {
          this.warehouseByClient = res.data.data;
          this.form.warehouseCode = this.warehouseByClient[0].warehouseCode;
          this.getList(this.form);
        }
      });
    },
    //导出
    exportExcel() {
      this.efficiencyLoading = true
      this.downBlobFile(
        "/statistics/stockSnapShoot/exportInventoryCounting",
        { ...this.form, warehouseCode: this.form.warehouseCode, clientCode: store.getters.commandName, },
        `${this.$store.state.common.commandName}-Inventory Counting-${this.toDateFormat(new Date(), true)}.xlsx`,
        () => this.efficiencyLoading = false
      );
    },
    //条数
    handleSizeChange(val) {
      this.page.current = 1;
      this.page.size = val;
      this.getList(this.form);
    },
    //当前页数
    handleCurrentChange(val) {
      this.page.current = val;
      this.getList(this.form);
    },
    //清空
    getReset() {
      this.form = Object.assign({}, formParams);
      this.form.warehouseCode = this.warehouseByClient[0].warehouseCode;
      this.page = this.$options.data().page;
      this.getSearchlist();
    },
    //仓库选泽
    getRadio() {
      this.getSearchlist();
    },
    //查询
    getSearchlist() {
      this.page.current = 1;
      for (let key in this.form) {
        if (this.form[key] === "" || this.form[key] === null) {
          this.form[key] = undefined;
        }
      }
      this.getList(this.form);
    },
    //数据列表
    getList(params) {
      this.dataListLoading = true;
      pageQuery(Object.assign({ ...this.page, warehouseCode: this.form.warehouseCode }, params)).then((res) => {
        console.log(res);
        if (res.data.code === 0) {
          this.tableData = res.data.data.inventoryCountingVoList;
          this.total = res.data.data.total;
          this.currentInventoryCountingRate = res.data.data.currentInventoryCountingRate
          this.currentInventoryProfit = res.data.data.currentInventoryProfit
          this.currentInventoryLosses = res.data.data.currentInventoryLosses
          this.toCurrentInventoryCountingRate = res.data.data.toCurrentInventoryCountingRate
          this.toCurrentInventoryProfit = res.data.data.toCurrentInventoryProfit
          this.toCurrentInventoryLosses = res.data.data.toCurrentInventoryLosses

          this.dataListLoading = false;
        } else {
          this.$message.error(res.data.msg);
          this.dataListLoading = false;
        }
      }).catch(() => {
        this.$message.error("request was aborted");
        this.dataListLoading = false;
      });
    },
  },
};
</script>
<style lang="scss" scoped>
.content {
  padding: 0 10px;

  .text {
    font-size: 14px;
  }

  .item {
    padding: 18px 0;
  }

  .box-card {
    width: 100%;
  }

  .down {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    border-top: 1px solid #999;
    padding-top: 20px;
    box-sizing: border-box;
  }

  .underLine {
    cursor: pointer;
    color: #599af8;
    text-decoration: underline;
  }

  ::v-deep .el-dialog {
    border-radius: 8px !important;
  }

  ::v-deep .el-select--small {
    display: block;
  }

  ::v-deep .el-date-editor.el-input,
  .el-date-editor.el-input__inner {
    width: 100%;
  }
}</style>
