<template>
  <div class="content" v-loading="rateLoading">
    <el-tabs type="border-card" v-model="activeName" @tab-click="handleClick" >
      <el-tab-pane label="Real-time" name="now">
        <el-row style="width:200px;display:flex">
          <el-col>
            <el-button type="primary" icon="el-icon-search" @click="getSearchlist">Query</el-button>
          </el-col>
          <el-col>
            <el-button icon="el-icon-refresh-left" @click="getReset">Reset</el-button>
          </el-col>
        </el-row>
        <el-form ref="form" :model="form" style="margin: 20px 0" @keyup.enter.native="getSearchlist">
          <el-row>
            <el-col>
              <el-radio-group v-model="form.warehouseCode" v-for="(ite,index) in warehouseByClient" :key="index">
                <el-radio :label="ite.warehouseCode" style="margin-right:10px" @change="getRadio">{{ite.warehouseName}}</el-radio>
              </el-radio-group>
            </el-col>
            <el-col :span="4" style="margin-top: 10px">
              <!-- value-format="yyyy-MM-dd HH:mm:ss" -->
              <el-date-picker 
                v-model="time.weekDate" 
                type="week" 
                format="yyyy 第 WW 周"  
                placeholder="Statistics Date (By Week)"
                disabled
              ></el-date-picker>
            </el-col>
          </el-row>
        </el-form>
        <div class="down">
          <div></div>
          <div>
            <el-button icon="el-icon-download" @click="exportExcel" v-if="permissions.statistics_warehosueefficiency_export"></el-button>
          </div>
        </div>
        <el-table
          border
          ref="multipleTable"
          :data="tableData"
          tooltip-effect="dark"
          style="width: 100%"
          show-summary
          :summary-method="getSummaries"
          v-loading="dataListLoading"
          :header-cell-style="{ background: '#f5f7fa', color: '#606266' }"
        >
          <el-table-column prop="clientCode" label="Owner" min-width="120" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.clientCode || '-' }}</template>
          </el-table-column>
          <el-table-column label="Warehouse" min-width="120" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.warehouseCode || '-' }}</template>
          </el-table-column>
          <el-table-column label="Statistics Date" min-width="160" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ tableDateValue || '-' }}</template>
          </el-table-column>
          <el-table-column label="Storage Type" min-width="120" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.storageType || '-' }}</template>
          </el-table-column>
          <el-table-column prop="useQty" label="Use Qty" min-width="120" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.useQty ? scope.row.useQty : scope.row.useQty == 0 ? 0 : '-' }}</template>
          </el-table-column>
          <el-table-column prop="totalQty" label="Total Qty" min-width="120" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.totalQty ? scope.row.totalQty : scope.row.totalQty == 0 ? 0 : '-' }}</template>
          </el-table-column>
          <el-table-column prop="stockEfficiency" label="Qty Capacity Rotia" min-width="150" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.stockEfficiency ? scope.row.stockEfficiency : scope.row.stockEfficiency == 0 ? 0 : '-' }}</template>
          </el-table-column>
          <el-table-column prop="useVom" label="Use VOM (m³)" min-width="120" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.useVom ? scope.row.useVom : scope.row.useVom == 0 ? 0 : '-' }}</template>
          </el-table-column>
          <el-table-column prop="totalVom" label="Total VOM (m³)" min-width="120" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.totalVom ? scope.row.totalVom : scope.row.totalVom == 0 ? 0 : '-' }}</template>
          </el-table-column>
          <el-table-column prop="stockVomEfficiency" label="Vom Capcity Rotia" min-width="120" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.stockVomEfficiency ? scope.row.stockVomEfficiency : scope.row.stockVomEfficiency == 0 ? 0 : '-' }}</template>
          </el-table-column>
        </el-table>
      </el-tab-pane>
      <el-tab-pane label="History" name="past">
        <History v-if="history" @overView="changeOverView"></History>
      </el-tab-pane>
      <el-tab-pane label="Future" name="future">
        <Future v-if="future" @overView="changeOverView"></Future>
      </el-tab-pane>
      <el-tab-pane label="Real-time Lux-mate Overview" name="overView">
        <OverView v-if="overView" @overView="changeOverView"></OverView>
      </el-tab-pane>
      <el-tab-pane label="History Lux-mate Overview" name="historyOverView">
        <HistoryOverView v-if="historyOverView" @overView="changeOverView"></HistoryOverView>
      </el-tab-pane>
      <el-tab-pane label="Future Lux-mate Overview" name="futureOverView">
        <FutureOverView v-if="futureOverView" @overView="changeOverView"></FutureOverView>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>
<script>
import { mapGetters } from "vuex"
import History from "./history.vue"
import Future from "./future.vue"
import OverView from "./overView.vue"
import HistoryOverView from "./historyOverView.vue"
import FutureOverView from "./futureOverView.vue"
import { pageQuery } from "@/api/statistics/storageCapacityRate"
import { getWarehouseByClient } from "@/api/stock/subwarehouse"
import store from "@/store";
import futureOverViewVue from './futureOverView.vue'
let formParams = {
  startDate: undefined,
  endDate:undefined,
  warehouseCode: undefined,
}
export default {
  name: "Order",
  data() {
    return {
      form: Object.assign({}, formParams),
      page:{
        clientCode: store.getters.commandName,
        sign: 'CURRENT'
      },
      dataListLoading: false,
      tableData: [],
      warehouseByClient:[],
      time:{
        weekDate:''
      },
      tableDateValue:"",
      rateLoading:false,
      activeName:"now",
      history:false,
      future:false,
      overView:false,
      historyOverView:false,
      futureOverView:false
    }
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  mounted(){
    this.exportExcel = this.$btn(this.exportExcel,500)
  },
  components: {
    History,
    Future,
    OverView,
    HistoryOverView,
    FutureOverView
  },
  created() {
    this.getWarehouseByClient()

    let d1 = new Date() 
    let d2 = new Date() 
    d2.setMonth(0) 
    d2.setDate(1) 
    let rq = d1-d2 
    let s1 = Math.ceil(rq/(24*60*60*1000)) 
    let s2 = Math.ceil(s1/7) 
    // this.tableDateValue = d1.getFullYear() + '年第' + s2 + '周'
    this.tableDateValue = 'Now'
    let dateDay = new Date().getDate()
    let dateMonth = new Date().getMonth() + 1
    this.time.weekDate = new Date().getFullYear() + '-' + dateMonth + '-' + dateDay
    // console.log(this.time.weekDate = new Date());
  },
  methods: {
    //tab切换
    handleClick() {
      if(this.activeName == 'past'){
        this.history = true
        this.future = false
        this.overView = false
        this.historyOverView = false
        this.futureOverView = false
      }else if(this.activeName == 'future'){
        this.history = false
        this.future = true
        this.overView = false
        this.historyOverView = false
        this.futureOverView = false
      }else if(this.activeName == 'overView'){
        this.history = false
        this.future = false
        this.overView = true
        this.historyOverView = false
        this.futureOverView = false
      }else if(this.activeName == 'historyOverView'){
        this.history = false
        this.future = false
        this.overView = false
        this.historyOverView = true
        this.futureOverView = false
      }else if(this.activeName == 'futureOverView'){
        this.history = false
        this.future = false
        this.overView = false
        this.historyOverView = false
        this.futureOverView = true
      }else{
        this.history = false
        this.future = false
        this.overView = false
        this.historyOverView = false
        this.futureOverView = false
        this.getReset()
      }
    },
    //查询仓库..
    getWarehouseByClient(){
      getWarehouseByClient().then(res=>{
        console.log(res)
        if(res.data.code === 0){
          this.warehouseByClient = res.data.data
          this.form.warehouseCode = this.warehouseByClient[0].warehouseCode
          this.getList(this.form)
        }
      })
    },
    //导出
    exportExcel() {
      this.rateLoading = true
      this.downBlobFile("/statistics/warehouseEfficiency/export", {...this.form,...this.page} , 
      `${this.$store.state.common.commandName}-WarehouseEfficiency-${this.toDateFormat(new Date(),true)}.xlsx`, ()=> this.rateLoading = false)
    },
    //清空
    getReset() {
      this.form = Object.assign({}, formParams)
      this.form.warehouseCode = this.warehouseByClient[0].warehouseCode
      this.getList(this.form)
    },
    //仓库选泽
    getRadio(){
      this.getSearchlist()
    },
    //查询
    getSearchlist() {
      for (let key in this.form) {
        if (this.form[key] === "" || this.form[key] === null) {
          this.form[key] = undefined;
        }
      }
      // if(this.time.weekDate !== '' && this.form.weekDate !== null){
      //   let date = this.time.weekDate
      //   let year = date.getFullYear()
      //   let month = date.getMonth() + 1
      //   let day = date.getDate()
      //   let days = new Date(year, month, 0).getDate()
      //   // this.tableDateValue = year + '年第' + this.getYearWeek(year,month,day) + '周'
      //   if(month<10){
      //     month = '0' + month
      //   }
      //   if(day<10){
      //     day = '0' + day
      //   }
      //   this.form.startDate = year + '-' + month + '-' + day + ' ' + '00' + ':' + "00" + ':' + '00'
      //   if(Number(day)+7>days){
      //     month++
      //     if(month > 12){
      //       year++
      //       month = '01' 
      //     }
      //     let finallyDay = (Number(day) + 7) - days
      //     console.log(finallyDay,days,day,'4444');
      //     if(finallyDay<10){
      //       finallyDay = '0' + finallyDay
      //     }
      //     this.form.endDate = year + '-' + month + '-' + finallyDay + ' ' + '00' + ':' + "00" + ':' + '00'
      //     console.log(this.form.endDate);
      //   }else{
      //     let finallyDay = Number(day) + 7
      //     if(finallyDay<10){
      //       finallyDay = '0' + finallyDay
      //     }
      //     this.form.endDate = year + '-' + month + '-' + finallyDay + ' ' + '00' + ':' + "00" + ':' + '00'
      //     console.log(this.form.endDate);
      //   }
      //   console.log(year,month,day,days);
      // }
      this.getList(this.form)
    },
    //获取选择的时间是次年的多少周
    getYearWeek (a, b, c) {//a为年 b为月 c为日
      let date1 = new Date(a, parseInt(b) - 1, c);
      let date2 = new Date(a, 0, 2);
      let d = Math.round((date1.valueOf() - date2.valueOf()) / 86400000);
      console.log(d);
      return Math.ceil((d + ((date2.getDay() + 1) - 1)) / 7);
    },
    //数据列表
    getList(params){
      this.dataListLoading = true
      pageQuery(Object.assign({...this.page},params)).then(res=>{
        console.log(res)
        if(res.data.code === 0){
          this.tableData = res.data.data
          this.dataListLoading = false
        }else{
          this.$message.error(res.data.msg)
          this.dataListLoading = false
        }
      }).catch(()=>{
        this.$message.error('request was aborted')
        this.dataListLoading = false
      })
    },
    changeOverView(e){
      this.rateLoading = e
    },
    //计算列总和
    getSummaries(param) {
      const { columns, data } = param;
      const sums = [];
      columns.forEach((column, index) => {
        if (index === 0) {
          sums[index] = 'Total';
          sums[1] = '';
          return;
        }
        if (index === 1) {
          sums[index] = '';
          return;
        }
        const values = data.map(item => Number(item[column.property]));
        if (!values.every(value => isNaN(value))) {
          sums[index] = values.reduce((prev, curr) => {
            const value = Number(curr);
            if (!isNaN(value)) {
              return Number(prev + curr);
            } else {
              return prev;
            }
          }, 0);
          if(index != 4 && index != 5){
            sums[index] = sums[index].toFixed(2) + '';
          }
        } else {
          sums[index] = '';
          if(index === 9){
            sums[9] = ((sums[7] / sums[8])*100).toFixed(0)+'%'
          }
        }
      });
      return sums;
    }
  },
} 
</script>
<style lang="scss" scoped>
.content {
  padding: 0 10px;
  .text {
    font-size: 14px;
  }
  .item {
    padding: 18px 0;
  }
  .box-card {
    width: 100%;
  }
  .down {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    border-top: 1px solid #999;
    padding-top: 20px;
    box-sizing: border-box;
  }
  .underLine {
    cursor: pointer;
    color: #599af8;
    text-decoration: underline;
  }
  ::v-deep .el-dialog {
    border-radius: 8px !important;
  }
  ::v-deep .el-select--small {
    display: block;
  }
  ::v-deep .el-date-editor.el-input, .el-date-editor.el-input__inner{
    width: 100%;
  }
}
</style>
