<template>
  <div>
    <el-row style="width:200px;display:flex">
      <el-col>
        <el-button type="primary" icon="el-icon-search" @click="getSearchlist">Query</el-button>
      </el-col>
      <el-col>
        <el-button icon="el-icon-refresh-left" @click="getReset">Reset</el-button>
      </el-col>
    </el-row>
    <el-form ref="form" :model="form" style="margin: 20px 0" @keyup.enter.native="getSearchlist">
      <el-row>
        <el-col>
          <el-radio-group v-model="form.warehouseCode" v-for="(ite,index) in warehouseByClient" :key="index">
            <el-radio :label="ite.warehouseCode" style="margin-right:10px" @change="getRadio">{{ite.warehouseName}}</el-radio>
          </el-radio-group>
        </el-col>
        <el-col :span="4" style="margin-top:10px">
          <!-- value-format="yyyy-MM-dd HH:mm:ss" -->
          <el-date-picker 
            v-model="time.weekDate" 
            type="week" 
            format="yyyy 第 WW 周"  
            placeholder="Statistics Date (By Week)"
            disabled
          ></el-date-picker>
        </el-col>
      </el-row>
    </el-form>
    <div class="down">
      <div></div>
      <div>
        <el-button icon="el-icon-download" @click="exportExcel" v-if="permissions.statistics_warehosueefficiency_export"></el-button>
      </div>
    </div>
    <el-table
      border
      ref="multipleTable"
      :data="tableDataList"
      tooltip-effect="dark"
      style="width: 100%"
      v-loading="dataListLoading"
      :header-cell-style="{ background: '#f5f7fa', color: '#606266' }"
    >
      <el-table-column align="center" v-for="(item, index) in columns" :key="index" :label="item.label" show-overflow-tooltip :fixed="item.fixed" :min-width="item.width">
        <template slot-scope="scope">{{ scope.row[item.prop] || '-' }}</template>
        <template >
          <el-table-column align="center" v-for="(subItem, subIndex) in item.children" :key="subIndex" :label="subItem.label" :min-width="subItem.width?subItem.width:'120'" >
            <template slot-scope="scope">
              {{ scope.row[subItem.prop] }}
            </template>
          </el-table-column>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>
<script>
import { mapGetters } from "vuex"
import { pageQueryOverView } from "@/api/statistics/storageCapacityRate"
import { getWarehouseByClient } from "@/api/stock/subwarehouse"
import store from "@/store";
let formParams = {
  warehouseCode: undefined,
  startDate: undefined,
  endDate:undefined,
}
export default {
  data() {
    return {
      form: Object.assign({}, formParams),
      page:{
        clientCode: store.getters.commandName,
        sign: 'CURRENT'
      },
      dataListLoading: false,
      warehouseByClient:[],
      time:{
        weekDate:''
      },
      columns:[
        {
          label:'',
          prop:'',
          fixed: 'left',
          width: "120",
          children:[{
            label:'Storage Type',
            prop:'storageType',
          }]
        },
        {
          label:'Location Qty',
          prop:'',
          children:[{
            label:'Plan Capacity',
            prop:'warehouseStorageTypeCapacity',
            width:'210'
          },
          {
            label:'Total',
            prop:'locationTotal'
          },
          {
            label:'SAIC',
            prop:'locationSaic'
          },
          {
            label:'NIO',
            prop:'locationNio'
          },
          {
            label:'AIWAYS',
            prop:'locationAiways'
          },
          {
            label:'X_PENG',
            prop:'locationXpeng'
          },
          {
            label:'LOTUS',
            prop:'locationLotus'
          },
          {
            label:'GW',
            prop:'locationGw'
          },
          {
            label:'ZEEKR',
            prop:'locationZeekr'
          }
        ]
        },
        {
          label:'Utilization rate of CLIENT',
          prop:'',
          children:[
          {
            label:'SAIC',
            prop:'utilizationRateSaic'
          },
          {
            label:'NIO',
            prop:'utilizationRateNio'
          },
          {
            label:'AIWAYS',
            prop:'utilizationRateAiways'
          },
          {
            label:'X_PENG',
            prop:'utilizationRateXpeng'
          },
          {
            label:'LOTUS',
            prop:'utilizationRateLotus'
          },
          {
            label:'GW',
            prop:'utilizationRateGw'
          },
          {
            label:'ZEEKR',
            prop:'utilizationRateZeekr'
          }
        ]
        },
        {
          label:'Accounted for FACILITY',
          prop:'',
          children:[
          {
            label:'Total',
            prop:'utilizationRateTotal'
          },
          {
            label:'SAIC',
            prop:'accountedSaic'
          },
          {
            label:'NIO',
            prop:'accountedNio'
          },
          {
            label:'AIWAYS',
            prop:'accountedAiways'
          },
          {
            label:'X_PENG',
            prop:'accountedXpeng'
          },
          {
            label:'LOTUS',
            prop:'accountedLotus'
          },
          {
            label:'GW',
            prop:'accountedGw'
          },
          {
            label:'ZEEKR',
            prop:'accountedZeekr'
          }
        ]
        },
        {
          label:'Volume(m³)',
          prop:'',
          children:[
          {
            label:'Total Plan',
            prop:'totalPlanVolume'
          },
          {
            label:'Total Use',
            prop:'totalUseVolume'
          },
          {
            label:'SAIC',
            prop:'totalUseVolumeSaic'
          },
          {
            label:'NIO',
            prop:'totalUseVolumeNio'
          },
          {
            label:'AIWAYS',
            prop:'totalUseVolumeAiways'
          },
          {
            label:'X_PENG',
            prop:'totalUseVolumeXpeng'
          },
          {
            label:'LOTUS',
            prop:'totalUseVolumeLotus'
          },
          {
            label:'GW',
            prop:'totalUseVolumeGw'
          },
          {
            label:'ZEEKR',
            prop:'totalUseVolumeZeekr'
          }
        ]
        }
      ],
      tableDataList:[],
      timeDate:''
    };
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  mounted(){
    this.exportExcel = this.$btn(this.exportExcel,500)
  },
  created() {
    let d1 = new Date() 
    let d2 = new Date() 
    d2.setMonth(0) 
    d2.setDate(1) 
    let rq = d1-d2 
    let s1 = Math.ceil(rq/(24*60*60*1000)) 
    let s2 = Math.ceil(s1/7) 
    let dateDay = new Date().getDate()
    let dateMonth = new Date().getMonth() + 1
    this.timeDate = new Date().getFullYear() + '-' + dateMonth + '-' + dateDay
    this.time.weekDate = new Date().getFullYear() + '-' + dateMonth + '-' + dateDay

    this.getWarehouseByClient()
  },
  methods: {
    //导出
    exportExcel() {
      this.$emit('overView',true)
      this.downBlobFile("/statistics/warehouseEfficiency/overviewExport", {...this.form,...this.page} , 
      `${this.$store.state.common.commandName}-WarehouseEfficiency-${this.toDateFormat(new Date(),true)}.xlsx`, ()=> this.$emit('overView',false))
    },
    //清空
    getReset() {
      this.form = Object.assign({}, formParams)
      this.form.warehouseCode = this.warehouseByClient[0].warehouseCode
      this.getSearchlist()
    },
    //仓库选泽
    getRadio(){
      this.getSearchlist()
    },
    //查询仓库..
    getWarehouseByClient(){
      getWarehouseByClient().then(res=>{
        console.log(res)
        if(res.data.code === 0){
          this.warehouseByClient = res.data.data
          this.form.warehouseCode = this.warehouseByClient[0].warehouseCode
          this.getList(this.form)
        }
      })
    },
    //查询
    getSearchlist() {
      for (let key in this.form) {
        if (this.form[key] === "" || this.form[key] === null) {
          this.form[key] = undefined;
        }
      }
      if(this.time.weekDate !== '' && this.form.weekDate !== null && this.timeDate === ''){
        let date = this.time.weekDate
        let year = date.getFullYear()
        let month = date.getMonth() + 1
        let day = date.getDate()
        let days = new Date(year, month, 0).getDate()
        if(month<10){
          month = '0' + month
        }
        if(day<10){
          day = '0' + day
        }
        this.form.startDate = year + '-' + month + '-' + day + ' ' + '00' + ':' + "00" + ':' + '00'
        if(Number(day)+7>days){
          month++
          if(month > 12){
            year++
            month = '01' 
          }
          let finallyDay = (Number(day) + 7) - days
          console.log(finallyDay,days,day,'4444');
          if(finallyDay<10){
            finallyDay = '0' + finallyDay
          }
          this.form.endDate = year + '-' + month + '-' + finallyDay + ' ' + '00' + ':' + "00" + ':' + '00'
          console.log(this.form.endDate);
        }else{
          let finallyDay = Number(day) + 7
          if(finallyDay<10){
            finallyDay = '0' + finallyDay
          }
          this.form.endDate = year + '-' + month + '-' + finallyDay + ' ' + '00' + ':' + "00" + ':' + '00'
          console.log(this.form.endDate);
        }
        console.log(year,month,day,days);
      }
      this.getList(this.form)
    },
    //数据列表
    getList(params){
      this.dataListLoading = true
      pageQueryOverView(Object.assign({...this.page},params)).then(res=>{
        console.log(res)
        if(res.data.code === 0){
          res.data.data.warehouseEfficiencyOverviewDataDtos.push({storageType:"Total",totalUseVolume: res.data.data.allTotalUseVolume,locationSaic:res.data.data.totalUseSaic,
          locationNio:res.data.data.totalUseNio,locationAiways:res.data.data.totalUseAiways,locationXpeng:res.data.data.totalUseXpeng,
          locationLotus:res.data.data.totalUseLotus,locationGw:res.data.data.totalUseGw,locationZeekr:res.data.data.totalUseZeekr,
          totalPlanVolume:  res.data.data.totalPlanUseVolume,
          totalUseVolumeSaic:  res.data.data.totalUseVolumeSaic,
          totalUseVolumeNio:  res.data.data.totalUseVolumeNio,
          totalUseVolumeAiways:  res.data.data.totalUseVolumeAiways,
          totalUseVolumeXpeng:  res.data.data.totalUseVolumeXpeng,
          totalUseVolumeLotus:  res.data.data.totalUseVolumeLotus,
          totalUseVolumeGw:  res.data.data.totalUseVolumeGw,
          totalUseVolumeZeekr:  res.data.data.totalUseVolumeZeekr,

          accountedSaic:  res.data.data.totalUseVolumeSaicPercent,
          accountedNio:  res.data.data.totalUseVolumeNioPercent,
          accountedAiways:  res.data.data.totalUseVolumeAiwaysPercent,
          accountedXpeng:  res.data.data.totalUseVolumeXpengPercent,
          accountedLotus:  res.data.data.totalUseVolumeLotusPercent,
          accountedGw:  res.data.data.totalUseVolumeGwPercent,
          accountedZeekr:  res.data.data.totalUseVolumeZeekrPercent,
          utilizationRateTotal: res.data.data.totalUseVolumePercent,

          utilizationRateSaic:  res.data.data.totalActualUseVolumeSaicPercent,
          utilizationRateNio:  res.data.data.totalActualUseVolumeNioPercent,
          utilizationRateAiways:  res.data.data.totalActualUseVolumeAiwaysPercent,
          utilizationRateXpeng:  res.data.data.totalActualUseVolumeXpengPercent,
          utilizationRateLotus:  res.data.data.totalActualUseVolumeLotusPercent,
          utilizationRateGw:  res.data.data.totalActualUseVolumeGwPercent,
          utilizationRateZeekr:  res.data.data.totalActualUseVolumeZeekrPercent,
          
          })
          this.tableDataList = res.data.data.warehouseEfficiencyOverviewDataDtos
          this.dataListLoading = false
        }else{
          this.$message.error(res.data.msg)
          this.dataListLoading = false
        }
      }).catch(()=>{
        this.$message.error('request was aborted')
        this.dataListLoading = false
      })
    },
  },
};
</script>
<style lang="scss" scoped>
.down {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    border-top: 1px solid #999;
    padding-top: 20px;
    box-sizing: border-box;
  }
  .underLine {
    cursor: pointer;
    color: #599af8;
    text-decoration: underline;
  }
  ::v-deep .el-dialog {
    border-radius: 8px !important;
  }
  ::v-deep .el-select--small {
    display: block;
  }
  ::v-deep .el-date-editor.el-input, .el-date-editor.el-input__inner{
    width: 100%;
  }
  ::v-deep .el-table tr:nth-child(1) th:nth-child(1) {
    background-color: #eeeeee !important;
  }

  ::v-deep .el-table tr:nth-child(1) th:nth-child(2) {
    background-color: #ad8d8d !important;
  }

  ::v-deep .el-table tr:nth-child(1) th:nth-child(3) {
    background-color: #489c79 !important;
  }

  ::v-deep .el-table tr:nth-child(1) th:nth-child(4) {
    background-color: #426898 !important;
  }

  ::v-deep .el-table tr:nth-child(1) th:nth-child(5) {
    background-color: #93b64d !important;
  }

  ::v-deep .el-table tr:nth-child(1) th {
    color: #fff !important; 
  }
</style>
