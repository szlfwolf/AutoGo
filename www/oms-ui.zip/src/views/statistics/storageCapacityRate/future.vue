<template>
  <div>
    <el-row style="width:200px;display:flex">
      <el-col>
        <el-button type="primary" icon="el-icon-search" @click="getSearchlist">Query</el-button>
      </el-col>
      <el-col>
        <el-button icon="el-icon-refresh-left" @click="getReset">Reset</el-button>
      </el-col>
    </el-row>
    <el-form ref="form" :model="form" style="margin: 20px 0" @keyup.enter.native="getSearchlist">
      <el-row>
        <el-col>
          <el-radio-group v-model="form.warehouseCode" v-for="(ite,index) in warehouseByClient" :key="index">
            <el-radio :label="ite.warehouseCode" style="margin-right:10px" @change="getRadio">{{ite.warehouseName}}</el-radio>
          </el-radio-group>
        </el-col>
        <el-col :span="4" style="margin-top: 10px">
          <!-- value-format="yyyy-MM-dd HH:mm:ss" -->
          <el-date-picker 
            v-model="time.weekDate" 
            type="week" 
            format="yyyy 第 WW 周"  
            placeholder="Statistics Date (By Week)"
            :picker-options="{disabledDate,firstDayOfWeek: 1}"
            @change="changeTimeValue"
          ></el-date-picker>
        </el-col>
      </el-row>
    </el-form>
    <div class="down">
      <div></div>
      <div>
        <el-button icon="el-icon-download" @click="exportExcel" v-if="permissions.statistics_warehosueefficiency_export" :disabled="!time.weekDate"></el-button>
      </div>
    </div>
    <el-table
      border
      ref="multipleTable"
      :data="tableData"
      tooltip-effect="dark"
      style="width: 100%"
      show-summary
      :summary-method="getSummaries"
      v-loading="dataListLoading"
      :header-cell-style="{ background: '#f5f7fa', color: '#606266' }"
    >
      <el-table-column prop="clientCode" label="Owner" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.clientCode || '-' }}</template>
      </el-table-column>
      <el-table-column label="Warehouse" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.warehouseCode || '-' }}</template>
      </el-table-column>
      <el-table-column label="Statistics Date" min-width="160" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ tableDateValue || '-' }}</template>
      </el-table-column>
      <el-table-column label="Storage Type" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.storageType || '-' }}</template>
      </el-table-column>
      <el-table-column prop="useQty" label="Use Qty" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.useQty ? scope.row.useQty : scope.row.useQty == 0 ? 0 : '-' }}</template>
      </el-table-column>
      <el-table-column prop="totalQty" label="Total Qty" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.totalQty ? scope.row.totalQty : scope.row.totalQty == 0 ? 0 : '-' }}</template>
      </el-table-column>
      <el-table-column prop="stockEfficiency" label="Qty Capacity Rotia" min-width="150" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.stockEfficiency ? scope.row.stockEfficiency : scope.row.stockEfficiency == 0 ? 0 : '-' }}</template>
      </el-table-column>
      <el-table-column prop="useVom" label="Use VOM (m³)" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.useVom ? scope.row.useVom : scope.row.useVom == 0 ? 0 : '-' }}</template>
      </el-table-column>
      <el-table-column prop="totalVom" label="Total VOM (m³)" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.totalVom ? scope.row.totalVom : scope.row.totalVom == 0 ? 0 : '-' }}</template>
      </el-table-column>
      <el-table-column prop="stockVomEfficiency" label="Vom Capcity Rotia" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.stockVomEfficiency ? scope.row.stockVomEfficiency : scope.row.stockVomEfficiency == 0 ? 0 : '-' }}</template>
      </el-table-column>
    </el-table>
  </div>
</template>
<script>
import { mapGetters } from "vuex"
import { pageQuery } from "@/api/statistics/storageCapacityRate"
import { getWarehouseByClient } from "@/api/stock/subwarehouse"
import store from "@/store";
let formParams = {
  startDate: undefined,
  endDate:undefined,
  warehouseCode: undefined,
}
export default {
  data() {
    return {
      form: Object.assign({}, formParams),
      page:{
        clientCode: store.getters.commandName,
        sign: 'ESTIMATE'
      },
      dataListLoading: false,
      tableData: [],
      warehouseByClient:[],
      time:{
        weekDate:''
      },
      tableDateValue:"",
      timeDate:""
    };
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  mounted(){
    this.exportExcel = this.$btn(this.exportExcel,500)
  },
  created() {
    this.getWarehouseByClient()
  },
  methods: {
    getDateList(){
      const week = new Date().getDay();

      //start
      let dateValue = new Date()
      let year = dateValue.getFullYear()
      let month = dateValue.getMonth() + 1
      let day = dateValue.getDate()
      console.log(day,'55');
      day = day + 7
      day = week ? day - week + 1 : day - 6
      let days = new Date(year, month, 0).getDate()
      // if(day < 1){
      //   var month1 = month - 1
      // }else{
      //   var month1 = month
      // }
      // if(month1 < 1){
      //   var year1 = year - 1
      // }else{
      //   var year1 = year
      // }
      if(day > days){
        var month1 = month + 1
      }else{
        var month1 = month
      }
      if(month1 > 12){
        var year1 = year + 1
      }else{
        var year1 = year
      }
      // day = day < 1 ? days + day : day
      day = day > days ? day - days : day
      day = day < 10 ? '0' + day : day

      //end
      let day2 = dateValue.getDate()
      day2 = day2 + 7
      day2 = week ? day2 + (8 - week) : day2 + 1
      let days2 = new Date(year, month, 0).getDate()
      if(day2 > days2){
        var month2 = month + 1
      }else{
        var month2 = month
      }
      if(month2 > 12){
        var year1 = year + 1
      }else{
        var year1 = year
      }
      day2 = day2 > days2 ? day2 - days2 : day2
      day2 = day2 < 10 ? '0' + day2 : day2

      month = month < 10 ? '0' + month : month
      month1 = month1 < 10 ? '0' + month1 : month1
      month2 = month2 < 10 ? '0' + month2 : month2

      console.log(day,day2,week,days)
      console.log(year,month1,day)
      this.timeDate = year + '-' + month1 + '-' + day + ' ' + '00' + ':' + "00" + ':' + '00'
      this.time.weekDate = year + '-' + month1 + '-' + day + ' ' + '00' + ':' + "00" + ':' + '00'
      this.tableDateValue = year + '年第' + this.getYearWeek(year,month1,day) + '周'

      this.form.startDate = year + '-' + month1 + '-' + day + ' ' + '00' + ':' + "00" + ':' + '00'
      this.form.endDate = year + '-' + month2 + '-' + day2 + ' ' + '00' + ':' + "00" + ':' + '00'

      this.getList(this.form)
    },
    //导出
    exportExcel() {
      this.$emit('overView',true)
      this.downBlobFile("/statistics/warehouseEfficiency/export", {...this.form,...this.page} , 
      `${this.$store.state.common.commandName}-WarehouseEfficiency-${this.toDateFormat(new Date(),true)}.xlsx`, ()=> this.$emit('overView',false))
    },
    //禁止选择未来/过去的时间
    disabledDate(time){
      const week = new Date().getDay();
      if(week != 0){
        return time.getTime() < Date.now() + 8.64e7 * (7-week);
      } // 不可选历史天、不可选当前天、可选未来天
      return time.getTime() < Date.now() 
    },
    //查询仓库..
    getWarehouseByClient(){
      getWarehouseByClient().then(res=>{
        console.log(res)
        if(res.data.code === 0){
          this.warehouseByClient = res.data.data
          this.form.warehouseCode = this.warehouseByClient[0].warehouseCode
          this.getDateList()
        }
      })
    },
    //清空
    getReset() {
      this.form = Object.assign({}, formParams)
      this.time = this.$options.data().time
      this.tableDateValue = ""
      this.tableData = this.$options.data().tableData
      this.form.warehouseCode = this.warehouseByClient[0].warehouseCode
      this.getDateList()
    },
    //仓库选泽
    getRadio(){
      this.getSearchlist()
    },
    changeTimeValue(){
      this.timeDate = ''
    },
    //查询
    getSearchlist() {
      // this.page.current = 1
      for (let key in this.form) {
        if (this.form[key] === "" || this.form[key] === null) {
          this.form[key] = undefined;
        }
      }
      if(this.time.weekDate !== '' && this.form.weekDate !== null && this.timeDate == ''){
        console.log(this.time.weekDate,'4444');
        let date = this.time.weekDate
        let year = date.getFullYear()
        let month = date.getMonth() + 1
        let day = date.getDate()
        let days = new Date(year, month, 0).getDate()
        this.tableDateValue = year + '年第' + this.getYearWeek(year,month,day) + '周'
        if(month<10){
          month = '0' + month
        }
        if(day - 1 < 0){
          day = days
        }else{
          day = day - 1
        }
         if(day<10){
          day = '0' + day
        }
        this.form.startDate = year + '-' + month + '-' + day + ' ' + '00' + ':' + "00" + ':' + '00'
        // this.toDateFormat(new Date(),true)+ ' ' + '00' + ':' + "00" + ':' + '00'  //当天
        if(Number(day)+7>days){
          month++
          if(month > 12){
            year++
            month = '01' 
          }
          let finallyDay = (Number(day) + 7) - days
          console.log(finallyDay,days,day,'4444');
          if(finallyDay<10){
            finallyDay = '0' + finallyDay
          }
          this.form.endDate = year + '-' + month + '-' + finallyDay + ' ' + '00' + ':' + "00" + ':' + '00'
          console.log(this.form.endDate);
        }else{
          let finallyDay = Number(day) + 7
          if(finallyDay<10){
            finallyDay = '0' + finallyDay
          }
          this.form.endDate = year + '-' + month + '-' + finallyDay + ' ' + '00' + ':' + "00" + ':' + '00'
          console.log(this.form.endDate);
        }
        console.log(year,month,day,days);
      }
      this.getList(this.form)
    },
    //获取选择的时间是次年的多少周
    getYearWeek (a, b, c) {//a为年 b为月 c为日
      let date1 = new Date(a, parseInt(b) - 1, c);
      let date2 = new Date(a, 0, 2);
      let d = Math.round((date1.valueOf() - date2.valueOf()) / 86400000);
      console.log(d);
      return Math.ceil((d + ((date2.getDay() + 1) - 1)) / 7);
    },
    //数据列表
    getList(params){
      this.dataListLoading = true
      pageQuery(Object.assign({...this.page,warehouseCode:this.form.warehouseCode},params)).then(res=>{
        console.log(res)
        if(res.data.code === 0){
          this.tableData = res.data.data
          this.dataListLoading = false
        }else{
          this.$message.error(res.data.msg)
          this.dataListLoading = false
        }
      }).catch(()=>{
        this.$message.error('request was aborted')
        this.dataListLoading = false
      })
    },
    //计算列总和
    getSummaries(param) {
      const { columns, data } = param;
      const sums = [];
      columns.forEach((column, index) => {
        if (index === 0) {
          sums[index] = 'Total';
          sums[1] = '';
          return;
        }
        if (index === 1) {
          sums[index] = '';
          return;
        }
        const values = data.map(item => Number(item[column.property]));
        if (!values.every(value => isNaN(value))) {
          sums[index] = values.reduce((prev, curr) => {
            const value = Number(curr);
            if (!isNaN(value)) {
              return Number(prev + curr);
            } else {
              return prev;
            }
          }, 0);
          if(index != 4 && index != 5){
            sums[index] = sums[index].toFixed(2) + '';
          }
        } else {
          sums[index] = '';
          if(index === 9){
            sums[9] = ((sums[7] / sums[8])*100).toFixed(0)+'%'
          }
        }
      });
      return sums;
    }
  },
};
</script>
<style lang="scss" scoped>
.down {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    border-top: 1px solid #999;
    padding-top: 20px;
    box-sizing: border-box;
  }
  .underLine {
    cursor: pointer;
    color: #599af8;
    text-decoration: underline;
  }
  ::v-deep .el-dialog {
    border-radius: 8px !important;
  }
  ::v-deep .el-select--small {
    display: block;
  }
  ::v-deep .el-date-editor.el-input, .el-date-editor.el-input__inner{
    width: 100%;
  }
</style>
