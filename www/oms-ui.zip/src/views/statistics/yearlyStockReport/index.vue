<template>
  <div class="content" v-loading="yearLoading">
    <el-card class="box-card">
      <el-row style="width: 200px; display: flex">
        <el-col>
          <el-button type="primary" icon="el-icon-search" @click="getSearchlist">Query</el-button>
        </el-col>
        <el-col>
          <el-button icon="el-icon-refresh-left" @click="getReset">Reset</el-button>
        </el-col>
      </el-row>
      <el-form ref="form" :model="form" style="margin: 20px 0" @keyup.enter.native="getSearchlist">
        <el-row :gutter="20">
          <el-col style="margin-bottom: 20px">
            <el-radio-group v-model="form.warehouseCode" v-for="(ite, index) in warehouseByClient" :key="index">
              <el-radio :label="ite.warehouseCode" style="margin-right: 10px" @change="getRadio">{{ ite.warehouseName
                              }}</el-radio>
            </el-radio-group>
          </el-col>
          <el-col :span="4">
            <el-input v-model="form.partNumber" placeholder="Sku no" clearable></el-input>
          </el-col>
          <el-col :span="4">
            <el-select filterable v-model="form.status" placeholder="Status" filterable clearable>
              <el-option v-for="item in status" :key="item.value" :label="item.label" :value="item.value">
              </el-option>
            </el-select>
          </el-col>
          <el-col :span="4">
            <el-date-picker v-model="form.year" type="year" value-format="yyyy" placeholder="Year">
            </el-date-picker>
          </el-col>
        </el-row>
      </el-form>
      <div class="down">
        <div>
          <!-- Add按钮 -->
          <el-button type="primary" style="padding: 7px 15px" @click="modifyBtn">
            <span style="display: flex; align-items: center">
              <img src="../../../../public/svg/shenhe.svg" alt="" style="margin-right: 10px; width: 16px" />Approve
            </span>
          </el-button>
        </div>
        <div>
          <el-button icon="el-icon-upload2" @click="countingUpload"
            v-if="permissions.statistics_yearlystock_import_adjust">Counting qty</el-button>
          <el-button icon="el-icon-download" @click="exportExcel" v-if="permissions.statistics_yearlystock_export">Yearly
            Stock Report</el-button>
        </div>
      </div>
      <el-table border ref="multipleTable" class="selectBtn" :data="tableData" tooltip-effect="dark" style="width: 100%"
        v-loading="dataListLoading" :header-cell-style="{ background: '#f5f7fa', color: '#606266' }">
        <el-table-column label="Owner" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.clientCode || "-" }}</template>
        </el-table-column>
        <el-table-column label="Warehouse" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.warehouseCode || "-" }}</template>
        </el-table-column>
        <el-table-column label="Year" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.year || "-" }}</template>
        </el-table-column>
        <el-table-column label="Sku no" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.partNumber || "-" }}</template>
        </el-table-column>
        <el-table-column label="Actual Counting Qty" min-width="180" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.actualCountingQty ? scope.row.actualCountingQty :
                      scope.row.actualCountingQty == 0 ? 0 : '-' }}</template>
        </el-table-column>
        <el-table-column label="Oms Qty" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.omsQty ? scope.row.omsQty : scope.row.omsQty == 0 ? 0 : '-'
                      }}</template>
        </el-table-column>
        <el-table-column label="Oms Gap" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.gap ? scope.row.gap : scope.row.gap == 0 ? 0 : '-'
                      }}</template>
        </el-table-column>
        <el-table-column label="Customer Qty" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.customerQty ? scope.row.customerQty : scope.row.customerQty == 0 ? 0 :
                      '-' }}</template>
        </el-table-column>
        <el-table-column label="Customer Gap" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.customerGap ? scope.row.customerGap : scope.row.customerGap == 0 ? 0 :
                      '-' }}</template>
        </el-table-column>
        <el-table-column label="Adjust Qty" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.adjustQty ? scope.row.adjustQty : scope.row.adjustQty == 0 ? 0 : '-'
                      }}</template>
        </el-table-column>
        <el-table-column label="Status" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ showStatus[scope.row.status] || "-" }}</template>
        </el-table-column>
        <!-- <el-table-column label="Opearte" min-width="120" align="center"
          v-if="permissions.statistics_yearlystock_update_check">
          <template slot-scope="scope">
            <el-button style="font-size: 18px; padding: 0; border: 0; margin-left: 0"
              :style="{ color: scope.row.isSelect ? '#65beff ' : '' }" class="iconfont icon-shenhe"
              @click="changeExamine(scope.row, scope.$index)"></el-button>
          </template>
        </el-table-column> -->
      </el-table>
      <Pagination @handleSizeChange="handleSizeChange" @handleCurrentChange="handleCurrentChange" :pageNum="page.current"
        :pageSize="page.size" :total="total"></Pagination>
      <!-- 弹窗 -->
      <el-dialog title="Approve" :visible.sync="centerDialogVisible" width="50%" @close="getClose"
        :close-on-click-modal="false" style="font-weight: 700" v-loading="dialogLoading">
        <el-form ref="formDialog" :model="formDialog" label-width="100px" :rules="rules">
          <!-- <el-row>
            <el-col :span="12">
              <el-form-item label="Owner:">
                <el-input disabled v-model="formDialog.clientCode"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="Warehouse:">
                <el-input disabled v-model="formDialog.warehouseCode"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="Year:">
                <el-input disabled v-model="formDialog.year"></el-input>
              </el-form-item>
            </el-col>
          </el-row> -->
          <u-table border ref="multipleTable" :data="formDialog.tableData" tooltip-effect="dark" style="width: 100%"
            use-virtual :row-height="30" height="400" header-cell-class-name="header-cell-class"
            :header-cell-style="{ background: '#f5f7fa', color: '#606266' }">
            <u-table-column label="Sku no" min-width="120" align="center"
              v-if="permissions.statistics_yearlystock_get_detail">
              <template slot-scope="scope">
                <el-form-item style="margin-bottom: 0; margin-left: -100px"
                  :prop="'tableData.' + scope.$index + '.partNumber'" :rules="rules.partNumber">
                  <el-input v-model="scope.row.partNumber" class="kit-input" @blur="changeInput(scope.row)"></el-input>
                </el-form-item>
              </template>
            </u-table-column>
            <u-table-column label="Owner" min-width="120" align="center">
              <template slot-scope="scope">{{ scope.row.clientCode || "-" }}</template>
            </u-table-column>
            <u-table-column label="Warehouse" min-width="120" align="center">
              <template slot-scope="scope">{{ scope.row.warehouseCode || "-" }}</template>
            </u-table-column>
            <u-table-column label="Year" min-width="120" align="center">
              <template slot-scope="scope">{{ scope.row.year || "-" }}</template>
            </u-table-column>
            <u-table-column label="Actual Counting Qty" min-width="140" align="center">
              <template slot-scope="scope"> {{ scope.row.actualCountingQty || "-" }}</template>
            </u-table-column>
            <u-table-column label="Oms Qty" min-width="120" align="center">
              <template slot-scope="scope"> {{ scope.row.omsQty ? scope.row.omsQty : scope.row.omsQty == 0 ? 0 : '-'
                              }}</template>
            </u-table-column>
            <u-table-column label="Customer Qty" min-width="120" align="center">
              <template slot-scope="scope">{{ scope.row.customerQty || "-" }}</template>
            </u-table-column>
            <u-table-column label="Gap" min-width="120" align="center">
              <template slot-scope="scope">{{ scope.row.gap || "-" }}</template>
            </u-table-column>
            <u-table-column label="Adjust Qty" min-width="120" align="center">
              <template slot-scope="scope">
                <el-form-item style="margin-bottom: 0; margin-left: -100px"
                  :prop="'tableData.' + scope.$index + '.adjustQty'" :rules="rules.adjustQty">
                  <el-input v-model.trim="scope.row.adjustQty" class="kit-input"></el-input>
                </el-form-item>
              </template>
            </u-table-column>
            <!-- 删除 -->
            <u-table-column label="Opearte" align="center">
              <template slot-scope="scope">
                <i class="el-icon-delete cursor-on" @click="kitDel(scope.$index, formDialog.tableData)"
                  style="color: #4095e5; font-size: 20px"></i>
              </template>
            </u-table-column>
          </u-table>
        </el-form>
        <!-- 添加 -->
        <div class="dialog-footer-add">
          <i class="el-icon-circle-plus-outline" style="margin-right: 20px; cursor: pointer" @click="kitAdd"></i>
          <i class="el-icon-upload" style="cursor: pointer" @click="dialogUpload"
            v-if="permissions.statistics_yearlystock_realNumber_import"></i>
        </div>
        <!-- 按钮 -->
        <span slot="footer" style="display: flex; justify-content: center">
          <el-button @click="getClose" style="margin-right: 20px; padding: 10px 40px" type="info">Cancel</el-button>
          <el-button type="primary" @click="updateSub" style="padding: 10px 40px"
            v-if="permissions.statistics_yearlystock_update_check">Confirm</el-button>
        </span>
      </el-dialog>
      <!--excel 模板导入 -->
      <excel-upload ref="excelUpload" :title="upload.title" :url="upload.url" :temp-name="upload.tempName"
        :temp-url="upload.tempUrl" @refreshDataList="handleRefreshChange" :timeDateStatus="timeDateStatus"></excel-upload>
    </el-card>
  </div>
</template>
<script>
import { mapGetters } from "vuex";
import Pagination from "@/components/pagination/pagination.vue";
import ExcelUpload from "@/components/upload/excel";
import { pageQuery, getUpDateCheck, getYearlyStockDetail, getUpdateQty, getYearlyStockEnum, } from "@/api/statistics/yearlyStockReport";
import { getWarehouseByClient } from "@/api/stock/subwarehouse";
import store from "@/store";
import { deepClone } from "@/util/util";
let formParams = {
  partNumber: undefined,
  year: undefined,
  status: undefined,
  warehouseCode: undefined,
};
export default {
  name: "ASN",
  data() {
    return {
      form: Object.assign({}, formParams),
      total: 0,
      page: {
        size: 10,
        current: 1,
        clientCode: store.getters.commandName,
      },
      dataListLoading: false,
      tableData: [],
      warehouseByClient: [],
      btnType: "",
      skuLoading: false,
      status: [],
      centerDialogVisible: false,
      formDialog: {
        // clientCode: store.getters.commandName,
        // warehouseCode: "",
        // year:"",
        tableData: [
          // {
          //   clientCode: "",
          //   warehouseCode: "",
          //   year: "",
          //   partNumber: "",
          //   actualCountingQty: "",
          //   omsQty: "",
          //   customerQty: "",
          //   gap: "",
          //   adjustQty: "",
          // },
        ],
      },
      showStatus: {
        CHECK_NO_PASS: "审核未通过",
        CHECK_PASS: "审核通过",
        NO_CHECK: "未审核",
      },
      // add表单
      rules: {
        adjustQty: [
          { required: true, message: "此区域为必填项", trigger: "blur" },
          { pattern: /^-?[0-9]\d*$/, message: "请输入整数", trigger: "blur" },
        ],
        partNumber: [
          { required: true, message: "此区域为必填项", trigger: "blur" },
          // { pattern: /^[0-9]*$/, message: "请输入正数字", trigger: "change" },
        ],
      },
      upload: {
        title: "",
        url: "",
        tempName: "",
        tempUrl: "",
      },
      yearLoading: false,
      selectArr: [],
      timeDateStatus:false,
      dialogLoading:false
    };
  },
  created() {
    this.getWarehouseByClient();
  },
  components: {
    ExcelUpload,
    Pagination,
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  mounted() { 
    this.exportExcel = this.$btn(this.exportExcel, 500)
  },
  methods: {
    //查询仓库..
    getWarehouseByClient() {
      getWarehouseByClient().then((res) => {
        console.log(res);
        if (res.data.code === 0) {
          this.warehouseByClient = res.data.data;
          this.form.warehouseCode = this.warehouseByClient[0].warehouseCode;
          this.getList();
        }
      });
      getYearlyStockEnum().then((res) => {
        console.log(res);
        this.status = res.data;
      });
    },
    //导出
    exportExcel() {
      this.yearLoading = true;
      this.downBlobFile("/statistics/yearlyStock/export",
        { ...this.form, warehouseCode: this.form.warehouseCode, clientCode: store.getters.commandName, },
        `${this.$store.state.common.commandName}-YearlyStockReport-${this.toDateFormat(new Date(), true)}.xlsx`,
        () => (this.yearLoading = false)
      );
    },
    //上传
    handleRefreshChange(e) {
      console.log(this.type, "upload");
      console.log(e, "upload");
      if (this.type == "counting") {
        if (e === "loading") {
          this.yearLoading = true;
          return;
        }
        this.yearLoading = false;
        this.getList(this.form);
      } else {
        if (e === "loading") {
          this.dialogLoading = true;
          return;
        }
        this.dialogLoading = false;
        this.formDialog.tableData = e.data
      }
    },
    countingUpload() {
      this.type = "counting";
      this.$refs.excelUpload.show();
      this.timeDateStatus = true
      this.upload = Object.assign(
        {},
        {
          title: "CountingQtyUploadFile",
          url: `/statistics/yearlyStock/realNumber/import`,
          tempName: "yearly-counting-template.xlsx",
          tempUrl: "/admin/sys-file/local/yearly-counting-template.xlsx",
        }
      );
    },
    dialogUpload() {
      this.type = "adjust";
      this.$refs.excelUpload.show();
      this.timeDateStatus = false
      this.upload = Object.assign(
        {},
        {
          title: "AdjustUploadFile",
          url: `/statistics/yearlyStock/importAdjust`,
          tempName: "yearly-adjustQty-template.xlsx",
          tempUrl: "/admin/sys-file/local/yearly-adjustQty-template.xlsx",
        }
      );
    },
    //条数
    handleSizeChange(val) {
      this.page.current = 1;
      this.page.size = val;
      this.getList(this.form);
    },
    //当前页数
    handleCurrentChange(val) {
      this.page.current = val;
      this.getList(this.form);
    },
    //清空
    getReset() {
      this.form = Object.assign({}, formParams);
      this.form.warehouseCode = this.warehouseByClient[0].warehouseCode;
      this.page = this.$options.data().page
      this.getList();
    },
    //仓库选泽
    getRadio() {
      this.getSearchlist();
    },
    //查询
    getSearchlist() {
      this.page.current = 1;
      for (let key in this.form) {
        if (this.form[key] === "" || this.form[key] === null) {
          this.form[key] = undefined;
        }
      }
      this.getList(this.form);
    },
    //数据列表
    getList(params) {
      this.dataListLoading = true;
      pageQuery(Object.assign({ ...this.page, warehouseCode: this.form.warehouseCode }, params)).then((res) => {
        console.log(res);
        this.formDialog = this.$options.data().formDialog
        if (res.data.code === 0) {
          this.tableData = res.data.data.records;
          this.tableData.forEach((item) => {
            this.$set(item, "isSelect", false);
          });
          this.total = res.data.data.total;
          this.dataListLoading = false;
        } else {
          this.$message.error(res.data.msg);
          this.dataListLoading = false;
        }
      }).catch(() => {
        this.$message.error("request was aborted");
        this.dataListLoading = false;
      });
    },
    //审核
    // changeExamine(row, index) {
    //   if (row.isSelect) {
    //     this.formDialog.tableData = this.formDialog.tableData.filter((i, x) => {
    //       if (i.id != row.id) return i;
    //     });
    //     // this.formDialog.tableData.splice(row,1)
    //   } else {
    //     this.formDialog.tableData.push(row)
    //     // this.formDialog.tableData = this.formDialog.tableData.concat(row)
    //   }
    //   row.isSelect = !row.isSelect;
    //   // getUpDateCheck(row).then(res=>{
    //   //   if(res.data.code === 0){
    //   //     this.$message.success('Operation succeeded')
    //   //     this.getList(this.form)
    //   //   }else{
    //   //     this.$message.error(res.data.msg)
    //   //   }
    //   // })
    // },
    //
    modifyBtn() {
      this.centerDialogVisible = true;
      // this.formDialog.warehouseCode = this.form.warehouseCode
      // this.formDialog.year = this.tableData[0].year
    },
    updateSub() {
      if(!this.formDialog.tableData.length){
        return;
      }
      this.$refs.formDialog.validate((valid) => {
        if (!valid) return false;
        getUpdateQty(this.formDialog.tableData).then((res) => {
          if (res.data.code === 0) {
            this.$message.success("Audit update succeeded");
            this.getList(this.form);
            this.centerDialogVisible = false;
          } else {
            this.$message.error(res.data.msg);
            this.centerDialogVisible = false;
          }
        }).catch(() => {
          this.centerDialogVisible = false;
        });
      });
    },
    //添加
    kitAdd() {
      this.formDialog.tableData.push({
        clientCode: "",
        warehouseCode: "",
        year: "",
        partNumber: "",
        actualCountingQty: "",
        omsQty: "",
        customerQty: "",
        gap: "",
        adjustQty: "",
      });
    },
    //单条数据查询
    changeInput(row, index) {
      console.log(row);
      if (row.partNumber) {
        getYearlyStockDetail(Object.assign({}, { partNumber: row.partNumber, clientCode: this.page.clientCode, warehouseCode:this.form.warehouseCode })).then((res) => {
          console.log(res);
          if (res.data.code === 0) {
            row.clientCode = res.data.data.clientCode;
            row.warehouseCode = res.data.data.warehouseCode;
            row.year = res.data.data.year;
            row.actualCountingQty = res.data.data.actualCountingQty;
            row.omsQty = res.data.data.omsQty;
            row.customerQty = res.data.data.customerQty;
            row.gap = res.data.data.gap;
            row.adjustQty = res.data.data.adjustQty;
          } else {
            this.$message.error(res.data.msg);
          }
        });
      }
    },
    //删除
    kitDel(index,row) {
      row.splice(index, 1);
      // this.formDialog.tableData = this.formDialog.tableData.filter(ite => {
      //   if (ite.id != row.id) return ite;
      //   ite.isSelect = false;
      // })
    },
    getClose() {
      this.centerDialogVisible = false;
      // this.$refs.formDialog.resetFields();
      this.formDialog.tableData = this.$options.data().formDialog.tableData;
    },
  },
};
</script>
<style lang="scss" scoped>
.content {
  padding: 0 10px;

  // box-sizing: border-box;
  .down {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    border-top: 1px solid #999;
    padding-top: 20px;
    box-sizing: border-box;
    // content-visibility: auto;
    // contain-intrinsic-size: 320px;
  }

  .header-cell-class {
    background-color: #ccc;
  }

  .cursor-on {
    cursor: pointer;
  }

  .dialog-footer-add {
    font-size: 24px;
    display: flex;
    justify-content: center;
    margin-top: 20px;
    color: #59a6f9;
  }

  ::v-deep .el-dialog__wrapper .el-dialog {
    border-radius: 8px;
  }

  ::v-deep .el-select--small {
    display: block;
  }

  ::v-deep .el-date-editor.el-input,
  .el-date-editor.el-input__inner {
    width: 100%;
  }

  .selectBtn ::v-deep .el-button:focus {
    color: #606266;
  }
}</style>
