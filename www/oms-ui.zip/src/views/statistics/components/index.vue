<template id="temp">
  <!-- vue实例外创建 -->
  <div>
    <div class="calendarBox">
      <div>
        <i style="margin-right: 10px; vertical-align: middle" class="el-icon-arrow-left" @click="timeChange('reduce')"></i>
        <!-- <el-popover placement="left" width="300" trigger="click">  -->
          <!-- <span style="user-select: none" slot="reference">{{ year }} 年 {{ month }} 月 </span> -->
            <el-date-picker
              v-model="value"
              type="month"
              placeholder="选择月"
              format=" yyyy 年 MM 月"
            >
            </el-date-picker>
           <i class="el-icon-caret-bottom" slot="reference"></i>
          <!-- <el-calendar v-model="value">
            <template slot="dateCell" slot-scope="{ data }">
              <p :class="data.isSelected ? 'is-selected' : ''">
                {{ data.day.split("-").slice(1).join("-") }}
                {{ data.isSelected ? "✔️" : "" }}
              </p>
            </template>
          </el-calendar> -->
        <!-- </el-popover> -->
        <i style="margin-left: 10px; vertical-align: middle" class="el-icon-arrow-right" @click="timeChange('add')"></i>
      </div>
      <el-switch
        v-model="switchValue"
        :active-text="switchText"
        v-if="status"
        @change="changeSwitch"
        style="margin-left:20px;color:#409EFF">
      </el-switch>
      <div class="jisuan" @click="exportExcel" v-if="type">
        <img style="width: 25px; margin-right: 5px" src="../../../../public/svg/yunxiazai.svg"/>
        <span>Download details</span>
      </div>
    </div>
    <!--  -->
    <el-row type="flex" justify="center">
      <el-col :span="8">
        <div class="radioBox">
          <el-radio-group v-model="form.warehouseCode" v-for="(ite,index) in warehouseByClient" :key="index">
            <el-radio :label="ite.warehouseCode" style="margin-right:10px" @change="getRadio">{{ite.warehouseName}}</el-radio>
          </el-radio-group>
        </div>
      </el-col>
    </el-row>
  </div>
</template>
<script>
import { getWarehouseByClient } from "@/api/stock/subwarehouse";
export default {
  data() {
    return {
      value: null,
      year: null,
      month: null,
      form:{
        warehouseCode:""
      },
      warehouseByClient:[],
      typeLoading:false,
      switchValue:false,
      switchText:'Detail'
    };
  },
  watch: {
    value: function (newVal, oldVal) {
      console.log(newVal);
      this.value = newVal;
      this.year = newVal.getFullYear();
      this.month = newVal.getMonth()+1;
      if(this.month < 10){
        this.month = '0' + this.month
      }
      if(this.form.warehouseCode){
        this.$emit("calendar", { year: this.year, month: this.month });
      }
    },
  },
  created() {
    this.getWarehouseByClient()
    let value= new Date()
    this.year = value.getFullYear();  
    // if(this.dateFormatType){ //上一个月
      this.month = value.getMonth();
      this.month = this.month < 10 ? '0'+ this.month : this.month
      this.value = new Date(this.year + '-' + this.month)
    // }else{
    //   this.month = value.getMonth()+1;
    //   this.month = this.month < 10 ? '0'+ this.month : this.month
    //   this.value = new Date()
    // }  //当前月
  },
  mounted() {
    this.exportExcel = this.$btn(this.exportExcel, 500);
  },
  props: {
    pageName: {
      type: Object
    },
    type:{
      type: Boolean
    },
    status:{
      type: Boolean
    },
    dateFormatType:{
      type: Boolean
    }
  },
  methods: {
    // 左右箭头调整日期
    timeChange(type) {
      if (type === "add") {
        this.month++;
        if (this.month > 12) {
          this.month = '01';
          this.year++;
          if(this.month < 10){
            this.month = '0' + this.month
          }
        }
      } else {
        this.month--;
        if (this.month < 1) {
          this.month = 12;
          this.year--;
        }
      }
      this.value = new Date(`${this.year},${this.month}`);
    },
    // 下载
    exportExcel() {
      console.log(this.pageName.data + "页面点了下载按钮");
      this.$emit('typeLoading',true)
      this.downBlobFile(
        this.pageName.url,
        {...this.pageName.data,queryTime: this.year + '-' + this.month,warehouseCode: this.form.warehouseCode},
        this.pageName.name, ()=> this.$emit('typeLoading',false)
      );
    },
    //查询仓库..
    getWarehouseByClient() {
      getWarehouseByClient().then((res) => {
        console.log(res);
        if (res.data.code === 0) {
          this.warehouseByClient = res.data.data;
          this.form.warehouseCode = this.warehouseByClient[0].warehouseCode;
          this.$emit('getRadio',this.form.warehouseCode);
        }
      });
    },
    //仓库选泽
    getRadio() {
      this.$emit('getRadio',this.form.warehouseCode)
    },
    changeSwitch(e){
      console.log(e);
      if(e == false){
        this.switchText = 'Detail'
        this.$emit('getSwitch',e)
      }else{
        this.switchText = 'OverView'
        this.$emit('getSwitch',e)
      }
    },
    getRest(){
      console.log(this.warehouseByClient);
      let value= new Date()
      this.year = value.getFullYear();  
      this.month = value.getMonth();
      this.month = this.month < 10 ? '0'+ this.month : this.month
      this.value = new Date(this.year + '-' + this.month)
      this.$emit('getRadio',this.form.warehouseCode)
    }
  },
};
</script>
<style lang="scss" scoped>
.calendarBox {
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;

  i,
  span {
    height: 60px;
    line-height: 60px;
    cursor: pointer;
  }

  i {
    font-size: 23px;
    color: #000;
  }
}

.jisuan {
  position: absolute;
  width: fit-content;
  cursor: pointer;
  right: 200px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #65beff;
  font-weight: bold;
  user-select: none;
}

.radioBox {
  display: flex;
  justify-content: center;
  align-items: center;
}

::v-deep .el-input__inner{
  font-size: 16px;
  background-color: #F0F2F5;
  border:0;
  padding: 0;
  text-align: center;
  cursor: pointer;
  color: transparent;
  text-shadow: 0 0 0 #000;
}
.el-date-editor.el-input, .el-date-editor.el-input__inner{
  width: 140px;
}

::v-deep .el-icon-date{
  opacity: 0;
}

::v-deep .el-input__suffix-inner{
  display: none;
}
::v-deep .el-switch__label *{
  color: #409EFF;
}
</style>
