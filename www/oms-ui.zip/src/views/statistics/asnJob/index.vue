<template>
  <div v-loading="asnLoading">
    <TopPage :pageName="pageName" @calendar="calendar" @getRadio="getRadio"
      :type="permissions.statistics_asnhead_exportshiptype" @typeLoading="typeLoading"></TopPage>
    <div class="efficiency">
      <el-row type="flex" justify="center" style="padding: 30px 0">
        <el-col class="efficiency-div" :span="6">
          <div class="Exhibition">
            <span>{{ qty.asnQty ? getFData(qty.asnQty) : 0 }}</span>
            <span>Asn Qty</span>
          </div>
        </el-col>
        <el-col class="efficiency-div" :span="6">
          <div class="Exhibition">
            <span>{{ qty.totalLine ? getFData(qty.totalLine) : 0 }}</span>
            <span>Total Line</span>
          </div>
        </el-col>
        <el-col class="efficiency-div" :span="6">
          <div class="Exhibition">
            <span>{{ qty.totalPcs ? getFData(qty.totalPcs) : 0 }}</span>
            <span>Total PCS</span>
          </div>
        </el-col>
        <el-col class="efficiency-div" :span="6">
          <div class="Exhibition">
            <span>{{ qty.totalVom ? getFData(qty.totalVom) : 0 }}</span>
            <span>VOM(m³)</span>
          </div>
        </el-col>
      </el-row>
      <!-- 表 -->
      <el-table border stripe ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%"
        header-cell-class-name="header-cell-class" :header-cell-style="{ background: '#f5f7fa', color: '#606266' }"
        v-loading="dataListLoading">
        <el-table-column label="Owner" min-width="100" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.clientCode || '-' }}</template>
        </el-table-column>
        <el-table-column label="Warehouse" min-width="150" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.warehouseCode || '-' }}</template>
        </el-table-column>
        <el-table-column label="Ship Type" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.shipType || '-' }}</template>
        </el-table-column>
        <el-table-column label="Line" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.line ? scope.row.line : scope.row.line == 0 ? 0 : '-' }}</template>
        </el-table-column>
        <el-table-column label="Pcs" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.pcs ? scope.row.pcs : scope.row.pcs == 0 ? 0 : '-' }}</template>
        </el-table-column>
        <el-table-column label="VOM(m³)" min-width="180" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.vom ? scope.row.vom : scope.row.vom == 0 ? 0 : '-' }}</template>
        </el-table-column>
        <!-- 按钮 -->
        <el-table-column label="Opearte" min-width="100" align="center" v-if="permissions.statistics_asnhead_get_detail">
          <template slot-scope="scope">
            <el-button type="text" style="font-size: 18px; color: #65beff" icon="el-icon-view"
              @click="getDetailList(scope.row)">
            </el-button>
          </template>
        </el-table-column>
      </el-table>
      <!-- 弹窗 -->
      <el-dialog title="ASN Details" :visible.sync="dialogVisible" width="60%" class="custom-class" @close="getclose"
        v-loading="asnDialogLoading">
        <!-- :close-on-click-modal="false" -->
        <el-row style="width:200px;display:flex">
          <el-col>
            <el-button type="primary" icon="el-icon-search" @click="getSearchlist">Query</el-button>
          </el-col>
          <el-col>
            <el-button icon="el-icon-refresh-left" @click="getReset">Reset</el-button>
          </el-col>
        </el-row>
        <el-form ref="formDialog" :model="formDialog" @keyup.enter.native="getSearchlist">
          <el-row style="margin-top: 20px" :gutter="20">
            <el-col :span="4">
              <el-form-item>
                <el-input v-model="formDialog.orderNo" placeholder="Asn no"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="4">
              <el-date-picker v-model="time.createTime" type="daterange" start-placeholder="CreateTime"
                end-placeholder="CreateEndTime" :default-time="['00:00:00', '23:59:59']"
                value-format="yyyy-MM-dd HH:mm:ss" @change="changeCreateTime" />
            </el-col>
            <el-col :span="4">
              <el-date-picker v-model="time.finishTime" type="daterange" start-placeholder="FinishTime"
                end-placeholder="FinishEndTime" :default-time="['00:00:00', '23:59:59']"
                value-format="yyyy-MM-dd HH:mm:ss" @change="changeFinsihTime" />
            </el-col>
          </el-row>
        </el-form>
        <!-- 下载 -->
        <div class="down">
          <el-button icon="el-icon-download" @click="exportExcel" v-if="permissions.statistics_asndetail_export">
          </el-button>
        </div>
        <!-- 表 -->
        <el-table border stripe ref="multipleTable" :data="formDaialogTableData" tooltip-effect="dark" style="width: 100%"
          header-cell-class-name="header-cell-class" :header-cell-style="{ background: '#f5f7fa', color: '#606266' }">
          <el-table-column label="Warehouse" min-width="120" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.warehouseCode || '-' }}</template>
          </el-table-column>
          <el-table-column label="Owner" min-width="120" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.clientCode || '-' }}</template>
          </el-table-column>
          <el-table-column label="ASN" min-width="140" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.orderNo || '-' }}</template>
          </el-table-column>
          <el-table-column label="BL no" min-width="140" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.blNo || '-' }}</template>
          </el-table-column>
          <el-table-column label="AWB" min-width="140" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.awb || '-' }}</template>
          </el-table-column>
          <el-table-column label="Ship Type" min-width="120" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.shipType || '-' }}</template>
          </el-table-column>
          <el-table-column label="Line" min-width="120" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.lineQuality ? scope.row.lineQuality : scope.row.lineQuality == 0 ? 0
              : '-' }}</template>
          </el-table-column>
          <el-table-column label="Pcs" min-width="120" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.pcsQuality ? scope.row.pcsQuality : scope.row.pcsQuality == 0 ? 0 :
              '-' }}</template>
          </el-table-column>
          <el-table-column label="VOM(m³)" min-width="120" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.vom ? scope.row.vom : scope.row.vom == 0 ? 0 : '-' }}</template>
          </el-table-column>
          <el-table-column label="Create Time" min-width="140" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.productTime || '-' }}</template>
          </el-table-column>
          <el-table-column label="Finish Time" min-width="140" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.finishedTime || '-' }}</template>
          </el-table-column>
        </el-table>
        <Pagination @handleSizeChange="handleSizeChange" @handleCurrentChange="handleCurrentChange"
          :pageNum="page.current" :pageSize="page.size" :total="total"></Pagination>
      </el-dialog>
    </div>
  </div>
</template>
<script>
import TopPage from "../components/index.vue";
import Pagination from "@/components/pagination/pagination.vue";
import { mapGetters } from "vuex";
import { deepClone } from "@/util/util";
import store from "@/store";
import { pageQuery, pageQueryDetail } from "@/api/statistics/asnJob"
// import { getWarehouseByClient } from "@/api/stock/subwarehouse";
export default {
  data() {
    return {
      formDialog: {
        orderNo: "",
      },
      form: {
        clientCode: store.getters.commandName,
        queryTime: "",
        warehouseCode: "",
      },
      time: {
        createTime: "",
        finishTime: ""
      },
      page: {
        size: 10,
        current: 1,
      },
      total: 0,
      // 云下载
      pageName: {
        name: `${store.getters.commandName}-AsnJob-${this.toDateFormat(new Date(), true)}.xlsx`,
        data: { clientCode: store.getters.commandName },
        url: "/statistics/asnHead/exportShipType",
      },
      tableData: [],
      formDaialogTableData: [],
      qty: {},
      dataListLoading: false,
      dialogVisible: false,
      row: {},
      asnLoading: false,
      asnDialogLoading: false
    };
  },
  components: {
    TopPage,
    Pagination
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  created() {
    let year = new Date().getFullYear()
    let month = (new Date()).getMonth()
    //  + 1
    if (month < 10) {
      month = '0' + month
    }
    this.form.queryTime = year + '-' + month
    // this.getWarehouseByClient()
  },
  mounted() {
    this.exportExcel = this.$btn(this.exportExcel, 500);
  },
  methods: {
    //时间参数
    changeCreateTime(val) {
      if (val !== undefined && val !== null && val !== '' && val.length > 0) {
        this.$set(this.formDialog, 'productStartTime', val[0])
        this.$set(this.formDialog, 'productEndTIme', val[1])
      } else {
        this.$set(this.formDialog, 'productStartTime', undefined)
        this.$set(this.formDialog, 'productEndTIme', undefined)
      }
    },
    changeFinsihTime(val) {
      if (val !== undefined && val !== null && val !== '' && val.length > 0) {
        this.$set(this.formDialog, 'finishedStartTime', val[0])
        this.$set(this.formDialog, 'finishedEndTime', val[1])
      } else {
        this.$set(this.formDialog, 'finishedStartTime', undefined)
        this.$set(this.formDialog, 'finishedEndTime', undefined)
      }
    },
    //转换数字格式
    getFData(source, length = 3) {
      source = String(source).split('.')
      source[0] = source[0].replace(new RegExp('(\\d)(?=(\\d{' + length + '})+$)', 'ig'), '$1,')
      return source.join('.')
    },
    typeLoading(e) {
      this.asnLoading = e
    },
    //条数 详情
    handleSizeChange(val) {
      this.page.current = 1;
      this.page.size = val;
      this.getDetailList(this.row);
    },
    //当前页数 详情
    handleCurrentChange(val) {
      this.page.current = val;
      this.getDetailList(this.row);
    },
    //导出
    exportExcel() {
      this.asnDialogLoading = true
      this.downBlobFilePost("/statistics/asnDetail/export", { ...this.formDialog, ...this.form, clientCode: store.getters.commandName, },
        `${this.$store.state.common.commandName}-AsnJobDetail-${this.toDateFormat(new Date(), true)}.xlsx`, () => this.asnDialogLoading = false)
    },
    // 单选
    getRadio(e) {
      console.log("当前选择的仓库", e);
      this.form.warehouseCode = e
      this.getList();
    },
    // 子组件传过来的日期
    calendar(e) {
      console.log("日历", JSON.parse(JSON.stringify(e)));
      this.form.queryTime = e.year + '-' + e.month
      this.getList();
    },
    // //查询仓库..
    // getWarehouseByClient() {
    //   getWarehouseByClient().then((res) => {
    //     console.log(res);
    //     if (res.data.code === 0) {
    //       this.warehouseByClient = res.data.data;
    //       this.form.warehouseCode = this.warehouseByClient[0].warehouseCode;
    //       this.getList()
    //     }
    //   });
    // },
    //数据列表
    getList() {
      this.dataListLoading = true
      pageQuery({ ...this.form }).then(res => {
        console.log(res)
        if (res.data.code === 0) {
          this.qty = res.data.data
          this.tableData = res.data.data.detailList
          this.dataListLoading = false
        } else {
          this.$message.error(res.data.msg)
          this.dataListLoading = false
        }
      }).catch(() => {
        this.$message.error('request was aborted')
        this.dataListLoading = false
      })
    },
    //清空
    getReset() {
      this.formDialog = { orderNo: "" }
      this.time = {
        createTime: "",
        finishTime: ""
      }
      this.page = {
        size: 10,
        current: 1,
      },
      this.getDetailList(this.row)
    },
    //查询
    getSearchlist() {
      this.page.current = 1;
      for (let key in this.formDialog) {
        if (this.formDialog[key] === "" || this.formDialog[key] === null) {
          this.formDialog[key] = undefined;
        }
      }
      this.getDetailList(this.row)
    },
    //详情列表
    getDetailList(row) {
      this.row = row
      pageQueryDetail(Object.assign(this.formDialog, row, { queryTime: this.form.queryTime }, this.page)).then(res => {
        if (res.data.code === 0) {
          this.dialogVisible = true;
          this.formDaialogTableData = res.data.data.records
          this.total = res.data.data.total
        } else {
          this.$message.error(res.data.msg)
        }
      })
    },
    // 重置
    getclose() {
      this.formDialog = { orderNo: "" }
      this.time = { createTime: "", finishTime: "" }
    },
  },
};
</script>
<style lang="scss" scoped>
.efficiency {
  width: 100%;
  min-height: 500px;
  margin-top: 20px;
  background: rgb(255, 255, 255);
  padding: 0px 20px;
  box-sizing: border-box;

  .efficiency-div {
    display: flex;
    justify-content: center;
  }

  .Exhibition {
    background-color: rgba(147, 210, 243, 0.26);
    font-weight: 700;
    font-size: 36px;
    color: rgb(16, 16, 16);
    width: 173px;
    height: 125px;
    border-radius: 5px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    font-family: SourceHanSansSC;

    span:nth-last-child(1) {
      font-weight: 400;
      font-size: 14px;
      color: rgb(16, 16, 16);
      margin-top: 10px;
    }
  }
}

.custom-class {
  ::v-deep .el-dialog__header {
    font-weight: bold;
  }

  .down {
    display: flex;
    justify-content: flex-end;
    margin-bottom: 20px;
    border-top: 1px solid #999;
    padding-top: 20px;
    box-sizing: border-box;
  }

  ::v-deep .el-date-editor--daterange.el-input,
  ::v-deep .el-date-editor--daterange.el-input__inner,
  ::v-deep .el-date-editor--timerange.el-input,
  ::v-deep .el-date-editor--timerange.el-input__inner {
    width: 100% !important;
  }
}
</style>
