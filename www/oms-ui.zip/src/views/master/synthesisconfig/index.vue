<template>
  <div class="content">
    <el-tabs type="border-card" v-loading="skuLoading">
      <el-row style="width:200px;display:flex">
        <el-col>
          <el-button type="primary" icon="el-icon-search" @click="clientData()">Query</el-button>
        </el-col>
        <el-col>
          <el-button @click="resetForm('form')" type="info" plain icon="el-icon-refresh-left">Reset</el-button>
        </el-col>
      </el-row>
      <el-form ref="form" :model="form">
        <el-row style="margin-top: 20px" :gutter="20">
          <el-col :span="4">
            <el-form-item prop="clientCode">
              <el-select filterable clearable v-model="form.clientCode" placeholder="Client">
                <el-option v-for="item in clientCodeSelect" :key="item.value" :label="item.clientName"
                  :value="item.clientCode">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="4">
            <el-form-item prop="status">
              <el-select filterable clearable v-model="form.status" placeholder="Status">
                <el-option label="Off" value="1"></el-option>
                <el-option label="On" value="0"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="4">
            <el-form-item prop="warehouseCode">
              <el-select filterable clearable v-model="form.warehouseCode" placeholder="Warehouse Code">
                <el-option v-for="item in warehouseCodeArr" :key="item.warehouse_code" :label="item.warehouse_name"
                  :value="item.warehouse_code">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div class="down">
        <!-- Add按钮 -->
        <el-button v-if="permissions.outbound_synthesisconfig_add" type="primary" style="padding: 5px 20px;color: #fff;"
          @click="modifyBtn('', 'add')">
          <span style="display: flex; align-items: center">
            <i class="el-icon-circle-plus-outline" style="margin-right: 10px; font-size: 20px"></i>Add
          </span>
        </el-button>
        <!-- <el-button icon="el-icon-download" @click="exportExcel"></el-button> -->
      </div>
      <!-- 数据表 -->
      <el-table border stripe ref="multipleTable" :data="tableData.records" tooltip-effect="dark" style="width: 100%"
        header-cell-class-name="header-cell-class" :header-cell-style="{ background: '#f5f7fa', color: '#606266' }">
        <el-table-column :show-overflow-tooltip="true" label="Client" min-width="60" align="center">
          <template slot-scope="scope">{{ scope.row.clientCode }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Warehouse Code" min-width="100" align="center">
          <template slot-scope="scope">{{ scope.row.warehouseCode }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Warehouse Name" min-width="100" align="center">
          <template slot-scope="scope">{{ scope.row.warehouseName }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Zipcode" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.zipCodes }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Execution Time" min-width="100" align="center">
          <template slot-scope="scope">{{ scope.row.executeTime }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Execution Desc" min-width="200" align="center">
          <template slot-scope="scope">{{ scope.row.executeDesc }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Country Code" min-width="80" align="center">
          <template slot-scope="scope">
            {{ scope.row.countryCode }}
          </template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Order Type" min-width="120" align="center">
          <template slot-scope="scope">
            {{ scope.row.orderType }}
          </template>
        </el-table-column>
        <el-table-column label="Status" align="center" min-width="60">
          <template slot-scope="scope">
            <div style="display: flex;align-items: center;justify-content: center;">
              <span :class="scope.row.status == '1' ? 'tableRed' : 'tableGre'">
                {{ scope.row.status == '1' ? 'Off' : 'On' }}</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column v-if="permissions.outbound_synthesisconfig_edit || permissions.outbound_synthesisconfig_runJob"
          :show-overflow-tooltip="true" label="Opearte" min-width="60" align="center">
          <template slot-scope="scope">

            <el-button v-if="permissions.outbound_synthesisconfig_runJob" type="text"
              style="font-size:18px;  color: #65BEFF;" icon=" el-icon-video-play" @click="runJobBtn(scope.row)">
            </el-button>
            <el-button v-if="permissions.outbound_synthesisconfig_edit" type="text"
              style="font-size:18px;  color: #65BEFF;" icon="el-icon-edit" @click="modifyBtn(scope.row, 'modify')">
            </el-button>

          </template>
        </el-table-column>
      </el-table>

      <Pagination @handleSizeChange="handleSizeChange" @handleCurrentChange="handleCurrentChange"
        :pageNum="tableData.current" :pageSize="tableData.size" :total="tableData.total"></Pagination>
      <!-- Add弹框  Synthesis Setting-->
      <el-dialog :title="dialogTitle" :visible.sync="detailAdd" width="35%" :before-close="cancelClo"
        style="font-weight: 700" :close-on-click-modal='btnType != "add"'>
        <!-- 内容 -->
        <el-form ref="updateObj" :rules="rules" :model="updateObj" label-width="150px">
          <el-form-item label="Client:" prop="clientCode">

            <el-select filterable placeholder="" clearable v-model="updateObj.clientCode">
              <el-option v-for="item in clientCodeSelect" :key="item.value" :label="item.clientName"
                :value="item.clientCode">
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="Warehouse Code:" prop="warehouseCode">
            <el-select filterable placeholder="" clearable v-model="updateObj.warehouseCode">
              <el-option v-for="item in warehouseCodeArr" :key="item.warehouse_code" :label="item.warehouse_name"
                :value="item.warehouse_code">
              </el-option>
            </el-select>
          </el-form-item>

          <el-row>
            <el-form-item label="Country:" prop="countryCode">
              <el-select filterable placeholder="" clearable multiple v-model="updateObj.countryCode">
                <el-option v-for="item in countryCodeArr" :key="item.value" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-row>
          <el-row>
            <el-form-item label="Zipcode:" prop="zipCodes">
              <el-input v-model.trim="updateObj.zipCodes" rows="4" type="textarea"></el-input>
            </el-form-item>
          </el-row>
          <el-row>
            <el-form-item label="Order Type:" prop="orderType">
              <el-select filterable placeholder="" clearable multiple v-model="updateObj.orderType">
                <el-option v-for="item in orderTypeArr" :key="item.value" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-row>
          <el-row>
            <el-form-item label="Execution Time:" prop="executeTime">
              <el-popover placement="top" v-model="cronPopover">
                <vueCron class="cronBox" @change="onChangeCron" @close="cronOff"></vueCron>
                <el-input slot="reference" v-model="updateObj.executeTime" placeholder="" size="small">
                </el-input>
              </el-popover>
            </el-form-item>
          </el-row>
          <el-row>
            <el-form-item label="Execution Desc:" prop="executeDesc">
              <el-input v-model="updateObj.executeDesc" placeholder="" size="small"></el-input>
            </el-form-item>
          </el-row>
          <el-row>
            <el-form-item label="Status:" prop="status">
              <el-switch @change="switchChange" v-model="SwitchValue" active-color="#13ce66" inactive-color="#949494">
              </el-switch>
            </el-form-item>
          </el-row>
        </el-form>
        <div class="dialog-footer-box">
          <span slot="footer">
            <el-button @click="cancelClo" style="margin-right: 20px; padding: 10px 40px" type="info">Cancel
            </el-button>
            <el-button type="primary" @click="updateSub" style="padding: 10px 40px">Confirm</el-button>
          </span>
        </div>
      </el-dialog>
    </el-tabs>


  </div>
</template>
<script>
let formParams = {
  clientCode: null,
  status: null,
  warehouseCode: null,
};
import { mapGetters } from "vuex"
import Pagination from "@/components/pagination/pagination.vue"
import { deepClone } from '@/util/util';
import { remote } from '@/api/admin/dict'
import { getClient, getWarehouseCode, getWarehouse } from '@/api/warehouse'
import { pageObj, saveObj, updateObj, runJobNow } from '@/api/synthesisconfig'
import { btnAntiShake } from '@/util/btnAntiShake'
export default {
  name: "ASN",
  data() {
    return {
      cronPopover: false,
      dialogTitle: '',
      SwitchValue: null,   //status
      btnType: '',
      skuLoading: false,
      pageSize: '',
      pageCurrent: '1',
      detailAdd: false,
      isBackUp: false,
      isPrice: false,
      isPackageInfo: false,
      form: Object.assign({}, formParams),
      options: [
      ],
      // 基本数据
      tableData: [],
      multipleSelection: [],
      size: 10,
      total: 100,
      //   修改表单
      updateObj: {
      },
      // add表单
      addUpdateObj: {},
      pClientArr: [],
      clientCodeSelect: null,
      countryCodeArr: [],
      orderTypeArr: [],
      warehouseCodeArr: null,
      executionArr: [],
      rules: {
        clientCode: [
          { required: true, message: '此区域为必填项', trigger: "change" },
        ],
        warehouseCode: [
          { required: true, message: '此区域为必填项', trigger: "change" },
        ],
        countryCode: [
          { required: true, message: '此区域为必填项', trigger: "change" },
        ],
        executeTime: [
          { required: true, message: '此区域为必填项', trigger: "change" },
        ],
        orderType: [
          { required: false, message: '此区域为必填项', trigger: "change" },
        ],
        zipCodes: [
          { required: true, message: "此区域为必填项", trigger: "blur" },
          // { pattern: /^[(\d+,?\*?)|*]+$/, message: '必须是两位数字或数字和*组成，英文逗号隔开！', trigger: 'change' },
          { pattern: /^([0-9]{1}[0-9*]{1})(,[0-9]{1}[0-9*]{1})*$|^\*$/, message: '请用单独的*号或者两位数字、一位数字和*，中间用英文逗号隔开！', trigger: 'change' },

        ],
      }
    }
  },
  // ============
  created() {
    this.getClientCode()
  },
  components: {
    Pagination
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  mounted() {
    this.runJobBtn = btnAntiShake(this.runJobBtn, 500)
    this.updateSub = btnAntiShake(this.updateSub, 500)
  },
  methods: {
    // 获取基本数据
    async clientData(query) {
      if (!query) {
        this.pageCurrent = 1
        this.pageSize = 10
        query = { current: this.pageCurrent, size: this.pageSize }
      }
      let queryObj = Object.assign(this.form, query)
      this.skuLoading = true //开启loading
      let { data } = await pageObj(queryObj)
      let { data: warehouse } = await getWarehouseCode()
      this.warehouseCodeArr = warehouse.data
      console.log('warehouse_code下拉框查询', JSON.parse(JSON.stringify(warehouse.data)))
      if (data.code != 0) {
        this.skuLoading = false //关loading
        this.$message.error(data.msg);
        return;
      }
      this.tableData = deepClone(data.data)
      data.data.records.forEach((i, v) => {
        warehouse.data.forEach(item => {
          if (i.warehouseCode == item.warehouse_code) {
            this.tableData.records[v].warehouseName = item.warehouse_name
          }
        })
      })
      this.skuLoading = false //关loading
      console.log('页面基本数据', JSON.parse(JSON.stringify(this.tableData.records)))
    },
    // 获取页面下拉框
    async getClientCode() {
      this.clientData()
      // clientCode下拉框查询  /master/client/getClient
      let { data: clientCodeSelect } = await getClient()
      this.clientCodeSelect = clientCodeSelect.data
      // console.log('clientCode下拉框查询', JSON.parse(JSON.stringify(clientCodeSelect.data)))
      // country下拉框查询
      let { data: country } = await remote('country_code')
      this.countryCodeArr = country.data
      let { data: orderType } = await remote('dn_type')
      this.orderTypeArr = orderType.data
      // console.log('country下拉框查询', country.data);
      // console.log('execution下拉框查询', execution.data);
    },

    // 重置
    resetForm(rule) {
      this.$refs[rule].resetFields();
      this.getClientCode()
    },

    //条数
    handleSizeChange(val) {
      this.pageSize = val
      let query = { current: this.pageCurrent, size: val }
      this.clientData(query)
      console.log(`每页 ${val} 条`);
    },
    //当前页数
    handleCurrentChange(val) {
      this.pageCurrent = val
      let query = { current: val, size: this.pageSize }
      this.clientData(query)
      console.log(`当前页: ${val}`);
    },

    async modifyBtn(row, type) {
      this.btnType = type
      if (type == 'add') {
        this.dialogTitle = 'Add'

        //  新增数据 addUpdateObj
        this.updateObj = {
          clientCode: null,
          warehouseCode: null,
          countryCode: [],
          orderType: [],
          executeTime: '',
          executeDesc: '',
          zipCodes: '',
          status: null,
        }
        this.detailAdd = true
        if (this.$refs.updateObj !== undefined) {
          this.$refs.updateObj.resetFields()
        }
      } else {

        this.dialogTitle = 'Edit'
        // 修改数据
        let newUpdateObj = deepClone(row)
        console.log('let newUpdateObj', JSON.parse(JSON.stringify(newUpdateObj)))
        this.updateObj = Object.assign(newUpdateObj, { countryCode: newUpdateObj.countryCode.split(',') }, { orderType: newUpdateObj.orderType ? newUpdateObj.orderType.split(',') : [] })
        this.SwitchValue = this.updateObj.status == '1' ? false : true
        this.detailAdd = true
        console.log('这一行的数据', JSON.parse(JSON.stringify(this.updateObj)))
      }
    },

    runJobBtn(row) {
      console.log('row', JSON.parse(JSON.stringify(row)))
      runJobNow(row.id).then(({ data }) => {
        console.log('执行Job的返回', data);
        if (data.code == 0) {
          this.$message.success(data.msg)
        } else {
          this.$message.error(data.msg)
        }
      }).catch(err => {
        console.log("🚀→→→→→ ~ err", err)
        this.$message.error('Job 执行失败')
      });
    },

    // add/修改数据提交按钮
    updateSub() {
      if (this.btnType == 'add') {
        // 添加数据 addSave
        this.$refs.updateObj.validate(async (valid) => {
          if (!valid) return false
          let putUpdateObj = deepClone(this.updateObj)
          putUpdateObj = { ...this.updateObj, isDelete: '0', status: this.updateObj.status == '1' ? '1' : '0', countryCode: this.updateObj.countryCode.join(), orderType: this.updateObj.orderType.join() }
          console.log(this.btnType, '携带的参数', JSON.parse(JSON.stringify(putUpdateObj)))
          let { data } = await saveObj(putUpdateObj)
          console.log('添加后的数据返回', JSON.parse(JSON.stringify(data)))
          if (data.code != 0) return this.$message.error(data.msg);
          this.skuLoading = false //关loading
          this.cancelClo()
          this.$message.success('Successfully added');
          this.clientData()
        });

      } else {
        // 修改数据
        this.$refs.updateObj.validate(async (valid) => {
          if (!valid) return false
          let putUpdateObj = deepClone(this.updateObj)
          putUpdateObj = { ...this.updateObj, status: this.updateObj.status == '1' ? '1' : '0', countryCode: this.updateObj.countryCode.join(), orderType: this.updateObj.orderType.join() }
          console.log(this.btnType, '携带的参数', JSON.parse(JSON.stringify(putUpdateObj)))
          let { data } = await updateObj(putUpdateObj)
          console.log('修改后的数据返回', JSON.parse(JSON.stringify(data)))
          if (data.code != 0) return this.$message.error(data.msg);
          this.skuLoading = false //关loading
          this.cancelClo()
          this.$message.success('Edit succeeded');
          this.clientData()
        });
      }
    },
    // 添加删除弹框的关闭按钮
    cancelClo() {
      this.detailAdd = false
      this.SwitchValue = false
    },
    // status状态改变
    switchChange(type) {
      this.updateObj.status = type ? 0 : 1;
    },
    // 定时任务
    onChangeCron(v) {
      console.log(v);
      this.updateObj.executeTime = v
      console.log("🚀→→→→→ ~ this.updateObj", this.updateObj)
    },
    cronOff() {
      this.cronPopover = false
    },
  },
};
</script>
<style lang="scss" scoped>
::v-deep .el-select--small {
  display: block;
}

// /* 去掉中间数据的分割线 */
// ::v-deep .el-table__row>td {
//   border: none;
// }

// /* 去掉上面的线 */
// ::v-deep .el-table th.is-leaf {
//   border: none;
// }

// /* 去掉最下面的那一条线 */
// ::v-deep .el-table::before {
//   height: 0px;
// }

.dialog-footer-add {
  display: flex;
  justify-content: center;
  color: rgb(64, 149, 229);
  font-size: 25px;
  margin: 20px 0;
}

.dialog-footer-box {
  display: flex;
  justify-content: center;
  margin-top: 50px;
}

.content {
  padding: 0 10px;

  // box-sizing: border-box;
  .down {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    border-top: 1px solid #999;
    padding-top: 20px;
    box-sizing: border-box;
  }

  .underLine {
    color: #599af8;
    text-decoration: underline;

    .underIcon {
      background-color: green;
      color: #fff;
      border-radius: 50%;
      margin-right: 5px;
    }
  }
}

.operate-icon-wrap {
  display: flex;
  column-gap: 15px;
}

.operate-icon-box {
  display: flex;
  align-items: center;
  cursor: pointer;
  color: #4095e5;
}

.header-cell-class {
  background-color: #ccc;
}

.foot {
  display: flex;
  justify-content: flex-end;
  margin-top: 20px;
}

.btn-bgc {
  background-color: rgb(31, 99, 255);
  color: #fff;
}

.confrim-bgc {
  background-color: #1376c7;
  color: #fff;
}

.cursor-on {
  cursor: pointer;
}

::v-deep .el-dialog__wrapper .el-dialog {
  border-radius: 8px;
}

.tableRed {
  display: inline-block;
  width: 35px;
  height: 18px;
  background-color: #949494;
  border-radius: 9px;
  font-weight: 500;
  line-height: 18px;
  color: white;
}


.tableGre {
  display: inline-block;
  width: 35px;
  height: 18px;
  background-color: #13ce66;
  border-radius: 9px;
  font-weight: 500;
  line-height: 18px;
  color: white;
}

.cronBox {
  ::v-deep .el-tabs__content {
    max-height: 400px !important;
    overflow: auto !important;
  }
}
</style>