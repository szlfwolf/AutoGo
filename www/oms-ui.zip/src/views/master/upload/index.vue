<template>
  <div class="content">
    <el-tabs type="border-card" v-loading="uploadLoading">
      <el-row style="width:200px;display:flex">
        <el-col>
          <el-button icon="el-icon-search" type="primary" @click="getDataList()">Query</el-button>
        </el-col>
        <el-col>
          <el-button @click="resetForm" type="info" plain icon="el-icon-refresh-left">Reset</el-button>
        </el-col>
      </el-row>
      <el-form :model="dataForm" ref="dataForm">
        <el-row style="margin-top: 20px" :gutter="20">
          <el-col :span="4">
            <el-form-item prop="fileName">
              <el-input v-model="dataForm.name" placeholder="fileName"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="4">
            <el-form-item prop="type">
              <el-select filterable v-model="dataForm.type" placeholder="type" clearable>
                <el-option v-for="item in uploadTypeList" :key="item.value" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>

          <el-col :span="4">
            <el-form-item prop="isException">
              <el-select filterable v-model="dataForm.isException" placeholder="status" clearable>
                <el-option v-for="item in uploadStatusList" :key="item.value" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>

          <el-col :span="4">
            <el-form-item prop="exceptionMsg">
              <el-input v-model="dataForm.exceptionMsg" placeholder="msg" clearable></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="4">
            <el-form-item prop="uploadTime">
              <el-date-picker v-model="time.beginTime" type="daterange" start-placeholder="开始日期" end-placeholder="结束日期"
                :default-time="['00:00:00', '23:59:59']" value-format="yyyy-MM-dd HH:mm:ss" @change="changeCreateTime">
              </el-date-picker>
            </el-form-item>

          </el-col>
        </el-row>
      </el-form>

      <div class="down">
        <div></div>
        <div>
          <excel-upload ref="uploadAsnRef" title="ASN upload" url="/inbound/inOrder/uploadAsnOrder"
            temp-name="asnOrder-upload-template.xlsx" temp-url="/admin/sys-file/local/asnOrder-upload-template.xlsx"
            @refreshDataList="asnUploadExcel">
          </excel-upload>
          <excel-upload ref="uploadSkuRef" title="SKU upload" url="/master/sku/uploadSkuByFile"
            temp-name="sku-upload-template.xlsx" temp-url="/admin/sys-file/local/sku-upload-template.xlsx"
            @refreshDataList="skuUploadExcel">
          </excel-upload>
          <excel-upload ref="uploadDnRef" title="DN upload" url="/outbound/outorder/uploadDn"
            temp-name="dn-upload-template.xlsx" temp-url="/admin/sys-file/local/dn-upload-template.xlsx"
            @refreshDataList="dnUploadExcel">
          </excel-upload>
           <!-- 上传 -->
           <el-button icon="el-icon-upload2" @click="$refs.uploadAsnRef.show()"
            v-if="permissions.inbound_inorder_upload_file">ASN</el-button>
          <!-- 上传 -->
          <el-button icon="el-icon-upload2" @click="$refs.uploadSkuRef.show()"
            v-if="permissions.master_sku_upload_file">SKU</el-button>
          <!-- 上传 -->
          <el-button icon="el-icon-upload2" @click="$refs.uploadDnRef.show()"
            v-if="permissions.outorder_uploadDn">DN</el-button>
        </div>
      </div>


      <div class="avue-crud">
        <el-table :data="dataList" border v-loading="dataListLoading" header-cell-class-name="header-cell-class"
          :header-cell-style="{ background: '#f5f7fa', color: '#606266' }">
          <el-table-column prop="clientCode" header-align="center" align="center" label="Owner"
            :show-overflow-tooltip="true" width="120px">
          </el-table-column>
          <el-table-column prop="name" header-align="center" align="center" label="FileName"
            :show-overflow-tooltip="true">
            <template slot-scope="scope">
              <div class="underLine" style="cursor: pointer" @click="getFile(scope.row.path)">
                {{ scope.row.name }}
              </div>
            </template>
          </el-table-column>
          <el-table-column prop="type" header-align="center" align="center" label="Type" :show-overflow-tooltip="true"
            width="120px">
          </el-table-column>
          <el-table-column prop="isException" header-align="center" align="center" label="Status"
            :show-overflow-tooltip="true" width="120px">
            <template slot-scope="scope">
              <span
                :style='{ color: scope.row.isException == "0" ? "green" : scope.row.isException == "1" ? "red" : "blue" }'>
                {{ typeObj[scope.row.isException] }}
              </span>
            </template>
          </el-table-column>
          <el-table-column prop="exceptionMsg" header-align="center" align="center" label="Msg"
            :show-overflow-tooltip="true">
          </el-table-column>
          <el-table-column prop="createTime" header-align="center" align="center" label="UploadTime"
            :show-overflow-tooltip="true" width="150px">
          </el-table-column>
          <el-table-column prop="createBy" header-align="center" align="center" label="UploadUser"
            :show-overflow-tooltip="true" width="120px">
          </el-table-column>
        </el-table>
      </div>

      <div class="avue-crud__pagination">
        <el-pagination @size-change="sizeChangeHandle" @current-change="currentChangeHandle" :current-page="pageIndex"
          :page-sizes="[10, 20, 50, 100]" :page-size="pageSize" :total="totalPage" background
          layout="total, sizes, prev, pager, next, jumper">
        </el-pagination>
      </div>
      <!-- 弹窗, 新增 / 修改 -->
      <table-form v-if="addOrUpdateVisible" ref="addOrUpdate" @refreshDataList="getDataList"></table-form>
    </el-tabs>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { fetchList, delObj } from '@/api/filelog'
import { deepClone } from '@/util/util';
import TableForm from './filelog-form'
import ExcelUpload from "@/components/upload/excel"
import store from '@/store'
import { remote } from '@/api/admin/dict'

export default {
  data() {
    return {
      dataForm: {
      },
      dataList: [],
      pageIndex: 1,
      pageSize: 10,
      totalPage: 0,
      dataListLoading: false,
      addOrUpdateVisible: false,
      uploadTypeList: [],
      uploadStatusList: [],
      typeObj: {
        "0": "normal",
        "1": "exception",
        "2": "part exception",
      },
      uploadLoading: false,
      time: {
        beginTime: "",
        endTime: ""
      },
    }
  },
  components: {
    ExcelUpload,
    TableForm
  },
  created() {
    this.getSelectDataList()
    this.getDataList()
  },
  computed: {
    ...mapGetters(['permissions'])
  },
  methods: {

        //时间参数
        changeCreateTime(val) {
      if (val !== undefined && val !== null && val !== '' && val.length > 0) {
        this.$set(this.dataForm, 'beginTime', val[0])
        this.$set(this.dataForm, 'endTime', val[1])
      } else {
        this.$set(this.dataForm, 'beginTime', undefined)
        this.$set(this.dataForm, 'endTime', undefined)
      }
    },
    // 获取数据列表
    getDataList() {
      this.dataListLoading = true
      fetchList(Object.assign({
        current: this.pageIndex,
        size: this.pageSize
      }, this.dataForm)).then(response => {
        this.dataList = response.data.data.records
        this.totalPage = response.data.data.total
      })
      this.dataListLoading = false
    },
    // 每页数
    sizeChangeHandle(val) {
      this.pageSize = val
      this.pageIndex = 1
      this.getDataList()
    },
    // 当前页
    currentChangeHandle(val) {
      this.pageIndex = val
      this.getDataList()
    },
    // 新增 / 修改
    addOrUpdateHandle(id) {
      this.addOrUpdateVisible = true
      this.$nextTick(() => {
        this.$refs.addOrUpdate.init(id)
      })
    },
    // 删除
    deleteHandle(id) {
      this.$confirm('是否确认删除ID为' + id, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(function () {
        return delObj(id)
      }).then(data => {
        this.$message.success('删除成功')
        this.getDataList()
      }).catch(() => { })
    },
    
     // ASN上传
     asnUploadExcel(response) {
      if (response == 'loading') {
        this.uploadLoading = true
        return
      }
      if (!!response && response.code == 0) {
        this.uploadLoading = false
      } else {
        this.uploadLoading = false
      }
      this.getDataList()
    },

    // SKU上传
    skuUploadExcel(response) {
      if (response == 'loading') {
        this.uploadLoading = true
        return
      }
      if (!!response && response.code == 0) {
        this.uploadLoading = false
      } else {
        this.uploadLoading = false
      }
      this.getDataList()
    },
  
    // DN上传
    dnUploadExcel(response) {
      // console.log("resoonse", response);
      // if (response == 'loading') {
      //   this.uploadLoading = true
      //   return
      // }
      this.uploadLoading = true

      this.getDataList()
      this.uploadLoading = false
    },

    //表单重置
    resetForm() {
      this.dataForm = this.$options.data().dataForm
      this.time = this.$options.data().time
      this.getDataList()
    },
    getSelectDataList() {
      remote("upload_type").then(res => {
        if (res.data.code === 0) {
          this.uploadTypeList = res.data.data;
        }
      });
      remote("upload_status").then(res => {
        if (res.data.code === 0) {
          this.uploadStatusList = res.data.data;
        }
      });
    },

    //下载文件
    getFile(file) {
      console.log("下载文件链接", file)
      const link = document.createElement("a");
      link.href = file
      document.body.appendChild(link);
      link.click();
      window.setTimeout(function () {
        URL.revokeObjectURL(link.href);
        document.body.removeChild(link);
      }, 0);
    }


  }
}


</script>

<style lang="scss" scoped>
::v-deep .el-select--small {
  display: block;
}

.down {
  display: flex;
  justify-content: space-between;
  margin-bottom: 20px;
  border-top: 1px solid #999;
  padding-top: 20px;
  box-sizing: border-box;
}

.underLine {
  color: #599af8;
  text-decoration: underline;

  .underIcon {
    background-color: green;
    color: #fff;
    border-radius: 50%;
    margin-right: 5px;
  }
}

.content {
  padding: 0 10px;

  .down {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    border-top: 1px solid #999;
    padding-top: 20px;
    box-sizing: border-box;
  }

  .underLine {
    color: #599af8;
    text-decoration: underline;

    .underIcon {
      background-color: green;
      color: #fff;
      border-radius: 50%;
      margin-right: 5px;
    }
  }
}

.operate-icon-wrap {
  display: flex;
  column-gap: 15px;
}

.operate-icon-box {
  display: flex;
  align-items: center;
  cursor: pointer;
  color: #4095e5;
}

.header-cell-class {
  background-color: #ccc;
}

.foot {
  display: flex;
  justify-content: flex-end;
  margin-top: 20px;
}

.btn-bgc {
  background-color: rgb(31, 99, 255);
  color: #fff;
}

.confrim-bgc {
  background-color: #1376c7;
  color: #fff;
}

.cursor-on {
  cursor: pointer;
}

::v-deep .el-dialog__wrapper .el-dialog {
  border-radius: 8px;
}
</style>
