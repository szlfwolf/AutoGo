<template>
  <div class="content">
    <el-tabs type="border-card" v-loading="dataLoading">
      <el-row style="width: 200px; display: flex">
        <el-col>
          <el-button type="primary" icon="el-icon-search" @click="queryList()">Query</el-button>
        </el-col>
        <el-col>
          <el-button @click="resetForm('form')" type="info" plain icon="el-icon-refresh-left">Reset</el-button>
        </el-col>
      </el-row>
      <el-form ref="form" :model="form">
        <el-row style="margin-top: 20px" :gutter="20">
          <el-col :span="4">
            <el-form-item prop="shipType">
              <el-select filterable clearable v-model="form.shipType" placeholder="ShipType">
                <el-option v-for="item in shipTypeList" :key="item.value" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="4">
            <el-form-item prop="supplierCode"><el-input v-model="form.supplierCode" placeholder="Supplier Code"
                size="small" class="search"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="4">
            <el-form-item prop="supplierName"><el-input v-model="form.supplierName" placeholder="Supplier Name"
                size="small" class="search"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div class="down">
        <!-- Add按钮 -->
        <el-button v-if="permissions.supplier_add" type="primary" style="padding: 5px 20px; color: #fff"
          @click="modifyBtn('', 'add')">
          <span style="display: flex; align-items: center">
            <i class="el-icon-circle-plus-outline" style="margin-right: 10px; font-size: 20px"></i>Add
          </span>
        </el-button>
      </div>
      <!-- 数据表 -->
      <el-table border stripe ref="multipleTable" :data="tableData.records" tooltip-effect="dark" style="width: 100%"
        header-cell-class-name="header-cell-class" :header-cell-style="{ background: '#f5f7fa', color: '#606266' }">
        <el-table-column :show-overflow-tooltip="true" label="Ship Type" min-width="100" align="center">
          <template slot-scope="scope">{{
            formatShipTypeFunc(scope.row.shipType)
          }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Supplier Code" min-width="100" align="center">
          <template slot-scope="scope">{{ scope.row.supplierCode }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Supplier Name" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.supplierName }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Official Website" min-width="200" align="center">
          <template slot-scope="scope">{{
            scope.row.officialWebsite
          }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Remark" min-width="100" align="center">
          <template slot-scope="scope">{{ scope.row.remark }}</template>
        </el-table-column>

        <el-table-column :show-overflow-tooltip="true" label="Create User" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.createBy }}</template>
        </el-table-column>

        <el-table-column :show-overflow-tooltip="true" label="Create Time" min-width="130" align="center">
          <template slot-scope="scope">{{ scope.row.createTime }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Update User" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.updateBy }}</template>
        </el-table-column>

        <el-table-column :show-overflow-tooltip="true" label="Update Time" min-width="130" align="center">
          <template slot-scope="scope">{{ scope.row.updateTime }}</template>
        </el-table-column>

        <el-table-column v-if="permissions.supplier_update || permissions.supplier_delete" :show-overflow-tooltip="true"
          label="Opearte" min-width="130" align="center">
          <template slot-scope="scope">
            <el-button v-if="permissions.supplier_update" type="text" style="font-size: 18px; color: #65beff"
              icon="el-icon-edit" @click="modifyBtn(scope.row, 'edit')">
            </el-button>
            <el-button v-if="permissions.supplier_delete" type="text" style="font-size: 18px; color: #65beff"
              icon="el-icon-delete" @click="modifyBtn(scope.row, 'delete')">
            </el-button>
          </template>
        </el-table-column>
      </el-table>

      <Pagination @handleSizeChange="handleSizeChange" @handleCurrentChange="handleCurrentChange"
        :pageNum="tableData.current" :pageSize="tableData.size" :total="tableData.total"></Pagination>

      <!-- Add弹框  Synthesis Setting-->
      <el-dialog :title="dialogTitle" :visible.sync="detailAdd" width="35%" :before-close="cancelClo"
        style="font-weight: 700" :close-on-click-modal="btnType != 'add'">
        <!-- 内容 -->
        <el-form ref="updateObj" :rules="rules" :model="updateObj" label-width="150px">
          <el-form-item label="ShipType:" prop="shipType">
            <el-select filterable placeholder="" clearable v-model="updateObj.shipType">
              <el-option v-for="item in shipTypeList" :key="item.value" :label="item.label" :value="item.value">
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="Supplier Code:" prop="supplierCode">
            <el-input placeholder="" size="small" v-model="updateObj.supplierCode">
            </el-input>
          </el-form-item>
          <el-form-item label="Supplier Name:" prop="supplierName">
            <el-input type="input" v-model="updateObj.supplierName"> </el-input>
          </el-form-item>

          <el-row>
            <el-form-item label="Official Website:" prop="officialWebsite">
              <el-input rows="4" type="textarea" v-model="updateObj.officialWebsite">
              </el-input>
            </el-form-item>
          </el-row>
          <el-row>
            <el-form-item label="Remark:" prop="remark">
              <el-input v-model.trim="updateObj.remark" rows="4" type="textarea"></el-input>
            </el-form-item>
          </el-row>
        </el-form>
        <div class="dialog-footer-box">
          <span slot="footer">
            <el-button @click="cancelClo" style="margin-right: 20px; padding: 10px 40px" type="info">Cancel
            </el-button>
            <el-button type="primary" @click="updateSub" style="padding: 10px 40px">Confirm</el-button>
          </span>
        </div>
      </el-dialog>
    </el-tabs>
  </div>
</template>
<script>
let formParams = {
  shipType: null,
  supplierCode: null,
  supplierName: null,
};
import { mapGetters } from "vuex";
import Pagination from "@/components/pagination/pagination.vue";
import { deepClone } from "@/util/util";
import {
  fetch,
  save,
  updateById,
  deleteById,
} from "@/api/master/supplier/supplier";
import { btnAntiShake } from "@/util/btnAntiShake";
export default {
  name: "SupplierConfig",
  data() {
    return {
      shipTypeList: [
        {
          label: "Express",
          value: "1",
        },
        {
          label: "Pallet",
          value: "2",
        },
        {
          label: "Special Car",
          value: "3",
        },
      ],

      dialogTitle: "",
      btnType: "",
      dataLoading: false,
      pageSize: "",
      pageCurrent: "1",
      detailAdd: false,
      form: Object.assign({}, formParams),
      // 基本数据
      tableData: [],
      size: 10,
      total: 100,
      //   修改表单
      updateObj: {},

      rules: {
        shipType: [
          { required: true, message: "此区域为必填项", trigger: "change" },
        ],
        supplierCode: [
          { required: true, message: "此区域为必填项", trigger: "change" },
        ],
        supplierName: [
          { required: true, message: "此区域为必填项", trigger: "change" },
        ],
      },
    };
  },
  // ============
  created() {
    this.queryList();
  },
  components: {
    Pagination,
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  mounted() {
    this.updateSub = btnAntiShake(this.updateSub, 500);
  },
  methods: {
    formatShipTypeFunc(value) {
      let formatVal = value;
      this.shipTypeList.forEach((x) => {
        if (x.value === value) {
          formatVal = x.label;
        }
      });

      return formatVal;
    },

    // 重置
    resetForm(rule) {
      this.$refs[rule].resetFields();
      this.getClientCode();
    },

    queryList() {
      this.dataLoading = true;
      const obj = Object.assign(
        {
          current: this.pageCurrent,
          size: this.pageSize,
        },
        this.form
      );
      fetch(obj).then((response) => {
        if (response.data.code === 0) {
          this.tableData = response.data.data;
          this.total = response.data.data.total;
          this.dataLoading = false;
        } else {
          this.$message.error(response.data.msg);
        }
      });
    },

    //条数
    handleSizeChange(val) {
      this.pageSize = val;
      let query = { current: this.pageCurrent, size: val };
      this.queryList(query);
      console.log(`每页 ${val} 条`);
    },
    //当前页数
    handleCurrentChange(val) {
      this.pageCurrent = val;
      let query = { current: val, size: this.pageSize };
      this.queryList(query);
      console.log(`当前页: ${val}`);
    },

    async modifyBtn(row, type) {
      this.btnType = type;
      if (type == "add") {
        this.dialogTitle = "Add";

        //  新增数据
        this.updateObj = {
          shipType: null,
          supplierCode: null,
          supplierName: null,
          officialWebsite: null,
          remark: "",
        };
        this.detailAdd = true;
        if (this.$refs.updateObj !== undefined) {
          this.$refs.updateObj.resetFields();
        }
      } else if (type == "edit") {
        this.dialogTitle = "Edit";
        // 修改数据
        let newUpdateObj = deepClone(row);
        this.updateObj = Object.assign(newUpdateObj);
        this.detailAdd = true;
      } else if (type == "delete") {
        let { data } = await deleteById(row.id);
        if (data.code != 0) return this.$message.error(data.msg);

        this.queryList();
      }
    },

    // add/修改数据提交按钮
    updateSub() {
      if (this.btnType == "add") {
        // 添加数据 addSave
        this.$refs.updateObj.validate(async (valid) => {
          if (!valid) return false;
          let putUpdateObj = deepClone(this.updateObj);
          putUpdateObj = {
            ...this.updateObj,
          };

          let { data } = await save(putUpdateObj);
          if (data.code != 0) return this.$message.error(data.msg);
          this.dataLoading = false; //关loading
          this.cancelClo();
          this.$message.success("Successfully added");
          this.queryList();
        });
      } else {
        // 修改数据
        this.$refs.updateObj.validate(async (valid) => {
          if (!valid) return false;
          let putUpdateObj = deepClone(this.updateObj);
          putUpdateObj = {
            ...this.updateObj,
          };

          let { data } = await updateById(putUpdateObj);
          if (data.code != 0) return this.$message.error(data.msg);
          this.dataLoading = false; //关loading
          this.cancelClo();
          this.$message.success("Edit succeeded");
          this.queryList();
        });
      }
    },

    // 添加删除弹框的关闭按钮
    cancelClo() {
      this.detailAdd = false;
      this.SwitchValue = false;
    },
  },
};
</script>
<style lang="scss" scoped>
::v-deep .el-select--small {
  display: block;
}

.dialog-footer-add {
  display: flex;
  justify-content: center;
  color: rgb(64, 149, 229);
  font-size: 25px;
  margin: 20px 0;
}

.dialog-footer-box {
  display: flex;
  justify-content: center;
  margin-top: 50px;
}

.content {
  padding: 0 10px;

  // box-sizing: border-box;
  .down {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    border-top: 1px solid #999;
    padding-top: 20px;
    box-sizing: border-box;
  }

  .underLine {
    color: #599af8;
    text-decoration: underline;

    .underIcon {
      background-color: green;
      color: #fff;
      border-radius: 50%;
      margin-right: 5px;
    }
  }
}

.operate-icon-wrap {
  display: flex;
  column-gap: 15px;
}

.operate-icon-box {
  display: flex;
  align-items: center;
  cursor: pointer;
  color: #4095e5;
}

.header-cell-class {
  background-color: #ccc;
}

.foot {
  display: flex;
  justify-content: flex-end;
  margin-top: 20px;
}

.btn-bgc {
  background-color: rgb(31, 99, 255);
  color: #fff;
}

.confrim-bgc {
  background-color: #1376c7;
  color: #fff;
}

.cursor-on {
  cursor: pointer;
}

::v-deep .el-dialog__wrapper .el-dialog {
  border-radius: 8px;
}

.tableRed {
  display: inline-block;
  width: 35px;
  height: 18px;
  background-color: #949494;
  border-radius: 9px;
  font-weight: 500;
  line-height: 18px;
  color: white;
}

.tableGre {
  display: inline-block;
  width: 35px;
  height: 18px;
  background-color: #13ce66;
  border-radius: 9px;
  font-weight: 500;
  line-height: 18px;
  color: white;
}

.cronBox {
  ::v-deep .el-tabs__content {
    max-height: 400px !important;
    overflow: auto !important;
  }
}
</style>
