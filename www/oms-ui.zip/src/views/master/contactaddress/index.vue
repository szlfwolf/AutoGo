<template>
  <div class="content">
    <el-tabs type="border-card" v-loading="skuLoading">
      <el-row style="width:200px;display:flex">
        <el-col>
          <el-button type="primary" icon="el-icon-search" @click="getFetchList()">Query</el-button>
        </el-col>
        <el-col>
          <el-button @click="resetForm('form')" type="info" plain icon="el-icon-refresh-left">Reset</el-button>
        </el-col>
      </el-row>
      <el-form ref="form" :model="form">
        <el-row style="margin-top: 20px" :gutter="20">
          <el-col :span="4">
            <el-form-item prop="countryCode">
              <el-select filterable clearable placeholder="Country Code" v-model="form.countryCode">
                <el-option v-for="item in options" :key="item" :label="item" :value="item">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="4">
            <el-form-item prop="contactPhone">
              <el-input v-model="form.contactPhone" placeholder="Tel"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="4">
            <el-form-item prop="zipCode">
              <el-input v-model="form.zipCode" placeholder="Zipcode"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <!-- 下载 -->
      <div class="down">
        <el-button v-if="permissions.master_contactaddress_export" icon="el-icon-download" @click="exportExcel">
        </el-button>
      </div>
      <!-- 表 -->
      <el-table border stripe ref="multipleTable" :data="tableData.records" tooltip-effect="dark" style="width: 100%"
        header-cell-class-name="header-cell-class" :header-cell-style="{ background: '#f5f7fa', color: '#606266' }">
        <el-table-column :show-overflow-tooltip="true" label="Address Id" min-width="100" align="center">
          <template slot-scope="scope">{{ scope.row.id }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Customer Number" min-width="150" align="center">
          <template slot-scope="scope">
            {{ scope.row.customerCode }}
          </template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="ConsigneeName" min-width="120" align="center">
          <template slot-scope="scope">
            {{ scope.row.contactName }}
          </template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="ConsigneeMobile" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.contactPhone }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="ConsigneeEmail" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.contactEmail }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Zipcode" min-width="180" align="center">
          <template slot-scope="scope">{{ scope.row.zipCode }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Country Code" min-width="100" align="center">
          <template slot-scope="scope">{{ scope.row.countryCode }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="City" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.cityName }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Address" min-width="180" align="center">
          <template slot-scope="scope">{{ scope.row.address }}</template>
        </el-table-column>
        <!-- 按钮 -->
        <el-table-column v-if="permissions.master_contactaddress_update" label="Opearte" min-width="100" align="center">
          <template slot-scope="scope">
            <el-button type="text" style="font-size:18px;  color: #65BEFF;" icon="el-icon-edit"
              @click="modifyBtn(scope.row)">
            </el-button>
          </template>
        </el-table-column>
      </el-table>
      <!-- 分页 -->
      <Pagination @handleSizeChange="handleSizeChange" @handleCurrentChange="handleCurrentChange"
        :pageNum="tableData.current" :pageSize="tableData.size" :total="tableData.total"></Pagination>
      <!-- 修改的弹框 -->
      <el-dialog title="Edit" :visible.sync="centerDialogVisible" width="30%" style="font-weight: 700" @close="getClose">
        <el-form ref="releaseForm" :model="editData" :rules="rules" label-width="100px">
          <el-form-item label="Remark:" prop="remark">
            <el-input type="textarea" v-model="editData.remark" placeholder="请输入..."> </el-input>
          </el-form-item>
        </el-form>
        <span slot="footer" class="dialog-footer">
          <el-button type="info" @click="centerDialogVisible = false">Cancel</el-button>
          <el-button type="primary" @click="dialogButton(editData)">Release</el-button>
        </span>
      </el-dialog>
    </el-tabs>
  </div>
</template>
<script>
import { deepClone } from '@/util/util';
let formParams = {
  countryCode: null,
  contactPhone: null,
  zipCode: null,
};
import { mapGetters } from "vuex"
import Pagination from "@/components/pagination/pagination.vue"
import { fetchList } from "../../../api/contactaddress";
import { getCountryCode, putObj } from "../../../api/contactaddress";
import { btnAntiShake } from '@/util/btnAntiShake'
export default {
  name: "ASN",
  data() {
    return {
      centerDialogVisible: false,
      skuLoading: false,
      pageSize: '',
      pageCurrent: '1',
      detailAdd: false,
      isBackUp: false,
      isPackageInfo: false,
      form: Object.assign({}, formParams),
      options: [],
      // 基本数据
      tableData: {},
      multipleSelection: [],
      size: 10,
      total: 100,
      rules: {
        remark: [{ required: true, message: '请输入备注', trigger: 'blur' },
        { max: 255, message: '长度最大 255 个字', trigger: 'blur' }
        ],
      },
      // 修改remark  这一行的数据
      editData: {}
    };

  },

  //===========
  created() {
    this.getFetchList();
    this.countryCode()
  },
  components: {
    Pagination
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  mounted() {
    this.exportExcel = btnAntiShake(this.exportExcel, 500)
  },
  methods: {
    // 分页查询
    async getFetchList(query) {
      if (!query) {
        this.pageCurrent = 1
        this.pageSize = 10
        query = { current: this.pageCurrent, size: this.pageSize }
      }
      let queryObj = Object.assign(this.form, query)
      this.skuLoading = true //开启loading
      let { data } = await fetchList(queryObj);
      if (data.code != 0) {
        this.skuLoading = false //关loading
        this.$message.error(data.msg);
        return;
      }
      this.skuLoading = false //关loading
      this.tableData = deepClone(data.data)
      console.log('页面基本数据', JSON.parse(JSON.stringify(this.tableData)))
    },
    // 条件查询的下拉框数据
    async countryCode() {
      let { data } = await getCountryCode()
      this.options = data
      console.log('条件查询的下拉框数据', JSON.parse(JSON.stringify(data)))
    },
    // 重置
    resetForm(rule) {
      this.$refs[rule].resetFields();
      this.getFetchList();
    },
    //导出
    exportExcel() {
      this.skuLoading = true
      this.downBlobFile("/master/contactaddress/export", this.form, `${this.$store.state.common.commandName}-address-${this.toDateFormat(new Date(), true)}.xlsx`, () => this.skuLoading = false);
    },

    //条数
    handleSizeChange(val) {
      this.pageSize = val
      let query = { current: this.pageCurrent, size: val }
      this.getFetchList(query)
      console.log(`每页 ${val} 条`);
    },
    //当前页数
    handleCurrentChange(val) {
      this.pageCurrent = val
      let query = { current: val, size: this.pageSize }
      this.getFetchList(query)
      console.log(`当前页: ${val}`);
    },
    // modifyBtn 编辑
    modifyBtn(row) {
      console.log('这一样的数据', JSON.parse(JSON.stringify(row)))
      this.centerDialogVisible = true
      this.editData = deepClone(row)
    },
    //关闭弹窗
    getClose() {
      this.formDialog = { remark: "" }
    },
    // 编辑确定按钮
    async dialogButton(editData) {
      console.log('修改携带的数据', JSON.parse(JSON.stringify(editData)))
      let { data } = await putObj(editData)
      if (data.code != 0) {
        this.$message.error(data.msg)
        return
      }
      this.$message.success(data.msg)
      this.centerDialogVisible = false
      // let query = { current: this.pageCurrent, size: this.pageSize }
      this.getFetchList();
      console.log('data', JSON.parse(JSON.stringify(data)))
    }
  },
};
</script>
<style lang="scss" scoped>
::v-deep .el-select--small {
  display: block;
}

// /* 去掉中间数据的分割线 */
// ::v-deep .el-table__row>td {
//   border: none;
// }

// /* 去掉上面的线 */
// ::v-deep .el-table th.is-leaf {
//   border: none;
// }

// /* 去掉最下面的那一条线 */
// ::v-deep .el-table::before {
//   height: 0px;
// }

.dialog-footer-add {
  display: flex;
  justify-content: center;
  color: rgb(64, 149, 229);
  font-size: 25px;
  margin: 20px 0;
}

.dialog-footer-box {
  display: flex;
  justify-content: center;
  margin-top: 150px;
}

.content {
  padding: 0 10px;

  // box-sizing: border-box;
  .down {
    display: flex;
    justify-content: flex-end;
    margin-bottom: 20px;
    border-top: 1px solid #999;
    padding-top: 20px;
    box-sizing: border-box;
  }

  .underLine {
    color: #599af8;
    text-decoration: underline;

    .underIcon {
      background-color: green;
      color: #fff;
      border-radius: 50%;
      margin-right: 5px;
    }
  }
}

.operate-icon-wrap {
  display: flex;
  column-gap: 15px;
}

.operate-icon-box {
  display: flex;
  align-items: center;
  cursor: pointer;
  color: #4095e5;
}

.header-cell-class {
  background-color: #ccc;
}

.foot {
  display: flex;
  justify-content: flex-end;
  margin-top: 20px;
}

.btn-bgc {
  background-color: rgb(31, 99, 255);
  color: #fff;
}

.confrim-bgc {
  background-color: #1376c7;
  color: #fff;
}

.cursor-on {
  cursor: pointer;
}
</style>
