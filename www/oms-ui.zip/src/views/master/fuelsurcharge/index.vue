<template>
  <div class="content">
    <el-tabs type="border-card" v-loading="skuLoading">
      <el-row style="width:200px;display:flex">
        <el-col>
          <el-button type="primary" icon="el-icon-search" @click="Query()">Query</el-button>
        </el-col>
        <el-col>
          <el-button @click="resetForm('form')" type="info" plain icon="el-icon-refresh-left">Reset</el-button>
        </el-col>
      </el-row>
      <el-form ref="form" :model="form">
        <el-row style="margin-top: 20px" :gutter="20">
          <!-- <el-col :span="4">
            <el-form-item prop="warehouseCode">
               <el-select filterable clearable v-model="form.warehouseCode" placeholder="Warehouse Code">
                <el-option v-for="item in warehouseArr" :key="item.warehouseCode" :label="item.warehouseName"
                  :value="item.warehouseCode"></el-option>
              </el-select>
            </el-form-item>
          </el-col> -->
          <el-col :span="4">
            <el-form-item prop="month">
              <el-date-picker style="width:100%" v-model="form.month" type="month" value-format="yyyy-MM"
                placeholder="Month">
              </el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span="4">
            <el-form-item prop="courierType">
              <el-select filterable clearable v-model="form.courierType" placeholder="Courier Type">
                <el-option v-for="item in courierTypeArr" :key="item.value" :label="item.label"
                  :value="item.value"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="4">
            <el-form-item prop="countryCode">
              <el-select filterable clearable v-model="form.countryCode" placeholder="Country Code">
                <el-option v-for="item in countryCodeArr" :key="item.value" :label="item.label"
                  :value="item.value"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div class="down">
        <!-- Add按钮 -->
        <el-button v-if="permissions.masterdata_fuelsurcharge_add" type="primary"
          style=" padding: 5px 20px; color: #fff;  " @click="modifyBtn('', 'add')">
          <span style="display: flex; align-items: center">
            <i class="el-icon-circle-plus-outline" style="margin-right: 10px; font-size: 20px"></i>Add
          </span>
        </el-button>
        <span v-else></span>
        <div>
          <excel-upload ref="BackUpRef" title="Fuelsurcharge upload" url="/master/fuelsurcharge/import"
            temp-name="fuelSurchargeTemplate.xlsx" temp-url="/admin/sys-file/local/fuelSurchargeTemplate.xlsx"
            @refreshDataList="uploadHsCode">
          </excel-upload>
          <!-- 上传 -->
          <el-button v-if="permissions.masterdata_fuelsurcharge_import" icon="el-icon-upload2"
            @click="$refs.BackUpRef.show()"></el-button>
          <!-- 下载 -->
          <el-button v-if="permissions.masterdata_fuelsurcharge_export" icon="el-icon-download"
            @click="exportExcel"></el-button>
        </div>
      </div>
      <!-- 数据表 -->
      <el-table tooltip-effect="dark" stripe border ref="multipleTable" :data="tableData.records" style="width: 100%"
        header-cell-class-name="header-cell-class" :header-cell-style="{ background: '#f5f7fa', color: '#606266' }">
        <!-- <el-table-column :show-overflow-tooltip="true" label="Owner" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.clientCode }}</template>
        </el-table-column> -->
        <el-table-column :show-overflow-tooltip="true" label="Courier Type" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.courierName }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Country Code" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.countryCode }}</template>
        </el-table-column>
        <!-- <el-table-column :show-overflow-tooltip="true" label="Warehouse Code" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.warehouseCode }}</template>
        </el-table-column> -->
        <el-table-column :show-overflow-tooltip="true" label="Month" min-width="100" align="center">
          <template slot-scope="scope">{{ scope.row.month }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Rate" min-width="100" align="center">
          <template slot-scope="scope">{{ scope.row.rate ? scope.row.rate + '%' : '' }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Create Time" min-width="100" align="center">
          <template slot-scope="scope">{{ scope.row.createTime }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Create By" min-width="100" align="center">
          <template slot-scope="scope">{{ scope.row.createBy }}</template>
        </el-table-column>
        <el-table-column v-if="permissions.masterdata_fuelsurcharge_edit || permissions.masterdata_fuelsurcharge_del"
          :show-overflow-tooltip="true" label="Opearte" min-width="100" align="center">
          <template slot-scope="scope">
            <el-button v-if="permissions.masterdata_fuelsurcharge_edit" type="text"
              style="font-size:18px;  color: #65BEFF;" icon="el-icon-edit" @click="modifyBtn(scope.row, 'modify')">
            </el-button>
            <el-button v-if="permissions.masterdata_fuelsurcharge_del" type="text"
              style="font-size:18px;  color: #65BEFF;" icon="el-icon-delete" @click="deleteBtn(scope.$index, scope.row)">
            </el-button>
          </template>
        </el-table-column>
      </el-table>
      <Pagination @handleSizeChange="handleSizeChange" @handleCurrentChange="handleCurrentChange"
        :pageNum="tableData.current" :pageSize="tableData.size" :total="tableData.total"></Pagination>

      <!-- Add弹框 -->
      <el-dialog :title="dialogTitle" :visible.sync="detailAdd" width="35%" :before-close="cancelClo"
        style="font-weight: 700" :close-on-click-modal='btnType != "add"'>
        <!-- 内容 -->
        <el-form ref="updateObj" :rules="rules" :model="updateObj" label-width="140px">
          <!-- <el-form-item label="Client Code:" prop="clientCode">
            <el-input disabled :value="clientCodeName"></el-input>
          </el-form-item> -->
          <!-- <el-form-item label="Warehouse Code:" prop="warehouseCode">
             <el-select filterable clearable v-model="updateObj.warehouseCode" placeholder="">
              <el-option v-for="item in warehouseArr" :key="item.warehouseCode" :label="item.warehouseName"
                :value="item.warehouseCode"></el-option>
            </el-select>
          </el-form-item> -->
          <el-form-item label="Courier Type:" prop="courierType">
            <el-select filterable clearable v-model="updateObj.courierType" placeholder="">
              <el-option v-for="item in courierTypeArr" :key="item.value" :label="item.label"
                :value="item.value"></el-option>
            </el-select>
          </el-form-item>

          <el-row>
            <el-form-item label="Month:" prop="month">
              <el-date-picker style="width:100%" v-model="updateObj.month" type="month" value-format="yyyy-MM"
                placeholder="选择月">
              </el-date-picker>
            </el-form-item>
          </el-row>
          <el-row>
            <el-form-item label="Country Code:" prop="countryCode">
              <el-select filterable multiple clearable v-model="updateObj.countryCode" placeholder="">
                <el-option v-for="item in countryCodeArr" :key="item.value" :label="item.label"
                  :value="item.value"></el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="Rate:" prop="rate">
              <el-input v-model.trim="updateObj.rate">
                <template slot="append">%</template>
              </el-input>
            </el-form-item>
          </el-row>
        </el-form>
        <div class="dialog-footer-box">
          <span slot="footer">
            <el-button @click="cancelClo" style="margin-right: 20px; padding: 10px 40px" type="info">Cancel
            </el-button>
            <el-button type="primary" @click="updateSub" style="padding: 10px 40px">Confirm</el-button>
          </span>
        </div>
      </el-dialog>
    </el-tabs>
  </div>
</template>
<script>
let formParams = {
  // clientCode: store.getters.commandName,
  // warehouseCode: null,
  month: null,
  courierType: null,
  countryCode: null,
};
import { mapGetters } from "vuex"
import Pagination from "@/components/pagination/pagination.vue"
import { deepClone } from '@/util/util';
import ExcelUpload from "@/components/upload/excel"
import { btnAntiShake } from '@/util/btnAntiShake'
import { remote } from '@/api/admin/dict'
import store from '@/store'
import { addSave, update, delObj, queryHscode } from '@/api/fuelsurcharge'
import { getCountryCode, } from '@/api/warehouse'
// import { AddParentWarehouseCodes } from "@/api/quotation"

export default {
  data() {
    let priceRule8 = (rule, value, callback) => {
      value = String(value)
      if (value.includes('.')) {
        value.indexOf('.') >= 9 ? callback(new Error('整数部分最大长度为8位')) : callback()
      } else {
        value.length >= 9 ? callback(new Error('整数部分最大长度为8位')) : callback()
      }
    }
    return {
      courierTypeArr: [],
      countryCodeArr: [],
      clientCodeName: '',
      dialogTitle: '',
      btnType: '',
      skuLoading: false,
      pageSize: '',
      pageCurrent: '1',
      detailAdd: false,
      form: Object.assign({}, formParams),
      // 基本数据
      tableData: [],
      size: 10,
      total: 100,
      //   修改表单
      updateObj: {
      },

      rules: {
        // warehouseCode: [
        //   { required: true, message: '此区域为必填项', trigger: "change" },
        // ],
        month: [
          { required: true, message: '此区域为必填项', trigger: "change" },
        ],
        courierType: [
          { required: true, message: '此区域为必填项', trigger: "change" },
        ],
        countryCode: [
          { required: true, message: '此区域为必填项', trigger: "change" },
        ],
        rate: [
          { required: true, message: "此区域为必填项", trigger: "change" },
          { pattern: /^[0-9]+([.]{1}[0-9]+){0,1}$/, message: '请输入大于等于0的整数或小数', trigger: 'change' },
          { validator: priceRule8, trigger: 'change' },
        ],
      }
    }
  },
  // ============
  created() {
    // 当前的用户
    this.clientCodeName = store.getters.commandName
    this.Query()
  },
  components: {
    ExcelUpload,
    Pagination
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  mounted() {
    this.exportExcel = btnAntiShake(this.exportExcel, 500)
    this.updateSub = btnAntiShake(this.updateSub, 500)
  },
  methods: {
    // 通过条件查询数据
    async Query(query) {
      if (!query) {
        this.pageCurrent = 1
        this.pageSize = 10
        query = { current: this.pageCurrent, size: this.pageSize }
      }
      let queryObj = Object.assign(this.form, query)
      this.skuLoading = true
      // let { data: warehouse } = await AddParentWarehouseCodes()
      // this.warehouseArr = warehouse.data
      let { data: { data: codeArr } } = await remote('country_code')
      this.countryCodeArr = codeArr
      let { data: { data: typeArr } } = await remote('courier_type')
      this.courierTypeArr = typeArr
      // console.log("🚀→→→→→ ~ typeArr:", typeArr)
      // console.log("🚀→→→→→ ~ codeArr:", codeArr)
      let { data } = await queryHscode(queryObj)
      if (data.code != 0) {
        this.skuLoading = false //关loading
        this.$message.error(data.msg);
        return;
      }
      this.skuLoading = false //关loading
      let dataMap = deepClone(data.data)
      // 映射courierName
      dataMap.records.forEach(i => {
        typeArr.forEach(item => {
          if (i.courierType == item.value) {
            i.courierName = item.label
          }
        })
      })
      this.tableData = dataMap
      console.log('页面基本数据', JSON.parse(JSON.stringify(this.tableData)))
    },
    // 重置
    resetForm(rule) {
      this.$refs[rule].resetFields();
      this.Query()
    },
    //导出
    exportExcel() {
      this.skuLoading = true
      this.downBlobFile("/master/fuelsurcharge/export", this.form, `${this.$store.state.common.commandName}-fuelsurcharge-${this.toDateFormat(new Date(), true)}.xlsx`, () => this.skuLoading = false);
    },

    // 上传
    uploadHsCode(response) {
      if (response == 'loading') {
        this.skuLoading = true
        return
      }
      if (!!response && response.code == 0) {
        this.skuLoading = false
      } else {
        this.skuLoading = false
      }
      this.Query()
    },
    //条数
    handleSizeChange(val) {
      this.pageSize = val
      let query = { current: this.pageCurrent, size: val }
      this.Query(query)
      console.log(`每页 ${val} 条`);
    },
    //当前页数
    handleCurrentChange(val) {
      this.pageCurrent = val
      let query = { current: val, size: this.pageSize }
      this.Query(query)
      console.log(`当前页: ${val}`);
    },
    // 新增或者修改按钮
    async modifyBtn(row, type) {
      this.btnType = type
      if (type == 'add') {
        this.dialogTitle = 'Add'
        this.updateObj = { countryCode: [] }
        this.detailAdd = true
        if (this.$refs.updateObj !== undefined) {
          this.$refs.updateObj.resetFields();
        }
      } else {
        this.dialogTitle = 'Edit'
        // 修改数据
        this.updateObj = Object.assign(deepClone(row), { countryCode: row.countryCode.split(',') })
        this.detailAdd = true
        console.log('这一行的数据', JSON.parse(JSON.stringify(row)))
      }
    },

    // 删除数据
    deleteBtn(index, row) {
      console.log('要删除的这一行数据', JSON.parse(JSON.stringify(row)))
      this.$confirm("This operation will permanently delete this data. Do you want to continue?", "Tips", {
        confirmButtonText: "submit",
        cancelButtonText: "cancel",
        type: "warning",
      })
        .then(async () => {
          let { data } = await delObj(row.id)
          if (data.code != 0) return this.$message.error(data.msg)
          this.$message.success(data.msg)
          this.Query()
        })
        .catch(() => {
          // this.$message.info('Destruction cancelled')
        });
    },
    // add/修改数据提交按钮
    updateSub() {
      let newData = deepClone(this.updateObj)
      let params = Object.assign(newData, { countryCode: newData.countryCode.join(',') })
      // let params = Object.assign(newData, { clientCode: this.clientCodeName, countryCode: newData.countryCode.join(',') })
      if (this.btnType == 'add') {
        // 添加数据 addSave
        this.$refs.updateObj.validate(async (valid) => {
          if (!valid) return false
          let { data } = await addSave(params)
          console.log('添加后的数据返回', JSON.parse(JSON.stringify(data)))
          if (data.code != 0) return this.$message.error(data.msg);
          this.$message.success('添加成功');
          this.detailAdd = false
          this.Query()
        });

      } else {
        // 修改数据
        this.$refs.updateObj.validate(async (valid) => {
          if (!valid) return false
          let { data } = await update(params)
          console.log('修改后的数据返回', JSON.parse(JSON.stringify(data)))
          if (data.code != 0) return this.$message.error(data.msg);
          this.$message.success('修改成功');
          this.detailAdd = false
          this.Query()
        });
      }
    },
    // 添加删除弹框的关闭按钮
    cancelClo() {
      this.detailAdd = false
    },

  },
};
</script>
<style lang="scss" scoped>
::v-deep .el-select--small {
  display: block;
}

.dialog-footer-add {
  display: flex;
  justify-content: center;
  color: rgb(64, 149, 229);
  font-size: 25px;
  margin: 20px 0;
}

.dialog-footer-box {
  display: flex;
  justify-content: center;
  margin-top: 50px;
}

.content {
  padding: 0 10px;

  .down {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    border-top: 1px solid #999;
    padding-top: 20px;
    box-sizing: border-box;
  }

  .underLine {
    color: #599af8;
    text-decoration: underline;

    .underIcon {
      background-color: green;
      color: #fff;
      border-radius: 50%;
      margin-right: 5px;
    }
  }
}

.operate-icon-wrap {
  display: flex;
  column-gap: 15px;
}

.operate-icon-box {
  display: flex;
  align-items: center;
  cursor: pointer;
  color: #4095e5;
}

.header-cell-class {
  background-color: #ccc;
}

.foot {
  display: flex;
  justify-content: flex-end;
  margin-top: 20px;
}

.btn-bgc {
  background-color: rgb(31, 99, 255);
  color: #fff;
}

.confrim-bgc {
  background-color: #1376c7;
  color: #fff;
}

.cursor-on {
  cursor: pointer;
}

::v-deep .el-dialog__wrapper .el-dialog {
  border-radius: 8px;
}
</style>