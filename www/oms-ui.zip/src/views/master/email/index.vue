<template>
  <div class="content">
    <el-card class="box-card">
      <el-row style="width: 200px; display: flex">
        <el-col>
          <el-button type="primary" icon="el-icon-search" @click="getSearchlist">Query</el-button>
        </el-col>
        <el-col>
          <el-button icon="el-icon-refresh-left" @click="getReset">Reset</el-button>
        </el-col>
      </el-row>
      <el-form ref="form" :model="form" style="margin: 20px 0" @keyup.enter.native="getSearchlist">
        <el-row :gutter="20">
          <el-col :span="4">
            <el-select v-model="form.warehouseCode" placeholder="Warehouse" filterable clearable>
              <el-option v-for="item in warehouseCode" :key="item.value" :label="item.warehouseName"
                :value="item.warehouseCode">
              </el-option>
            </el-select>
          </el-col>
          <el-col :span="4">
            <el-select v-model="form.countryCode" placeholder="countryCode" filterable clearable>
              <el-option v-for="item in countryCode" :key="item.value" :label="item.label" :value="item.value">
              </el-option>
            </el-select>
          </el-col>
        </el-row>
      </el-form>
      <div class="down">
        <div>
          <el-button type="primary" v-if="permissions.master_emailconfig_add" @click="emailAdd('Add')"
            style="padding: 5px 20px;">
            <span style="display: flex; align-items: center">
              <i class="el-icon-circle-plus-outline" style="margin-right: 10px; font-size: 20px"></i>Add
            </span>
          </el-button>
        </div>
        <div>
          <!-- <el-button icon="el-icon-download" v-if="permissions.stock_skubatch_export" @click="exportExcel"></el-button> -->
        </div>
      </div>
      <el-table border ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%"
        v-loading="dataListLoading" :header-cell-style="{ background: '#f5f7fa', color: '#606266' }">
        <el-table-column label="clientCode" min-width="120px" align="center">
          <template slot-scope="scope">{{ scope.row.clientCode || "-" }}</template>
        </el-table-column>
        <el-table-column label="warehouseCode" min-width="120px" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.warehouseCode || "-" }}</template>
        </el-table-column>
        <el-table-column label="countryCode" min-width="120px" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.countryCode || "-" }}</template>
        </el-table-column>
        <!-- <el-table-column label="zipCode" min-width="120px" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.zipCode || "-" }}</template>
        </el-table-column> -->
        <el-table-column label="ccEmails" min-width="160px" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.ccEmails || "-" }}</template>
        </el-table-column>
        <el-table-column label="createTime" min-width="160px" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.createTime || "-" }}</template>
        </el-table-column>
        <el-table-column label="createBy" align="center">
          <template slot-scope="scope">{{ scope.row.createBy || "-" }}</template>
        </el-table-column>
        <el-table-column label="updateTime" min-width="160px" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.updateTime || "-" }}</template>
        </el-table-column>
        <el-table-column label="updateBy" align="center">
          <template slot-scope="scope">{{ scope.row.updateBy || "-" }}</template>
        </el-table-column>
        <el-table-column label="Opearter" align="center"
          v-if="permissions.master_emailconfig_update || permissions.master_emailconfig_del">
          <template slot-scope="scope">
            <i style="font-size: 18px;cursor: pointer;color:#65BEFF;margin-right:10px" class="el-icon-edit"
              @click="emailAdd('Edit', scope.row)" v-if="permissions.master_emailconfig_update"></i>
            <i style="font-size: 18px;cursor: pointer;color:#65BEFF" class="el-icon-delete"
              @click="emailDelete(scope.row, scope.index)" v-if="permissions.master_emailconfig_del"></i>
          </template>
        </el-table-column>
      </el-table>
      <Pagination @handleSizeChange="handleSizeChange" @handleCurrentChange="handleCurrentChange" :pageNum="page.current"
        :pageSize="page.size" :total="total"></Pagination>
      <el-dialog :title="title" :visible.sync="centerDialogVisible" width="30%" style="font-weight: 700" @close="getClose"
        :close-on-click-modal="title === 'Edit'">
        <el-form :model="formDialog" ref="emailForm" :rules="rules" label-width="120px">
          <el-form-item label="Warehouse:" prop="warehouseCode">
            <el-select :disabled="this.title == 'Edit'" v-model="formDialog.warehouseCode" placeholder="请选择仓库代码"
              filterable clearable>
              <el-option v-for="item in warehouseCode" :key="item.value" :label="item.warehouseName"
                :value="item.warehouseCode">
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="CountryCode:" prop="countryCode">
            <el-select :disabled="this.title == 'Edit'" v-model="formDialog.countryCode" placeholder="请选择国家代码" filterable
              clearable>
              <el-option v-for="item in countryCode" :key="item.value" :label="item.label" :value="item.value">
              </el-option>
            </el-select>
          </el-form-item>
          <!-- <el-form-item label="zipCode:">
            <el-input maxlength="200" v-model="formDialog.zipCode" placeholder='zipCode之间英文","分隔'
              clearable></el-input>
          </el-form-item> -->
          <el-form-item label="ccEmails:" prop="ccEmails">
            <el-input type="textarea" maxlength="200" v-model="formDialog.ccEmails" placeholder='邮件之间英文","分隔'
              clearable></el-input>
          </el-form-item>
        </el-form>
        <span slot="footer" class="dialog-footer">
          <el-button type="info" @click="centerDialogVisible = false">Cancel</el-button>
          <el-button type="primary" @click="dialogButton">Confirm</el-button>
        </span>
      </el-dialog>
    </el-card>
  </div>
</template>
<script>
import Pagination from "@/components/pagination/pagination.vue";
import { mapState, mapGetters } from "vuex";
import { pageQuery, getSave, getUpdate, delEmail } from "@/api/master/email/email";
import { getWarehouse } from "@/api/stock/analysis";
import { remote } from "@/api/admin/dict";

let formParams = {
  warehouseCode: undefined,
  countryCode: undefined,
};
export default {
  name: "ObEmail",
  data() {
    return {
      form: Object.assign({}, formParams),
      total: 0,
      page: {
        size: 10,
        current: 1,
      },
      formDialog: {
        warehouseCode: "",
        countryCode: "",
        ccEmails: "",
      },
      centerDialogVisible: false,
      dataListLoading: false,
      tableData: [],
      warehouseCode: [], //仓库
      countryCode: [], //国家
      title: "",
      rules: {
        warehouseCode: [
          { required: true, message: "请选择仓库代码", trigger: "change" },
        ],
        countryCode: [
          { required: true, message: "请选择国家代码", trigger: "change" },
        ],
        ccEmails: [
          { required: true, message: "请填写email代码", trigger: "blur" },
          { pattern: /^(\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*,)*(\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*)$/, message: '请输入正确的邮件格式且邮件之间请用英文,隔开！', trigger: 'blur' },
        ],
      },
    };
  },
  computed: {
    ...mapGetters(["permissions"]),
    ...mapState({
      clientCode: state => state.common.commandName,
    })
  },
  components: {
    Pagination,
  },
  async created() {
    await this.getWarehouseByClient();
    await this.getList();
  },
  methods: {
    // //导出
    // exportExcel() {
    //   this.downBlobFile("stock/skubatch/export", this.form, "skubatch.xlsx");
    // },
    //条数
    handleSizeChange(val) {
      this.page.current = 1;
      this.page.size = val;
      this.getList(this.form);
    },
    //当前页数
    handleCurrentChange(val) {
      this.page.current = val;
      this.getList(this.form);
    },
    //清空
    getReset() {
      this.form = Object.assign({}, formParams);
      this.getList();
    },
    //查询
    getSearchlist() {
      this.page.current = 1;
      for (let key in this.form) {
        if (this.form[key] === "" || this.form[key] === null) {
          this.form[key] = undefined;
        }
      }
      this.getList(this.form);
    },
    //数据列表
    getList(params) {
      this.dataListLoading = true;
      pageQuery(Object.assign({ ...this.page }, params)).then((res) => {
        console.log(res);
        if (res.data.code === 0) {
          this.tableData = res.data.data.records;
          this.total = res.data.data.total;
          this.dataListLoading = false;
        } else {
          this.$message.error(res.data.msg);
          this.dataListLoading = false;
        }
      }).catch(() => {
        this.$message.error("request was aborted");
        this.dataListLoading = false;
      });
    },
    emailAdd(type, row) {
      this.centerDialogVisible = true;
      this.title = type
      if (type === 'Edit') {
        this.formDialog = Object.assign({}, row)
      } else { }
    },
    //编辑
    dialogButton() {
      this.$refs.emailForm.validate((valid) => {
        if (!valid) return false;
        if (this.title === "Edit") {
          getUpdate({ ...this.formDialog }).then((res) => {
            if (res.data.code === 0) {
              this.$message.success("Edit succeeded");
              this.getList();
              this.centerDialogVisible = false;
            } else {
              this.$message.error(res.data.msg);
              this.centerDialogVisible = false;
            }
          });
        } else {
          getSave({ ...this.formDialog, clientCode: this.clientCode }).then((res) => {
            if (res.data.code === 0) {
              this.$message.success("Add succeeded");
              this.getList();
              this.centerDialogVisible = false;
            } else {
              this.$message.error(res.data.msg);
              this.centerDialogVisible = false;
            }
          })
        }
      });
    },
    //删除
    emailDelete(row, index) {
      this.$confirm('This operation will permanently delete this data. Do you want to continue?', 'Tips', {
        confirmButtonText: 'submit',
        cancelButtonText: 'cancel',
        type: 'warning'
      }).then(() => {
        delEmail(row.id).then(res => {
          if (res.data.code === 0) {
            this.getList();
            this.$message.success("Deleted succeeded");
          } else {
            this.$message.error(res.data.msg)
            this.centerDialogVisible = false;
          }
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: 'Destruction'
        });
      });
    },
    //关闭弹窗
    getClose() {
      // this.formDialog = Object.assign({}, { warehouseCode: "", countryCode: "" , ccEmails:""});
      this.formDialog = this.$options.data().formDialog;
      this.$refs.emailForm.resetFields();
    },
    //warehouseCode下拉数据
    getWarehouseByClient() {
      getWarehouse().then((res) => {
        if (res.data.code === 0) {
          this.warehouseCode = res.data.data;
        }
      });
      remote("country_code").then((res) => {
        if (res.data.code === 0) {
          this.countryCode = res.data.data;
        }
      });
    },
  },
};
</script>
<style lang="scss" scoped>
.content {
  padding: 0 10px;

  // box-sizing: border-box;
  .text {
    font-size: 14px;
  }

  .item {
    padding: 18px 0;
  }

  .box-card {
    width: 100%;
  }

  .down {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    border-top: 1px solid #999;
    padding-top: 20px;
    box-sizing: border-box;
  }

  .underLine {
    color: #599af8;
    text-decoration: underline;
  }

  ::v-deep .el-dialog {
    border-radius: 8px !important;
  }

  ::v-deep .el-select--small {
    display: block;
  }
}
</style>
