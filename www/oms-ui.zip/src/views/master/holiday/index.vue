<template>
  <div class="content">
    <el-tabs type="border-card" v-loading="skuLoading">
      <el-row style="width:200px;display:flex">
        <el-col>
          <el-button type="primary" icon="el-icon-search" @click="clientData()">Query</el-button>
        </el-col>
        <el-col>
          <el-button @click="resetForm('form')" type="info" plain icon="el-icon-refresh-left">Reset</el-button>
        </el-col>
      </el-row>
      <el-form ref="form" :model="form">
        <el-row style="margin-top: 20px" :gutter="20">
          <el-col :span="4">
            <el-form-item prop="holidayDate">
              <!-- <el-input v-model.trim="form.holidayDate" placeholder="Date"></el-input> -->
              <el-date-picker style="width:100%" v-model="form.holidayDate" value-format="yyyy-MM-dd" type="date"
                placeholder="选择日期">
              </el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span="4">
            <el-form-item prop="warehouseCode">
              <el-select filterable clearable v-model="form.warehouseCode" placeholder="Warehouse">
                <el-option v-for="item in warehouseArr" :key="item.warehouseCode" :label="item.warehouseName"
                  :value="item.warehouseCode"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div class="down">
        <!-- Add按钮 -->
        <el-button v-if="permissions.statistics_holiday_add" type="primary" style=" padding: 5px 20px; color: #fff;  "
          @click="modifyBtn('', 'add')">
          <span style="display: flex; align-items: center">
            <i class="el-icon-circle-plus-outline" style="margin-right: 10px; font-size: 20px"></i>Add
          </span>
        </el-button>
        <span v-else></span>
        <div>
          <excel-upload ref="uploadRef" title="holiday upload" url="/statistics/holiday/import"
            temp-name="holiday-import-template.xlsx" temp-url="/admin/sys-file/local/holiday-import-template.xlsx"
            @refreshDataList="skuUploadExcel">
          </excel-upload>
          <!-- 上传 -->
          <el-button v-if="permissions.statistics_holiday_import" icon="el-icon-upload2"
            @click="$refs.uploadRef.show()"></el-button>
          <!-- 下载 -->
          <el-button v-if="permissions.statistics_holiday_export" icon="el-icon-download" @click="exportExcel">
          </el-button>
        </div>
      </div>
      <!-- 数据表 -->
      <el-table tooltip-effect="dark" stripe border ref="multipleTable" :data="tableData.records" style="width: 100%"
        header-cell-class-name="header-cell-class" :header-cell-style="{ background: '#f5f7fa', color: '#606266' }">
        <el-table-column :show-overflow-tooltip="true" label="Owner" min-width="150" align="center">
          <template slot-scope="scope">{{ scope.row.clientCode }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Warehouse" min-width="150" align="center">
          <template slot-scope="scope">{{ scope.row.warehouseCode }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Non-working Day" min-width="150" align="center">
          <template slot-scope="scope">{{ scope.row.holidayDate }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Remark" min-width="150" align="center">
          <template slot-scope="scope">{{ scope.row.holiday }}</template>
        </el-table-column>

        <el-table-column v-if="permissions.statistics_holiday_edit || permissions.statistics_holiday_del"
          :show-overflow-tooltip="true" label="Opearte" min-width="100" align="center">
          <template slot-scope="scope">
            <el-button v-if="permissions.statistics_holiday_edit" type="text" style="font-size:18px;  color: #65BEFF;"
              icon="el-icon-edit" @click="modifyBtn(scope.row, 'modify')">
            </el-button>
            <el-button v-if="permissions.statistics_holiday_del" type="text" style="font-size:18px;  color: #65BEFF;"
              icon="el-icon-delete" @click="deleteBtn(scope.$index, scope.row)">
            </el-button>
          </template>
        </el-table-column>
      </el-table>

      <Pagination @handleSizeChange="handleSizeChange" @handleCurrentChange="handleCurrentChange"
        :pageNum="tableData.current" :pageSize="tableData.size" :total="tableData.total"></Pagination>

      <!-- Add弹框 -->
      <el-dialog :title="dialogTitle" :visible.sync="detailAdd" width="35%" :before-close="cancelClo"
        style="font-weight: 700" :close-on-click-modal='btnType != "add"'>
        <!-- 内容 -->
        <el-form ref="updateObj" :rules="rules" :model="updateObj" label-width="170px">
          <el-row>
            <el-form-item label="Warehouse:" prop="warehouseCode">
              <el-select filterable clearable v-model="updateObj.warehouseCode" placeholder="">
                <el-option v-for="item in warehouseCodeArr" :label="item.warehouseName" :value="item.warehouseCode"
                  :key="item.warehouseCode">
                </el-option>
              </el-select>
            </el-form-item>
          </el-row>
          <el-row>
            <el-form-item label="Non-working Day:" prop="holidayDate">
              <!-- <el-input v-model.trim="updateObj.holidayDate"></el-input> -->
              <el-date-picker style="width:100%" v-model="updateObj.holidayDate" value-format="yyyy-MM-dd" type="date"
                placeholder="选择日期">
              </el-date-picker>
            </el-form-item>
          </el-row>
          <el-row>
            <el-form-item label="Remark:" prop="holiday">
              <el-input v-model.trim="updateObj.holiday"></el-input>
            </el-form-item>
          </el-row>
        </el-form>
        <div class="dialog-footer-box">
          <span slot="footer">
            <el-button @click="cancelClo" style="margin-right: 20px; padding: 10px 40px" type="info">Cancel
            </el-button>
            <el-button type="primary" @click="updateSub" style="padding: 10px 40px">Confirm</el-button>
          </span>
        </div>
      </el-dialog>
    </el-tabs>
  </div>
</template>
<script>
let formParams = {
  holidayDate: '',
  warehouseCode: '',
  clientCode: store.getters.commandName
};
import { mapGetters } from "vuex"
import Pagination from "@/components/pagination/pagination.vue"
import { deepClone } from '@/util/util';
import { remote } from '@/api/admin/dict'
import ExcelUpload from "@/components/upload/excel"
import { btnAntiShake } from '@/util/btnAntiShake'
import store from '@/store'
import { getUrgenttypemapping, addSave, update, delObj, getWarehouseCode } from '@/api/holiday'
import { AddParentWarehouseCodes } from "@/api/quotation"
export default {
  name: "ASN",
  data() {
    return {
      warehouseArr: [],
      warehouseCodeArr: [],
      clientCodeName: '',
      dialogTitle: '',
      isDisCode: false,
      btnType: '',
      skuLoading: false,
      pageSize: '',
      pageCurrent: '1',
      detailAdd: false,
      form: Object.assign({}, formParams),
      options: [
      ],
      // 基本数据
      tableData: [],
      size: 10,
      total: 100,
      //   修改表单
      updateObj: {

      },
      // add表单
      pClientArr: [],
      rules: {
        warehouseCode: [
          { required: true, message: '此区域为必填项', trigger: "change" },
        ],
        holidayDate: [
          { required: true, message: '此区域为必填项', trigger: "change" },
        ],
        holiday: [
          { required: true, message: '此区域为必填项', trigger: "change" },
        ],
      }
    }
  },
  // ============
  created() {
    // 当前的用户
    this.clientCodeName = store.getters.commandName
    this.clientData()

  },
  components: {
    ExcelUpload,
    Pagination
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  mounted() {
    this.exportExcel = btnAntiShake(this.exportExcel, 500)
    this.updateSub = btnAntiShake(this.updateSub, 500)
  },
  methods: {
    // 获取基本数据
    async clientData(query) {
      if (!query) {
        this.pageCurrent = 1
        this.pageSize = 10
        query = { current: this.pageCurrent, size: this.pageSize }
      }
      let queryObj = Object.assign(this.form, query)
      this.skuLoading = true //开启loading
      let { data } = await getUrgenttypemapping(queryObj)

      if (data.code != 0) {
        this.skuLoading = false //关loading
        this.$message.error(data.msg);
        return;
      }
      let { data: warehouse } = await AddParentWarehouseCodes()
      this.warehouseArr = warehouse.data
      this.skuLoading = false //关loading
      this.tableData = deepClone(data.data)
      console.log('页面基本数据', JSON.parse(JSON.stringify(this.tableData)))
    },

    // 用户下拉
    async clientCode() {
      let { data } = await getWarehouseCode()
      this.warehouseCodeArr = data.data
      console.log('下拉数据', data.data);
    },
    // 重置
    resetForm(rule) {
      this.$refs[rule].resetFields();
      this.clientData()
    },
    //导出
    exportExcel() {
      this.skuLoading = true
      this.downBlobFile("/master/holiday/export", this.form, `${this.$store.state.common.commandName}-holiday-${this.toDateFormat(new Date(), true)}.xlsx`, () => this.skuLoading = false);
    },
    // 上传
    skuUploadExcel(response) {
      if (response == 'loading') {
        this.skuLoading = true
        return
      }
      if (!!response && response.code == 0) {
        this.skuLoading = false
      } else {
        this.skuLoading = false
      }
      this.clientData()
    },
    //条数
    handleSizeChange(val) {
      this.pageSize = val
      let query = { current: this.pageCurrent, size: val }
      this.clientData(query)
      console.log(`每页 ${val} 条`);
    },
    //当前页数
    handleCurrentChange(val) {
      this.pageCurrent = val
      let query = { current: val, size: this.pageSize }
      this.clientData(query)
      console.log(`当前页: ${val}`);
    },
    // 新增或者修改按钮
    async modifyBtn(row, type) {
      this.clientCode()
      this.skuLoading = true
      this.btnType = type
      if (type == 'add') {
        this.dialogTitle = 'Add'
        this.isDisCode = false
        this.skuLoading = false
        this.updateObj = {}
        this.detailAdd = true
        if (this.$refs.updateObj !== undefined) {
          this.$refs.updateObj.resetFields();
        }
      } else {
        this.dialogTitle = 'Edit'
        this.isDisCode = true
        // 修改数据
        this.skuLoading = false
        this.updateObj = deepClone(row)
        this.detailAdd = true
        console.log('这一行的数据', this.updateObj)
      }
    },

    // 删除数据
    deleteBtn(index, row) {
      console.log('要删除的这一行数据', JSON.parse(JSON.stringify(row)))
      this.$confirm("This operation will permanently delete this data. Do you want to continue?", "Tips", {
        confirmButtonText: "submit",
        cancelButtonText: "cancel",
        type: "warning",
      })
        .then(async () => {
          let { data } = await delObj(row.id)
          if (data.code != 0) return this.$message.error(data.msg)
          this.$message.success(data.msg)
          this.clientData()
        })
        .catch(() => {
          // this.$message.info('Destruction cancelled')
        });
    },
    // add/修改数据提交按钮
    updateSub() {
      let params = Object.assign(this.updateObj, { clientCode: this.clientCodeName })
      if (this.btnType == 'add') {
        // 添加数据 addSave
        this.$refs.updateObj.validate(async (valid) => {
          if (!valid) return false
          let { data } = await addSave(params)
          console.log('添加后的数据返回', JSON.parse(JSON.stringify(data)))
          if (data.code != 0) return this.$message.error(data.msg);
          this.$message.success(data.msg);
          this.detailAdd = false
          this.clientData()
        });

      } else {
        // 修改数据
        this.$refs.updateObj.validate(async (valid) => {
          if (!valid) return false
          let { data } = await update(this.updateObj)
          console.log('修改后的数据返回', JSON.parse(JSON.stringify(data)))
          if (data.code != 0) return this.$message.error(data.msg);
          this.$message.success(data.msg);
          this.detailAdd = false
          this.clientData()
        });
      }
    },

    // 添加删除弹框的关闭按钮
    cancelClo() {
      this.detailAdd = false
    },
  },
};
</script>
<style lang="scss" scoped>
::v-deep .el-select--small {
  display: block;
}

.dialog-footer-add {
  display: flex;
  justify-content: center;
  color: rgb(64, 149, 229);
  font-size: 25px;
  margin: 20px 0;
}

.dialog-footer-box {
  display: flex;
  justify-content: center;
  margin-top: 100px;
}

.content {
  padding: 0 10px;

  .down {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    border-top: 1px solid #999;
    padding-top: 20px;
    box-sizing: border-box;
  }

  .underLine {
    color: #599af8;
    text-decoration: underline;

    .underIcon {
      background-color: green;
      color: #fff;
      border-radius: 50%;
      margin-right: 5px;
    }
  }
}

.operate-icon-wrap {
  display: flex;
  column-gap: 15px;
}

.operate-icon-box {
  display: flex;
  align-items: center;
  cursor: pointer;
  color: #4095e5;
}

.header-cell-class {
  background-color: #ccc;
}

.foot {
  display: flex;
  justify-content: flex-end;
  margin-top: 20px;
}

.btn-bgc {
  background-color: rgb(31, 99, 255);
  color: #fff;
}

.confrim-bgc {
  background-color: #1376c7;
  color: #fff;
}

.cursor-on {
  cursor: pointer;
}

::v-deep .el-dialog__wrapper .el-dialog {
  border-radius: 8px;
}
</style>