<template>
  <basic-container>
    <div class="avue-crud content">
      <div v-loading="skuLoading">
        <div class="title">
          <span></span>
          <label for="">Base Info</label>
        </div>
        <el-form class="contain" label-width="150px">
          <el-row>
            <el-col :span="8">
              <el-form-item label="Name:">
                <span>{{ rowParams.warehouseName }}</span>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="Code:">
                <span>{{ rowParams.warehouseCode }} <i class="el-icon-document-copy copy"
                    @click='clickCopy("asn_no")'></i></span>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="Parent Warehouse:">
                <span>{{ rowParams.parentWarehouseCode }}</span>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="Children warehouse:">
                <span>{{ rowParams.childWarehouseArr.join() }}</span>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="Total Area(㎡):">
                <span>{{ rowParams.totalArea }}</span>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="Function Area(㎡):">
                <span>{{ rowParams.functionArea }}</span>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
        <div class="title">
          <span></span>
          <label for="">Contacts Info</label>
        </div>
        <el-form class="contain" label-width="150px">
          <el-row>
            <el-col :span="8">
              <el-form-item label="Contacts Name:">
                <span>{{ rowParams.contactName }}</span>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="Contacts Tel:">
                <span>{{ rowParams.contactPhone }}</span>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="Contacts Email:">
                <span>{{ rowParams.contactEmail }}</span>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="Country:">
                <span>{{ rowParams.countryName }}</span>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="City:">
                <span>{{ rowParams.cityName }}</span>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="Zipcode::">
                <span>{{ rowParams.wms }}</span>
              </el-form-item>
            </el-col>
            <!-- <el-col :span="8">
              <el-form-item label="Country Code:">
                <span>{{ rowParams.countryCode }}</span>
              </el-form-item>
            </el-col> -->
          </el-row>
          <el-row>

            <el-col :span="8">
              <el-form-item label="Address:">
                <span>{{ rowParams.address }}</span>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>

        <div class="title">
          <span></span>
          <label for="">Api Info</label>
        </div>
        <el-form class="contain" label-width="150px">
          <el-row>
            <el-col :span="8">
              <el-form-item label="WMS:">
                <span>{{ rowParams.wms }}</span>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>

        <div class="title">
          <span></span>
          <label for="">Storage Info</label>
        </div>
        <div class="contain">
          <!-- Storage -->
          <el-table tooltip-effect="dark" stripe border style="width:fit-content;" :data="rowParams.warehouseStorages
          " :header-cell-style="{ background: '#f5f7fa', color: '#606266' }">
            <el-table-column :show-overflow-tooltip="true" align="center" label="Storage Type" width="150">
              <template slot-scope="scope">
                <span>{{ scope.row.storageType }}</span>
              </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" align="center" label="Qty" width="120">
              <template slot-scope="scope">
                <span>{{ scope.row.qty }}</span>
              </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" align="center" label="Saic Qty" width="120">
              <template slot-scope="scope">
                <span>{{ scope.row.saicQty }}</span>
              </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" align="center" label="NIO Qty" width="120">
              <template slot-scope="scope">
                <span>{{ scope.row.nioQty }}</span>
              </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" align="center" label="GW Qty" width="120">
              <template slot-scope="scope">
                <span>{{ scope.row.gwQty }}</span>
              </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" align="center" label="X-peng Qty" width="120">
              <template slot-scope="scope">
                <span>{{ scope.row.xpengQty }}</span>
              </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" align="center" label="Aiways Qty" width="120">
              <template slot-scope="scope">
                <span>{{ scope.row.aiwaysQty }}</span>
              </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" align="center" label="Lotus Qty" width="120">
              <template slot-scope="scope">
                <span>{{ scope.row.lotusQty }}</span>
              </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" align="center" label="ZEEKR Qty" width="120">
              <template slot-scope="scope">
                <span>{{ scope.row.zeekrQty }}</span>
              </template>
            </el-table-column>
          </el-table>
        </div>

      </div>
    </div>
  </basic-container>
</template>
<script>
import { remote } from '@/api/admin/dict'
import { deepClone } from '@/util/util';
export default {
  name: "dnDetail",
  data() {
    return {
      skuLoading: false,
      rowParams: {},
    };
  },
  created() {
    this.getselectType()
  },
  watch: {

    // 利用watch方法检测路由变化：
    $route: function (to, from) {
      if (to.path == '/WarehouseDetail/index' && to.query.row) {
        if (to.query.row !== from.query.row) {
          this.rowParams = JSON.parse(to.query.row)
          this.getselectType()
        }
      }
    }
  },
  methods: {
    //获取type
    async getselectType() {
      this.skuLoading = true //kai loading
      let newRowParams = JSON.parse(this.$route.query.row);
      this.rowParams = deepClone(newRowParams)
      let childWarehouseArr = []
      this.rowParams.childWarehouseCode.forEach(i => childWarehouseArr.push(i.warehouseCode))
      this.rowParams.childWarehouseArr = this.rowParams.childWarehouseCode.length == 0 ? [] : childWarehouseArr
      console.log("🚀→→→→→ ~ 传过来的这一行数据", this.rowParams)

      // let { data: allWarehouseCodeArr } = await remote('warehouse_type')
      // if (allWarehouseCodeArr.code != 0) {
      //   this.$message.error(allWarehouseCodeArr.msg)
      //   this.skuLoading = false //关loading
      //   return
      // }
      // allWarehouseCodeArr.data.forEach(i => {
      //   if (newRowParams.warehouseType == i.value) {
      //     this.rowParams = { ...newRowParams, warehouseType: i.description }
      //   }
      // })
      this.skuLoading = false //关loading

    },
    //复制
    async clickCopy() {
      let content = this.rowParams.warehouseCode
      if (this.copy(content) === '文本为空') {
        this.$message.error("Text is empty and cannot be copied !!!");
        return
      }
      this.$message.success("copy success");
    },
  },
};
</script>
<style lang="scss" scoped>
/* 去掉中间数据的分割线 */
// ::v-deep .el-table__row>td {
//   border: none;
// }

// /* 去掉上面的线 */
// ::v-deep .el-table th.is-leaf {
//   border: none;
// }

// /* 去掉最下面的那一条线 */
// ::v-deep .el-table::before {
//   height: 0px;
// }

.underLine {
  color: #599af8;
  text-decoration: underline;
}

.content {
  width: 100%;
  //   padding: 20px;
  box-sizing: border-box;

  .title {
    width: 100%;
    height: 30px;
    line-height: 30px;
    display: flex;
    margin-bottom: 10px;

    span {
      width: 3px;
      height: 30px;
      background-color: #000;
      margin-right: 10px;
    }

    label {
      font-weight: 700;
    }
  }

  .containBox {
    border-bottom: 1px solid #999;
    margin-bottom: 10px;
  }

  .contain {
    padding: 10px;
    box-sizing: border-box;

    label {
      display: inline;
      margin-right: 30px;
    }
  }

  .down {
    float: right;
    margin-bottom: 20px;
  }

  .timeline {
    padding: 10px;

    .box {
      background-color: #f4f6f7;
      border-radius: 5px;
      padding: 10px 20px;
      box-sizing: border-box;

      .boxTop {
        font-weight: 700;
        margin-bottom: 10px;

        span {
          margin-left: 10px;
        }
      }

      .boxBottom {
        color: #666;
      }
    }
  }

  .contain-box {
    display: flex;
    column-gap: 20px;
  }

  .eplacement-parts-text {
    width: 100px;
    height: 30px;
    background-color: #000000;
    display: flex;
    justify-content: center;
    align-items: center;
    color: #fff;
    font-size: 12px;
    border-radius: 5px;
  }


  .copy {
    cursor: pointer;
  }
}

::v-deep .el-form-item--small {
  margin-bottom: 0;
}
</style>
