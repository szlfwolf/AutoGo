<template>
  <basic-container>
    <div class="avue-crud content">
      <div v-loading="skuLoading">

        <div class="contain">
          <div class="title">
            <span></span>
            <label for="">Base Info</label>
          </div>
          <el-form ref="rowParams" :rules="rules" :model="rowParams" label-width="150px">
            <el-row>
              <el-col :span="8">
                <el-form-item label="Name:" prop="warehouseName">
                  <el-input v-model.trim="rowParams.warehouseName"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="8">
                <el-form-item label="Code:" prop="warehouseCode">
                  <el-input v-model.trim="rowParams.warehouseCode"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="8">
                <el-form-item label="Parent Warehouse:" prop="parentWarehouseCode">
                  <el-select filterable placeholder="" clearable v-model="rowParams.parentWarehouseCode">
                    <el-option v-for="item in options.codeArr" :key="item" :label="item" :value="item"></el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span="8">
                <el-form-item label="Total Area(㎡):" prop="totalArea">
                  <el-input v-model.number="rowParams.totalArea"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="8">
                <el-form-item label="Function Area(㎡):" prop="functionArea">
                  <el-input v-model.number="rowParams.functionArea"></el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <div class="title">
              <span></span>
              <label for="">Contacts Info</label>
            </div>
            <el-row>
              <el-col :span="8">
                <el-form-item label="Contacts Name:" prop="contactName">
                  <el-input v-model.trim="rowParams.contactName"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="8">
                <el-form-item label="Contacts Tel:" prop="contactPhone">
                  <el-input v-model.trim="rowParams.contactPhone"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="8">
                <el-form-item label="Contacts Email:" prop="contactEmail">
                  <el-input v-model.trim="rowParams.contactEmail"></el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="8">
                <el-form-item label="Country Name:" prop="countryName">
                  <el-input v-model.trim="rowParams.countryName"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="8">
                <el-form-item label="Country Code:" prop="countryCode">
                  <el-select filterable clearable v-model="rowParams.countryCode" placeholder="">
                    <el-option v-for="item in countryCodeArr" :label="item.value" :value="item.value" :key="item.value">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span="8">
                <el-form-item label="Zip Code:" prop="zipCode">
                  <el-input v-model.trim="rowParams.zipCode"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="8">
                <el-form-item label="Address:" prop="address">
                  <el-input v-model.trim="rowParams.address"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="8">
                <el-form-item label="City:" prop="cityName">
                  <el-input v-model.trim="rowParams.cityName"></el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <div class="title">
              <span></span>
              <label for="">Api lnfo</label>
            </div>
            <el-row>
              <el-col :span="8">
                <el-form-item label="WMS:" prop="wms">
                  <el-select filterable placeholder="" clearable v-model="rowParams.wms">
                    <el-option v-for="item in options.wmsArr" :key="item.value" :label="item.label" :value="item.value">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-row>

            <div class="title">
              <span></span>
              <label for="">Storage Info</label>
            </div>
            <div class="contain">
              <el-table tooltip-effect="dark" stripe border style="width:fit-content;" :data="rowParams.warehouseStorages
                            " :header-cell-style="{ background: '#f5f7fa', color: '#606266' }">
                <el-table-column :show-overflow-tooltip="true" align="center" label="Storage Type" width="150">
                  <template slot-scope="scope">
                    <span>{{ scope.row.storageType }}</span>
                  </template>
                </el-table-column>
                <el-table-column align="center" label="Qty" min-width="120">
                  <template slot-scope="scope">
                    <el-form-item :show-message="false" style="margin-bottom: 0;"
                      :prop="'warehouseStorages.' + scope.$index + '.qty'" :rules="rules.qty">
                      <el-input v-model.number="scope.row.qty" class="kit-input"></el-input>
                    </el-form-item>
                  </template>
                </el-table-column>
                <el-table-column align="center" label="Saic Qty" min-width="120">
                  <template slot-scope="scope">
                    <el-form-item :show-message="false" style="margin-bottom: 0;"
                      :prop="'warehouseStorages.' + scope.$index + '.saicQty'" :rules="rules.saicQty">
                      <el-input v-model.number="scope.row.saicQty" class="kit-input"></el-input>
                    </el-form-item>
                  </template>
                </el-table-column>
                <el-table-column align="center" label="NIO Qty" min-width="120">
                  <template slot-scope="scope">
                    <el-form-item :show-message="false" style="margin-bottom: 0;"
                      :prop="'warehouseStorages.' + scope.$index + '.nioQty'" :rules="rules.nioQty">
                      <el-input v-model.number="scope.row.nioQty" class="kit-input"></el-input>
                    </el-form-item>
                  </template>
                </el-table-column>
                <el-table-column align="center" label="GW Qty" min-width="120">
                  <template slot-scope="scope">
                    <el-form-item :show-message="false" style="margin-bottom: 0;"
                      :prop="'warehouseStorages.' + scope.$index + '.gwQty'" :rules="rules.gwQty">
                      <el-input v-model.number="scope.row.gwQty" class="kit-input"></el-input>
                    </el-form-item>
                  </template>
                </el-table-column>
                <el-table-column align="center" label="X-peng Qty" min-width="120">
                  <template slot-scope="scope">
                    <el-form-item :show-message="false" style="margin-bottom: 0;"
                      :prop="'warehouseStorages.' + scope.$index + '.xpengQty'" :rules="rules.xpengQty">
                      <el-input v-model.number="scope.row.xpengQty" class="kit-input"></el-input>
                    </el-form-item>
                  </template>
                </el-table-column>
                <el-table-column align="center" label="Aiways Qty" min-width="120">
                  <template slot-scope="scope">
                    <el-form-item :show-message="false" style="margin-bottom: 0;"
                      :prop="'warehouseStorages.' + scope.$index + '.aiwaysQty'" :rules="rules.aiwaysQty">
                      <el-input v-model.number="scope.row.aiwaysQty" class="kit-input"></el-input>
                    </el-form-item>
                  </template>
                </el-table-column>
                <el-table-column align="center" label="Lotus Qty" min-width="120">
                  <template slot-scope="scope">
                    <el-form-item :show-message="false" style="margin-bottom: 0;"
                      :prop="'warehouseStorages.' + scope.$index + '.lotusQty'" :rules="rules.lotusQty">
                      <el-input v-model.number="scope.row.lotusQty" class="kit-input"></el-input>
                    </el-form-item>
                  </template>
                </el-table-column>
                <el-table-column align="center" label="Zeekr Qty" min-width="120">
                  <template slot-scope="scope">
                    <el-form-item :show-message="false" style="margin-bottom: 0;"
                      :prop="'warehouseStorages.' + scope.$index + '.zeekrQty'" :rules="rules.zeekrQty">
                      <el-input v-model.number="scope.row.zeekrQty" class="kit-input"></el-input>
                    </el-form-item>
                  </template>
                </el-table-column>
                <el-table-column label="Opearte" min-width="80" align="center">
                  <template slot-scope="scope">
                    <el-button type="text" style="font-size:18px;  color: #65BEFF;" icon="el-icon-delete"
                      @click="deleteBtn(scope.$index)">
                    </el-button>
                  </template>
                </el-table-column>
              </el-table>
            </div>
          </el-form>
          <!-- 按钮 -->
          <div class="dialog-footer-box">
            <span slot="footer">
              <el-button @click="cancelClo" style="margin-right: 20px; padding: 10px 40px" type="info">Cancel
              </el-button>
              <el-button type="primary" @click="updateSub" style="padding: 10px 40px">Save</el-button>
            </span>
          </div>
        </div>

      </div>

    </div>
  </basic-container>
</template>
<script>
import { addObj, AddParentWarehouseCodes, ChangeParentWarehouseCodes, updateByWarehouseCode, } from '@/api/warehouse'
import { remote } from '@/api/admin/dict'
import { deepClone } from '@/util/util';
import { btnAntiShake } from '@/util/btnAntiShake';
import { mapGetters } from "vuex"
import { getStorageTypeList } from '@/api/sku'
export default {
  name: "adDetail",
  data() {
    const required = [
      { required: true, message: "此区域为必填项", trigger: "change" },
    ]
    const numPattern = [
      { required: true, message: "此区域为必填项", trigger: "change" },
      { pattern: /^[0-9]*$/, message: '请输入纯数字', trigger: 'change' },
    ]
    return {
      countryCodeArr: [],
      skuLoading: false,
      btnType: '',
      rowParams: {
        warehouseName: null,
        warehouseCode: null,
        parentWarehouseCode: null,
        countryName: null,
        countryCode: null,
        cityName: null,
        address: null,
        zipCode: null,
        contactName: null,
        contactPhone: null,
        contactEmail: null,
        wms: null,
        warehouseType: null,
        totalArea: null,
        functionArea: null,
        warehouseStorages: []
      },
      options: {
        wmsArr: [],
        codeArr: [],
      },
      rules: {
        warehouseName: required,
        warehouseCode: required,
        countryCode: required,
        countryName: required,
        cityName: required,
        address: required,
        zipCode: required,
        contactName: required,
        contactPhone: required,
        contactEmail: [
          { required: true, message: "此区域为必填项", trigger: "change" },
          { pattern: /[^`~!@#$%\^&\*\(\)\+=\|\{\}\':;\',\\\[\]<>\/\?~！@#￥%……&\*（）——+\|\{\}【】‘；：”“’。，、？\s]{1,}@[^`~!@#$%\^&\*\(\)\+=\|\{\}\':;\',\\\[\]\.<>\/\?~！@#￥%……&\*（）——+\|\{\}【】‘；：”“’。，、？\s]{1,}\.[^`~!@#$%\^&\*\(\)\+=\|\{\}\':;\',\\\[\]<>\/\?~！@#￥%……&\*（）——+\|\{\}【】‘；：”“’。，、？\s]{1,}/i, message: '请输入正确邮箱', trigger: 'change' },   //国际邮
        ],
        warehouseType: required,
        wms: required,
        totalArea: [
          { required: true, message: "此区域为必填项", trigger: "change" },
          { pattern: /^\d+(\.\d+)?$/, message: '请输入小数或者整数', trigger: 'change' },
        ],
        functionArea: [
          { required: true, message: "此区域为必填项", trigger: "change" },
          { pattern: /^\d+(\.\d+)?$/, message: '请输入小数或者整数', trigger: 'change' },
        ],
        qty: numPattern,
        saicQty: numPattern,
        nioQty: numPattern,
        gwQty: numPattern,
        xpengQty: numPattern,
        aiwaysQty: numPattern,
        lotusQty: numPattern,
      },
    };
  },
  created() {
    this.btnType = this.$route.query.btnType
    this.getSelect()
    if (this.btnType == 'add') this.storageTypeArr()
    // console.log('这个页面的数据', JSON.parse(JSON.stringify(this.rowParams)))
  },
  computed: {
    ...mapGetters(["permissions", "tagList"]),
  },
  mounted() {
    this.updateSub = btnAntiShake(this.updateSub, 500)
  },
  watch: {
    // 利用watch方法检测路由变化：
    $route: function (to, from) {
      if (to.path == '/skuAddEdit/index' && this.$route.query.row) {
        // 编辑
        if (to.query.row !== from.query.row) {
          this.getSelect()
          this.btnType = this.$route.query.btnType
        } else {
          this.btnType = this.$route.query.btnType
        }
      } else {
        // 添加
        this.btnType = this.$route.query.btnType
        this.$refs.rowParams.resetFields()
        this.rowParams.parentWarehouseCode = null
      }
    }
  },

  methods: {
    // 获取storageType列表
    async storageTypeArr() {
      let { data } = await getStorageTypeList()
      console.log('storageType列表', data);
      data.forEach(i => {
        this.rowParams.warehouseStorages.push({
          storageType: i,
          qty: 0,
          saicQty: 0,
          nioQty: 0,
          gwQty: 0,
          xpengQty: 0,
          aiwaysQty: 0,
          lotusQty: 0,
        })
      });
    },
    // 获取下拉框数据
    async getSelect() {
      // 开弹框
      this.skuLoading = true //kai loading
      let { data: wms } = await remote('wms')
      this.options.wmsArr = wms.data
      // 国家代码
      let { data: country } = await remote('country_code')

      this.countryCodeArr = country.data
      // console.log(country.data);
      // console.log('wms', JSON.parse(JSON.stringify(wms.data)))
      // add
      if (this.btnType == 'add') {
        let { data: warehouse } = await AddParentWarehouseCodes()
        console.log('获取addP warehouse 下拉数据', warehouse.data);
        this.options.codeArr = warehouse.data
      } else if (this.btnType == 'change' && this.$route.query.row !== undefined) {
        let { data: warehouse } = await ChangeParentWarehouseCodes({ warehouseCode: JSON.parse(this.$route.query.row).warehouseCode })
        console.log('获取changeP warehouse 下拉数据', warehouse.data);
        this.options.codeArr = warehouse.data
        this.rowParams = JSON.parse(this.$route.query.row)
        console.log('this.rowParams', JSON.parse(JSON.stringify(this.rowParams)))
        if (this.rowParams.warehouseStorages.length === 0) await this.storageTypeArr()
      }
      // if (this.btnType == 'change' && this.$route.query.row != undefined) {
      // this.rowParams = JSON.parse(this.$route.query.row)
      // }
      this.skuLoading = false //关loading
    },
    // 关闭当前页面
    findTag(value) {
      let tag, key;
      this.tagList.map((item, index) => {
        if (item.value.includes(value)) {
          tag = item;
          key = index;
        }
      });
      return { tag: tag, key: key };
    },
    //清除表单
    cancelClo() {
      this.$refs.rowParams.resetFields()
      this.rowParams.parentWarehouseCode = null
      let { tag, key } = this.findTag(this.$route.fullPath);
      this.$store.commit('DEL_TAG', tag)
      this.$router.push({
        path: `/master/warehouse/index`,
      });
      this.eventBus.$emit('query')
    },
    //新增/修改表单
    updateSub() {
      this.$refs.rowParams.validate(async (valid) => {
        if (!valid) return false;
        // 检查用户分配数量 
        // for (let i of Object.values(this.rowParams.warehouseStorages)) { if (!this.count(i)) return }

        this.rowParams.parentWarehouseCode = !this.rowParams.parentWarehouseCode ? null : this.rowParams.parentWarehouseCode
        if (this.btnType == 'add') {
          console.log('新增数据携带的参数', JSON.parse(JSON.stringify(this.rowParams)))
          let { data } = await addObj(this.rowParams)
          console.log('提交后返回的参数', JSON.parse(JSON.stringify(data)))
          if (data.code == 0) {
            this.$message.success(data.msg)
            // this.eventBus.$emit('updateSub')
            this.getSelect()
            this.cancelClo()
          } else {
            return this.$message.error(data.msg)
          }
        } else {
          console.log('修改数据携带的参数', JSON.parse(JSON.stringify(this.rowParams)))
          let { data } = await updateByWarehouseCode(this.rowParams)
          console.log('提交后返回的参数', JSON.parse(JSON.stringify(data)))
          if (data.code == 0) {
            this.$message.success(data.msg)
            // this.eventBus.$emit('updateSub')
            this.getSelect()
            this.cancelClo()
          } else {
            return this.$message.error(data.msg)
          }
        }
      });

    },
    // 计算每一行用户数量是否等于总数
    // count(row) {
    //   let userNum = row.saicQty + row.nioQty + row.gwQty + row.xpengQty + row.aiwaysQty + row.lotusQty
    //   if (userNum > row.qty || userNum < row.qty) {
    //     this.$message.warning(`${row.storageType}分配给客户的数量之和不等于总数，请检查`)
    //     return false
    //   } else {
    //     return true
    //   }
    // },

    // 删除表格某一项数据
    deleteBtn(index) {
      this.rowParams.warehouseStorages.splice(index, 1)
    },
  },
};
</script>
<style lang="scss" scoped>
.underLine {
  color: #599af8;
  text-decoration: underline;
}

.content {
  width: 100%;
  padding: 20px;
  box-sizing: border-box;

  .title {
    width: 100%;
    height: 30px;
    line-height: 30px;
    display: flex;
    margin-bottom: 10px;

    span {
      width: 3px;
      height: 30px;
      background-color: #000;
      margin-right: 10px;
    }

    label {
      font-weight: 700;
    }
  }

  .containBox {
    border-bottom: 1px solid #999;
    margin-bottom: 10px;
  }

  .contain {
    padding: 10px;
    box-sizing: border-box;

    label {
      display: inline;
      margin-right: 30px;
    }
  }

  .el-col {
    margin-top: 15px !important;
  }

  .down {
    float: right;
    margin-bottom: 20px;
  }

  .timeline {
    padding: 10px;

    .box {
      background-color: #f4f6f7;
      border-radius: 5px;
      padding: 10px 20px;
      box-sizing: border-box;

      .boxTop {
        font-weight: 700;
        margin-bottom: 10px;

        span {
          margin-left: 10px;
        }
      }

      .boxBottom {
        color: #666;
      }
    }
  }

  .contain-box {
    display: flex;
    column-gap: 20px;
  }

  .eplacement-parts-text {
    width: 100px;
    height: 30px;
    background-color: #000000;
    display: flex;
    justify-content: center;
    align-items: center;
    color: #fff;
    font-size: 12px;
    border-radius: 5px;
  }

  .dialog-footer-box {
    display: flex;
    justify-content: center;
    margin-top: 100px;
  }

  .confrim-bgc {
    background-color: #1376c7;
    color: #fff;
  }
}

::v-deep .el-form-item--small {
  margin-bottom: 0;
}

::v-deep .kit-input>.el-input__inner {
  text-align: center;
}

::v-deep .el-table__row .cell .el-form-item__content {
  margin-left: 0 !important;
}
</style>
