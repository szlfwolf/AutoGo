<template>
  <div class="content">
    <el-tabs type="border-card" v-loading="skuLoading">
      <el-row style="width:200px;display:flex">
        <el-col>
          <el-button type="primary" icon="el-icon-search" @click="fetchListData()">Query</el-button>
        </el-col>
        <el-col>
          <el-button @click="resetForm()" type="info" plain icon="el-icon-refresh-left">Reset</el-button>
        </el-col>
      </el-row>
      <el-form ref="form" :model="form">
        <el-row style="margin-top: 20px" :gutter="20">
          <el-col :span="4">
            <el-form-item prop="warehouseName">
              <el-input v-model="form.warehouseName" placeholder="Name"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="4">
            <el-form-item prop="warehouseCode">
              <el-input v-model="form.warehouseCode" placeholder="Code"></el-input>
            </el-form-item>
          </el-col>

          <el-col :span="4">
            <el-form-item prop="countryCode">
              <el-select filterable clearable v-model="form.countryCode" placeholder="Country Code">
                <el-option v-for="item in codeArr" :key="item" :label="item" :value="item">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="4">
            <el-form-item prop="contactName">
              <el-input v-model="form.contactName" placeholder="Contact Name"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="4">
            <el-form-item prop="address">
              <el-input v-model="form.address" placeholder="Address"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div class="down">
        <!--add按钮 -->
        <el-button v-if="permissions.master_warehouse_add" type="primary" style="padding: 5px 20px; color: #fff;
                        " @click="addBtn('', 'add')">
          <span style="display: flex; align-items: center">
            <i class="el-icon-circle-plus-outline" style="margin-right: 10px; font-size: 20px"></i>Add
          </span>
        </el-button>
        <span v-else></span>
        <el-button v-if="permissions.master_warehouse_export" icon="el-icon-download" @click="exportExcel"></el-button>
      </div>
      <!-- 数据表 -->
      <el-table tooltip-effect="dark" stripe border ref="multipleTable" :data="tableData.records" style="width: 100%"
        header-cell-class-name="header-cell-class"
        :header-cell-style="{ background: '#f5f7fa', color: '#606266', 'text-align': 'center' }" row-key="id"
        :tree-props="{ children: 'childWarehouseCode' }" default-expand-all>
        <el-table-column :show-overflow-tooltip="true" label="Code" min-width="180" align="left">
          <template slot-scope="scope"><i class="el-icon-discount"
              style="margin-right:10px;font-weight: 600;color: #001529;"
              :style="scope.row.colorNum ? 'font-weight: 400;' : ''"></i>{{
                          scope.row.warehouseCode
                          }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Name" min-width="150" align="center">
          <template slot-scope="scope">
            <div class="underLine" style="cursor: pointer" @click="handleDetail(scope.$index, scope.row)">
              {{ scope.row.warehouseName }}
            </div>
          </template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Country Code" min-width="120" align="center">
          <template slot-scope="scope">
            {{ scope.row.countryCode }}
          </template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Country Name" min-width="120" align="center">
          <template slot-scope="scope">
            {{ scope.row.countryName }}
          </template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Citry Name" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.cityName }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Address" min-width="170" align="center">
          <template slot-scope="scope">{{ scope.row.address }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Contact Name" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.contactName }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Contact Tel" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.contactPhone }}</template>
        </el-table-column>

        <el-table-column :show-overflow-tooltip="true" label="WMS" align="center">
          <template slot-scope="scope">{{
                      scope.row.wms
                      }}</template>
        </el-table-column>
        <el-table-column v-if="permissions.master_warehouse_edit || permissions.master_warehouse_del" label="Opearte"
          min-width="150" align="center">
          <template slot-scope="scope">
            <el-button v-if="permissions.master_warehouse_edit" type="text" style="font-size:18px;  color: #65BEFF;"
              icon="el-icon-edit" @click="addBtn(scope.row, 'change')">
            </el-button>
            <el-button v-if="permissions.master_warehouse_del" type="text" style="font-size:18px;  color: #65BEFF;"
              icon="el-icon-delete" @click="deleteBtn(scope.$index, scope.row)">
            </el-button>
          </template>
        </el-table-column>
      </el-table>
      <!-- <el-pagination class="foot" background @size-change="handleSizeChange" @current-change="handleCurrentChange"
        :current-page="tableData.current" :page-sizes="[5,10,15,20]" layout="total, sizes, prev, pager, next, jumper"
        :total="tableData.total">
      </el-pagination> -->
      <Pagination @handleSizeChange="handleSizeChange" @handleCurrentChange="handleCurrentChange"
        :pageNum="tableData.current" :pageSize="tableData.size" :total="tableData.total"></Pagination>
    </el-tabs>
  </div>
</template>
<script>
let formParams = {
  countryCode: null,
  contactName: null,
  warehouseName: null,
  warehouseCode: null,
  address: null,
};
import { mapGetters } from "vuex"
import Pagination from "@/components/pagination/pagination.vue"
import { fetchList, removeByWarehouseCode, getCountryCode, } from '@/api/warehouse'
import { deepClone } from '@/util/util';
import { btnAntiShake } from '@/util/btnAntiShake';
export default {
  name: "ASN",
  data() {
    return {
      btnType: '',
      skuLoading: false,
      pageSize: '',
      pageCurrent: '1',
      isPackageInfo: false,
      form: Object.assign({}, formParams),
      codeArr: [],
      // 基本数据
      tableData: [],
      // 回显数据
      tableDataPath: []
    };
  },
  // ===========
  created() {
    this.fetchListData()
    this.eventBus.$on('query', () => this.fetchListData())
  },
  mounted() {
    this.exportExcel = btnAntiShake(this.exportExcel, 500)
  },
  components: {
    Pagination
  },
  computed: {
    ...mapGetters(["permissions"]),
  },

  methods: {
    // 获取基本数据
    async fetchListData(query) {
      if (!query) {
        this.pageCurrent = 1
        this.pageSize = 10
        query = { current: this.pageCurrent, size: this.pageSize }
      }
      let queryObj = Object.assign(this.form, query)
      this.skuLoading = true //开启loading
      let { data } = await fetchList(queryObj)
      if (data.code != 0) {
        this.skuLoading = false //关loading
        this.$message.error(data.msg);
        return;
      }
      let { data: codeArr } = await getCountryCode()

      // console.log(codeArr);
      this.codeArr = codeArr
      this.skuLoading = false //关loading
      this.tableData = deepClone(data.data)
      this.nameFor(this.tableData.records)
      console.log('页面基本数据', JSON.parse(JSON.stringify(this.tableData)))
    },

    // 重置
    resetForm() {
      this.$refs.form.resetFields();
      this.fetchListData()
    },
    //导出
    exportExcel() {
      this.skuLoading = true
      this.downBlobFile("/master/warehouse/export", this.form, `${this.$store.state.common.commandName}-warehouse-${this.toDateFormat(new Date(), true)}.xlsx`, () => this.skuLoading = false);
    },
    //条数
    handleSizeChange(val) {
      this.pageSize = val
      let query = { current: this.pageCurrent, size: val }
      this.fetchListData(query)
      console.log(`每页 ${val} 条`);
    },
    //当前页数
    handleCurrentChange(val) {
      this.pageCurrent = val
      let query = { current: val, size: this.pageSize }
      this.fetchListData(query)
      console.log(`当前页: ${val}`);
    },
    //跳转详情数据也
    handleDetail(index, row) {
      this.$router.push({
        path: `/WarehouseDetail`,
        query: {
          name: row.warehouseName,
          row: JSON.stringify(row),
        },
      });
    },

    // add/修改按钮
    addBtn(row, btnType) {
      this.btnType = btnType
      //新增数据 
      if (btnType == 'add') {
        this.$router.push({
          path: `/skuAddEdit`,
          query: {
            btnType: btnType
          }
        })
      } else {
        // 修改数据
        this.$router.push({
          path: `/skuAddEdit`,
          query: {
            name: row.warehouseName,
            row: JSON.stringify(row),
            btnType: btnType
          }
        })
      }

    },

    // 删除
    deleteBtn(index, row) {
      console.log(index, row);
      this.$confirm("This operation will permanently delete this data. Do you want to continue?", "Tips", {
        confirmButtonText: "submit",
        cancelButtonText: "cancel",
        type: "warning",
      }).then(async () => {
        let { data } = await removeByWarehouseCode({ warehouseCode: row.warehouseCode })
        if (data.code != 0) return this.$message.error(data.msg)
        this.$message.success(data.msg)
        this.fetchListData()
      }).catch(() => {
        // this.$message.info('Destruction cancelled')
      })
    },

    // 循环上色
    nameFor(data) {
      data.forEach((i, v) => {
        if (i.childWarehouseCode && i.childWarehouseCode.length > 0) {
          this.nameFor(i.childWarehouseCode)
          i.childWarehouseCode.forEach(ival => {
            ival.colorNum = true
          })
        }

      })
    },

  },
};
</script>
<style lang="scss" scoped>
::v-deep .el-select--small {
  display: block;
}

// /* 去掉中间数据的分割线 */
// ::v-deep .el-table__row>td {
//   border: none;
// }

// /* 去掉上面的线 */
// ::v-deep .el-table th.is-leaf {
//   border: none;
// }

// /* 去掉最下面的那一条线 */
// ::v-deep .el-table::before {
//   height: 0px;
// }

.dialog-footer-add {
  display: flex;
  justify-content: center;
  color: rgb(64, 149, 229);
  font-size: 25px;
  margin: 20px 0;
}

.dialog-footer-box {
  display: flex;
  justify-content: center;
}

.content {
  padding: 0 10px;

  // box-sizing: border-box;
  .down {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    border-top: 1px solid #999;
    padding-top: 20px;
    box-sizing: border-box;
  }

  .underLine {
    color: #599af8;
    text-decoration: underline;

    .underIcon {
      background-color: green;
      color: #fff;
      border-radius: 50%;
      margin-right: 5px;
    }
  }
}

.operate-icon-wrap {
  display: flex;
  column-gap: 15px;
}

.operate-icon-box {
  display: flex;
  align-items: center;
  cursor: pointer;
  color: #4095e5;
}

.header-cell-class {
  background-color: #ccc;
}

.foot {
  display: flex;
  justify-content: flex-end;
  margin-top: 20px;
}

.btn-bgc {
  background-color: rgb(31, 99, 255);
  color: #fff;
}

.confrim-bgc {
  background-color: #1376c7;
  color: #fff;
}

.cursor-on {
  cursor: pointer;
}

// 将el-table的展开图标替换为其他图标
// 设置展开或者收起时，不发生旋转
// ::v-deep .el-table__expand-icon {
//   -webkit-transform: rotate(0deg);
//   transform: rotate(0deg);
// }

// ::v-deep .el-table__expand-icon .el-icon-arrow-right:before {
//   content: "\e723";
//   font-size: 16px;
// }

// ::v-deep .el-table__expand-icon--expanded .el-icon-arrow-right:before {
//   content: "\e722";
//   font-size: 16px;
// }
</style>
