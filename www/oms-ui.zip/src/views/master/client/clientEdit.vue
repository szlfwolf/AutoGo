<template>
  <basic-container>
    <div class="avue-crud content">
      <div v-loading="skuLoading">
        <div class="contain">
          <div class="title">
            <span></span>
            <label for="">Client Info</label>
          </div>
          <el-form ref="updateObj" :rules="rules" :model="updateObj" label-width="200px">
            <el-row>
              <el-col :span="12">
                <el-form-item label="Name:" prop="clientName" ref="clientName">
                  <el-input v-model.trim="updateObj.clientName"></el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="12">
                <el-form-item label="Code:" prop="clientCode" ref="clientCode">
                  <el-input :disabled="isDisCode" v-model.trim="updateObj.clientCode"></el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="12">
                <el-form-item label="Parent Client:">
                  <el-select filterable placeholder="" clearable v-model="updateObj.parentClientCode">
                    <el-option v-for="item in pClientArr" :key="item" :label="item" :value="item"></el-option>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="12">
                <el-form-item label="Is EU:" prop="isEu" ref="isEu">
                  <el-select filterable placeholder="" clearable v-model="updateObj.isEu">
                    <el-option label="Yes" value="Y"></el-option>
                    <el-option label="No" value="N"></el-option>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="12">
                <el-form-item label="Contact Name:" prop="linkName" ref="linkName">
                  <el-input v-model.trim="updateObj.linkName"></el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="12">
                <el-form-item label="Contact Tel:" prop="linkPhone" ref="linkPhone">
                  <el-input v-model.trim="updateObj.linkPhone"></el-input>
                </el-form-item>
              </el-col>
            </el-row>

            <div class="title" style="margin: 30px 0">
              <span></span>
              <label for="">Settings</label>
            </div>
            <template>
              <el-tabs style="user-select: none" v-model="activeName" @tab-click="handleClick">
                <!-- Base Setting -->
                <el-tab-pane label="Base Setting" name="one">
                  <el-form-item label="ASN Multiple Response :">
                    <el-switch @change="switchChange($event, 'asn')" v-model="btnAsnMultiple" active-color="#13ce66"
                      inactive-color="#949494">
                    </el-switch>
                    <span style="margin-left: 10px">* The customer's interface is required to support
                      multiple response.</span>
                  </el-form-item>
                  <el-form-item label="Split PKG Response :">
                    <el-switch @change="switchChange($event, 'split')" v-model="btnSplitPkg" active-color="#13ce66"
                      inactive-color="#949494">
                    </el-switch>
                    <span style="margin-left: 10px">* Whether to split the pkg information and return it to
                      the customer after merging</span>
                  </el-form-item>
                </el-tab-pane>
                <!-- KPI Setting -->
                <el-tab-pane label="KPI Setting" name="two">
                  <!-- 111 -->
                  <el-row type="flex" justify="center">
                    <el-col class="kpi-title" style="text-align: center" :span="6">Import & Inbound KPI</el-col>
                  </el-row>
                  <el-row type="flex" justify="center">
                    <el-col :span="23">
                      <el-table tooltip-effect="dark" stripe border :data="updateObj.clientSettingInboundVos"
                        :header-cell-style="{
                          background: '#f5f7fa',
                          color: '#606266',
                        }">
                        <el-table-column :show-overflow-tooltip="true" align="center" label="Ship Type" width="180px">
                          <template slot-scope="scope">
                            <span>{{ scope.row.shipTypeName }}</span>
                          </template>
                        </el-table-column>
                        <el-table-column align="center" label="Import KPI Days (Work day)">
                          <template slot-scope="scope">
                            <el-form-item style="margin-bottom: 0" :prop="'clientSettingInboundVos.' +
                              scope.$index +
                              '.importKpiDays'
                              " :rules="rules.importKpiDays" :ref="'clientSettingInboundVos.' +
    scope.$index +
    '.importKpiDays'
    ">
                              <el-input v-model.trim="scope.row.importKpiDays" type="number"
                                @keydown.native="inputKeyDown" min="0" class="kit-input"></el-input>
                            </el-form-item>
                          </template>
                        </el-table-column>
                        <el-table-column align="center" label="Inbound KPI Days (Work day)">
                          <template slot-scope="scope">
                            <el-form-item style="margin-bottom: 0" :prop="'clientSettingInboundVos.' +
                              scope.$index +
                              '.inboundKpiDays'
                              " :ref="'clientSettingInboundVos.' +
    scope.$index +
    '.inboundKpiDays'
    " :rules="rules.inboundKpiDays">
                              <el-input v-model.trim="scope.row.inboundKpiDays" type="number"
                                @keydown.native="inputKeyDown" min="0" class="kit-input"></el-input>
                            </el-form-item>
                          </template>
                        </el-table-column>
                      </el-table>
                    </el-col>
                  </el-row>
                  <!-- 222 -->
                  <el-row type="flex" justify="center">
                    <el-col class="kpi-title" style="text-align: center" :span="6">Packing & Ship-out & Delivery
                      KPI</el-col>
                  </el-row>
                  <el-row type="flex" justify="center">
                    <el-col :span="23">
                      <el-table tooltip-effect="dark" stripe border :data="updateObj.clientSettingOutboundVos"
                        :header-cell-style="{
                          background: '#f5f7fa',
                          color: '#606266',
                        }">
                        <el-table-column align="center" min-width="80px" label="Urgent Type">
                          <template slot-scope="scope">
                            <el-form-item style="margin-bottom: 0" :prop="'clientSettingOutboundVos.' +
                              scope.$index +
                              '.urgentType'
                              " :ref="'clientSettingOutboundVos.' +
    scope.$index +
    '.urgentType'
    " :rules="rules.urgentType">
                              <el-select filterable placeholder="" clearable v-model="scope.row.urgentType">
                                <el-option v-for="item in urgent_level" :key="item.value" :label="item.label"
                                  :value="item.value"></el-option>
                              </el-select>
                            </el-form-item>
                          </template>
                        </el-table-column>
                        <el-table-column align="center" min-width="120px" label="Country Code">
                          <template slot-scope="scope">
                            <el-form-item style="margin-bottom: 0" :prop="'clientSettingOutboundVos.' +
                              scope.$index +
                              '.countryCode'
                              " :ref="'clientSettingOutboundVos.' +
    scope.$index +
    '.countryCode'
    " :rules="rules.countryCode">
                              <el-select filterable multiple collapse-tags @input="
                                labelBtn($event, 'countryCode', scope.$index)
                                " placeholder="" clearable v-model="scope.row.countryCode">
                                <el-option v-for="item in countryCodeArr" :key="item.value" :label="item.label"
                                  :value="item.value"></el-option>
                              </el-select>
                            </el-form-item>
                          </template>
                        </el-table-column>
                        <el-table-column align="center" min-width="120px" label="Package Type">
                          <template slot-scope="scope">
                            <el-form-item style="margin-bottom: 0" :prop="'clientSettingOutboundVos.' +
                              scope.$index +
                              '.packageType'
                              " :ref="'clientSettingOutboundVos.' +
    scope.$index +
    '.packageType'
    " :rules="rules.packageType">
                              <el-select filterable multiple collapse-tags @input="
                                labelBtn($event, 'packageType', scope.$index)
                                " placeholder="" clearable v-model="scope.row.packageType">
                                <el-option v-for="item in packageTypeArr" :key="item.code" :label="item.code"
                                  :value="item.code"></el-option>
                              </el-select>
                            </el-form-item>
                          </template>
                        </el-table-column>
                        <el-table-column align="center" min-width="80px" label="Weight">
                          <template slot-scope="scope">
                            <el-form-item style="margin-bottom: 0" :prop="'clientSettingOutboundVos.' +
                              scope.$index +
                              '.weightStr'
                              " :ref="'clientSettingOutboundVos.' +
    scope.$index +
    '.weightStr'
    " :rules="rules.weightStr">
                              <el-select filterable placeholder="" clearable v-model="scope.row.weightStr" @input="
                                weightChange($event, 'weight', scope.$index)
                                ">
                                <el-option v-for="item in weightAndCutOffTime" :key="item.label" :label="item.label"
                                  :value="[item.character, item.value]"></el-option>
                              </el-select>
                            </el-form-item>
                          </template>
                        </el-table-column>
                        <el-table-column align="center" min-width="100px" label="Cut off time">
                          <template slot-scope="scope">
                            <el-form-item style="margin-bottom: 0" :prop="'clientSettingOutboundVos.' +
                              scope.$index +
                              '.cutStr'
                              " :ref="'clientSettingOutboundVos.' +
    scope.$index +
    '.cutStr'
    " :rules="rules.cutStr">
                              <el-select filterable placeholder="" clearable v-model="scope.row.cutStr" @input="
                                weightChange($event, 'cut', scope.$index)
                                ">
                                <el-option v-for="item in cutofftime" :key="item.label" :label="item.label"
                                  :value="[item.character, item.value]"></el-option>
                              </el-select>
                            </el-form-item>
                          </template>
                        </el-table-column>
                        <el-table-column align="center" min-width="95px" label="Packing KPI Days">
                          <template slot-scope="scope">
                            <el-form-item style="margin-bottom: 0" :prop="'clientSettingOutboundVos.' +
                              scope.$index +
                              '.packingKpiDays'
                              " :ref="'clientSettingOutboundVos.' +
    scope.$index +
    '.packingKpiDays'
    " :rules="rules.packingKpiDays">
                              <el-input v-model.trim="scope.row.packingKpiDays" type="number"
                                @keydown.native="inputKeyDown" min="0" class="kit-input"></el-input>
                            </el-form-item>
                          </template>
                        </el-table-column>
                        <el-table-column align="center" min-width="95px" label="Ship-out KPI Days">
                          <template slot-scope="scope">
                            <el-form-item style="margin-bottom: 0" :prop="'clientSettingOutboundVos.' +
                              scope.$index +
                              '.shipOutKpiDays'
                              " :ref="'clientSettingOutboundVos.' +
    scope.$index +
    '.shipOutKpiDays'
    " :rules="rules.shipOutKpiDays">
                              <el-input v-model.trim="scope.row.shipOutKpiDays" type="number"
                                @keydown.native="inputKeyDown" min="0" class="kit-input"></el-input>
                            </el-form-item>
                          </template>
                        </el-table-column>
                        <el-table-column align="center" min-width="95px" label="Delivery KPI Days">
                          <template slot-scope="scope">
                            <el-form-item style="margin-bottom: 0" :prop="'clientSettingOutboundVos.' +
                              scope.$index +
                              '.deliveryKpiDays'
                              " :ref="'clientSettingOutboundVos.' +
    scope.$index +
    '.deliveryKpiDays'
    " :rules="rules.deliveryKpiDays">
                              <el-input v-model.trim="scope.row.deliveryKpiDays" type="number"
                                @keydown.native="inputKeyDown" min="0" class="kit-input"></el-input>
                            </el-form-item>
                          </template>
                        </el-table-column>
                        <!-- 删除 -->
                        <el-table-column label="Opearte" align="center" min-width="55px">
                          <template slot-scope="scope">
                            <div style="
                                display: flex;
                                align-items: center;
                                justify-content: center;
                              ">
                              <i class="el-icon-delete" @click="kpiDel(scope.$index)" style="
                                  color: #4095e5;
                                  font-size: 20px;
                                  cursor: pointer;
                                "></i>
                            </div>
                          </template>
                        </el-table-column>
                      </el-table>
                      <!-- 添加 -->
                      <div class="dialog-footer-add">
                        <i @click="kpiAdd" class="el-icon-circle-plus-outline cursor-on"></i>
                        <excel-upload ref="uploadRef" title="client outbound upload"
                          url="/master/client/uploadOutBoundByExcel" temp-name="client_outbound_template.xlsx"
                          temp-url="/admin/sys-file/local/client_outbound_template.xlsx"
                          @refreshDataList="skuUploadExcel">
                        </excel-upload>
                        <!-- 上传 -->
                        <el-button v-if="permissions.master_client_upload_outbound" type="text" style="font-size: 28px"
                          icon="el-icon-upload" @click="$refs.uploadRef.show()"></el-button>
                      </div>
                    </el-col>
                  </el-row>
                </el-tab-pane>
                <!-- Counting Plan Setting -->
                <el-tab-pane class="bottom-input" label="Counting Plan Setting" name="three">
                  <el-col :span="12">
                    <el-form-item label="Run Counting Plan Job Date" prop="clientSettingVo.countingPlanCron"
                      :rules="rules.countingPlanCron" ref="clientSettingVo.countingPlanCron">
                      <el-popover placement="top" v-model="cronPopover">
                        <vueCron class="cronBox" @change="onChangeCron" @close="cronPopover = false"></vueCron>
                        <el-input clearable slot="reference" v-model.trim="updateObj.clientSettingVo.countingPlanCron
                          " placeholder="Cron 表达式" size="small">
                        </el-input>
                      </el-popover>
                    </el-form-item>
                    <el-form-item label="Remark" prop="clientSettingVo.remark">
                      <el-input v-model.trim="updateObj.clientSettingVo.remark" placeholder=" ">
                      </el-input>
                    </el-form-item>
                  </el-col>
                </el-tab-pane>

                <el-tab-pane class="bottom-input" label="T&T Msg Setting" name="four">
                  <el-row>
                    <el-col :span="16" :offset="4">
                      <el-form-item label="Node notice Subject:">
                        <el-input v-model="subject"></el-input>
                      </el-form-item>
                    </el-col>

                  </el-row>
                  <el-row :gutter="100">
                    <el-col :span="7" :offset="5">
                      <el-card>
                        <div slot="header">
                          <i class="el-icon-discount" style="font-size: large"><span style="margin-left: 10px">Cargo
                              Owner</span></i>
                        </div>
                        <el-form-item label="Order Received Msg:">
                          <el-switch @change="switchChange($event, 'releasedInstruct')" v-model="releasedInstruct"
                            active-color="#13ce66" inactive-color="#949494">
                          </el-switch>
                        </el-form-item>
                        <el-form-item label="Ready For Dispatch Msg:">
                          <el-switch @change="switchChange($event, 'packageInstruct')" v-model="packageInstruct"
                            active-color="#13ce66" inactive-color="#949494">
                          </el-switch>
                        </el-form-item>
                        <el-form-item label="Order Shipping Out Msg:">
                          <el-switch @change="switchChange($event, 'outboundInstruct')" v-model="outboundInstruct"
                            active-color="#13ce66" inactive-color="#949494">
                          </el-switch>
                        </el-form-item>
                        <el-form-item label="Order Completed Msg:">
                          <el-switch @change="switchChange($event, 'podInstruct')" v-model="podInstruct"
                            active-color="#13ce66" inactive-color="#949494">
                          </el-switch>
                        </el-form-item>
                      </el-card>
                    </el-col>
                    <el-col :span="7">
                      <el-card>
                        <div slot="header">
                          <i class="el-icon-user" style="font-size: larger"><span
                              style="margin-left: 10px">Consumer</span></i>
                        </div>
                        <el-form-item label="Order Received Msg:">
                          <el-switch @change="
                            switchChange($event, 'releasedInstructUser')
                            " v-model="releasedInstructUser" active-color="#13ce66" inactive-color="#949494">
                          </el-switch>
                        </el-form-item>
                        <el-form-item label="Ready For Dispatch Msg:">
                          <el-switch @change="
                            switchChange($event, 'packageInstructUser')
                            " v-model="packageInstructUser" active-color="#13ce66" inactive-color="#949494">
                          </el-switch>
                        </el-form-item>
                        <el-form-item label="Order Shipping Out Msg:">
                          <el-switch @change="
                            switchChange($event, 'outboundInstructUser')
                            " v-model="outboundInstructUser" active-color="#13ce66" inactive-color="#949494">
                          </el-switch>
                        </el-form-item>
                        <el-form-item label="Order Completed Msg:">
                          <el-switch @change="switchChange($event, 'podInstructUser')" v-model="podInstructUser"
                            active-color="#13ce66" inactive-color="#949494">
                          </el-switch>
                        </el-form-item>
                      </el-card>
                    </el-col>
                  </el-row>
                </el-tab-pane>
              </el-tabs>
            </template>
          </el-form>
          <!-- 按钮 -->
          <div class="dialog-footer-box">
            <span slot="footer">
              <el-button @click="cancelClo" style="margin-right: 20px; padding: 10px 40px" type="info">Cancel
              </el-button>
              <el-button type="primary" @click="updateSub" style="padding: 10px 40px">Confirm</el-button>
            </span>
          </div>
        </div>
      </div>
    </div>
  </basic-container>
</template>
<script>
import { deepClone } from "@/util/util";
import { btnAntiShake } from "@/util/btnAntiShake";
import {
  addSave,
  update,
  getAllParentClientCodes,
  changeAllParentClientCodes,
  getWeightAndCutOffTime,
  getUrgent_level,
  getShip_type,
  getCountry_code,
  getPackageType,
} from "@/api/client";
import { mapGetters } from "vuex";
import ExcelUpload from "@/components/upload/excel";
export default {
  name: "adDetail",
  data() {
    const required = [
      { required: true, message: "此区域为必填项", trigger: "change" },
    ];
    const verification = [
      { required: true, message: "此区域为必填项", trigger: "change" },
      {
        validator: function (rule, value, callback) {
          let reg = /^(0|[1-9][0-9]*)$/;
          if (reg.test(value)) {
            callback();
          } else {
            callback(new Error("请正确输入数字"));
          }
        },
        trigger: "change",
      },
    ];

    return {
      countryCodeArr: [],
      packageTypeArr: [],
      btnAsnMultiple: false,
      btnSplitPkg: false,

      packageInstruct: false,

      releasedInstruct: false,

      outboundInstruct: false,

      podInstruct: false,
      packageInstructUser: false,

      releasedInstructUser: false,

      outboundInstructUser: false,

      podInstructUser: false,
      subject: '',

      weightAndCutOffTime: [],
      cutofftime: [],
      urgent_level: [],
      cronPopover: false,
      activeName: "one",
      pClientArr: [],
      isDisCode: false,
      skuLoading: false,
      btnType: "",
      //   修改表单
      updateObj: {
        clientName: "",
        clientCode: "",
        parentClientCode: "",
        isEu: "",
        linkName: "",
        linkPhone: "",
        clientSettingInboundVos: [],
        clientSettingOutboundVos: [],
        clientSettingVo: {
          countingPlanCron: "",
          remark: "",
          isAsnMultiple: false,
          isSplitPkg: false,
        },
      },
      rules: {
        clientName: required,
        clientCode: required,
        isEu: required,
        linkName: required,
        countingPlanCron: required,
        urgentType: required,
        countryCode: required,
        packageType: required,
        weightStr: required,
        cutStr: required,
        linkPhone: required,
        packingKpiDays: verification,
        shipOutKpiDays: verification,
        deliveryKpiDays: verification,
        importKpiDays: verification,
        inboundKpiDays: verification,
      },
    };
  },
  created() {
    this.btnType = this.$route.query.btnType;
    if (this.btnType == "change") {
      let row = JSON.parse(this.$route.query.row);

      row.clientSettingOutboundVos.forEach((i) => {
        i = Object.assign(i, {
          weightStr:
            i.weightCharacter != "ALL"
              ? i.weightCharacter + i.weight + "kg"
              : i.weightCharacter,
          cutStr:
            i.cutOffCharacter != "ALL"
              ? i.cutOffCharacter + i.cutOffTime
              : i.cutOffCharacter,
          countryCode: i.countryCode.split(","),
          packageType: i.packageType.split(","),
        });
      });
      if (!!row.clientSettingVo) {
        this.btnAsnMultiple = row.clientSettingVo.isAsnMultiple == "Y";
        this.btnSplitPkg = row.clientSettingVo.isSplitPkg == "Y";
        this.packageInstruct = row.clientSettingVo.packageInstruct == "Y";
        this.releasedInstruct = row.clientSettingVo.releasedInstruct == "Y";
        this.outboundInstruct = row.clientSettingVo.outboundInstruct == "Y";
        this.podInstruct = row.clientSettingVo.podInstruct == "Y";

        this.packageInstructUser =
          row.clientSettingVo.packageInstructUser == "Y";
        this.releasedInstructUser =
          row.clientSettingVo.releasedInstructUser == "Y";
        this.outboundInstructUser =
          row.clientSettingVo.outboundInstructUser == "Y";
        this.podInstructUser = row.clientSettingVo.podInstructUser == "Y";
        this.subject = row.clientSettingVo.subject;
      } else {
        row.clientSettingVo = {
          countingPlanCron: "",
          remark: "",
        };
        this.btnAsnMultiple = false;
        this.btnSplitPkg = false;
      }
      this.modifyBtn(this.btnType, row);
    } else {
      this.modifyBtn(this.btnType);
    }
  },
  computed: {
    ...mapGetters(["permissions", "tagList"]),
  },
  mounted() {
    this.updateSub = btnAntiShake(this.updateSub, 500);
  },
  components: {
    ExcelUpload,
  },
  watch: {
    // 利用watch方法检测路由变化：
    $route: function (to, from) {
      if (to.path == "/clientEdit/index" && this.$route.query.row) {
        // 编辑
        this.btnType = this.$route.query.btnType;
        if (to.query.row !== from.query.row) {
          let row = JSON.parse(this.$route.query.row);
          row.clientSettingOutboundVos.forEach((i) => {
            i = Object.assign(i, {
              weightStr:
                i.weightCharacter != "ALL"
                  ? i.weightCharacter + i.weight + "kg"
                  : i.weightCharacter,
              cutStr:
                i.cutOffCharacter != "ALL"
                  ? i.cutOffCharacter + i.cutOffTime
                  : i.cutOffCharacter,
              countryCode: i.countryCode.split(","),
              packageType: i.packageType.split(","),
            });
          });
          if (!!row.clientSettingVo) {
            this.btnAsnMultiple = row.clientSettingVo.isAsnMultiple == "Y";
            this.btnSplitPkg = row.clientSettingVo.isSplitPkg == "Y";
          } else {
            row.clientSettingVo = {
              countingPlanCron: "",
              remark: "",
            };
            this.btnAsnMultiple = false;
            this.btnSplitPkg = false;
          }
          this.modifyBtn(this.btnType, row);
        }
      } else {
        // 添加
        this.btnType = this.$route.query.btnType;
        this.$refs.updateObj.resetFields();
        this.modifyBtn(this.btnType);
      }
    },
  },

  methods: {
    findTag(value) {
      let tag, key;
      this.tagList.map((item, index) => {
        if (item.value.includes(value)) {
          tag = item;
          key = index;
        }
      });
      return { tag: tag, key: key };
    },
    //返回并清除表单
    cancelClo() {
      this.$refs.updateObj.resetFields();
      let { tag, key } = this.findTag(this.$route.fullPath);
      this.$store.commit("DEL_TAG", tag);
      this.$router.push({
        path: "/master/client/index",
      });
      this.eventBus.$emit("query");
    },
    // 是新增还是修改
    async modifyBtn(type, row) {
      this.skuLoading = true;
      let { data: weightAndCutOffTime } = await getWeightAndCutOffTime({
        type1: "weight_character_type",
        type2: "weight_type",
      });
      let { data: cutofftime } = await getWeightAndCutOffTime({
        type1: "cutofftime_character_type",
        type2: "cutofftime_type",
      });
      let {
        data: { data: urgent_level },
      } = await getUrgent_level();
      let {
        data: { data: country_code },
      } = await getCountry_code();
      // console.log("🚀→→→→→ ~ country_code", country_code)
      let { data: client_package_type } = await getPackageType();
      client_package_type.push({ code: "ALL" });
      let {
        data: { data: ship_type },
      } = await getShip_type();
      console.log("🚀→→→→→ ~ client_package_type", client_package_type);
      this.countryCodeArr = country_code;
      this.countryCodeArr.push({ value: "ALL", label: "ALL" });
      this.packageTypeArr = client_package_type;
      this.weightAndCutOffTime = weightAndCutOffTime;
      this.cutofftime = cutofftime;
      this.urgent_level = urgent_level;
      if (type == "add") {
        this.btnAsnMultiple = false;
        this.btnSplitPkg = false;
        this.isDisCode = false;
        this.updateObj = {
          clientName: "",
          clientCode: "",
          parentClientCode: "",
          isEu: "",
          linkName: "",
          linkPhone: "",
          clientSettingInboundVos: [],
          clientSettingOutboundVos: [],
          clientSettingVo: {
            countingPlanCron: "",
            remark: "",
            isAsnMultiple: false,
            isSplitPkg: false,
          },
        };
        //  新增数据
        for (const key of ship_type) {
          this.updateObj.clientSettingInboundVos.push({
            shipTypeName: key.label,
            shipType: key.value,
            importKpiDays: "",
            inboundKpiDays: "",
          });
        }
        let { data } = await getAllParentClientCodes();
        if (data.code != 0) {
          this.skuLoading = false;
          this.$message.error(data.msg);
          return;
        }
        this.skuLoading = false;
        this.pClientArr = data.data;
        // console.log('this.updateObj', JSON.parse(JSON.stringify(this.updateObj)))

        if (this.$refs.updateObj !== undefined) {
          this.$refs.updateObj.resetFields();
        }
      } else {
        this.isDisCode = true;
        // 修改数据
        let { data } = await changeAllParentClientCodes({
          clientCode: row.clientCode,
        });
        if (data.code != 0) {
          this.skuLoading = false;
          this.$message.error(data.msg);
          return;
        }
        this.skuLoading = false;
        this.pClientArr = data.data;
        // 进行映射运输名
        let nameMap = deepClone(row);
        nameMap.clientSettingInboundVos.forEach((i) => {
          ship_type.forEach((item) => {
            if (i.shipType == item.value) {
              i.shipTypeName = item.label;
            }
          });
        });
        this.updateObj = nameMap;
        console.log("传过来的数据", JSON.parse(JSON.stringify(row)));
        if (this.updateObj.clientSettingInboundVos.length === 0) {
          //  新增数据
          let {
            data: { data: ship_type },
          } = await getShip_type();
          for (const key of ship_type) {
            this.updateObj.clientSettingInboundVos.push({
              shipTypeName: key.label,
              shipType: key.value,
              importKpiDays: "",
              inboundKpiDays: "",
            });
          }
        }

        // console.log('修改的数据', JSON.parse(JSON.stringify(this.updateObj)))
      }
    },
    // add/修改数据提交按钮
    updateSub() {
      this.$refs.updateObj.validate(async (valid, object) => {
        // 处理携带的数据
        if (!valid) {
          this.$message.warning(
            "Please check whether there is an area not entered"
          );
          let key1 = Object.keys(object);
          let keyIndex = [];
          for (const key in object) {
            keyIndex =
              key1[0] == "clientSettingVo.countingPlanCron" &&
                this.activeName == "two"
                ? [...keyIndex, key1.shift()]
                : key1;
            let dom = this.$refs[keyIndex[0]];
            if (Object.prototype.toString.call(dom) !== "[object Object]") {
              dom = dom[0];
              break; //结束语句并跳出语句，进行下个语句执行
            }
            // 定位代码
            dom.$el.scrollIntoView({
              block: "center",
              behavior: "smooth",
            });
          }
          return false;
        }
        let dataList = this.updateObj;
        dataList.clientSettingVo = Object.assign(dataList.clientSettingVo, {
          isAsnMultiple: this.btnAsnMultiple ? "Y" : "N",
          isSplitPkg: this.btnSplitPkg ? "Y" : "N",
          releasedInstruct: this.releasedInstruct ? "Y" : "N",
          packageInstruct: this.packageInstruct ? "Y" : "N",
          outboundInstruct: this.outboundInstruct ? "Y" : "N",
          podInstruct: this.podInstruct ? "Y" : "N",
          releasedInstructUser: this.releasedInstructUser ? "Y" : "N",
          packageInstructUser: this.packageInstructUser ? "Y" : "N",
          outboundInstructUser: this.outboundInstructUser ? "Y" : "N",
          podInstructUser: this.podInstructUser ? "Y" : "N",
          subject: this.subject,
        });
        let data_list = deepClone(dataList);
        data_list.clientSettingOutboundVos.forEach((i) => {
          i.countryCode = i.countryCode.join();
          i.packageType = i.packageType.join();
        });
        console.log("带的参数", data_list);
        // -----数据处理完毕
        if (this.btnType == "add") {
          // 添加数据 addSave
          let { data } = await addSave(data_list);
          console.log("添加后的数据返回", JSON.parse(JSON.stringify(data)));
          if (data.code != 0) return this.$message.error(data.msg);
          this.$message.success(data.msg);
        } else {
          // 修改数据
          if (!valid) return false;
          let { data } = await update(data_list);
          console.log("修改后的数据返回", JSON.parse(JSON.stringify(data)));
          if (data.code != 0) return this.$message.error(data.msg);
          this.$message.success(data.msg);
        }
        this.cancelClo();
      });
    },
    // tabs标签页
    handleClick(tab, event) {
      // console.log(tab, event);
    },
    // Switch开关
    switchChange(type, btn) {
      if (btn == "asn") {
        this.btnAsnMultiple = type;
      } else if (btn == "split") {
        this.btnSplitPkg = type;
      }

      if (btn == "packageInstruct") {
        this.packageInstruct = type;
      }
      if (btn == "releasedInstruct") {
        this.releasedInstruct = type;
      }
      if (btn == "outboundInstruct") {
        this.outboundInstruct = type;
      }
      if (btn == "podInstruct") {
        this.podInstruct = type;
      }

      if (btn == "packageInstructUser") {
        this.packageInstructUser = type;
      }
      if (btn == "releasedInstructUser") {
        this.releasedInstructUser = type;
      }
      if (btn == "outboundInstructUser") {
        this.outboundInstructUser = type;
      }
      if (btn == "podInstructUser") {
        this.podInstructUser = type;
      }
    },
    // 定时任务
    onChangeCron(v) {
      this.updateObj.clientSettingVo.countingPlanCron = v;
    },
    //  添加
    kpiAdd() {
      this.updateObj.clientSettingOutboundVos.push({
        countryCode: [],
        packageType: [],
      });
    },

    // packageType和countryCode下拉框
    labelBtn(val, btn, index) {
      if (btn == "countryCode") {
        if (val.includes("ALL"))
          this.updateObj.clientSettingOutboundVos[index].countryCode = ["ALL"];
        if (val.length > 1 && val[0] == "ALL") {
          val.shift();
          this.updateObj.clientSettingOutboundVos[index].countryCode = val;
        }
      } else {
        if (val.includes("ALL"))
          this.updateObj.clientSettingOutboundVos[index].packageType = ["ALL"];
        if (val.length > 1 && val[0] == "ALL") {
          val.shift();
          this.updateObj.clientSettingOutboundVos[index].packageType = val;
        }
      }
    },
    // 上传
    skuUploadExcel(response) {
      if (response == "loading") {
        this.skuLoading = true;
        return;
      }
      if (!!response && response.code == 0) {
        this.skuLoading = false;
        let { data } = response;
        data.forEach((i) => {
          i = Object.assign(i, {
            weightStr:
              i.weightCharacter != "ALL"
                ? i.weightCharacter + i.weight + "kg"
                : i.weightCharacter,
            cutStr:
              i.cutOffCharacter != "ALL"
                ? i.cutOffCharacter + i.cutOffTime
                : i.cutOffCharacter,
            countryCode: i.countryCode.split(","),
            packageType: i.packageType.split(","),
          });
        });
        this.updateObj.clientSettingOutboundVos.push(...data);
        console.log("data", JSON.parse(JSON.stringify(data)));
        // console.log('this.', JSON.parse(JSON.stringify(this.updateObj.clientSettingOutboundVos)))
      } else {
        this.skuLoading = false;
      }
    },
    // 删除
    kpiDel(index) {
      this.updateObj.clientSettingOutboundVos.splice(index, 1);
    },
    weightChange(val, type, index) {
      let dataList = this.updateObj;
      if (!!type && type == "weight") {
        dataList.clientSettingOutboundVos[index].weightCharacter = val[0];
        dataList.clientSettingOutboundVos[index].weight = val[1];
      } else {
        dataList.clientSettingOutboundVos[index].cutOffCharacter = val[0];
        dataList.clientSettingOutboundVos[index].cutOffTime = val[1];
      }
      console.log(dataList);
    },

    inputKeyDown(e) {
      let key = e.key;
      if (
        key === "e" ||
        key === "E" ||
        key === "." ||
        key === "-" ||
        key === "+"
      )
        e.returnValue = false;
    },
  },
};
</script>
<style lang="scss" scoped>
.underLine {
  color: #599af8;
  text-decoration: underline;
}

.content {
  width: 100%;
  padding: 20px;
  box-sizing: border-box;

  .title {
    width: 100%;
    height: 30px;
    line-height: 30px;
    display: flex;
    margin-bottom: 10px;

    span {
      width: 3px;
      height: 30px;
      background-color: #000;
      margin-right: 10px;
    }

    label {
      font-weight: 700;
    }
  }

  .containBox {
    border-bottom: 1px solid #999;
    margin-bottom: 10px;
  }

  .contain {
    padding: 10px;
    box-sizing: border-box;

    label {
      display: inline;
      margin-right: 30px;
    }
  }

  .el-col {
    margin-top: 15px !important;
  }

  .down {
    float: right;
    margin-bottom: 20px;
  }

  .timeline {
    padding: 10px;

    .box {
      background-color: #f4f6f7;
      border-radius: 5px;
      padding: 10px 20px;
      box-sizing: border-box;

      .boxTop {
        font-weight: 700;
        margin-bottom: 10px;

        span {
          margin-left: 10px;
        }
      }

      .boxBottom {
        color: #666;
      }
    }
  }

  .contain-box {
    display: flex;
    column-gap: 20px;
  }

  .eplacement-parts-text {
    width: 100px;
    height: 30px;
    background-color: #000000;
    display: flex;
    justify-content: center;
    align-items: center;
    color: #fff;
    font-size: 12px;
    border-radius: 5px;
  }

  .dialog-footer-box {
    display: flex;
    justify-content: center;
    margin-top: 100px;
  }

  .confrim-bgc {
    background-color: #1376c7;
    color: #fff;
  }
}

::v-deep .el-form-item--small {
  margin-bottom: 0;
}

::v-deep .kit-input>.el-input__inner {
  text-align: center;
}

::v-deep .el-table__row .cell .el-form-item__content {
  margin-left: 0 !important;
}

::v-deep .el-tabs__nav-wrap {
  display: flex;
  justify-content: center;
  background-color: #e4e7ed;
}

.cronBox {
  ::v-deep .el-tabs__content {
    max-height: 400px !important;
    overflow: auto !important;
  }
}

.kpi-title {
  font-family: SourceHanSansSC;
  font-weight: 700;
  font-size: 14px;
  color: rgb(16, 16, 16);
}

.dialog-footer-add {
  display: flex;
  justify-content: center;
  align-items: center;
  color: rgb(64, 149, 229);
  font-size: 25px;
  margin: 20px 0;
  gap: 15px;
}

.cursor-on {
  cursor: pointer;
}

::v-deep .el-form-item__error {
  position: absolute !important;
}

.bottom-input ::v-deep .el-form-item--small.el-form-item {
  margin-bottom: 18px;
}
</style>
