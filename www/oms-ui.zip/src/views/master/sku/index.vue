<template>
  <div class="content">
    <el-tabs type="border-card" v-loading="skuLoading">
      <el-row style="width:200px;display:flex">
        <el-col>
          <el-button type="primary" icon="el-icon-search" @click="getSkuData()">Query</el-button>
        </el-col>
        <el-col>
          <el-button @click="resetForm('options')" type="info" plain icon="el-icon-refresh-left">Reset</el-button>
        </el-col>
      </el-row>
      <el-form ref="options" :model="options">
        <el-row style="margin-top: 20px" :gutter="20">
          <el-col :span="4">
            <el-form-item prop="skuNo">
              <el-input v-model="options.skuNo" placeholder="Sku no"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="4">
            <el-form-item prop="halfYearlyType">
              <el-select filterable clearable v-model="options.halfYearlyType" placeholder="Half-yearly A/B/C">
                <el-option v-for="item in yearlyTypeArr" :key="item.value" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="4">
            <el-form-item prop="storageType">
              <el-select filterable clearable v-model="options.storageType" placeholder="Storage Type">
                <el-option v-for="item in storageTypeListArr" :key="item" :label="item" :value="item">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="4">
            <el-form-item prop="carModel">
              <el-select filterable clearable v-model="options.carModel" placeholder="Car Model">
                <el-option v-for="item in newOptions.carModel" :key="item" :label="item" :value="item">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="4">
            <el-form-item prop="category">
              <el-select filterable clearable v-model="options.category" placeholder="Category 1">
                <el-option v-for="item in newOptions.category" :key="item" :label="item" :value="item">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="4">
            <el-button style="margin-left: 20px;float:right" type="primary" @click="about"
              :icon="show ? 'el-icon-arrow-up' : 'el-icon-arrow-down'">
              <label for="">{{ show ? "收起" : "更多" }}</label>
            </el-button>
          </el-col>
        </el-row>

        <el-row v-show="show" :gutter="20">
          <el-col :span="4">
            <el-form-item prop="backUpSkuNo">
              <el-input v-model="options.backUpSkuNo" placeholder="Back - up sku no"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="4">
            <el-form-item prop="isKit">
              <el-select filterable clearable v-model="options.isKit" placeholder="Is kit">
                <el-option label="Yes" value="y"></el-option>
                <el-option label="No" value="n"> </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="4">
            <el-form-item prop="skuName">
              <el-input v-model="options.skuName" placeholder="Sku Name"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="4">
            <el-form-item prop="skuDesc">
              <el-input v-model="options.skuDesc" placeholder="Sku Desc"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="4">
            <el-form-item prop="status">
              <el-select filterable clearable v-model="options.status" placeholder="Status">
                <el-option v-for="item in statusArr" :key="item.value" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>

        <el-row v-show="show" :gutter="20">

          <el-col :span="4">
            <el-form-item prop="hasStorageType">
              <el-select filterable clearable v-model="options.hasStorageType" placeholder="has-storage-type">
                <el-option label="Yes" value="Y"></el-option>
                <el-option label="No" value="N"> </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="4">
            <el-form-item prop="hasStockQty">
              <el-select filterable clearable v-model="options.hasStockQty" placeholder="has-stock-qty">
                <el-option label="Yes" value="Y"></el-option>
                <el-option label="No" value="N"> </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="4">
            <el-form-item prop="hasAvailableQty">
              <el-select filterable clearable v-model="options.hasAvailableQty" placeholder="has-available-qty ">
                <el-option label="Yes" value="Y"></el-option>
                <el-option label="No" value="N"> </el-option>
              </el-select>
            </el-form-item>
          </el-col>

        </el-row>
      </el-form>
      <div class="down">
        <!-- kit按钮 -->
        <el-button v-if="permissions.master_skukitmapping_edit" type="primary" icon="el-icon-box"
          @click="centerDialogVisible = true" :disabled="isKitSelect">Kit
        </el-button>
        <span v-else></span>
        <div style="display: flex;">
          <excel-upload ref="BackUpRef" title="Supercession info upload" url="/master/skupuppet/uploadSkuPuppetByExcel"
            temp-name="supercession-info-template.xlsx" temp-url="/admin/sys-file/local/supercession-info-template.xlsx"
            @refreshDataList="skuUploadExcel">
          </excel-upload>
          <excel-upload ref="PriceInfoRef" title="Price info upload" url="/master/sku/uploadSkuPriceByExcel"
            temp-name="price-info-template.xlsx" temp-url="/admin/sys-file/local/price-info-template.xlsx"
            @refreshDataList="skuUploadExcel">
          </excel-upload>
          <excel-upload ref="PackageInfoRef" title="Package info upload" url="/master/skupackage/uploadSkuPackageByExcel"
            temp-name="package-info-template.xlsx" temp-url="/admin/sys-file/local/package-info-template.xlsx"
            @refreshDataList="skuUploadExcel">
          </excel-upload>
          <excel-upload ref="KitInfo" title="Kit info upload" url=" /master/skukitmapping/uploadSkuKitByExcel"
            temp-name="Kit-info-template.xlsx" temp-url="/admin/sys-file/local/Kit-info-template.xlsx"
            @refreshDataList="skuUploadExcel">
          </excel-upload>
          <excel-upload ref="StorageInfo" title="Storage info upload" url="/master/sku/uploadSkuStorageTypeByExcel"
            temp-name="sku_storagetype_template.xlsx" temp-url="/admin/sys-file/local/sku_storagetype_template.xlsx"
            @refreshDataList="skuUploadExcel">
          </excel-upload>
          <!--  -->
          <excel-upload ref="uploadRef" title="sku upload" url="/master/sku/uploadSkuInfoAndPackageByExcel"
            temp-name="sku-info-package-template.xlsx" temp-url="/admin/sys-file/local/sku-info-package-template.xlsx"
            @refreshDataList="skuUploadExcel">
          </excel-upload>

          <el-button v-if="permissions.master_skupuppet_upload" icon="el-icon-upload2" @click="$refs.BackUpRef.show()">
            Supercession info</el-button>
          <el-button v-if="permissions.master_sku_price_upload" icon="el-icon-upload2"
            @click="$refs.PriceInfoRef.show()">Price info</el-button>
          <el-button v-if="permissions.master_skupackage_upload" icon="el-icon-upload2"
            @click="$refs.PackageInfoRef.show()">Package info</el-button>
          <el-button v-if="permissions.master_skukitmapping_upload" icon="el-icon-upload2"
            @click="$refs.KitInfo.show()">Kit info</el-button>
          <el-button v-if="permissions.master_sku_storagetype_upload" icon="el-icon-upload2"
            @click="$refs.StorageInfo.show()">Storage info</el-button>
          <!-- 上传 -->
          <el-button v-if="permissions.master_sku_info_package_upload" icon="el-icon-upload2"
            @click="$refs.uploadRef.show()"></el-button>
          <el-button v-if="permissions.master_sku_export" icon="el-icon-download" @click="exportExcel"></el-button>
        </div>
      </div>
      <!-- sku表 -->
      <el-table border tooltip-effect="dark" stripe ref="multipleTable" :data="tableData.records" style="width: 100%"
        :header-cell-style="{ background: '#f5f7fa', color: '#606266' }" @selection-change="handleSelectionChange"
        header-cell-class-name="disabledCheck">
        <!-- 单选 -->
        <el-table-column :selectable="selectable" :show-overflow-tooltip="true" type="selection" align="center"
          width="35">
        </el-table-column>

        <el-table-column :show-overflow-tooltip="true" label="Owner" align="center">
          <template slot-scope="scope">{{ scope.row.sku.clientCode }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Sku no" align="center" min-width="120">
          <template slot-scope="scope">
            <el-button type="text" v-if="permissions.master_sku_query_skuId"
              @click="handleDetail(scope.$index, scope.row)">
              {{ scope.row.sku.partNumber }}
            </el-button>
            <span v-else>{{ scope.row.sku.partNumber }}</span>
          </template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Name" min-width="160" align="center">
          <template slot-scope="scope">
            {{ scope.row.sku.nameEn || scope.row.sku.nameCn }}
          </template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Desc" min-width="200" align="center">
          <template slot-scope="scope">{{ scope.row.sku.partDesc }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Car Model" min-width="100" align="center">
          <template slot-scope="scope">{{ scope.row.sku.carModel }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Category 1" min-width="100" align="center">
          <template slot-scope="scope">{{ scope.row.sku.partType1 }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Category 2" min-width="100" align="center">
          <template slot-scope="scope">{{ scope.row.sku.partType2 }}</template>
        </el-table-column>

        <el-table-column :show-overflow-tooltip="true" label="Half-yearly A/B/C" min-width="150" align="center">
          <template slot-scope="scope">{{ scope.row.sku.halfYearlyType }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Storage Type" min-width="100" align="center">
          <template slot-scope="scope">{{ scope.row.sku.storageType }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Capacity" min-width="100" align="center">
          <template slot-scope="scope">{{ scope.row.sku.capacity }}</template>
        </el-table-column>

        <el-table-column :show-overflow-tooltip="true" label="Dangerous" min-width="100" align="center">
          <template slot-scope="scope">{{ scope.row.sku.isDangerous == 0 ? 'N' : 'Y' }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Status " min-width="80" align="center">
          <template slot-scope="scope">{{ scope.row.sku.status }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Replacement Parts" align="center" width="150">
          <template slot-scope="scope">{{ scope.row.backUp }}</template>
        </el-table-column>
        <!-- 包装信息-->
        <!-- <el-table-column v-if="permissions.master_skupackage_edit" :show-overflow-tooltip="true" label="Package"
          align="center">
          <template slot-scope="scope">
            <i class="el-icon-edit" :class="scope.row.sku.btnDisplay ? 'statusOff' : 'statusOn'"
              @click="scope.row.sku.btnDisplay ? '' : isEyes(scope.row)"></i>
          </template>
        </el-table-column> -->

        <!-- 编辑 -->
        <el-table-column
          v-if="permissions.master_sku_edit || permissions.master_skupuppet_edit || permissions.master_skupackage_edit || permissions.sys_BizRecord_get"
          :show-overflow-tooltip="true" label="Opearte" align="center" min-width="270">
          <template class="operate-icon-wrap" slot-scope="scope">
            <div style="display: flex;justify-content: center;">
              <!-- 包装信息 -->
              <div v-if="permissions.master_skupackage_edit" class="operate-icon-box"
                :class="scope.row.sku.btnDisplay ? 'statusOff' : 'statusOn'"
                @click="scope.row.sku.btnDisplay ? '' : isEyes(scope.row)">
                <i class="el-icon-setting"><span style="font-size: 12px;margin-right:10px">Package</span></i>
              </div>
              <!-- Price -->
              <div v-if="permissions.master_sku_edit" class="operate-icon-box"
                :class="scope.row.sku.btnDisplay ? 'statusOff' : 'statusOn'"
                @click="scope.row.sku.btnDisplay ? '' : priceOn(scope.row)">
                <i class="el-icon-edit-outline"></i><span style="font-size: 12px;margin-right:10px">Price</span>
              </div>
              <!-- Supercession -->
              <div v-if="permissions.master_skupuppet_edit" class="operate-icon-box"
                :class="scope.row.sku.btnDisplay ? 'statusOff' : 'statusOn'"
                @click="scope.row.sku.btnDisplay ? '' : backUpOn(scope.row)">
                <i class="el-icon-edit"></i><span style="font-size: 12px;margin-right:10px">Supercession</span>
              </div>
              <!-- 失败日志 -->
              <div v-if="permissions.sys_BizRecord_get" class="operate-icon-box">
                <i style="font-size: 18px;cursor: pointer;color:#65BEFF;margin-right:10px" class="el-icon-info"
                  @click="handleSee(scope.$index, scope.row)"></i>
              </div>
            </div>
          </template>
        </el-table-column>
      </el-table>
      <AllDrawer v-if="AllDrawer" :AllDrawer="AllDrawer" @handleClose="handleClose" :AllDrawerObj="AllDrawerObj"
        @AllDrawerDetail="AllDrawerDetail" :AllDrawerRow="AllDrawerRow"></AllDrawer>
      <!-- 分页 -->
      <Pagination @handleSizeChange="handleSizeChange" @handleCurrentChange="handleCurrentChange"
        :pageNum="tableData.current" :pageSize="tableData.size" :total="tableData.total"></Pagination>
      <!-- kit 弹框 -->
      <el-dialog title="Kit" :visible.sync="centerDialogVisible" :before-close="kitCancel" width="30%"
        style="font-weight: 700;">
        <el-form label-width="70px">
          <el-row type="flex" justify="space-between" style="padding-right: 20px">
            <el-form-item label="Owner:">
              <span>{{ kitData.sku ? kitData.sku.clientCode : '' }}</span>
            </el-form-item>
            <el-form-item label="Sku no:">
              <span>{{ kitData.sku ? kitData.sku.partNumber : '' }}</span>
            </el-form-item>
          </el-row>
        </el-form>

        <el-form ref="kitDataRef" :model="kitData" :rules="rules">
          <el-table border :data="kitData.kitMappings" style="width: 100%; color: #888888" tooltip-effect="dark"
            :header-cell-style="{ background: '#f5f7fa', color: '#606266' }">
            <el-table-column label="Sku" align="center" width="120">
              <template slot-scope="scope">
                <el-form-item style="margin-bottom: 0;" :prop="'kitMappings.' + scope.$index + '.partNumber'"
                  :rules="rules.partNumber">
                  <el-input v-model.trim="scope.row.partNumber" class="kit-input"></el-input>
                </el-form-item>
              </template>
            </el-table-column>
            <el-table-column label="Qty" align="center" width="120">
              <template slot-scope="scope">
                <el-form-item style="margin-bottom: 0;" :prop="'kitMappings.' + scope.$index + '.num'" :rules="rules.num">
                  <el-input v-model.trim="scope.row.num" class="kit-input"></el-input>
                </el-form-item>
              </template>
            </el-table-column>
            <!-- 删除 -->
            <el-table-column label="Opearte" align="center">
              <template slot-scope="scope">
                <i class="el-icon-delete cursor-on" @click="kitDel(scope.$index)"
                  style="color: #4095e5; font-size: 20px"></i>
              </template>
            </el-table-column>
          </el-table>
        </el-form>
        <!-- 添加 -->
        <div class="dialog-footer-add ">
          <i @click="kitAdd" class="el-icon-circle-plus-outline cursor-on"></i>
        </div>
        <div class="dialog-footer-box">
          <span slot="footer">
            <el-button style="padding: 10px 40px; margin-right: 20px" type="info" @click="kitCancel">
              Cancel</el-button>
            <el-button style="padding: 10px 40px;" type="primary" @click="getHandleEditKit">Confrim
            </el-button>
          </span>
        </div>
      </el-dialog>
      <!-- Package 弹框 -->
      <el-dialog title="Package info" :visible.sync="isPackageInfo" :before-close="isPackageInfoOn" width="60%"
        style="font-weight: 700">

        <el-form :model="newRowDataArr" ref="newRowDataArr">
          <el-row type="flex">
            <el-col :span="6">Owner:<span style="margin-left: 20px">{{
                            rowData.sku ? rowData.sku.clientCode : ''
                            }}</span>
            </el-col>
            <el-col :span="6">Sku no:<span style="margin-left: 20px">{{
                            rowData.sku ? rowData.sku.partNumber : ''
                            }}</span>
            </el-col>
          </el-row>
          <el-row style="margin-top: 20px;">

            <el-table border tooltip-effect="dark" stripe style="width: 100%" :data="newRowDataArr.newRowData"
              :header-cell-style="{ background: '#f5f7fa', color: '#606266' }">
              <el-table-column :show-overflow-tooltip="true" prop="Type" align="center" label="Type" width="120">
                <template slot-scope="scope">
                  <span>{{ scope.row.type }}</span>
                </template>
              </el-table-column>
              <!-- ------- -->
              <el-table-column align="center" label="Length(mm)" min-width="120">
                <template slot-scope="scope">
                  <el-form-item :prop="'newRowData.' + scope.$index + '.length'" :rules="rulesFunc(scope.row, 'length')"
                    error="" style="margin-bottom: 0px">
                    <el-input :disabled="scope.$index == '0'" class="package-info-input"
                      v-model.trim="scope.row.length"></el-input>
                  </el-form-item>
                </template>
              </el-table-column>
              <el-table-column prop="Width" align="center" label="Width(mm)" min-width="120">
                <template slot-scope="scope">
                  <el-form-item :prop="'newRowData.' + scope.$index + '.width'" :rules="rulesFunc(scope.row, 'width')"
                    style="margin-bottom: 0px">
                    <el-input :disabled="scope.$index == '0'" class="package-info-input" v-model.trim="scope.row.width">
                    </el-input>
                  </el-form-item>
                </template>
              </el-table-column>
              <el-table-column prop="Height" align="center" label="Height(mm)" min-width="120">
                <template slot-scope="scope">
                  <el-form-item :prop="'newRowData.' + scope.$index + '.height'" :rules="rulesFunc(scope.row, 'height')"
                    style="margin-bottom: 0px">
                    <el-input :disabled="scope.$index == '0'" class="package-info-input"
                      v-model.trim="scope.row.height"></el-input>
                  </el-form-item>
                </template>
              </el-table-column>
              <el-table-column prop="NetWeight" align="center" label="Net Weight(kg)" min-width="120">
                <template slot-scope="scope">
                  <el-form-item :prop="'newRowData.' + scope.$index + '.netWeight'"
                    :rules="rulesFunc(scope.row, 'netWeight')" style="margin-bottom: 0px">
                    <el-input :disabled="scope.$index == '0'" class="package-info-input"
                      v-model.trim="scope.row.netWeight"></el-input>
                  </el-form-item>
                </template>
              </el-table-column>
              <el-table-column prop="GrossWeight" align="center" label="Gross Weight(kg)" min-width="120">
                <template slot-scope="scope">
                  <el-form-item :prop="'newRowData.' + scope.$index + '.grossWeight'"
                    :rules="rulesFunc(scope.row, 'grossWeight')" style="margin-bottom: 0px">
                    <el-input :disabled="scope.$index == '0'" class="package-info-input"
                      v-model.trim="scope.row.grossWeight"></el-input>
                  </el-form-item>
                </template>
              </el-table-column>
              <el-table-column prop="MOQ" align="center" label="MOQ">
                <template slot-scope="scope">
                  <el-form-item :prop="'newRowData.' + scope.$index + '.moq'" :rules="rulesFunc(scope.row, 'moq')"
                    style="margin-bottom: 0px">
                    <el-input :disabled="scope.$index == '0'" class="package-info-input" v-model.trim="scope.row.moq">
                    </el-input>
                  </el-form-item>
                </template>
              </el-table-column>
              <el-table-column prop=" Unit" align="center" min-width="100px" label="Unit">
                <template slot-scope="scope">
                  <el-form-item :prop="'newRowData.' + scope.$index + '.unit'" :rules="rulesFunc(scope.row, 'unit')"
                    style="margin-bottom: 0px">
                    <el-select filterable :disabled="scope.$index == '0'" placeholder="" clearable
                      v-model.trim="scope.row.unit">
                      <el-option value="PCS" label="PCS"></el-option>
                      <el-option value="PCE" label="PCE"></el-option>
                    </el-select>
                  </el-form-item>
                </template>
              </el-table-column>
              <!-- ---------- -->
              <el-table-column prop="Remark1" align="center" label="Remark1" min-width="100">
                <template slot-scope="scope">
                  <el-input :disabled="scope.$index == '0'" class="package-info-input" v-model.trim="scope.row.remark1">
                  </el-input>
                </template>
              </el-table-column>
              <el-table-column prop="Remark2" align="center" label="Remark2" min-width="100">
                <template slot-scope="scope">
                  <el-input :disabled="scope.$index == '0'" class="package-info-input" v-model.trim="scope.row.remark2">
                  </el-input>
                </template>
              </el-table-column>
              <el-table-column prop="Remark3" align="center" label="Remark3" min-width="100">
                <template slot-scope="scope">
                  <el-input :disabled="scope.$index == '0'" class="package-info-input" v-model.trim="scope.row.remark3">
                  </el-input>
                </template>
              </el-table-column>
            </el-table>
          </el-row>
        </el-form>
        <div class="dialog-footer-box">
          <span slot="footer">
            <el-button @click="isPackageInfoOn" style="margin-right: 20px; padding: 10px 40px" type="info">
              Cancel</el-button>
            <el-button style="padding: 10px 40px" type="primary" @click="packageChange">Confrim</el-button>
          </span>
        </div>
      </el-dialog>
      <!-- Price弹框 -->
      <el-dialog title="Price info" :visible.sync="isPrice" width="30%" style="font-weight: 700"
        :before-close="isPriceClo">
        <el-form :model="rowData" ref="rowDataRef" :rules="rules" label-width="130px">
          <el-row type="flex" justify="space-between">
            <el-form-item label="Owner:">
              <span>{{ rowData.clientCode }}</span>
            </el-form-item>
            <el-form-item label="Sku no:">
              <span>{{ rowData.partNumber }}</span>
            </el-form-item>
          </el-row>
          <el-form-item label="Buy Price:" prop="purchasPrice">
            <el-input v-model.trim="rowData.purchasPrice"></el-input>
          </el-form-item>
          <el-form-item label="Sale Price:" prop="sellingPrice">
            <el-input v-model.trim="rowData.sellingPrice"></el-input>
          </el-form-item>
          <el-form-item label="MonetaryUnit:" prop="monetaryUnit">
            <el-select filterable v-model="rowData.monetaryUnit" clearable placeholder="">
              <el-option v-for="item in monetaryUnitArr" :label="item.label" :value="item.value" :key="item.value">
              </el-option>
            </el-select>
          </el-form-item>
        </el-form>
        <div class="dialog-footer-box">
          <span slot="footer">
            <el-button style="padding: 10px 40px; margin-right: 20px" type="info" @click="isPriceClo">
              Cancel
            </el-button>
            <el-button style="padding: 10px 40px" type="primary" @click="priceChange">Confrim</el-button>
          </span>
        </div>
      </el-dialog>
      <!-- Back up弹框 -->
      <el-dialog title="Replacement parts info" :visible.sync="isBackUp" width="30%" style="font-weight: 700">
        <el-form :model="rowData.sku" label-width="80px">
          <el-row type="flex" justify="space-between">
            <el-form-item label="Owner:">
              <span>{{ rowData.sku ? rowData.sku.clientCode : '' }}</span>
            </el-form-item>
            <el-form-item label="Sku no:">
              <span>{{ rowData.sku ? rowData.sku.partNumber : '' }}</span>
            </el-form-item>
          </el-row>
          <el-form-item label="Remark:" prop="backUp">
            <el-input v-model.trim="rowData.backUp" type="textarea" rows="4"></el-input>
          </el-form-item>
          <el-form-item>
            <span style="color: rgb(135, 136, 138);font-size: 12px;font-weight: 400; ">* 多个用英文逗号分割</span>
          </el-form-item>
        </el-form>
        <div class="dialog-footer-box">
          <span slot="footer">
            <el-button style="padding: 10px 40px; margin-right: 20px" type="info" @click="isBackUp = false">
              Cancel
            </el-button>
            <el-button style="padding: 10px 40px" type="primary" @click="backUpChange">Confrim</el-button>
          </span>
        </div>
      </el-dialog>
    </el-tabs>
  </div>
</template>
<script>
import { mapGetters } from "vuex"
import Pagination from "@/components/pagination/pagination.vue"
import { deepClone } from '../../../util/util'
import { fetchList, putObj, getSkuDetailById, getSkuQueryParam, getYearlyType, getStorageTypeList } from '../../../api/sku'
import { putUpdatePuppetBySku } from '../../../api/skupuppet'
import { putBatchEditPackage } from '../../../api/skupackage'
import { batchHandleEditKit } from '../../../api/skukitmapping'
import { remote } from '@/api/admin/dict'
import ExcelUpload from "@/components/upload/excel"
import { btnAntiShake } from '@/util/btnAntiShake'
import AllDrawer from "@/views/outbound/dn/drawer/allDrawer.vue"
import { bizRecordPage } from "@/api/outbound/dn";
export default {
  name: "ASN",
  data() {
    return {
      yearlyTypeArr: [],
      storageTypeListArr: [],
      AllDrawer: false,
      AllDrawerObj: {},
      AllDrawerRow: {},
      packageType: '',
      remoteArr: [],
      isKitSelect: true,
      pageSize: '',
      pageCurrent: '1',
      isBackUp: false,
      isPrice: false,
      isPackageInfo: false,
      // kit add
      kitData: {},
      backupskitData: {},
      // 备份kit
      backupsKitData: {},
      newOptions: {},
      options:
      {
        carModel: '',
        category: '',
        skuNo: "",
        skuName: "",
        skuDesc: "",
        backUpSkuNo: "",
        isKit: '',
        status: '',
        hasStorageType: '',
        hasStockQty: '',
        hasAvailableQty: '',
      },
      statusArr: [],
      monetaryUnitArr: [],
      skuLoading: false,
      show: false, //更多
      // sku    data
      tableData: {
      },
      rowData: {}, //弹框后的数据
      newRowDataArr: {
        newRowData: [],
      },
      rules:
      {
        sellingPrice: [
          // { required: true, trigger: "change" },
          { pattern: /^\d+(\.\d+)?$/, message: '请输入大于等于0的数字', trigger: 'change' },
        ],
        purchasPrice: [
          // { required: true, trigger: "change" },
          { pattern: /^\d+(\.\d+)?$/, message: '请输入大于等于0的数字', trigger: 'change' },
        ],
        partNumber: [
          { required: true, trigger: "change" },
        ],
        monetaryUnit: [
          { required: true, message: '此区域为必填项', trigger: "change" },
        ],
        num: [
          { required: true, trigger: "change" },
          { pattern: /^\d+?$/, trigger: 'change' },
        ],


      },
      multipleSelection: [],
      centerDialogVisible: false,

    };
  },

  // =========
  components: {
    ExcelUpload,
    AllDrawer,
    Pagination
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  created() {
    this.getSkuData()
    this.getSkuQuery()
    this.getRemote()
  },
  mounted() {
    // 按钮防双击
    this.packageChange = btnAntiShake(this.packageChange, 500)
    this.priceChange = btnAntiShake(this.priceChange, 500)
    this.backUpChange = btnAntiShake(this.backUpChange, 500)
    this.getHandleEditKit = btnAntiShake(this.getHandleEditKit, 500)
    this.exportExcel = btnAntiShake(this.exportExcel, 500)
  },
  methods: {
    rulesFunc(rowData, field) {
      let pattern = /^\d+(\.\d+)?$/

      if ((rowData[field])) {
        if (pattern.test(rowData[field])) {
          return [
            { required: false, trigger: "change" },
          ]
        } else {
          if (field == 'unit') {
            return [
              { required: true, trigger: "change" },
            ]
          } else {
            return [
              { required: true, trigger: "change" },
              { pattern: pattern, trigger: 'change' },
            ]
          }
        }
      } else {
        let keyArray = Object.keys(rowData)
        let deleteKeys = [field, 'remark1', 'remark2', 'remark3', 'type']
        deleteKeys.forEach(key => {
          if (keyArray.includes(key)) {
            let index = keyArray.indexOf(key)
            keyArray.splice(index, 1)
          }
        })

        let res = keyArray.some(key => {
          return rowData[key]
        })
        if (res) {
          return [
            { required: true, trigger: "change" },
            { pattern: pattern, trigger: 'change' },
          ]
        } else {
          return [
            { required: false },
          ]
        }
      }
    },
    // 获取下拉框
    async getRemote() {
      let { data } = await remote('package_type')
      let { data: status } = await remote('sku_status')
      let { data: monetaryUnit } = await remote('monetary_unit')
      let { data: yearlyType } = await getYearlyType()
      let { data: storageTypeList } = await getStorageTypeList()

      this.storageTypeListArr = storageTypeList
      this.yearlyTypeArr = yearlyType.data
      this.remoteArr = data.data
      this.statusArr = status.data
      this.monetaryUnitArr = monetaryUnit.data
      // console.log('获取package用来映射', data.data);
      // console.log('status', status.data);
      // console.log('货币单位', monetaryUnit);
      // console.log('yearlyTypeArr', this.yearlyTypeArr);
      // console.log('storageTypeListArr', this.storageTypeListArr);
    },
    // 单选
    handleSelectionChange(selection, row) {
      if (selection.length > 1) {
        let del_row = selection.shift()
        this.$refs.multipleTable.toggleRowSelection(del_row, false) // 用于多选表格，
      }
      // kit按钮是否可以点击
      if (selection.length > 0) {
        this.kitData = deepClone(selection[0])
        this.backupskitData = selection[0]
        this.isKitSelect = false
        console.log('选中的这一行数据', this.kitData, this.isKitSelect)
      } else if (selection.length == 0) {
        this.kitData = {}
        this.backupskitData = {}
        this.isKitSelect = true
        console.log('选中的这一行数据', this.kitData, this.isKitSelect)
      }
    },

    // Sku 查询条件 获取
    async getSkuQuery() {
      let { data } = await getSkuQueryParam()
      if (!data.data) {
        this.skuLoading = false //关loading
        this.$message.error('request was aborted')
        return
      }
      // 查询功能-多条件分页
      this.newOptions.carModel = data.data.carModel
      this.newOptions.category = data.data.category
      console.log('Sku 查询条件 获取', data);
    },
    // 按条件查询sku数据
    // async skuQuery() {
    //   console.log('带的参数', JSON.parse(JSON.stringify(this.options)))
    //   this.getSkuData(this.options)
    // },
    // 这是sku的基本数据
    async getSkuData(query) {
      if (!query) {
        this.pageCurrent = 1
        this.pageSize = 10
        query = { current: this.pageCurrent, size: this.pageSize }
      }
      let queryObj = Object.assign(this.options, query)
      this.skuLoading = true //开启loading
      let { data } = await fetchList(queryObj)
      if (!data.data) {
        this.skuLoading = false //关loading
        this.$message.error(data.msg)
        return
      }
      this.skuLoading = false //关loading
      this.tableData = data.data
      this.tableData.records.forEach(i => {
        if (i.sku.status == 'C') {
          i.sku.btnDisplay = true
          this.selectable(i)
        } else {
          this.selectable(i)
        }
      })
      // this.options.clientCode = data.data.recor
      console.log('sku基本数据', JSON.parse(JSON.stringify(this.tableData)))
    },
    // package 弹框
    isEyes(data) {

      this.rowData = deepClone(data)
      // 用来渲染的数据  this.newRowDataArr.newRowData
      console.log('接口请求过来的', JSON.parse(JSON.stringify(this.remoteArr)))
      console.log('后台返回的数据', JSON.parse(JSON.stringify(this.rowData.packages)))


      // -----
      this.remoteArr.forEach(item => {
        const findIndex = this.rowData.packages.findIndex(i => {
          return i.type === item.value
        })

        if (findIndex === -1) {
          console.log("🚀→→→→→ ~  this.rowData.packages:", this.rowData.packages)

          this.rowData.packages.push({
            type: item.value
          })
        }
      })
      this.newRowDataArr.newRowData = deepClone(this.rowData.packages)

      this.rowData.packages.forEach((val, x) => {
        const each = this.remoteArr.find(item => {
          return item.value === val.type
        })
        this.newRowDataArr.newRowData[x].type = each.label

        console.log("🚀→→→→→ ~ each:", each)

      })

      // // --------
      console.log('点击package 的弹框数据', JSON.parse(JSON.stringify(this.newRowDataArr.newRowData)))
      this.isPackageInfo = true
    },

    getValueFromRemote(label) {
      let result = this.remoteArr.find(item => {
        return item.label === label
      }).value
      return result
    },

    // package 确认修改
    packageChange() {
      // console.log('传的参数', JSON.parse(JSON.stringify(this.newRowDataArr.newRowData)))
      console.log('这一行的数据', JSON.parse(JSON.stringify(this.rowData.packages)))
      this.$refs.newRowDataArr.validate(async (valid) => {
        if (!valid) return false  //有未填的则return

        let dataArr = deepClone(this.newRowDataArr.newRowData)
        let tempList = dataArr.filter(i => {
          let realKeys = Object.keys(i).filter(key => {
            if (key !== 'type' && i[key]) {
              return i
            }
          });

          if (realKeys.length) {
            return i
          }
        })

        tempList.map(item => {
          return Object.assign(item, {
            type: this.getValueFromRemote(item.type),
            clientCode: this.rowData.sku.clientCode,
            partNumber: this.rowData.sku.partNumber
          })
        })
        tempList.splice(0, 1)
        console.log(tempList, ' 修改携带的参数')
        let { data } = await putBatchEditPackage({ skuPackages: tempList })
        if (data.code != 0) {
          this.$message.error(data.msg)
          return
        }
        this.$message.success('Edit succeeded')
        console.log("🚀→→→→→ ~ package 确认按钮", data)
        this.getSkuData()
        // this.isPackageInfo = false
        this.isPackageInfoOn()

      });
    },
    // 关闭kit弹框清空数据
    kitCancel() {
      this.kitData = deepClone(this.backupskitData)
      this.centerDialogVisible = false
    },
    // price  开弹窗
    priceOn(data) {
      this.rowData = deepClone(data.sku)
      console.log(' price  弹框数据', JSON.parse(JSON.stringify(this.rowData)))
      this.isPrice = true
    },
    // price 确认按钮
    priceChange() {
      this.$refs.rowDataRef.validate(async (valid) => {
        if (!valid) return
        console.log('修改价格携带参数', JSON.parse(JSON.stringify(this.rowData)))
        let { data } = await putObj(this.rowData)
        if (data.code != 0) {
          this.$message.error(data.msg)
          return
        }
        this.$message.success('Edit succeeded')
        console.log("🚀→→→→→ ~ price 确认按钮修改价格", data)
        this.getSkuData()
        this.isPriceClo()
      })
    },
    // backUP 开弹窗
    backUpOn(data) {
      this.rowData = deepClone(data)
      console.log('backUP弹框数据', JSON.parse(JSON.stringify(this.rowData)))
      this.isBackUp = true
    },

    // packageinfo 关闭弹框
    isPackageInfoOn() {
      // console.log(this.rowData.packages);
      this.newRowDataArr.newRowData = []
      this.isPackageInfo = false
    },
    // backUP 确认按钮
    async backUpChange() {
      let obj = {
        partNumber: this.rowData.sku.partNumber,
        replacementNumber: this.rowData.backUp,
        clientCode: this.rowData.sku.clientCode
      }
      let { data } = await putUpdatePuppetBySku(obj)
      console.log("🚀→→→→→ ~ backUP 确认按钮", data)
      if (data.code != 0) {
        this.$message.error('Modification failed')
        return
      }
      this.$message.success('Edit succeeded')
      this.getSkuData()
      this.isBackUp = false
    },

    // kit  添加
    kitAdd() {
      this.kitData.kitMappings.push({ partNumber: "", num: "", parentPartNumber: this.kitData.sku.partNumber, unit: this.kitData.sku.unit })
    },
    // kit 删除
    kitDel(index) {
      console.log('删除', index);
      this.$confirm("This operation will permanently delete this data. Do you want to continue?", "Tips", {
        confirmButtonText: "submit",
        cancelButtonText: "cancel",
        type: "warning",
      }).then(() => {
        this.kitData.kitMappings.splice(index, 1)
        this.$message.success('Deletion succeeded, please confirm')
      }).catch(() => {
        this.$message.info('Destruction cancelled')
      })
    },

    // kit提交
    getHandleEditKit() {
      // console.log(this.kitData, 1111111111);
      this.$refs.kitDataRef.validate(async (valid) => {
        if (!valid) return false
        let obj = {
          skuNo: this.kitData.sku.partNumber,
          skuKitMappings: this.kitData.kitMappings
        }
        console.log('提交携带的数据', JSON.parse(JSON.stringify(obj)))
        let { data } = await batchHandleEditKit(obj)
        console.log('kit提交', JSON.parse(JSON.stringify(data)))
        if (data.code !== 0) {
          console.log('请求失败');
          this.$message.error(data.msg)
          return
        }
        this.$message.success('Edit succeeded')
        this.centerDialogVisible = false
        this.getSkuData()
      })
    },
    // 重置
    resetForm(rule) {
      this.$refs[rule].resetFields();
      this.getSkuData()
    },
    isPriceClo(rule) {
      this.isPrice = false
      this.$refs.rowDataRef.resetFields();
    },
    //展开
    about() {
      this.show = !this.show;
    },
    //导出
    exportExcel() {
      this.skuLoading = true
      this.downBlobFile("/master/sku/export", this.options, `${this.$store.state.common.commandName}-sku-${this.toDateFormat(new Date(), true)}.xlsx`, () => this.skuLoading = false);
    },


    // 上传
    skuUploadExcel(response) {
      if (response == 'loading') {
        this.skuLoading = true
        return
      }
      if (!!response && response.code == 0) {
        this.skuLoading = false
      } else {
        this.skuLoading = false
      }
      this.getSkuData()
    },
    //条数
    handleSizeChange(val) {
      this.pageSize = val
      let query = { current: this.pageCurrent, size: val }
      this.getSkuData(query)
      console.log(`每页 ${val} 条`);
    },
    //当前页数
    handleCurrentChange(val) {
      this.pageCurrent = val
      let query = { current: val, size: this.pageSize }
      this.getSkuData(query)
      console.log(`当前页: ${val}`);
    },
    //跳转
    async handleDetail(index, row) {
      // 通过id获取sku详情数据
      let { data } = await getSkuDetailById(row.sku.id)
      if (!data.data) {
        this.$message.error('request was aborted')
        return
      }
      // console.log(data, '通过id获取sku详情数据');
      this.$router.push({
        path: `/skuAsnDetail`,
        query: {
          name: row.sku.partNumber,
          skuDetail: JSON.stringify(data.data),
          // unit:JSON.stringify( this.monetaryUnitArr),
        },
      });
    },
    // 控制表格单选框的禁用
    selectable(row) {
      return !row.sku.btnDisplay
    },
    //查看错误详情
    handleSee(index, row) {
      this.AllDrawerRow = { ...row, current: 1, size: 10 }
      // console.log(row.sku.partNumber, 111111111111);
      bizRecordPage({ type: "SKU", orderNum: row.sku.partNumber, current: row.current || 1, size: row.size || 10, }).then(res => {
        console.log(res);
        if (res.data.code === 0) {
          if (!res.data.data.records.length) {
            this.AllDrawer = false
            this.$message.warning(`单号${row.sku.partNumber}没有错误日志`)
          } else {
            this.AllDrawer = true
            this.AllDrawerObj = res.data.data
          }
        } else {
          this.$message.error(res.data.msg)
        }
      })
    },
    //关闭详情
    handleClose(e) {
      this.AllDrawer = e
    },
    AllDrawerDetail(e) {
      console.log(e.AllDrawerRow,);
      this.handleSee('', e.AllDrawerRow)
    },
  },
};
</script>
<style lang="scss" scoped>
// /* 去掉中间数据的分割线 */
// ::v-deep .el-table__row>td {
//   border: none;
// }

// /* 去掉上面的线 */
// ::v-deep .el-table th.is-leaf {
//   border: none;
// }

// /* 去掉最下面的那一条线 */
// ::v-deep .el-table::before {
//   height: 0px;
// }

.dialog-footer-add {
  display: flex;
  justify-content: center;
  color: rgb(64, 149, 229);
  font-size: 25px;
  margin: 20px 0;
}

.dialog-footer-box {
  display: flex;
  justify-content: center;
  margin-top: 100px;
}

.content {
  padding: 0 10px;

  // box-sizing: border-box;
  .down {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    border-top: 1px solid #999;
    padding-top: 20px;
    box-sizing: border-box;
  }

  .underLine {
    color: #599af8;
    // text-decoration: underline;

    .underIcon {
      background-color: green;
      color: #fff;
      border-radius: 50%;
      margin-right: 5px;
    }
  }
}

.operate-icon-wrap {
  display: flex;
  align-items: center;
  column-gap: 15px;
}

.operate-icon-box {
  display: flex;
  align-items: center;
  justify-content: center;
  // cursor: pointer;
  // color: #65BEFF;
}

.btn-bgc {
  background-color: rgb(31, 99, 255);
  color: #fff;
}

.disabled-btn {
  color: #C0C4CC;
  cursor: not-allowed;
  background-image: none;
  background-color: #FFF;
  border-color: #EBEEF5;
}

.confrim-bgc {
  background-color: #1376c7;
  color: #fff;
}

.cursor-on {
  cursor: pointer;
}

.statusOff {
  cursor: no-drop;
  font-size: 18px;
  color: #9c9c9c;
}

.statusOn {
  cursor: pointer;
  font-size: 18px;
  color: #65BEFF
}

::v-deep .package-info-input>.el-input__inner {
  width: 50px;
  padding: 0;
  text-align: center;
}

// 深度选择器 去掉全选按钮
::v-deep .el-table .disabledCheck .cell .el-checkbox__inner {
  display: none;
}

::v-deep .el-table .disabledCheck .cell::before {
  content: '';
  text-align: center;
}

::v-deep .kit-input>.el-input__inner {
  text-align: center;
}

::v-deep .el-select--small {
  display: block;
}

::v-deep .el-dialog__wrapper .el-dialog {
  border-radius: 8px;
}
</style>
