<template>
  <basic-container>
    <div class="avue-crud content" v-loading="skuLoading">
      <div>
        <div class="title">
          <span></span>
          <label for="">SKU Info</label>
        </div>
        <el-form class="contain" label-width="130px">
          <el-row>
            <el-col :span="6">
              <el-form-item label="Owner:">
                <span>{{ rowParams.clientCode }}</span>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="SKU no:">
                <span>{{ rowParams.partNumber }} <i class="el-icon-document-copy copy"
                    @click='clickCopy("asn_no")'></i></span>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="EN-sku name:">
                <span>{{ rowParams.nameEn }}</span>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="ZH-sku name:">
                <span>{{ rowParams.nameCn }}</span>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="EAN:">
                <span>{{ rowParams.ean }}</span>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="Dangerous:">
                <span>{{ rowParams.isDangerous == 0 ? 'N' : 'Y' }}</span>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="Desc:">
                <span>{{ rowParams.partDesc }}</span>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="6">
              <el-form-item label="Breakable:">
                <span></span>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="Half-yearly A/B/C:">
                <span>{{ rowParams.halfYearlyType }}</span>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="Weekly A/B/C:">
                <span>{{ rowParams.weeklyTypesStr }}</span>
              </el-form-item>
            </el-col>
     

          </el-row>
          <el-row>
            <el-col :span="6">
              <el-form-item label="Buy Price:">
                <span> {{ rowParams.purchasPrice }} {{ rowParams.purchasPrice ? rowParams.monetaryUnit : '' }}</span>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="Sale Price:">
                <span>{{ rowParams.sellingPrice }} {{ rowParams.sellingPrice ? rowParams.monetaryUnit : '' }} </span>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="Unit:">
                <span>{{ rowParams.unit }}</span>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="HSCODE:">
                <span></span>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="Category1:">
                <span>{{ rowParams.partType1 }}</span>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="Category2:">
                <span>{{ rowParams.partType2 }}</span>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="Category3:">
                <span>{{ rowParams.partType3 }}</span>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="Category4:">
                <span>{{ rowParams.partType4 }}</span>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="Storage Type:">
                <span>{{ rowParams.storageType }}</span>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="Capacity:">
                <span>{{ rowParams.capacity }}</span>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="Attr:">
                <span>{{ rowParams.attribute }}</span>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="PackUp:">
                <span>{{ rowParams.packUp }}</span>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <div>
        <div class="title">
          <span></span>
          <label for="">Package Info</label>
        </div>
        <div class="contain">
          <!-- Package Info -->
          <el-table tooltip-effect="dark" stripe border :data="packageData" style="width: 100%"
            :header-cell-style="{ background: '#f5f7fa', color: '#606266' }">
            <el-table-column :show-overflow-tooltip="true" align="center" prop="type" label="Type">
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" align="center" prop="length" label="Length">
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" align="center" prop="width" label="Width">
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" align="center" prop="height" label="Height">
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" align="center" prop="netWeight" label="Net Weight">
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" align="center" prop="grossWeight" label="Gross Weight">
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" align="center" prop="moq" label="MOQ">
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" align="center" prop="remark1" label="Remark1">
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" align="center" prop="remark2" label="Remark2">
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" align="center" prop="remark3" label="Remark3">
            </el-table-column>
          </el-table>
        </div>
      </div>
      <div>
        <div class="title">
          <span></span>
          <label for="">Replacement Parts</label>
        </div>
        <div class="contain">
          <!-- Replacement parts -->
          <div class="contain-box">
            <div class="eplacement-parts-text" v-for="item in replacementParts" :key="item">{{ item }}</div>
          </div>
        </div>
      </div>
      <div class="containBox">
        <div class="title">
          <span></span>
          <label for="">KIT</label>
        </div>
        <div class="contain">
          <!-- kit -->
          <el-table tooltip-effect="dark" stripe border style="width:fit-content;" :data="kitData"
            :header-cell-style="{ background: '#f5f7fa', color: '#606266' }">
            <el-table-column :show-overflow-tooltip="true" align="center" label="SKU" width="150">
              <template slot-scope="scope">
                <span>{{ scope.row.partNumber }}</span>
              </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" align="center" label="Qty" width="120">
              <template slot-scope="scope">{{ scope.row.num }}</template>
            </el-table-column>
          </el-table>
        </div>
      </div>
    </div>
  </basic-container>
</template>
<script>
import { remote } from '@/api/admin/dict'

export default {
  name: "dnDetail",
  data() {
    return {
      skuLoading: false,
      skuInfo: {},//skuInfo数据
      kitData: [
      ],
      packageData: [
      ],
      replacementParts: [],
      form: {
        name: "",
        value: "",
      },
      rowParams: {}, // sku详情数据

    };
  },
  watch: {
    // 利用watch方法检测路由变化：
    $route: function (to, from) {
      if (to.path == '/skuAsnDetail/index' && to.query.skuDetail) {
        if (to.query.skuDetail !== from.query.skuDetail) {
          this.rowParams = JSON.parse(this.$route.query.skuDetail);
          this.packageData = this.rowParams.packageInfo
          this.replacementParts = this.rowParams.replacementParts
          this.kitData = this.rowParams.kitMappings
          this.getRemote()
        }
      }

    }
  },
  created() {
    // sku 详情
    this.rowParams = JSON.parse(this.$route.query.skuDetail)
    // 拼接Weekly
    let weeklyTypesStr = []
    this.rowParams.skuWeeklyTypes.forEach(i => weeklyTypesStr.push(i.warehouseName + ': ' + i.weeklyType))
    this.rowParams.weeklyTypesStr = weeklyTypesStr.join(' ; ')
    console.log('id查询详情', JSON.parse(JSON.stringify(this.rowParams)))
    // Package Info详情
    this.packageData = this.rowParams.packageInfo
    console.log('package info', JSON.parse(JSON.stringify(this.packageData)))
    this.replacementParts = this.rowParams.replacementParts
    this.kitData = this.rowParams.kitMappings
    this.getRemote()
  },
  methods: {
    // 获取package
    async getRemote() {
      this.skuLoading = true //kai loading
      let { data } = await remote('package_type')
      let remoteArr = data.data
      remoteArr.forEach(i => {
        this.packageData.forEach(val => {
          if (i.value == val.type) {
            val.type = i.label
          }
        })
      })
      this.skuLoading = false //关loading
      console.log('获取package用来映射', data.data);
    },
    //复制
    async clickCopy() {
      let content = this.rowParams.partNumber
      if (this.copy(content) === '文本为空') {
        this.$message.error("Text is empty and cannot be copied !!!");
        return
      }
      this.$message.success("copy success");
    },
    // kit中的sku
    handleDetail() {

    },
    //条数
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`);
    },
    //当前页数
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`);
    },
    //dn详情页
    dnDetailClick() {
      this.$router.push({
        path: "/exWarehouse/dnDetail/index",
      });
    },
  },
};
</script>
<style lang="scss" scoped>
// /* 去掉中间数据的分割线 */
// ::v-deep .el-table__row>td {
//   border: none;
// }

// /* 去掉上面的线 */
// ::v-deep .el-table th.is-leaf {
//   border: none;
// }

// /* 去掉最下面的那一条线 */
// ::v-deep .el-table::before {
//   height: 0px;
// }


.underLine {
  color: #599af8;
  text-decoration: underline;
}

.content {
  width: 100%;
  //   padding: 20px;
  box-sizing: border-box;

  .title {
    width: 100%;
    height: 30px;
    line-height: 30px;
    display: flex;
    margin-bottom: 10px;

    span {
      width: 3px;
      height: 30px;
      background-color: #000;
      margin-right: 10px;
    }

    label {
      font-weight: 700;
    }
  }

  .containBox {
    margin-bottom: 10px;
  }

  .contain {
    padding: 10px;
    box-sizing: border-box;

    label {
      display: inline;
      margin-right: 30px;
    }
  }

  .down {
    float: right;
    margin-bottom: 20px;
  }

  .timeline {
    padding: 10px;

    .box {
      background-color: #f4f6f7;
      border-radius: 5px;
      padding: 10px 20px;
      box-sizing: border-box;

      .boxTop {
        font-weight: 700;
        margin-bottom: 10px;

        span {
          margin-left: 10px;
        }
      }

      .boxBottom {
        color: #666;
      }
    }
  }

  .contain-box {
    display: flex;
    column-gap: 20px;
  }

  .eplacement-parts-text {
    width: fit-content;
    height: 30px;
    padding: 0 20px;
    background-color: #000000;
    display: flex;
    justify-content: center;
    align-items: center;
    color: #fff;
    font-size: 12px;
    border-radius: 5px;
  }

  .copy {
    cursor: pointer;
  }
}

::v-deep .el-form-item--small {
  margin-bottom: 0;
}
</style>
