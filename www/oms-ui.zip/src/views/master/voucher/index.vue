<template>
  <div class="content">
    <el-tabs type="border-card" v-loading="skuLoading">
      <el-row style="width:200px;display:flex">
        <el-col>
          <el-button type="primary" icon="el-icon-search" @click="fetchListData()">Query</el-button>
        </el-col>
        <el-col>
          <el-button @click="resetForm()" type="info" plain icon="el-icon-refresh-left">Reset</el-button>
        </el-col>
      </el-row>
      <el-form ref="form" :model="form">
        <el-row style="margin-top: 20px" :gutter="20">
          <el-col :span="4">
            <el-form-item prop="orderNo">
              <el-input v-model="form.orderNo" placeholder="Order No"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="4">
            <el-form-item prop="warehouseCode">
              <el-input v-model="form.warehouseCode" placeholder="WarehouseCode"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="4">
            <el-form-item prop="operateType">
              <el-select filterable clearable v-model="form.operateType" placeholder="Operate Type">
                <el-option v-for="item in operateTypeSelect" :label="item.label" :value="item.value" :key="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="4">
            <el-form-item prop="status">
              <el-select filterable clearable v-model="form.status" placeholder="Status">
                <el-option v-for="item in statusSelect" :label="item.label" :value="item.value" :key="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>

      <!-- 数据表 -->
      <el-table tooltip-effect="dark" stripe border ref="multipleTable" :data="tableData.records" style="width: 100%"
        header-cell-class-name="header-cell-class"
        :header-cell-style="{ background: '#f5f7fa', color: '#606266', 'text-align': 'center' }">
        <el-table-column :show-overflow-tooltip="true" label="WarehouseCode" min-width="150" align="center">
          <template slot-scope="scope">{{ scope.row.warehouseCode }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Order No" min-width="200" align="center">
          <template slot-scope="scope">
            <span class="underLine" style="cursor: pointer" @click="handleDetail(scope.row)">
              {{ scope.row.orderNo }}
            </span>
          </template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Client" min-width="120" align="center">
          <template slot-scope="scope">
            {{ scope.row.clientCode }}
          </template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="SapStockOrder No" min-width="180" align="center">
          <template slot-scope="scope">
            {{ scope.row.sapStockOrderNo }}
          </template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Operate Type" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.operateType }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Send Time" min-width="170" align="center">
          <template slot-scope="scope">{{ scope.row.sendTime }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Status" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.status }}</template>
        </el-table-column>

        <el-table-column :show-overflow-tooltip="true" label="Opearte" min-width="150" align="center">
          <template slot-scope="scope">
            <!-- 重试 -->
            <template v-if="permissions.sku_voucher_send">
              <el-button v-if="scope.row.statusCode === '0' || scope.row.statusCode === '2'" type="text"
                style="font-size:18px;  color: #65BEFF;" icon="el-icon-position" @click="retryBtn(scope.row.id)">
              </el-button>
              <!-- 冲销 -->
              <el-tooltip class="item" effect="dark" content="Write Off " placement="top-end">
                <el-button v-if="scope.row.statusCode === '1' || scope.row.statusCode === '4'" type="text"
                  style="font-size:18px;  color: #65BEFF;" icon="el-icon-refresh-left" @click="writeOffBtn(scope.row.id)">
                </el-button>
              </el-tooltip>
            </template>
            <!-- 失败日志 -->
            <el-button v-if="permissions.sys_BizRecord_get" type="text" style="font-size: 18px;color:#65BEFF;"
              icon="el-icon-info" @click="handleSee(scope.$index, scope.row)"></el-button>
          </template>
        </el-table-column>
      </el-table>
      <!-- 失败日志 -->
      <AllDrawer v-if="AllDrawer" :AllDrawer="AllDrawer" @handleClose="handleClose" :AllDrawerObj="AllDrawerObj"
        @AllDrawerDetail="AllDrawerDetail" :AllDrawerRow="AllDrawerRow"></AllDrawer>
      <!-- 分页 -->
      <Pagination @handleSizeChange="handleSizeChange" @handleCurrentChange="handleCurrentChange"
        :pageNum="tableData.current" :pageSize="tableData.size" :total="tableData.total"></Pagination>
    </el-tabs>
  </div>
</template>
<script>
let formParams = {
  warehouseCode: '',
  operateType: '',
  orderNo: '',
  status: '',
};
import { mapGetters } from "vuex"
import Pagination from "@/components/pagination/pagination.vue"
import { fetchList, skuVoucherWriteOff, skuVoucherCreateResend } from '@/api/voucher'
import { deepClone } from '@/util/util';
import { remote } from '@/api/admin/dict'
import AllDrawer from "@/views/outbound/dn/drawer/allDrawer.vue"
import { bizRecordPage } from "@/api/outbound/dn";
import { btnAntiShake } from '@/util/btnAntiShake';
export default {
  name: "ASN",
  data() {
    return {
      AllDrawer: false,
      AllDrawerObj: {},
      AllDrawerRow: {},
      operateTypeSelect: [],
      statusSelect: [],
      btnType: '',
      skuLoading: false,
      pageSize: '',
      pageCurrent: '1',
      isPackageInfo: false,
      form: Object.assign({}, formParams),
      // codeArr: [],
      // 基本数据
      tableData: [],
    };
  },
  // ===========
  created() {
    this.fetchListData()
    this.querySelect()
  },
  mounted() {
    this.retryBtn = btnAntiShake(this.retryBtn, 500)
    this.writeOffBtn = btnAntiShake(this.writeOffBtn, 500)
    this.handleSee = btnAntiShake(this.handleSee, 500)
  },
  components: {
    Pagination,
    AllDrawer,
  },
  computed: {
    ...mapGetters(["permissions"]),
  },

  methods: {
    // 获取基本数据
    async fetchListData(query) {
      this.skuLoading = true //开启loading
      if (!query) {
        this.pageCurrent = 1
        this.pageSize = 10
        query = { current: this.pageCurrent, size: this.pageSize }
      }
      let queryData = Object.assign(this.form, query)
      let { data } = await fetchList(queryData)
      if (data.code != 0) {
        this.skuLoading = false //关loading
        this.$message.error(data.msg);
        return;
      }
      this.skuLoading = false //关loading
      this.tableData = deepClone(data.data)
      console.log('页面基本数据', JSON.parse(JSON.stringify(this.tableData)))
    },
    // 获取query下拉框  
    // voucher_operate_type
    // voucher_status
    async querySelect() {
      let { data: res } = await remote('voucher_operate_type')
      // console.log("🚀→→→→→ ~ res", res.data)
      this.operateTypeSelect = res.data
      let { data } = await remote('voucher_status')
      data.data.forEach(i => { console.log(i.label + ':' + i.value); })
      this.statusSelect = data.data
    },
    // 重置
    resetForm() {
      this.$refs.form.resetFields();
      this.fetchListData()
    },
    //条数
    handleSizeChange(val) {
      this.pageSize = val
      let query = { current: this.pageCurrent, size: val }
      this.fetchListData(query)
      console.log(`每页 ${val} 条`);
    },
    //当前页数
    handleCurrentChange(val) {
      this.pageCurrent = val
      let query = { current: val, size: this.pageSize }
      this.fetchListData(query)
      console.log(`当前页: ${val}`);
    },
    //跳转详情数据也
    handleDetail(row) {
      this.$router.push({
        path: `/VoucherDetail`,
        query: {
          name: row.orderNo,
          id: row.id,
        }
      });
    },

    //重试
    async retryBtn(id) {
      console.log("🚀→→→→→ ~ 重试",)
      let { data } = await skuVoucherCreateResend(id)
      console.log(data);
      if (data.code == 0) {
        this.$message.success(data.msg)
      } else {
        this.$message.error(data.msg)
      }
      this.fetchListData()

    },
    // 冲销
    writeOffBtn(id) {
      console.log("🚀→→→→→ ~ 冲销",)
      this.$confirm('Confirm whether to write off. Do you want to continue?', 'Tips', {
        confirmButtonText: 'submit',
        cancelButtonText: 'cancel',
        type: 'warning'
      }).then(async () => {
        let { data } = await skuVoucherWriteOff(id)
        console.log(data);
        if (data.code == 0) {
          this.$message.success(data.msg)
        } else {
          this.$message.error(data.msg)
        }
        this.fetchListData()
      }).catch(() => {
        this.$message({
          type: 'info',
          message: 'Destruction'
        });
      });
    },
    //查看错误详情
    handleSee(index, row) {
      this.AllDrawerRow = { ...row, current: 1, size: 10 }
      // console.log(row.sku.partNumber, 111111111111);
      bizRecordPage({ type: "LOTUS_SKU_VOUCHER", orderNum: row.orderNo, current: row.current || 1, size: row.size || 10, }).then(res => {
        console.log(res);
        if (res.data.code === 0) {
          if (!res.data.data.records.length) {
            this.AllDrawer = false
            this.$message.warning(`单号${row.orderNo}没有错误日志`)
          } else {
            this.AllDrawer = true
            this.AllDrawerObj = res.data.data
          }
        } else {
          this.$message.error(res.data.msg)
        }
      })
    },
    //关闭详情
    handleClose(e) {
      this.AllDrawer = e
    },
    AllDrawerDetail(e) {
      console.log(e.AllDrawerRow,);
      this.handleSee('', e.AllDrawerRow)
    },
  },
}
</script>
<style lang="scss" scoped>
::v-deep .el-select--small {
  display: block;
}

.dialog-footer-add {
  display: flex;
  justify-content: center;
  color: rgb(64, 149, 229);
  font-size: 25px;
  margin: 20px 0;
}

.dialog-footer-box {
  display: flex;
  justify-content: center;
}

.content {
  padding: 0 10px;

  .down {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    border-top: 1px solid #999;
    padding-top: 20px;
    box-sizing: border-box;
  }

  .underLine {
    color: #599af8;
    text-decoration: underline;

    .underIcon {
      background-color: green;
      color: #fff;
      border-radius: 50%;
      margin-right: 5px;
    }
  }
}

.operate-icon-wrap {
  display: flex;
  column-gap: 15px;
}

.operate-icon-box {
  display: flex;
  align-items: center;
  cursor: pointer;
  color: #4095e5;
}

.header-cell-class {
  background-color: #ccc;
}

.foot {
  display: flex;
  justify-content: flex-end;
  margin-top: 20px;
}

.btn-bgc {
  background-color: rgb(31, 99, 255);
  color: #fff;
}

.confrim-bgc {
  background-color: #1376c7;
  color: #fff;
}

.cursor-on {
  cursor: pointer;
}
</style>
