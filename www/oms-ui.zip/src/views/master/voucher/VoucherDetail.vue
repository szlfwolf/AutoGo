<template>
  <basic-container>
    <div class="avue-crud content" v-loading="skuLoading">
      <div>
        <div class="title">
          <span></span>
          <label for="">SkuVoucher Info</label>
        </div>
        <el-form class="contain">
          <el-row>
            <el-col :span="8">
              <el-form-item label="WarehouseCode:">
                <span>{{ skuVoucherInfo.warehouseCode }}</span>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="Client:">
                <span>{{ skuVoucherInfo.clientCode }}</span>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="SapStockOrder No:">
                <span>{{ skuVoucherInfo.sapStockOrderNo }}</span>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="Operate Type:">
                <span>{{ skuVoucherInfo.operateType }}</span>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="Send Time:">
                <span>{{ skuVoucherInfo.sendTime }}</span>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="Status:">
                <span>{{ skuVoucherInfo.status }}</span>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="Order No:">
                <span>{{ skuVoucherInfo.orderNo }}</span>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <div>
        <div class="title">
          <span></span>
          <label for="">SkuVoucher Line</label>
        </div>
        <div class="contain">
          <el-row>
            <el-col :span="2">
              <el-button @click="Query()" type="primary" icon="el-icon-search">Query</el-button>
            </el-col>
            <el-col :span="2">
              <el-button @click="resetForm()" icon="el-icon-refresh-left">Reset</el-button>
            </el-col>
          </el-row>
          <el-row>
            <el-form ref="form" :model="form">
              <el-row style="margin-top: 20px" :gutter="20">
                <el-col :span="4">
                  <el-form-item prop="partNumber">
                    <el-input v-model="form.partNumber" placeholder="PartNumber"></el-input>
                  </el-form-item>
                </el-col>

                <el-col :span="4">
                  <el-form-item prop="moveType">
                    <el-select filterable clearable v-model="form.moveType" placeholder="Move Type">
                      <el-option v-for="item in moveTypeSelect" :key="item.value" :label="item.label" :value="item.value">
                      </el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
              </el-row>
            </el-form>
          </el-row>
        </div>
      </div>
      <!-- 列表 -->
      <el-table tooltip-effect="dark" stripe border ref="multipleTable" :data="tableData.records"
        style="width: 100%;margin-bottom: 20px;" header-cell-class-name="header-cell-class"
        :header-cell-style="{ background: '#f5f7fa', color: '#606266', 'text-align': 'center' }">
        <el-table-column :show-overflow-tooltip="true" label="Line No" align="center" min-width="80">
          <template slot-scope="scope">{{ scope.row.lineNo }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="PartNumber" align="center" min-width="160">
          <template slot-scope="scope"> {{ scope.row.partNumber }} </template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Move Type" align="center" min-width="150">
          <template slot-scope="scope"> {{ scope.row.moveType }} </template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="ReceiptAddressNo" align="center" min-width="180">
          <template slot-scope="scope">{{ scope.row.receiptAddressNo }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Batch No" align="center" min-width="120">
          <template slot-scope="scope">{{ scope.row.batchNo }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Num" align="center" min-width="100">
          <template slot-scope="scope">{{ scope.row.num }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Unit" align="center" min-width="100">
          <template slot-scope="scope">{{ scope.row.unit }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Address No" align="center" min-width="120">
          <template slot-scope="scope">{{ scope.row.addressNo }}</template>
        </el-table-column>
      </el-table>
      <Pagination @handleSizeChange="handleSizeChange" @handleCurrentChange="handleCurrentChange"
        :pageNum="tableData.current" :pageSize="tableData.size" :total="tableData.total"></Pagination>
    </div>
  </basic-container>
</template>
<script>
import { getDetails, getSkuVoucherLine } from '@/api/voucher'
import Pagination from "@/components/pagination/pagination.vue"
import { deepClone } from '@/util/util';
import { remote } from '@/api/admin/dict'
export default {
  name: "dnDetail",
  data() {
    return {
      skuLoading: false,
      pageSize: '',
      pageCurrent: '1',
      form: {
        partNumber: "",
        moveType: ''
      },
      currentPage4: 4,
      moveTypeSelect: [],
      tableData: [],
      skuVoucherInfo: {},
    };
  },
  created() {
    let data = Object.assign(this.form, { skuVoucherId: this.$route.query.id })
    this.fetchListData(this.$route.query.id, data) //通过id查询详情
    this.querySelect()
  },
  components: {
    Pagination
  },
  methods: {
    // 按条件查询
    async Query(query) {
      this.skuLoading = true //关loading
      let data = Object.assign(this.form, { skuVoucherId: this.$route.query.id }, query)
      // 列表
      let { data: skuVoucherLine } = await getSkuVoucherLine(data)
      if (skuVoucherLine.code != 0) {
        this.skuLoading = false //关loading
        this.$message.error(skuVoucherLine.msg);
        return;
      }
      this.skuLoading = false //关loading
      this.tableData = deepClone(skuVoucherLine.data)
      console.log('列表', JSON.parse(JSON.stringify(this.tableData.records)))
    },
    // 获取基本数据
    async fetchListData(id, obj) {
      this.skuLoading = true //开启loading
      // 详情
      let { data } = await getDetails(id)
      if (data.code != 0) {
        this.skuLoading = false //关loading
        this.$message.error(data.msg);
        return;
      }
      this.skuVoucherInfo = deepClone(data.data)
      console.log('页面基本数据', JSON.parse(JSON.stringify(this.skuVoucherInfo)))
      // 列表
      let { data: skuVoucherLine } = await getSkuVoucherLine(obj)
      if (skuVoucherLine.code != 0) {
        this.skuLoading = false //关loading
        this.$message.error(skuVoucherLine.msg);
        return;
      }
      this.skuLoading = false //关loading
      this.tableData = deepClone(skuVoucherLine.data)
      console.log('列表', JSON.parse(JSON.stringify(this.tableData.records)))
    },
    // 获取query下拉框  
    // voucher_move_type
    async querySelect() {
      let { data } = await remote('voucher_move_type')
      this.moveTypeSelect = data.data
    },
    //条数
    handleSizeChange(val) {
      this.pageSize = val
      let query = { current: this.pageCurrent, size: val }
      this.Query(query)
      console.log(`每页 ${val} 条`);
    },
    //当前页数
    handleCurrentChange(val) {
      this.pageCurrent = val
      let query = { current: val, size: this.pageSize }
      this.Query(query)
      console.log(`当前页: ${val}`);
    },
    // 重置
    resetForm() {
      this.$refs.form.resetFields();
    },
  },
};
</script>
<style lang="scss" scoped>
::v-deep .el-form-item--small {
  margin-bottom: 0;
}

.content {
  width: 100%;
  //   padding: 20px;
  box-sizing: border-box;

  .title {
    width: 100%;
    height: 30px;
    line-height: 30px;
    display: flex;
    margin-bottom: 10px;

    span {
      width: 3px;
      height: 30px;
      background-color: #000;
      margin-right: 10px;
    }

    label {
      font-weight: 700;
    }
  }

  .containBox {
    border-bottom: 1px solid #999;
    margin-bottom: 10px;
  }

  .contain {
    padding: 10px;
    box-sizing: border-box;

    label {
      display: inline;
      margin-right: 10px;
    }
  }

  .down {
    float: right;
    margin-bottom: 20px;
  }

  .timeline {
    padding: 10px;

    .box {
      background-color: #f4f6f7;
      border-radius: 5px;
      padding: 10px 20px;
      box-sizing: border-box;

      .boxTop {
        font-weight: 700;
        margin-bottom: 10px;

        span {
          margin-left: 10px
        }
      }

      .boxBottom {
        color: #666;
      }
    }
  }

}
</style>
  