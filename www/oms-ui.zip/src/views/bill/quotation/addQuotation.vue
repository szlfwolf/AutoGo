<template>
  <div class="content">
    <div class="savebtn">
      <el-button type="primary" @click="next">Save</el-button>
    </div>
    <el-card class="box-card" v-loading="isLoading">
      <el-form ref="form" :model="form" :rules="rules" label-width="140px" style="width:50%;margin:0 auto">
        <el-form-item label="Warehouse:" prop="warehouseCode">
          <el-select filterable v-model="form.warehouseCode" placeholder="" clearable>
            <el-option v-for="item in warehouseArr" :key="item.warehouseCode" :label="item.warehouseName"
              :value="item.warehouseCode">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="Currency:" prop="currency">
          <el-select filterable v-model="form.currency" placeholder="" clearable>
            <el-option v-for="item in currencyArr" :key="item.value" :label="item.label" :value="item.value">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="Valid Scope:" prop="timeRange">
          <div class="block">
            <el-date-picker v-model="form.timeRange" type="monthrange" range-separator="至" start-placeholder="开始月份"
              end-placeholder="结束月份" value-format="yyyy-MM" @change="pickerTiem">
            </el-date-picker>
          </div>
        </el-form-item>
        <el-form-item v-if="active === 2" label="Weight Threshold:" prop="weightThreshold">
          <el-input v-model.trim="form.weightThreshold"></el-input>
        </el-form-item>
      </el-form>
      <el-steps :active="active" finish-status="success" align-center style="width:70%;margin:40px auto">
        <el-step style="cursor:pointer;user-select:none;" @click.native="active = 0" title="Import"> </el-step>
        <el-step style="cursor:pointer;user-select:none;" @click.native="active = 1" title="Warehousing"> </el-step>
        <el-step style="cursor:pointer;user-select:none;" @click.native="active = 2" title="Transport"> </el-step>
        <!-- <el-step title="Completed"> </el-step> -->
      </el-steps>
      <div style="width: 60%; margin: 50px auto">
        <div v-show="active === 0">
          <div style="width:80%;margin: 50px auto;">
            <el-form ref="form1" :model="form.importQuotations" :rules="rules" label-width="190px">

              <el-card>

                <el-form-item label="Import C/D Min Price:" prop="importCdMinPrice">
                  <el-input placeholder="Please enter Unit Price"
                    v-model.trim="form.importQuotations.importCdMinPrice"></el-input>
                </el-form-item>
                <el-form-item label="Hscode Threshold:" prop="hscodeThreshold">
                  <el-input placeholder="Please enter Unit Price" v-model.trim="form.importQuotations.hscodeThreshold"
                    :maxlength="8"></el-input>
                </el-form-item>

                <el-form-item label="Hscode Unit Price:" prop="hscodeUnitPrice">
                  <el-input placeholder="Please enter Unit Price"
                    v-model.trim="form.importQuotations.hscodeUnitPrice"></el-input>
                </el-form-item>

              </el-card>


              <el-card>
                <div slot="header">
                  <span>Inland Transport</span>
                </div>
                <el-form-item label="Sea Transport:" prop="seaInlandTransportUnitPrice">
                  <el-input placeholder="Please enter Unit Price"
                    v-model.trim="form.importQuotations.seaInlandTransportUnitPrice"></el-input>
                </el-form-item>
                <el-form-item label="Air&Sea Transport:" prop="airInlandTransportUnitPrice">
                  <el-input placeholder="Please enter Unit Price"
                    v-model.trim="form.importQuotations.airInlandTransportUnitPrice"></el-input>
                </el-form-item>
                <el-form-item label="Train Transport:" prop="trainInlandTransportUnitPrice">
                  <el-input placeholder="Please enter Unit Price"
                    v-model.trim="form.importQuotations.trainInlandTransportUnitPrice"></el-input>
                </el-form-item>
                <el-form-item label="Local Transport:" prop="localInlandTransportUnitPrice">
                  <el-input placeholder="Please enter Unit Price"
                    v-model.trim="form.importQuotations.localInlandTransportUnitPrice"></el-input>
                </el-form-item>

              </el-card>
            </el-form>

          </div>
        </div>
        <div v-show="active === 1">
          <Warehousing ref="Warehousing" @pre="pre" @next="next" @formData="formData" @activeChange="activeChange"
            :propsForm="form" :newPropsForm="newForm" @deleteDataChange="deleteDataChange" @nextTran="nextTran">
          </Warehousing>
        </div>
        <div v-if="transportShow">
          <div v-show="active === 2">
            <Transport ref="Transport" @pre="pre" @next="next" @thresholdDefault="thresholdDefault" @formData="formData"
              @activeChange="activeChange" :propsForm="transport.transportQuotationDto"
              :newPropsForm="transport.transportQuotationDto" @submitPost="submitPost"
              @deleteDataChange="deleteDataChange">
            </Transport>
          </div>
        </div>
      </div>
    </el-card>
  </div>
</template>
<script>
import store from "@/store";
import { mapGetters } from "vuex";
import { remote } from "@/api/admin/dict";
import Warehousing from "./components/add/warehousing.vue"
import Transport from "./components/add/transport.vue"
import Complete from "./components/add/complete.vue"
import { addSave, AddParentWarehouseCodes, getQuotationDetails, getTransportDetails, update } from "@/api/quotation"
import { getPfepDataByQuery } from '@/api/pfepData'
import { deepClone } from '@/util/util';
import { getStore, setStore, removeStore } from '@/util/store';

export default {
  name: "AddQuotation",
  data() {
    let priceRule8 = (rule, value, callback) => {
      if (this.submitData) {
        if (!value) callback(new Error('请全部填写或者全部为空'))
      }
      if (this.isThresholdDefault && rule.field == 'weightThreshold' && !this.form.weightThreshold) {
        callback(new Error('填写快递或者运输后这一项为必填'))
      } else if (rule.field != 'hscodeThreshold') {
        value = String(value)
        if (value.includes('.')) {
          value.indexOf('.') >= 9 ? callback(new Error('整数部分最大长度为8位')) : callback()
        } else {
          value.length >= 9 ? callback(new Error('整数部分最大长度为8位')) : callback()
        }
      } else {
        callback()
      }

    }

    let timeVerification = (rule, value, callback) => {
      if (value[0] === value[1]) {
        callback(new Error('填写错误,PS:2023-01至2023-02表示2023-01-01至2023-02-01'))
      } else { callback() }
    }
    return {
      isThresholdDefault: false,   //判断threshold是否要填写
      submitData: false,
      transportShow: false,
      transport: {},
      dataId: '',
      addQuotationRow: null,
      paraData: null,
      fteData: [],
      pmhvData: [],
      pkgData: [],
      otherData: [],
      active: 0,
      isLoading: false,
      form: {
        clickType: '',
        clientCode: '',
        warehouseCode: "",
        currency: "",
        weightThreshold: "",
        timeRange: [],
        importQuotations: {
          importCdMinPrice: '',
          airInlandTransportUnitPrice: '',
          trainInlandTransportUnitPrice: '',
          localInlandTransportUnitPrice: '',
          seaInlandTransportUnitPrice: '',
          hscodeThreshold: '',
          // hscodeFreeNum: '',
          hscodeUnitPrice: '',
        }
      },
      newForm: {
        clickType: '',
        clientCode: '',
        warehouseCode: "",
        currency: "",
        timeRange: [],
        importQuotations: {
          importCdMinPrice: '',
          airInlandTransportUnitPrice: '',
          trainInlandTransportUnitPrice: '',
          localInlandTransportUnitPrice: '',
          seaInlandTransportUnitPrice: '',
          hscodeThreshold: '',
          // hscodeFreeNum: '',
          hscodeUnitPrice: '',
        }
      },
      currencyArr: [],
      warehouseArr: [],
      rules: {
        currency: [
          { required: true, message: "此区域为必填项", trigger: "change" }
        ],
        warehouseCode: [
          { required: true, message: "此区域为必填项", trigger: "change" },
        ],
        timeRange: [
          { required: true, message: "此区域为必填项", trigger: "change" },
          { validator: timeVerification, trigger: 'change' },
        ],
        importCdMinPrice: [
          { pattern: /^(([0-9]\d*)|([0][.]{1}[0-9]{0,2}[1-9]+)|([1-9]\d*[.]{1}[0-9]+))$/g, message: '请输入大于等于0的整数或小数', trigger: 'change' },
          { validator: priceRule8, trigger: 'change' },
        ],
        airInlandTransportUnitPrice: [
          { pattern: /^(([0-9]\d*)|([0][.]{1}[0-9]{0,2}[1-9]+)|([1-9]\d*[.]{1}[0-9]+))$/g, message: '请输入大于等于0的整数或小数', trigger: 'change' },
          { validator: priceRule8, trigger: 'change' },
        ],
        trainInlandTransportUnitPrice: [
          { pattern: /^(([0-9]\d*)|([0][.]{1}[0-9]{0,2}[1-9]+)|([1-9]\d*[.]{1}[0-9]+))$/g, message: '请输入大于等于0的整数或小数', trigger: 'change' },
          { validator: priceRule8, trigger: 'change' },
        ],
        localInlandTransportUnitPrice: [
          { pattern: /^(([0-9]\d*)|([0][.]{1}[0-9]{0,2}[1-9]+)|([1-9]\d*[.]{1}[0-9]+))$/g, message: '请输入大于等于0的整数或小数', trigger: 'change' },
          { validator: priceRule8, trigger: 'change' },
        ],
        seaInlandTransportUnitPrice: [
          { pattern: /^(([0-9]\d*)|([0][.]{1}[0-9]{0,2}[1-9]+)|([1-9]\d*[.]{1}[0-9]+))$/g, message: '请输入大于等于0的整数或小数', trigger: 'change' },
          { validator: priceRule8, trigger: 'change' },
        ],
        hscodeThreshold: [
          { pattern: /^\+?[0-9]\d*$/, message: '请输入大于等于0的整数', trigger: 'change' },
          { validator: priceRule8, trigger: 'change' },
        ],
        hscodeUnitPrice: [
          { pattern: /^(([0-9]\d*)|([0][.]{1}[0-9]{0,2}[1-9]+)|([1-9]\d*[.]{1}[0-9]+))$/g, message: '请输入大于等于0的整数或小数', trigger: 'change' },
          { validator: priceRule8, trigger: 'change' },
        ],
        weightThreshold: [
          { pattern: /^\+?[0-9]\d*$/, message: '请输入大于等于0的整数', trigger: 'change' },
          { validator: priceRule8, trigger: 'change' },
        ],
      },
    };
  },
  computed: {
    ...mapGetters(["permissions", 'tagList']),
  },


  components: {
    Warehousing,
    Transport,
    Complete
  },

  async beforeRouteUpdate(to, from, next) {
    if (to.query.id) {
      this.isLoading = true;
      let { data } = await getQuotationDetails(to.query.id)
      if (data.code != 0) {
        this.isLoading = false;
        this.$message.error('request was aborted')
        return
      }
      this.isLoading = false;
      let newData = deepClone(data.data)

      if (newData.importQuotations == null) newData.importQuotations = {
        importCdMinPrice: '',
        airInlandTransportUnitPrice: '',
        trainInlandTransportUnitPrice: '',
        localInlandTransportUnitPrice: '',
        seaInlandTransportUnitPrice: '',
        hscodeThreshold: '',
        // hscodeFreeNum: '',
        hscodeUnitPrice: '',
      }

      console.log('查询出来的详细数据', JSON.parse(JSON.stringify(newData)))
      this.form = deepClone(newData)
      this.newForm = deepClone(newData)
      this.$set(this.form, 'timeRange', [newData.validTimeBegin, newData.validTimeFinish])
      this.active = 0
      try {
        this.$refs.Warehousing.assignment()
      } catch (error) {
      }
      setTimeout(async () => {
        this.transportShow = true
        // 查询transportDetails详情
        let { data: transportDetails } = await getTransportDetails(to.query.id)
        //如果返回的data是0 就给个初始化的数据
        if (transportDetails.data == 0) {
          this.transport = {
            transportQuotationDto: [
              {
                transportQuotations: [
                  {
                    transportType: '',
                    countryCode: '',
                    weightScopeLeading: '',
                    weightScopeAfter: '',
                    unitPrice: '',
                  }
                ]
              },
              // 托盘
              {
                transportQuotations: [
                  {
                    transportType: '',
                    countryCode: '',
                    scopeLeading: '',
                    scopeAfter: '',
                    weightScopeLeading: '',
                    weightScopeAfter: '',
                    unitPrice: '',
                  }
                ]
              },
            ]
          }
        } else {
          this.transport = transportDetails.data
        }
        console.log('查询transportDetails详情', JSON.parse(JSON.stringify(transportDetails.data)))
        try {
          this.$refs.Transport.assignment()
        } catch (error) {
        }
      }, 150)
      this.form.clickType = 'change'
    } else {
      this.transportShow = true
      this.active = 0
      this.form = this.$options.data().form
      this.form.clientCode = store.getters.commandName
      this.$refs.form.resetFields()
      this.$refs.form1.resetFields()
      this.$refs.Warehousing.clear()
      this.$refs.Transport.clear()
      this.form.clickType = 'add'
    }
    this.getRemote();
    next();
  },

  async created() {
    if (this.$route.query.id) {
      this.isLoading = true;
      let { data } = await getQuotationDetails(this.$route.query.id)
      if (data.code != 0) {
        this.isLoading = false;
        this.$message.error('request was aborted')
        return
      }
      this.isLoading = false;
      // 处理后端返回的初始数据
      let newData = deepClone(data.data)

      if (newData.importQuotations == null) newData.importQuotations = {
        importCdMinPrice: '',
        airInlandTransportUnitPrice: '',
        trainInlandTransportUnitPrice: '',
        localInlandTransportUnitPrice: '',
        seaInlandTransportUnitPrice: '',
        hscodeThreshold: '',
        // hscodeFreeNum: '',
        hscodeUnitPrice: '',
      }
      if (newData.fixedAssetsQuotations == null) newData.fixedAssetsQuotations = []


      console.log('查询出来的详细数据', JSON.parse(JSON.stringify(newData)))
      this.form = deepClone(newData)
      this.newForm = deepClone(newData)
      this.$set(this.form, 'timeRange', [newData.validTimeBegin, newData.validTimeFinish])
      this.active = 0
      try {
        this.$refs.Warehousing.assignment()
      } catch (error) {
      }
      setTimeout(async () => {
        this.transportShow = true
        // 查询transportDetails详情
        let { data: transportDetails } = await getTransportDetails(this.$route.query.id)
        console.log('查询transportDetails详情', JSON.parse(JSON.stringify(transportDetails.data)))
        //如果返回的data是0 就给个初始化的数据
        if (transportDetails.data == 0) {
          this.transport = {
            transportQuotationDto: [
              {
                transportQuotations: [
                  {
                    transportType: '',
                    countryCode: '',
                    weightScopeLeading: '',
                    weightScopeAfter: '',
                    unitPrice: '',
                  }
                ]
              },
              // 托盘
              {
                transportQuotations: [
                  {
                    transportType: '',
                    countryCode: '',
                    scopeLeading: '',
                    scopeAfter: '',
                    weightScopeLeading: '',
                    weightScopeAfter: '',
                    unitPrice: '',
                  }
                ]
              },
            ]
          }
        } else {
          this.transport = transportDetails.data
        }

        try {
          this.$refs.Transport.assignment()
        } catch (error) {
        }
      }, 150)
      this.form.clickType = 'change'
    } else {
      this.transportShow = true
      this.form.clickType = 'add'
      this.newForm.clickType = 'add'
    }
    // 当前的用户
    this.form.clientCode = store.getters.commandName
    this.newForm.clientCode = store.getters.commandName
    // 传过来的数据
    this.getRemote();
  },

  // 数据更新
  methods: {
    pickerTiem(val) {
      this.form.validTimeBegin = val[0]
      this.form.validTimeFinish = val[1]
    },
    thresholdDefault(val) {
      this.isThresholdDefault = val
    },
    // 跳转组件
    activeChange(val) {
      this.active = val
    },
    // 如果warehous页面所有组件都通过校验  就进行最后一个页面校验
    nextTran() {
      this.$refs.Transport.next()
    },
    next() {
      this.$refs.form.validate((valid) => {
        if (!valid) {
          this.$message.warning('Please fill in correctly')
          return false
        };
        let formData = []
        formData.push(
          this.form.importQuotations.airInlandTransportUnitPrice,
          this.form.importQuotations.trainInlandTransportUnitPrice,
          this.form.importQuotations.localInlandTransportUnitPrice,
          this.form.importQuotations.seaInlandTransportUnitPrice,
          this.form.importQuotations.importCdMinPrice,
          this.form.importQuotations.hscodeUnitPrice,
          this.form.importQuotations.hscodeThreshold,
          // this.form.importQuotations.hscodeFreeNum,
        )
        // 如果  someNext 是true的话说明页面有内容
        let someNext = formData.some(i => i !== '' && i !== null)
        // 如果  everyNext 是true的话说明页面的内容都填好了
        let everyNext = formData.every(i => i !== '' && i !== null)
        console.log("🚀→→→→→ ~ 主页面表单状态:", someNext, everyNext, formData)
        // 这是页面有填写但是没填完
        if (someNext && !everyNext) {
          this.submitData = true  //控制是否报红验证
          console.log(this.form,'this.form');
          this.$refs.form1.validate((valid) => {
            if (!valid) {
              this.active = 0
              this.formData(this.form)
              return false
            }
          });
          //页面都填完了然后校验数据是否符合规则
        } else if (someNext && everyNext) {
          this.submitData = false  //控制是否报红验证
          this.$refs.form1.validate((valid) => {
            if (!valid) {
              this.active = 0
              return false
            }
            // 都填写了并且校验通过 进行下一步校验！！！！！！！！
            this.formData(this.form)
            this.$refs.Warehousing.next()

          });
        } else {
          this.submitData = false  //控制是否报红验证
          this.$refs.form1.validate((valid) => {
            // 都不填写 进行下一步校验！！！！！！！！
            if(this.form.importQuotations.hscodeUnitPrice === null || this.form.importQuotations.hscodeUnitPrice === ''){
              this.formData({ Import: "true" })
            }else{
              this.formData({ Import: true })
            }
            this.$refs.Warehousing.next()
          });
        }
      });
    },

    // 将数据提交
    submitPost() {
      this.isLoading = true
      if (this.paraData.clickType === 'add') {
        let deleteArr = {
          StorageAmount: 'storageQuotations',
          FteAmountOrder: 'fteOrderQuotation',
          FteAmountType: 'fteTypeQuotations',
          PmhvAmount: 'pmhvQuotations',
          FixedAssetsAmount: 'fixedAssetsQuotations',
          PackagingCm: 'packingCmQuotations',
          Other: 'otherQuotations',
          Import: 'importQuotations'
        }
        Object.keys(deleteArr).forEach((i) => {
          if (this.paraData[i] == 'true') {
            this.paraData[deleteArr[i]] = undefined
          }
        })
        console.log('新增的时候带的参数this.paraData', JSON.parse(JSON.stringify(this.paraData)))
        addSave(this.paraData).then(({ data }) => {
          if (data.code != 0) {
            this.$message.error(data.msg)
            this.isLoading = false
            return
          } else {
            this.$message.success(data.msg)
            this.isLoading = false
            // 关页面
            this.cancelClo()
          }
          console.log("🚀→→→→→ ~ 新增返回的数据", data)
        }).catch((err) => {
          this.isLoading = false
        })


      } else {
        let deleteArr = {
          StorageAmount: 'storageQuotations',
          FteAmountOrder: 'fteOrderQuotation',
          FteAmountType: 'fteTypeQuotations',
          PmhvAmount: 'pmhvQuotations',
          FixedAssetsAmount: 'fixedAssetsQuotations',
          PackagingCm: 'packingCmQuotations',
          Other: 'otherQuotations',
          Import: 'importQuotations'
        }
        Object.keys(deleteArr).forEach((i) => {
          if (this.paraData[i] == 'true') {
            this.paraData[deleteArr[i]] = undefined
          }
        })
        console.log('修改的时候带的参数this.paraData', JSON.parse(JSON.stringify(this.paraData)))
        update(this.paraData).then(({ data }) => {
          console.log("🚀→→→→→ ~ 修改返回的数据data", data)
          if (data.code != 0) {
            this.$message.error(data.msg)
            this.isLoading = false
            return
          } else {
            this.$message.success('修改成功')
            this.isLoading = false
            // 关页面
            this.cancelClo()
          }
        }).catch((err) => {
          this.isLoading = false
        })

      }
      this.eventBus.$emit('query')
    },
    findTag(value) {
      let tag, key;
      this.tagList.map((item, index) => {
        if (item.value.includes(value)) {
          tag = item;
          key = index;
        }
      });
      return { tag: tag, key: key };
    },
    //返回
    cancelClo() {
      let { tag, key } = this.findTag(this.$route.fullPath);
      this.$store.commit('DEL_TAG', tag)
      this.$router.push({
        path: "/bill/quotation/index"
      })
    },
    // 把填好的表单整合在一起
    formData(val) {
      let arr = Object.values(this.form.importQuotations)
      let boo = arr.some(i => i)
      this.form = { ...this.form, ...val }
      // 如果收到了submit  那么调用新增接口
      this.paraData = deepClone(this.form)
      if (!boo) delete (this.paraData.importQuotations)
      if (!this.isThresholdDefault && !this.paraData.weightThreshold) delete (this.paraData.weightThreshold)
      delete (this.paraData.timeRange)
      // 处理数据用于提交
      if (this.paraData.fteOrderQuotation && this.paraData.fteOrderQuotation.quotationType === 'FTE') {
        this.paraData.fteTypeQuotations = this.paraData.fteOrderQuotation.fteTypeQuotations
        // 映射数据用于提交
        this.dataMap(this.fteData, this.paraData.fteTypeQuotations, 'fteTypeQuotations', 'fteType')
        this.paraData.fteOrderQuotation = undefined
      } else {
        if (this.paraData.fteOrderQuotation) {
          delete this.paraData.fteOrderQuotation.fteTypeQuotations
          this.paraData.fteTypeQuotations = []
        }
      }
      // 映射数据用于提交
      if (this.paraData.pmhvQuotations) {
        this.dataMap(this.pmhvData, this.paraData.pmhvQuotations, 'pmhvQuotations', 'pmhvType')
      }
      if (this.paraData.packingCmQuotations) {
        this.dataMap(this.pkgData, this.paraData.packingCmQuotations, 'packingCmQuotations', 'packingCmType')
      }
      if (this.paraData.otherQuotations) {
        this.dataMap(this.otherData, this.paraData.otherQuotations, 'otherQuotations', 'otherType')
      }

      // console.log('处理数据用于提交', JSON.parse(JSON.stringify(this.paraData)))

    },
    pre() {
      if (this.active === 3) {
        console.log('再次新增');
        this.active = 0
        this.form = this.$options.data().form
        this.form.clientCode = store.getters.commandName
        this.$refs.form.resetFields()
        this.$refs.form1.resetFields()
        this.$refs.Warehousing.clear()
        this.$refs.Transport.clear()
        this.form.clickType = 'add'
      } else {
        this.active--;
      }
    },
    async getRemote() {
      let { data: currency } = await remote('monetary_unit')
      this.currencyArr = currency.data
      let { data: warehouse } = await AddParentWarehouseCodes()
      this.warehouseArr = warehouse.data
      let { data: fte } = await getPfepDataByQuery({ dataType: 'FTE' })
      this.fteData = fte.data.records
      let { data: pmhv } = await getPfepDataByQuery({ dataType: 'PMHV' })
      this.pmhvData = pmhv.data.records
      let { data: pkg } = await getPfepDataByQuery({ dataType: 'Packaging CM' })
      this.pkgData = pkg.data.records
      let { data: other } = await getPfepDataByQuery({ dataType: 'Other Type' })
      this.otherData = other.data.records
    },
    // 映射数据用于提交
    dataMap(res, data, name, type) {
      let newData = []
      res.forEach((i) => {
        data.forEach((item) => {
          if (item[type] == i.name) {
            item[type] = i.code
            newData.push(item)
          }
        })
      })
      this.paraData[name] = newData
    },
    //  修改的时候如果什么都没填写 就删掉这项数据
    deleteDataChange(val) {
      delete (this.paraData[val])
    },

  },
};
</script>
<style lang="scss" scoped>
.content {
  padding: 0 10px;

  // box-sizing: border-box;
  .text {
    font-size: 14px;
  }

  .item {
    padding: 18px 0;
  }

  .box-card {
    width: 100%;
    padding-top: 20px;
  }

  ::v-deep .el-select--small {
    display: block;
  }

  ::v-deep .el-date-editor--daterange.el-input,
  ::v-deep .el-date-editor--daterange.el-input__inner,
  ::v-deep .el-date-editor--timerange.el-input,
  ::v-deep .el-date-editor--timerange.el-input__inner {
    width: 100% !important;
  }

  ::v-deep .el-date-editor.el-input,
  .el-date-editor.el-input__inner {
    width: 100%;
  }
}

.savebtn {
  position: absolute;
  right: 40px;
  top: 40px;
}
</style>
