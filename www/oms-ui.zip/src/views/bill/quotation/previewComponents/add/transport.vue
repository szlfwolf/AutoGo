<template>
  <div class="content">
    <el-tabs v-model="activeName" v-loading="skuLoading">
      <el-tab-pane label="快递" name="form1">
        <el-form ref="form1" :model="form.transportQuotationDto[0]" label-width="130px">
          <u-table use-virtual max-height="400" border ref="multipleTableform1"
            :data="form.transportQuotationDto[0].transportQuotations" tooltip-effect="dark" class="transport"
            style="width: 100%" :header-cell-style="{ background: '#f5f7fa', color: '#606266' }">
            <u-table-column label="Country Code" min-width="120" align="center" prop="countryCode"
              column-key="countryCode" :filters="newCountryFilters" :filter-method="filterHandler">
              <template slot-scope="scope">
                <el-form-item style="margin-bottom: 0;" :prop="'transportQuotations.' + scope.$index + '.countryCode'">
                  <el-select filterable disabled @change="countyrChange" clearable v-model.trim="scope.row.countryCode"
                    placeholder=" ">
                    <el-option v-for="item in countryCodeSelect" :label="item.label" :value="item.value"
                      :key="item.value">
                    </el-option>
                  </el-select>
                </el-form-item>
              </template>
            </u-table-column>
            <u-table-column label="Urgent Type" min-width="100" align="center">
              <template slot-scope="scope">
                <el-form-item style="margin-bottom: 0;" :prop="'transportQuotations.' + scope.$index + '.urgentType'">
                  <el-select filterable disabled @change="countyrChange" clearable v-model.trim="scope.row.urgentType"
                    placeholder=" ">
                    <el-option v-for="item in urgentTypeList" :label="item.label" :value="item.value" :key="item.value">
                    </el-option>
                  </el-select>
                </el-form-item>
              </template>
            </u-table-column>

            <u-table-column label="Weight Scope (KG)" min-width="160" align="center">
              <template slot-scope="scope">
                <el-row type="flex" align="middle">
                  <el-form-item style="margin-bottom: 0; width: 50%;"
                    :prop="'transportQuotations.' + scope.$index + '.weightScopeLeading'">
                    <el-input disabled v-model.trim="scope.row.weightScopeLeading"></el-input>
                  </el-form-item>
                  <span>~</span>
                  <el-form-item style="margin-bottom: 0; width: 50%;"
                    :prop="'transportQuotations.' + scope.$index + '.weightScopeAfter'">
                    <el-input disabled v-model.trim="scope.row.weightScopeAfter"></el-input>
                  </el-form-item>
                </el-row>
              </template>
            </u-table-column>
            <u-table-column label="Unit Price" min-width="100" align="center">
              <template slot-scope="scope">
                <el-form-item style="margin-bottom: 0;" :prop="'transportQuotations.' + scope.$index + '.unitPrice'">
                  <el-input disabled v-model.trim="scope.row.unitPrice"></el-input>
                </el-form-item>
              </template>
            </u-table-column>
            <u-table-column v-if="false" label="Opearter" align="center" min-width="80">
              <template slot-scope="scope">
                <i style="font-size: 18px; cursor: pointer; color: #65beff" class="el-icon-delete"
                  @click="handleDelete(scope.$index, scope.row.countryCode)"></i>
              </template>
            </u-table-column>
          </u-table>
          <!-- 添加 -->
          <div v-if="false" class="dialog-footer-add">
            <i @click="kpiAdd" class="el-icon-circle-plus-outline cursor-on"></i>
            <excel-upload ref="expressDelivery" title="Expressage upload" url="/bill/quotation/uploadTransportByExcel"
              temp-name="transport-upload.xlsx" temp-url="/admin/sys-file/local/transport-upload.xlsx"
              @refreshDataList="skuUploadExcel">
            </excel-upload>
            <!-- 上传 -->
            <el-button type="text" style="font-size: 28px;" icon="el-icon-upload"
              @click="$refs.expressDelivery.show()"></el-button>
          </div>
        </el-form>
      </el-tab-pane>

      <el-tab-pane label="托盘" name="form2">
        <el-form ref="form2" :model="form.transportQuotationDto[1]" label-width="130px">
          <u-table use-virtual max-height="400" border ref="multipleTableform2"
            :data="form.transportQuotationDto[1].transportQuotations" tooltip-effect="dark" class="transport"
            style="width: 100%" :header-cell-style="{ background: '#f5f7fa', color: '#606266' }">
            <u-table-column label="Country Code" min-width="120" align="center" prop="countryCode"
              column-key="countryCode" :filters="newCountryFilters" :filter-method="filterHandler">
              <template slot-scope="scope">
                <el-form-item style="margin-bottom: 0;" :prop="'transportQuotations.' + scope.$index + '.countryCode'">
                  <el-select filterable disabled @change="countyrChange" clearable v-model.trim="scope.row.countryCode"
                    placeholder=" ">
                    <el-option v-for="item in countryCodeSelect" :label="item.label" :value="item.value"
                      :key="item.value">
                    </el-option>
                  </el-select>
                </el-form-item>
              </template>
            </u-table-column>
            <u-table-column label="Urgent Type" min-width="100" align="center">
              <template slot-scope="scope">
                <el-form-item style="margin-bottom: 0;" :prop="'transportQuotations.' + scope.$index + '.urgentType'">
                  <el-select filterable disabled @change="countyrChange" clearable v-model.trim="scope.row.urgentType"
                    placeholder=" ">
                    <el-option v-for="item in urgentTypeList" :label="item.label" :value="item.value" :key="item.value">
                    </el-option>
                  </el-select>
                </el-form-item>
              </template>
            </u-table-column>

            <u-table-column label="Zip code scope" min-width="160" align="center">
              <template slot-scope="scope">
                <el-row type="flex" align="middle">
                  <el-form-item style="margin-bottom: 0; width: 50%;"
                    :prop="'transportQuotations.' + scope.$index + '.scopeLeading'">
                    <el-input disabled @change.native="zipCodeChange" v-model.trim="scope.row.scopeLeading"></el-input>
                  </el-form-item>
                  <span>~</span>
                  <el-form-item style="margin-bottom: 0; width: 50%;"
                    :prop="'transportQuotations.' + scope.$index + '.scopeAfter'">
                    <el-input disabled @change.native="zipCodeChange" v-model.trim="scope.row.scopeAfter"></el-input>
                  </el-form-item>
                </el-row>
              </template>
            </u-table-column>
            <u-table-column label="Pallet Qty Scope" min-width="160" align="center">
              <template slot-scope="scope">
                <el-row type="flex" align="middle">
                  <el-form-item style="margin-bottom: 0; width: 50%;"
                    :prop="'transportQuotations.' + scope.$index + '.weightScopeLeading'">
                    <el-input disabled v-model.trim="scope.row.weightScopeLeading"></el-input>
                  </el-form-item>
                  <span>~</span>
                  <el-form-item style="margin-bottom: 0; width: 50%;"
                    :prop="'transportQuotations.' + scope.$index + '.weightScopeAfter'">
                    <el-input disabled v-model.trim="scope.row.weightScopeAfter"></el-input>
                  </el-form-item>
                </el-row>
              </template>
            </u-table-column>
            <u-table-column label="Unit Price" min-width="100" align="center">
              <template slot-scope="scope">
                <el-form-item style="margin-bottom: 0;" :prop="'transportQuotations.' + scope.$index + '.unitPrice'">
                  <el-input disabled v-model.trim="scope.row.unitPrice"></el-input>
                </el-form-item>
              </template>
            </u-table-column>
            <u-table-column v-if="false" label="Opearter" align="center" min-width="80">
              <template slot-scope="scope">
                <i style="font-size: 18px; cursor: pointer; color: #65beff" class="el-icon-delete"
                  @click="handleDelete(scope.$index, scope.row.countryCode)"></i>
              </template>
            </u-table-column>
          </u-table>
          <!-- 添加 -->
          <div v-if="false" class="dialog-footer-add ">
            <i @click="kpiAdd" class="el-icon-circle-plus-outline cursor-on"></i>
            <excel-upload ref="tray" title="Tray upload" url="/bill/quotation/uploadTransportByExcel"
              temp-name="transport-upload.xlsx" temp-url="/admin/sys-file/local/transport-upload.xlsx"
              @refreshDataList="skuUploadExcel">
            </excel-upload>
            <!-- 上传 -->
            <el-button type="text" style="font-size: 28px;" icon="el-icon-upload" @click="$refs.tray.show()"></el-button>
          </div>
        </el-form>
      </el-tab-pane>
    </el-tabs>
    <div v-if="false" style="margin-top: 50px; display: flex; justify-content: center">
      <el-button type="primary" style="margin-right: 30px" @click="pre">上一步</el-button>
      <el-button type="primary" @click="next">下一步</el-button>
    </div>
  </div>
</template>
<script>
import ExcelUpload from "@/components/upload/excel"
import { remote } from '@/api/admin/dict'
import { mapGetters } from "vuex"
import { checkTransports, getTransportDetails } from "@/api/quotation"
export default {
  name: "FunctionArea",
  data() {
    let priceRule6 = (rule, value, callback) => {
      value = String(value)
      if (value.includes('.')) {
        value.indexOf('.') >= 7 ? callback(new Error('整数部分最大长度为6位')) : callback()
      } else {
        value.length >= 7 ? callback(new Error('整数部分最大长度为6位')) : callback()
      }
    }
    let priceRule2 = (rule, value, callback) => {
      value = String(value)
      if (!value.includes('.')) {
        value.length >= 3 ? callback(new Error('最大长度为2位')) : callback()
      }
    }
    return {
      newCountryFilters: [],
      // countryFilters: {
      //   form1: [],
      //   form2: []
      // }, //筛选table
      // countryArr: {
      //   form1: [],
      //   form2: []
      // },
      skuLoading: false,
      countryCodeSelect: [],
      urgentTypeList: [],
      dataListLoading: false,
      activeName: 'form1',
      form: {
        transportQuotationDto: [
          // 快递
          {
            transportQuotations: [
              {
                transportType: '',
                countryCode: '',
                // city: '',
                // scopeLeading: '',
                scopeAfter: '',
                weightScopeLeading: '',
                weightScopeAfter: '',
                unitPrice: '',
              }
            ]
          },
          // 托盘
          {
            transportQuotations: [
              {
                transportType: '',
                countryCode: '',
                // city: '',
                scopeLeading: '',
                scopeAfter: '',
                weightScopeLeading: '',
                weightScopeAfter: '',
                unitPrice: '',
              }
            ]
          },
        ]

      },
      rules: {
        countryCode: [
          { required: true, message: "此区域为必填项", trigger: "change" },
        ],
        // city: [
        //   { required: true, message: "此区域为必填项", trigger: "change" },
        // ],
        scopeLeading: [
          { required: true, message: "此区域为必填项", trigger: "change" },
          { pattern: /^[0-9]*$/, message: '请输入大于等于0的整数', trigger: 'change' },
          { validator: priceRule2, trigger: 'change' }
        ],
        scopeAfter: [
          { required: true, message: "此区域为必填项", trigger: "change" },
          { pattern: /^[0-9]*$/, message: '请输入大于等于0的整数', trigger: 'change' },
          { validator: priceRule2, trigger: 'change' }
        ],
        weightScopeLeading: [
          { required: true, message: "此区域为必填项", trigger: "change" },
          { pattern: /^[0-9]+([.]{1}[0-9]+){0,1}$/, message: '请输入大于等于0的整数或小数', trigger: 'change' }
        ],
        weightScopeAfter: [
          { required: true, message: "此区域为必填项", trigger: "change" },
          { pattern: /^[0-9]+([.]{1}[0-9]+){0,1}$/, message: '请输入大于等于0的整数或小数', trigger: 'change' }
        ],
        unitPrice: [
          { required: true, message: "此区域为必填项", trigger: "change" },
          { pattern: /^(([1-9]\d*)|([0][.]{1}[0-9]{0,2}[1-9]+)|([1-9]\d*[.]{1}[0-9]+))$/g, message: '请输入大于0的整数或小数', trigger: 'change' },
          { validator: priceRule6, trigger: 'change' },
        ],
      },

    };
  },

  async created() {
    if (this.propsForm) {
      this.combinationData()
    }

    await this.countryCode()
    // 给country加筛选条件
    await this.countryCodeSelect.forEach(i => this.newCountryFilters.push({ text: i.value, value: i.value }))
  },
  components: {
    ExcelUpload,
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  props: {
    propsForm: Array,
    newPropsForm: Array
  },
  methods: {
    // 国家代码下拉框
    async countryCode() {
      let { data } = await remote('country_code')
      this.countryCodeSelect = data.data
      // console.log('条件查询的下拉框数据', JSON.parse(JSON.stringify(this.countryCodeSelect)))
    },

    pre() {
      let activeNameArr = ['form1', 'form2']
      let activeIndex = activeNameArr.indexOf(this.activeName) - 1
      this.activeName != 'form1' ? this.activeName = activeNameArr[activeIndex] : this.$emit("pre");
    },

    next() {
      console.log('this.form.transportQuotationDto', JSON.parse(JSON.stringify(this.form.transportQuotationDto)))
      let activeNameArr = ['form1', 'form2']
      let activeIndex = activeNameArr.indexOf(this.activeName)
      this.form.transportQuotationDto[activeIndex].transportQuotations.forEach(i => this.activeName == 'form1' ? i.transportType = '1' : i.transportType = '2')
      // 快递和托盘页

      this.$refs[this.activeName].validate((valid) => {
        if (!valid) {
          this.$message.warning('Please fill in correctly')
          return false
        };
        if (this.activeName == 'form1') {
          // 校验数据是否填写正确
          checkTransports({ transportQuotations: this.form.transportQuotationDto[0].transportQuotations }).then(({ data }) => {
            if (data.code == 0) {
              activeIndex++
              this.activeName = 'form2'
            }
          }).catch((e) => { })

        } else if (this.activeName == 'form2') {
          // 校验数据是否填写正确
          checkTransports({ transportQuotations: this.form.transportQuotationDto[1].transportQuotations }).then(({ data }) => {
            if (data.code == 0) {
              this.$emit("formData", this.form, 'submit')
            }
          }).catch((e) => { })
        }
      })


      // if (activeIndex < activeNameArr.length) {
      //   // 快递和托盘页
      //   this.$refs[this.activeName].validate((valid) => {
      //     if (!valid) {
      //       this.$message.warning('Please fill in correctly')
      //       return false
      //     };
      //     activeIndex++
      //     console.log("🚀→→→→→ ~ activeIndex:", activeIndex)
      //     this.activeName = activeNameArr[activeIndex]
      //   })
      // } else {
      //   this.$refs[this.activeName].validate((valid) => {
      //     if (!valid) {
      //       this.$message.warning('Please fill in correctly')
      //       return false
      //     };
      //     this.$emit("formData", this.form, 'submit')
      //   })
      // }
    },
    //  添加
    kpiAdd() {
      if (this.activeName === 'form1') {
        this.form.transportQuotationDto[0].transportQuotations.push({
          transportType: '',
          countryCode: '',
          // city: '',
          // scopeLeading: '',
          scopeAfter: '',
          weightScopeLeading: '',
          weightScopeAfter: '',
          unitPrice: '',
        })
      } else {
        this.form.transportQuotationDto[1].transportQuotations.push({
          transportType: '',
          countryCode: '',
          // city: '',
          scopeLeading: '',
          scopeAfter: '',
          weightScopeLeading: '',
          weightScopeAfter: '',
          unitPrice: '',
        })
      }
      // 滚动条回到底部
      this.$nextTick(() => {
        setTimeout(() => {
          this.$refs[`multipleTable${this.activeName}`].scrollBottom()
        }, 10);
      })
      console.log('this.form', JSON.parse(JSON.stringify(this.form)))
    },
    // 整合数据
    combinationData(type = 'propsForm') {
      this.$nextTick(() => {
        this.form.transportQuotationDto = this[type]
        // this.form.transportQuotationDto[0].transportQuotations.forEach((i) => {
        //   let countryArr = this.countryArrSet('form1')
        //   if (!countryArr.includes(i.countryCode)) {
        //     this.countryArr.form1.push(i.countryCode)
        //     this.countryFilters.form1.push({ text: i.countryCode, value: i.countryCode })
        //   }
        // })
        // this.form.transportQuotationDto[1].transportQuotations.forEach((i) => {
        //   let countryArr = this.countryArrSet('form2')
        //   if (!countryArr.includes(i.countryCode)) {
        //     this.countryArr.form2.push(i.countryCode)
        //     this.countryFilters.form2.push({ text: i.countryCode, value: i.countryCode })
        //   }
        // })
      })
    },
    // 删除这一行
    handleDelete(index, countryCode) {
      let activeNameArr = ['form1', 'form2']
      let activeIndex = activeNameArr.indexOf(this.activeName)
      this.form.transportQuotationDto[activeIndex].transportQuotations.splice(index, 1)
      // 滚动条回滚
      this.scrollRollback()
      // 更新country的筛选项
      // this.setCountryLabel(countryCode, activeIndex)
    },
    // 滚动条回滚
    scrollRollback() {
      // 记录原来的滚动条位置
      let scrollTop = this.$refs[`multipleTable${this.activeName}`].$refs.singleTable.$refs.bodyWrapper.scrollTop;
      // 回到原来的滚动条位置
      this.$nextTick(() => {
        setTimeout(() => {
          this.$refs[`multipleTable${this.activeName}`].pagingScrollTopLeft(scrollTop, 0)
        }, 10);
      })
    },
    // 上传
    skuUploadExcel(response) {
      this.skuLoading = true
      console.log('上传快递或者托盘', JSON.parse(JSON.stringify(response)))
      let form1 = this.form.transportQuotationDto[0].transportQuotations
      let form2 = this.form.transportQuotationDto[1].transportQuotations
      if (response != 'loading') {
        if (response.code != 0) return this.skuLoading = false
        else {
          response.data.forEach(i => {
            // let countryArr = this.countryArrSet(this.activeName)
            // if (!countryArr.includes(i.countryCode)) {
            //   this.countryArr[this.activeName].push(i.countryCode)
            //   this.countryFilters[this.activeName].push({ text: i.countryCode, value: i.countryCode })
            // }
            // 上传补0
            let reg = /^[0-9]*$/

            if (reg.test(i.scopeAfter) && i.scopeAfter.length < 2) {
              i.scopeAfter = '0' + i.scopeAfter
            }
            if (reg.test(i.scopeLeading) && i.scopeLeading.length < 2) {
              i.scopeLeading = '0' + i.scopeLeading
            }

          })
          if (this.activeName === 'form1') {
            // 快递
            // 把返回的数据新增到表单中
            this.form.transportQuotationDto[0].transportQuotations = form1.concat(response.data)
          } else if (this.activeName === 'form2') {
            // 托盘
            // 把返回的数据新增到表单中
            this.form.transportQuotationDto[1].transportQuotations = form2.concat(response.data)
          }
          this.skuLoading = false
        }
      }
    },
    // 判断是否有未填的数据
    unfilledData(obj) {
      return Object.values(obj).every(i => {
        return !i
      })
    },
    // 切换新增时
    clear() {
      this.activeName = 'form1'
      this.form = this.$options.data().form
      this.$refs.form1.resetFields()
      this.$refs.form2.resetFields()
      // this.$refs.form3.resetFields()
      this.countryCode()
    },
    // 切换到编辑页面时
    assignment() {
      this.activeName = 'form1'
      this.combinationData('newPropsForm')
      this.countryCode()
    },
    // 处理手写zipcode补0
    zipCodeChange(e) {
      let reg = /^[0-9]*$/
      if (reg.test(e.target.value)) {
        e.target.value = e.target.value.length < 2 ? '0' + e.target.value : e.target.value
        e.target.dispatchEvent(new Event('input'))
      }
    },
    // 筛选table
    filterHandler(value, row, column) {
      const property = column['property'];
      return row[property] === value;
    },
    //去重country
    countryArrSet(type) {
      return [...new Set(this.countryArr[type])]
    },
    //  更新country的筛选项
    setCountryLabel(val, activeIndex) {
      let exist = this.form.transportQuotationDto[activeIndex].transportQuotations.findIndex(i => i.countryCode == val)
      if (exist == -1) {
        this.countryFilters[this.activeName] = this.countryFilters[this.activeName].filter(i => i.value != val)
        this.countryArr[this.activeName] = this.countryArr[this.activeName].filter(i => i != val)
      }
    },
    // country改变之后 
    countyrChange() {
      // let activeNameArr = ['form1', 'form2']
      // let activeIndex = activeNameArr.indexOf(this.activeName)
      // let response = this.form.transportQuotationDto[activeIndex].transportQuotations
      // this.countryArr[this.activeName] = []
      // this.countryFilters[this.activeName] = []
      // response.forEach(i => {
      //   let countryArr = this.countryArrSet(this.activeName)
      //   if (!countryArr.includes(i.countryCode)) {
      //     this.countryArr[this.activeName].push(i.countryCode)
      //     this.countryFilters[this.activeName].push({ text: i.countryCode, value: i.countryCode })
      //   }
      // })
    },
  },
};
</script>
<style lang="scss" scoped>
.content {
  width: 100%;

  ::v-deep .el-tabs__nav-scroll {
    padding: 0 20px;
    box-sizing: border-box;
    background-color: #edeff3;
  }

  // ::v-deep .el-tabs__item.is-active {
  //   color: #333;
  // }

  ::v-deep .el-tabs__active-bar {
    // background-color: #000;
    width: 0 !important;
  }

}

.transport {
  ::v-deep .el-form-item__content {
    margin-left: 0 !important;
  }
}

.dialog-footer-add {
  display: flex;
  justify-content: center;
  align-items: center;
  color: rgb(64, 149, 229);
  font-size: 25px;
  margin: 20px 0;
  gap: 15px;
}

.cursor-on {
  cursor: pointer;
}
</style>
