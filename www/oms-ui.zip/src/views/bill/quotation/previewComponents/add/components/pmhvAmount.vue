<template>
  <div>
    <el-form ref="form" :model="form" label-width="140px" :rules="rules">
      <el-table border ref="multipleTable" :data="form.pmhvQuotations" tooltip-effect="dark" class="pmhv"
        style="width: 100%" :header-cell-style="{ background: '#f5f7fa', color: '#606266' }">
        <el-table-column label="PMHV Type" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.pmhvType }}</template>
        </el-table-column>
        <el-table-column label="Qty" min-width="120" align="center">
          <template slot-scope="scope">
            <el-form-item style="margin-bottom: 0;" :prop="'pmhvQuotations.' + scope.$index + '.pmhvQty'">
              <el-input disabled v-model.trim="scope.row.pmhvQty" :maxlength="9"></el-input>
            </el-form-item>
          </template>
        </el-table-column>
        <el-table-column label="Unit Price" min-width="120" align="center">
          <template slot-scope="scope">
            <el-form-item style="margin-bottom: 0;" :prop="'pmhvQuotations.' + scope.$index + '.unitPrice'">
              <el-input disabled v-model.trim="scope.row.unitPrice"></el-input>
            </el-form-item>
          </template>
        </el-table-column>
      </el-table>
    </el-form>
  </div>
</template>
<script>
import { getPfepDataByQuery } from '@/api/pfepData'
export default {
  name: "PmhvAmount",
  data() {
    let priceRule8 = (rule, value, callback) => {
      value = String(value)
      if (value.includes('.')) {
        value.indexOf('.') >= 9 ? callback(new Error('整数部分最大长度为8位')) : callback()
      } else {
        value.length >= 9 ? callback(new Error('整数部分最大长度为8位')) : callback()
      }
    }
    return {
      form: {
        pmhvQuotations: [],
      },
      rules: {
        pmhvQty: [
          { required: true, message: "此区域为必填项", trigger: "change" },
          { pattern: /^\+?[1-9]\d*$/, message: '请输入大于0的整数', trigger: 'change' },
          // { max: 9, message: '最大为9位数', trigger: 'change' },
        ],
        unitPrice: [
          { required: true, message: "此区域为必填项", trigger: "change" },
          { pattern: /^(([1-9]\d*)|([0][.]{1}[0-9]{0,2}[1-9]+)|([1-9]\d*[.]{1}[0-9]+))$/g, message: '请输入大于0的整数或小数', trigger: 'change' },
          { validator: priceRule8, trigger: 'change' },
        ],
      },
      validForm: false,
      dataListLoading: false,
    };
  },
  created() {
    if (this.propsForm) {
      this.form.pmhvQuotations = this.propsForm
    } else {
      this.getRemote()
    }
  },
  props: {
    propsForm: Array,
    newPropsForm: Array,
  },
  methods: {
    async getRemote() {
      //fte type
      let arr = []
      let { data: fte } = await getPfepDataByQuery({ dataType: 'PMHV' })
      let fteTypeArr = fte.data.records
      fteTypeArr.forEach(i => arr.push({ pmhvType: i.name }))
      this.form.pmhvQuotations = arr
    },
    // 验证
    verify() {
      this.$refs.form.validate((valid) => {
        this.validForm = valid
        if (!valid) {
          this.$message.warning('Please fill in correctly')
          return false
        };
      })
    },
    // 切换新增时
    async clear() {
      this.form = this.$options.data().form
      this.getRemote()
    },
    // 切换到编辑页面时
    async assignment() {
      this.$nextTick(() => {
        setTimeout(() => {
          this.form.pmhvQuotations = this.newPropsForm
        }, 200)
      })
    },

  },
};
</script>
<style lang="scss" scoped>
.pmhv {
  ::v-deep .el-form-item__content {
    margin-left: 0 !important;
  }
}
</style>
