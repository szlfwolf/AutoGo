<template>
  <div>
    <el-form ref="form" :model="form" label-width="140px">
      <el-table border ref="multipleTable" :data="form.fixedAssetsQuotations" tooltip-effect="dark" class="fixed"
        style="width: 100%" :header-cell-style="{ background: '#f5f7fa', color: '#606266' }">
        <el-table-column label="Fixed assets" min-width="120" align="center">
          <template slot-scope="scope">
            <el-form-item style="margin-bottom: 0;" :prop="'fixedAssetsQuotations.' + scope.$index + '.fixedAssets'">
              <el-input disabled v-model.trim="scope.row.fixedAssets"></el-input>
            </el-form-item>
          </template>
        </el-table-column>
        <el-table-column label="Qty" min-width="120" align="center">
          <template slot-scope="scope">
            <el-form-item style="margin-bottom: 0;" :prop="'fixedAssetsQuotations.' + scope.$index + '.fixedAssetsQty'">
              <el-input disabled v-model.trim="scope.row.fixedAssetsQty" :maxlength="9"></el-input>
            </el-form-item>
          </template>
        </el-table-column>
        <el-table-column label="Investment" min-width="120" align="center">
          <template slot-scope="scope">
            <el-form-item style="margin-bottom: 0;" :prop="'fixedAssetsQuotations.' + scope.$index + '.investment'">
              <el-input disabled @blur="inputBlur(scope.row)" v-model.trim="scope.row.investment"></el-input>
            </el-form-item>
          </template>
        </el-table-column>
        <el-table-column label="Contribution Quota" min-width="140" align="center">
          <template slot-scope="scope">
            <el-form-item style="margin-bottom: 0;"
              :prop="'fixedAssetsQuotations.' + scope.$index + '.contributionQuota'">
              <el-input disabled @blur="inputBlur(scope.row)" v-model.trim="scope.row.contributionQuota"></el-input>
            </el-form-item>
          </template>
        </el-table-column>
        <el-table-column label="Start Date" min-width="150" align="center">
          <template slot-scope="scope">
            <el-form-item style="margin-bottom: 0;" :prop="'fixedAssetsQuotations.' + scope.$index + '.startDate'">
              <el-date-picker disabled style="width:100%" v-model="scope.row.startDate" value-format="yyyy-MM"
                type="month" placeholder="选择月">
              </el-date-picker>
            </el-form-item>
          </template>
        </el-table-column>
        <el-table-column label="Period" min-width="120" align="center">
          <template slot-scope="scope">
            <el-form-item style="margin-bottom: 0;" :prop="'fixedAssetsQuotations.' + scope.$index + '.period'">
              <el-input disabled v-model.trim="scope.row.period" :maxlength="9"></el-input>
            </el-form-item>
          </template>
        </el-table-column>
        <el-table-column v-if="false" label="Opearter" align="center" min-width="80">
          <template slot-scope="scope">
            <i style="font-size: 18px; cursor: pointer; color: #65beff" class="el-icon-delete"
              @click="handleDelete(scope.$index)"></i>
          </template>
        </el-table-column>
      </el-table>
    </el-form>
    <span v-if="false" slot="footer" class="dialog-footer box"
      style="font-size: 24px; color: #59a6f9; margin-bottom: 10px;display:flex;justify-content:center;margin-top:20px">
      <div>
        <i class="el-icon-circle-plus-outline" style="margin-right: 20px; cursor: pointer" @click="addRows()"></i>
      </div>
      <div></div>
    </span>
  </div>
</template>
<script>
export default {
  name: "FixedAssets",
  data() {
    let priceRule8 = (rule, value, callback) => {
      value = String(value)
      if (value.includes('.')) {
        value.indexOf('.') >= 9 ? callback(new Error('整数部分最大长度为8位')) : callback()
      } else {
        value.length >= 9 ? callback(new Error('整数部分最大长度为8位')) : callback()
      }
    }
    return {
      form: {
        fixedAssetsQuotations: [],
      },
      validForm: false,
      dataListLoading: false,
      // warehouseCode: [],
      fixedRules: {
        fixedAssets: [{ required: true, message: '此区域为必填项', trigger: "change" }],
        fixedAssetsQty: [
          { required: true, message: "此区域为必填项", trigger: "change" },
          { pattern: /^\+?[1-9]\d*$/, message: '请输入大于0的整数', trigger: 'change' },
          // { max: 9, message: '最大为9位数', trigger: 'change' },
        ],
        investment: [
          { pattern: /^\+?[1-9]\d*$/, message: '请输入大于0的整数', trigger: 'change' },
          {
            validator: (rule, value, callback) => {
              value = String(value)
              if (value.includes('.')) {

                if (value.indexOf('.') >= 9) {
                  callback(new Error())
                } else {
                  const reg = /(\d)/gi;
                  const result = rule.field.match(reg)[0]
                  value = +value
                  let text = +this.form.fixedAssetsQuotations[result].contributionQuota
                  if (isNaN(value)) {
                    callback(new Error())
                  }
                  if (!value || value < text) {
                    callback(new Error())
                  } else {
                    callback()
                  }
                }
              } else {

                if (value.length >= 9) {
                  callback(new Error())
                } else {
                  const reg = /(\d)/gi;
                  const result = rule.field.match(reg)[0]
                  value = +value
                  let text = +this.form.fixedAssetsQuotations[result].contributionQuota
                  if (isNaN(value)) {
                    callback(new Error())
                  }
                  if (!value || value < text) {
                    callback(new Error())
                  } else {
                    callback()
                  }
                }
              }

            }, trigger: 'blur'
          }
        ],
        contributionQuota: [
          { pattern: /^\+?[1-9]\d*$/, message: '请输入大于0的整数', trigger: 'change' },
          {
            validator: (rule, value, callback) => {
              value = String(value)
              if (value.includes('.')) {

                if (value.indexOf('.') >= 9) {
                  callback(new Error('整数部分最大长度为8位'))
                } else {
                  const reg = /(\d)/gi;
                  const result = rule.field.match(reg)[0]
                  value = +value
                  let text = +this.form.fixedAssetsQuotations[result].investment
                  if (isNaN(value)) {
                    callback(new Error())
                  }
                  if (!value || value > text) {
                    callback(new Error())
                  } else {
                    callback()
                  }
                }
              } else {

                if (value.length >= 9) {
                  callback(new Error('整数部分最大长度为8位'))
                } else {
                  const reg = /(\d)/gi;
                  const result = rule.field.match(reg)[0]
                  value = +value
                  let text = +this.form.fixedAssetsQuotations[result].investment
                  if (isNaN(value)) {
                    callback(new Error())
                  }
                  if (!value || value > text) {
                    callback(new Error())
                  } else {
                    callback()
                  }
                }
              }
            }, trigger: 'blur'
          }
        ],
        currency: [{ required: true, message: '此区域为必填项', trigger: "change" }],
        startDate: [{ required: true, message: '此区域为必填项', trigger: "change" }],
        period: [
          { required: true, message: "此区域为必填项", trigger: "change" },
          { pattern: /^\+?[1-9]\d*$/, message: '请输入大于0的整数', trigger: 'change' },
          // { max: 9, message: '最大为9位数', trigger: 'change' },
        ],
      }
    };
  },
  created() {
    if (this.propsForm) {
      this.form.fixedAssetsQuotations = this.propsForm
      // console.log("🚀→→→→→ ~ 传给fix的数据.", this.propsForm)
    }
    // console.log('fix页面的数据', this.form);
  },
  props: {
    propsForm: Array,
    newPropsForm: Array,

  },
  methods: {
    addRows() {
      this.form.fixedAssetsQuotations.push({})
    },
    // 删除这一行
    handleDelete(index) {
      this.form.fixedAssetsQuotations.splice(index, 1)
    },
    // 验证
    verify() {
      this.$refs.form.validate((valid) => {
        this.validForm = valid
        if (!valid) {
          this.$message.warning('Please fill in correctly')
          // this.$message.warning('Please fill in correctly')
          return false
        };
      })
    },
    inputBlur(row) {
      let str1 = String(row.investment)
      let str2 = String(row.contributionQuota)
      if (str1.includes('.') || str2.includes('.')) {
        if (str1.indexOf('.') >= 9 && str2.indexOf('.') >= 9) {
          this.$message.warning('整数部分最大长度为8位')
        } else {
          if (+str1 < +str2) {
            this.$message.warning('investment不可以小于contributionQuota')
          }
        }
      } else {
        if (str1.length >= 9 && str2.length >= 9) {
          this.$message.warning('整数部分最大长度为8位')
        } else {
          if (+str1 < +str2) {
            this.$message.warning('investment不可以小于contributionQuota')
          }
        }
      }

    },
    // 切换新增时
    async clear() {
      this.form = this.$options.data().form
    },
    // 切换到编辑页面时
    async assignment() {
      this.$nextTick(() => {
        this.form.fixedAssetsQuotations = this.newPropsForm
      })
    },

  },
};
</script>
<style lang="scss" scoped>
.fixed {
  ::v-deep .el-form-item__content {
    margin-left: 0 !important;
  }
}
</style>
