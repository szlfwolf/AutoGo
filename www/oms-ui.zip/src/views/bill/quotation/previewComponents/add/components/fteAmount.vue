<template>
  <div>
    <el-form ref="form" :model="form.fteOrderQuotation" label-width="250px">
      <el-form-item label="Quotation Type:" prop="quotationType">
        <el-radio-group disabled v-model="form.fteOrderQuotation.quotationType" v-for="(ite, index) in quotationType"
          :key="index">
          <el-radio :label="ite.value" style="margin-right:10px">{{ ite.label }}</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-table class="fte" border ref="multipleTable" :data="form.fteOrderQuotation.fteTypeQuotations"
        tooltip-effect="dark" :header-cell-style="{ background: '#f5f7fa', color: '#606266' }"
        v-if="form.fteOrderQuotation.quotationType === 'FTE'">
        <el-table-column label="FTE Type" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.fteType }}</template>
        </el-table-column>
        <el-table-column label="Qty" min-width="120" align="center">
          <template slot-scope="scope">
            <el-form-item style="margin-bottom: 0;" :prop="'fteTypeQuotations.' + scope.$index + '.fteQty'">
              <el-input disabled v-model.trim="scope.row.fteQty" :maxlength="8"></el-input>
            </el-form-item>
          </template>
        </el-table-column>
        <el-table-column label="Unit Price" min-width="120" align="center">
          <template slot-scope="scope">
            <el-form-item style="margin-bottom: 0;" :prop="'fteTypeQuotations.' + scope.$index + '.fteUnitPrice'">
              <el-input disabled v-model.trim="scope.row.fteUnitPrice"></el-input>
            </el-form-item>
          </template>
        </el-table-column>
      </el-table>
      <div v-else>
        <el-form-item label="Inbound Unit Price:" prop="inboundUnitPrice">
          <el-input disabled placeholder="Please enter unit price" v-model.trim="form.fteOrderQuotation.inboundUnitPrice"
            :maxlength="9">
            <template slot="append">{{ form.fteOrderQuotation.quotationType == 'MOQ' ? 'MOQ' : 'Line' }}</template>
          </el-input>
        </el-form-item>
        <el-form-item label="inbound inlanding Unit Price:" prop="inboundInlandingUnitPrice">
          <el-input disabled placeholder="Please enter unit price"
            v-model.trim="form.fteOrderQuotation.inboundInlandingUnitPrice" :maxlength="9">
            <template slot="append">{{ form.fteOrderQuotation.quotationType == 'MOQ' ? 'MOQ' : 'Line' }}</template>
          </el-input>
        </el-form-item>
        <el-form-item label="Inbound Minimum Price:" prop="inboundMinimumPrice">
          <el-input disabled placeholder="Please enter Minimum Price"
            v-model.trim="form.fteOrderQuotation.inboundMinimumPrice" :maxlength="9">
          </el-input>
        </el-form-item>
        <el-form-item label="Inbound Container Unit Price:" prop="inboundContainerUnitPrice">
          <el-input disabled placeholder="Please enter Labeling Price"
            v-model.trim="form.fteOrderQuotation.inboundContainerUnitPrice" :maxlength="9">
          </el-input>
        </el-form-item>
        <el-form-item label="Inbound Labeling Unit Price:" prop="inboundLabelingUnitPrice">
          <el-input disabled placeholder="Please enter Labeling Price"
            v-model.trim="form.fteOrderQuotation.inboundLabelingUnitPrice" :maxlength="9">
          </el-input>
        </el-form-item>
        <el-form-item label="Inbound Adm Unit Price:" prop="inboundAdminUnitPrice">
          <el-input disabled placeholder="Please enter Adm Price"
            v-model.trim="form.fteOrderQuotation.inboundAdminUnitPrice" :maxlength="9">
          </el-input>
        </el-form-item>
        <el-form-item label="Outbound Unit Price - Big:" prop="outboundUnitPriceBig">
          <el-input disabled placeholder="Please enter unit price"
            v-model.trim="form.fteOrderQuotation.outboundUnitPriceBig" :maxlength="9">
            <template slot="append">{{ form.fteOrderQuotation.quotationType == 'MOQ' ? 'MOQ' : 'Line' }}</template>
          </el-input>
        </el-form-item>
        <el-form-item label="Outbound Unit Price - Sm:" prop="outboundUnitPriceSm">
          <el-input disabled placeholder="Please enter unit price"
            v-model.trim="form.fteOrderQuotation.outboundUnitPriceSm" :maxlength="9">
            <template slot="append">{{ form.fteOrderQuotation.quotationType == 'MOQ' ? 'MOQ' : 'Line' }}</template>
          </el-input>
        </el-form-item>
        <el-form-item label="Loading Onto Truck Unit Price:" prop="outboundLoadingOntoTruck">
          <el-input disabled placeholder=" " v-model.trim="form.fteOrderQuotation.outboundLoadingOntoTruck"
            :maxlength="9">
          </el-input>
        </el-form-item>
        <el-form-item label="Loading Onto Truck Minimum Price:" prop="outboundLoadingOntoTruckMin">
          <el-input disabled placeholder=" " v-model.trim="form.fteOrderQuotation.outboundLoadingOntoTruckMin"
            :maxlength="9">
          </el-input>
        </el-form-item>
        <el-form-item label="Outbound Adm Unit Price:" prop="outboundAdminUnitPrice">
          <el-input disabled placeholder="Please enter Adm Price"
            v-model.trim="form.fteOrderQuotation.outboundAdminUnitPrice" :maxlength="9">
          </el-input>
        </el-form-item>
        <el-form-item label="Export C/D Min Price:" prop="exportCdMinPrice">
          <el-input disabled placeholder="Please enter Unit Price" v-model.trim="form.fteOrderQuotation.exportCdMinPrice"
            :maxlength="9">
          </el-input>
        </el-form-item>
        <el-form-item label="Hscode Threshold:" prop="hscodeThreshold">
          <el-input disabled placeholder="Please enter Unit Price" v-model.trim="form.fteOrderQuotation.hscodeThreshold"
            :maxlength="9">
          </el-input>
        </el-form-item>
        <el-form-item label="Hscode Unit Price:" prop="hscodeUnitPrice">
          <el-input disabled placeholder="Please enter Unit Price" v-model.trim="form.fteOrderQuotation.hscodeUnitPrice"
            :maxlength="9">
          </el-input>
        </el-form-item>
      </div>
    </el-form>
  </div>
</template>
<script>
import { getPfepDataByQuery } from '@/api/pfepData'
import { deepClone } from '@/util/util'
export default {
  name: "FteAmount",
  data() {
    let priceRule6 = (rule, value, callback) => {
      value = String(value)
      if (value.includes('.')) {
        value.indexOf('.') >= 7 ? callback(new Error('整数部分最大长度为6位')) : callback()
      } else {
        value.length >= 7 ? callback(new Error('整数部分最大长度为6位')) : callback()
      }
    }
    let priceRule8 = (rule, value, callback) => {
      value = String(value)
      if (value.includes('.')) {
        value.indexOf('.') >= 9 ? callback(new Error('整数部分最大长度为8位')) : callback()
      } else {
        value.length >= 9 ? callback(new Error('整数部分最大长度为8位')) : callback()
      }
    }
    let amountVerification = [
      { required: true, message: "此区域为必填项", trigger: "change" },
      { pattern: /^(([1-9]\d*)|([0][.]{1}[0-9]{0,2}[1-9]+)|([1-9]\d*[.]{1}[0-9]+))$/g, message: '请输入大于0的整数或小数', trigger: 'change' },
      { validator: priceRule6, trigger: 'change' },
    ]
    return {
      form: {
        fteOrderQuotation: {
          quotationType: "FTE",
          fteTypeQuotations: [],
        },


      },
      quotationType: [
        {
          label: "FTE",
          value: "FTE"
        },
        {
          label: "Order Line",
          value: "ORDERLINE"
        },
        // {
        //   label: "MOQ",
        //   value: "MOQ"
        // },
      ],
      dataListLoading: false,
      validForm: false,
      rules: {
        fteQty: [
          { required: true, message: "此区域为必填项", trigger: "change" },
          { pattern: /^\+?[1-9]\d*$/, message: '请输入大于0的整数', trigger: 'change' },
        ],
        quotationType: [{ required: true, message: "此区域为必填项", trigger: "change" },],
        fteUnitPrice: [
          { required: true, message: "此区域为必填项", trigger: "change" },
          { pattern: /^(([1-9]\d*)|([0][.]{1}[0-9]{0,2}[1-9]+)|([1-9]\d*[.]{1}[0-9]+))$/g, message: '请输入大于0的整数或小数', trigger: 'change' },
          { validator: priceRule8, trigger: 'change' },
        ],
        inboundMinimumPrice: amountVerification,
        inboundLabelingUnitPrice: amountVerification,
        inboundContainerUnitPrice: amountVerification,
        inboundAdminUnitPrice: amountVerification,
        inboundUnitPrice: amountVerification,
        inboundInlandingUnitPrice: amountVerification,
        outboundUnitPriceBig: amountVerification,
        outboundUnitPriceSm: amountVerification,
        // outboundMinimumPrice: amountVerification,
        outboundLoadingOntoTruck: amountVerification,
        outboundLoadingOntoTruckMin: amountVerification,
        outboundAdminUnitPrice: amountVerification,
        exportCdMinPrice: amountVerification,
        hscodeThreshold: amountVerification,
        hscodeUnitPrice: amountVerification,
        // outboundOtUnitPrice: amountVerification,
        // outboundAutoOt: [{ required: false, trigger: "change" }],
        // outboundDailyLinesLimit: [
        //   { required: true, message: "此区域为必填项", trigger: "change" },
        //   { pattern: /^\+?[1-9]\d*$/, message: '请输入大于0的整数', trigger: 'change' },
        // ],
        // outboundUnitPrice: [
        //   { required: true, message: "此区域为必填项", trigger: "change" },
        //   { pattern: /^\+?[1-9]\d*$/, message: '请输入大于0的整数', trigger: 'change' },
        //   { validator: priceRule6, trigger: 'change' },
        // ],
      },
    };
  },
  created() {
    this.getRemote()
  },
  props: {
    propsForm: Object,
    newPropsForm: Object,
  },
  methods: {
    async getRemote() {
      //fte type
      let arr = []
      let { data: fte } = await getPfepDataByQuery({ dataType: 'FTE' })
      let fteTypeArr = fte.data.records
      fteTypeArr.forEach(i => arr.push({ fteType: i.name }))
      if (this.propsForm.fteOrderQuotation || this.propsForm.fteTypeQuotations) {
        if (this.propsForm.fteOrderQuotation) {
          this.form.fteOrderQuotation = this.propsForm.fteOrderQuotation
          this.$set(this.form.fteOrderQuotation, 'fteTypeQuotations', arr)
        } else {
          this.$set(this.form.fteOrderQuotation, 'fteTypeQuotations', this.propsForm.fteTypeQuotations)
        }
      } else {
        this.$set(this.form.fteOrderQuotation, 'fteTypeQuotations', arr)
      }
      // console.log('FTE页面的数据', this.form);
    },
    // 验证
    verify() {
      this.$refs.form.validate((valid) => {
        this.validForm = valid
        if (!valid) {
          this.$message.warning('Please fill in correctly')
          return false
        };

      })
    },
    // 切换新增时
    async clear() {
      this.form = this.$options.data().form
      this.form.fteOrderQuotation.quotationType = "FTE"
      let arr = []
      let { data: fte } = await getPfepDataByQuery({ dataType: 'FTE' })
      let fteTypeArr = fte.data.records
      fteTypeArr.forEach(i => arr.push({ fteType: i.name }))
      this.$set(this.form.fteOrderQuotation, 'fteTypeQuotations', arr)
    },
    // 切换到编辑页面时
    async assignment() {
      let arr = []
      let { data: fte } = await getPfepDataByQuery({ dataType: 'FTE' })
      let fteTypeArr = fte.data.records
      fteTypeArr.forEach(i => arr.push({ fteType: i.name }))
      this.$nextTick(() => {
        if (!!this.newPropsForm.fteOrderQuotation) {
          this.form.fteOrderQuotation = this.newPropsForm.fteOrderQuotation
          this.$set(this.form.fteOrderQuotation, 'fteTypeQuotations', arr)
        } else {
          this.form.fteOrderQuotation = { quotationType: "FTE", },
            this.$set(this.form.fteOrderQuotation, 'fteTypeQuotations', this.newPropsForm.fteTypeQuotations)
        }
      })
    },
  },
};
</script>
<style lang="scss" scoped>
.fte {
  ::v-deep .el-form-item__content {
    margin-left: 0 !important;
  }
}
</style>
