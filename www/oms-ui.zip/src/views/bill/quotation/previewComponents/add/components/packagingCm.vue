<template>
  <div>
    <el-form ref="form" :model="form" label-width="140px">
      <el-table border ref="multipleTable" :data="form.packingCmQuotations" tooltip-effect="dark" class="packaging"
        style="width: 100%" :header-cell-style="{ background: '#f5f7fa', color: '#606266' }">
        <el-table-column label="Packaging CM Type" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.packingCmType }}</template>
        </el-table-column>
        <el-table-column label="Unit Price" min-width="120" align="center">
          <template slot-scope="scope">
            <el-form-item style="margin-bottom: 0;" :prop="'packingCmQuotations.' + scope.$index + '.unitPrice'">
              <el-input disabled v-model.trim="scope.row.unitPrice"></el-input>
            </el-form-item>
          </template>
        </el-table-column>
      </el-table>
    </el-form>
  </div>
</template>
<script>
import { getPfepDataByQuery } from '@/api/pfepData'
export default {
  name: "PackagingCm",
  data() {
    let priceRule8 = (rule, value, callback) => {
      value = String(value)
      if (value.includes('.')) {
        value.indexOf('.') >= 9 ? callback(new Error('整数部分最大长度为8位')) : callback()
      } else {
        value.length >= 9 ? callback(new Error('整数部分最大长度为8位')) : callback()
      }
    }
    return {
      form: {
        packingCmQuotations: [],
      },
      rules: {
        unitPrice: [
          { required: true, message: "此区域为必填项", trigger: "change" },
          { pattern: /^(([1-9]\d*)|([0][.]{1}[0-9]{0,2}[1-9]+)|([1-9]\d*[.]{1}[0-9]+))$/g, message: '请输入大于0的整数或小数', trigger: 'change' },
          { validator: priceRule8, trigger: 'change' },
        ],
      },
      validForm: false,
      dataListLoading: false,
    };
  },
  components: {
  },
  created() {
    if (this.propsForm) {
      this.form.packingCmQuotations = this.propsForm
      // console.log("🚀→→→→→ ~ 传给packCm的数据.", this.propsForm)
    } else {
      this.getRemote()
    }
    // console.log('packCm页面的数据', this.form);
  },
  props: {
    propsForm: Array,
    newPropsForm: Array,
  },
  methods: {
    async getRemote() {
      let arr = []
      let { data: pkg } = await getPfepDataByQuery({ dataType: 'Packaging CM' })
      let pkgArr = pkg.data.records
      pkgArr.forEach(i => arr.push({ packingCmType: i.name }))
      this.form.packingCmQuotations = arr
      // console.log("🚀→→→→→ ~ Packaging CM", arr)
    },
    // 验证
    verify() {
      this.$refs.form.validate((valid) => {
        this.validForm = valid
        if (!valid) {
          this.$message.warning('Please fill in correctly')
          return false
        };
      })
    },
    // 切换新增时
    async clear() {
      this.form = this.$options.data().form
      this.getRemote()
    },
    // 切换到编辑页面时
    async assignment() {
      this.$nextTick(() => {
        setTimeout(() => { this.form.packingCmQuotations = this.newPropsForm }, 200)
      })
    },

  },
};
</script>
<style lang="scss" scoped>
.packaging {
  ::v-deep .el-form-item__content {
    margin-left: 0 !important;
  }
}
</style>
