<template>
  <div class="content">
    <el-tabs v-model="activeName" @tab-click="handleClick">
      <el-tab-pane label="Storage" name="StorageAmount">
        <el-form ref="StorageAmount" :model="form">
          <el-table border ref="multipleTable" :data="form.storageQuotations" tooltip-effect="dark" style="width: 100%"
            v-loading="dataListLoading"
            :header-cell-style="{ background: '#f5f7fa', color: '#606266', 'text-align': 'center' }">

            <el-table-column label="Storage Type" align="center">
              <template slot-scope="scope">{{ scope.row.storageType }}</template>
            </el-table-column>

            <el-table-column label="Unit Price(Monthly)" align="center">
              <template slot-scope="scope">
                <el-form-item style="margin-bottom: 0" :prop="'storageQuotations.' + scope.$index + '.unitPrice'">
                  <el-input disabled placeholder="" v-model.trim="scope.row.unitPrice">
                    <template slot="append">{{ scope.row.storageType === 'Floor' ? '/ ㎡' : '/ PCS' }}</template>
                  </el-input>
                </el-form-item>
              </template>
            </el-table-column>

          </el-table>
        </el-form>
      </el-tab-pane>
      <el-tab-pane label="FTE" name="FteAmount">
        <FteAmount ref="FteAmount" :propsForm="propsForm" :newPropsForm="newPropsForm">
        </FteAmount>
      </el-tab-pane>
      <el-tab-pane label="PMHV" name="PmhvAmount">
        <PmhvAmount ref="PmhvAmount" :propsForm="propsForm.pmhvQuotations" :newPropsForm="newPropsForm.pmhvQuotations">
        </PmhvAmount>
      </el-tab-pane>
      <el-tab-pane label="Fixed assets" name="FixedAssetsAmount">
        <FixedAssetsAmount ref="FixedAssetsAmount" :propsForm="propsForm.fixedAssetsQuotations"
          :newPropsForm="newPropsForm.fixedAssetsQuotations"></FixedAssetsAmount>
      </el-tab-pane>
      <el-tab-pane label="Packaging CM" name="PackagingCm">
        <PackagingCm ref="PackagingCm" :propsForm="propsForm.packingCmQuotations"
          :newPropsForm="newPropsForm.packingCmQuotations"></PackagingCm>
      </el-tab-pane>
      <el-tab-pane label="Other" name="Other">
        <Other ref="Other" :propsForm="propsForm.otherQuotations" :newPropsForm="newPropsForm.otherQuotations"></Other>
      </el-tab-pane>
    </el-tabs>
    <div v-if="false" style="margin-top: 50px; display: flex; justify-content: center">
      <el-button type="primary" style="margin-right: 30px" @click="pre">上一步</el-button>
      <el-button type="primary" @click="next">下一步</el-button>
    </div>
  </div>
</template>
<script>
import FteAmount from "./components/fteAmount.vue"
import PmhvAmount from "./components/pmhvAmount.vue"
import FixedAssetsAmount from "./components/fixedAssets.vue"
import PackagingCm from "./components/packagingCm.vue"
import Other from "./components/other.vue"
import { getStorageTypeList } from '@/api/sku'
export default {
  name: "FunctionArea",
  data() {
    return {
      validForm: false,
      dataListLoading: false,
      form: {
        storageQuotations: []
      },
      activeName: 'StorageAmount',
      nameArr: ['StorageAmount', 'FteAmount', 'PmhvAmount', 'FixedAssetsAmount', 'PackagingCm', 'Other',],
      nameIndex: 0,
      rules: {
        unitPrice: [
          { required: true, message: '此区域为必填项', trigger: "change" },
          { pattern: /^(([1-9]\d*)|([0][.]{1}[0-9]{0,2}[1-9]+)|([1-9]\d*[.]{1}[0-9]+))$/g, message: '请输入大于0的整数或小数', trigger: 'change' },
          {
            validator: (rule, value, callback) => {
              value = String(value)
              if (value.includes('.')) {
                value.indexOf('.') >= 7 ? callback(new Error('整数部分最大长度为6位')) : callback()
              } else {
                value.length >= 7 ? callback(new Error('整数部分最大长度为6位')) : callback()
              }
            },
            trigger: 'change'
          },
        ]
      }
    };
  },
  components: {
    FteAmount,
    PmhvAmount,
    FixedAssetsAmount,
    PackagingCm,
    Other
  },
  props: {
    propsForm: Object,
    newPropsForm: Object,
  },
  created() {
    if (this.propsForm.clickType === 'add') {
      this.storageArr()
    } else {
      this.form.storageQuotations = this.propsForm.storageQuotations
      // console.log('主页面传给warehousingde的数据', JSON.parse(JSON.stringify(this.propsForm)))
    }
    // console.log('storage的数据', JSON.parse(JSON.stringify(this.form)))
  },
  methods: {
    //切换tab
    handleClick(e) {
      this.nameIndex = e.index
    },
    async storageArr() {
      let { data } = await getStorageTypeList()
      // console.log('data', JSON.parse(JSON.stringify(data)))
      if (!data.includes('Floor')) data.push('Floor')
      data.forEach(i => {
        this.form.storageQuotations.push({
          storageType: i,
          unitPrice: '',
        })
      });
    },
    // 上一步
    pre() {
      // console.log("🚀→→→→→ ~  this.nameIndex)", this.nameIndex)
      if (this.activeName === 'StorageAmount') {
        this.$emit("pre")
      } else {
        this.nameIndex--
        this.activeName = this.nameArr[this.nameIndex]
      }
    },
    // 下一步
    next() {
      let on = this.activeName === 'StorageAmount' ? this : this.$refs[this.activeName]
      on.verify()
      if (on.validForm) {
        if (this.nameIndex < this.nameArr.length - 1) {
          this.nameIndex++
          this.activeName = this.nameArr[this.nameIndex]
          console.log('上个表单数据', JSON.parse(JSON.stringify(on.form)))
          this.$emit("formData", on.form)
        } else {
          // 如果都填完整了就跳到下一页面
          this.$emit("formData", on.form)
          this.$emit("next")
        }
      }


    },
    // 验证
    verify() {
      this.$refs.StorageAmount.validate((valid) => {
        this.validForm = valid
        if (!valid) {
          this.$message.warning('Please fill in correctly')
          return false
        };
      })
    },
    // 切换新增时
    clear() {
      this.activeName = 'StorageAmount'
      this.nameIndex = 0
      this.form = this.$options.data().form
      this.storageArr()
      this.pageSwitching('clear')

    },
    // 切换到编辑页面时
    assignment() {
      this.activeName = 'StorageAmount'
      this.nameIndex = 0
      this.$nextTick(() => {
        this.form.storageQuotations = this.newPropsForm.storageQuotations
      })
      this.pageSwitching('assignment')
    },
    // 页面切换
    pageSwitching(type) {
      let arr = ['FteAmount', 'PmhvAmount', 'FixedAssetsAmount', 'PackagingCm', 'Other']
      let obj = {
        clear: () => {
          arr.forEach(i => this.$refs[i].clear())
        },
        assignment: () => {
          arr.forEach(i => this.$refs[i].assignment())
        },
      }
      return obj[type]()
    },
  },
};
</script>
<style lang="scss" scoped>
.content {
  width: 100%;

  ::v-deep .el-tabs__nav-scroll {
    padding: 0 20px;
    box-sizing: border-box;
    background-color: #edeff3;
  }

  // ::v-deep .el-tabs__item.is-active {
  //   color: #333;
  // }

  ::v-deep .el-tabs__active-bar {
    // background-color: #000;
    width: 0 !important;
  }

  // ::v-deep .el-tabs__item:hover {
  //   color: #000;
  // }

  ::v-deep .el-input-group__append {
    width: 70px;
    padding: 0;
    text-align: center;
  }
}
</style>
