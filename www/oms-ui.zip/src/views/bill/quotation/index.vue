<template>
  <div class="content">
    <el-card class="box-card">
      <el-row style="width: 200px; display: flex">
        <el-col>
          <el-button type="primary" icon="el-icon-search" @click="getList()">Query</el-button>
        </el-col>
        <el-col>
          <el-button icon="el-icon-refresh-left" @click="getReset">Reset</el-button>
        </el-col>
      </el-row>
      <el-form ref="form" :model="form" style="margin: 20px 0">
        <el-row :gutter="20">
          <el-col :span="4">
            <el-form-item prop="warehouseCode">
              <el-select filterable clearable v-model="form.warehouseCode" placeholder="Warehouse">
                <el-option v-for="item in warehouseArr" :key="item.warehouseCode" :label="item.warehouseName"
                  :value="item.warehouseCode"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item prop="warehouseCode">
              <el-date-picker v-model="form.timeFrame" type="monthrange" range-separator="至" start-placeholder="开始月份"
                end-placeholder="结束月份" value-format="yyyy-MM" @change="timeFrame">
              </el-date-picker>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div v-if="permissions.bill_quotation_save" class="down">
        <div>
          <el-button :disabled="customerPermissions" type="primary" @click="blAdd" style="padding: 5px 15px;">
            <span style="display: flex; align-items: center">
              <i class="el-icon-circle-plus-outline" style="margin-right: 5px; font-size: 20px"></i>Add
            </span>
          </el-button>
        </div>

      </div>
      <el-table border ref="multipleTable" :data="tableData.records" tooltip-effect="dark" style="width: 100%"
        v-loading="dataListLoading" :header-cell-style="{ background: '#f5f7fa', color: '#606266' }">
        <el-table-column label="Owner" min-width="80" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.clientCode }}</template>
        </el-table-column>
        <el-table-column label="Warehouse" min-width="80" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.warehouseCode }}</template>
        </el-table-column>
        <el-table-column label="Currency" min-width="80" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.currency }}</template>
        </el-table-column>
        <el-table-column label="StartDate" min-width="100" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.validTimeBegin }}</template>
        </el-table-column>
        <el-table-column label="EndDate" min-width="100" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.validTimeFinish }}</template>
        </el-table-column>
        <el-table-column label="Create time" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.createTime }}</template>
        </el-table-column>
        <el-table-column label="Create User" min-width="80" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.createBy }}</template>
        </el-table-column>
        <el-table-column label="Update time" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.updateTime }}</template>
        </el-table-column>
        <el-table-column label="Update User" min-width="80" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.updateBy }}</template>
        </el-table-column>
        <el-table-column label="Opearter" min-width="100" align="center">
          <template slot-scope="scope">
            <el-button :disabled="customerPermissions" type="text" icon="el-icon-edit" style="font-size: 18px"
              v-if="permissions.bill_quotation_update" @click="handleEdit(scope.row)"></el-button>
            <el-button :disabled="customerPermissions" type="text" icon="el-icon-delete" style="font-size: 18px"
              v-if="permissions.bill_quotation_del" @click="handleDelete(scope.row, scope.$index)"></el-button>
            <el-button type="text" icon="el-icon-view" style="font-size: 18px"
              @click="preview(scope.row, scope.$index)"></el-button>
          </template>
        </el-table-column>
      </el-table>
      <Pagination @handleSizeChange="handleSizeChange" @handleCurrentChange="handleCurrentChange"
        :pageNum="tableData.current" :pageSize="tableData.size" :total="tableData.total"></Pagination>
    </el-card>
  </div>
</template>
<script>
import Pagination from "@/components/pagination/pagination.vue";
import { mapGetters } from "vuex";
import ExcelUpload from "@/components/upload/excel";
import { getData, queryData, delObj, getQuotationDetails } from "@/api/quotation"
import { AddParentWarehouseCodes } from "@/api/quotation"
import { setStore } from '@/util/store';
let formParams = {
  warehouseCode: '',
  validTimeBegin: '',
  validTimeFinish: '',
  timeFrame: [],
};
export default {
  name: "Quatation",
  data() {
    return {
      customerPermissions: false,  //客户的权限如果是客户 Lux-mate 则不允许更改数据
      renovatePage: false,
      form: Object.assign({}, formParams),
      pageSize: '',
      pageCurrent: '1',
      centerDialogVisible: false,
      dataListLoading: false,
      tableData: [],
      warehouseArr: [],
    };
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  components: {
    Pagination,
    ExcelUpload
  },
  watch: {
    $route: function (to, from) {
      if (to.path == "/bill/quotation/index" && this.renovatePage) this.getList()

    },
  },
  created() {
    this.getList();
    this.eventBus.$on('query', () => this.renovatePage = true)
    this.customerPermissions = this.$store.state.common.commandName === 'Lux-mate'
  },
  methods: {
    //导入
    // handleRefreshChange() { },
    // //导出
    // exportExcel() {
    //   this.downBlobFile("/inbound/bl/exportBlByQuery", this.form, "bl.xlsx");
    // },
    //条数
    handleSizeChange(val) {
      this.pageSize = val
      let query = { current: this.pageCurrent, size: val }
      this.getList(query);
    },
    //当前页数
    handleCurrentChange(val) {
      this.pageCurrent = val
      let query = { current: val, size: this.pageSize }
      this.getList(query);
    },
    //清空
    getReset() {
      this.form = Object.assign({}, formParams);
      this.getList();
    },

    //数据列表
    async getList(params) {
      this.dataListLoading = true;
      let { data: warehouse } = await AddParentWarehouseCodes()
      this.warehouseArr = warehouse.data
      if (!params) {
        this.pageCurrent = 1
        this.pageSize = 10
        params = { current: this.pageCurrent, size: this.pageSize }
      }
      let query = Object.assign(this.form, params)
      queryData(query).then(({ data }) => {
        console.log('基础数据', JSON.parse(JSON.stringify(data.data.records)))
        if (data.code === 0) {
          this.tableData = data.data;
          this.dataListLoading = false;
        } else {
          this.$message.error(data.msg);
          this.dataListLoading = false;
        }
      }).catch(() => {
        this.$message.error("request was aborted");
        this.dataListLoading = false;
      });
      this.renovatePage = false
    },
    //new编辑
    handleEdit(row) {
      this.$router.push({
        path: "/addQuotation",
        query: {
          id: JSON.stringify(row.id)
        }
      })
    },
    //查看数据
    preview(row) {
      this.$router.push({
        path: "/previewQuotation",
        query: {
          id: JSON.stringify(row.id)
        }
      })
    },

    //删除
    handleDelete(row, index) {
      this.$confirm('This data may be in use, and the relevant bill data will also be deleted after deletion. Are you sure you want to delete it?', 'Tips', {
        confirmButtonText: 'submit',
        cancelButtonText: 'cancel',
        type: 'warning'
      }).then(() => {
        delObj(row.id).then(res => {
          if (res.data.code === 0) {
            this.getList();
            this.$message.success("Deleted succeeded");
          } else {
            this.$message.error(res.data.msg)
            this.centerDialogVisible = false;
          }
        })
      }).catch((e) => {
      });
    },
    //新增
    blAdd() {
      this.$router.push({
        path: "/addQuotation"
      })
    },
    // 选择时间范围查询
    timeFrame(val) {
      console.log("🚀→→→→→ ~ val", val)
      if (Array.isArray(val)) {
        this.form.validTimeBegin = val[0]
        this.form.validTimeFinish = val[1]
      } else {
        this.form.validTimeBegin = ''
        this.form.validTimeFinish = ''
      }

    },

  },
};
</script>
<style lang="scss" scoped>
.content {
  padding: 0 10px;

  .text {
    font-size: 14px;
  }

  .item {
    padding: 18px 0;
  }

  .box-card {
    width: 100%;
  }

  .down {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    border-top: 1px solid #999;
    padding-top: 20px;
    box-sizing: border-box;
  }

  .underLine {
    color: #599af8;
    text-decoration: underline;
    cursor: pointer;
  }

  ::v-deep .el-dialog {
    border-radius: 8px !important;
  }

  ::v-deep .el-select--small {
    display: block;
  }
}
</style>
