<template>
  <div>
    <el-form ref="form" :model="form" label-width="140px" :rules="fixedRules">
      <el-table border ref="multipleTable" :data="form.fixedAssetsQuotations" tooltip-effect="dark" class="fixed"
        style="width: 100%" :header-cell-style="{ background: '#f5f7fa', color: '#606266' }">
        <el-table-column label="Fixed assets" min-width="120" align="center">
          <template slot-scope="scope">
            <el-form-item style="margin-bottom: 0;" :prop="'fixedAssetsQuotations.' + scope.$index + '.fixedAssets'"
              :rules="fixedRules.fixedAssets">
              <el-input v-model.trim="scope.row.fixedAssets"></el-input>
            </el-form-item>
          </template>
        </el-table-column>
        <el-table-column label="Qty" min-width="120" align="center">
          <template slot-scope="scope">
            <el-form-item style="margin-bottom: 0;" :prop="'fixedAssetsQuotations.' + scope.$index + '.fixedAssetsQty'"
              :rules="fixedRules.fixedAssetsQty">
              <el-input v-model.trim="scope.row.fixedAssetsQty" :maxlength="9"></el-input>
            </el-form-item>
          </template>
        </el-table-column>
        <el-table-column label="Investment" min-width="120" align="center">
          <template slot-scope="scope">
            <el-form-item style="margin-bottom: 0;" :prop="'fixedAssetsQuotations.' + scope.$index + '.investment'"
              :rules="fixedRules.investment">
              <el-input @blur="inputBlur(scope.row)" v-model.trim="scope.row.investment"></el-input>
            </el-form-item>
          </template>
        </el-table-column>
        <el-table-column label="Contribution Quota" min-width="140" align="center">
          <template slot-scope="scope">
            <el-form-item style="margin-bottom: 0;" :prop="'fixedAssetsQuotations.' + scope.$index + '.contributionQuota'"
              :rules="fixedRules.contributionQuota">
              <el-input @blur="inputBlur(scope.row)" v-model.trim="scope.row.contributionQuota"></el-input>
            </el-form-item>
          </template>
        </el-table-column>

        <el-table-column label="Start Date" min-width="150" align="center">
          <template slot-scope="scope">
            <el-form-item style="margin-bottom: 0;" :prop="'fixedAssetsQuotations.' + scope.$index + '.startDate'"
              :rules="fixedRules.startDate">

              <el-date-picker style="width:100%" v-model="scope.row.startDate" value-format="yyyy-MM" type="month"
                placeholder="选择月">
              </el-date-picker>
            </el-form-item>
          </template>
        </el-table-column>
        <el-table-column label="Period" min-width="120" align="center">
          <template slot-scope="scope">
            <el-form-item style="margin-bottom: 0;" :prop="'fixedAssetsQuotations.' + scope.$index + '.period'"
              :rules="fixedRules.period">
              <el-input v-model.trim="scope.row.period" :maxlength="9"></el-input>
            </el-form-item>
          </template>
        </el-table-column>
        <el-table-column label="Opearter" align="center" min-width="80">
          <template slot-scope="scope">
            <i style="font-size: 18px; cursor: pointer; color: #65beff" class="el-icon-delete"
              @click="handleDelete(scope.$index)"></i>
          </template>
        </el-table-column>
      </el-table>
    </el-form>
    <span slot="footer" class="dialog-footer box"
      style="font-size: 24px; color: #59a6f9; margin-bottom: 10px;display:flex;justify-content:center;margin-top:20px">
      <div>
        <i class="el-icon-circle-plus-outline" style="margin-right: 20px; cursor: pointer" @click="addRows()"></i>
      </div>
      <div></div>
    </span>
  </div>
</template>
<script>
export default {
  name: "FixedAssets",
  data() {
    let priceRule8 = (rule, value, callback) => {
      if (this.submitData) {
        if (!value) callback(new Error('请全部填写或者全部为空'))
      }
      if (rule.field.includes('investment') && !!value) {
        value = String(value)
        if (value.includes('.')) {

          if (value.indexOf('.') >= 9) {
            callback(new Error())
          } else {
            const reg = /(\d)/gi;
            const result = rule.field.match(reg)[0]
            value = +value
            let text = +this.form.fixedAssetsQuotations[result].contributionQuota
            if (isNaN(value)) {
              callback(new Error())
            }
            if (!value || value < text) {
              callback(new Error())
            } else {
              callback()
            }
          }
        } else {
          if (value.length >= 9) {
            callback(new Error())
          } else {
            const reg = /(\d)/gi;
            const result = rule.field.match(reg)[0]
            value = +value
            let text = +this.form.fixedAssetsQuotations[result].contributionQuota
            if (isNaN(value)) {
              callback(new Error())
            }
            if (!value || value < text) {
              callback(new Error())
            } else {
              callback()
            }
          }
        }
      } else if (rule.field.includes('contributionQuota') && !!value) {
        value = String(value)
        if (value.includes('.')) {

          if (value.indexOf('.') >= 9) {
            callback(new Error('整数部分最大长度为8位'))
          } else {
            const reg = /(\d)/gi;
            const result = rule.field.match(reg)[0]
            value = +value
            let text = +this.form.fixedAssetsQuotations[result].investment
            if (isNaN(value)) {
              callback(new Error())
            }
            if (!value || value > text) {
              callback(new Error())
            } else {
              callback()
            }
          }
        } else {
          if (value.length >= 9) {
            callback(new Error('整数部分最大长度为8位'))
          } else {
            const reg = /(\d)/gi;
            const result = rule.field.match(reg)[0]
            value = +value
            let text = +this.form.fixedAssetsQuotations[result].investment
            if (isNaN(value)) {
              callback(new Error())
            }
            if (!value || value > text) {
              callback(new Error())
            } else {
              callback()
            }
          }
        }
      } else {
        callback()
      }

    }

    return {
      submitData: false,
      form: {
        fixedAssetsQuotations: [],
      },
      validForm: false,
      dataListLoading: false,
      // warehouseCode: [],
      fixedRules: {
        fixedAssets: [
          { validator: priceRule8, trigger: 'change' }
        ],
        fixedAssetsQty: [
          { pattern: /^\+?[0-9]\d*$/, message: '请输入大于等于0的整数', trigger: 'change' },
          { validator: priceRule8, trigger: 'change' }
        ],
        investment: [
          { pattern: /^\+?[0-9]\d*$/, message: '请输入大于等于0的整数', trigger: 'change' },
          { validator: priceRule8, trigger: 'blur' }
        ],
        contributionQuota: [
          { pattern: /^\+?[0-9]\d*$/, message: '请输入大于等于0的整数', trigger: 'change' },
          { validator: priceRule8, trigger: 'blur' }
        ],
        startDate: [
          { validator: priceRule8, trigger: 'change' }
        ],
        period: [
          { validator: priceRule8, trigger: 'change' },
          { pattern: /^\+?[0-9]\d*$/, message: '请输入大于等于0的整数', trigger: 'change' },

        ],
      },
      isTrue: false
    };
  },
  created() {
    if (this.propsForm) {
      this.form.fixedAssetsQuotations = this.propsForm
      // console.log("🚀→→→→→ ~ 传给fix的数据.", this.propsForm)
    }
    // console.log('fix页面的数据', this.form);
  },

  props: {
    propsForm: Array,
    newPropsForm: Array,

  },
  methods: {
    addRows() {
      this.form.fixedAssetsQuotations.push({
        investment: "",
        fixedAssets: "",
        fixedAssetsQty: "",
        contributionQuota: "",
        period: "",
        startDate: ""
      })

    },
    // 删除这一行
    handleDelete(index) {
      this.form.fixedAssetsQuotations.splice(index, 1)
    },
    // 验证
    verify() {
      let formData = []

      // console.log("🚀→→→→→ ~  this.form:", this.form)
      if (this.form.fixedAssetsQuotations != null) {
        this.form.fixedAssetsQuotations.forEach(i => formData.push(i.investment, i.fixedAssets, i.fixedAssetsQty, i.contributionQuota, i.period, i.startDate))
      } else {
        this.form.fixedAssetsQuotations = []
        formData = []
      }
      let someNext = Object.values(formData).some(i => i !== '' || i !== null)
      let everyNext = Object.values(formData).every(i => i !== '')
      console.log("🚀→→→→→ ~ fix  页面表单状态:", someNext, everyNext, formData)
      if (this.form.fixedAssetsQuotations.length > 0) {
        // 这是页面有填写但是没填完
        if (someNext && !everyNext) {
          this.submitData = true  //控制是否报红验证
          this.$refs.form.validate((valid) => {
            this.validForm = valid
            if (!valid) {
              // 跳转页面  $emit
              this.$emit('goComponents', 'FixedAssetsAmount')
              this.$emit('mergeData', this.form)
              this.$emit('tranCheck', 'FixedAssetsAmount', false)
              // this.$emit('verificationResults', 'FixedAssetsAmount', false)
              return false
            };

          })
          //页面都填完了然后校验数据是否符合规则
        } else if (someNext && everyNext) {
          this.submitData = false  //控制是否报红验证
          this.$refs.form.validate((valid) => {
            this.validForm = valid
            if (!valid) {
              // 跳转页面  $emit
              this.$emit('goComponents', 'FixedAssetsAmount')
              this.$emit('tranCheck', 'FixedAssetsAmount', false)
              // this.$emit('verificationResults', 'FixedAssetsAmount', false)
              return false
            };
            this.$emit('mergeData', this.form)
            this.$emit('tranCheck', 'FixedAssetsAmount', true)
            // this.$emit('verificationResults', 'FixedAssetsAmount', true)
          })

        } else {
          this.submitData = false  //控制是否报红验证
          this.$refs.form.validate((valid) => {
            this.validForm = valid
            this.$emit('deleteData', 'fixedAssetsQuotations')
            console.log(this.form,'this.form');
            this.$emit('mergeData', { ...this.form, FixedAssetsAmount: true })
            this.$emit('tranCheck', 'FixedAssetsAmount', true)
            // this.$emit('mergeData', this.form)
            // this.$emit('verificationResults', 'FixedAssetsAmount', true)
          })
        }
      } else {
        this.$emit('deleteData', 'fixedAssetsQuotations')
        console.log(this.form,'this.form');
        this.$emit('mergeData', { ...this.form, FixedAssetsAmount: "true" })
        this.$emit('tranCheck', 'FixedAssetsAmount', true)
      }

    },
    inputBlur(row) {
      let str1 = String(row.investment)
      let str2 = String(row.contributionQuota)
      if (str1.includes('.') || str2.includes('.')) {
        if (str1.indexOf('.') >= 9 && str2.indexOf('.') >= 9) {
          this.$message.warning('整数部分最大长度为8位')
        } else {
          if (+str1 < +str2) {
            this.$message.warning('investment不可以小于contributionQuota')
          }
        }
      } else {
        if (str1.length >= 9 && str2.length >= 9) {
          this.$message.warning('整数部分最大长度为8位')
        } else {
          if (+str1 < +str2) {
            this.$message.warning('investment不可以小于contributionQuota')
          }
        }
      }

    },
    // 切换新增时
    async clear() {
      this.form = this.$options.data().form
    },
    // 切换到编辑页面时
    async assignment() {
      this.$nextTick(() => {
        this.form.fixedAssetsQuotations = this.newPropsForm
      })
    },

  },
};
</script>
<style lang="scss" scoped>
.fixed {
  ::v-deep .el-form-item__content {
    margin-left: 0 !important;
  }
}
</style>
