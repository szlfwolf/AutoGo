<template>
  <div class="content">
    <el-tabs v-model="activeName" v-loading="skuLoading">
      <el-tab-pane label="快递" name="form1">
        <el-form ref="form1" :model="form.transportQuotationDto[0]" :rules="rules" label-width="130px">
          <u-table use-virtual max-height="400" border ref="multipleTableform1"
            :data="form.transportQuotationDto[0].transportQuotations" tooltip-effect="dark" class="transport"
            style="width: 100%" :header-cell-style="{ background: '#f5f7fa', color: '#606266' }">
            <u-table-column label="Country Code" min-width="120" align="center" prop="countryCode"
              column-key="countryCode" :filters="newCountryFilters" :filter-method="filterHandler">
              <template slot-scope="scope">
                <el-form-item style="margin-bottom: 0;" :prop="'transportQuotations.' + scope.$index + '.countryCode'"
                  :rules="rules.countryCode">
                  <el-select filterable clearable v-model.trim="scope.row.countryCode" placeholder=" ">
                    <el-option v-for="item in countryCodeSelect" :label="item.label" :value="item.value"
                      :key="item.value">
                    </el-option>
                  </el-select>
                </el-form-item>
              </template>
            </u-table-column>
            <u-table-column label="Urgent Type" min-width="100" align="center">
              <template slot-scope="scope">
                <el-form-item style="margin-bottom: 0;" :prop="'transportQuotations.' + scope.$index + '.urgentType'"
                  :rules="rules.urgentType">
                  <el-select filterable clearable v-model.trim="scope.row.urgentType" placeholder=" ">
                    <el-option v-for="item in urgentTypeList" :label="item.label" :value="item.value" :key="item.value">
                    </el-option>
                  </el-select>
                </el-form-item>
              </template>
            </u-table-column>

            <u-table-column label="Weight Scope (KG)" min-width="160" align="center">
              <template slot-scope="scope">
                <el-row type="flex" align="middle">
                  <el-form-item style="margin-bottom: 0; width: 50%;"
                    :prop="'transportQuotations.' + scope.$index + '.weightScopeLeading'"
                    :rules="rules.weightScopeLeading">
                    <el-input v-model.trim="scope.row.weightScopeLeading"></el-input>
                  </el-form-item>
                  <span>~</span>
                  <el-form-item style="margin-bottom: 0; width: 50%;"
                    :prop="'transportQuotations.' + scope.$index + '.weightScopeAfter'" :rules="rules.weightScopeAfter">
                    <el-input v-model.trim="scope.row.weightScopeAfter"></el-input>
                  </el-form-item>
                </el-row>
              </template>
            </u-table-column>
            <u-table-column label="Unit Price" min-width="100" align="center">
              <template slot-scope="scope">
                <el-form-item style="margin-bottom: 0;" :prop="'transportQuotations.' + scope.$index + '.unitPrice'"
                  :rules="rules.unitPrice">
                  <el-input v-model.trim="scope.row.unitPrice"></el-input>
                </el-form-item>
              </template>
            </u-table-column>
            <u-table-column v-if="form.transportQuotationDto[0].transportQuotations.length > 1" label="Opearter"
              align="center" min-width="80">
              <template slot-scope="scope">
                <i style="font-size: 18px; cursor: pointer; color: #65beff" class="el-icon-delete"
                  @click="handleDelete(scope.$index, scope.row.countryCode)"></i>
              </template>
            </u-table-column>
          </u-table>
          <!-- 添加 -->
          <div class="dialog-footer-add">
            <i @click="kpiAdd" class="el-icon-circle-plus-outline cursor-on"></i>
            <excel-upload ref="expressDelivery" title="Expressage upload" url="/bill/quotation/uploadTransportByExcel"
              temp-name="transport-upload-express.xlsx" temp-url="/admin/sys-file/local/transport-upload-express.xlsx"
              @refreshDataList="skuUploadExcel">
            </excel-upload>
            <!-- 上传 -->
            <el-button type="text" style="font-size: 28px;" icon="el-icon-upload"
              @click="$refs.expressDelivery.show()"></el-button>
          </div>
        </el-form>
      </el-tab-pane>

      <el-tab-pane label="托盘" name="form2">
        <el-form ref="form2" :model="form.transportQuotationDto[1]" :rules="rules" label-width="130px">
          <u-table use-virtual max-height="400" border ref="multipleTableform2"
            :data="form.transportQuotationDto[1].transportQuotations" tooltip-effect="dark" class="transport"
            style="width: 100%" :header-cell-style="{ background: '#f5f7fa', color: '#606266' }">
            <u-table-column label="Country Code" min-width="120" align="center" prop="countryCode"
              column-key="countryCode" :filters="newCountryFilters" :filter-method="filterHandler">
              <template slot-scope="scope">
                <el-form-item style="margin-bottom: 0;" :prop="'transportQuotations.' + scope.$index + '.countryCode'"
                  :rules="rules.countryCode">
                  <el-select filterable clearable v-model.trim="scope.row.countryCode" placeholder=" ">
                    <el-option v-for="item in countryCodeSelect" :label="item.label" :value="item.value"
                      :key="item.value">
                    </el-option>
                  </el-select>
                </el-form-item>
              </template>
            </u-table-column>
            <u-table-column label="Urgent Type" min-width="100" align="center">
              <template slot-scope="scope">
                <el-form-item style="margin-bottom: 0;" :prop="'transportQuotations.' + scope.$index + '.urgentType'"
                  :rules="rules.urgentType">
                  <el-select filterable clearable v-model.trim="scope.row.urgentType" placeholder=" ">
                    <el-option v-for="item in urgentTypeList" :label="item.label" :value="item.value" :key="item.value">
                    </el-option>
                  </el-select>
                </el-form-item>
              </template>
            </u-table-column>

            <u-table-column label="Zip code scope" min-width="160" align="center">
              <template slot-scope="scope">
                <el-row type="flex" align="middle">
                  <el-form-item style="margin-bottom: 0; width: 50%;"
                    :prop="'transportQuotations.' + scope.$index + '.scopeLeading'" :rules="rules.scopeLeading">
                    <el-input @change.native="zipCodeChange" v-model.trim="scope.row.scopeLeading"></el-input>
                  </el-form-item>
                  <span>~</span>
                  <el-form-item style="margin-bottom: 0; width: 50%;"
                    :prop="'transportQuotations.' + scope.$index + '.scopeAfter'" :rules="rules.scopeAfter">
                    <el-input @change.native="zipCodeChange" v-model.trim="scope.row.scopeAfter"></el-input>
                  </el-form-item>
                </el-row>
              </template>
            </u-table-column>
            <u-table-column label="Pallet Qty Scope" min-width="160" align="center">
              <template slot-scope="scope">
                <el-row type="flex" align="middle">
                  <el-form-item style="margin-bottom: 0; width: 50%;"
                    :prop="'transportQuotations.' + scope.$index + '.weightScopeLeading'"
                    :rules="rules.weightScopeLeading">
                    <el-input v-model.trim="scope.row.weightScopeLeading"></el-input>
                  </el-form-item>
                  <span>~</span>
                  <el-form-item style="margin-bottom: 0; width: 50%;"
                    :prop="'transportQuotations.' + scope.$index + '.weightScopeAfter'" :rules="rules.weightScopeAfter">
                    <el-input v-model.trim="scope.row.weightScopeAfter"></el-input>
                  </el-form-item>
                </el-row>
              </template>
            </u-table-column>
            <u-table-column label="Unit Price" min-width="100" align="center">
              <template slot-scope="scope">
                <el-form-item style="margin-bottom: 0;" :prop="'transportQuotations.' + scope.$index + '.unitPrice'"
                  :rules="rules.unitPrice">
                  <el-input v-model.trim="scope.row.unitPrice"></el-input>
                </el-form-item>
              </template>
            </u-table-column>
            <u-table-column v-if="form.transportQuotationDto[1].transportQuotations.length > 1" label="Opearter"
              align="center" min-width="80">
              <template slot-scope="scope">
                <i style="font-size: 18px; cursor: pointer; color: #65beff" class="el-icon-delete"
                  @click="handleDelete(scope.$index, scope.row.countryCode)"></i>
              </template>
            </u-table-column>
          </u-table>
          <!-- 添加 -->
          <div class="dialog-footer-add ">
            <i @click="kpiAdd" class="el-icon-circle-plus-outline cursor-on"></i>
            <excel-upload ref="tray" title="Tray upload" url="/bill/quotation/uploadTransportByExcel"
              temp-name="transport-upload-pallet.xlsx" temp-url="/admin/sys-file/local/transport-upload-pallet.xlsx"
              @refreshDataList="skuUploadExcel">
            </excel-upload>
            <!-- 上传 -->
            <el-button type="text" style="font-size: 28px;" icon="el-icon-upload" @click="$refs.tray.show()"></el-button>
          </div>
        </el-form>
      </el-tab-pane>
    </el-tabs>

  </div>
</template>
<script>
import ExcelUpload from "@/components/upload/excel"
import { remote } from '@/api/admin/dict'
import { mapGetters } from "vuex"
import { deepClone } from '@/util/util'
import { checkTransports, getTransportDetails } from "@/api/quotation"
export default {
  name: "FunctionArea",
  data() {
    let priceRule6 = (rule, value, callback) => {
      if (value) {
        this.$emit('thresholdDefault', true)
      } else {
        this.$emit('thresholdDefault', false)
      }

      if (rule.field.includes('unitPrice') && !!value) {
        value = String(value)
        if (value.includes('.')) {
          value.indexOf('.') >= 7 ? callback(new Error('整数部分最大长度为6位')) : callback()
        } else {
          value.length >= 7 ? callback(new Error('整数部分最大长度为6位')) : callback()
        }
      } else if ((rule.field.includes('scopeAfter') || rule.field.includes('scopeLeading')) && !!value) {

        if (this.submitData) {
          if (!value) callback(new Error('请全部填写或者全部为空'))
        }
        value = String(value)
        if (!value.includes('.')) {
          value.length >= 3 ? callback(new Error('最大长度为2位')) : callback()
        }

      } else if (this.activeName == 'form1') {
        if ((rule.field.includes('weightScopeLeading') || rule.field.includes('weightScopeAfter')) && !!value) {
          let reg = /^[0-9]+([.]{1}[0-9]+){0,1}$/
          if (reg.test(value)) {
            callback()
          } else {
            callback(new Error('请输入大于等于0的整数或小数'))
          }
        }

      } else if (this.activeName == 'form2') {
        if ((rule.field.includes('weightScopeLeading') || rule.field.includes('weightScopeAfter')) && !!value) {
          let reg = /^\+?[1-9]\d*$/
          if (reg.test(value)) {
            callback()
          } else {
            callback(new Error('请输入大于0的整数'))
          }
        }

      } else {
        callback()
      }
      if (this.submitData) {
        if (!value) {
          this.$emit('activeChange', 2)
          callback(new Error('请全部填写或者全部为空'))
        }
      } else {
        callback()
      }
    }

    return {
      verifyFlag: true,
      selectSubArr: [],
      dataPost: null,
      validForm: false,
      isNextform1: '',
      isNextform2: '',
      submitData: false,
      newCountryFilters: [],
      skuLoading: false,
      countryCodeSelect: [],
      urgentTypeList: [],
      dataListLoading: false,
      activeName: 'form1',
      form: {
        transportQuotationDto: [
          // 快递
          {
            transportQuotations: [
              {
                transportType: '',
                countryCode: '',
                urgentType: '',
                weightScopeLeading: '',
                weightScopeAfter: '',
                unitPrice: '',
              }
            ]
          },
          // 托盘
          {
            transportQuotations: [
              {
                transportType: '',
                countryCode: '',
                urgentType: '',
                scopeLeading: '',
                scopeAfter: '',
                weightScopeLeading: '',
                weightScopeAfter: '',
                unitPrice: '',
              }
            ]
          },
        ]

      },
      rules: {
        countryCode: [
          { validator: priceRule6, trigger: 'change' },
        ],
        urgentType: [
          { validator: priceRule6, trigger: 'change' },
        ],
        scopeLeading: [
          { pattern: /^[0-9]*$/, message: '请输入大于等于0的整数', trigger: 'change' },
          { validator: priceRule6, trigger: 'change' }
        ],
        scopeAfter: [
          { pattern: /^[0-9]*$/, message: '请输入大于等于0的整数', trigger: 'change' },
          { validator: priceRule6, trigger: 'change' }
        ],
        weightScopeLeading: [
          { validator: priceRule6, trigger: 'change' },
          // { pattern: /^[0-9]+([.]{1}[0-9]+){0,1}$/, message: '请输入大于等于0的整数或小数', trigger: 'change' }
        ],
        weightScopeAfter: [
          { validator: priceRule6, trigger: 'change' },
          // { pattern: /^[0-9]+([.]{1}[0-9]+){0,1}$/, message: '请输入大于等于0的整数或小数', trigger: 'change' }
        ],
        unitPrice: [
          { pattern: /^(([1-9]\d*)|([0][.]{1}[0-9]{0,2}[1-9]+)|([1-9]\d*[.]{1}[0-9]+))$/g, message: '请输入大于0的整数或小数', trigger: 'change' },
          { validator: priceRule6, trigger: 'change' },
        ],
      },

    };
  },

  async created() {
    if (this.propsForm) {
      this.combinationData()
    }

    await this.countryCode()
    // 给country加筛选条件
    await this.countryCodeSelect.forEach(i => this.newCountryFilters.push({ text: i.value, value: i.value }))
  },
  components: {
    ExcelUpload,
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  props: {
    propsForm: Array,
    newPropsForm: Array
  },
  methods: {
    // 国家代码下拉框
    async countryCode() {
      let { data } = await remote('country_code')
      this.countryCodeSelect = data.data
      let { data: urgentType } = await remote('urgent_level')
      console.log("🚀→→→→→ ~ urgentType:", urgentType)
      this.urgentTypeList = urgentType.data
    },

    // 跳转页面
    goComponents(val) {
      this.$emit('activeChange', 2)
      this.activeName = val
    },
    goPage(formName, formData) {
      let someNext = Object.values(formData).some(i => i === 0 || i)
      let everyNext = Object.values(formData).every(i => i === 0 || i)
      console.log("🚀→→→→→ ~ trna 页面表单状态:", someNext, everyNext, formData)
      // 这是页面有填写但是没填完
      if (someNext && !everyNext) {
        if (formName == 'form1') {
          this.isNextform1 = 'form1No'
        }
        if (formName == 'form2') {
          this.isNextform2 = 'form2No'
        }
        this.submitData = true  //控制是否报红验证
        this.$refs[formName].validate((valid) => {
          this.validForm = valid
          if (!valid) {
            this.goComponents(formName)

            return false
          };
        })
        //页面都填完了然后校验数据是否符合规则
      } else if (someNext && everyNext) {
        this.submitData = false  //控制是否报红验证
        this.$refs[formName].validate((valid) => {
          this.validForm = valid
          if (!valid) {
            if (formName == 'form1') {
              this.isNextform1 = 'form1No'
            }
            if (formName == 'form2') {
              this.isNextform2 = 'form2No'
            }
            this.goComponents(formName)
            return false
          };
          if (formName == 'form1') {
            this.isNextform1 = 'form1'
          }
          if (formName == 'form2') {
            this.isNextform2 = 'form2'
          }

        })

      } else {
        this.submitData = false  //控制是否报红验证
        this.$refs[formName].validate((valid) => {
          this.validForm = valid
          if (formName == 'form1') {
            this.isNextform1 = ''
          }
          if (formName == 'form2') {
            this.isNextform2 = ''
          }
        })
      }
    },
    verify() {
      // 如果都通过验证就进行下一步
      this.dataPost = deepClone(this.form)
      if (this.isNextform1 == 'form1') {
        let paramsData = deepClone(this.form.transportQuotationDto[0].transportQuotations)  //要提交的数据
        paramsData.forEach(item => item.transportType = '1')
        this.dataPost.transportQuotationDto[0].transportQuotations = paramsData
        checkTransports({ transportQuotations: paramsData }).then(({ data }) => {
          if (data.code == 0) {
            // 合并数据
            this.verifyFlag = false
            this.$emit('formData', this.dataPost)
            if (!this.isNextform2) {
              this.dataPost.transportQuotationDto[1].transportQuotations = []
              this.$emit('formData', this.dataPost)
              this.$emit('submitPost')
              console.log('  快递校验通过，运输未填写');
            } else {
              this.activeName = 'form2'
            }
          }
        }).catch((e) => {
          this.verifyFlag = true
          this.activeName = 'form1'
          console.log('  快递校验未通过');
          return false
        })

      } else if (this.isNextform1 == 'form1No') {
        this.activeName = 'form1'
        return false
      }
      if (this.isNextform2 == 'form2') {
        let paramsData = deepClone(this.form.transportQuotationDto[1].transportQuotations)  //要提交的数据
        paramsData.forEach(item => item.transportType = '2')
        this.dataPost.transportQuotationDto[1].transportQuotations = paramsData
        checkTransports({ transportQuotations: paramsData }).then(({ data }) => {
          if (data.code == 0) {
            // 合并数据
            this.$emit('formData', this.dataPost)
            if (!this.isNextform1) {
              this.dataPost.transportQuotationDto[0].transportQuotations = []
              this.$emit('formData', this.dataPost)
              this.$emit('submitPost')
              console.log('  运输校验通过，快递未填写');
            } if (this.isNextform1 == 'form1No') {
              this.activeName = 'form1'
            } else {
              setTimeout(() => { this.verifyFlag ? this.activeName = 'form1' : this.$emit('submitPost') }, 100)
            }
          }
        }).catch((e) => {
          console.log('  运输校验未通过');
          this.activeName = 'form2'
          return false
        })
      } else if (this.isNextform2 == 'form2No') {
        this.activeName = 'form2'
        return false
      }

      if (!this.isNextform1 && !this.isNextform2) {
        // 如果运输和托盘都为空 也可以提交
        this.deleteData('transportQuotationDto')
        this.$emit('submitPost')
        console.log("🚀→→→→→ ~ 如果运输和托盘都为空也可以提交 ",)
      }
    },


    next() {
      // 验证
      let activeNameArr = ['form1', 'form2']
      // 循环这两个大表单
      for (let item of activeNameArr) {
        if (item === 'form1') {
          let formData = []
          this.form.transportQuotationDto[0].transportQuotations.forEach(i => formData.push(i.countryCode, i.weightScopeLeading, i.weightScopeAfter, i.unitPrice))
          this.goPage(item, formData)
        } else if (item === 'form2') {
          let formData = []
          this.form.transportQuotationDto[1].transportQuotations.forEach(i => formData.push(i.countryCode, i.scopeLeading, i.scopeAfter, i.weightScopeLeading, i.weightScopeAfter, i.unitPrice))
          this.goPage(item, formData)
        }
      }
      // 最后的提交 
      this.verify()

    },
    //  添加
    kpiAdd() {
      if (this.activeName === 'form1') {
        this.form.transportQuotationDto[0].transportQuotations.push({
          transportType: '',
          countryCode: '',
          urgentType: '',
          weightScopeLeading: '',
          weightScopeAfter: '',
          unitPrice: '',
        })
      } else {
        this.form.transportQuotationDto[1].transportQuotations.push({
          transportType: '',
          countryCode: '',
          urgentType: '',
          scopeLeading: '',
          scopeAfter: '',
          weightScopeLeading: '',
          weightScopeAfter: '',
          unitPrice: '',
        })
      }
      // 滚动条回到底部
      this.$nextTick(() => {
        setTimeout(() => {
          this.$refs[`multipleTable${this.activeName}`].scrollBottom()
        }, 10);
      })
      console.log('this.form', JSON.parse(JSON.stringify(this.form)))
    },
    // 整合数据
    combinationData(type = 'propsForm') {
      this.$nextTick(() => {
        this.form.transportQuotationDto = this[type]
      })
    },
    // 删除这一行
    handleDelete(index, countryCode) {
      let activeNameArr = ['form1', 'form2']
      let activeIndex = activeNameArr.indexOf(this.activeName)
      this.form.transportQuotationDto[activeIndex].transportQuotations.splice(index, 1)
      // 滚动条回滚
      this.scrollRollback()
      // 更新country的筛选项
      // this.setCountryLabel(countryCode, activeIndex)
    },
    // 滚动条回滚
    scrollRollback() {
      // 记录原来的滚动条位置
      let scrollTop = this.$refs[`multipleTable${this.activeName}`].$refs.singleTable.$refs.bodyWrapper.scrollTop;
      // 回到原来的滚动条位置
      this.$nextTick(() => {
        setTimeout(() => {
          this.$refs[`multipleTable${this.activeName}`].pagingScrollTopLeft(scrollTop, 0)
        }, 10);
      })
    },
    // 上传
    skuUploadExcel(response) {
      this.skuLoading = true
      console.log('上传快递或者托盘', JSON.parse(JSON.stringify(response)))
      let form1 = this.form.transportQuotationDto[0].transportQuotations
      let form2 = this.form.transportQuotationDto[1].transportQuotations
      if (response != 'loading') {
        if (response.code != 0) return this.skuLoading = false
        else {
          response.data.forEach(i => {
            // 上传补0
            let reg = /^[0-9]*$/

            if (reg.test(i.scopeAfter) && i.scopeAfter.length < 2) {
              i.scopeAfter = '0' + i.scopeAfter
            }
            if (reg.test(i.scopeLeading) && i.scopeLeading.length < 2) {
              i.scopeLeading = '0' + i.scopeLeading
            }

          })
          if (this.activeName === 'form1') {
            // 快递
            // 把返回的数据新增到表单中
            this.form.transportQuotationDto[0].transportQuotations = form1.concat(response.data)
          } else if (this.activeName === 'form2') {
            // 托盘
            // 把返回的数据新增到表单中
            this.form.transportQuotationDto[1].transportQuotations = form2.concat(response.data)
          }
          this.skuLoading = false
        }
      }
    },
    // 判断是否有未填的数据
    unfilledData(obj) {
      return Object.values(obj).every(i => {
        return !i
      })
    },
    // 切换新增时
    clear() {
      this.activeName = 'form1'
      this.form = this.$options.data().form
      this.$refs.form1.resetFields()
      this.$refs.form2.resetFields()
      this.countryCode()
    },
    // 切换到编辑页面时
    assignment() {
      this.activeName = 'form1'
      this.combinationData('newPropsForm')
      this.countryCode()
    },
    // 处理手写zipcode补0
    zipCodeChange(e) {
      let reg = /^[0-9]*$/
      if (reg.test(e.target.value) && e.target.value) {
        e.target.value = e.target.value.length < 2 ? '0' + e.target.value : e.target.value
        e.target.dispatchEvent(new Event('input'))
      }
    },
    // 筛选table
    filterHandler(value, row, column) {
      const property = column['property'];
      return row[property] === value;
    },
    //去重country
    countryArrSet(type) {
      return [...new Set(this.countryArr[type])]
    },
    //  更新country的筛选项
    setCountryLabel(val, activeIndex) {
      let exist = this.form.transportQuotationDto[activeIndex].transportQuotations.findIndex(i => i.countryCode == val)
      if (exist == -1) {
        this.countryFilters[this.activeName] = this.countryFilters[this.activeName].filter(i => i.value != val)
        this.countryArr[this.activeName] = this.countryArr[this.activeName].filter(i => i != val)
      }
    },
    // country改变之后 
    countyrChange() {
    },
    //  修改的时候如果什么都没填写 就删掉这项数据
    deleteData(val) {
      this.$emit('deleteDataChange', val)
    },
  },
};
</script>
<style lang="scss" scoped>
.content {
  width: 100%;

  ::v-deep .el-tabs__nav-scroll {
    padding: 0 20px;
    box-sizing: border-box;
    background-color: #edeff3;
  }


  ::v-deep .el-tabs__active-bar {
    // background-color: #000;
    width: 0 !important;
  }

}

.transport {
  ::v-deep .el-form-item__content {
    margin-left: 0 !important;
  }
}

.dialog-footer-add {
  display: flex;
  justify-content: center;
  align-items: center;
  color: rgb(64, 149, 229);
  font-size: 25px;
  margin: 20px 0;
  gap: 15px;
}

.cursor-on {
  cursor: pointer;
}
</style>
