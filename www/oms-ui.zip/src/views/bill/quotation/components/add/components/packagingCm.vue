<template>
  <div>
    <el-form ref="form" :model="form" label-width="140px">
      <el-table border ref="multipleTable" :data="form.packingCmQuotations" tooltip-effect="dark" class="packaging"
        style="width: 100%" :header-cell-style="{ background: '#f5f7fa', color: '#606266' }">
        <el-table-column label="Packaging CM Type" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.packingCmType }}</template>
        </el-table-column>
        <el-table-column label="Unit Price" min-width="120" align="center">
          <template slot-scope="scope">
            <el-form-item style="margin-bottom: 0;" :prop="'packingCmQuotations.' + scope.$index + '.unitPrice'"
              :rules="rules.unitPrice">
              <el-input v-model.trim="scope.row.unitPrice"></el-input>
            </el-form-item>
          </template>
        </el-table-column>
      </el-table>
    </el-form>
  </div>
</template>
<script>
import { getPfepDataByQuery } from '@/api/pfepData'
export default {
  name: "PackagingCm",
  data() {
    let priceRule8 = (rule, value, callback) => {
      if (this.submitData) {
        if (!value) callback(new Error('请全部填写或者全部为空'))
      }
      value = String(value)
      if (value.includes('.')) {
        value.indexOf('.') >= 9 ? callback(new Error('整数部分最大长度为8位')) : callback()
      } else {
        value.length >= 9 ? callback(new Error('整数部分最大长度为8位')) : callback()
      }
    }
    return {
      submitData: false,
      form: {
        packingCmQuotations: [],
      },
      rules: {
        unitPrice: [
          { pattern: /^(([0-9]\d*)|([0][.]{1}[0-9]{0,2}[1-9]+)|([1-9]\d*[.]{1}[0-9]+))$/g, message: '请输入大于等于0的整数或小数', trigger: 'change' },
          { validator: priceRule8, trigger: 'change' },
        ],
      },
      validForm: false,
      dataListLoading: false,
      isTrue: false
    };
  },
  components: {
  },
  async created() {
    if (this.propsForm) {
      this.form.packingCmQuotations = this.propsForm
      // console.log("🚀→→→→→ ~ 传给packCm的数据.", this.propsForm)
    } else {
      await this.getRemote();
      if(this.isTrue){
        await this.assignment();
      }
      
    }
    // console.log('packCm页面的数据', this.form);
  },
  props: {
    propsForm: Array,
    newPropsForm: Array,
  },
  methods: {
    async getRemote() {
      let arr = []
      let { data: pkg } = await getPfepDataByQuery({ dataType: 'Packaging CM' })
      let pkgArr = pkg.data.records
      pkgArr.forEach(i => arr.push({ packingCmType: i.name, unitPrice: '' }))
      this.form.packingCmQuotations = arr
      // console.log("🚀→→→→→ ~ Packaging CM", arr)
    },
    // 验证
    verify() {
      let formData = []
      if (this.form.packingCmQuotations != null) {
        this.form.packingCmQuotations.forEach(i => formData.push(i.unitPrice))
      } else {
        this.form.packingCmQuotations = []
        formData = []
      }
      // 如果  someNext 是true的话说明页面有内容
      let someNext = Object.values(formData).some(i => i !== '' && i !== null)
      // 如果  everyNext 是true的话说明页面的内容都填好了
      let everyNext = Object.values(formData).every(i => i !== '' && i !== null)
      console.log("🚀→→→→→ ~ packagingCm  页面表单状态:", someNext, everyNext, formData)
      // 这是页面有填写但是没填完
      if (someNext && !everyNext) {
        this.submitData = true  //控制是否报红验证
        this.$refs.form.validate((valid) => {
          this.validForm = valid
          if (!valid) {
            // 跳转页面  $emit
            this.$emit('goComponents', 'PackagingCm')
            this.$emit('tranCheck', 'PackagingCm', false)
            // this.$emit('verificationResults','PackagingCm',false)
            return false
          };
        })
        //页面都填完了然后校验数据是否符合规则
      } else if (someNext && everyNext) {
        this.submitData = false  //控制是否报红验证
        this.$refs.form.validate((valid) => {
          this.validForm = valid
          if (!valid) {
            // 跳转页面  $emit
            this.$emit('goComponents', 'PackagingCm')
            this.$emit('tranCheck', 'PackagingCm', false)
            // this.$emit('verificationResults','PackagingCm',false)
            return false
          };
          this.$emit('mergeData', this.form)
          this.$emit('tranCheck', 'PackagingCm', true)
          // this.$emit('verificationResults','PackagingCm',true)
        })

      } else {
        this.submitData = false  //控制是否报红验证
        this.$refs.form.validate((valid) => {
          this.validForm = valid
          this.$emit('deleteData', 'packingCmQuotations')
          if(this.form.packingCmQuotations.length && (this.form.packingCmQuotations[0].unitPrice === null || this.form.packingCmQuotations[0].unitPrice === '')){
            this.$emit('mergeData', { ...this.form, PackagingCm: "true" })
            this.$emit('tranCheck', 'PackagingCm', true)
          }else{
            this.$emit('mergeData', { ...this.form, PackagingCm: true })
            this.$emit('tranCheck', 'PackagingCm', true)
          }
          
          // this.$emit('mergeData', this.form)
          // this.$emit('verificationResults','PackagingCm',true)
        })
      }

    },
    // 切换新增时
    async clear() {
      this.form = this.$options.data().form
      this.getRemote()
    },
    // 切换到编辑页面时
    async assignment() {
      this.$nextTick(() => {
        setTimeout(() => { this.form.packingCmQuotations = this.newPropsForm }, 200)
      })
    },

  },
};
</script>
<style lang="scss" scoped>
.packaging {
  ::v-deep .el-form-item__content {
    margin-left: 0 !important;
  }
}
</style>
