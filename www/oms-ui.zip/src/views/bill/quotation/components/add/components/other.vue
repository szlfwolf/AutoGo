<template>
  <div>
    <el-form ref="form" :model="form" label-width="140px">
      <el-table border ref="multipleTable" :data="form.otherQuotations" tooltip-effect="dark" class="other"
        style="width: 100%" :header-cell-style="{ background: '#f5f7fa', color: '#606266' }">
        <el-table-column label="Type" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.otherType }}</template>
        </el-table-column>
        <el-table-column label="Unit Price" min-width="120" align="center">
          <template slot-scope="scope">
            <el-form-item style="margin-bottom: 0;" :prop="'otherQuotations.' + scope.$index + '.unitPrice'"
              :rules="rules.unitPrice">
              <el-input v-model.trim="scope.row.unitPrice">
              </el-input>
            </el-form-item>
          </template>
        </el-table-column>
      </el-table>

    </el-form>
  </div>
</template>
<script>
import { getPfepDataByQuery } from '@/api/pfepData'
import ExcelUpload from "@/components/upload/jpgPdfUpload"
export default {
  name: "Shipment",
  data() {
    let priceRule8 = (rule, value, callback) => {
      if (this.submitData) {
        if (!value) callback(new Error('请全部填写或者全部为空'))
      }
      value = String(value)
      if (value.includes('.')) {
        value.indexOf('.') >= 9 ? callback(new Error('整数部分最大长度为8位')) : callback()
      } else {
        value.length >= 9 ? callback(new Error('整数部分最大长度为8位')) : callback()
      }
    }
    return {
      submitData: false,
      form: {
        otherQuotations: [],
      },
      rules: {
        unitPrice: [
          { pattern: /^(([0-9]\d*)|([0][.]{1}[0-9]{0,2}[1-9]+)|([1-9]\d*[.]{1}[0-9]+))$/g, message: '请输入大于等于0的整数或小数', trigger: 'change' },
          { validator: priceRule8, trigger: 'change' },
        ],
      },
      validForm: false,
      dataListLoading: false,
      isTrue: false
    };
  },
  components: {
    ExcelUpload,
  },
  async created() {
    if (this.propsForm) {
      this.form.otherQuotations = this.propsForm;
      // console.log("🚀→→→→→ ~ 传给other的数据.", this.propsForm)
    } else {
      await this.getRemote();
      if(this.isTrue){
        await this.assignment()
      }
    }
    // console.log('other页面的数据', this.form);
  },
  props: {
    propsForm: Array,
    newPropsForm: Array,
  },
  methods: {
    async getRemote() {
      let arr = []
      let { data: pkg } = await getPfepDataByQuery({ dataType: 'Other Type' })
      let pkgArr = pkg.data.records
      pkgArr.forEach(i => arr.push({ otherType: i.name, unitPrice: '' }))
      this.form.otherQuotations = arr
      console.log(this.form.otherQuotations,'this.newPropsForm');
      // console.log("🚀→→→→→ ~ other", arr)
    },
    // 验证
    verify() {
      let formData = []
      if (this.form.otherQuotations != null) {
        this.form.otherQuotations.forEach(i => formData.push(i.unitPrice))
      } else {
        this.form.otherQuotations = []
        formData = []
      }
      // 如果  someNext 是true的话说明页面有内容
      let someNext = Object.values(formData).some(i => i !== '' && i !== null)
      // 如果  everyNext 是true的话说明页面的内容都填好了
      let everyNext = Object.values(formData).every(i => i !== '' && i !== null)
      console.log("🚀→→→→→ ~ other  页面表单状态:", someNext, everyNext, formData)
      // 这是页面有填写但是没填完
      if (someNext && !everyNext) {
        this.submitData = true  //控制是否报红验证
        this.$refs.form.validate((valid) => {
          this.validForm = valid
          if (!valid) {
            // 跳转页面  $emit
            this.$emit('goComponents', 'Other')
            this.$emit('tranCheck', 'Other', false)
            // this.$emit('verificationResults', 'Other', false)
            return false
          };
        })
        //页面都填完了然后校验数据是否符合规则
      } else if (someNext && everyNext) {
        this.submitData = false  //控制是否报红验证
        this.$refs.form.validate((valid) => {
          this.validForm = valid
          if (!valid) {
            // 跳转页面  $emit
            this.$emit('goComponents', 'Other')
            this.$emit('tranCheck', 'Other', false)
            // this.$emit('verificationResults', 'Other', false)
            return false
          };
          this.$emit('mergeData', this.form)
          this.$emit('tranCheck', 'Other', true)
          // this.$emit('verificationResults', 'Other', true)
        })

      } else {
        this.submitData = false  //控制是否报红验证
        this.$refs.form.validate((valid) => {
          this.validForm = valid
          this.$emit('deleteData', 'otherQuotations')
          if(this.form.otherQuotations[0].unitPrice === null || this.form.otherQuotations[0].unitPrice === ''){
            this.$emit('mergeData', { ...this.form, Other: "true" })
            this.$emit('tranCheck', 'Other', true)
          }else{
            this.$emit('mergeData', { ...this.form, Other: true})
            this.$emit('tranCheck', 'Other', true)
          }
          
          // this.$emit('mergeData', this.form)
          // this.$emit('verificationResults', 'Other', true)
        })
      }
    },
    // 切换新增时
    async clear() {
      this.form = this.$options.data().form
      this.getRemote()
    },
    // 切换到编辑页面时
    async assignment() {
      this.$nextTick(() => {
        setTimeout(() => { 
          this.form.otherQuotations = this.newPropsForm
          //  console.log(this.newPropsForm,'this.newPropsForm',this.form.otherQuotations);
        }, 200)
      })
    },
    // 点击上传按钮
    // proofBtn(row) {
    //   console.log('row', JSON.parse(JSON.stringify(row)))
    //   this.$refs.File.show()
    // },
    // 上传
    // uploadHsCode(response) {

    // },
  },
};
</script>
<style lang="scss" scoped>
.other {
  ::v-deep .el-form-item__content {
    margin-left: 0 !important;
  }
}
</style>
