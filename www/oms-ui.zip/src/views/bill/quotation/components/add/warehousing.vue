<template>
  <div class="content">
    <el-tabs v-model="activeName" @tab-click="handleClick">
      <el-tab-pane label="Storage" name="StorageAmount">
        <el-form ref="StorageAmount" :model="form">
          <el-table border ref="multipleTable" :data="form.storageQuotations" tooltip-effect="dark" style="width: 100%"
            v-loading="dataListLoading"
            :header-cell-style="{ background: '#f5f7fa', color: '#606266', 'text-align': 'center' }">

            <el-table-column label="Storage Type" align="center">
              <template slot-scope="scope">{{ scope.row.storageType }}</template>
            </el-table-column>

            <el-table-column label="Unit Price(Monthly)" align="center">
              <template slot-scope="scope">
                <el-form-item style="margin-bottom: 0" :prop="'storageQuotations.' + scope.$index + '.unitPrice'"
                  :rules="rules.unitPrice">
                  <el-input placeholder="" v-model.trim="scope.row.unitPrice">
                    <template slot="append">{{ scope.row.storageType === 'Floor' ? '/ ㎡' : '/ PCS' }}</template>
                  </el-input>
                </el-form-item>
              </template>
            </el-table-column>

          </el-table>
        </el-form>
      </el-tab-pane>
      <el-tab-pane label="FTE" name="FteAmount">
        <FteAmount ref="FteAmount" :propsForm="propsForm" :newPropsForm="newPropsForm" @goComponents="goComponents"
          @mergeData="mergeData" @deleteData="deleteData" @tranCheck="tranCheck">
        </FteAmount>
      </el-tab-pane>
      <el-tab-pane label="PMHV" name="PmhvAmount">
        <PmhvAmount ref="PmhvAmount" :propsForm="propsForm.pmhvQuotations" :newPropsForm="newPropsForm.pmhvQuotations"
          @goComponents="goComponents" @mergeData="mergeData" @deleteData="deleteData" @tranCheck="tranCheck">
        </PmhvAmount>
      </el-tab-pane>
      <el-tab-pane label="Fixed assets" name="FixedAssetsAmount">
        <FixedAssetsAmount ref="FixedAssetsAmount" :propsForm="propsForm.fixedAssetsQuotations"
          :newPropsForm="newPropsForm.fixedAssetsQuotations" @goComponents="goComponents" @mergeData="mergeData"
          @deleteData="deleteData" @tranCheck="tranCheck">
        </FixedAssetsAmount>
      </el-tab-pane>
      <el-tab-pane label="Packaging CM" name="PackagingCm">
        <PackagingCm ref="PackagingCm" :propsForm="propsForm.packingCmQuotations"
          :newPropsForm="newPropsForm.packingCmQuotations" @goComponents="goComponents" @mergeData="mergeData"
          @deleteData="deleteData" @tranCheck="tranCheck">
        </PackagingCm>
      </el-tab-pane>
      <el-tab-pane label="Other" name="Other">
        <Other ref="Other" :propsForm="propsForm.otherQuotations" :newPropsForm="newPropsForm.otherQuotations"
          @goComponents="goComponents" @mergeData="mergeData" @deleteData="deleteData" @tranCheck="tranCheck"></Other>
      </el-tab-pane>
    </el-tabs>

  </div>
</template>
<script>
import FteAmount from "./components/fteAmount.vue"
import PmhvAmount from "./components/pmhvAmount.vue"
import FixedAssetsAmount from "./components/fixedAssets.vue"
import PackagingCm from "./components/packagingCm.vue"
import Other from "./components/other.vue"
import { deepClone } from '@/util/util';
import { getStorageTypeList } from '@/api/sku'
export default {
  name: "FunctionArea",
  data() {
    return {
      timeId: null,
      isSub: false,
      tranCheckObj: {},
      submitData: false,
      validForm: false,
      dataListLoading: false,
      form: {
        storageQuotations: []
      },
      activeName: 'StorageAmount',
      nameArr: ['StorageAmount', 'FteAmount', 'PmhvAmount', 'FixedAssetsAmount', 'PackagingCm', 'Other',],
      nameIndex: 0,
      rules: {
        unitPrice: [
          // { required: true, message: '此区域为必填项', trigger: "change" },
          { pattern: /^(([0-9]\d*)|([0][.]{1}[0-9]{0,2}[1-9]+)|([1-9]\d*[.]{1}[0-9]+))$/g, message: '请输入大于等于0的整数或小数', trigger: 'change' },
          {
            validator: (rule, value, callback) => {
              if (this.submitData) {
                if (!value) callback(new Error('请全部填写或者全部为空'))
              }
              value = String(value)
              if (value.includes('.')) {
                value.indexOf('.') >= 7 ? callback(new Error('整数部分最大长度为6位')) : callback()
              } else {
                value.length >= 7 ? callback(new Error('整数部分最大长度为6位')) : callback()
              }
            },
            trigger: 'change'
          },
        ]
      }
    };
  },
  components: {
    FteAmount,
    PmhvAmount,
    FixedAssetsAmount,
    PackagingCm,
    Other
  },
  props: {
    propsForm: Object,
    newPropsForm: Object,
  },
  created() {
    if (this.propsForm.clickType === 'add') {
      this.storageArr()
    } else {
      this.form.storageQuotations = this.propsForm.storageQuotations
    }
  },
  methods: {
    //切换tab
    handleClick(e) {
      this.nameIndex = e.index
    },
    async storageArr() {
      let { data } = await getStorageTypeList()
      // console.log('data', JSON.parse(JSON.stringify(data)))
      if (!data.includes('Floor')) data.push('Floor')
      data.forEach(i => {
        this.form.storageQuotations.push({
          storageType: i,
          unitPrice: '',
        })
      });
    },

    // 合并数据
    mergeData(data) {
      // 传递数据到主页面
      this.$emit("formData", data)
    },
    // 下一步
    next() {
      for (let i of this.nameArr) {
        let on = i === 'StorageAmount' ? this : this.$refs[i]
        console.log("🚀→→→→→ ~ i11111:", i)
        on.verify()
        console.log("🚀→→→→→ ~ i222222:", i)
      }

    },
    // 跳转页面
    goComponents(val) {
      this.$emit('activeChange', 1)
      this.activeName = val
    },
    //  集合数据判断是否进行tran页面的校验
    tranCheck(name, boo) {
      this.tranCheckObj[name] = boo
      let arr = Object.values(this.tranCheckObj)
      if (arr.length == 6) {
        // console.log('集合数据判断是否进行tran页面的校验', JSON.parse(JSON.stringify(this.tranCheckObj)))
        let flag = Object.values(this.tranCheckObj).every(i => i)
        if (flag && !this.isSub) {
          this.$emit('nextTran')
          this.isSub = true
          clearTimeout(timeId)
          let timeId = setTimeout(() => { this.isSub = false }, 1000)
          console.log('进入tran页面校验');
        } else {
          this.tranCheckObj = {}
          console.log('没进tran页面 ');
        }
      }
    },

    // 验证
    verify() {
      // console.log('这里是第二个页面', JSON.parse(JSON.stringify(this.form)))
      let formData = []
      if (this.form.storageQuotations != null) {
        this.form.storageQuotations.forEach(i => formData.push(i.unitPrice))
      } else {
        this.form.storageQuotations = []
        formData = []
      }
      // 如果  someNext 是true的话说明页面有内容
      let someNext = Object.values(formData).some(i => i !== '' && i !== null)
      // 如果  everyNext 是true的话说明页面的内容都填好了
      let everyNext = Object.values(formData).every(i => i !== '' && i !== null)
      console.log("🚀→→→→→ ~ storage页面表单状态:", someNext, everyNext, formData)
      // 这是页面有填写但是没填完
      if (someNext && !everyNext) {
        this.submitData = true  //控制是否报红验证
        this.$refs.StorageAmount.validate((valid) => {
          this.validForm = valid
          if (!valid) {
            this.goComponents('StorageAmount')
            this.tranCheck('storageQuotations', false)
            return false
          };
        })
        //页面都填完了然后校验数据是否符合规则
      } else if (someNext && everyNext) {
        this.submitData = false  //控制是否报红验证
        this.$refs.StorageAmount.validate((valid) => {
          this.validForm = valid
          if (!valid) {
            this.goComponents('StorageAmount')
            this.tranCheck('storageQuotations', false)
            return false
          };
          // 都填写了并且校验通过 进行下一步校验！！！！！！！！
          this.mergeData(this.form)
          this.tranCheck('storageQuotations', true)
        })

      } else {
        this.submitData = false  //控制是否报红验证
        this.$refs.StorageAmount.validate((valid) => {
          this.validForm = valid
          // 都不填写 进行下一步校验！！！！！！！！
          // this.mergeData(this.form)
          if(this.form.storageQuotations[0].unitPrice === '' || this.form.storageQuotations[0].unitPrice === null){
            this.mergeData({ ...this.form, StorageAmount: "true" })
            this.tranCheck('storageQuotations', true)
          }else{
            this.mergeData({ ...this.form, StorageAmount: true })
            this.tranCheck('storageQuotations', true)
          }
          this.deleteData('storageQuotations')
        })

      }

    },

    // 切换新增时
    clear() {
      this.activeName = 'StorageAmount'
      this.nameIndex = 0
      this.form = this.$options.data().form
      this.storageArr()
      this.pageSwitching('clear')

    },
    // 切换到编辑页面时
    assignment() {
      this.activeName = 'StorageAmount'
      this.nameIndex = 0
      this.$nextTick(() => {
        this.form.storageQuotations = this.newPropsForm.storageQuotations
      })
      this.pageSwitching('assignment')
    },
    // 页面切换
    pageSwitching(type) {
      let arr = ['FteAmount', 'PmhvAmount', 'FixedAssetsAmount', 'PackagingCm', 'Other']
      let obj = {
        clear: () => {
          arr.forEach(i => this.$refs[i].clear())
        },
        assignment: () => {
          arr.forEach(i => {
            this.$refs[i].assignment() 
            this.$refs[i].isTrue = true
          })
        },
      }
      return obj[type]()
    },
    //  修改的时候如果什么都没填写 就删掉这项数据
    deleteData(val) {
      this.$emit('deleteDataChange', val)
    },
  },
};
</script>
<style lang="scss" scoped>
.content {
  width: 100%;

  ::v-deep .el-tabs__nav-scroll {
    padding: 0 20px;
    box-sizing: border-box;
    background-color: #edeff3;
  }

  // ::v-deep .el-tabs__item.is-active {
  //   color: #333;
  // }

  ::v-deep .el-tabs__active-bar {
    // background-color: #000;
    width: 0 !important;
  }



  ::v-deep .el-input-group__append {
    width: 70px;
    padding: 0;
    text-align: center;
  }
}
</style>
