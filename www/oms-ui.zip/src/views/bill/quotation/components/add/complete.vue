<template>
  <div class="content">
    <el-card class="box-card">
      <div style="display: flex; flex-direction: column; align-items: center">
        <i class="el-icon-success" style="color: #34c627; font-size: 72px"></i>
        <div style="font-size: 36px; font-weight: 700">Add Success</div>
      </div>
      <div style="margin-top: 50px; display: flex; justify-content: center">
        <el-button v-if="clickType === 'add'" type="primary" @click="pre">Continue to add</el-button>
        <el-button type="primary" @click="cancelClo">View details</el-button>
      </div>
    </el-card>
  </div>
</template>
<script>
import { mapGetters } from "vuex";
export default {
  name: "complete",
  data() {
    return {
    };
  },
  computed: {
    ...mapGetters(["permissions", 'tagList']),
  },
  components: {},
  created() { },
  props: {
    clickType: String
  },
  methods: {
    pre() {
      this.$emit("pre");
      // this.$router.go()
    },
    findTag(value) {
      let tag, key;
      this.tagList.map((item, index) => {
        if (item.value.includes(value)) {
          tag = item;
          key = index;
        }
      });
      return { tag: tag, key: key };
    },
    //返回
    cancelClo() {
      let { tag, key } = this.findTag(this.$route.fullPath);
      this.$store.commit('DEL_TAG', tag)
      this.$router.push({
        path: "/bill/quotation/index"
      })
    },
  },
};
</script>
<style lang="scss" scoped>
.content {
  padding: 0 10px;

  // box-sizing: border-box;
  .text {
    font-size: 14px;
  }

  .item {
    padding: 18px 0;
  }

  .box-card {
    width: 100%;
  }
}
</style>
