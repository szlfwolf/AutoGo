<template>
  <div>
    <el-form ref="form" :model="form" label-width="140px" :rules="rules">
      <el-table border ref="multipleTable" :data="form.pmhvQuotations" tooltip-effect="dark" class="pmhv"
        style="width: 100%" :header-cell-style="{ background: '#f5f7fa', color: '#606266' }">
        <el-table-column label="PMHV Type" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.pmhvType }}</template>
        </el-table-column>
        <el-table-column label="Qty" min-width="120" align="center">
          <template slot-scope="scope">
            <el-form-item style="margin-bottom: 0;" :prop="'pmhvQuotations.' + scope.$index + '.pmhvQty'"
              :rules="rules.pmhvQty">
              <el-input v-model.trim="scope.row.pmhvQty" :maxlength="9"></el-input>
            </el-form-item>
          </template>
        </el-table-column>
        <el-table-column label="Unit Price" min-width="120" align="center">
          <template slot-scope="scope">
            <el-form-item style="margin-bottom: 0;" :prop="'pmhvQuotations.' + scope.$index + '.unitPrice'"
              :rules="rules.unitPrice">
              <el-input v-model.trim="scope.row.unitPrice"></el-input>
            </el-form-item>
          </template>
        </el-table-column>
      </el-table>
    </el-form>
  </div>
</template>
<script>
import { getPfepDataByQuery } from '@/api/pfepData'
export default {
  name: "PmhvAmount",
  data() {
    let priceRule8 = (rule, value, callback) => {
      if (this.submitData) {
        if (!value) callback(new Error('请全部填写或者全部为空'))
      }
      if (rule.field.includes('unitPrice')) {
        value = String(value)
        if (value.includes('.')) {
          value.indexOf('.') >= 9 ? callback(new Error('整数部分最大长度为8位')) : callback()
        } else {
          value.length >= 9 ? callback(new Error('整数部分最大长度为8位')) : callback()
        }
      } else {
        callback()
      }

    }
    return {
      submitData: false,
      form: {
        pmhvQuotations: [],
      },
      rules: {
        pmhvQty: [
          { pattern: /^\+?[0-9]\d*$/, message: '请输入大于等于0的整数', trigger: 'change' },
          { validator: priceRule8, trigger: 'change' },
        ],
        unitPrice: [
          { pattern: /^(([0-9]\d*)|([0][.]{1}[0-9]{0,2}[1-9]+)|([1-9]\d*[.]{1}[0-9]+))$/g, message: '请输入大于等于0的整数或小数', trigger: 'change' },
          { validator: priceRule8, trigger: 'change' },
        ],
      },
      validForm: false,
      dataListLoading: false,
      isTrue: false
    };
  },
  async created() {
    if (this.propsForm) {
      this.form.pmhvQuotations = this.propsForm
    } else {
      await this.getRemote()
      if(this.isTrue){
        await this.assignment()
      }
    }
  },
  props: {
    propsForm: Array,
    newPropsForm: Array,
  },
  methods: {
    async getRemote() {
      //fte type
      let arr = []
      let { data: fte } = await getPfepDataByQuery({ dataType: 'PMHV' })
      let fteTypeArr = fte.data.records
      fteTypeArr.forEach(i => arr.push({ pmhvType: i.name, pmhvQty: '', unitPrice: '' }))
      this.form.pmhvQuotations = arr
    },
    // 验证
    verify() {
      let formData = []
      if (this.form.pmhvQuotations != null) {
        this.form.pmhvQuotations.forEach(i => formData.push(i.pmhvQty, i.unitPrice))
      } else {
        this.form.pmhvQuotations = []
        formData = []
      }
      // 如果  someNext 是true的话说明页面有内容
      let someNext = Object.values(formData).some(i => i !== '' && i !== null)
      // 如果  everyNext 是true的话说明页面的内容都填好了
      let everyNext = Object.values(formData).every(i => i !== '' && i !== null)
      console.log("🚀→→→→→ ~ pmhv  页面表单状态:", someNext, everyNext, formData)
      // 这是页面有填写但是没填完
      if (someNext && !everyNext) {
        this.submitData = true  //控制是否报红验证
        this.$refs.form.validate((valid) => {
          this.validForm = valid
          if (!valid) {
            // 跳转页面  $emit
            this.$emit('goComponents', 'PmhvAmount')
            this.$emit('tranCheck', 'PmhvAmount', false)
            // this.$emit('verificationResults','PmhvAmount',false)
            return false
          };
        })
        //页面都填完了然后校验数据是否符合规则
      } else if (someNext && everyNext) {
        this.submitData = false  //控制是否报红验证
        this.$refs.form.validate((valid) => {
          this.validForm = valid
          if (!valid) {
            // 跳转页面  $emit
            this.$emit('goComponents', 'PmhvAmount')
            this.$emit('tranCheck', 'PmhvAmount', false)
            // this.$emit('verificationResults','PmhvAmount',false)
            return false
          };
          this.$emit('mergeData', this.form)
          this.$emit('tranCheck', 'PmhvAmount', true)
          // this.$emit('verificationResults','PmhvAmount',true)
        })

      } else {
        this.submitData = false  //控制是否报红验证
        this.$refs.form.validate((valid) => {
          this.validForm = valid
          this.$emit('deleteData', 'pmhvQuotations')
          if(this.form.pmhvQuotations[0].unitPrice === null || this.form.pmhvQuotations[0].unitPrice === ''){
            this.$emit('mergeData', { ...this.form, PmhvAmount: "true" })
            this.$emit('tranCheck', 'PmhvAmount', true)
          }else{
            this.$emit('mergeData', { ...this.form, PmhvAmount: true })
            this.$emit('tranCheck', 'PmhvAmount', true)
          }
          // this.$emit('mergeData', this.form)
          // this.$emit('verificationResults','PmhvAmount',true)
        })

      }

    },
    // 切换新增时
    async clear() {
      this.form = this.$options.data().form
      this.getRemote()
    },
    // 切换到编辑页面时
    async assignment() {
      this.$nextTick(() => {
        setTimeout(() => {
          this.form.pmhvQuotations = this.newPropsForm
        }, 200)
      })
    },

  },
};
</script>
<style lang="scss" scoped>
.pmhv {
  ::v-deep .el-form-item__content {
    margin-left: 0 !important;
  }
}
</style>
