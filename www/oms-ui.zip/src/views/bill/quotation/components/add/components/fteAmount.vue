<template>
  <div>
    <el-form ref="form" :model="form.fteOrderQuotation" :rules="rules" label-width="250px">
      <el-form-item label="Quotation Type:" prop="quotationType">
        <el-radio-group v-model="form.fteOrderQuotation.quotationType" v-for="(ite, index) in quotationType" :key="index">
          <el-radio :label="ite.value" style="margin-right:10px">{{ ite.label }}</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-table class="fte" border ref="multipleTable" :data="form.fteOrderQuotation.fteTypeQuotations"
        tooltip-effect="dark" :header-cell-style="{ background: '#f5f7fa', color: '#606266' }"
        v-if="form.fteOrderQuotation.quotationType === 'FTE'">
        <el-table-column label="FTE Type" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.fteType }}</template>
        </el-table-column>
        <el-table-column label="Qty" min-width="120" align="center">
          <template slot-scope="scope">
            <el-form-item style="margin-bottom: 0;" :prop="'fteTypeQuotations.' + scope.$index + '.fteQty'"
              :rules="rules.fteQty">
              <el-input v-model.trim="scope.row.fteQty" :maxlength="8"></el-input>
            </el-form-item>
          </template>
        </el-table-column>
        <el-table-column label="Unit Price" min-width="120" align="center">
          <template slot-scope="scope">
            <el-form-item style="margin-bottom: 0;" :prop="'fteTypeQuotations.' + scope.$index + '.fteUnitPrice'"
              :rules="rules.fteUnitPrice">
              <el-input v-model.trim="scope.row.fteUnitPrice"></el-input>
            </el-form-item>
          </template>
        </el-table-column>
      </el-table>
      <div v-else>
        <el-form-item label="Inbound Unit Price:" prop="inboundUnitPrice">
          <el-input placeholder="Please enter unit price" v-model.trim="form.fteOrderQuotation.inboundUnitPrice"
            :maxlength="9">
            <template slot="append">{{ form.fteOrderQuotation.quotationType == 'MOQ' ? 'MOQ' : 'Line' }}</template>
          </el-input>
        </el-form-item>
        <el-form-item label="inbound inlanding Unit Price:" prop="inboundInlandingUnitPrice">
          <el-input placeholder="Please enter unit price" v-model.trim="form.fteOrderQuotation.inboundInlandingUnitPrice"
            :maxlength="9">
            <template slot="append">{{ form.fteOrderQuotation.quotationType == 'MOQ' ? 'MOQ' : 'Line' }}</template>
          </el-input>
        </el-form-item>
        <el-form-item label="Inbound Minimum Price:" prop="inboundMinimumPrice">
          <el-input placeholder="Please enter Minimum Price" v-model.trim="form.fteOrderQuotation.inboundMinimumPrice"
            :maxlength="9">
          </el-input>
        </el-form-item>
        <el-form-item label="Inbound Container Unit Price:" prop="inboundContainerUnitPrice">
          <el-input placeholder="Please enter Labeling Price"
            v-model.trim="form.fteOrderQuotation.inboundContainerUnitPrice" :maxlength="9">
          </el-input>
        </el-form-item>
        <el-form-item label="Inbound Labeling Unit Price:" prop="inboundLabelingUnitPrice">
          <el-input placeholder="Please enter Labeling Price"
            v-model.trim="form.fteOrderQuotation.inboundLabelingUnitPrice" :maxlength="9">
          </el-input>
        </el-form-item>
        <el-form-item label="Inbound Adm Unit Price:" prop="inboundAdminUnitPrice">
          <el-input placeholder="Please enter Adm Price" v-model.trim="form.fteOrderQuotation.inboundAdminUnitPrice"
            :maxlength="9">
          </el-input>
        </el-form-item>
        <el-form-item label="Outbound Unit Price - Big:" prop="outboundUnitPriceBig">
          <el-input placeholder="Please enter unit price" v-model.trim="form.fteOrderQuotation.outboundUnitPriceBig"
            :maxlength="9">
            <template slot="append">{{ form.fteOrderQuotation.quotationType == 'MOQ' ? 'MOQ' : 'Line' }}</template>
          </el-input>
        </el-form-item>
        <el-form-item label="Outbound Unit Price - Sm:" prop="outboundUnitPriceSm">
          <el-input placeholder="Please enter unit price" v-model.trim="form.fteOrderQuotation.outboundUnitPriceSm"
            :maxlength="9">
            <template slot="append">{{ form.fteOrderQuotation.quotationType == 'MOQ' ? 'MOQ' : 'Line' }}</template>
          </el-input>
        </el-form-item>

        <el-form-item label="Loading Onto Truck Unit Price:" prop="outboundLoadingOntoTruck">
          <el-input placeholder=" " v-model.trim="form.fteOrderQuotation.outboundLoadingOntoTruck" :maxlength="9">
          </el-input>
        </el-form-item>
        <el-form-item label="Loading Onto Truck Minimum Price:" prop="outboundLoadingOntoTruckMin">
          <el-input placeholder=" " v-model.trim="form.fteOrderQuotation.outboundLoadingOntoTruckMin" :maxlength="9">
          </el-input>
        </el-form-item>
        <el-form-item label="Outbound Adm Unit Price:" prop="outboundAdminUnitPrice">
          <el-input placeholder="Please enter Adm Price" v-model.trim="form.fteOrderQuotation.outboundAdminUnitPrice"
            :maxlength="9">
          </el-input>
        </el-form-item>

        <el-form-item label="Export C/D Min Price:" prop="exportCdMinPrice">
          <el-input placeholder="Please enter Unit Price" v-model.trim="form.fteOrderQuotation.exportCdMinPrice"
            :maxlength="9">
          </el-input>
        </el-form-item>
        <el-form-item label="Hscode Threshold:" prop="hscodeThreshold">
          <el-input placeholder="Please enter Unit Price" v-model.trim="form.fteOrderQuotation.hscodeThreshold"
            :maxlength="9">
          </el-input>
        </el-form-item>
        <el-form-item label="Hscode Unit Price:" prop="hscodeUnitPrice">
          <el-input placeholder="Please enter Unit Price" v-model.trim="form.fteOrderQuotation.hscodeUnitPrice"
            :maxlength="9">
          </el-input>
        </el-form-item>

      </div>
    </el-form>
  </div>
</template>
<script>
import { getPfepDataByQuery } from '@/api/pfepData'
import { deepClone } from '@/util/util'
export default {
  name: "FteAmount",
  data() {
    let priceRule6 = (rule, value, callback) => {
      if (this.submitData) {
        if (!value) callback(new Error('请全部填写或者全部为空'))
      }
      value = String(value)
      if (value.includes('.')) {
        value.indexOf('.') >= 7 ? callback(new Error('整数部分最大长度为6位')) : callback()
      } else {
        value.length >= 7 ? callback(new Error('整数部分最大长度为6位')) : callback()
      }
    }
    let priceRule8 = (rule, value, callback) => {
      if (this.submitData) {
        if (!value) callback(new Error('请全部填写或者全部为空'))
      }
      if (rule.field.includes('fteUnitPrice')) {
        value = String(value)
        if (value.includes('.')) {
          value.indexOf('.') >= 9 ? callback(new Error('整数部分最大长度为8位')) : callback()
        } else {
          value.length >= 9 ? callback(new Error('整数部分最大长度为8位')) : callback()
        }
      } else {
        callback()
      }
    }
    let amountVerification = [
      { pattern: /^(([0-9]\d*)|([0][.]{1}[0-9]{0,2}[1-9]+)|([1-9]\d*[.]{1}[0-9]+))$/g, message: '请输入大于等于0的整数或小数', trigger: 'change' },
      { validator: priceRule6, trigger: 'change' },
    ]
    return {
      submitData: false,
      form: {
        fteOrderQuotation: {
          quotationType: "FTE",
          fteTypeQuotations: [],
          inboundMinimumPrice: '',
          inboundLabelingUnitPrice: '',
          inboundContainerUnitPrice: '',
          inboundAdminUnitPrice: '',
          inboundUnitPrice: '',
          inboundInlandingUnitPrice: '',
          outboundUnitPriceBig: '',
          outboundUnitPriceSm: '',
          outboundLoadingOntoTruck: '',
          outboundLoadingOntoTruckMin: '',
          outboundAdminUnitPrice: '',
          exportCdMinPrice: '',
          hscodeThreshold: '',
          hscodeUnitPrice: '',
        },


      },
      quotationType: [
        {
          label: "FTE",
          value: "FTE"
        },
        {
          label: "Order Line",
          value: "ORDERLINE"
        },
      ],
      dataListLoading: false,
      validForm: false,
      rules: {
        fteQty: [
          { pattern: /^\+?[0-9]\d*$/, message: '请输入大于等于0的整数', trigger: 'change' },
          { validator: priceRule8, trigger: 'change' },
        ],
        fteUnitPrice: [
          { pattern: /^(([0-9]\d*)|([0][.]{1}[0-9]{0,2}[1-9]+)|([1-9]\d*[.]{1}[0-9]+))$/g, message: '请输入大于等于0的整数或小数', trigger: 'change' },
          { validator: priceRule8, trigger: 'change' },
        ],
        inboundMinimumPrice: amountVerification,
        inboundLabelingUnitPrice: amountVerification,
        inboundContainerUnitPrice: amountVerification,
        inboundAdminUnitPrice: amountVerification,
        inboundUnitPrice: amountVerification,
        inboundInlandingUnitPrice: amountVerification,
        outboundUnitPriceBig: amountVerification,
        outboundUnitPriceSm: amountVerification,
        outboundLoadingOntoTruck: amountVerification,
        outboundLoadingOntoTruckMin: amountVerification,
        outboundAdminUnitPrice: amountVerification,
        exportCdMinPrice: amountVerification,
        hscodeThreshold: amountVerification,
        hscodeUnitPrice: amountVerification,
      },
      isTrue: false
    };
  },
  async created() {
    await this.getRemote()
    if(this.isTrue){
      await this.assignment()
    }
  },
  props: {
    propsForm: Object,
    newPropsForm: Object,
  },
  methods: {
    async getRemote() {
      //fte type
      let arr = []
      let { data: fte } = await getPfepDataByQuery({ dataType: 'FTE' })
      let fteTypeArr = fte.data.records
      fteTypeArr.forEach(i => arr.push({ fteType: i.name, fteQty: '', fteUnitPrice: '', }))
      if (this.propsForm.fteOrderQuotation || this.propsForm.fteTypeQuotations) {
        if (this.propsForm.fteOrderQuotation) {
          this.form.fteOrderQuotation = this.propsForm.fteOrderQuotation
          this.$set(this.form.fteOrderQuotation, 'fteTypeQuotations', arr)
        } else {
          this.$set(this.form.fteOrderQuotation, 'fteTypeQuotations', this.propsForm.fteTypeQuotations)
        }
      } else {
        this.$set(this.form.fteOrderQuotation, 'fteTypeQuotations', arr)
      }
    },
    // 验证
    // verify() {
    //   this.$refs.form.validate((valid) => {
    //     this.validForm = valid
    //     if (!valid) {
    //       this.$message.warning('Please fill in correctly')
    //       return false
    //     };

    //   })
    // },

    // 验证
    verify() {
      let formData = []
      let dataName = [
        'inboundMinimumPrice',
        'inboundLabelingUnitPrice',
        'inboundContainerUnitPrice',
        'inboundAdminUnitPrice',
        'inboundUnitPrice',
        'inboundInlandingUnitPrice',
        'outboundUnitPriceBig',
        'outboundUnitPriceSm',
        'outboundLoadingOntoTruck',
        'outboundLoadingOntoTruckMin',
        'outboundAdminUnitPrice',
        'exportCdMinPrice',
        'hscodeThreshold',
        'hscodeUnitPrice',
      ]
      // 如果选择的是ORDERLINE
      if (this.form.fteOrderQuotation.quotationType == "ORDERLINE") {
        let data = deepClone(this.form.fteOrderQuotation)
        dataName.forEach(i => formData.push(data[i]))
      } else {
        // 如果选择的是FTE
        if (this.form.fteOrderQuotation != null && this.form.fteOrderQuotation.fteTypeQuotations != null) {
          this.form.fteOrderQuotation.fteTypeQuotations.forEach(i => formData.push(i.fteQty, i.fteUnitPrice))

        } else {
          this.form.fteOrderQuotation = { fteTypeQuotations: [] }
          formData = []
        }
      }
      // 如果  someNext 是true的话说明页面有内容
      let someNext = Object.values(formData).some(i => i !== '' && i !== null)
      // 如果  everyNext 是true的话说明页面的内容都填好了
      console.log(formData,'formData222222222222222222222');
      let everyNext = Object.values(formData).every(i => i !== '' && i !== null)
      console.log("🚀→→→→→ ~fte页面表单状态:", someNext, everyNext, formData)
      // 这是页面有填写但是没填完
      if (someNext && !everyNext) {
        this.submitData = true  //控制是否报红验证
        this.$refs.form.validate((valid) => {
          this.validForm = valid
          if (!valid) {
            // 跳转页面  $emit
            // this.$emit('verificationResults','FteAmount',false)
            this.$emit('goComponents', 'FteAmount')
            this.$emit('tranCheck', 'FteAmount', false)
            return false
          };
        })
        //页面都填完了然后校验数据是否符合规则
      } else if (someNext && everyNext) {
        this.submitData = false  //控制是否报红验证
        this.$refs.form.validate((valid) => {
          this.validForm = valid
          if (!valid) {
            // 跳转页面  $emit
            // this.$emit('verificationResults','FteAmount',false)
            this.$emit('goComponents', 'FteAmount')
            this.$emit('tranCheck', 'FteAmount', false)
            return false
          };
          this.$emit('mergeData', this.form)
          this.$emit('tranCheck', 'FteAmount', true)
          // this.$emit('verificationResults','FteAmount',true)
        })

      } else {
        this.submitData = false  //控制是否报红验证
        this.$refs.form.validate((valid) => {
          this.validForm = valid
          this.$emit('deleteData', 'fteOrderQuotation')
          this.$emit('deleteData', 'fteTypeQuotations')
          if(this.form.fteOrderQuotation.fteTypeQuotations[0].fteUnitPrice === null || this.form.fteOrderQuotation.fteTypeQuotations[0].fteUnitPrice === ''){
            this.$emit('mergeData', { ...this.form, FteAmountOrder: "true", FteAmountType: "true" })
            this.$emit('tranCheck', 'FteAmount', true)
          }else{
            this.$emit('mergeData', { ...this.form, FteAmountOrder: "true", FteAmountType: true})
            this.$emit('tranCheck', 'FteAmount', true)
          }
          // this.$emit('mergeData', this.form)
          // this.$emit('verificationResults','FteAmount',true)
        })

      }

    },



    // 切换新增时
    async clear() {
      this.form = this.$options.data().form
      this.form.fteOrderQuotation.quotationType = "FTE"
      let arr = []
      let { data: fte } = await getPfepDataByQuery({ dataType: 'FTE' })
      let fteTypeArr = fte.data.records
      fteTypeArr.forEach(i => arr.push({ fteType: i.name, fteQty: '', fteUnitPrice: '', }))
      this.$set(this.form.fteOrderQuotation, 'fteTypeQuotations', arr)
    },
    // 切换到编辑页面时
    async assignment() {
      let arr = []
      let { data: fte } = await getPfepDataByQuery({ dataType: 'FTE' })
      let fteTypeArr = fte.data.records
      fteTypeArr.forEach(i => arr.push({ fteType: i.name, fteQty: '', fteUnitPrice: '', }))
      this.$nextTick(() => {
        if (!!this.newPropsForm.fteOrderQuotation) {
          this.form.fteOrderQuotation = this.newPropsForm.fteOrderQuotation
          this.$set(this.form.fteOrderQuotation, 'fteTypeQuotations', arr)
        } else {
          this.form.fteOrderQuotation = { quotationType: "FTE", },
            this.$set(this.form.fteOrderQuotation, 'fteTypeQuotations', this.newPropsForm.fteTypeQuotations)
        }
      })
    },
  },
};
</script>
<style lang="scss" scoped>
.fte {
  ::v-deep .el-form-item__content {
    margin-left: 0 !important;
  }
}
</style>
