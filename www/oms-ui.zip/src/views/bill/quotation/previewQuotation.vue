<template>
  <div class="content">
    <el-card class="box-card" v-loading="isLoading">
      <el-form ref="form" :model="form" label-width="140px" style="width:50%;margin:0 auto">
        <el-form-item label="Warehouse:" prop="warehouseCode">
          <el-select filterable disabled v-model="form.warehouseCode" placeholder="" clearable>
            <el-option v-for="item in warehouseArr" :key="item.warehouseCode" :label="item.warehouseName"
              :value="item.warehouseCode">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="Currency:" prop="currency">
          <el-select filterable disabled v-model="form.currency" placeholder="" clearable>
            <el-option v-for="item in currencyArr" :key="item.value" :label="item.label" :value="item.value">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="Valid Scope:" prop="timeRange">
          <div class="block">
            <el-date-picker disabled v-model="form.timeRange" type="monthrange" range-separator="至"
              start-placeholder="开始月份" end-placeholder="结束月份" value-format="yyyy-MM" @change="pickerTiem">
            </el-date-picker>
          </div>
        </el-form-item>
        <el-form-item v-if="active === 2" label="Weight Threshold:" prop="weightThreshold">
          <el-input disabled v-model.number="form.weightThreshold"></el-input>
        </el-form-item>
      </el-form>
      <el-steps :active="active" finish-status="success" align-center style="width:70%;margin:40px auto">
        <el-step style="cursor:pointer;user-select:none;" @click.native="active = 0" title="Import"> </el-step>
        <el-step style="cursor:pointer;user-select:none;" @click.native="active = 1" title="Warehousing"> </el-step>
        <el-step style="cursor:pointer;user-select:none;" @click.native="active = 2" title="Transport"> </el-step>
        <!-- <el-step title="Completed"> </el-step> -->
      </el-steps>
      <div style="width: 60%; margin: 50px auto">
        <div v-show="active === 0">
          <div style="width:80%;margin: 50px auto;">
            <el-form ref="form1" :model="form.importQuotations" label-width="190px">
              <el-card>
                <el-form-item label="Import C/D Min Price:" prop="importCdMinPrice">
                  <el-input disabled placeholder="Please enter Unit Price"
                    v-model.trim="form.importQuotations.importCdMinPrice"></el-input>
                </el-form-item>
                <el-form-item label="Hscode Threshold:" prop="hscodeThreshold">
                  <el-input disabled placeholder="Please enter Unit Price"
                    v-model.trim="form.importQuotations.hscodeThreshold" :maxlength="8"></el-input>
                </el-form-item>

                <el-form-item label="Hscode Unit Price:" prop="hscodeUnitPrice">
                  <el-input disabled placeholder="Please enter Unit Price"
                    v-model.trim="form.importQuotations.hscodeUnitPrice"></el-input>
                </el-form-item>
              </el-card>


              <el-card>
                <div slot="header">
                  <span>Inland Transport</span>
                </div>
                <el-form-item label="Sea Transport:" prop="seaInlandTransportUnitPrice">
                  <el-input disabled placeholder="Please enter Unit Price"
                    v-model.trim="form.importQuotations.seaInlandTransportUnitPrice"></el-input>
                </el-form-item>
                <el-form-item label="Air&Sea Transport:" prop="airInlandTransportUnitPrice">
                  <el-input disabled placeholder="Please enter Unit Price"
                    v-model.trim="form.importQuotations.airInlandTransportUnitPrice"></el-input>
                </el-form-item>
                <el-form-item label="Train Transport:" prop="trainInlandTransportUnitPrice">
                  <el-input disabled placeholder="Please enter Unit Price"
                    v-model.trim="form.importQuotations.trainInlandTransportUnitPrice"></el-input>
                </el-form-item>
                <el-form-item label="Local Transport:" prop="localInlandTransportUnitPrice">
                  <el-input disabled placeholder="Please enter Unit Price"
                    v-model.trim="form.importQuotations.localInlandTransportUnitPrice"></el-input>
                </el-form-item>
              </el-card>



            </el-form>
            <div v-if="false" style="display:flex;justify-content:center;margin-top:50px">
              <el-button type="primary" @click="next">下一步</el-button>
            </div>
          </div>
        </div>
        <div v-show="active === 1">
          <Warehousing ref="Warehousing" @pre="pre" @next="next" @formData="formData" :propsForm="form"
            :newPropsForm="newForm"></Warehousing>
        </div>
        <div v-if="transportShow">
          <div v-show="active === 2">
            <Transport ref="Transport" @pre="pre" @next="next" @formData="formData"
              :propsForm="transport.transportQuotationDto" :newPropsForm="transport.transportQuotationDto">
            </Transport>
          </div>
        </div>
        <!-- <div v-show="active === 3">
          <Complete @pre="pre" @next="next" :clickType="form.clickType"></Complete>
        </div> -->
      </div>
    </el-card>
  </div>
</template>
<script>
import store from "@/store";
import { mapGetters } from "vuex";
import { remote } from "@/api/admin/dict";
import Warehousing from "./previewComponents/add/warehousing.vue"
import Transport from "./previewComponents/add/transport.vue"
// import Complete from "./previewComponents/add/complete.vue"
import { addSave, AddParentWarehouseCodes, getQuotationDetails, getTransportDetails, update } from "@/api/quotation"
import { getPfepDataByQuery } from '@/api/pfepData'
import { deepClone } from '@/util/util';
import { getStore, setStore, removeStore } from '@/util/store';

export default {
  name: "AddQuotation",
  data() {
    let priceRule8 = (rule, value, callback) => {
      value = String(value)
      if (value.includes('.')) {
        value.indexOf('.') >= 9 ? callback(new Error('整数部分最大长度为8位')) : callback()
      } else {
        value.length >= 9 ? callback(new Error('整数部分最大长度为8位')) : callback()
      }
    }
    let timeVerification = (rule, value, callback) => {
      if (value[0] === value[1]) {
        callback(new Error('填写错误,PS:2023-01至2023-02表示2023-01-01至2023-02-01'))
      } else { callback() }
    }
    return {
      transportShow: false,
      transport: {},
      dataId: '',
      addQuotationRow: null,
      paraData: null,
      fteData: [],
      pmhvData: [],
      pkgData: [],
      otherData: [],
      active: 0,
      isLoading: false,
      form: {
        clickType: '',
        clientCode: '',
        warehouseCode: "",
        currency: "",
        weightThreshold: "",
        timeRange: [],
        importQuotations: {
          importCdMinPrice: '',
          inlandTransportUnitPrice: '',
          hscodeThreshold: '',
          // hscodeFreeNum: '',
          hscodeUnitPrice: '',
        }
      },
      newForm: {
        clickType: '',
        clientCode: '',
        warehouseCode: "",
        currency: "",
        timeRange: [],
        importQuotations: {
          importCdMinPrice: '',
          inlandTransportUnitPrice: '',
          hscodeThreshold: '',
          // hscodeFreeNum: '',
          hscodeUnitPrice: '',
        }
      },
      currencyArr: [],
      warehouseArr: [],
      rules: {
        currency: [
          { required: true, message: "此区域为必填项", trigger: "change" }
        ],
        warehouseCode: [
          { required: true, message: "此区域为必填项", trigger: "change" },
        ],
        timeRange: [
          { required: true, message: "此区域为必填项", trigger: "change" },
          { validator: timeVerification, trigger: 'change' },
        ],
        importCdMinPrice: [
          { required: true, message: "此区域为必填项", trigger: "change" },
          { pattern: /^(([1-9]\d*)|([0][.]{1}[0-9]{0,2}[1-9]+)|([1-9]\d*[.]{1}[0-9]+))$/g, message: '请输入大于0的整数或小数', trigger: 'change' },
          { validator: priceRule8, trigger: 'change' },
        ],
        inlandTransportUnitPrice: [
          { required: true, message: "此区域为必填项", trigger: "change" },
          { pattern: /^(([1-9]\d*)|([0][.]{1}[0-9]{0,2}[1-9]+)|([1-9]\d*[.]{1}[0-9]+))$/g, message: '请输入大于0的整数或小数', trigger: 'change' },
          { validator: priceRule8, trigger: 'change' },
        ],
        hscodeThreshold: [
          { required: true, message: "此区域为必填项", trigger: "change" },
          { pattern: /^\+?[1-9]\d*$/, message: '请输入大于0的整数', trigger: 'change' },
        ],
        // hscodeFreeNum: [
        //   { required: true, message: "此区域为必填项", trigger: "change" },
        //   { pattern: /^\+?[1-9]\d*$/, message: '请输入大于0的整数', trigger: 'change' },
        //   { validator: priceRule8, trigger: 'change' },
        // ],
        hscodeUnitPrice: [
          { required: true, message: "此区域为必填项", trigger: "change" },
          { pattern: /^(([1-9]\d*)|([0][.]{1}[0-9]{0,2}[1-9]+)|([1-9]\d*[.]{1}[0-9]+))$/g, message: '请输入大于0的整数或小数', trigger: 'change' },
          { validator: priceRule8, trigger: 'change' },
        ],
        weightThreshold: [
          { required: true, message: "此区域为必填项", trigger: "change" },
          { pattern: /^\+?[1-9]\d*$/, message: '请输入大于0的整数', trigger: 'change' },
          { validator: priceRule8, trigger: 'change' },
        ],
      },
    };
  },
  computed: {
    ...mapGetters(["permissions"]),
  },


  components: {
    Warehousing,
    Transport,
    // Complete
  },

  async beforeRouteUpdate(to, from, next) {
    if (to.query.id) {
      this.isLoading = true;
      let { data } = await getQuotationDetails(to.query.id)
      if (data.code != 0) {
        this.isLoading = false;
        this.$message.error('request was aborted')
        return
      }
      this.isLoading = false;
      this.newForm = deepClone(data.data)
      this.form = deepClone(data.data)
      this.$set(this.form, 'timeRange', [data.data.validTimeBegin, data.data.validTimeFinish])
      this.active = 0
      try {
        this.$refs.Warehousing.assignment()
      } catch (error) {
      }
      setTimeout(async () => {
        this.transportShow = true
        // 查询transportDetails详情
        let { data: transportDetails } = await getTransportDetails(to.query.id)
        this.transport = transportDetails.data
        console.log('查询transportDetails详情', JSON.parse(JSON.stringify(transportDetails.data)))
        try {
          this.$refs.Transport.assignment()
        } catch (error) {
        }
      }, 150)
      this.form.clickType = 'change'
    } else {
      this.transportShow = true
      this.active = 0
      this.form = this.$options.data().form
      this.form.clientCode = store.getters.commandName
      this.$refs.form.resetFields()
      this.$refs.form1.resetFields()
      this.$refs.Warehousing.clear()
      this.$refs.Transport.clear()
      this.form.clickType = 'add'
    }
    this.getRemote();
    next();
  },

  async created() {
    if (this.$route.query.id) {
      this.isLoading = true;
      let { data } = await getQuotationDetails(this.$route.query.id)
      if (data.code != 0) {
        this.isLoading = false;
        this.$message.error('request was aborted')
        return
      }
      this.isLoading = false;

      console.log('createddata.data', JSON.parse(JSON.stringify(data.data)))
      let newData = deepClone(data.data)

      if (newData.importQuotations == null) newData.importQuotations = {
        importCdMinPrice: '',
        inlandTransportUnitPrice: '',
        hscodeThreshold: '',
        // hscodeFreeNum: '',
        hscodeUnitPrice: '',
      }
      if (newData.fixedAssetsQuotations == null) newData.fixedAssetsQuotations = []

      this.form = deepClone(newData)
      this.newForm = deepClone(newData)
      this.$set(this.form, 'timeRange', [newData.validTimeBegin, newData.validTimeFinish])
      this.active = 0
      try {
        this.$refs.Warehousing.assignment()
      } catch (error) {
      }
      setTimeout(async () => {
        this.transportShow = true
        // 查询transportDetails详情
        let { data: transportDetails } = await getTransportDetails(this.$route.query.id)
        if (transportDetails.data == 0) {
          this.transport = {
            transportQuotationDto: [
              {
                transportQuotations: [
                  {
                    transportType: '',
                    countryCode: '',
                    weightScopeLeading: '',
                    weightScopeAfter: '',
                    unitPrice: '',
                  }
                ]
              },
              // 托盘
              {
                transportQuotations: [
                  {
                    transportType: '',
                    countryCode: '',
                    scopeLeading: '',
                    scopeAfter: '',
                    weightScopeLeading: '',
                    weightScopeAfter: '',
                    unitPrice: '',
                  }
                ]
              },
            ]
          }
        } else {
          this.transport = transportDetails.data
        }
        console.log('查询transportDetails详情', JSON.parse(JSON.stringify(transportDetails.data)))
        try {
          this.$refs.Transport.assignment()
        } catch (error) {
        }
      }, 150)
      this.form.clickType = 'change'
    } else {
      this.transportShow = true
      this.form.clickType = 'add'
      this.newForm.clickType = 'add'
    }
    // 当前的用户
    this.form.clientCode = store.getters.commandName
    this.newForm.clientCode = store.getters.commandName
    // 传过来的数据
    this.getRemote();
  },

  // 数据更新
  methods: {
    pickerTiem(val) {
      this.form.validTimeBegin = val[0]
      this.form.validTimeFinish = val[1]
    },
    next() {
      this.$refs.form.validate((valid) => {
        if (!valid) {
          this.$message.warning('Please fill in correctly')
          return false
        };
        this.$refs.form1.validate((valid) => {
          if (!valid) {
            this.$message.warning('Please fill in correctly')
            return false
          };
          this.active++;
        });
      });
      console.log('表单数据', JSON.parse(JSON.stringify(this.form)))
    },
    // 把填好的表单整合在一起
    formData(val, submit) {

      this.form = { ...this.form, ...val }
      // 如果收到了submit  那么调用新增接口
      if (submit === 'submit') {
        this.$refs.form.validate(async (valid) => {
          if (!valid) {
            this.$message.warning('Please fill in correctly')
            return false
          };
          this.paraData = deepClone(this.form)
          // 处理数据用于提交
          if (this.paraData.fteOrderQuotation.quotationType === 'FTE') {
            this.paraData.fteTypeQuotations = this.paraData.fteOrderQuotation.fteTypeQuotations
            // 映射数据用于提交
            this.dataMap(this.fteData, this.paraData.fteTypeQuotations, 'fteTypeQuotations', 'fteType')
            this.paraData.fteOrderQuotation = {}
          } else {
            delete this.paraData.fteOrderQuotation.fteTypeQuotations
            this.paraData.fteTypeQuotations = []
          }
          // 映射数据用于提交
          this.dataMap(this.pmhvData, this.paraData.pmhvQuotations, 'pmhvQuotations', 'pmhvType')
          this.dataMap(this.pkgData, this.paraData.packingCmQuotations, 'packingCmQuotations', 'packingCmType')
          this.dataMap(this.otherData, this.paraData.otherQuotations, 'otherQuotations', 'otherType')

          console.log('处理数据用于提交', JSON.parse(JSON.stringify(this.paraData)))
          this.isLoading = true
          if (this.paraData.clickType === 'add') {
            addSave(this.paraData).then(({ data }) => {
              if (data.code != 0) {
                this.$message.error(data.msg)
                this.isLoading = false
                return
              } else {
                this.$message.success(data.msg)
                this.isLoading = false
                this.active++;
              }
              console.log("🚀→→→→→ ~ 新增返回的数据", data)
            }).catch(() => {
              this.isLoading = false
            })


          } else {
            update(this.paraData).then(({ data }) => {
              console.log("🚀→→→→→ ~ 修改返回的数据data", data)
              if (data.code != 0) {
                this.$message.error(data.msg)
                this.isLoading = false
                return
              } else {
                this.$message.success('修改成功')
                this.isLoading = false
                this.active++;
              }
            }).catch(() => {
              this.isLoading = false
            })

          }
          this.eventBus.$emit('query')
        });
      }
    },
    pre() {
      if (this.active === 3) {
        console.log('再次新增');
        this.active = 0
        this.form = this.$options.data().form
        this.form.clientCode = store.getters.commandName
        this.$refs.form.resetFields()
        this.$refs.form1.resetFields()
        this.$refs.Warehousing.clear()
        this.$refs.Transport.clear()
        this.form.clickType = 'add'
      } else {
        this.active--;
      }
    },
    async getRemote() {
      let { data: currency } = await remote('monetary_unit')
      this.currencyArr = currency.data
      let { data: warehouse } = await AddParentWarehouseCodes()
      this.warehouseArr = warehouse.data
      let { data: fte } = await getPfepDataByQuery({ dataType: 'FTE' })
      this.fteData = fte.data.records
      let { data: pmhv } = await getPfepDataByQuery({ dataType: 'PMHV' })
      this.pmhvData = pmhv.data.records
      let { data: pkg } = await getPfepDataByQuery({ dataType: 'Packaging CM' })
      this.pkgData = pkg.data.records
      let { data: other } = await getPfepDataByQuery({ dataType: 'Other Type' })
      this.otherData = other.data.records
    },
    // 映射数据用于提交
    dataMap(res, data, name, type) {
      let newData = []
      res.forEach((i) => {
        data.forEach((item) => {
          if (item[type] == i.name) {
            item[type] = i.code
            newData.push(item)
          }
        })
      })
      this.paraData[name] = newData
    },

  },
};
</script>
<style lang="scss" scoped>
.content {
  padding: 0 10px;

  .text {
    font-size: 14px;
  }

  .item {
    padding: 18px 0;
  }

  .box-card {
    width: 100%;
    padding-top: 20px;
  }

  ::v-deep .el-select--small {
    display: block;
  }

  ::v-deep .el-date-editor--daterange.el-input,
  ::v-deep .el-date-editor--daterange.el-input__inner,
  ::v-deep .el-date-editor--timerange.el-input,
  ::v-deep .el-date-editor--timerange.el-input__inner {
    width: 100% !important;
  }

  ::v-deep .el-date-editor.el-input,
  .el-date-editor.el-input__inner {
    width: 100%;
  }
}
</style>
