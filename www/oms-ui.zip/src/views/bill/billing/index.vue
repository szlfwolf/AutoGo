<template>
  <div class="content">
    <el-tabs type="border-card" v-loading="skuLoading">
      <el-row style="width:200px;display:flex">
        <el-col>
          <el-button type="primary" icon="el-icon-search" @click="Query()">Query</el-button>
        </el-col>
        <el-col>
          <el-button @click="resetForm('form')" type="info" plain icon="el-icon-refresh-left">Reset</el-button>
        </el-col>
      </el-row>
      <el-form ref="form" :model="form">
        <el-row style="margin-top: 20px" :gutter="20">
          <!-- <el-col :span="4">
            <el-form-item prop="clientCode">
               <el-select filterable clearable v-model="form.clientCode" placeholder="Owner">
                <el-option v-for="item in 2" :label="item" :value="item" :key="item">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col> -->
          <el-col :span="4">
            <el-form-item prop="warehouseCode">
              <el-select filterable clearable v-model="form.warehouseCode" placeholder="Warehouse">
                <el-option v-for="item in warehouseArr" :key="item.warehouseCode" :label="item.warehouseName"
                  :value="item.warehouseCode"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="4">
            <el-form-item prop="month">
              <el-date-picker style="width:100%" v-model="form.month" type="month" value-format="yyyy-MM"
                placeholder="Month">
              </el-date-picker>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div class="down">
        <span></span>
        <div>
          <el-button v-if="permissions.bill_billing_export" icon="el-icon-download" @click="exportExcel"></el-button>
        </div>
      </div>
      <!-- 数据表 -->
      <el-table tooltip-effect="dark" stripe border ref="multipleTable" :data="tableData.records" style="width: 100%"
        header-cell-class-name="header-cell-class" :header-cell-style="{ background: '#f5f7fa', color: '#606266' }">
        <el-table-column :show-overflow-tooltip="true" label="Owner" min-width="100" align="center">
          <template slot-scope="scope">{{ scope.row.clientCode }}</template>
        </el-table-column>

        <el-table-column :show-overflow-tooltip="true" label="Warehouse" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.warehouseCode }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Month" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.month }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Import Amount" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.importAmount }} {{ scope.row.currency }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Warehouse Amount" min-width="150" align="center">
          <template slot-scope="scope">{{ scope.row.warehouseAmount }} {{ scope.row.currency }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Transport Amount" min-width="150" align="center">
          <template slot-scope="scope">{{ scope.row.transportAmount }} {{ scope.row.currency }}</template>
        </el-table-column>
        <el-table-column label="Opearte" min-width="150" align="center">
          <template slot-scope="scope">
            <div style="display: flex; justify-content: center;">
              <img @click="count(scope.row)" :src="disabledBtn ? jisuan1 : jisuan"
                :class="disabledBtn ? 'jisuan1' : 'jisuan'">
              <img v-if="permissions.bill_billing_export" :src="disabledBtn ? yunxiazai1 : yunxiazai"
                @click="exportDetails(scope.row)" :class="disabledBtn ? 'jisuan1' : 'jisuan'">
              <img src="../../../../public/svg/mingxi.svg" @click="detailed(scope.row)" class="jisuan">
            </div>
          </template>
        </el-table-column>
      </el-table>

      <Pagination @handleSizeChange="handleSizeChange" @handleCurrentChange="handleCurrentChange"
        :pageNum="tableData.current" :pageSize="tableData.size" :total="tableData.total"></Pagination>
    </el-tabs>
  </div>
</template>
<script>
let formParams = {
  clientCode: '',
  warehouseCode: '',
  month: '',
};
import jisuan from '../../../../public/svg/jisuan.svg'
import yunxiazai from '../../../../public/svg/yunxiazai.svg'
import jisuan1 from '../../../../public/svg/jisuan1.svg'
import yunxiazai1 from '../../../../public/svg/yunxiazai1.svg'
import { mapGetters } from "vuex"
import Pagination from "@/components/pagination/pagination.vue"
import { deepClone } from '@/util/util';
import ExcelUpload from "@/components/upload/excel"
import { btnAntiShake } from '@/util/btnAntiShake'
import { remote } from '@/api/admin/dict'
import store from '@/store'
import { recount, queryData } from '@/api/billing'
import { AddParentWarehouseCodes } from "@/api/quotation"
export default {
  data() {
    return {
      timeId: null,
      disabledBtn: false,
      jisuan: jisuan,
      yunxiazai: yunxiazai,
      jisuan1: jisuan1,
      yunxiazai1: yunxiazai1,
      skuNoDisabled: false,
      clientCodeName: '',
      dialogTitle: '',
      isDisCode: false,
      btnType: '',
      skuLoading: false,
      pageSize: '',
      pageCurrent: '1',
      detailAdd: false,
      form: Object.assign({}, formParams),
      options: [
      ],
      // 基本数据
      tableData: [],
      warehouseArr: [],
      size: 10,
      total: 100,
      //   修改表单
      updateObj: {
      },
      // add表单
      pClientArr: [],
      rules: {
        partNumber: [
          { required: true, message: '此区域为必填项', trigger: "change" },
        ],
        hsCode: [
          { required: true, message: '此区域为必填项', trigger: "change" },
        ],
        dutyRate: [
          { required: true, message: '此区域为必填项', trigger: "change" },
        ],
      }
    }
  },
  // ============
  created() {
    this.isClick()
    this.clientCodeName = store.getters.commandName
    this.Query()
  },
  components: {
    ExcelUpload,
    Pagination
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  beforeDestroy() {
    clearTimeout(this.timeId)
  },
  mounted() {
    this.exportExcel = btnAntiShake(this.exportExcel, 500)
    this.exportDetails = btnAntiShake(this.exportDetails, 500)
    this.count = btnAntiShake(this.count, 500)
  },
  methods: {
    // 通过条件查询数据
    async Query(query) {
      if (!query) {
        this.pageCurrent = 1
        this.pageSize = 10
        query = { current: this.pageCurrent, size: this.pageSize }
      }
      let queryObj = Object.assign(this.form, query)
      console.log('携带的参数', queryObj);
      this.skuLoading = true
      let { data: warehouse } = await AddParentWarehouseCodes()
      this.warehouseArr = warehouse.data
      let { data } = await queryData(queryObj)
      if (data.code != 0) {
        this.skuLoading = false //关loading
        this.$message.error(data.msg);
        return;
      }
      this.skuLoading = false //关loading
      this.tableData = deepClone(data.data)
      console.log('页面基本数据', JSON.parse(JSON.stringify(this.tableData)))
    },

    // 明细
    detailed(row) {
      let newRow = {
        clientCode: row.clientCode,
        warehouseCode: row.warehouseCode,
        month: row.month,
        amountType: row.amountType,
      }
      this.$router.push({
        path: `/bill/billingDetails/index`,
        query: {
          row: JSON.stringify(newRow),
        },
      })
    },
    // 重置
    resetForm(rule) {
      this.form = Object.assign({}, formParams);
      this.Query()
    },
    //导出
    exportExcel() {
      this.skuLoading = true
      this.downBlobFile("/bill/billing/export", this.form, `${this.$store.state.common.commandName}-billing-${this.toDateFormat(new Date(), true)}.xlsx`, () => this.skuLoading = false);
    },
    //导出
    exportDetails(row) {
      if (this.disabledBtn) return this.$message('正在计算中请耐心等待!')
      this.skuLoading = true
      this.downBlobFile("/bill/billing/exportDetails", row, `${row.clientCode}-${row.warehouseCode}-${this.toDateFormat(new Date(), true)}.xlsx`, () => this.skuLoading = false);
    },


    //条数
    handleSizeChange(val) {
      this.pageSize = val
      let query = { current: this.pageCurrent, size: val }
      this.Query(query)
      console.log(`每页 ${val} 条`);
    },
    //当前页数
    handleCurrentChange(val) {
      this.pageCurrent = val
      let query = { current: val, size: this.pageSize }
      this.Query(query)
      console.log(`当前页: ${val}`);
    },
    // 计算
    async count(row) {
      if (this.disabledBtn) return this.$message('正在计算中请耐心等待!')
      // 确认是否计算
      this.$confirm("Recalculating all monthly bills for this data will take about one minutes. Please be patient!", "Tips", {
        confirmButtonText: "submit",
        cancelButtonText: "cancel",
        type: "warning",
      })
        .then(async () => {
          this.skuLoading = true
          this.disabledBtn = true
          let { data } = await recount(row)
          if (data.code != 0) {
            this.skuLoading = false
            return this.$message.error(data.msg)
          }
          this.timeId = setTimeout(() => {
            this.disabledBtn = false
            window.localStorage.removeItem('billlingBtnTime')
            // this.Query()
          }, 60000)
          this.$message(data.msg)
          window.localStorage.setItem('billlingBtnTime', +new Date())
          this.skuLoading = false
          console.log("🚀→→→→→ ~ 计算:", data)
        }).catch((e)=>{})

    },
    // 用户点击后 一分钟后才可以再次点击计算或者下载
    isClick() {
      let time
      if (window.localStorage.getItem('billlingBtnTime') === null) {
        this.disabledBtn = false
      } else {
        time = +new Date() - (window.localStorage.getItem('billlingBtnTime'))
        if (time >= 60000) {
          this.disabledBtn = false
          window.localStorage.removeItem('billlingBtnTime')
        } else {
          console.log((60000 - time) / 1000 + '秒后才可以再次点击计算、下载');
          this.disabledBtn = true
          this.timeId = setTimeout(() => {
            this.disabledBtn = false
            // this.Query()
            window.localStorage.removeItem('billlingBtnTime')
          }, 60000 - time)
        }
      }
    },
  },
};
</script>
<style lang="scss" scoped>
::v-deep .el-select--small {
  display: block;
}

.jisuan {
  width: 25px;
  cursor: pointer;
  margin: 0 5px;
}

.jisuan1 {
  width: 25px;
  cursor: no-drop;
  margin: 0 5px;
}


.dialog-footer-add {
  display: flex;
  justify-content: center;
  color: rgb(64, 149, 229);
  font-size: 25px;
}

.dialog-footer-box {
  display: flex;
  justify-content: center;
  margin-top: 100px;
}

.content {
  padding: 0 10px;

  .down {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    border-top: 1px solid #999;
    padding-top: 20px;
    box-sizing: border-box;
  }

  .underLine {
    color: #599af8;
    text-decoration: underline;

    .underIcon {
      background-color: green;
      color: #fff;
      border-radius: 50%;
      margin-right: 5px;
    }
  }
}

.operate-icon-wrap {
  display: flex;
  column-gap: 15px;
}

.operate-icon-box {
  display: flex;
  align-items: center;
  cursor: pointer;
  color: #4095e5;
}

.header-cell-class {
  background-color: #ccc;
}

.foot {
  display: flex;
  justify-content: flex-end;
  margin-top: 20px;
}

.btn-bgc {
  background-color: rgb(31, 99, 255);
  color: #fff;
}

.confrim-bgc {
  background-color: #1376c7;
  color: #fff;
}

.cursor-on {
  cursor: pointer;
}

::v-deep .el-dialog__wrapper .el-dialog {
  border-radius: 8px;
}
</style>