<template>
  <div class="content">
    <el-tabs type="border-card" v-loading="skuLoading">
      <el-row style="width:200px;display:flex">
        <el-col>
          <el-button type="primary" icon="el-icon-search" @click="Query()">Query</el-button>
        </el-col>
        <el-col>
          <el-button @click="resetForm('form')" type="info" plain icon="el-icon-refresh-left">Reset</el-button>
        </el-col>
      </el-row>
      <el-form ref="form" :model="form">
        <el-row style="margin-top: 20px" :gutter="20">
          <el-col :span="4">
            <el-form-item prop="warehouseCode">
              <el-select filterable clearable v-model="form.warehouseCode" placeholder="Warehouse">
                <el-option v-for="item in warehouseArr" :key="item.warehouseCode" :label="item.warehouseName"
                  :value="item.warehouseCode"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="4">
            <el-form-item prop="month">
              <el-date-picker style="width:100%" v-model="form.month" type="month" value-format="yyyy-MM"
                placeholder="Month">
              </el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span="4">
            <el-form-item prop="amountType">
              <el-select filterable clearable v-model="form.amountType" placeholder="Amount Type">
                <el-option v-for="item in amountArr" :label="item" :value="item" :key="item">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="4">
            <el-form-item prop="refNo">
              <el-input v-model.trim="form.refNo" placeholder="Ref No"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="4">
            <el-form-item prop="remark">
              <el-input v-model.trim="form.remark" placeholder="Remark"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div class="down">
        <span></span>
        <div>
          <!-- 下载 -->
          <el-button v-if="permissions.bill_billingDetails_export" icon="el-icon-download"
            @click="exportExcel"></el-button>
        </div>
      </div>
      <!-- 数据表 -->
      <el-table tooltip-effect="dark" stripe border ref="multipleTable" :data="tableData.records" style="width: 100%"
        header-cell-class-name="header-cell-class" :header-cell-style="{ background: '#f5f7fa', color: '#606266' }">
        <el-table-column :show-overflow-tooltip="true" label="Owner" min-width="100" align="center">
          <template slot-scope="scope">{{ scope.row.clientCode }}</template>
        </el-table-column>

        <el-table-column :show-overflow-tooltip="true" label="Warehouse" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.warehouseCode }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Month" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.month }}</template>
        </el-table-column>

        <el-table-column :show-overflow-tooltip="true" label="Date" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.date }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Amount Type" min-width="150" align="center">
          <template slot-scope="scope">{{ scope.row.amountType }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Qty" min-width="100" align="center">
          <template slot-scope="scope">{{ scope.row.qty }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Unit Price" min-width="100" align="center">
          <template slot-scope="scope">{{ scope.row.unitPrice }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Total Price" min-width="100" align="center">
          <template slot-scope="scope">{{ scope.row.totalPrice }} {{ scope.row.currency }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Ref" min-width="150" align="center">
          <template slot-scope="scope">{{ scope.row.refNo }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Remark" min-width="180" align="center">
          <template slot-scope="scope">{{ scope.row.remark }}</template>
        </el-table-column>
      </el-table>

      <Pagination @handleSizeChange="handleSizeChange" @handleCurrentChange="handleCurrentChange"
        :pageNum="tableData.current" :pageSize="tableData.size" :total="tableData.total"></Pagination>
    </el-tabs>
  </div>
</template>
<script>
let formParams = {
  warehouseCode: '',
  month: '',
  amountType: '',
  refNo: '',
  remark: '',
};
import { mapGetters } from "vuex"
import Pagination from "@/components/pagination/pagination.vue"
import { deepClone } from '@/util/util';
import ExcelUpload from "@/components/upload/excel"
import { btnAntiShake } from '@/util/btnAntiShake'
import { remote } from '@/api/admin/dict'
import store from '@/store'
import { getData, queryData } from '@/api/billingDetails'
import { AddParentWarehouseCodes, getAmountType } from "@/api/quotation"
export default {
  name: "ASN",
  data() {
    return {
      amountArr: [],
      warehouseArr: [],
      skuNoDisabled: false,
      clientCodeName: '',
      dialogTitle: '',
      isDisCode: false,
      btnType: '',
      skuLoading: false,
      pageSize: '',
      pageCurrent: '1',
      detailAdd: false,
      form: Object.assign({}, formParams),
      options: [
      ],
      // 基本数据
      tableData: [],
      size: 10,
      total: 100,
      //   修改表单
      updateObj: {
      },
      // add表单
      pClientArr: [],
      rules: {
        partNumber: [
          { required: true, message: '此区域为必填项', trigger: "change" },
        ],
        hsCode: [
          { required: true, message: '此区域为必填项', trigger: "change" },
        ],
        dutyRate: [
          { required: true, message: '此区域为必填项', trigger: "change" },
        ],
      }
    }
  },
  // ============
  created() {
    // 当前的用户
    this.clientCodeName = store.getters.commandName
    if (this.$route.query.row) {
      this.form = JSON.parse(this.$route.query.row)
      this.Query(this.form)
      console.log('this.form', JSON.parse(JSON.stringify(this.form)))
    } else {
      this.Query()
    }
  },
  components: {
    ExcelUpload,
    Pagination
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  mounted() {
    this.exportExcel = btnAntiShake(this.exportExcel, 500)
  },
  methods: {
    // 通过条件查询数据
    async Query(query) {
      if (!query) {
        this.pageCurrent = 1
        this.pageSize = 10
        query = { current: this.pageCurrent, size: this.pageSize }
      }
      let queryObj = Object.assign(this.form, query)
      console.log('携带的参数', queryObj);
      this.skuLoading = true
      let { data: warehouse } = await AddParentWarehouseCodes()
      this.warehouseArr = warehouse.data
      let { data: amount } = await getAmountType()
      this.amountArr = amount.data
      let { data } = await queryData(queryObj)
      if (data.code != 0) {
        this.skuLoading = false //关loading
        this.$message.error(data.msg);
        return;
      }
      this.skuLoading = false //关loading
      this.tableData = deepClone(data.data)
      console.log('页面基本数据', JSON.parse(JSON.stringify(this.tableData)))
    },
    // 重置
    resetForm(rule) {
      this.form = Object.assign({}, formParams);
      this.Query()
    },
    //导出
    exportExcel() {
      this.skuLoading = true
      this.downBlobFile("/bill/billingDetails/export", this.form, `${this.$store.state.common.commandName}-billingDetails-${this.toDateFormat(new Date(), true)}.xlsx`, () => this.skuLoading = false);
    },
    //条数
    handleSizeChange(val) {
      this.pageSize = val
      let query = { current: this.pageCurrent, size: val }
      this.Query(query)
      console.log(`每页 ${val} 条`);
    },
    //当前页数
    handleCurrentChange(val) {
      this.pageCurrent = val
      let query = { current: val, size: this.pageSize }
      this.Query(query)
      console.log(`当前页: ${val}`);
    },
  },
};
</script>
<style lang="scss" scoped>
::v-deep .el-select--small {
  display: block;
}

.jisuan {
  width: 25px;
  cursor: pointer;
  margin: 0 5px;
}

.dialog-footer-add {
  display: flex;
  justify-content: center;
  color: rgb(64, 149, 229);
  font-size: 25px;
}

.dialog-footer-box {
  display: flex;
  justify-content: center;
  margin-top: 100px;
}

.content {
  padding: 0 10px;

  .down {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    border-top: 1px solid #999;
    padding-top: 20px;
    box-sizing: border-box;
  }

  .underLine {
    color: #599af8;
    text-decoration: underline;

    .underIcon {
      background-color: green;
      color: #fff;
      border-radius: 50%;
      margin-right: 5px;
    }
  }
}

.operate-icon-wrap {
  display: flex;
  column-gap: 15px;
}

.operate-icon-box {
  display: flex;
  align-items: center;
  cursor: pointer;
  color: #4095e5;
}

.header-cell-class {
  background-color: #ccc;
}

.foot {
  display: flex;
  justify-content: flex-end;
  margin-top: 20px;
}

.btn-bgc {
  background-color: rgb(31, 99, 255);
  color: #fff;
}

.confrim-bgc {
  background-color: #1376c7;
  color: #fff;
}

.cursor-on {
  cursor: pointer;
}

::v-deep .el-dialog__wrapper .el-dialog {
  border-radius: 8px;
}
</style>