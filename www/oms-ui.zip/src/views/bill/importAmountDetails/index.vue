<template>
  <div class="content">
    <el-tabs type="border-card" v-loading="skuLoading">
      <el-row style="width:200px;display:flex">
        <el-col>
          <el-button type="primary" icon="el-icon-search" @click="Query()">Query</el-button>
        </el-col>
        <el-col>
          <el-button @click="resetForm('form')" type="info" plain icon="el-icon-refresh-left">Reset</el-button>
        </el-col>
      </el-row>
      <el-form ref="form" :model="form">
        <el-row style="margin-top: 20px" :gutter="20">
          <el-col :span="4">
            <el-form-item prop="blNo">
              <el-input v-model.trim="form.blNo" placeholder="BL no / JobNo"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="4">
            <el-form-item prop="warehouseCode">
              <el-select filterable clearable v-model="form.warehouseCode" placeholder="Warehouse">
                <el-option v-for="item in warehouseArr" :key="item.warehouseCode" :label="item.warehouseName"
                  :value="item.warehouseCode"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="7">
            <el-form-item prop="arrivedTime">
              <el-date-picker style="width:100%" v-model="form.arrivedTime" type="datetimerange"
                value-format="yyyy-MM-dd HH:mm:ss" placeholder="Arrived Time" range-separator="至"
                start-placeholder="arrivedTimeBegin" end-placeholder="arrivedTimeFinish"
                @change="timeFrame($event, 'arrivedTime')"></el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span="7">
            <el-form-item prop="createTime">
              <el-date-picker style="width:100%" v-model="form.createTime" type="datetimerange"
                value-format="yyyy-MM-dd HH:mm:ss" placeholder="Create Time" range-separator="至"
                start-placeholder="createTimeBegin" end-placeholder="createTimeFinish"
                @change="timeFrame($event, 'createTime')"></el-date-picker>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div class="down">
        <!-- Add按钮 -->
        <el-button :disabled="customerPermissions" v-if="permissions.bill_importAmountDetails_save" type="primary"
          style=" padding: 5px 20px; color: #fff;  " @click="modifyBtn('', 'add')">
          <span style="display: flex; align-items: center">
            <i class="el-icon-circle-plus-outline" style="margin-right: 10px; font-size: 20px"></i>Add
          </span>
        </el-button>
        <span v-else></span>
        <div>
          <excel-upload ref="BackUpRef" title="ImportAmountDetails upload" url="/bill/importAmountDetails/uploadByExcel"
            temp-name="importAmount-upload.xlsx" temp-url="/admin/sys-file/local/importAmount-upload.xlsx"
            @refreshDataList="uploadHsCode">
          </excel-upload>
          <!-- 上传 -->
          <el-button :disabled="customerPermissions" v-if="permissions.bill_importAmountDetails_upload"
            icon="el-icon-upload2" @click="$refs.BackUpRef.show()">
          </el-button>
          <!-- 下载 -->
          <el-button v-if="permissions.bill_importAmountDetails_export" icon="el-icon-download"
            @click="exportExcel"></el-button>
        </div>
      </div>
      <!-- 数据表 -->
      <el-table tooltip-effect="dark" border ref="multipleTable" :data="tableData.records" style="width: 100%"
        header-cell-class-name="header-cell-class" :header-cell-style="{ background: '#f5f7fa', color: '#606266' }"
        :cell-style="upperColor">
        <el-table-column :show-overflow-tooltip="true" label="Owner" min-width="100" align="center">
          <template slot-scope="scope">{{ scope.row.clientCode }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Warehouse" min-width="100" align="center">
          <template slot-scope="scope">{{ scope.row.warehouseCode }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="JobNo" min-width="120" align="center">
          <template slot-scope="scope">
            <el-button @click="modifyBtn(scope.row, 'detail')" type="text">{{ scope.row.blNo }}</el-button>
          </template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="BL no" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.awb }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Import C/D" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.importCD ? scope.row.importCD + ' ' + scope.row.currency : ''
                      }}</template>
        </el-table-column>

        <el-table-column :show-overflow-tooltip="true" label="Inland Transport" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.inlandTransport ? scope.row.inlandTransport + ' ' + scope.row.currency
                      : '' }}</template>
        </el-table-column>

        <el-table-column :show-overflow-tooltip="true" label="THC" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.thc ? scope.row.thc + ' ' + scope.row.currency : ''
                      }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Duty & Tax" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.dutyTax ? scope.row.dutyTax + ' ' + scope.row.currency : ''
                      }}</template>
        </el-table-column>

        <el-table-column :show-overflow-tooltip="true" label="Arrived Time" min-width="150" align="center">
          <template slot-scope="scope">{{ scope.row.arrivedTime }}</template>
        </el-table-column>

        <el-table-column :show-overflow-tooltip="true" label="Create Time" min-width="150" align="center">
          <template slot-scope="scope">{{ scope.row.createTime }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Create User" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.createBy }}</template>
        </el-table-column>
        <el-table-column
          v-if="permissions.bill_importAmountDetails_update || permissions.bill_importAmountDetails_del || permissions.bill_importAmountDetails_download"
          :show-overflow-tooltip="true" label="Opearte" min-width="120" align="center">
          <template slot-scope="scope">
            <el-button :disabled="customerPermissions" v-if="permissions.bill_importAmountDetails_update" type="text"
              style="font-size:18px;" icon="el-icon-edit" @click="modifyBtn(scope.row, 'change')">
            </el-button>
            <el-button :disabled="customerPermissions" v-if="permissions.bill_importAmountDetails_del" type="text"
              style="font-size:18px;" icon="el-icon-delete" @click="deleteBtn(scope.$index, scope.row)">
            </el-button>
            <el-button v-if="permissions.bill_importAmountDetails_download" type="text" style="font-size:18px;"
              icon="el-icon-download" @click="downloadFiles(scope.row)">
            </el-button>
          </template>
        </el-table-column>
      </el-table>
      <Pagination @handleSizeChange="handleSizeChange" @handleCurrentChange="handleCurrentChange"
        :pageNum="tableData.current" :pageSize="tableData.size" :total="tableData.total"></Pagination>

    </el-tabs>
  </div>
</template>
<script>
let formParams = {
  blNo: '',
  warehouseCode: '',
  createTimeBegin: '',
  createTimeFinish: '',
  arrivedTimeBegin: '',
  arrivedTimeFinish: '',
  arrivedTime: [],
  createTime: [],
};
import { mapGetters } from "vuex"
import Pagination from "@/components/pagination/pagination.vue"
import { deepClone } from '@/util/util';
import ExcelUpload from "@/components/upload/excel"
import { btnAntiShake } from '@/util/btnAntiShake'
import { remote } from '@/api/admin/dict'
import store from '@/store'
import { getBillData, delObj, queryBill } from '@/api/importAmountDetails'
import { AddParentWarehouseCodes } from "@/api/quotation"

export default {
  name: "ASN",
  data() {
    return {
      customerPermissions: false,  //客户的权限如果是客户 Lux-mate 则不允许更改数据
      warehouseArr: [],
      skuNoDisabled: false,
      clientCodeName: '',
      dialogTitle: '',
      isDisCode: false,
      btnType: '',
      skuLoading: false,
      pageSize: '',
      pageCurrent: '1',
      detailAdd: false,
      form: Object.assign({}, formParams),
      options: [
      ],
      // 基本数据
      tableData: [],
      size: 10,
      total: 100,
      //   修改表单
      updateObj: {
      },
      // add表单
      pClientArr: [],
      rules: {
        partNumber: [
          { required: true, message: '此区域为必填项', trigger: "change" },
        ],
        hsCode: [
          { required: true, message: '此区域为必填项', trigger: "change" },
        ],
        dutyRate: [
          { required: true, message: '此区域为必填项', trigger: "change" },
        ],
      }
    }
  },
  // ============
  created() {
    // 当前的用户
    this.clientCodeName = store.getters.commandName
    this.Query()
    this.eventBus.$on('query', () => this.Query())
    this.customerPermissions = this.$store.state.common.commandName === 'Lux-mate'
  },
  components: {
    ExcelUpload,
    Pagination
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  mounted() {
    this.exportExcel = btnAntiShake(this.exportExcel, 500)
  },
  methods: {
    // 通过条件查询数据
    async Query(query) {
      if (!query) {
        this.pageCurrent = 1
        this.pageSize = 10
        query = { current: this.pageCurrent, size: this.pageSize }
      }
      let queryObj = Object.assign(this.form, query)
      this.skuLoading = true
      let { data: warehouse } = await AddParentWarehouseCodes()
      this.warehouseArr = warehouse.data
      let { data } = await queryBill(queryObj)
      if (data.code != 0) {
        this.skuLoading = false //关loading
        this.$message.error(data.msg);
        return;
      }
      this.skuLoading = false //关loading
      this.tableData = deepClone(data.data)
      this.upperColorData(this.tableData)
      console.log('页面基本数据', JSON.parse(JSON.stringify(this.tableData)))
    },
    // 标记未完成的数据着重提示
    upperColor({ row }) {
      if (row.status == '0') return 'background: beige'
      return ''
    },
    // 如果有未填完成的数据，则提示
    upperColorData(row) {
      for (let item of row.records) {
        if (item.status == '0') return this.$message.warning('请完善有颜色标记的数据')
      }
    },
    // 重置
    resetForm(rule) {
      this.form = Object.assign({}, formParams);
      this.Query()
    },
    //导出
    exportExcel() {
      this.skuLoading = true
      this.downBlobFile("/bill/importAmountDetails/export", this.form, `${this.$store.state.common.commandName}-ImportAmountDetails-${this.toDateFormat(new Date(), true)}.xlsx`, () => this.skuLoading = false);
    },

    // 上传
    uploadHsCode(response) {
      if (response == 'loading') {
        this.skuLoading = true
        return
      }
      if (!!response && response.code == 0) {
        this.skuLoading = false
      } else {
        this.skuLoading = false
      }
      this.Query()
    },
    //条数
    handleSizeChange(val) {
      this.pageSize = val
      let query = { current: this.pageCurrent, size: val }
      this.Query(query)
      console.log(`每页 ${val} 条`);
    },
    //当前页数
    handleCurrentChange(val) {
      this.pageCurrent = val
      let query = { current: val, size: this.pageSize }
      this.Query(query)
      console.log(`当前页: ${val}`);
    },
    // 新增或者修改按钮,详情
    async modifyBtn(row, type) {
      let btnType = type
      //新增数据 
      if (btnType == 'add') {
        this.$router.push({
          path: `/importAmountAdd`,
          query: {
            btnType: btnType
          }
        })
      } else if (btnType == 'change' || btnType == 'detail') {
        // 修改数据     // 跳转到详情
        this.$router.push({
          path: `/importAmountAdd`,
          query: {
            name: row.blNo,
            id: row.id,
            btnType: btnType
          }
        })
      }
    },

    // 删除数据
    deleteBtn(index, row) {
      console.log('要删除的这一行数据', JSON.parse(JSON.stringify(row)))
      this.$confirm("This operation will permanently delete this data. Do you want to continue?", "Tips", {
        confirmButtonText: "submit",
        cancelButtonText: "cancel",
        type: "warning",
      })
        .then(async () => {
          let { data } = await delObj(row.id)
          if (data.code != 0) return this.$message.error(data.msg)
          this.$message.success(data.msg)
          this.Query()
        })
        .catch(() => {
          // this.$message.info('Destruction cancelled')
        });
    },
    //  下载附件
    downloadFiles(row) {
      this.skuLoading = true
      // this.downBlobFile("/bill/importAmountDetails/download/" + row.id, '', `${this.$store.state.common.commandName}-ImportAmountFiles-${this.toDateFormat(new Date(), true)}.zip`, () => this.skuLoading = false);
      this.newDownBlobFile("/bill/importAmountDetails/download/" + row.id, '', `${row.clientCode}-${row.blNo}-${this.toDateFormat(new Date(), true)}`, () => this.skuLoading = false);
    },
    // 选择时间范围查询 
    timeFrame(val, btn) {
      if (btn === 'arrivedTime') {
        if (Array.isArray(val)) {
          this.form.arrivedTimeBegin = val[0]
          this.form.arrivedTimeFinish = val[1]
        } else {
          this.form.arrivedTimeBegin = ''
          this.form.arrivedTimeFinish = ''
        }
      } else if (btn === 'createTime') {
        if (Array.isArray(val)) {
          this.form.createTimeBegin = val[0]
          this.form.createTimeFinish = val[1]
        } else {
          this.form.createTimeBegin = ''
          this.form.createTimeFinish = ''
        }
      }
      console.log('🚀→→→→→选择时间', JSON.parse(JSON.stringify(this.form)))
    },
  },
};
</script>
<style lang="scss" scoped>
::v-deep .el-select--small {
  display: block;
}

.content {
  padding: 0 10px;

  .down {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    border-top: 1px solid #999;
    padding-top: 20px;
    box-sizing: border-box;
  }

}

.header-cell-class {
  background-color: #ccc;
}
</style>