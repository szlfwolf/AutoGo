<template>
  <basic-container>
    <div class="avue-crud content">
      <div v-loading="skuLoading">
        <div class="title">
          <span></span>
          <label for="">Import Amount Info</label>
        </div>
        <div class="contain">
          <el-form ref="rowParams" :rules="rules" :model="rowParams" label-width="160px">
            <el-row>
              <el-col :span="12">
                <el-form-item label="BL no:" :prop="btnType == 'add' ? 'blNo' : 'awb'">
                  <el-input v-if="btnType == 'add'" :disabled="btnType != 'add'" @change="blNoChange"
                    v-model.trim="rowParams.blNo"></el-input>
                  <el-input v-else :disabled="btnType != 'add'" @change="blNoChange"
                    v-model.trim="rowParams.awb"></el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="12">
                <el-form-item label="Owner:" prop="clientCode">
                  <el-input disabled v-model="rowParams.clientCode"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item label="Currency:" prop="currency">
                  <el-input disabled v-model="rowParams.currency"></el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="12">
                <el-form-item label="Job no:" :prop="btnType == 'add' ? 'jobNo' : 'blNo'">
                  <el-input v-if="btnType == 'add'" disabled v-model="rowParams.jobNo"></el-input>
                  <el-input v-else disabled v-model="rowParams.blNo"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item label="Warehouse:" prop="warehouseCode">
                  <el-input disabled v-model="rowParams.warehouseCode"></el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="12">
                <el-form-item label="Inland Transport:" prop="inlandTransport">
                  <el-input disabled maxlength="8" v-model="rowParams.inlandTransport">
                  </el-input>
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item label="Import C/D:" prop="importCD">
                  <el-input disabled maxlength="8" v-model="rowParams.importCD"></el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="12">
                <el-form-item label="THC:" prop="thc">
                  <el-input :disabled="btnType == 'detail'" maxlength="8" v-model.trim="rowParams.thc">
                    <el-button slot="append" icon="el-icon-paperclip" :disabled="btnType == 'detail' || !rowParams.thc"
                      :style="{ color: rowParams.thc && btnType != 'detail' ? '#65BEFF' : '' }"
                      @click="proofBtn('thcProof')">
                    </el-button>
                  </el-input>
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item label="Duty & Tax:" prop="dutyTax">
                  <el-input :disabled="btnType == 'detail'" maxlength="8" v-model.trim="rowParams.dutyTax">
                    <el-button slot="append" icon="el-icon-paperclip"
                      :disabled="btnType == 'detail' || !rowParams.dutyTax"
                      :style="{ color: rowParams.dutyTax && btnType != 'detail' ? '#65BEFF' : '' }"
                      @click="proofBtn('dutyTaxProof')">
                    </el-button>
                  </el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <template>
              <!-- 数据表 -->
              <el-table
                v-if="rowParams.importContainerAmountList != null && rowParams.importContainerAmountList.length > 0"
                class=" import" tooltip-effect="dark" stripe border ref="multipleTable" height="300"
                :data="rowParams.importContainerAmountList" style="width: 100%; "
                header-cell-class-name="header-cell-class"
                :header-cell-style="{ background: '#f5f7fa', color: '#606266' }">
                <el-table-column :show-overflow-tooltip="true" label="ContainerNo" min-width="60" align="center">
                  <template slot-scope="scope">{{ scope.row.containerNo }}</template>
                </el-table-column>
                <el-table-column label="Demurrage" min-width="100" align="center">
                  <template slot-scope="scope">
                    <el-form-item :show-message="false" :prop="'importContainerAmountList.' + scope.$index + '.demurrage'"
                      :rules="rules.demurrage">
                      <el-input :disabled="btnType == 'detail'" maxlength="8" v-model.trim="scope.row.demurrage">
                        <el-button slot="append" icon="el-icon-paperclip"
                          :disabled="btnType == 'detail' || !scope.row.demurrage"
                          :style="{ color: scope.row.demurrage && btnType != 'detail' ? '#65BEFF' : '' }"
                          @click="proofBtn('demurrageProof', scope.$index)">
                        </el-button>
                      </el-input>
                    </el-form-item>
                  </template>
                </el-table-column>
                <el-table-column label="Handling-FCL" min-width="100" align="center">
                  <template slot-scope="scope">
                    <el-form-item :show-message="false"
                      :prop="'importContainerAmountList.' + scope.$index + '.handlingFcl'" :rules="rules.handlingFcl">
                      <el-input :disabled="btnType == 'detail'" maxlength="8" v-model.trim="scope.row.handlingFcl">
                        <el-button slot="append" icon="el-icon-paperclip"
                          :disabled="btnType == 'detail' || !scope.row.handlingFcl"
                          :style="{ color: scope.row.handlingFcl && btnType != 'detail' ? '#65BEFF' : '' }"
                          @click="proofBtn('handlingFclProof', scope.$index)">
                        </el-button>
                      </el-input>
                    </el-form-item>
                  </template>
                </el-table-column>
                <el-table-column label="Disbursement" min-width="100" align="center">
                  <template slot-scope="scope">
                    <el-form-item :show-message="false"
                      :prop="'importContainerAmountList.' + scope.$index + '.disbursement'" :rules="rules.disbursement">
                      <el-input :disabled="btnType == 'detail'" maxlength="8" v-model.trim="scope.row.disbursement">
                        <el-button slot="append" icon="el-icon-paperclip"
                          :disabled="btnType == 'detail' || !scope.row.disbursement"
                          :style="{ color: scope.row.disbursement && btnType != 'detail' ? '#65BEFF' : '' }"
                          @click="proofBtn('disbursementProof', scope.$index)">
                        </el-button>
                      </el-input>
                    </el-form-item>
                  </template>
                </el-table-column>
                <el-table-column label="Classification" min-width="100" align="center">
                  <template slot-scope="scope">
                    <el-form-item :show-message="false"
                      :prop="'importContainerAmountList.' + scope.$index + '.classification'"
                      :rules="rules.classification">
                      <el-input :disabled="btnType == 'detail'" maxlength="8" v-model.trim="scope.row.classification">
                        <el-button slot="append" icon="el-icon-paperclip"
                          :disabled="btnType == 'detail' || !scope.row.classification"
                          :style="{ color: scope.row.classification && btnType != 'detail' ? '#65BEFF' : '' }"
                          @click="proofBtn('classificationProof', scope.$index)">
                        </el-button>
                      </el-input>
                    </el-form-item>
                  </template>
                </el-table-column>
                <el-table-column label="Others" min-width="100" align="center">
                  <template slot-scope="scope">
                    <el-form-item :show-message="false" :prop="'importContainerAmountList.' + scope.$index + '.others'"
                      :rules="rules.others">
                      <el-input :disabled="btnType == 'detail'" maxlength="8" v-model.trim="scope.row.others">
                        <el-button slot="append" icon="el-icon-paperclip"
                          :disabled="btnType == 'detail' || !scope.row.others"
                          :style="{ color: scope.row.others && btnType != 'detail' ? '#65BEFF' : '' }"
                          @click="proofBtn('othersProof', scope.$index)">
                        </el-button>
                      </el-input>
                    </el-form-item>
                  </template>
                </el-table-column>
                <el-table-column label="Remark" min-width="100" align="center">
                  <template slot-scope="scope">
                    <el-input :disabled="btnType == 'detail'" v-model.trim="scope.row.remark"> </el-input>
                  </template>
                </el-table-column>
              </el-table>
            </template>
            <!-- 上传 -->
            <JpgUpload ref="File" title="File upload" url="/bill/importAmountDetails/uploadProofFile" :data="uploadData"
              accept=".jpg, .jpeg, .png, .JPG, .JPEG, .PNG, .pdf, .PDF, .docx, .DOCX, .doc, .DOC, .xlsx, .XLSX, .xls, .XLS, .ppt, .PPT, .pptx, .PPTX"
              :limit="1" @refreshDataList="uploadHsCode">
            </JpgUpload>
            <div class="dialog-footer-box">
              <span slot="footer">
                <el-button @click="cancelClo" style="margin-right: 20px; padding: 10px 40px" type="info">Cancel
                </el-button>
                <el-button v-if="btnType != 'detail'" type="primary" @click="updateSub"
                  style="padding: 10px 40px">Confrim</el-button>
              </span>
            </div>
          </el-form>
        </div>
      </div>

    </div>
  </basic-container>
</template>
<script>
import { addSave, update, getBlNo, getImportAmountDetails } from '@/api/importAmountDetails'
import { remote } from '@/api/admin/dict'
import { mapGetters } from "vuex"
import { deepClone } from '@/util/util';
import { btnAntiShake } from '@/util/btnAntiShake';
import JpgUpload from "@/components/upload/jpgPdfUpload"
import Pagination from "@/components/pagination/pagination.vue"
export default {
  name: "adDetail",
  data() {
    const pattern = [
      { pattern: /^(([1-9]\d*)|([0][.]{1}[0-9]{0,2}[1-9]+)|([1-9]\d*[.]{1}[0-9]+))$/g, message: '请输入大于0的整数或小数', trigger: 'change' },
    ]
    const required = [
      { required: true, message: "此区域为必填项", trigger: "change" },
    ]
    return {
      uploadData: null,
      uploadName: '',
      skuLoading: false,
      btnType: '',
      rowParams: {
        awb: '',
        clientCode: '',
        currency: '',
        blNo: '',
        jobNo: '',
        warehouseCode: '',
        inlandTransport
          : '',
        importCD: '',
        thc: '',
        dutyTax: '',
        importContainerAmountList: []
      },
      rules: {
        awb: required,
        clientCode: required,
        warehouseCode: required,
        blNo: required,
        jobNo: required,
        importCD: required,
        currency: required,
        inlandTransport
          : required,
        handlingFcl: pattern,
        demurrage: pattern,
        classification: pattern,
        disbursement: pattern,
        others: pattern,
        thc: [
          { required: true, message: "此区域为必填项", trigger: "change" },
          { pattern: /^(([1-9]\d*)|([0][.]{1}[0-9]{0,2}[1-9]+)|([1-9]\d*[.]{1}[0-9]+))$/g, message: '请输入大于0的整数或小数', trigger: 'change' },
        ],
        dutyTax: [
          { required: true, message: "此区域为必填项", trigger: "change" },
          { pattern: /^(([1-9]\d*)|([0][.]{1}[0-9]{0,2}[1-9]+)|([1-9]\d*[.]{1}[0-9]+))$/g, message: '请输入大于0的整数或小数', trigger: 'change' },
        ],
      },
    };
  },
  created() {
    this.btnType = this.$route.query.btnType
    this.getSelect()
  },
  mounted() {
    this.updateSub = btnAntiShake(this.updateSub, 500)
  },
  components: {
    JpgUpload,
    Pagination
  },
  computed: {
    ...mapGetters(["permissions", "tagList"]),
  },
  watch: {
    // 利用watch方法检测路由变化：
    $route: function (to, from) {
      if (to.path == '/importAmountAdd/index' && this.$route.query.id) {
        // 编辑
        if (to.query.id !== from.query.id) {
          this.getSelect()
        }
        this.btnType = this.$route.query.btnType
      } else {
        // 添加
        this.btnType = this.$route.query.btnType
        this.$refs.rowParams.resetFields()
        this.getSelect()
      }
    }
  },


  methods: {
    // 通过id查询需要的数据
    async getSelect() {
      let id = this.$route.query.id
      if (id) {
        this.skuLoading = true
        let { data } = await getImportAmountDetails(id)
        if (data.code != 0) {
          this.skuLoading = false
          return this.$message.error(data.msg)
        }
        this.skuLoading = false
        console.log('查询到的数据', JSON.parse(JSON.stringify(data.data)))
        this.rowParams = data.data
      } else {
        this.uploadData = null//凭证参数
        this.rowParams.importContainerAmountList = []
      }
    },
    // blNo 输入框变化请求接口
    blNoChange(val) {
      getBlNo({ billLandNum: val }).then(({ data }) => {
        console.log("🚀→→→→→ ~ data", data)
        if (data.code === 0) {
          this.rowParams = { ...this.rowParams, ...data.data }
        } else {
          this.rowParams = {}
          this.$message.error(data.msg)
        }
      }).catch(() => {
        this.$refs.rowParams.resetFields()
        this.rowParams.importContainerAmountList = []
      })
    },
    findTag(value) {
      let tag, key;
      this.tagList.map((item, index) => {
        if (item.value.includes(value)) {
          tag = item;
          key = index;
        }
      });
      return { tag: tag, key: key };
    },
    //清除表单
    cancelClo() {
      this.$refs.rowParams.resetFields()
      let { tag, key } = this.findTag(this.$route.fullPath);
      this.$store.commit('DEL_TAG', tag)
      this.$router.push({
        path: "/bill/importAmountDetails/index"
      })
      this.eventBus.$emit('query')
    },
    // 上传
    uploadHsCode(response) {
      let index = this.uploadNameIndex
      let list = this.rowParams.importContainerAmountList
      if (this.uploadName == 'thcProof' || this.uploadName == 'dutyTaxProof') {
        // if (this.rowParams[this.uploadName]) {
        //   this.rowParams[this.uploadName] = this.rowParams[this.uploadName].split(',').concat(response.data).join(',')
        // } else {
        this.rowParams[this.uploadName] = response.data.join()
        // }
      } else {
        // if ((list[index])[this.uploadName]) {
        //   (list[index])[this.uploadName] = (list[index])[this.uploadName].split(',').concat(response.data).join(',')
        // } else {
        (list[index])[this.uploadName] = response.data.join()
        // }
      }
      console.log('this.rowParams', JSON.parse(JSON.stringify(this.rowParams)))
    },

    //新增/修改表单
    updateSub() {
      // 处理要提交的数据 
      let dataList = deepClone(this.rowParams)
      this.$refs.rowParams.validate(async (valid) => {
        // 凭证提示语
        let messageObj = {
          thcProof: 'THC',
          dutyTaxProof: 'Duty & Tax',
        }
        let messageObjTable = {
          demurrageProof: 'Demurrage',
          handlingFclProof: 'Handling-FCL',
          classificationProof: 'Classification',
          othersProof: 'Others',
          disbursementProof: 'Disbursement',
        }
        // input 对应的凭证字段
        let names = {
          thc: 'thcProof',
          dutyTax: 'dutyTaxProof',
        }
        let namesTable = {
          demurrage: 'demurrageProof',
          handlingFcl: 'handlingFclProof',
          classification: 'classificationProof',
          others: 'othersProof',
          disbursement: 'disbursementProof',
        }

        // 确定凭证是否上传
        if (!valid) return false;
        for (const i of Object.keys(names)) {
          if (String(this.rowParams[i]) === '0' || this.rowParams[i]) {
            if (!this.rowParams[names[i]]) return this.$message.warning('请上传' + messageObj[names[i]] + '凭证')
            if (this.rowParams.importContainerAmountList != null) {
              // 查table是否有填入，如果有那么检查凭证是否上传
              let list = Object.values(this.rowParams.importContainerAmountList)
              for (const itemTable of Object.keys(namesTable)) {
                for (let index in list) {
                  let item = list[index]
                  if (String(item[itemTable]) === '0' || item[itemTable]) {
                    // console.log('this.rowParams', JSON.parse(JSON.stringify(this.rowParams)))
                    if (!item[namesTable[itemTable]]) return this.$message.warning('请上传第' + (+index + 1) + '行' + messageObjTable[namesTable[itemTable]] + '凭证')
                  } else {
                    this.$set(item, itemTable, '')
                    this.$set(item, namesTable[itemTable], '')
                  }
                }
              }
            }

          } else {
            this.$set(this.rowParams, i, '')
            this.$set(this.rowParams, names[i], '')
          }
        }
        console.log('携带的参数', JSON.parse(JSON.stringify(dataList)))
        // 确认是修改还是新增
        if (this.btnType == 'add') {
          dataList.awb = dataList.blNo
          dataList.blNo = dataList.jobNo
          delete dataList.jobNo
          let { data } = await addSave(dataList)
          console.log('提交后返回的参数', JSON.parse(JSON.stringify(data)))
          if (data.code == 0) {
            this.$message.success(data.msg)
            this.cancelClo()
          } else {
            return this.$message.error(data.msg)
          }
        } else {
          let { data } = await update(dataList)
          console.log('提交后返回的参数', JSON.parse(JSON.stringify(data)))
          if (data.code == 0) {
            this.$message.success(data.msg)
            this.cancelClo()
          } else {
            return this.$message.error(data.msg)
          }
        }
      });

    },
    // 点击上传按钮
    proofBtn(val, index) {
      console.log("🚀→→→→→ ~ val", val)
      this.$refs.File.show()
      this.uploadName = val
      //  //凭证参数
      if (val == 'thcProof' || val == 'dutyTaxProof') {
        this.uploadData = { old: this.rowParams[val] }  //凭证参数
        console.log('原凭证', this.rowParams[val]);
      } else {
        if (this.rowParams.importContainerAmountList[index][val]) this.uploadData = { old: this.rowParams.importContainerAmountList[index][val] }  //凭证参数 
        console.log('原凭证', this.rowParams.importContainerAmountList[index][val]);
      }
      this.uploadNameIndex = index
    },
  },
};
</script>
<style lang="scss" scoped>
/* 去掉中间数据的分割线 */
::v-deep .el-table__row>td {
  border: none;
}

/* 去掉上面的线 */
::v-deep .el-table th.is-leaf {
  border: none;
}

/* 去掉最下面的那一条线 */
::v-deep .el-table::before {
  height: 0px;
}

.underLine {
  color: #599af8;
  text-decoration: underline;
}

.content {
  width: 100%;
  padding: 20px;
  box-sizing: border-box;

  .title {
    width: 100%;
    height: 30px;
    line-height: 30px;
    display: flex;
    margin-bottom: 10px;

    span {
      width: 3px;
      height: 30px;
      background-color: #000;
      margin-right: 10px;
    }

    label {
      font-weight: 700;
    }
  }

  .containBox {
    border-bottom: 1px solid #999;
    margin-bottom: 10px;
  }

  .contain {
    padding: 10px;
    box-sizing: border-box;

    label {
      display: inline;
      margin-right: 30px;
    }
  }



  .timeline {
    padding: 10px;

    .box {
      background-color: #f4f6f7;
      border-radius: 5px;
      padding: 10px 20px;
      box-sizing: border-box;

      .boxTop {
        font-weight: 700;
        margin-bottom: 10px;

        span {
          margin-left: 10px;
        }
      }

      .boxBottom {
        color: #666;
      }
    }
  }

  .contain-box {
    display: flex;
    column-gap: 20px;
  }

  .eplacement-parts-text {
    width: 100px;
    height: 30px;
    background-color: #000000;
    display: flex;
    justify-content: center;
    align-items: center;
    color: #fff;
    font-size: 12px;
    border-radius: 5px;
  }

  .dialog-footer-box {
    display: flex;
    justify-content: center;
    margin-top: 50px;
  }

  .confrim-bgc {
    background-color: #1376c7;
    color: #fff;
  }
}

.proofBtn {
  display: flex;
  align-items: center;
  justify-content: center;

  i {
    font-size: 18px;
    vertical-align: middle;
    margin-right: 5px;
  }

  span {
    vertical-align: middle;
  }
}

.other-class {
  display: flex;
  flex-direction: column;
  flex: 1;

  .el-form-item.el-form-item--small:first-child {
    margin-bottom: 26px;
  }
}

.import {
  ::v-deep .el-form-item__content {
    margin-left: 0 !important;
  }
}
</style>
