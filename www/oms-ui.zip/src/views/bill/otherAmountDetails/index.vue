<template>
  <div class="content">
    <el-tabs type="border-card" v-loading="skuLoading">
      <el-row style="width:200px;display:flex">
        <el-col>
          <el-button type="primary" icon="el-icon-search" @click="Query()">Query</el-button>
        </el-col>
        <el-col>
          <el-button @click="resetForm('form')" type="info" plain icon="el-icon-refresh-left">Reset</el-button>
        </el-col>
      </el-row>
      <el-form ref="form" :model="form">
        <el-row style="margin-top: 20px" :gutter="20">
          <el-col :span="4">
            <el-form-item prop="warehouseCode">
              <el-select filterable clearable v-model="form.warehouseCode" placeholder="Warehouse">
                <el-option v-for="item in warehouseArr" :key="item.warehouseCode" :label="item.warehouseName"
                  :value="item.warehouseCode"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="7">
            <el-form-item prop="createTime">
              <el-date-picker style="width:100%" v-model="form.createTime" type="datetimerange"
                value-format="yyyy-MM-dd HH:mm:ss" placeholder="Create Time" range-separator="至"
                start-placeholder="createTimeBegin" end-placeholder="createTimeFinish"
                @change="timeFrame($event, 'createTime')"></el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item prop="usedDateTime">
              <el-date-picker style="width:100%" v-model="form.usedDateTime" type="daterange" value-format="yyyy-MM-dd"
                placeholder="Create Time" range-separator="至" start-placeholder="usedTimeBegin"
                end-placeholder="usedTimeFinish" @change="timeFrame($event, 'usedDateTime')"></el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span="4">
            <el-form-item prop="ref">
              <el-input v-model.trim="form.ref" placeholder="Ref"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div class="down">
        <!-- Add按钮 -->
        <el-button :disabled="customerPermissions" v-if="permissions.bill_otherAmountDetails_save" type="primary"
          style=" padding: 5px 20px; color: #fff;  " @click="modifyBtn('', 'add')">
          <span style="display: flex; align-items: center">
            <i class="el-icon-circle-plus-outline" style="margin-right: 10px; font-size: 20px"></i>Add
          </span>
        </el-button>
        <span v-else></span>
        <div>
          <excel-upload ref="BackUpRef" title="otherAmount upload" url="/bill/otherAmountDetails/uploadByExcel"
            temp-name="otherAmount-upload.xlsx" temp-url="/admin/sys-file/local/otherAmount-upload.xlsx"
            @refreshDataList="uploadHsCode">
          </excel-upload>
          <!-- 上传 -->
          <el-button :disabled="customerPermissions" v-if="permissions.bill_otherAmountDetails_upload"
            icon="el-icon-upload2" @click="$refs.BackUpRef.show()">
          </el-button>
          <!-- 下载 -->
          <el-button v-if="permissions.bill_otherAmountDetails_export" icon="el-icon-download"
            @click="exportExcel"></el-button>
        </div>
      </div>
      <!-- 数据表 -->
      <el-table tooltip-effect="dark" stripe border ref="multipleTable" :data="tableData.records" style="width: 100%"
        header-cell-class-name="header-cell-class" :header-cell-style="{ background: '#f5f7fa', color: '#606266' }"
        :cell-style="upperColor">
        <el-table-column :show-overflow-tooltip="true" label="Owner" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.clientCode }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Warehouse" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.warehouseCode }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Other Amount" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.otherAmount }} {{ scope.row.currency }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Qty" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.qty }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Unit Price" min-width="150" align="center">
          <template slot-scope="scope">{{ scope.row.unitPrice }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Used Date" min-width="150" align="center">
          <template slot-scope="scope">{{ scope.row.useDate }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Type" min-width="150" align="center">
          <template slot-scope="scope">{{ scope.row.otherName }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Ref" min-width="150" align="center">
          <template slot-scope="scope">{{ scope.row.ref }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Create Time" min-width="150" align="center">
          <template slot-scope="scope">{{ scope.row.createTime }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Create User" min-width="150" align="center">
          <template slot-scope="scope">{{ scope.row.createBy }}</template>
        </el-table-column>
        <el-table-column
          v-if="permissions.bill_otherAmountDetails_update || permissions.bill_otherAmountDetails_del || permissions.bill_otherAmountDetails_download"
          :show-overflow-tooltip="true" label="Opearte" min-width="150" align="center">
          <template slot-scope="scope">
            <el-button :disabled="customerPermissions" v-if="permissions.bill_otherAmountDetails_update" type="text"
              style="font-size:18px;" icon="el-icon-edit" @click="modifyBtn(scope.row, 'modify')">
            </el-button>
            <el-button :disabled="customerPermissions" v-if="permissions.bill_otherAmountDetails_del" type="text"
              style="font-size:18px;" icon="el-icon-delete" @click="deleteBtn(scope.$index, scope.row)">
            </el-button>
            <el-button v-if="permissions.bill_otherAmountDetails_download" type="text" style="font-size:18px;"
              icon="el-icon-download" @click="downloadFiles(scope.row)">
            </el-button>
          </template>
        </el-table-column>
      </el-table>
      <Pagination @handleSizeChange="handleSizeChange" @handleCurrentChange="handleCurrentChange"
        :pageNum="tableData.current" :pageSize="tableData.size" :total="tableData.total"></Pagination>

      <!-- Add弹框 -->
      <el-dialog :title="dialogTitle" :visible.sync="detailAdd" width="35%" :before-close="cancelClo"
        style="font-weight: 700" :close-on-click-modal='btnType != "add"'>
        <!-- 内容 -->
        <el-form ref="updateObj" :rules="rules" :model="updateObj" label-width="150px">
          <el-form-item label="Warehouse:" prop="warehouseCode">
            <el-select filterable clearable v-model.trim="updateObj.warehouseCode" placeholder="">
              <el-option v-for="item in warehouseArr" :key="item.warehouseCode" :label="item.warehouseName"
                :value="item.warehouseCode"></el-option>
            </el-select>
          </el-form-item>
          <el-row>
            <el-form-item label="Other Type:" prop="otherType">
              <el-select filterable clearable v-model.trim="updateObj.otherType" placeholder="">
                <el-option v-for="item in otherArr" :label="item.name" :value="item.code" :key="item.code">
                </el-option>
              </el-select>
            </el-form-item>
          </el-row>
          <el-row>
            <el-form-item label="Qty:" prop="qty">
              <el-input v-model.trim="updateObj.qty">
                <el-button slot="append" icon="el-icon-paperclip" :disabled="!updateObj.qty && updateObj.qty != 0"
                  :style="{ color: updateObj.qty || updateObj.qty == 0 ? '#65BEFF' : '' }" @click="$refs.File.show()">
                </el-button>
              </el-input>
            </el-form-item>
          </el-row>

          <el-row>
            <el-form-item label="Used Date:" prop="useDate">
              <el-date-picker style="width:100%" value-format="yyyy-MM-dd" v-model="updateObj.useDate" type="date"
                placeholder="选择日期" :picker-options="pickerOptions">
              </el-date-picker>
            </el-form-item>
          </el-row>
          <el-row>
            <el-form-item label="Ref:" prop="ref">
              <el-input v-model.trim="updateObj.ref"></el-input>
            </el-form-item>
          </el-row>
          <el-row>
            <el-form-item label="Remark:" prop="remark">
              <el-input v-model.trim="updateObj.remark" type="textarea" rows="4"></el-input>
            </el-form-item>
          </el-row>
        </el-form>
        <div class="dialog-footer-box">
          <span slot="footer">
            <el-button @click="cancelClo" style="margin-right: 20px; padding: 10px 40px" type="info">Cancel
            </el-button>
            <el-button type="primary" @click="updateSub" style="padding: 10px 40px">Confirm</el-button>
          </span>
        </div>
        <!-- 上传 -->
        <JpgUpload ref="File" title="File upload" url="/bill/importAmountDetails/uploadProofFile" :data="uploadData"
          accept=".jpg, .jpeg, .png, .JPG, .JPEG, .PNG, .pdf, .PDF, .docx, .DOCX, .doc, .DOC, .xlsx, .XLSX, .xls, .XLS, .ppt, .PPT, .pptx, .PPTX"
          :limit="1" @refreshDataList="uploadFiles">
        </JpgUpload>
      </el-dialog>
    </el-tabs>
  </div>
</template>
<script>
let formParams = {
  warehouseCode: '',
  createTimeBegin: '',
  createTimeFinish: '',
  usedTimeBegin: '',
  usedTimeFinish: '',
  createTime: [],
  usedDateTime: [],
  ref: '',
};
import { mapGetters } from "vuex"
import JpgUpload from "@/components/upload/jpgPdfUpload"
import Pagination from "@/components/pagination/pagination.vue"
import { deepClone } from '@/util/util';
import ExcelUpload from "@/components/upload/excel"
import { btnAntiShake } from '@/util/btnAntiShake'
import { remote } from '@/api/admin/dict'
import store from '@/store'
import { getPfepDataByQuery } from '@/api/pfepData'
import { getData, addSave, update, delObj, queryData } from '@/api/otherAmount'
import { AddParentWarehouseCodes } from "@/api/quotation"
export default {
  data() {
    return {
      uploadData: null,  //上传凭证要带的参数
      customerPermissions: false,  //客户的权限如果是客户 Lux-mate 则不允许更改数据
      pickerOptions: {
        disabledDate(time) {
          return time.getTime() > Date.now();
        },
      },
      clientCodeName: '',
      dialogTitle: '',
      isDisCode: false,
      btnType: '',
      skuLoading: false,
      pageSize: '',
      pageCurrent: '1',
      detailAdd: false,
      form: Object.assign({}, formParams),
      options: [
      ],
      // 基本数据
      tableData: [],
      size: 10,
      total: 100,
      //   修改表单
      updateObj: {
      },
      // add表单
      pClientArr: [],
      warehouseArr: [],
      otherArr: [],
      rules: {
        warehouseCode: [
          { required: true, message: '此区域为必填项', trigger: "change" },
        ],
        otherType: [
          { required: true, message: '此区域为必填项', trigger: "change" },
        ],
        useDate: [
          { required: true, message: '此区域为必填项', trigger: "change" },
          // { pattern: /^(((?:19|20)\d\d)-(0?[1-9]|1[0-2])-(0?[1-9]|[12][0-9]|3[01]))$/, message: '请输入正确的时间格式如2000-01-01或者2000-1-1', trigger: 'change' },
        ],
        // currency: [
        //   { required: true, message: '此区域为必填项', trigger: "change" },
        // ],
        qty: [
          { required: true, message: '此区域为必填项', trigger: "change" },
          { pattern: /^\+?[1-9]\d*$/, message: '请输入大于0的整数', trigger: 'change' },
          {
            validator: (rule, value, callback) => {
              value = String(value)
              if (value.includes('.')) {
                value.indexOf('.') >= 9 ? callback(new Error('整数部分最大长度为8位')) : callback()
              } else {
                value.length >= 9 ? callback(new Error('整数部分最大长度为8位')) : callback()
              }
            },
            trigger: 'change'
          },
        ],
      }
    }
  },
  // ============
  created() {
    // 当前的用户
    this.clientCodeName = store.getters.commandName
    this.Query()
    this.customerPermissions = this.$store.state.common.commandName === 'Lux-mate'
  },
  components: {
    ExcelUpload,
    JpgUpload,
    Pagination
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  mounted() {
    this.exportExcel = btnAntiShake(this.exportExcel, 500)
    this.updateSub = btnAntiShake(this.updateSub, 500)
  },
  methods: {
    // 通过条件查询数据
    async Query(query) {
      if (!query) {
        this.pageCurrent = 1
        this.pageSize = 10
        query = { current: this.pageCurrent, size: this.pageSize }
      }
      let queryObj = Object.assign(this.form, query)
      this.skuLoading = true
      let { data: warehouse } = await AddParentWarehouseCodes()
      this.warehouseArr = warehouse.data
      let { data: Other } = await getPfepDataByQuery({ dataType: 'Other Type' })
      this.otherArr = Other.data.records
      console.log("🚀→→→→→ ~ Other.data", this.otherArr)
      let { data } = await queryData(queryObj)
      if (data.code != 0) {
        this.skuLoading = false //关loading
        this.$message.error(data.msg);
        return;
      }
      this.skuLoading = false //关loading
      this.tableData = deepClone(data.data)
      this.tableData.records.forEach(i => {
        this.otherArr.forEach(item => {
          if (i.otherType == item.code) i.otherName = item.name
        })
      })
      this.upperColorData(this.tableData)
      console.log('页面基本数据', JSON.parse(JSON.stringify(this.tableData)))
    },
    // 重置
    resetForm(rule) {
      this.form = Object.assign({}, formParams);
      this.Query()
    },
    //导出
    exportExcel() {
      this.skuLoading = true
      this.downBlobFile("/bill/otherAmountDetails/export", this.form, `${this.$store.state.common.commandName}-otherAmount-${this.toDateFormat(new Date(), true)}.xlsx`, () => this.skuLoading = false);
    },

    // 上传
    uploadHsCode(response) {
      if (response == 'loading') {
        this.skuLoading = true
        return
      }
      if (!!response && response.code == 0) {
        this.skuLoading = false
      } else {
        this.skuLoading = false
      }
      this.Query()
    },
    //条数
    handleSizeChange(val) {
      this.pageSize = val
      let query = { current: this.pageCurrent, size: val }
      this.Query(query)
      console.log(`每页 ${val} 条`);
    },
    //当前页数
    handleCurrentChange(val) {
      this.pageCurrent = val
      let query = { current: val, size: this.pageSize }
      this.Query(query)
      console.log(`当前页: ${val}`);
    },
    // 新增或者修改按钮
    async modifyBtn(row, type) {
      this.skuLoading = true
      this.btnType = type
      if (type == 'add') {
        this.uploadData = null //凭证参数
        this.dialogTitle = 'Add'
        this.isDisCode = false
        this.skuLoading = false
        this.updateObj = {}
        this.detailAdd = true
        if (this.$refs.updateObj !== undefined) {
          this.$refs.updateObj.resetFields();
        }
      } else {
        this.uploadData = { old: row.otherAmountProof } //凭证参数
        this.dialogTitle = 'Edit'
        this.isDisCode = true
        // 修改数据
        this.skuLoading = false
        this.updateObj = deepClone(row)
        this.detailAdd = true
        console.log('这一行的数据', row)
      }
    },

    // 删除数据
    deleteBtn(index, row) {
      console.log('要删除的这一行数据', JSON.parse(JSON.stringify(row)))
      this.$confirm("This operation will permanently delete this data. Do you want to continue?", "Tips", {
        confirmButtonText: "submit",
        cancelButtonText: "cancel",
        type: "warning",
      })
        .then(async () => {
          let { data } = await delObj(row.id)
          if (data.code != 0) return this.$message.error(data.msg)
          this.$message.success(data.msg)
          this.Query()
        })
        .catch(() => {
          // this.$message.info('Destruction cancelled')
        });
    },
    // add/修改数据提交按钮
    updateSub() {
      let params = Object.assign(this.updateObj, { clientCode: this.clientCodeName })
      if (this.btnType == 'add') {
        // 添加数据 addSave
        this.$refs.updateObj.validate(async (valid) => {
          if (!valid) return false
          if (!this.updateObj.otherAmountProof) return this.$message.warning('请上传Qty凭证')
          let { data } = await addSave(params)
          console.log('添加后的数据返回', JSON.parse(JSON.stringify(data)))
          if (data.code != 0) return this.$message.error(data.msg);
          this.$message.success(data.msg);
          this.detailAdd = false
          this.Query()
        });

      } else {
        // 修改数据
        this.$refs.updateObj.validate(async (valid) => {
          if (!valid) return false
          if (!this.updateObj.otherAmountProof) return this.$message.warning('请上传Qty凭证')
          let { data } = await update(params)
          console.log('修改后的数据返回', JSON.parse(JSON.stringify(data)))
          if (data.code != 0) return this.$message.error(data.msg);
          this.$message.success(data.msg);
          this.detailAdd = false
          this.Query()
        });
      }
    },

    // 添加删除弹框的关闭按钮
    cancelClo() {
      this.detailAdd = false
    },
    //  下载附件
    downloadFiles(row) {
      this.skuLoading = true
      // this.downBlobFile("/bill/otherAmountDetails/download/" + row.id, '', `${this.$store.state.common.commandName}-OtherAmountFiles-${this.toDateFormat(new Date(), true)}.png`, () => this.skuLoading = false);
      this.newDownBlobFile("/bill/otherAmountDetails/download/" + row.id, '', `${row.clientCode}-${row.warehouseCode}-${this.toDateFormat(new Date(), true)}`, () => this.skuLoading = false);

    },
    // 上传
    uploadFiles(response) {
      // if (this.updateObj['otherAmountProof']) {
      //   this.updateObj['otherAmountProof'] = this.updateObj['otherAmountProof'].split(',').concat(response.data).join(',')
      // } else {
      this.updateObj['otherAmountProof'] = response.data.join()
      // }
      console.log('this.updateObj', JSON.parse(JSON.stringify(this.updateObj)))
    },
    // 标记未完成的数据着重提示
    upperColor({ row }) {
      if (row.status == '0') return 'background: beige'
      return ''
    },
    // 如果有未填完成的数据，则提示
    upperColorData(row) {
      for (let item of row.records) {
        if (item.status == '0') return this.$message.warning('请完善有颜色标记的数据')
      }
    },
    // 选择时间范围查询
    timeFrame(val, btn) {
      if (btn == 'createTime') {
        if (Array.isArray(val)) {
          this.form.createTimeBegin = val[0]
          this.form.createTimeFinish = val[1]
        } else {
          this.form.createTimeBegin = ''
          this.form.createTimeFinish = ''
        }
      } else if (btn == 'usedDateTime') {
        if (Array.isArray(val)) {
          this.form.usedTimeBegin = val[0]
          this.form.usedTimeFinish = val[1]
        } else {
          this.form.usedTimeBegin = ''
          this.form.usedTimeFinish = ''
        }
      }
      console.log('🚀→→→→→选择时间', JSON.parse(JSON.stringify(this.form)))
    },
  },
};
</script>
<style lang="scss" scoped>
::v-deep .el-select--small {
  display: block;
}

.dialog-footer-add {
  display: flex;
  justify-content: center;
  color: rgb(64, 149, 229);
  font-size: 25px;
  margin: 20px 0;
}

.dialog-footer-box {
  display: flex;
  justify-content: center;
  margin-top: 50px;
}

.content {
  padding: 0 10px;

  .down {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    border-top: 1px solid #999;
    padding-top: 20px;
    box-sizing: border-box;
  }

  .underLine {
    color: #599af8;
    text-decoration: underline;

    .underIcon {
      background-color: green;
      color: #fff;
      border-radius: 50%;
      margin-right: 5px;
    }
  }
}

.operate-icon-wrap {
  display: flex;
  column-gap: 15px;
}

.operate-icon-box {
  display: flex;
  align-items: center;
  cursor: pointer;
  color: #4095e5;
}

.header-cell-class {
  background-color: #ccc;
}

.foot {
  display: flex;
  justify-content: flex-end;
  margin-top: 20px;
}

.btn-bgc {
  background-color: rgb(31, 99, 255);
  color: #fff;
}

.confrim-bgc {
  background-color: #1376c7;
  color: #fff;
}

.cursor-on {
  cursor: pointer;
}

::v-deep .el-dialog__wrapper .el-dialog {
  border-radius: 8px;
}
</style>