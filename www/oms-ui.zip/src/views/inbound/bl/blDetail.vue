<template>
  <basic-container>
    <div class="avue-crud content" v-loading="allLoading">
      <div v-loading="blDetailLoading">
        <div>
          <div class="title">
            <span></span>
            <label>BL Info</label>  
            <div style="width:calc(100% - 60px);text-align:right" >
              <el-button type="primary" :disabled="rowParams.status === 'allocated'" @click="editClick" v-if="permissions.inbound_bl_edit">Edit</el-button>
            </div>
          </div>
          <div class="contain">
            <el-row>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>Owner:</label>
                <span>{{ rowParams.clientCode }}</span>
              </el-col>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>Warehouse:</label>
                <span>{{ rowParams.warehouseCode }}</span>
              </el-col>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>Job no:</label>
                <span>{{ rowParams.blNo }}
                  <i class="el-icon-document-copy copy" @click="clickCopy"></i>
                </span>
              </el-col>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>BL no:</label>
                <span>{{ rowParams.billLandNum }}</span>
              </el-col>
            </el-row>
            <el-row>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>Ship Type:</label>
                <span>{{ rowParams.shipType }}</span>
              </el-col>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>CountryCode:</label>
                <span>{{ rowParams.countryCode }}</span>
              </el-col>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>Incoterms:</label>
                <span>{{ rowParams.incoterms }}</span>
              </el-col>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>Status:</label>
                <span>{{ rowParams.status }}</span>
              </el-col>
            </el-row>
            <el-row>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>ETA:</label>
                <span>{{ rowParams.etaTime }}</span>
              </el-col>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>C-Number:</label>
                <span>{{ rowParams.cnumber }}</span>
              </el-col>
              <el-col :xs="24" :sm="24" :md="24" :lg="12">
                <label>Address:</label>
                <el-tooltip class="item" effect="dark" :content="rowParams.address" placement="top-end">
                  <span style="display:inline-block;width:400px;white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">{{ rowParams.address }}</span>
                </el-tooltip>
              </el-col>
            </el-row>
            <el-row>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>Container Qty:</label>
                <span>{{ rowParams.containerQty }}</span>
              </el-col>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>Total PCS:</label>
                <span>{{ rowParams.totalPcs }}</span>
              </el-col>
            </el-row>
          </div>
        </div>
        <div>
          <div class="title">
            <span></span>
            <label>Track</label>
          </div>
          <div class="contain">
            <el-row>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>Create Time:</label>
                <span>{{ rowParams.createTime }}</span>
              </el-col>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>Verified Time:</label>
                <span>{{ rowParams.dataVerifyPassedTime }}</span>
              </el-col>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>ATA Time:</label>
                <span>{{ rowParams.arrivedTime }}</span>
              </el-col>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>Allocate Time:</label>
                <span>{{ rowParams.allocateTime }}</span>
              </el-col>
            </el-row>
          </div>
        </div>
      </div>
      <BlFile :blFile="rowId" ref="blFile" :blFileRow="blFileRow" @refresh="refresh" @blFileLoading="blFileLoading"></BlFile>
      <div class="containBox">
        <div class="title">
          <span></span>
          <label>BL Line</label>
        </div>
        <div class="contain">
          <el-row style="width: 200px; display: flex">
            <el-col>
              <el-button type="primary" icon="el-icon-search" @click="getSearchlist" >Query</el-button>
            </el-col>
            <el-col>
              <el-button icon="el-icon-refresh-left" @click="getReset">Reset</el-button>
            </el-col>
          </el-row>
          <el-row>
            <el-form
              ref="form"
              :model="form"
              @keyup.enter.native="getSearchlist"
              style="margin: 20px 0"
            >
              <el-row :gutter="20">
                <el-col :span="4">
                  <el-input v-model="form.containerNo" placeholder="Container No"></el-input>
                </el-col>
                <el-col :span="4">
                  <el-input v-model="form.partNumber" placeholder="Sku no"></el-input>
                </el-col>
                <el-col :span="4">
                  <el-select v-model="form.hsSku" placeholder="Has Sku" filterable clearable>
                    <el-option
                      v-for="item in differenceList"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value"
                    >
                    </el-option>
                  </el-select>
                </el-col>
                <el-col :span="4">
                  <el-select v-model="form.hsCode" placeholder="Has HSCode" filterable clearable>
                    <el-option
                      v-for="item in differenceList"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value"
                    >
                    </el-option>
                  </el-select>
                </el-col>
                <el-col :span="4">
                  <el-select v-model="form.hsPkg" placeholder="Has Package Info" filterable clearable>
                    <el-option
                      v-for="item in differenceList"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value"
                    >
                    </el-option>
                  </el-select>
                </el-col>
                <el-col :span="4">
                  <el-button style="float:right;padding: 7px 15px;" type="primary" @click="about" :icon="show?'el-icon-arrow-up': 'el-icon-arrow-down'">
                    <label style="width:24px;height:16px;line-height:16px">{{show?'收起':'更多'}}</label>
                  </el-button>
                </el-col>
              </el-row>
              <el-row v-show="show" style="margin-top: 10px" :gutter="20">
                <el-col :span="4">
                  <el-select v-model="form.HsStorageType" placeholder="Has Storage Type" filterable clearable>
                    <el-option
                      v-for="item in differenceList"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value"
                    >
                    </el-option>
                  </el-select>
                </el-col>
              </el-row>
            </el-form>
          </el-row>
        </div>
      </div>
      <div class="down">
        <div>
          <el-button type="primary" :disabled="rowParams.status !== 'arrived'" 
          v-if="permissions.inbound_bl_allocate" @click="operaterType('Allocate')" style="padding: 9px 15px">
            <span style="display: flex; align-items: center">
              <i class="iconfont icon-fenxiang"></i>Allocate
            </span>
          </el-button>
          <el-button type="primary" :disabled="rowParams.status !== 'verifyFailed' && rowParams.status !== 'verifySuccess'" 
          v-if="permissions.inbound_bl_verify" @click="operaterType('Verify')" style="padding: 9px 15px">
            <span style="display: flex; align-items: center">
              <i class="iconfont icon-dunpai"></i>Verify
            </span>
          </el-button>
        </div>
        <div class="downIcon">
          <el-button
            icon="el-icon-download"
            @click="exportExcelSku"
            v-if="permissions.inbound_blline_exportNonSkuList"
            >Non Sku List</el-button
          >
          <el-button
            icon="el-icon-download"
            @click="exportExcelHSCode"
            v-if="permissions.inbound_blline_exportNonHsCodeList"
            >Non HsCode List</el-button
          >
          <el-button
            icon="el-icon-download"
            @click="exportExcelPkg"
            v-if="permissions.inbound_blline_exportNonPkgList"
            >Non Pkg List</el-button
          >
          <el-button
            icon="el-icon-download"
            @click="exportStorageType"
            v-if="permissions.inbound_blline_exportNonPkgList"
            >Non Storage Type</el-button
          >
          <el-button
            icon="el-icon-download"
            @click="exportExcel"
            v-if="permissions.inbound_blline_export"
          ></el-button>
          <!-- <i class="el-icon-download" v-if="permissions.outbound_outorderline_export" @click="exportExcelSku"><span>Non Sku List</span></i>
          <i class="el-icon-download" v-if="permissions.outbound_outorderline_export" @click="exportExcelHSCode"><span>Non HSCode List</span></i>
          <i class="el-icon-download" v-if="permissions.outbound_outorderline_export" @click="exportExcelPkg"><span>Non Pkg List</span></i>
          <i class="el-icon-download" v-if="permissions.outbound_outorderline_export" @click="exportExcel"></i> -->
        </div>
      </div>
      <el-table
        border
        ref="multipleTable"
        :data="tableData"
        tooltip-effect="dark"
        style="width: 100%"
        v-loading="dataListLoading"
        :header-cell-style="{ background: '#f5f7fa', color: '#606266', 'text-align': 'center'}"
      >
        <el-table-column label="Line no" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.lineNo || "-"}}</template>
        </el-table-column>
        <el-table-column label="Container no" min-width="160" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.containerNo || "-" }}</template>
        </el-table-column>
        <el-table-column label="Sku no" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.partNumber || "-" }}</template>
        </el-table-column>
        <el-table-column label="Qty" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.qty || "-" }}</template>
        </el-table-column>
        <el-table-column label="Unit" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.unit || "0" }}</template>
        </el-table-column>
        <el-table-column label="Total Price" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.totalPrice || "-" }}</template>
        </el-table-column>
        <el-table-column label="G.W." min-width="140" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.totalGw || "0" }}</template>
        </el-table-column>
        <el-table-column label="N.W." min-width="140" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.totalNw || "-" }}</template>
        </el-table-column>
        <el-table-column label="VOM" min-width="140" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.totalVom || "-" }}</template>
        </el-table-column>
        <el-table-column label="Has Sku" min-width="120" align="center">
          <template slot-scope="scope">
            <i :class="scope.row.hsSku === 'Y'? 'el-icon-success success' : 'el-icon-error error'"></i>
          </template>
        </el-table-column>
        <el-table-column label="Has Storage Type" min-width="140" align="center" show-overflow-tooltip>
          <template slot-scope="scope">
            <i :class="scope.row.hsStorageType === 'Y' ? 'el-icon-success success' : 'el-icon-error error'"></i>
          </template>
        </el-table-column>
        <el-table-column label="HsCode" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.hsCode || "-" }}</template>
        </el-table-column>
        <el-table-column label="Has Pkg" min-width="120" align="center">
          <template slot-scope="scope">
            <i :class="scope.row.hsPkg === 'Y' ? 'el-icon-success success' : 'el-icon-error error'"></i>
          </template>
        </el-table-column>
        <el-table-column label="PL File" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.plFile || "-" }}</template>
        </el-table-column>
      </el-table>
      <Pagination
        @handleSizeChange="handleSizeChange"
        @handleCurrentChange="handleCurrentChange"
        :pageNum="page.current"
        :pageSize="page.size"
        :total="total"
      ></Pagination>
      <Dialog v-if="showDialog" :centerDialogVisible="centerDialogVisible" :title="title" @formClose="formClose" :rowArray="rowArray"></Dialog>
      <BlDetailDialog v-if="blDetailEdit" :editDetailDialog="editDetailDialog" :blDetail="blDetail" @getClose="getClose"></BlDetailDialog>
    </div>
  </basic-container>
</template>
<script>
import { mapGetters } from "vuex";
import Pagination from "@/components/pagination/pagination.vue";
import BlFile from "./components/blFile.vue";
import BlDetailDialog from "./components/dialog/blDetailEdit.vue";
import Dialog from "./components/dialog/dialog.vue"
import { getBlLine, getBlDetail, exportNonSkuList } from "@/api/inbound/bl"
let formParams = {
  containerNo:undefined,
  partNumber: undefined,
  hsSku:undefined,
  hsCode: undefined,
  hsPkg:undefined,
  HsStorageType:undefined
};
export default {
  name: "BlDetail",
  data() {
    return {
      form: Object.assign({}, formParams),
      page: {
        size: 10,
        current: 1,
      },
      centerDialogVisible: false,
      dataListLoading: false,
      total: 0,
      title: "",
      showDialog:false,
      tableData: [],
      differenceList: [
        {
          value: "Y",
          label: "Y",
        },
        {
          value: "N",
          label: "N",
        },
      ],
      rowParams: {},
      blFileRow:{},//blFile所需字段
      rowId:"",//详情参数字段
      blDetailEdit:false,
      editDetailDialog:false,
      blDetail:{},
      blDetailLoading:false,
      allLoading:false,
      rowArray: [],
      blNo:[],
      show:false
    };
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  components: {
    Pagination,
    BlFile,
    BlDetailDialog,
    Dialog
  },
  watch: {
    // 利用watch方法检测路由变化：
    $route: function (to, from) {
      if (to.path == "/blDetail/index" && to.query.name) {
        if (to.query.name != from.query.name) {
          this.rowId = this.$route.query.name;
          this.getList();
          this.getDate();
        }
      }
    },
  },
  mounted(){
    this.clickCopy = this.$btn(this.clickCopy,500)
  },
  async created() {
    this.rowId = this.$route.query.name;
    await this.getDate()
    await this.getList();
  },
  methods: {
    //展开
    about() {
      this.show = !this.show
    },
    //复制
    clickCopy() {
      let content = this.rowParams.blNo
      if(this.copy(content) === '文本为空'){
        this.$message.warning("Text is empty and cannot be copied !!!")
        return
      }
      this.$message.success("copy success")
    },
    //导出
    exportExcelSku() {
      this.downBlobFilePost( "/inbound/blLine/exportNonSkuList", { ...this.form,blNo:this.rowId }, `${this.rowParams.billLandNum}-NonSkuList.xlsx`);
    },
    exportExcelHSCode() {
      this.downBlobFilePost( "/inbound/blLine/exportNonHsCodeList", { ...this.form,blNo:this.rowId }, `${this.rowParams.billLandNum}-NonHsCodeList.xlsx`);
    },
    exportExcelPkg() {
      this.downBlobFilePost( "/inbound/blLine/exportNonPkgList", { ...this.form,blNo:this.rowId }, `${this.rowParams.billLandNum}-NonPkgList.xlsx`);
    },
    exportStorageType(){
      this.downBlobFilePost( "/inbound/blLine/exportNonStorageList", { ...this.form,blNo:this.rowId }, `${this.rowParams.billLandNum}-NonStorageList.xlsx`);
    },
    exportExcel() {
      this.downBlobFile( "/inbound/blLine/export", { ...this.form,blNo:this.rowId }, "blLine.xlsx");
    },
    //Bl info信息
    getDate(){
      this.blDetailLoading = true
      getBlDetail({blNo:this.rowId}).then(res=>{
        console.log(res);
        if(res.data.code === 0){
          this.blDetailLoading =false
          this.rowParams = res.data.data
          this.blFileRow = this.rowParams
        }else{
          this.blDetailLoading = false
          this.$message.error(res.data.msg)
        }
      }).catch(()=>{
        this.blDetailLoading = false
      })
    },
    //条数
    handleSizeChange(val) {
      this.page.current = 1;
      this.page.size = val;
      this.getList(this.form);
    },
    //当前页数
    handleCurrentChange(val) {
      this.page.current = val;
      this.getList(this.form);
    },
    //清空
    getReset() {
      this.form = Object.assign({}, formParams);
      this.page = this.$options.data().page
      this.getSearchlist();
    },
    //查询
    getSearchlist() {
      this.page.current = 1;
      for (let key in this.form) {
        if (this.form[key] === "" || this.form[key] === null) {
          this.form[key] = undefined;
        }
      }
      this.getList(this.form);
    },
    //详情编辑
    editClick() {
      this.blDetailEdit = true;
      this.editDetailDialog = true;
      this.blDetail = this.rowParams;
    },
    //关闭编辑
    getClose(e,type){
      if(type){
        this.getDate();
        this.eventBus.$emit('blDetailStatus')
      }
      this.blDetailEdit = e;
      this.editDetailDialog = e;
    },
    //数据列表
    getList(params) {
      this.dataListLoading = true;
      getBlLine( Object.assign({ ...this.page }, params, { blNo: this.rowId })).then((res) => {
        console.log(res);
        if (res.data.code === 0) {
          this.tableData = res.data.data.records
          this.total = res.data.data.total;
          this.dataListLoading = false;
        } else {
          this.$message.error(res.data.msg);
          this.dataListLoading = false;
        }
      }).catch(()=>{
        this.dataListLoading = false
      })
    },
    operaterType(type, row) {
      this.showDialog = true
      this.centerDialogVisible = true;
      this.title = type;
      this.blNo = []
      this.blNo.push(this.rowParams.blNo)
      this.rowArray = this.blNo
    },
    //关闭dialog
    formClose(e,type){
      this.centerDialogVisible =  e
      this.showDialog = e
      if(type === "Refresh"){
        this.getList()
        this.getDate()
        this.$refs.blFile.getList()
        this.eventBus.$emit('blDetailStatus')
      }
      console.log(e,type);
    },
    //blFile子刷新blLine
    refresh(){
      if(this.tableData.length){
        this.getList()
      }
    },
    blFileLoading(e){
      this.allLoading = e
    }
  },
};
</script>
<style lang="scss" scoped>
.content {
  width: 100%;
  //   padding: 20px;
  font-size: 13px;
  box-sizing: border-box;
  .title {
    width: 100%;
    height: 30px;
    line-height: 30px;
    display: flex;
    margin-bottom: 10px;
    span {
      width: 3px;
      height: 30px;
      background-color: #000;
      margin-right: 10px;
    }
    label {
      width: 200px;
      font-weight: 700;
    }
  }
  .containBox {
    border-bottom: 1px solid #999;
    margin-bottom: 20px;
  }
  .contain {
    padding: 10px;
    box-sizing: border-box;
    label {
      display: inline-block;
      margin-right: 5px;
      width: 100px;
      text-align: right;
      vertical-align: middle;
    }
    span {
      color: #999;
      vertical-align: middle;
    }
  }
  .down {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    i {
      margin-right: 5px;
      font-size: 12px;
    }
    // .downIcon{
    //   margin: auto 0;
    //   i{
    //     padding:9px 15px;
    //     background-color:#F7F8FA;
    //     cursor: pointer;
    //   }
    //   i:last-of-type{
    //     margin-right: 0px;
    //   }
    //   span{
    //     margin-left:10px;
    //   }
    // }
  }
  .success {
    color: rgb(137, 234, 137);
    font-size: 18px;
  }
  .error {
    color: rgb(238, 99, 99);
    font-size: 18px;
  }
  .copy {
    cursor: pointer;
  }
  ::v-deep .el-dialog {
    border-radius: 8px !important;
  }
}
</style>
