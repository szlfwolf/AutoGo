<template>
  <div class="content" v-loading="blLoading">
    <el-card class="box-card">
      <el-row style="width: 200px; display: flex">
        <el-col>
          <el-button type="primary" icon="el-icon-search" @click="getSearchlist">Query</el-button>
        </el-col>
        <el-col>
          <el-button icon="el-icon-refresh-left" @click="getReset">Reset</el-button>
        </el-col>
      </el-row>
      <el-form ref="form" :model="form" style="margin: 20px 0" @keyup.enter.native="getSearchlist">
        <el-row :gutter="20">
          <el-col :span="4">
            <el-input v-model="form.blNo" placeholder="Job no/ASN no/BL no/C-number"></el-input>
          </el-col>
          <el-col :span="4">
            <el-select v-model="form.warehouseCode" placeholder="Warehouse" filterable clearable>
              <el-option v-for="item in warehouseCode" :key="item.value" :label="item.warehouseName"
                :value="item.warehouseCode">
              </el-option>
            </el-select>
          </el-col>
          <el-col :span="4">
            <el-select v-model="form.status" placeholder="Status" filterable clearable>
              <el-option v-for="item in blStatus" :key="item.value" :label="item.label" :value="item.value">
              </el-option>
            </el-select>
          </el-col>
          <el-col :span="4">
            <el-select v-model="form.shipType" placeholder="Ship Type" filterable clearable>
              <el-option v-for="item in shipType" :key="item.value" :label="item.label" :value="item.value">
              </el-option>
            </el-select>
          </el-col>
          <el-col :span="4">
            <el-select v-model="form.countryCode" placeholder="Country Code" filterable clearable>
              <el-option v-for="item in countryCode" :key="item.value" :label="item.label" :value="item.value">
              </el-option>
            </el-select>
          </el-col>
          <el-col :span="4">
            <el-button style="float:right" type="primary" @click="about"
              :icon="show ? 'el-icon-arrow-up' : 'el-icon-arrow-down'">
              <label for="">{{ show ? '收起' : '更多' }}</label>
            </el-button>
          </el-col>
        </el-row>
        <el-row v-show="show" style="margin-top: 10px" :gutter="20">
          <el-col :span="4">
            <el-date-picker v-model="time.createTime" type="daterange" start-placeholder="CreateTime"
              end-placeholder="CreateEndTime" :default-time="['00:00:00', '23:59:59']" value-format="yyyy-MM-dd HH:mm:ss"
              @change="changeCreateTime" />
          </el-col>
          <el-col :span="4">
            <el-date-picker v-model="time.allocateTime" type="daterange" start-placeholder="AllocateTime"
              end-placeholder="AllocateEndTime" :default-time="['00:00:00', '23:59:59']"
              value-format="yyyy-MM-dd HH:mm:ss" @change="changeReleaseTime" />
          </el-col>
          <el-col :span="4">
            <el-date-picker v-model="time.dataVerifyPassedTime" type="daterange" start-placeholder="DataVerifyTime"
              end-placeholder="DataVerifyEndTime" :default-time="['00:00:00', '23:59:59']"
              value-format="yyyy-MM-dd HH:mm:ss" @change="changePackedTime" />
          </el-col>
          <el-col :span="4">
            <el-date-picker v-model="time.arrivedTime" type="daterange" start-placeholder="ArrivedTime"
              end-placeholder="ArrivedEndTime" :default-time="['00:00:00', '23:59:59']" value-format="yyyy-MM-dd HH:mm:ss"
              @change="changeOutboundedTime" />
          </el-col>
          <el-col :span="4">
            <el-date-picker v-model="time.etaTime" type="daterange" start-placeholder="EtaTime"
              end-placeholder="EtaEndTime" :default-time="['00:00:00', '23:59:59']" value-format="yyyy-MM-dd HH:mm:ss"
              @change="changeEtaTime" />
          </el-col>
        </el-row>
      </el-form>
      <div class="down">
        <div>
          <el-button type="primary" v-if="permissions.inbound_bl_add" @click="blAdd" style="padding: 5px 15px;">
            <span style="display: flex; align-items: center">
              <i class="el-icon-circle-plus-outline" style="margin-right: 5px; font-size: 20px"></i>Add
            </span>
          </el-button>
          <el-button type="primary" :disabled="verifyDisabled" v-if="permissions.inbound_bl_verify"
            @click="operaterType('Verify')" style="padding: 5px 15px;">
            <span style="display: flex; align-items: center">
              <i class="iconfont icon-dunpai" style="margin-right: 5px; font-size: 20px"></i>Verify
            </span>
          </el-button>
          <el-button type="primary" :disabled="arrivedDisabled" v-if="permissions.inbound_bl_arrive"
            @click="operaterType('Arrive')" style="padding: 5px 15px;">
            <span style="display: flex; align-items: center">
              <i class="iconfont icon-24gl-fence" style="margin-right: 5px; font-size: 20px"></i>Arrive
            </span>
          </el-button>
          <el-button type="primary" :disabled="allocatedDisabled" v-if="permissions.inbound_bl_allocate"
            @click="operaterType('Allocate')" style="padding: 5px 15px;">
            <span style="display: flex; align-items: center">
              <i class="iconfont icon-fenxiang" style="margin-right: 5px; font-size: 20px"></i>Allocate
            </span>
          </el-button>
          <el-button :disabled="deletedDisabled" v-if="permissions.inbound_bl_delete" @click="deleteOrd"
            style="padding: 5px 15px;">
            <span style="display: flex; align-items: center">
              <i class="el-icon-delete" style="margin-right: 5px; font-size: 20px"></i>Delete
            </span>
          </el-button>
        </div>
        <div>
          <!-- iconfont icon-xiazai-wenjianxiazai-05 -->
          <el-button class="el-icon-download" v-if="permissions.inbound_bl_export" @click="exportExcel"></el-button>
        </div>
      </div>
      <el-table border ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%"
        @selection-change="handleSelectionChange" v-loading="dataListLoading"
        :header-cell-style="{ background: '#f5f7fa', color: '#606266' }">
        <el-table-column type="selection" min-width="55" align="center"> </el-table-column>
        <el-table-column label="Owner" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.clientCode || "-" }}</template>
        </el-table-column>
        <el-table-column label="WarehouseName" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.warehouseName || "-" }}</template>
        </el-table-column>
        <el-table-column label="WarehouseCode" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.warehouseCode || "-" }}</template>
        </el-table-column>
        <el-table-column label="Job no" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">
            <div class="underLine" @click="handleDetail(scope.row, scope.index)" v-if="permissions.inbound_bl_getDetail">
              {{ scope.row.blNo || "-" }}
            </div>
            <div v-else>
              {{ scope.row.blNo || "-" }}
            </div>
          </template>
        </el-table-column>
        <el-table-column label="BL no" min-width="140" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.billLandNum || "-" }}</template>
        </el-table-column>
        <el-table-column label="Ship Type" min-width="140" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.shipType || "-" }}</template>
        </el-table-column>
        <el-table-column label="CountryCode" min-width="140" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.countryCode || "-" }}</template>
        </el-table-column>
        <el-table-column label="ETA" min-width="140" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.etaTime || "-" }}</template>
        </el-table-column>
        <el-table-column label="Created" min-width="140" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.createTime || "-" }}</template>
        </el-table-column>
        <el-table-column label="Verified" min-width="140" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.dataVerifyPassedTime || "-" }}</template>
        </el-table-column>
        <el-table-column label="ATA" min-width="140" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.arrivedTime || "-" }}</template>
        </el-table-column>
        <el-table-column label="Allocated" min-width="140" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.allocateTime || "-" }}</template>
        </el-table-column>
        <el-table-column fixed="right" label="Status" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">
            <div :style="{ 'color': scope.row.status === 'verifyFailed' ? '#FF514F' : '' }">{{ scope.row.status || "-" }}
            </div>
          </template>
        </el-table-column>
        <el-table-column fixed="right" label="Opearter" align="center" v-if="permissions.inbound_bl_getDetail">
          <template slot-scope="scope">
            <i style="font-size: 18px;cursor: pointer;color:#65BEFF;margin-right:10px" class="el-icon-view"
              @click="handleDetail(scope.row, scope.index)" v-if="permissions.inbound_bl_getDetail"></i>
          </template>
        </el-table-column>
      </el-table>
      <Pagination @handleSizeChange="handleSizeChange" @handleCurrentChange="handleCurrentChange" :pageNum="page.current"
        :pageSize="page.size" :total="total"></Pagination>
      <Dialog v-if="showDialog" :centerDialogVisible="centerDialogVisible" :title="title" @formClose="formClose"
        :rowArray="rowArray"></Dialog>
    </el-card>
  </div>
</template>
<script>
import Pagination from "@/components/pagination/pagination.vue";
import { mapGetters } from "vuex";
import Dialog from "./components/dialog/dialog.vue";
import { pageQuery, getDeleteBl } from "@/api/inbound/bl"
import { getWarehouse } from "@/api/stock/analysis";
import { remote } from "@/api/admin/dict";

let formParams = {
  blNo: undefined,
  status: undefined,
  shipType: undefined,
  warehouseCode: undefined,
  countryCode: undefined,
};
export default {
  name: "Bl",
  data() {
    return {
      show: false,
      form: Object.assign({}, formParams),
      total: 0,
      page: {
        size: 10,
        current: 1,
      },
      time: {
        createTime: undefined,
        allocateTime: undefined,
        dataVerifyPassedTime: undefined,
        arrivedTime: undefined,
        etaTime: undefined
      },
      centerDialogVisible: false,
      dataListLoading: false,
      tableData: [],
      blStatus: [],//bl状态
      warehouseCode: [], //仓库
      countryCode: [], //国家
      shipType: [],//运输方式
      title: "",
      verifyDisabled: true,//verify校检
      arrivedDisabled: true,//arrived到达
      allocatedDisabled: true,//allocate分配
      deletedDisabled: true,//批量删除是否禁用
      showDialog: false,
      multipleSelection: [],
      status: [],
      rowArray: [],
      blNo: [],
      blLoading: false,//全局Loading
    };
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  components: {
    Pagination,
    Dialog
  },
  async created() {
    await this.getWarehouse();
    await this.getList();
    this.getRemote();
    this.eventBus.$on('blDetailStatus', () => {
      this.getList(this.form);
    })
  },
  methods: {
    //展开
    about() {
      this.show = !this.show
    },
    //时间参数
    changeCreateTime(val) {
      if (val !== undefined && val !== null && val !== '' && val.length > 0) {
        this.$set(this.form, 'beginCreateTime', val[0])
        this.$set(this.form, 'endCreateTime', val[1])
      } else {
        this.$set(this.form, 'beginCreateTime', undefined)
        this.$set(this.form, 'endCreateTime', undefined)
      }
    },
    changeReleaseTime(val) {
      if (val !== undefined && val !== null && val !== '' && val.length > 0) {
        this.$set(this.form, 'beginAllocateTime', val[0])
        this.$set(this.form, 'endAllocateTime', val[1])
      } else {
        this.$set(this.form, 'beginAllocateTime', undefined)
        this.$set(this.form, 'endAllocateTime', undefined)
      }
    },
    changePackedTime(val) {
      if (val !== undefined && val !== null && val !== '' && val.length > 0) {
        this.$set(this.form, 'beginDataVerifyPassedTime', val[0])
        this.$set(this.form, 'endDataVerifyPassedTime', val[1])
      } else {
        this.$set(this.form, 'beginDataVerifyPassedTime', undefined)
        this.$set(this.form, 'endDataVerifyPassedTime', undefined)
      }
    },
    changeOutboundedTime(val) {
      if (val !== undefined && val !== null && val !== '' && val.length > 0) {
        this.$set(this.form, 'beginArrivedTime', val[0])
        this.$set(this.form, 'endArrivedTime', val[1])
      } else {
        this.$set(this.form, 'beginArrivedTime', undefined)
        this.$set(this.form, 'endArrivedTime', undefined)
      }
    },
    changeEtaTime(val) {
      if (val !== undefined && val !== null && val !== '' && val.length > 0) {
        this.$set(this.form, 'beginEtaTime', val[0])
        this.$set(this.form, 'endEtaTime', val[1])
      } else {
        this.$set(this.form, 'beginEtaTime', undefined)
        this.$set(this.form, 'endEtaTime', undefined)
      }
    },
    //多选
    handleSelectionChange(val) {
      this.multipleSelection = val
      this.status = []
      this.blNo = []
      this.multipleSelection.forEach(ite => {
        this.status.push(ite.status)
        this.blNo.push(ite.blNo)
      })
      //verify
      console.log(this.status);
      if (this.multipleSelection.length !== 0) {
        let verify = this.status.filter(ite => ite !== 'verifyFailed' && ite !== 'verifySuccess')
        if (verify.length) {
          this.verifyDisabled = true
        } else {
          this.verifyDisabled = false
        }
      } else {
        this.verifyDisabled = true
      }
      //arrive
      if (this.multipleSelection.length === 1 && (this.status[0] === 'arrived' || this.status[0] === 'verifySuccess')) {
        this.arrivedDisabled = false
      } else {
        this.arrivedDisabled = true
      }
      //allocate
      if (this.multipleSelection.length !== 0 && (this.status.indexOf('arrived') !== -1 && new Set(this.status).size === 1)) {
        this.allocatedDisabled = false
      } else {
        this.allocatedDisabled = true
      }
      //delete
      if (this.multipleSelection.length !== 0 && (this.status.indexOf('allocated') === -1)) {
        this.deletedDisabled = false
      } else {
        this.deletedDisabled = true
      }
    },
    //导出
    exportExcel() {
      this.blLoading = true
      this.downBlobFile("/inbound/bl/exportBlByQuery", this.form, `${this.$store.state.common.commandName}-BL-${this.toDateFormat(new Date(), true)}.xlsx`, () => this.blLoading = false);
    },
    //条数
    handleSizeChange(val) {
      this.page.current = 1;
      this.page.size = val;
      this.getList(this.form);
    },
    //当前页数
    handleCurrentChange(val) {
      this.page.current = val;
      this.getList(this.form);
    },
    //清空
    getReset() {
      this.form = Object.assign({}, formParams);
      this.time = this.$options.data().time
      this.page = this.$options.data().page
      this.getList();
    },
    //查询
    getSearchlist() {
      this.page.current = 1;
      for (let key in this.form) {
        if (this.form[key] === "" || this.form[key] === null) {
          this.form[key] = undefined;
        }
      }
      this.getList(this.form);
    },
    //数据列表
    getList(params) {
      this.dataListLoading = true;
      pageQuery(Object.assign({ ...this.page }, params)).then((res) => {
        console.log(res);
        if (res.data.code === 0) {
          res.data.data.records.forEach(ite => {
            this.warehouseCode.forEach(item => {
              if (ite.warehouseCode == item.warehouseCode) {
                ite.warehouseName = item.warehouseName
              }
            })
          })
          this.tableData = res.data.data.records
          this.total = res.data.data.total;
          this.dataListLoading = false;
        } else {
          this.$message.error(res.data.msg);
          this.dataListLoading = false;
        }
      }).catch(() => {
        this.$message.error("request was aborted");
        this.dataListLoading = false;
      });
    },
    //打开dialog
    operaterType(type) {
      this.showDialog = true
      this.centerDialogVisible = true;
      this.title = type
      if (type === "Arrive") {
        this.rowArray = this.multipleSelection
        return
      }
      this.rowArray = this.blNo
    },
    //关闭dialog
    formClose(e, type, title) {
      this.centerDialogVisible = e
      this.showDialog = e
      if (type) {
        this.getList(this.form)
      }
      console.log(e, type);
    },
    //删除
    deleteOrd() {
      this.$confirm('This operation will permanently delete this data. Do you want to continue?', 'Tips', {
        confirmButtonText: 'submit',
        cancelButtonText: 'cancel',
        type: 'warning'
      }).then(() => {
        getDeleteBl(this.blNo).then(res => {
          if (res.data.code === 0) {
            this.getList(this.form);
            this.$message.success("Deleted succeeded");
          } else {
            this.$message.error(res.data.msg)
            this.centerDialogVisible = false;
          }
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: 'Destruction'
        });
      });
    },
    //新增
    blAdd() {
      this.$router.push({
        path: "/blAdd"
      })
    },
    //详情
    handleDetail(row, index) {
      this.$router.push({
        path: "/blDetail",
        query: {
          name: row.blNo,
        }
      })
    },
    //warehouseCode下拉数据
    getWarehouse() {
      getWarehouse().then((res) => {
        if (res.data.code === 0) {
          this.warehouseCode = res.data.data;
        }
      });
    },
    //下拉数据
    getRemote() {
      remote("country_code").then((res) => {
        if (res.data.code === 0) {
          this.countryCode = res.data.data;
        }
      });
      remote("bl_ship_type").then((res) => {
        if (res.data.code === 0) {
          this.shipType = res.data.data;
        }
      });
      remote("bl_type").then((res) => {
        if (res.data.code === 0) {
          this.blStatus = res.data.data;
        }
      });
    },
  },
};
</script>
<style lang="scss" scoped>
.content {
  padding: 0 10px;

  .text {
    font-size: 14px;
  }

  .item {
    padding: 18px 0;
  }

  .box-card {
    width: 100%;
  }

  .down {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    border-top: 1px solid #999;
    padding-top: 20px;
    box-sizing: border-box;
  }

  .underLine {
    color: #599af8;
    text-decoration: underline;
    cursor: pointer;
  }

  ::v-deep .el-dialog {
    border-radius: 8px !important;
  }

  ::v-deep .el-select--small {
    display: block;
  }

  ::v-deep .el-date-editor--daterange.el-input,
  ::v-deep .el-date-editor--daterange.el-input__inner,
  ::v-deep .el-date-editor--timerange.el-input,
  ::v-deep .el-date-editor--timerange.el-input__inner {
    width: 100% !important;
  }
}
</style>
