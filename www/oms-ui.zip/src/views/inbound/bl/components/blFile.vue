<template>
  <div class="blFile">
    <div class="containBox">
      <div class="title">
        <span></span>
        <label>BL File</label>
      </div>
    </div>
    <div class="down">
      <el-button icon="el-icon-upload2" @click="uploadExcelBl"
        :disabled="blFileRow.status === 'arrived' || blFileRow.status === 'allocated'"
        v-if="permissions.inbound_bl_upload_bl">BL Document</el-button>
      <el-button icon="el-icon-upload2" @click="uploadExcelCl"
        :disabled="blFileRow.status === 'arrived' || blFileRow.status === 'allocated'"
        v-if="permissions.inbound_bl_upload_ci">Cl</el-button>
      <el-button icon="el-icon-upload2" @click="uploadExcelPl"
        :disabled="blFileRow.status === 'arrived' || blFileRow.status === 'allocated'"
        v-if="permissions.inbound_bl_upload_pl">PL</el-button>
      <el-button icon="el-icon-download" @click="exportExcelCustoms"
        :disabled='blFileRow.shipType === "Local" || (blFileRow.status !== "verifySuccess" && blFileRow.status !== "arrived" && blFileRow.status !== "allocated")'
        v-if="permissions.inbound_blfile_download">Customs Files</el-button>
      <!-- <i class="iconfont icon-shangchuan" v-if="permissions.outbound_outorderline_export" @click="uploadExcelBl"><span>BL Document</span></i>
      <i class="iconfont icon-shangchuan" v-if="permissions.outbound_outorderline_export" @click="uploadExcelCl"><span>Cl</span></i>
      <i class="iconfont icon-shangchuan" v-if="permissions.outbound_outorderline_export" @click="uploadExcelPl"><span>PL</span></i>
      <i class="el-icon-download" v-if="permissions.outbound_outorderline_export" @click="exportExcelCustoms"><span>Customs Files</span></i> -->
    </div>
    <el-table border ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%; margin-bottom: 20px"
      v-loading="dataListLoading"
      :header-cell-style="{ background: '#f5f7fa', color: '#606266', 'text-align': 'center', }">
      <el-table-column label="File Type" min-width="120" align="center">
        <template slot-scope="scope">{{ scope.row.fileType || "-" }}</template>
      </el-table-column>
      <el-table-column label="File Name" min-width="160" align="center" show-overflow-tooltip>
        <template slot-scope="scope">
          <div @click="downloadFile(scope.row, scope.index)"
            style="cursor: pointer;color: #599af8;text-decoration: underline;">
            {{ scope.row.fileName || "-" }}
          </div>
        </template>
      </el-table-column>
      <el-table-column label="File Size." min-width="120" align="center">
        <template slot-scope="scope">{{ scope.row.fileSize || "--" }}</template>
      </el-table-column>
      <el-table-column label="Parse Status" min-width="120" align="center">
        <template slot-scope="scope">
          <i
            :class="scope.row.fileStatus === 'verifySuccess' || scope.row.fileStatus === 'uploaded' ? 'el-icon-success success' : 'el-icon-error error'"></i>
          {{ scope.row.fileStatus ? "" : "-" }}
        </template>
      </el-table-column>
      <el-table-column label="Upload Time" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.createTime || "-" }}</template>
      </el-table-column>
      <el-table-column label="Opearter" align="center">
        <template slot-scope="scope">
          <el-button :disabled="blFileRow.status === 'arrived' || blFileRow.status === 'allocated'"
            style="font-size: 18px;color: #65beff;padding:0;border:0;margin-left:0"
            :style="{ 'color': blFileRow.status === 'arrived' || blFileRow.status === 'allocated' ? '' : '#65beff' }"
            class="el-icon-delete" @click="deleteFile(scope.row, scope.index)"
            v-if="permissions.inbound_blfile_del"></el-button>
        </template>
      </el-table-column>
    </el-table>
    <!--excel 模板导入 -->
    <MultipleExcelDialog ref="excelUpload" :multiple="upload.multiple" :accept="upload.accept" :title="upload.title"
      :url="upload.url" :temp-name="upload.tempName" :temp-url="upload.tempUrl" @refreshDataList="handleRefreshChange"
      :row="row" :fileDateList="tableData"></MultipleExcelDialog>
  </div>
</template>
<script>
import { mapGetters } from "vuex";
import MultipleExcelDialog from "@/components/upload/multipleExcelDialog.vue";
import { getBlFile, getDeleteBlFileById, downloadCustomsFile } from "@/api/inbound/bl"
export default {
  data() {
    return {
      // page: {
      //   size: 10,
      //   current: 1,
      // },
      // total: 0,
      tableData: [],
      dataListLoading: false,
      upload: {
        multiple: false,
        accept: "",
        title: "",
        url: "",
        tempName: "",
        tempUrl: "",
      },
      row: {}
    };
  },
  props: {
    blFile: {
      type: String
    },
    blFileRow: {
      type: Object
    }
  },
  components: {
    MultipleExcelDialog,
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  watch: {
    // 利用watch方法检测路由变化：
    $route: function (to, from) {
      if (to.path == "/blDetail/index" && to.query.name) {
        if (to.query.name != from.query.name) {
          this.blFile = to.query.name;
          this.getList();
        }
      }
    },
  },
  created() {
    this.getList()
  },
  methods: {
    //上传
    uploadExcelBl() {
      this.$refs.excelUpload.show();
      this.upload = Object.assign(
        {},
        {
          multiple: true,
          accept: ".pdf",
          title: "AddUploadBlDocument",
          url: `/inbound/bl/addUploadBlDocument?blNo=${this.blFile}`,
          // tempName: "year-end-report-template.pdf",
          // tempUrl: "/admin/sys-file/local/year-end-report-template.xlsx",
        }
      );
    },
    uploadExcelCl() {
      this.$refs.excelUpload.show();
      this.upload = Object.assign(
        {},
        {
          multiple: true,
          accept: ".xls, .xlsx",
          title: "AddUploadCIFile",
          url: `/inbound/bl/addUploadCIFile?blNo=${this.blFile}`,
          tempName: "CICurrencyTemplate.xlsx",
          tempUrl: "/admin/sys-file/local/CICurrencyTemplate.xlsx",
        }
      );
    },
    uploadExcelPl() {
      this.$refs.excelUpload.show();
      this.upload = Object.assign(
        {},
        {
          multiple: true,
          accept: ".xls, .xlsx",
          title: "AddUploadPLFile",
          url: `/inbound/bl/addUploadPLFile?blNo=${this.blFile}`,
          tempName: "PLCurrencyTemplate.xlsx",
          tempUrl: "/admin/sys-file/local/PLCurrencyTemplate.xlsx",
        }
      );
    },
    //上传子传父
    handleRefreshChange(e) {
      console.log(e, '12121');
      if (e === 'loading') {
        this.$emit('blFileLoading', true)
        return
      }
      this.$emit('blFileLoading', false)
      this.getList()
    },
    //导出
    exportExcelCustoms() {
      // if(this.blFileRow.shipType === "Local" && this.blFileRow.status !== "arrived" && this.blFileRow.status !== "allocated") {
      //   this.$message.error('当前运输类型或BL状态不支持下载资料包')
      //   return
      // }
      this.$emit('blFileLoading', true)
      downloadCustomsFile({ blNo: this.blFile }).then(res => {
        if (res.data.code === 0) {
          this.$emit('blFileLoading', false)
          const link = document.createElement('a');
          // 这里是将链接地址url转成blob地址，
          link.href = res.data.data
          // 下载文件的名称及文件类型后缀
          link.download = "CustomsFiles.xlsx";
          document.body.appendChild(link)
          link.click()
          //在资源下载完成后 清除 占用的缓存资源
          window.URL.revokeObjectURL(link.href);
          document.body.removeChild(link);
        } else {
          this.$emit('blFileLoading', false)
        }
      }).catch(() => {
        this.$emit('blFileLoading', false)
      })
    },
    //数据列表
    getList() {
      this.dataListLoading = true;
      getBlFile({ blNo: this.blFile }).then((res) => {
        console.log(res);
        if (res.data.code === 0) {
          this.tableData = res.data.data;
          this.dataListLoading = false;
        } else {
          this.$message.error(res.data.msg);
          this.dataListLoading = false;
        }
      }).catch(() => {
        this.dataListLoading = false;
      })
    },
    //下载file
    downloadFile(row, index) {
      console.log(row);
      const link = document.createElement("a");
      link.href = row.fileAddress
      link.download = row.fileName
      const fileIndex = row.fileAddress.lastIndexOf('.')
      const fileType = row.fileAddress.substring(fileIndex)
      if (fileType === '.pdf' || fileType === '.PDF') {
        link.target = "_blank"
      }
      document.body.appendChild(link);
      link.click();
      window.setTimeout(function () {
        URL.revokeObjectURL(link.href);
        document.body.removeChild(link);
      }, 0);
      //  // 这里是将链接地址url转成blob地址，
      // fetch(row.fileAddress).then(res => res.blob()).then(blob => {  
      //   link.href = URL.createObjectURL(blob)
      //   // 下载文件的名称及文件类型后缀
      //   link.download = row.fileName; 
      //   document.body.appendChild(link)
      //   link.click()
      //   //在资源下载完成后 清除 占用的缓存资源
      //   window.URL.revokeObjectURL(link.href);
      //   document.body.removeChild(link);
      // });
    },
    //删除
    deleteFile(row, index) {
      // console.log(this.blFileRow.status);
      // if(this.blFileRow.status === "arrived" || this.blFileRow.status === "allocated") {
      //   this.$message.error('当前BL状态不支持删除文件')
      //   return
      // }
      console.log(row.id);
      this.$confirm('This operation will permanently delete this data. Do you want to continue?', 'Tips', {
        confirmButtonText: 'submit',
        cancelButtonText: 'cancel',
        type: 'warning'
      }).then(() => {
        getDeleteBlFileById({ id: row.id }).then((res) => {
          if (res.data.code === 0) {
            this.getList();
            this.$emit('refresh')
            // this.$emit('delete',row)
            this.row = row
            this.$refs.excelUpload.delete();
            this.$message.success("Deleted succeeded");
          } else {
            this.$message.error(res.data.msg);
            this.centerDialogVisible = false;
          }
        });
      }).catch(() => {
        this.$message({
          type: 'info',
          message: 'Destruction cancelled'
        })
      })
    },
  },
};
</script>
<style lang="scss" scoped>
.blFile {
  .containBox {
    // border-bottom: 1px solid #999;
    margin-bottom: 20px;

    .title {
      width: 100%;
      height: 30px;
      line-height: 30px;
      display: flex;
      margin-bottom: 10px;

      span {
        width: 3px;
        height: 30px;
        background-color: #000;
        margin-right: 10px;
      }

      label {
        font-weight: 700;
      }
    }
  }

  .down {
    float: right;
    margin-bottom: 20px;

    i {
      font-size: 12px;
      padding: 9px 15px;
      background-color: #f7f8fa;
      margin-right: 5px;
      cursor: pointer;
    }

    i:last-of-type {
      margin-right: 0px;
    }

    span {
      margin-left: 10px;
    }
  }

  .success {
    color: rgb(137, 234, 137);
    font-size: 18px;
  }

  .error {
    color: rgb(238, 99, 99);
    font-size: 18px;
  }
}
</style>
