<template>
  <div>
    <el-dialog
      :title="title"
      :visible.sync="centerDialogVisible"
      width="35%"
      style="font-weight: 700"
      :close-on-click-modal="false"
      v-loading='dialogLoading'
    >
      <!-- element-loading-text="拼命加载中"
      element-loading-spinner="el-icon-loading" -->
      <div v-if="title === 'Verify'">
        <el-row>
          <el-col> Confirm to perform verification on the Job {{rowArray.join('/')}} again?</el-col>
          <el-col>- Verify whether master data exists</el-col>
          <el-col>- Verify whether hscodes are maintained</el-col>
          <el-col>- Verify whether the packaging information is complete</el-col>
        </el-row>
      </div>
      <div v-else-if="title === 'Allocate'">
        <div> Are you sure to allocate the BL {{rowArray.join('/')}} to ASN according to the container number?</div>
      </div>
      <el-form
        :model="formDialog"
        ref="blForm"
        :rules="rules"
        label-width="220px"
        v-else
      >
        <el-form-item label="Previous customs number:" prop="customsNumber">
          <el-input v-model="formDialog.customsNumber" placeholder='Please enter preious customs ref'></el-input>
        </el-form-item>
        <el-form-item label="Address:" prop="address">
          <el-input type="textarea" v-model="formDialog.address" placeholder='Please enter location of the goods'></el-input>
        </el-form-item>
        <div style="margin-top:50px;color:999;font-size:12px"> 
          * The basic information and file information of Job cannot be modified after submiting the arrival information.<br/>
          &nbsp;&nbsp;&nbsp;Please confirm that the information is correct before submiting.
        </div>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button type="info" @click="getClose">Cancel</el-button>
        <el-button type="primary" @click="dialogButton">Submit</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script>
import { getVerifyDataByBlNo, getBlArriveAddOrUpdate, getAllocateAsnByBlNo } from "@/api/inbound/bl"
export default {
  data() {
    return {
      formDialog: {
        customsNumber: "",
        address: "",
      },
      rules: {
        customsNumber: [
          { required: true, message: "请输入以前的海关参考号", trigger: "blur" },
        ],
        address: [
          { required: true, message: "请输入货物的位置", trigger: "blur" },
          { max: 500, message: '输入字段最大500个字符', trigger: 'blur' }
        ],
      },
      dialogLoading:false
    };
  },
  props:{
    centerDialogVisible:{
      type:Boolean
    },
    title:{
      type:String
    },
    rowArray:{
      type: Array
    }
  },
  created() {
    console.log(this.rowArray,'5555555');
    if (this.title === "Arrive"){
      this.$set(this.rowArray[0],'customsNumber',this.rowArray[0].cnumber)
      this.formDialog = this.rowArray[0]
    }
  },
  mounted(){
    this.dialogButton = this.$btn(this.dialogButton,500)
  },
  methods: {
    //子调父方法改变dialog状态
    getClose(){
      this.$emit("formClose",false);
      if(this.title === "Arrive"){
        this.formDialog = this.$options.data().formDialog;
        this.$refs.blForm.resetFields();
      }
    },
    //编辑
    dialogButton() {
      if (this.title === "Verify") {
        this.dialogLoading = true
        getVerifyDataByBlNo(this.rowArray).then((res) => {
          console.log(res);
          if (res.data.code === 0) {
            if(!res.data.msg){
              this.$message.success("Verify succeeded");
            }else{
              this.$message({
                type:'error',
                dangerouslyUseHTMLString: true,
                message: res.data.msg
              });
            }
            this.dialogLoading = false
            this.$emit("formClose",false,'Refresh');
          }else{
            this.dialogLoading = false
            this.$emit("formClose",false,'Refresh');
            this.$message.error(res.data.msg);
          }
        }).catch(()=>{
          this.dialogLoading = false
          this.$emit("formClose",false,'Refresh');
        })
      } else if (this.title === "Allocate"){
        this.dialogLoading = true
        getAllocateAsnByBlNo(this.rowArray).then((res) => {
          if (res.data.code === 0) {
            this.$message.success("Allocate succeeded");
            this.dialogLoading = false
            this.$emit("formClose",false,'Refresh');
          } else {
            this.dialogLoading = false
            this.$emit("formClose",false);
            this.$message.error(res.data.msg);
          }
        }).catch(()=>{
          this.dialogLoading = false
          this.$emit("formClose",false);
        })
      }else{
        this.$refs.blForm.validate((valid) => {
          if (!valid) return false;
          getBlArriveAddOrUpdate({...this.formDialog }).then((res) => {
            if (res.data.code === 0) {
              this.$message.success("Arrive succeeded");
              this.$emit("formClose",false,'Refresh');
            } else {
              this.$emit("formClose",false);
              this.$message.error(res.data.msg);
            }
          }).catch(()=>{
            this.$emit("formClose",false);
          })
        });
      }
    },
  },
};
</script>
<style lang="scss" scoped></style>
