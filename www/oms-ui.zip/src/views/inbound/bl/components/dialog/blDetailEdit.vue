<template>
  <div>
    <el-dialog
      title="Edit"
      :visible="editDetailDialog"
      width="50%"
      style="font-weight: 700"
      @close="getClose"
    >
      <el-form
        :model="formDialog"
        ref="editForm"
        :rules="rules"
        label-width="120px"
      >
        <el-form-item label="Owner:" prop="clientCode">
          <el-input v-model="formDialog.clientCode" disabled></el-input>
        </el-form-item>
        <el-form-item label="Job no:" prop="blNo">
          <el-input v-model="formDialog.blNo" disabled></el-input>
        </el-form-item>
        <el-form-item label="BL no:" prop="billLandNum">
          <el-input v-model="formDialog.billLandNum"></el-input>
        </el-form-item>
        <el-form-item label="Ship Type:" prop="shipType">
          <el-select v-model="formDialog.shipType" filterable clearable>
            <el-option
              v-for="item in shipType"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            >
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="CountryCode:" prop="countryCode">
          <el-select v-model="formDialog.countryCode" filterable clearable>
            <el-option
              v-for="item in countryCode"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            >
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="ETA:" prop="etaTime">
          <el-date-picker
            v-model="formDialog.etaTime"
            type="datetime"
            default-time="12:00:00"
            value-format="yyyy-MM-dd HH:mm:ss"
          >
          </el-date-picker>
        </el-form-item>
        <el-form-item label="Incoterms:" prop="incoterms">
          <el-input v-model="formDialog.incoterms"></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button type="info" @click="getClose">Cancel</el-button>
        <el-button type="primary" @click="dialogButton">Submit</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script>
import Pagination from "@/components/pagination/pagination.vue";
import { remote } from "@/api/admin/dict";
import { getBlEdit } from "@/api/inbound/bl";
export default {
  name: "BlDetailDialog",
  data() {
    return {
      formDialog: {
        clientCode: "",
        blNo: "",
        billLandNum: "",
        shipType: "",
        countryCode: "",
        etaTime: "",
        incoterms: "",
      },
      rules: {
        clientCode: { required: true, message: "请填写clientCode", trigger: "blur",},
        blNo: { required: true, message: "请填写blNo", trigger: "blur" },
        billLandNum: { required: true, message: "请填写billLandNum", trigger: "blur",},
        shipType: { required: true, message: "请选择shipType", trigger: "change",},
        countryCode: { required: true, message: "请选择countryCode", trigger: "change",},
        etaTime: { required: true, message: "请选择eta", trigger: "change" },
        incoterms: { required: true, message: "请填写incoterms", trigger: "blur",},
      },
      countryCode: [],
      shipType:[],
    };
  },
  props: {
    blDetail: {
      type: Object,
    },
    editDetailDialog: {
      type: Boolean,
    },
  },
  // watch: {
  //   // 利用watch方法检测路由变化：
  //   $route: function (to, from) {
  //     if (to.path == "/blDetail/index" && to.query.row) {
  //       if (to.query.row != from.query.row) {
  //         this.formDialog = this.blDetail;
  //       }
  //     }
  //   },
  // },
  created() {
    this.getRemote();
    this.formDialog = Object.assign({},this.blDetail);
  },
  methods: {
    getClose() {
      this.$emit("getClose", false);
      this.$refs.editForm.resetFields();
    },
    //编辑
    dialogButton() {
      this.$refs.editForm.validate((valid) => {
        if (!valid) return false;
        getBlEdit({ ...this.formDialog }).then((res) => {
          if (res.data.code === 0) {
            this.$message.success("Edit succeeded");
            this.$emit("getClose", false,'Refresh');
          } else {
            this.$message.error(res.data.msg);
            this.$emit("getClose",false,'Refresh');
          }
        });
      });
    },
    //下拉选择
    getRemote() {
      remote("country_code").then((res) => {
        if (res.data.code === 0) {
          this.countryCode = res.data.data;
        }
      });
      remote("bl_ship_type").then((res) => {
        if (res.data.code === 0) {
          this.shipType = res.data.data;
        }
      });
    },
  },
};
</script>
<style lang="scss" scoped></style>
