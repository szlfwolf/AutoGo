<template>
  <div class="content">
    <el-card class="box-card" v-loading="fileLoading" element-loading-text="拼命加载中"
    element-loading-spinner="el-icon-loading">
      <el-form
        ref="uploadForm"
        :model="upload"
        :rules="uploadRules"
        label-width="120px"
      >
        <div class="box-upload">
          <el-form-item label="IsCurrency:" prop="isCurrency">
            <el-switch
              v-model="upload.isCurrency"
              active-color="#13ce66"
              active-value="Y"
              inactive-value="N"
              >
            </el-switch>
          </el-form-item>
          <!--excel 模板导入 -->
          <el-form-item label="BL document:" :prop="form.shipType === 'Local'? '' : 'pic'">
              <!-- :limit="1" -->
            <MultipleExcelUpload
              :multiple="true"
              ref="pic"
              accept=".pdf"
              type="BL"
              url="/inbound/bl/addUploadBlDocument"
              @refreshDataList="handleRefreshChangePic"
              @uploadLoading="uploadLoading"
            ></MultipleExcelUpload>
          </el-form-item>
          <!--excel 模板导入 -->
          <el-form-item label="CI:" :prop="form.shipType === 'Local'? '' : 'cl'">
            <MultipleExcelUpload
              ref="cl"
              :multiple="true"
              accept=".xlsx, .xls"
              url="/inbound/bl/addUploadCIFile"
              @refreshDataList="handleRefreshChangeCl"
              @uploadLoading="uploadLoading"
              type="CI"
              temp-name="CICurrencyTemplate.xlsx"
              temp-url="/admin/sys-file/local/CICurrencyTemplate.xlsx"
              :isCurrency="upload.isCurrency"
            ></MultipleExcelUpload>
          </el-form-item>
          <!--excel 模板导入 -->
          <el-form-item label="PL:" prop="pl">
            <MultipleExcelUpload
              ref="pl"
              :multiple="true"
              accept=".xlsx, .xls"
              url="/inbound/bl/addUploadPLFile"
              @refreshDataList="handleRefreshChangePl"
              @uploadLoading="uploadLoading"
              type="PL"
              temp-name="PLCurrencyTemplate.xlsx"
              temp-url="/admin/sys-file/local/PLCurrencyTemplate.xlsx"
              :isCurrency="upload.isCurrency"
            ></MultipleExcelUpload>
          </el-form-item>
        </div>
      </el-form>
      <div style="margin-top: 50px; display: flex; justify-content: center">
        <el-button type="primary" style="margin-right: 30px" @click="pre">上一步</el-button>
        <el-button type="primary" @click="submit">提交</el-button>
      </div>
    </el-card>
  </div>
</template>
<script>
import Vue from "vue"
import { mapGetters } from "vuex";
import MultipleExcelUpload from "@/components/upload/multipleExcel.vue";
import { getAddBL } from "@/api/inbound/bl"
import { setStore } from '@/util/store';
export default {
  name: "Files",
  data() {
    return {
      upload: {
        pic: [],
        cl: [],
        pl: [],
        isCurrency:"N"
      },
      uploadRules: {
        pic: [
          {
            required: true,
            validator: (rule, value, callback) => {
              if (!this.upload.pic.length) {
                callback(new Error("请选择文件上传"));
                //new Error("请选择文件上传")
              }
              callback();
            },
            trigger: "change",
          },
        ],
        cl: [
          {
            required: true,
            validator: (rule, value, callback) => {
              if (!this.upload.cl.length) {
                callback(new Error("请选择文件上传"));
              }
              callback();
            },
            trigger: "change",
          },
        ],
        pl: [
          {
            required: true,
            validator: (rule, value, callback) => {
              if (!this.upload.pl.length) {
                callback(new Error("请选择文件上传"));
              }
              callback();
            },
            trigger: "change",
          },
        ],
        isCurrency:{ required: true, message: "请选择country", trigger: "change" },
      },
      pic:[],
      pl:[],
      cl:[],
      fileLoading:false
    };
  },
  props:{
    form:{
      type: Object
    }
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  components: {
    MultipleExcelUpload,
  },
  created() {},
  methods: {
    uploadLoading(e){
      // this.fileLoading = e
    },
    pre() {
      this.$emit("pre") 
    },
    submit() {
      this.$refs.uploadForm.validate((valid) => {
        if (!valid) return false;
        this.fileLoading = true
        // [0].response.data
        getAddBL({...this.form,blFileList:this.pic,plFileList:this.pl,ciFileList:this.cl,isCurrency:this.upload.isCurrency}).then(res=>{
          console.log(res);
          if(res.data.code === 0){
            this.$store.commit('SET_UUID',"")
            this.upload = this.$options.data().upload;
            this.pic = this.$options.data().pic
            this.pl = this.$options.data().pl
            this.cl = this.$options.data().cl
            this.fileLoading = false
            this.$emit("next");
            this.$emit('refresh')
            setStore({name:"fileComplete",content:JSON.stringify(res)})
            // this.eventBus.$emit('completed',JSON.stringify(res))
            if(res.data.msg){
              this.$message({
                type:'error',
                dangerouslyUseHTMLString: true,
                message: res.data.msg
              });
            }
            //失败的时候不清除吗
            this.$refs.pic.submitFileForm()
            this.$refs.cl.submitFileForm()
            this.$refs.pl.submitFileForm()
          }else{
            this.fileLoading = false
            // this.eventBus.$emit('completed',res)
            setStore({name:"fileComplete",content:JSON.stringify(res)})
            if(res.data.msg){
              this.$message({
                type:'error',
                dangerouslyUseHTMLString: true,
                message: res.data.msg
              });
            }
          }
        }).catch((err)=>{
          this.fileLoading = false
        })
      });
    },
    //清楚验证
    getClearValid(type) {
      this.$refs.uploadForm.clearValidate(type);
    },
    //pic
    handleRefreshChangePic(e) {
      // console.log(e, "pic");
      // this.upload.pic = e;
      // this.getClearValid("pic");
      // this.pic=this.upload.pic
      // console.log(this.pic,this.upload.pic);
      console.log(e, "pic");
      this.upload.pic = e;
      console.log(this.upload.pic,'this.upload.pic');
      if(this.upload.pic.length){
        this.getClearValid("pic");
      }
      this.pic = []
      this.upload.pic.forEach(ite=>{
        if(ite.response){
          if(ite.response.data){
            this.pic.push(ite.response.data)
            console.log(this.pic),'444444444';
          }
        }
      })
      this.pic = [...new Set(this.pic)]
      console.log(this.pic);
    },
    //cl
    handleRefreshChangeCl(e) {
      console.log(e, "cl");
      this.upload.cl = e;
      console.log(this.upload.cl,'this.upload.cl');
      if(this.upload.cl.length){
        this.getClearValid("cl");
      }
      this.cl = []
      this.upload.cl.forEach(ite=>{
        if(ite.response){
          if(ite.response.data.length){
            this.cl.push(ite.response.data[0])
          }
        }
      })
      this.cl = [...new Set(this.cl)]
      console.log(this.cl);
    },
    //pl
    handleRefreshChangePl(e) {
      console.log(e, "pl");
      this.upload.pl = e;
      if(this.upload.cl.length){
        this.getClearValid("pl");
      }
      this.pl = []
      this.upload.pl.forEach(ite=>{
       if(ite.response){
         if(ite.response.data.length){
          this.pl.push(ite.response.data[0])
        }
       }
      })
      this.pl = [...new Set(this.pl)]
      console.log(this.pl);
    },
  },
};
</script>
<style lang="scss" scoped>
.content {
  padding: 0 10px;
  // box-sizing: border-box;
  .text {
    font-size: 14px;
  }

  .item {
    padding: 18px 0;
  }
  .box-card {
    width: 100%;
  }

  .box-upload {
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-left: -100px;
  }
}
</style>
