<template>
  <div class="content">
    <el-card class="box-card">
      <div style="display: flex; flex-direction: column; align-items: center">
        <i class="el-icon-success" style="color: #34c627; font-size: 72px"></i>
        <div style="font-size: 36px; font-weight: 700">Add Success</div>
        <el-tag type="warning" v-if="msg" v-html="msg" style="margin-top:20px;height:100px"></el-tag>
      </div>
      <el-form label-width="120px" style="margin:20px 0 0 100px">
          <el-form-item label="Job no:">
            <i class="el-icon-document-copy copy" @click="clickCopy"></i>
            {{form.blNo}}
          </el-form-item>
          <el-form-item label="BL no:">{{form.billLandNum}}</el-form-item>
          <el-form-item label="Ship Type:">{{form.shipType}}</el-form-item>
        <el-table
          border
          ref="multipleTable"
          :data="tableData"
          tooltip-effect="dark"
          show-summary
          :summary-method="getSummaries"
        >
          <el-table-column label="Container Qty" min-width="120" align="center" show-overflow-tooltip prop="containerNo"></el-table-column>
          <el-table-column label="Lines" min-width="120" align="center" prop="lins"></el-table-column>
          <el-table-column label="PCS" min-width="120" align="center" prop="num"></el-table-column>
        </el-table>
      </el-form>
      <div style="margin-top: 50px; display: flex; justify-content: center">
        <el-button type="primary" @click="pre">Continue to add</el-button>
        <el-button type="primary" @click="submit">View details</el-button>
      </div>
    </el-card>
  </div>
</template>
<script>
import { getStore } from '@/util/store';
import { mapGetters } from "vuex";
export default {
  name: "complete",
  data() {
    return {
      tableData:[],
      form:{},
      msg:''
    };
  },
  computed: {
    ...mapGetters(["permissions","tagList"]),
  },
  components: {},
  created() {
    // this.eventBus.$on('completed',(e)=>{
    //   let res = JSON.parse(e)
    //   this.form = res.data.data
    //   this.tableData = res.data.data.blContainerList
    //   if(res.data.msg){
    //     this.msg = res.data.msg
    //   }
    // })
    console.log(JSON.parse(getStore({name:"fileComplete"})),'5555555555555');
    let res = JSON.parse(getStore({name:"fileComplete"}))
    this.form = res.data.data
    this.tableData = res.data.data.blContainerList
    if(res.data.msg){
      this.msg = res.data.msg
    }
  },
  beforeDestroy() {
    this.eventBus.$off('completed');
  },
  methods: {
    //复制
    clickCopy() {
      let content = this.form.blNo
      if(this.copy(content) === '文本为空'){
        this.$message.warning("Text is empty and cannot be copied !!!")
        return
      }
      this.$message.success("copy success")
    },
    pre() {
      this.$emit("pre");
    },
    submit() {
      let { tag, key } = this.findTag(this.$route.path);
      this.$store.commit('DEL_TAG',tag)
      this.$router.push({
        path: "/blDetail",
        query: {
          name:this.form.blNo,
        }
      });
    },
    findTag(value) {
      let tag, key;
      this.tagList.map((item, index) => {
        if (item.value === value) {
          tag = item;
          key = index;
        }
      });
      return { tag: tag, key: key };
    },
    getSummaries(param) {
        const { columns, data } = param;
        const sums = [];
        columns.forEach((column, index) => {
          if (index === 0) {
            sums[index] = 'Total';
            return;
          }
          const values = data.map(item => Number(item[column.property]));
          if (!values.every(value => isNaN(value))) {
            sums[index] = values.reduce((prev, curr) => {
              const value = Number(curr);
              if (!isNaN(value)) {
                return prev + curr;
              } else {
                return prev;
              }
            }, 0);
            // sums[index] += ' 元';
          } else {
            // sums[index] = 'N/A';
          }
        });

        return sums;
      }
  },
};
</script>
<style lang="scss" scoped>
.content {
  padding: 0 10px;
  // box-sizing: border-box;
  .text {
    font-size: 14px;
  }

  .item {
    padding: 18px 0;
  }
  .box-card {
    width: 100%;
  }
}
</style>
