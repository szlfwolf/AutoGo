<template>
  <div class="content">
    <el-card class="box-card">
      <el-steps :active="active" finish-status="success" align-center>
        <el-step title="Input base info"> </el-step>
        <el-step title="Upload Job Files"> </el-step>
        <el-step title="Completed"> </el-step>
      </el-steps>
      <div style="width: 60%;margin: 50px auto">
        <div v-show="active === 0"> 
          <el-form ref="form" :model="form" :rules="rules" label-width="120px">
            <el-form-item label="Owner:" prop="clientCode">
              <el-input disabled v-model="form.clientCode"></el-input>
            </el-form-item>
            <el-form-item label="BL no:" prop="billLandNum">
              <el-input placeholder="Please enter BL no" v-model="form.billLandNum"></el-input>
            </el-form-item>
            <el-form-item label="Ship Type:" prop="shipType">
              <el-select v-model="form.shipType" placeholder="Please choose the ship type of Ship Type" filterable clearable>
                <el-option
                  v-for="item in shipType"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                >
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="CountryCode:" prop="countryCode">
              <el-select v-model="form.countryCode" placeholder="Please choose the country code of CountryCode" filterable clearable>
                <el-option
                  v-for="item in countryCode"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                >
                </el-option>
              </el-select>
            </el-form-item>
             <el-form-item label="Warehouse:" prop="warehouseCode">
              <el-select v-model="form.warehouseCode" placeholder="Please choose the warehouse type of Warehouse" filterable clearable>
                <el-option
                  v-for="item in warehouseCode"
                  :key="item.value"
                  :label="item.warehouseName"
                  :value="item.warehouseCode"
                >
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="ETA:" prop="etaTime">
              <el-date-picker
                v-model="form.etaTime"
                type="datetime"
                default-time="12:00:00"
                value-format="yyyy-MM-dd HH:mm:ss"
              >
            </el-date-picker>
            </el-form-item>
            </el-form-item>
            <el-form-item label="Incoterms:" prop="incoterms">
              <el-input placeholder="Please enter incoterms" v-model="form.incoterms"></el-input>
            </el-form-item>
          </el-form>
          <div style="margin-top: 50px; display: flex; justify-content: center">
            <el-button type="primary" @click="next">下一步</el-button>
          </div>
        </div>
        <div v-show="active === 1">
          <Files @pre="pre" @next="next" :form="form" @refresh="refresh"></Files>
        </div>
        <div v-if="active === 2">
          <Complete @pre="pre" @next="next"></Complete>
        </div>
      </div>
    </el-card>
  </div>
</template>
<script>
import store from "@/store";
import { mapGetters } from "vuex";
import Files from "./components/files.vue";
import Complete from "./components/complete.vue";
import { remote } from "@/api/admin/dict";
import { getWarehouse,} from "@/api/outbound/order";
export default {
  name: "BlAdd",
  data() {
    return {
      active: 0,
      form: {
        clientCode: store.getters.commandName,
        billLandNum: "",
        shipType:"",
        warehouseCode: "",
        countryCode: "",
        incoterms: "",
        etaTime:"",
      },
      countryCode: [],                
      warehouseCode:[],
      shipType:[],
      rules: {
        clientCode: [{ required: true, message: "请填写owner", trigger: "blur" }],
        billLandNum: [{ required: true, message: "请填写BL no", trigger: "blur" }],
        shipType: [
          { required: true, message: "请选择仓库shipType", trigger: "change" },
        ],
        warehouseCode: [
          { required: true, message: "请选择warehouse", trigger: "change" },
        ],
        countryCode: [
          { required: true, message: "请选择country", trigger: "change" },
        ],
        etaTime:{ required: true, message: "请选择eta", trigger: "change"},
        incoterms: [
          { required: true, message: "请填写incoterms", trigger: "blur" },
        ],
      },
    };
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  components: {
    Files,
    Complete,
  },
  created() {
    this.getRemote();
    this.$store.commit('SET_UUID','')
  },
  methods: {
    next() {
      if (this.active === 0) {
        console.log(this.form);
        this.$refs.form.validate((valid) => {
          if (!valid) return false;
          this.active++;
        });
      } else {
        this.active++;
      }
    },
    pre() {
      if (this.active === 2) {
        this.active = 0;
        this.$nextTick(() => {
          this.form = this.$options.data().form;
          this.$refs.form.resetFields();
        });
      } else {
        this.active--;
      }
    },
    refresh(){
      this.eventBus.$emit('blDetailStatus')
    },
    getRemote() {
      remote("country_code").then((res) => {
        if (res.data.code === 0) {
          this.countryCode = res.data.data;
        }
      });
      //warehouse
      getWarehouse().then((res) => {
        if (res.data.code === 0) {
          this.warehouseCode = res.data.data;
        }
      });
      //shipType
      remote("bl_ship_type").then((res) => {
        if (res.data.code === 0) {
          this.shipType = res.data.data;
        }
      });
    },
  },
  // deactivated() {
  //   this.$store.commit('SET_UUID','')
  // },
};
</script>
<style lang="scss" scoped>
.content {
  padding: 0 10px;
  // box-sizing: border-box;
  .text {
    font-size: 14px;
  }

  .item {
    padding: 18px 0;
  }
  .box-card {
    width: 100%;
    padding-top: 20px;
  }
  ::v-deep .el-select--small {
    display: block;
  }
  ::v-deep .el-date-editor--daterange.el-input,
  ::v-deep .el-date-editor--daterange.el-input__inner,
  ::v-deep .el-date-editor--timerange.el-input,
  ::v-deep .el-date-editor--timerange.el-input__inner {
    width: 100% !important;
  }
  ::v-deep .el-date-editor.el-input, .el-date-editor.el-input__inner {
    width: 100%;
  }

}
</style>
