<template>
  <div class="contentPending" v-loading="responseLoading">
    <el-row style="width:200px;display:flex">
      <el-col>
        <el-button type="primary" icon="el-icon-search" @click="getSearchlist">Query</el-button>
      </el-col>
      <el-col>
        <el-button icon="el-icon-refresh-left" @click="getReset">Reset</el-button>
      </el-col>
    </el-row>
    <el-form ref="form" :model="form" @keyup.enter.native="getSearchlist" style="margin: 20px 0">
      <el-row :gutter="20">
        <el-col :span="4">
          <el-input placeholder="Order no/BL no/ASN no/Pallate no" v-model="form.orderNo">
            <el-select filterable v-model="form.isAccurate" slot="prepend" class="common_select">
              <el-option label="accurate" value="Y"></el-option>
              <el-option label="dim" value="N"></el-option>
            </el-select>
          </el-input>
        </el-col>
        <el-col :span="4">
          <el-select v-model="form.warehouseCode" placeholder="Warehouse" filterable clearable>
            <el-option v-for="item in select.warehouseCode" :key="item.value" :label="item.warehouseName"
              :value="item.warehouseCode">
            </el-option>
          </el-select>
        </el-col>
        <el-col :span="4">
          <el-select v-model="form.status" placeholder="Status" filterable clearable>
            <el-option v-for="item in select.status" :key="item.value" :label="item.label" :value="item.value">
            </el-option>
          </el-select>
        </el-col>
        <el-col :span="4">
          <el-date-picker v-model="time.createTime" type="daterange" start-placeholder="CreateTime"
            end-placeholder="CreateEndTime" :default-time="['00:00:00', '23:59:59']" value-format="yyyy-MM-dd HH:mm:ss"
            @change="changeCreateTime" />
        </el-col>
        <el-col :span="4">
          <el-date-picker v-model="time.mappingTime" type="daterange" start-placeholder="MappingTime"
            end-placeholder="MappingEndTime" :default-time="['00:00:00', '23:59:59']" value-format="yyyy-MM-dd HH:mm:ss"
            @change="changeMappingTime">
          </el-date-picker>
        </el-col>
        <el-col :span="4">
          <el-button style="float: right" type="primary" @click="about"
            :icon="show ? 'el-icon-arrow-up' : 'el-icon-arrow-down'">
            <label>{{ show ? "收起" : "更多" }}</label>
          </el-button>
        </el-col>
      </el-row>
      <el-row v-show="show" style="margin-top: 10px" :gutter="20">
        <el-col :span="4">
          <el-date-picker v-model="time.responseTime" type="daterange" start-placeholder="ResponseTime"
            end-placeholder="ResponseEndTime" :default-time="['00:00:00', '23:59:59']" value-format="yyyy-MM-dd HH:mm:ss"
            @change="changeResponseTime">
          </el-date-picker>
        </el-col>
        <el-col :span="4">
          <el-date-picker v-model="time.closeTime" type="daterange" start-placeholder="CloseTime"
            end-placeholder="CloseEndTime" :default-time="['00:00:00', '23:59:59']" value-format="yyyy-MM-dd HH:mm:ss"
            @change="changeClosedTime">
          </el-date-picker>
        </el-col>
      </el-row>
    </el-form>
    <div class="down">
      <div></div>
      <el-button class="el-icon-download" style="font-size:10px" v-if="permissions.inbound_inorder_export"
        @click="exportExcel"></el-button>
    </div>
    <el-table border ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%"
      v-loading="dataListLoading" @selection-change="handleSelectionChange"
      :header-cell-style="{ background: '#f5f7fa', color: '#606266', 'text-align': 'center', }">
      <el-table-column type="selection" min-width="55" align="center">
      </el-table-column>
      <el-table-column label="Warehouse" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.warehouseCode || "-" }}</template>
      </el-table-column>
      <el-table-column label="Owner" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.clientCode || "-" }}</template>
      </el-table-column>
      <el-table-column label="Order no" min-width="160" align="center" show-overflow-tooltip>
        <template slot-scope="scope">
          <div class="underLine" @click="handleDetail(scope.$index, scope.row, 'order')"
            v-if="permissions.inbound_inorder_getDetail">
            <i
              :class="scope.row.status === 'CLOSED' ? scope.row.hasDifference === 'N' ? 'el-icon-check underIcon' : 'el-icon-close underIconA' : ''"></i>
            {{ scope.row.orderNo || "-" }}
          </div>
          <div v-else>
            {{ scope.row.orderNo || "-" }}
          </div>
        </template>
      </el-table-column>
      <el-table-column label="BL no" min-width="160" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.billLandNum || "-" }}</template>
      </el-table-column>
      <el-table-column label="ASN" min-width="160" align="center" show-overflow-tooltip>
        <template slot-scope="scope">
          <div class="underLine" v-if="permissions.inbound_asn_getByAsnNo">
            <span v-if="scope.row.asnNo">
              <span v-for=" asnNo in scope.row.asnNo.split(';')">
                <span @click="handleDetail(scope.$index, asnNo, 'asn')" style="margin-right:5px">{{ asnNo || "-"
                }};</span>
              </span>
            </span>
            <span v-else>
              <span>{{ scope.row.asnNo || "-" }}</span>
            </span>
          </div>
          <div v-else>
            {{ scope.row.asnNo || "-" }}
          </div>
        </template>
      </el-table-column>
      <el-table-column label="Pallet no" min-width="140" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.palletNo || "-" }}</template>
      </el-table-column>
      <el-table-column label="Created" min-width="140" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.createTime || "-" }}</template>
      </el-table-column>
      <el-table-column label="Mapped" min-width="140" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.mappingTime || "-" }}</template>
      </el-table-column>
      <el-table-column label="Responded" min-width="140" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.responseTime || "-" }}</template>
      </el-table-column>
      <el-table-column label="Closed" min-width="140" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.closedTime || "-" }}</template>
      </el-table-column>
      <el-table-column label="Status" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.status || "-" }}</template>
      </el-table-column>
      <el-table-column fixed="right" label="Opearter" align="center" min-width="120"
        v-if="permissions.inbound_inorder_responsePreview || permissions.inbound_inorder_closedOrder">
        <template slot-scope="scope">
          <i style="font-size: 18px;cursor: pointer;color: #65beff;margin-right: 10px;" class="iconfont icon-fenxiang_f"
            v-if="permissions.inbound_inorder_responsePreview" @click="response(scope.row, scope.index)"></i>
          <el-button :disabled="scope.row.status !== 'RESPONDED'"
            style="font-size: 18px;color: #65beff;padding:0;border:0;margin-left:0"
            :style="{ 'color': scope.row.status !== 'RESPONDED' ? '' : '#65beff' }" class="iconfont icon-daka-copy"
            v-if="permissions.inbound_inorder_closedOrder" @click="close(scope.row, scope.index)"></el-button>
        </template>
      </el-table-column>
    </el-table>
    <Pagination @handleSizeChange="handleSizeChange" @handleCurrentChange="handleCurrentChange" :pageNum="page.current"
      :pageSize="page.size" :total="total"></Pagination>
  </div>
</template>
<script>
import { mapGetters } from "vuex"
import Pagination from "@/components/pagination/pagination.vue"
import { pageQuery, getInOrderResponsePreview, getClosedOrder } from "@/api/inbound/asnOrder";
import { getAsnDetails } from "@/api/inbound/asn"
import { remote } from "@/api/admin/dict"
import { getWarehouse } from "@/api/stock/analysis";
import { setStore } from "@/util/store"
let formParams = {
  orderNo: undefined,
  status: undefined,
  warehouseCode: undefined,
  isAccurate: "Y"
}
export default {
  name: "NoMapper",
  data() {
    return {
      time: {
        createTime: undefined,
        mappingTime: undefined,
        responseTime: undefined,
        closeTime: undefined,
      },
      form: Object.assign({}, formParams),
      page: {
        size: 10,
        current: 1,
        option: 'noResponded'
      },
      total: 0,
      dataListLoading: false,
      show: false, //更多
      tableData: [],
      multipleSelection: [],
      select: {
        status: [],
        warehouseCode: [],
      },//下拉列表字段
      status: [],
      dispatchDisabled: true,
      responseLoading: false
    }
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  components: {
    Pagination,
  },
  created() {
    this.getList()
    this.getRemote()
  },
  mounted() {
    this.exportExcel = this.$btn(this.exportExcel, 500)
    this.close = this.$btn(this.close, 500);
  },
  methods: {
    //时间参数
    changeCreateTime(val) {
      if (val !== undefined && val !== null && val !== "" && val.length > 0) {
        this.$set(this.form, "beginCreateTime", val[0]);
        this.$set(this.form, "endCreateTime", val[1]);
      } else {
        this.$set(this.form, "beginCreateTime", undefined);
        this.$set(this.form, "endCreateTime", undefined);
      }
    },
    changeMappingTime(val) {
      if (val !== undefined && val !== null && val !== "" && val.length > 0) {
        this.$set(this.form, "beginMappingTime", val[0]);
        this.$set(this.form, "endMappingTime", val[1]);
      } else {
        this.$set(this.form, "beginMappingTime", undefined);
        this.$set(this.form, "endMappingTime", undefined);
      }
    },
    changeResponseTime(val) {
      if (val !== undefined && val !== null && val !== "" && val.length > 0) {
        this.$set(this.form, "beginResponseTime", val[0]);
        this.$set(this.form, "endResponseTime", val[1]);
      } else {
        this.$set(this.form, "beginResponseTime", undefined);
        this.$set(this.form, "endResponseTime", undefined);
      }
    },
    changeClosedTime(val) {
      if (val !== undefined && val !== null && val !== "" && val.length > 0) {
        this.$set(this.form, "beginClosedTime", val[0]);
        this.$set(this.form, "endClosedTime", val[1]);
      } else {
        this.$set(this.form, "beginClosedTime", undefined);
        this.$set(this.form, "endClosedTime", undefined);
      }
    },
    //展开
    about() {
      this.show = !this.show
    },
    //条数
    handleSizeChange(val) {
      this.page.current = 1
      this.page.size = val
      this.getList(this.form)
    },
    //当前页数
    handleCurrentChange(val) {
      this.page.current = val
      this.getList(this.form)
    },
    //导出
    exportExcel() {
      this.responseLoading = true
      this.downBlobFile("/inbound/inOrder/export", { ...this.form, option: 'noResponded' }, `${this.$store.state.common.commandName}-AsnOrderNoRespond-${this.toDateFormat(new Date(), true)}.xlsx`, () => this.responseLoading = false);
    },
    //清空
    getReset() {
      this.form = Object.assign({}, formParams)
      this.time = this.$options.data().time
      this.page = this.$options.data().page
      this.getList()
    },
    //查询
    getSearchlist() {
      this.page.current = 1
      for (let key in this.form) {
        if (this.form[key] === '' || this.form[key] === null) {
          this.form[key] = undefined
        }
      }
      this.getList(this.form)
    },
    //数据列表
    getList(params) {
      this.dataListLoading = true
      pageQuery(Object.assign({ ...this.page }, params)).then(res => {
        console.log(res)
        if (res.data.code == 0) {
          this.tableData = res.data.data.records
          this.total = res.data.data.total
          this.dataListLoading = false
        } else {
          this.$message.error(res.data.msg)
          this.dataListLoading = false
        }
      }).catch(() => {
        this.$message.error('request was aborted')
        this.dataListLoading = false
      })
    },
    //多选
    handleSelectionChange(val) {
      this.multipleSelection = val
      this.status = []
      this.multipleSelection.forEach(ite => {
        this.status.push(ite.status)
      })
    },
    //回传
    response(row, index) {
      getInOrderResponsePreview({ orderNo: row.orderNo }).then(res => {
        console.log(res);
        if (res.data.code === 0) {
          this.$router.push({
            path: "/response",
          })
          setStore({ name: 'responseData', content: res.data.data })
        }
      })
    },
    //关闭
    close(row, index) {
      // if(row.status !== 'RESPONDED'){
      //   this.$message.warning(`${row.orderNo}  status does not support closing`)
      //   return
      // }
      getClosedOrder({ orderNo: row.orderNo }).then(res => {
        console.log(res);
        if (res.data.code === 0) {
          this.getList(this.form)
          this.$message.success('Closed succeeded')
        } else {
          this.$message.error(res.data.msg)
        }
      })
    },
    //下拉接口
    getRemote() {
      //status
      remote('in_order_type').then(res => {
        if (res.data.code === 0) {
          this.select.status = res.data.data
        }
      });
      //warehouse
      getWarehouse().then(res => {
        if (res.data.code === 0) {
          this.select.warehouseCode = res.data.data
        }
      });
    },
    getPending() {
      //获取pending数量
      getPending().then(res => {
        if (res.data.code === 0) {
          this.count = res.data.data
        }
      });
    },
    //跳转详情
    handleDetail(index, row, type) {
      if (type === "order") {
        this.$router.push({
          path: `/asnOrderDetail`,
          query: {
            name: row.orderNo,
          }
        })
      } else {
        getAsnDetails({ asnNo: row }).then(res => {
          console.log(res)
          if (res.data.code === 0) {
            let asnDetail = res.data.data
            this.$router.push({
              path: `/asnDetail`,
              query: {
                name: row,
                row: JSON.stringify(asnDetail),
              },
            })
          } else {
            this.$message.warning(res.data.msg)
          }
        })
      }
    },
  }
}
</script>
<style lang="scss" scoped>
.contentPending {

  // padding: 0 10px;
  // box-sizing: border-box;
  .down {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    border-top: 1px solid #999;
    padding-top: 20px;
    box-sizing: border-box;

    .el-button {
      // font-size:14px;
      // border:none;
      // background-color:#F7F8FA;
    }
  }

  .underLine {
    cursor: pointer;
    color: #599af8;
    text-decoration: underline;

    .underIcon {
      background-color: rgb(137, 234, 137);
      color: #fff;
      border-radius: 50%;
      margin-right: 5px;
    }

    .underIconA {
      background-color: rgb(238, 99, 99);
      color: #fff;
      border-radius: 50%;
      margin-right: 5px;
    }
  }

  .common_select {
    width: 80px;
  }
}
</style>
