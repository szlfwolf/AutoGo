<template>
  <div class="content">
    <el-card class="box-card" v-loading="responseLoading">
      <div class="box-top">
        <div>
          <label>Order no: </label>
          <span>{{ tableData.orderNo }}</span>
        </div>
        <div>
          <label>Support Multiple Response: </label>
          <span>{{ tableData.supportMultipleResponse }}</span>
        </div>
        <div>
          <label>Mapped ASN: </label>
          <span>{{ tableData.mappedAsn }}</span>
        </div>
      </div>
      <div class="box-qty">
        <div>
          <div class="box-content">
            <label>{{ getFData(tableData.planQty) }}</label>
            <span>Plan Qty</span>
          </div>
        </div>
        <div>
          <div class="box-content">
            <label>{{ getFData(tableData.mappedQty) }}</label>
            <span>Mapped Qty</span>
          </div>
        </div>
        <div>
          <div class="box-content">
            <label>{{ getFData(tableData.responseQty) }}</label>
            <span>Responsed Qty</span>
          </div>
        </div>
        <div>
          <div class="box-content">
            <label style="color:#FF2525">{{ getFData(tableData.needResponseQty) }}</label>
            <span style="color:#FF2525">Need Responsed Qty</span>
          </div>
        </div>
      </div>
      <el-table border ref="multipleTable" :data="tableData.lineList" tooltip-effect="dark" style="width: 100%"
        v-loading="dataListLoading" :header-cell-style="{ background: '#f5f7fa', color: '#606266' }">
        <el-table-column label="Line no" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.lineNo || '-' }}</template>
        </el-table-column>
        <el-table-column label="Sku no" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.skuNo || '-' }}</template>
        </el-table-column>
        <el-table-column label="Plan Qty" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.planQty || '0' }}</template>
        </el-table-column>
        <el-table-column label="Mapped Qty" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.mappedQty || '0' }}</template>
        </el-table-column>
        <el-table-column label="Responded Qty" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.respondedQty || '0' }}</template>
        </el-table-column>
        <el-table-column label="Need Response Qty" align="center" show-overflow-tooltip>
          <template slot-scope="scope"><span style="color:#FF2525">{{ scope.row.needResponseQty || '0'
          }}</span></template>
        </el-table-column>
        <el-table-column label="Todo Qty" align="center" show-overflow-tooltip>
          <template slot-scope="scope"
            :style="{ 'color': (scope.row.planQty - scope.row.respondedQty - scope.row.needResponseQty) > 0 ? '#CBAFB4' : '' }">{{
              scope.row.planQty - scope.row.respondedQty - scope.row.needResponseQty || '0' }}</template>
        </el-table-column>
      </el-table>
      <div style="margin-top: 50px; display: flex; justify-content: center">
        <el-button style="margin-right: 30px" @click="cancel">取消</el-button>
        <el-button type="primary" @click="response" v-if="permissions.inbound_inorder_responseSubmit">回传</el-button>
      </div>
    </el-card>
  </div>
</template>
<script>
import { mapGetters } from "vuex";
import { getInOrderResponseSubmit } from "@/api/inbound/asnOrder"
import { getStore } from "@/util/store"
export default {
  name: "Response",
  data() {
    return {
      tableData: {},
      dataListLoading: false,
      responseLoading: false
    };
  },
  computed: {
    ...mapGetters(["permissions", "tagList"]),
  },
  components: {
  },
  created() {
    this.tableData = getStore({ name: 'responseData' })
  },
  methods: {
    //转换数字格式
    getFData(source, length = 3) {
      source = String(source).split(".");
      source[0] = source[0].replace(
        new RegExp("(\\d)(?=(\\d{" + length + "})+$)", "ig"),
        "$1,"
      );
      return source.join(".");
    },
    findTag(value) {
      let tag, key;
      this.tagList.map((item, index) => {
        if (item.value === value) {
          tag = item;
          key = index;
        }
      });
      return { tag: tag, key: key };
    },
    //取消
    cancel() {
      let { tag, key } = this.findTag(this.$route.path);
      this.$store.commit('DEL_TAG', tag)
      this.$router.go(-1)
    },
    //回传
    response() {
      this.$confirm('Whether to confirm the Response. Do you want to continue?', 'Tips', {
        confirmButtonText: 'submit',
        cancelButtonText: 'cancel',
        type: 'warning'
      }).then(() => {
        this.responseLoading = true
        getInOrderResponseSubmit({ orderNo: this.tableData.orderNo }).then(res => {
          console.log(res);
          this.responseLoading = false
          if (res.data.code === 0) {
            let { tag, key } = this.findTag(this.$route.path);
            this.$store.commit('DEL_TAG', tag)
            this.$router.go(-1)
            this.$message.success('Responsed succeeded')
          } else {
            this.$message.error(res.data.msg)
          }
        }).catch(() => {
          this.responseLoading = false
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: 'Destruction'
        });
      });
    },
  },
};
</script>
<style lang="scss" scoped>
.content {
  padding: 0 10px;

  // box-sizing: border-box;
  .text {
    font-size: 14px;
  }

  .item {
    padding: 18px 0;
  }

  .box-card {
    width: 100%;
    padding-top: 20px;

    .box-top {
      width: 100%;
      height: 40px;
      line-height: 40px;
      background-color: #c9e8f9;
      display: flex;
      justify-content: space-around;
      font-weight: 700;
      margin-bottom: 50px;
    }

    .box-qty {
      width: 50%;
      margin: 0 auto;
      display: flex;
      justify-content: space-between;
      margin-bottom: 50px;
    }

    .box-content {
      display: flex;
      flex-direction: column;
      text-align: center;

      label {
        font-size: 32px;
        color: #000;
      }

      span {
        font-size: 10px;
        color: #666;
        margin-top: 10px;
        font-weight: 600;
      }
    }
  }
}</style>
