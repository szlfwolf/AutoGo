<template>
  <div class="content">
    <el-card class="box-card" v-loading="completeLoading">
      <div style="display: flex; flex-direction: column; align-items: center">
        <i class="el-icon-success" style="color: #34c627; font-size: 72px"></i>
        <div style="font-size: 36px; font-weight: 700">Mapping Success</div>
      </div>
      <el-form label-width="160px" style="margin: 20px 0 0 200px">
        <el-form-item label="Order no:" style="cursor:pointer;color:#599af8;font-size:18px;text-decoration: underline;">
          <span @click="handleDetail">{{ formParams.mappedOrderNo }}</span>
        </el-form-item>
        <el-form-item label="Total PCS:">{{ formParams.totalPCS }}</el-form-item>
        <el-form-item label="Mapping Success PCS:">{{ formParams.successPCS }}</el-form-item>
        <el-form-item label="Total Mapped PCS:">{{ formParams.totalMappedPCS }}</el-form-item>
      </el-form>
      <div style="width: 100%; text-align: center" v-if="formParams.isResponse === 'Y'">
        * Check the order has been
        <span style="color: #34c627">completed</span>, go to
        <span style="cursor: pointer;color: #599af8;font-size: 18px;text-decoration: underline;"
          @click="response">Response</span>
      </div>
      <div style="margin-top: 50px; display: flex; justify-content: center">
        <el-button type="primary" @click="pre">Continue to Mapping</el-button>
        <el-button @click="close">View ASN Detail</el-button>
      </div>
    </el-card>
  </div>
</template>
<script>
import { mapGetters } from "vuex";
import { setStore, getStore } from "@/util/store";
import { getInOrderResponseSubmit, getInOrderResponsePreview } from "@/api/inbound/asnOrder"
export default {
  name: "Complete",
  data() {
    return {
      formParams: {},
      completeLoading: false
    };
  },
  props: {
    asnNo: {
      type: String
    },
  },
  computed: {
    ...mapGetters(["permissions", "tagList"]),
  },
  created() {
    this.formParams = getStore({ name: "mappingComplete" });
    this.eventBus.$on("mappingComplete", (e) => {
      console.log(e, "44444");
    });
  },
  methods: {
    pre() {
      this.$emit("pre", "refresh");
    },
    close() {
      let { tag, key } = this.findTag(this.$route.path);
      this.$store.commit("DEL_TAG", tag);
      // this.$router.go(-1)
      this.$router.push({
        path: `/asnDetail`,
        query: {
          name: this.asnNo,
        },
      })
    },
    findTag(value) {
      let tag, key;
      this.tagList.map((item, index) => {
        if (item.value === value) {
          tag = item;
          key = index;
        }
      });
      return { tag: tag, key: key };
    },
    // //回传
    // response() {
    //   this.$confirm('Whether to confirm the Response. Do you want to continue?', 'Tips', {
    //     confirmButtonText: 'submit',
    //     cancelButtonText: 'cancel',
    //     type: 'warning'
    //   }).then(() => {
    //     this.completeLoading = true
    //     getInOrderResponseSubmit({ orderNo: this.formParams.mappedOrderNo }).then(res=>{
    //       console.log(res);
    //       this.completeLoading = false
    //       if(res.data.code === 0){
    //         let { tag, key } = this.findTag(this.$route.path);
    //         this.$store.commit('DEL_TAG',tag)
    //         this.$router.go(-1)
    //         this.$message.success('Responsed succeeded')
    //       }else{
    //         this.$message.error(res.data.msg)
    //       }
    //     }).catch(()=>{
    //       this.completeLoading = false
    //     })
    //   }).catch(() => {
    //     this.$message({
    //       type: 'info',
    //       message: 'Destruction'
    //     });          
    //   });
    // },
    //回传
    response() {
      getInOrderResponsePreview({ orderNo: this.formParams.mappedOrderNo }).then((res) => {
        console.log(res);
        if (res.data.code === 0) {
          this.$router.push({
            path: "/response",
          });
          setStore({ name: "responseData", content: res.data.data });
        } else {
          this.$message.error(res.data.msg);
        }
      }
      );
    },
    //asnOrder详情
    handleDetail() {
      let { tag, key } = this.findTag(this.$route.path);
      this.$store.commit("DEL_TAG", tag);
      this.$router.push({
        path: `/asnOrderDetail`,
        query: {
          name: this.formParams.mappedOrderNo,
        },
      });
    },
  },
};
</script>
<style lang="scss" scoped>
.content {
  padding: 0 10px;

  // box-sizing: border-box;
  .text {
    font-size: 14px;
  }

  .item {
    padding: 18px 0;
  }

  .box-card {
    width: 100%;
  }

  .copy {
    cursor: pointer;
  }
}</style>
