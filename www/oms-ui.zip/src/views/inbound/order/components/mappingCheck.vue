<template>
  <div class="content">
    <el-card class="box-card" v-loading="submitLoading">
      <el-form
        :model="mappingForm"
        ref="mappingForm"
        :rules="mapRules"
        label-width="100px"
      >
        <el-table
          border
          ref="multipleTable"
          :data="mappingForm.tableData"
          tooltip-effect="dark"
          style="width: 100%"
          :header-cell-style="{ background: '#f5f7fa', color: '#606266' }"
        >
         <!-- v-loading="dataListLoading" -->
          <el-table-column label="Line no" align="center"  show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.lineNo }}</template>
          </el-table-column>
          <el-table-column label="Sku no" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.partNumber }}</template>
          </el-table-column>
          <el-table-column label="Actual Qty" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.actualQty}}</template>
          </el-table-column>
          <el-table-column label="Mapped Qty" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.mappedQty }}</template>
          </el-table-column> 
          <el-table-column label="Non Mapped Qty" min-width="120" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.nonMappedQty }}</template>
          </el-table-column>
          <el-table-column label="Mapping Order Qty" align="center" min-width="120">
            <template slot-scope="scope" prop="mappingOrderQty">
              <el-form-item
                :prop="'tableData.' + scope.$index + '.mappingOrderQty'"
                :rules="formQtyFn(scope.row)"
                style="margin-bottom: 0; margin-left: -100px"
              >
                <el-input v-model="scope.row.mappingOrderQty"></el-input>
              </el-form-item>
            </template>
          </el-table-column>
          <!-- <el-table-column label="Mapping Order Qty" min-width="120" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.mappingOrderQty || 0  }}</template>
          </el-table-column> -->
          <el-table-column label="Todo Qty" align="center" show-overflow-tooltip>
            <template slot-scope="scope" :style="{'color': scope.row.actualQty-scope.row.mappedQty-scope.row.mappingOrderQty ? '#CBAFB4' : '' }">
              {{ scope.row.actualQty-scope.row.mappedQty-scope.row.mappingOrderQty }}</template>
          </el-table-column>
        </el-table>
      </el-form>
      <div style="margin-top: 50px; display: flex; justify-content: center">
        <el-button type="primary" style="margin-right: 30px" @click="pre">上一步</el-button>
        <el-button type="primary" @click="submit" v-if="permissions.inbound_asn_mappingSubmit">提交</el-button>
      </div>
    </el-card>
  </div>
</template>
<script>
import { mapGetters } from "vuex";
import { getMappingOrderPreview, getMappingOrderSubmit } from "@/api/inbound/asn"
import { setStore } from "@/util/store"
export default {
  name: "MappingCheck",
  data() {
    return {
      dataListLoading:false,
      submitLoading:false,
      mapRules:{
        // mappingOrderQty:[
        //   // { required: true, message: "此区域为必填项", trigger: "blur" },
        //   { pattern: /^[0-9]*$/, message: '请输入纯数字', trigger: 'blur' },
        //   { validator: (rule, value, callback) => {
        //     if(value > this.mappingRow.nonMappedQty){
        //       callback(new Error("mappingOrderQty 不能大于 nonMappedQty"));
        //     }else{
        //       callback()
        //     }
        //   },
        //     trigger:'blur'
        //   }
        // ],
      },
      mappingForm:{
        tableData:[]
      },
      mappingRow:{}
    };
  },
  props:{
    orderNo:{
      type:String
    },
    asnNo:{
      type:String
    },
    tableObj:{
      type: Object
    },
    mapParams:{
      type: Object
    }
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  created(){
    this.mappingForm.tableData = this.tableObj.data.data
  },
  methods: {
    //上一步
    pre() {
      this.$emit("pre");
    },
    formQtyFn(row) {
      if (row.nonMappedQty < row.mappingOrderQty) {
        return {
          validator: (rule, value, callback) => {
            callback(new Error());
          },
          trigger: "blur",
        };
      }
      return [
        // { required: false, trigger: "blur" },
      { pattern:/^([0-9]{1}\d*)$/, trigger: 'blur' },];
    },
    //提交
    submit() {
      this.submitLoading = true
      console.log(this.orderNo,this.asnNo,this.mappingForm.tableData);
      this.$refs.mappingForm.validate((valid) => {
        if (!valid) return false;
        getMappingOrderSubmit({orderNo:this.orderNo,asnNo:this.asnNo,asnLineList:this.mappingForm.tableData}).then(res=>{
          console.log(res);
          if(res.data.code === 0){
            this.submitLoading = false
            this.eventBus.$emit('mappingComplete',res)
            setStore({name:"mappingComplete",content:Object.assign(res.data.data,
            {mappedQty:Number(this.mapParams.mappedQty) + Number(res.data.data.successPCS),planQty:this.mapParams.planQty,actualQty:this.mapParams.actualQty})})
            this.$emit("next",res.data.data);
          }else{
            this.$message.error(res.data.msg)
            this.submitLoading = false
          }
        }).catch(()=>{
          this.submitLoading = false
        })
      })
    },
  },
};
</script>
<style lang="scss" scoped>
.content {
  padding: 0 10px;
  // box-sizing: border-box;
  .text {
    font-size: 14px;
  }

  .item {
    padding: 18px 0;
  }
  .box-card {
    width: 100%;
  }
}
</style>
