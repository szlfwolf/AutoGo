<template>
  <basic-container>
    <div class="avue-crud content">
      <div v-loading="orderDetailLoading">
        <div>
          <div class="title">
            <span></span>
            <label>Order Info</label>
          </div>
          <div class="contain containRow">
            <el-row>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>Owner:</label>
                <span>{{ rowParams.clientCode }}</span>
              </el-col>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>order no:</label>
                <span ref="copy">{{ rowParams.orderNo }}
                  <i class="el-icon-document-copy copy" @click="clickCopy"></i>
                </span>
              </el-col>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>Job no:</label>
                <span>{{ rowParams.blNo }}</span>
              </el-col>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>BL no:</label>
                <span>{{ rowParams.billLandNum }}</span>
              </el-col>
            </el-row>
            <el-row>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>Warehouse:</label>
                <span>{{ rowParams.warehouseCode }}</span>
              </el-col>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>Order Type:</label>
                <span>{{ rowParams.orderType }}</span>
              </el-col>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>ETA:</label>
                <span>{{ rowParams.etaTime }}</span>
              </el-col>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>ATA:</label>
                <span>{{ rowParams.ataTime }}</span>
              </el-col>
            </el-row>
            <el-row>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>Supplier Code:</label>
                <span>{{ rowParams.supplierCode }}</span>
              </el-col>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>source:</label>
                <span>{{ rowParams.tag }}</span>
              </el-col>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>status:</label>
                <span>{{ rowParams.status }}</span>
              </el-col>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>originalOrderNo:</label>
                <span>{{ rowParams.originalOrderNo }}</span>
              </el-col>
            </el-row>
            <el-row>
              <el-col :xs="24" :sm="24" :md="24" :lg="12">
                <label>Asn no:</label>
                <span v-if="permissions.inbound_asn_getByAsnNo" class="cursorStyle">
                  <span v-if="rowParams.asnNo">
                    <span v-for="asnNo in rowParams.asnNo.split(';')">
                      <span @click="dnDetailClick(asnNo)" style="
                          cursor: pointer;
                          color: #599af8;
                          font-size: 14px;
                          text-decoration: underline;
                          margin-right: 5px;
                        ">{{ asnNo }}</span>
                    </span>
                  </span>
                </span>
                <span class="cursorStyle" v-else>
                  <span v-if="rowParams.asnNo">
                    <span v-for="asnNo in rowParams.asnNo.split(';')">
                      {{ asnNo }}
                    </span>
                  </span>
                </span>
                <span v-if="permissions.inbound_orderoperatelog_get" @click="dialogTrue" style="
                    cursor: pointer;
                    color: #599af8;
                    font-size: 14px;
                    text-decoration: underline;
                  ">View Mapping logs</span>
              </el-col>
              <el-col :xs="24" :sm="24" :md="24" :lg="12">
                <label>Pallet no:</label>
                <span>{{ rowParams.palletNo }}</span>
              </el-col>
            </el-row>
          </div>
        </div>
        <div>
          <div class="title">
            <span></span>
            <label>Track</label>
          </div>
          <div class="contain containRow">
            <el-row>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>Create Time:</label>
                <span>{{ rowParams.createTime }}</span>
              </el-col>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>Arrived Time:</label>
                <span>{{ rowParams.arrivalTime }}</span>
              </el-col>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>Customs Time:</label>
                <span>{{ rowParams.customsTime }}</span>
              </el-col>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>Release Time:</label>
                <span>{{ rowParams.releaseTime }}</span>
              </el-col>
            </el-row>
            <el-row>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>Receipt Time:</label>
                <span>{{ rowParams.receivingTime }}</span>
              </el-col>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>Mapping Time:</label>
                <span>{{ rowParams.mappingTime }}</span>
              </el-col>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>Response Time:</label>
                <span>{{ rowParams.responseTime }}</span>
              </el-col>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>Close Time:</label>
                <span>{{ rowParams.closedTime }}</span>
              </el-col>
            </el-row>
            <el-row>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>Cancel Time:</label>
                <span>{{ rowParams.cancelTime }}</span>
              </el-col>
            </el-row>
          </div>
        </div>
      </div>
      <div class="containBox">
        <div class="title">
          <span></span>
          <label>Order Line</label>
        </div>
        <div class="contain">
          <el-row style="width: 200px; display: flex">
            <el-col>
              <el-button type="primary" icon="el-icon-search" @click="getSearchlist">Query</el-button>
            </el-col>
            <el-col>
              <el-button icon="el-icon-refresh-left" @click="getReset">Reset</el-button>
            </el-col>
          </el-row>
          <el-row>
            <el-form ref="form" :model="form" @keyup.enter.native="getSearchlist" style="margin: 20px 0">
              <el-row :gutter="20">
                <el-col :span="4">
                  <el-input v-model="form.partNumber" placeholder="Sku no"></el-input>
                </el-col>
                <el-col :span="4">
                  <el-select v-model="form.difference" placeholder="Has Difference" filterable>
                    <el-option v-for="item in differenceList" :key="item.value" :label="item.label" :value="item.value">
                    </el-option>
                  </el-select>
                </el-col>
                <div class="totalType">
                  <el-col :span="5">
                    <label>Total Plan:</label>
                    <span v-if="tableData.length">{{
                      getFData(rowParams.totalPlan)
                    }}</span>
                    <span v-else>0</span>
                  </el-col>
                  <el-col :span="5">
                    <label>Total Mapped:</label>
                    <span v-if="tableData.length">{{
                      getFData(rowParams.totalMapped)
                    }}</span>
                    <span v-else>0</span>
                  </el-col>
                  <el-col :span="5">
                    <label>Total Responded:</label>
                    <span v-if="tableData.length">{{
                      getFData(rowParams.totalResponded)
                    }}</span>
                    <span v-else>0</span>
                  </el-col>
                </div>
              </el-row>
            </el-form>
          </el-row>
        </div>
      </div>
      <div class="down">
        <div>
          <el-button type="primary" v-if="permissions.inbound_inorder_responsePreview" @click="operaterType('Response')"
            style="padding: 9px 15px">
            <span style="display: flex; align-items: center">
              <i class="iconfont icon-fenxiang_f" style="margin-right: 5px; font-size: 12px"></i>Response
            </span>
          </el-button>
          <el-button type="primary" @click="operaterType('showClosedComfired')" style="padding: 9px 15px">
            <span style="display: flex; align-items: center">
              <i class="iconfont icon-daka-copy" style="margin-right: 5px; font-size: 12px"></i>Close
            </span>
          </el-button>
        </div>
        <el-button class="el-icon-download" style="font-size: 10px" v-if="permissions.inbound_inorderline_export"
          @click="exportExcel"></el-button>
      </div>
      <el-table border ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%"
        v-loading="dataListLoading" :header-cell-style="{
          background: '#f5f7fa',
          color: '#606266',
          'text-align': 'center',
        }">
        <el-table-column label="Line no" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.lineNo || "-" }}</template>
        </el-table-column>
        <el-table-column label="Sku no" min-width="140" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{
            scope.row.partNumber || "-"
          }}</template>
        </el-table-column>
        <el-table-column label="Plan Qty" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.planQty || "0" }}</template>
        </el-table-column>
        <el-table-column label="Mapped Qty" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{
            scope.row.mappedQty || "0"
          }}</template>
        </el-table-column>
        <el-table-column label="Responded Qty" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{
            scope.row.respondedQty || "0"
          }}</template>
        </el-table-column>
        <el-table-column label="Todo Qty" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{
            scope.row.planQty - scope.row.respondedQty || "0"
          }}</template>
        </el-table-column>
        <el-table-column label="Unit" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.unit || "-" }}</template>
        </el-table-column>
        <el-table-column label="Vin" min-width="140" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.vin || '-' }}</template>
        </el-table-column>
        <el-table-column label="Reason" min-width="140" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.reason || '-' }}</template>
        </el-table-column>
        <el-table-column label="Asn no" min-width="140" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.asnNo || "-" }}</template>
        </el-table-column>
      </el-table>
      <Pagination @handleSizeChange="handleSizeChange" @handleCurrentChange="handleCurrentChange" :pageNum="page.current"
        :pageSize="page.size" :total="total"></Pagination>
      <el-dialog title="PFEP LOG" :visible.sync="centerDialogVisible" width="30%" style="font-weight: 700">
        <el-timeline class="timeline">
          <el-timeline-item v-for="(activity, index) in activities" :key="index" :icon="activity.icon"
            :type="activity.type" :color="activity.color" size="large">
            <div class="box">
              <div class="boxTop">
                {{ activity.clientCode }}
                <span>{{ activity.createTime }}</span>
              </div>
              <div class="boxBottom">{{ activity.operateContent }}</div>
            </div>
          </el-timeline-item>
        </el-timeline>
      </el-dialog>

      <el-dialog title="Close confirm" :visible.sync="closedDialogVisible" width="80%" style="font-weight: 700">
        <el-table border ref="multipleTable" :data="closedTableData" tooltip-effect="dark" style="width: 100%"
          v-loading="dataListLoading" :header-cell-style="{
            background: '#f5f7fa',
            color: '#606266',
            'text-align': 'center',
          }">
          <el-table-column label="Line no" min-width="120" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.lineNo || "-" }}</template>
          </el-table-column>
          <el-table-column label="Sku no" min-width="140" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{
              scope.row.partNumber || "-"
            }}</template>
          </el-table-column>
          <el-table-column label="Plan Qty" min-width="120" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.planQty || "0" }}</template>
          </el-table-column>
          <el-table-column label="Mapped Qty" min-width="120" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{
              scope.row.mappedQty || "0"
            }}</template>
          </el-table-column>
          <el-table-column label="Responded Qty" min-width="120" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{
              scope.row.respondedQty || "0"
            }}</template>
          </el-table-column>
          <el-table-column label="Todo Qty" min-width="120" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{
              scope.row.planQty - scope.row.respondedQty || "0"
            }}</template>
          </el-table-column>
          <el-table-column label="Unit" min-width="120" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.unit || "-" }}</template>
          </el-table-column>
          <el-table-column label="Reason" min-width="140" align="center" show-overflow-tooltip>
            <template slot-scope="scope">
              <el-input v-model="scope.row.reason"
                :disabled="!(permissions.inbound_inorder_closedOrder && rowParams.status != 'CLOSED')"></el-input>
            </template>
          </el-table-column>
        </el-table>



        <div style="margin-top: 50px; display: flex; justify-content: center"
          v-if="permissions.inbound_inorder_closedOrder && rowParams.status != 'CLOSED'">
          <el-button type="primary" style="margin-right: 30px" class="el-icon-back"
            @click="closedDialogVisibleBtn">&nbsp;取&nbsp;消&nbsp;</el-button>
          <el-button type="primary" @click="operaterType('closed')"
            class="el-icon-switch-button">&nbsp;关&nbsp;闭&nbsp;</el-button>
        </div>
      </el-dialog>
    </div>
  </basic-container>
</template>
<script>
import { mapGetters } from "vuex"
import Pagination from "@/components/pagination/pagination.vue"
import { getByOrderNo, getInOrderLine, getInOrderResponsePreview, getClosedOrder, getOrderDetail } from "@/api/inbound/asnOrder"
import { getAsnDetails } from "@/api/inbound/asn"
import { setStore } from "@/util/store"
let formParams = {
  partNumber: undefined,
  difference: undefined,
}
export default {
  name: "OrderDetail",
  data() {
    return {
      rowParams: {},
      form: Object.assign({}, formParams),
      page: {
        size: 10,
        current: 1,
      },
      centerDialogVisible: false,
      closedDialogVisible: false,
      dataListLoading: false,
      total: 0,
      tableData: [],
      closedTableData: [],
      activities: [],
      differenceList: [
        {
          value: 1,
          label: 'Y'
        }, {
          value: 0,
          label: 'N'
        }
      ],
      orderNo: "",
      orderDetailLoading: false
    }
  },
  computed: {
    ...mapGetters(["permissions", "tagList"]),
  },
  components: {
    Pagination,
  },
  watch: {
    // 利用watch方法检测路由变化：
    $route: function (to, from) {
      // if (to.fullPath !== from.fullPath) {
      if (to.path == '/asnOrderDetail/index' && to.query.name) {
        if (to.query.name != from.query.name) {
          this.orderNo = to.query.name
          this.getList()
          this.getDetail()
        }
      }
      // }
    }
  },
  async created() {
    this.orderNo = this.$route.query.name
    await this.getList()
    await this.getDetail()
  },
  mounted() {
    this.exportExcel = this.$btn(this.exportExcel, 500)
    this.clickCopy = this.$btn(this.clickCopy, 500)
    this.operaterType = this.$btn(this.operaterType, 500)
  },
  methods: {
    //转换数字格式
    getFData(source, length = 3) {
      source = String(source).split('.')
      source[0] = source[0].replace(new RegExp('(\\d)(?=(\\d{' + length + '})+$)', 'ig'), '$1,')
      return source.join('.')
    },
    //复制
    clickCopy() {
      let content = this.rowParams.orderNo
      if (this.copy(content) === '文本为空') {
        this.$message.warning("Text is empty and cannot be copied !!!")
        return
      }
      this.$message.success("copy success")
    },
    //导出
    exportExcel() {
      this.downBlobFile("/inbound/inOrderLine/export", { ...this.form, orderNo: this.orderNo }, `${this.$store.state.common.commandName}-AsnOrderLine-${this.toDateFormat(new Date(), true)}.xlsx`)
    },
    //条数
    handleSizeChange(val) {
      this.page.current = 1
      this.page.size = val
      this.getList(this.form)
    },
    //当前页数
    handleCurrentChange(val) {
      this.page.current = val
      this.getList(this.form)
    },
    //清空
    getReset() {
      this.form = Object.assign({}, formParams)
      this.page = this.$options.data().page
      this.getSearchlist()
    },
    //查询
    getSearchlist() {
      this.page.current = 1
      for (let key in this.form) {
        if (this.form[key] === '' || this.form[key] === null) {
          this.form[key] = undefined
        }
      }
      this.getList(this.form)
    },
    //数据列表
    getList(params) {
      this.dataListLoading = true
      getInOrderLine(Object.assign({ ...this.page }, params, { orderNo: this.orderNo })).then(res => {
        console.log(res)
        if (res.data.code === 0) {
          this.tableData = res.data.data.records
          this.total = res.data.data.total
          this.dataListLoading = false
        } else {
          this.$message.error(res.data.msg)
          this.dataListLoading = false
        }
      }).catch(() => {
        this.dataListLoading = false
      })
    },

    // 弹窗取消的清单 closedTableData
    getHasDiffList() {
      getInOrderLine({
        orderNo: this.orderNo, size: 10000,
        current: 1, hasClosed: 'Y'
      }).then(res => {
        if (res.data.code === 0) {
          if (res.data.data.total > 0) {
            this.closedDialogVisible = true;
            this.closedTableData = res.data.data.records
          }
        } else {
          this.$message.error(res.data.msg)
        }
      }).catch(() => {
      })
    },

    getDetail() {
      this.orderDetailLoading = true
      getOrderDetail({ orderNo: this.orderNo }).then(res => {
        console.log(res)
        if (res.data.code === 0) {
          this.orderDetailLoading = false
          this.rowParams = res.data.data
        } else {
          this.orderDetailLoading = false
          this.$message.error(res.data.msg)
        }
      }).catch(() => {
        this.orderDetailLoading = false
      })
    },
    //打开订单追踪弹窗
    dialogTrue() {
      getByOrderNo({ orderNo: this.orderNo }).then(res => {
        console.log(res)
        if (res.data.data.code === 0) {
          if (res.data.data.data.length) {
            this.centerDialogVisible = true
            this.activities = res.data.data.data
          } else {
            this.$message.warning('Not found temporarily ' + `${this.orderNo}` + ' PFEP allocation details of the order!')
          }
        } else {
          this.$message.error(res.data.data.msg)
        }
      }).catch(() => {
        this.$message.error(res.data.data.msg)
      })
    },
    //操作
    operaterType(type) {
      if (type === 'Response') {
        getInOrderResponsePreview({ orderNo: this.orderNo }).then(res => {
          console.log(res);
          if (res.data.code === 0) {
            this.$router.push({
              path: "/response",
            })
            setStore({ name: 'responseData', content: res.data.data })
          }
        })
      } else if (type === 'showClosedComfired') {

        this.getHasDiffList();
      }
      else if (type === 'closed') {
        getClosedOrder({ orderNo: this.orderNo, inOrderLines: this.closedTableData }).then(res => {
          console.log(res);
          if (res.data.code === 0) {
            this.getDetail()
            this.$message.success('Closed succeeded')
            this.eventBus.$emit('asnOrderDetailStatus')

            this.closedDialogVisible = false;
          } else {
            this.$message.error(res.data.msg)
          }
        })
      }
    },
    //dn详情页
    dnDetailClick(val) {
      getAsnDetails({ asnNo: val }).then(res => {
        console.log(res)
        if (res.data.code === 0) {
          if (res.data.data) {
            let asnDetail = res.data.data
            this.$router.push({
              path: `/asnDetail`,
              query: {
                name: val,
                row: JSON.stringify(asnDetail),
              },
            })
          } else {
            this.$message.warning('No data for details')
          }
        } else {
          this.$message.warning(res.data.msg)
        }
      })
    },

    //关闭closed 窗口
    closedDialogVisibleBtn() {
      this.closedDialogVisible = false;
    }
  },
}
</script>
<style lang="scss" scoped>
.content {
  width: 100%;
  //   padding: 20px;
  font-size: 13px;
  box-sizing: border-box;

  .title {
    width: 100%;
    height: 30px;
    line-height: 30px;
    display: flex;
    margin-bottom: 10px;

    span {
      width: 3px;
      height: 30px;
      background-color: #000;
      margin-right: 10px;
    }

    label {
      font-weight: 700;
    }
  }

  .containBox {
    border-bottom: 1px solid #999;
    margin-bottom: 20px;
  }

  // .containRow{
  //   .el-col{
  //     height: 25px;
  //     line-height: 25px;
  //   }
  // }
  .contain {
    padding: 10px;
    box-sizing: border-box;

    .cursorStyle {
      margin-right: 10px;
    }

    label {
      display: inline-block;
      margin-right: 5px;
      width: 100px;
      text-align: right;
      vertical-align: middle;
    }

    span {
      color: #999;
      vertical-align: middle;
    }

    .totalType {
      text-align: right;
      height: 25px;
      line-height: 25px;

      span {
        font-size: 18px;
        font-weight: 600;
        color: #000;
      }
    }
  }

  .down {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    box-sizing: border-box;
  }

  .timeline {
    padding: 10px;

    .box {
      background-color: #f4f6f7;
      border-radius: 5px;
      padding: 10px 20px;
      box-sizing: border-box;

      .boxTop {
        font-weight: 700;
        margin-bottom: 10px;

        span {
          margin-left: 10px;
        }
      }

      .boxBottom {
        color: #666;
        font-weight: normal;
      }
    }
  }

  .copy {
    cursor: pointer;
  }

  .underLine {
    cursor: pointer;
    color: #599af8;
    text-decoration: underline;

    .underIcon {
      background-color: rgb(137, 234, 137);
      color: #fff;
      border-radius: 50%;
      margin-right: 5px;
    }

    .underIconA {
      background-color: rgb(238, 99, 99);
      color: #fff;
      border-radius: 50%;
      margin-right: 5px;
    }
  }

  ::v-deep .el-dialog {
    border-radius: 8px !important;
  }
}
</style>
