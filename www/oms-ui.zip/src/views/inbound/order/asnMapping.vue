<template>
  <div class="content">
    <el-card class="box-card" v-loading="mappingLoading">
      <div class="box-top">
        <div>
          <label>Asn no: </label>
          <span v-if="asnNo">{{ asnNo }}</span>
          <span v-else></span>
        </div>
        <div>
          <!-- <label>Support Multiple Response: </label>
          <span>{{ mapParams.isResponse ? (mapParams.isResponse === "Y" ? 'Y' : 'N') : "N" }}</span> -->
        </div>
        <div>
          <label>Mapped Order: </label>
          <span>{{ mapParams.mappedOrderNo }}</span>
        </div>
      </div>
      <div class="box-qty">
        <div>
          <div class="box-content">
            <label v-if="mapParams.planQty">{{ getFData(mapParams.planQty) }}</label>
            <label v-else>{{ 0 }}</label>
            <span>Plan Qty</span>
          </div>
        </div>
        <div>
          <div class="box-content">
            <label v-if="mapParams.actualQty">{{ getFData(mapParams.actualQty) || 0 }}</label>
            <label v-else>{{ 0 }}</label>
            <span>Actual Qty</span>
          </div>
        </div>
        <div>
          <div class="box-content">
            <label v-if="mapParams.mappedQty">{{ getFData(mapParams.mappedQty) || 0 }}</label>
            <label v-else>{{ 0 }}</label>
            <span>Mapped Qty</span>
          </div>
        </div>
      </div>
      <el-steps :active="active" finish-status="success" align-center>
        <el-step title="Choose Order"> </el-step>
        <el-step title="Mapped Qty"> </el-step>
        <el-step title="Responsed Qty"> </el-step>
      </el-steps>
      <div>
        <div v-show="active === 0" style="width: 60%; margin: 50px auto">
          <el-form ref="form" :model="form" :rules="rules" label-width="120px">
            <el-form-item label="Order:" prop="orderNo">
              <el-select v-model="form.orderNo" placeholder="Please select one ASN with completed receipt" filterable clearable>
                <el-option
                  v-for="item in mapParams.orderNoList"
                  :key="item"
                  :label="item"
                  :value="item"
                >
                </el-option>
              </el-select>
            </el-form-item>
          </el-form>
          <div style="margin-top: 50px; display: flex; justify-content: center">
            <el-button
              type="primary"
              @click="confirm"
              v-if="permissions.inbound_asn_createAsnOrder && shipType === 'Local' && clientCode === 'NIO'"
            >Create AsnOrder</el-button>
            <el-button
              type="primary"
              @click="next"
              v-if="permissions.inbound_asn_mappingPreview"
            >下一步</el-button>
          </div>
        </div>
        <div v-if="active === 1" style="width: 100%; margin: 50px auto">
          <MappingCheck
            @pre="pre"
            @next="next"
            :orderNo="form.orderNo"
            :asnNo="asnNo"
            :tableObj="tableData"
            :mapParams="mapParams"
          ></MappingCheck>
        </div>
        <div v-if="active === 2" style="width: 60%; margin: 50px auto">
          <Complete @pre="pre" @next="next" :asnNo="asnNo"></Complete>
        </div>
      </div>
    </el-card>
  </div>
</template>
<script>
import { mapGetters } from "vuex";
import MappingCheck from "./components/mappingCheck.vue";
import Complete from "./components/complete.vue";
import { setStore, getStore } from "@/util/store";
import { getOrderNoByAsnNo, getMappingOrderPreview, createAsnOrder } from "@/api/inbound/asn";
import store from "@/store"
export default {
  name: "BlAdd",
  data() {
    return {
      active: 0,
      form: {
        orderNo: "",
      },
      rules: {
        orderNo: [
          {
            required: true,
            message: "请选择一个已完成收据的ASN",
            trigger: "change",
          },
        ],
      },
      mapParams: {},
      asnNo: getStore({ name: "mapParams" }).asnNo,
      shipType : getStore({ name: "mapParams" }).shipType,
      tableData: {},
      mappingLoading: false,
      clientCode:store.getters.commandName
    };
  },
  computed: {
    ...mapGetters(["permissions", "tagList"]),
  },
  components: {
    MappingCheck,
    Complete,
  },
  // watch:{
  //   $route:function(to, from) {
  //     console.log(to,44444444);
  //     if(to.path == '/asnMapping/index'){
  //       console.log('3333');
  //       if( this.asnNo !== getStore({ name: "mapParams" })){
  //         this.active = 0
  //         this.$refs.form.resetFields();
  //         this.asnNo = getStore({ name: "mapParams" })
  //         this.getOrderNoByAsnNo()
  //         console.log('1111');
  //       }
  //     }
  //   },
  // },
  activated() {
    if (this.$route.fullPath == "/asnMapping/index") {
      if (this.asnNo !== getStore({ name: "mapParams" }).asnNo) {
        this.active = 0;
        this.$refs.form.resetFields();
        this.asnNo = getStore({ name: "mapParams" }).asnNo;
        this.getOrderNoByAsnNoList();
      }
    }
  },
  created() {
    console.log(this.asnNo);
    this.asnNo = getStore({ name: "mapParams" }).asnNo;
    this.shipType = getStore({ name: "mapParams" }).shipType;
    this.getOrderNoByAsnNoList();
  },
  mounted() {
    this.next = this.$btn(this.next, 500);
  },
  methods: {
    //转换数字格式
    getFData(source, length = 3) {
      source = String(source).split(".");
      source[0] = source[0].replace(
        new RegExp("(\\d)(?=(\\d{" + length + "})+$)", "ig"),
        "$1,"
      );
      return source.join(".");
    },
    getOrderNoByAsnNoList() {
      this.mappingLoading = true;
      console.log(this.asnNo);
      getOrderNoByAsnNo({ asnNo: this.asnNo }).then((res) => {
        console.log(res);
        if (res.data.code === 0) {
          this.mappingLoading = false;
          this.mapParams = res.data.data;
          if (!this.mapParams.orderNoList.length) {
            this.getContinue();
          }
        } else {
          this.mappingLoading = false;
        }
      }).catch(() => {
        this.mappingLoading = false;
      });
    },
    next(e) {
      if (this.active === 0) {
        this.$refs.form.validate((valid) => {
          if (!valid) return false;
          this.mappingLoading = true
          getMappingOrderPreview({
            orderNo: this.form.orderNo,
            asnNo: this.asnNo,
          }).then((res) => {
            console.log(res);
            this.mappingLoading = false
            if (res.data.code === 0) {
              this.active++;
              this.tableData = res;
            }else{
              this.$message.error(res.data.msg)
            }
          });
        });
      } else {
        this.active++;
        if (e) {
          this.mapParams = Object.assign(this.mapParams, {
            planQty: e.planQty,
            actualQty: e.actualQty,
            mappedQty: e.mappedQty,
          });
        }
      }
    },
    pre(e) {
      if (this.active === 2) {
        this.active = 0;
        this.form = this.$options.data().form;
        this.$refs.form.resetFields();
        if (e) {
          this.getOrderNoByAsnNoList();
        }
      } else {
        this.active--;
      }
    },
    findTag(value) {
      let tag, key;
      this.tagList.map((item, index) => {
        if (item.value === value) {
          tag = item;
          key = index;
        }
      });
      return { tag: tag, key: key };
    },
    getContinue() {
      this.$confirm(
        "This operation is irreversible, confirm to continue this operation?",
        "Tips",
        {
          confirmButtonText: "Continue",
          cancelButtonText: "Back to ASN",
          type: "warning",
        }
      )
        .then(() => {})
        .catch(() => {
          let { tag, key } = this.findTag(this.$route.path);
          this.$store.commit("DEL_TAG", tag);
          this.$router.go(-1);
        });
    },
    //confirm
    confirm(){
      this.mappingLoading = true
      createAsnOrder({asnNo: this.asnNo}).then(res=>{
        if(res.data.code === 0){
          this.form.orderNo = res.data.data
          getMappingOrderPreview({
            asnNo: this.asnNo,
            orderNo: res.data.data
          }).then((res) => {
            console.log(res);
            if (res.data.code === 0) {
              this.active++;
              this.tableData = res;
               this.mappingLoading = false
            }else{
              this.$message.error(res.data.msg)
               this.mappingLoading = false
            }
          }).catch(()=>{
            this.mappingLoading = false
          })
        }else{
          this.mappingLoading = false
          this.$message.error(res.data.msg)
        }
      }).catch(()=>{
        this.mappingLoading = false
      })
    },
  },
};
</script>
<style lang="scss" scoped>
.content {
  padding: 0 10px;
  // box-sizing: border-box;
  .text {
    font-size: 14px;
  }

  .item {
    padding: 18px 0;
  }
  .box-card {
    width: 100%;
    padding-top: 20px;
    .box-top {
      width: 100%;
      height: 40px;
      line-height: 40px;
      background-color: #c9e8f9;
      display: flex;
      justify-content: space-around;
      font-weight: 700;
      margin-bottom: 50px;
    }
    .box-qty {
      width: 50%;
      margin: 0 auto;
      display: flex;
      justify-content: space-between;
      margin-bottom: 50px;
    }
    .box-content {
      display: flex;
      flex-direction: column;
      text-align: center;
      label {
        font-size: 32px;
        color: #000;
      }
      span {
        font-size: 10px;
        color: #666;
        margin-top: 10px;
        font-weight: 600;
      }
    }
  }
  ::v-deep .el-select--small {
    display: block;
  }
  ::v-deep .el-date-editor--daterange.el-input,
  ::v-deep .el-date-editor--daterange.el-input__inner,
  ::v-deep .el-date-editor--timerange.el-input,
  ::v-deep .el-date-editor--timerange.el-input__inner {
    width: 100% !important;
  }
}
</style>
