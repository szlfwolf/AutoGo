<template>
  <basic-container>
    <div class="avue-crud content" v-loading="asnDetailLoading">
      <div v-loading="titleLoading">
        <div>
          <div class="title">
            <span></span>
            <label>ASN Info</label>
          </div>
          <div class="contain">
            <el-row>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>Owner:</label>
                <span>{{ rowParams.clientCode }}</span>
              </el-col>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>ASN no:</label>
                <span>{{ rowParams.asnNo }}
                  <i class="el-icon-document-copy copy" @click="clickCopy('asn_no')"></i></span>
              </el-col>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>Job no:</label>
                <span>{{ rowParams.blNo }}</span>
              </el-col>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>BL no:</label>
                <span>{{ rowParams.billLandNum }}</span>
              </el-col>
            </el-row>
            <el-row>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>Warehouse:</label>
                <span>{{ rowParams.warehouseCode }}</span>
              </el-col>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>Ship Type:</label>
                <span>{{ rowParams.shipType }}</span>
              </el-col>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>ASN Type:</label>
                <span>{{ rowParams.asnType }}</span>
              </el-col>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>ATA:</label>
                <span>{{ rowParams.ataTime }}</span>
              </el-col>
            </el-row>
            <el-row>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>Status:</label>
                <span>{{ rowParams.status }}</span>
              </el-col>
              <el-col :xs="24" :sm="12" :md="12" :lg="12">
                <label>Split ASN:</label>
                <span @click="asnDetail" v-if="permissions.inbound_asn_getByAsnNo" style="
                    cursor: pointer;
                    color: #599af8;
                    font-size: 14px;
                    text-decoration: underline;
                  ">{{ rowParams.splitAsn }}</span>
                <span v-else>{{ rowParams.splitAsn }}</span>
              </el-col>
              <el-col :xs="24" :sm="24" :md="24" :lg="24">
                <label>Source:</label>
                <span>{{ rowParams.tag }}</span>
              </el-col>
            </el-row>
            <el-row>
              <el-col :xs="24" :sm="24" :md="24" :lg="24">
                <label>Order no:</label>
                <span v-if="rowParams.orderNo">
                  <span v-if="permissions.inbound_inorder_getDetail">
                    <span v-for="orderNo in rowParams.orderNo.split(';')" :key="orderNo">
                      <span @click="clickOrderDetail(orderNo)" style="
                          cursor: pointer;
                          color: #599af8;
                          font-size: 14px;
                          text-decoration: underline;
                          margin-right: 10px;
                        ">{{ orderNo }};</span>
                    </span>
                  </span>
                  <span v-else>
                    <span v-for="orderNo in rowParams.orderNo.split(';')" :key="orderNo">
                      <span>{{ orderNo }};</span>
                    </span>
                  </span>
                </span>
                <span @click="dialogTrue" v-if="permissions.inboud_asnoperatelog_get" style="
                    cursor: pointer;
                    color: #599af8;
                    font-size: 14px;
                    text-decoration: underline;
                  ">View Mapping Logs</span>
              </el-col>
            </el-row>
            <el-row>
              <el-col :xs="24" :sm="24" :md="24" :lg="24">
                <label>Remark:</label>
                <span>{{ rowParams.remark }}</span>
              </el-col>
            </el-row>
          </div>
        </div>
        <div>
          <div class="title">
            <span></span>
            <label>Track</label>
          </div>
          <div class="contain">
            <el-row>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>Create Time:</label>
                <span>{{ rowParams.createTime }}</span>
              </el-col>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>Release Time:</label>
                <span>{{ rowParams.releaseTime }}</span>
              </el-col>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>Finish Time:</label>
                <span>{{ rowParams.finishedTime }}</span>
              </el-col>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>Closed Time:</label>
                <span>{{ rowParams.closedTime }}</span>
              </el-col>
            </el-row>
          </div>
        </div>
      </div>
      <div class="containBox">
        <div class="title">
          <span></span>
          <label>ASN Line</label>
        </div>
        <div class="contain">
          <el-row style="width: 200px; display: flex">
            <el-col>
              <el-button type="primary" icon="el-icon-search" @click="getSearchlist">Query</el-button>
            </el-col>
            <el-col>
              <el-button icon="el-icon-refresh-left" @click="getReset">Reset</el-button>
            </el-col>
          </el-row>
          <el-row>
            <el-form ref="form" :model="form" style="margin: 20px 0" @keyup.enter.native="getSearchlist">
              <el-row :gutter="20">
                <el-col :span="4">
                  <el-input v-model="form.partNumber" placeholder="Sku no"></el-input>
                </el-col>
                <el-col :span="4">
                  <el-input v-model="form.orderNo" placeholder="Mapped order no"></el-input>
                </el-col>
                <el-col :span="4">
                  <el-select filterable v-model="form.hasDifference" placeholder="Has difference" clearable>
                    <el-option v-for="item in differenceList" :key="item.value" :label="item.label" :value="item.value">
                    </el-option>
                  </el-select>
                </el-col>
                <el-col :span="4">
                  <el-select filterable v-model="form.hasNoMapped" placeholder="Has no mapped" clearable>
                    <el-option v-for="item in differenceList" :key="item.value" :label="item.label" :value="item.value">
                    </el-option>
                  </el-select>
                </el-col>
              </el-row>
            </el-form>
          </el-row>
        </div>
      </div>
      <div class="down">
        <div>
          <el-button type="primary" :disabled="rowParams.status !== 'FINISHED' && rowParams.status !== 'MAPPED'
            " v-if="permissions.inbound_asn_getOrderNo" @click="mapping" style="padding: 9px 15px">
            <span style="display: flex; align-items: center">
              <i class="iconfont icon-icon--" style="margin-right: 5px; font-size: 12px"></i>Mapping
            </span>
          </el-button>
          <el-button type="primary" :disabled="rowParams.status !== 'FINISHED' && rowParams.status !== 'MAPPED'
            " v-if="permissions.inbound_asn_cutoffPreview" @click="cutOrEdit('Cut off')" style="padding: 9px 15px">
            <span style="display: flex; align-items: center">
              <i class="iconfont icon-quxiaochaolianjie" style="margin-right: 5px; font-size: 12px"></i>Cutoff
            </span>
          </el-button>
          <el-button type="primary" v-if="permissions.inbound_asn_getOrderNo" @click="print" style="padding: 9px 15px">
            <span style="display: flex; align-items: center">
              <i class="iconfont icon-dayinji" style="margin-right: 5px; font-size: 12px"></i>Print
            </span>
          </el-button>
        </div>
        <el-button icon="el-icon-download" v-if="permissions.inbound_asnline_export" @click="exportExcel"></el-button>
      </div>
      <el-table border ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%"
        v-loading="dataListLoading" @selection-change="handleSelectionChange"
        :header-cell-style="{ background: '#f5f7fa', color: '#606266' }">
        <el-table-column type="selection" min-width="55" align="center">
        </el-table-column>
        <el-table-column label="Line no" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.lineNo || "-" }}</template>
        </el-table-column>
        <el-table-column label="Sku no" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{
            scope.row.partNumber || "-"
          }}</template>
        </el-table-column>
        <el-table-column label="Plan Qty" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.planQty || "0" }}</template>
        </el-table-column>
        <el-table-column label="Actual Qty" min-width="120" align="center">
          <template slot-scope="scope">{{
            scope.row.actualQty || "0"
          }}</template>
        </el-table-column>
        <el-table-column label="Difference" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.differenceQty }}</template>
        </el-table-column>
        <el-table-column label="Mapped Qty" min-width="120" align="center">
          <template slot-scope="scope">{{
            scope.row.mappedQty || "-"
          }}</template>
        </el-table-column>
        <el-table-column label="Responded Qty" min-width="120" align="center">
          <template slot-scope="scope">{{
            scope.row.respondedQty || "-"
          }}</template>
        </el-table-column>
        <el-table-column label="Unit" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.unit || "-" }}</template>
        </el-table-column>
        <el-table-column label="Mapped Order" min-width="140" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.orderNo || "-" }}</template>
        </el-table-column>
        <el-table-column label="Vin" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.vin || '-' }}</template>
        </el-table-column>
        <el-table-column label="Opearter" min-width="120" align="center" v-if="permissions.inbound_bl_edit">
          <template slot-scope="scope">
            <el-button :disabled="rowParams.status !== 'FINISHED'" style="
                font-size: 12px;
                color: #65beff;
                padding: 0;
                border: 0;
                margin-left: 0;
                text-decoration: underline;
              " :style="{
                color: rowParams.status !== 'FINISHED' ? '' : '#65beff',
              }" @click="cutOrEdit('Edit Actual qty', scope.row, scope.index)" v-if="permissions.inbound_bl_edit">
              Edit actual qty
            </el-button>
            <!-- <div
              style="cursor: pointer;color: #599af8;font-size: 14px;text-decoration: underline;"
               @click="cutOrEdit('Edit Actual qty',scope.row,scope.index)"
               v-if="permissions.inbound_bl_edit"
            >
              Edit actual qty
            </div> -->
          </template>
        </el-table-column>
      </el-table>
      <Pagination @handleSizeChange="handleSizeChange" @handleCurrentChange="handleCurrentChange" :pageNum="page.current"
        :pageSize="page.size" :total="total"></Pagination>
      <el-dialog :title="title" :visible.sync="centerDialogVisible" width="30%" style="font-weight: 700" @close="getClose"
        :close-on-click-modal="false">
        <el-form ref="form" :rules="rules" :model="formDialog" label-width="100px" v-if="title === 'Edit Actual qty'">
          <el-form-item label="Line no:" prop="lineNo">
            <el-input disabled v-model="formDialog.lineNo"></el-input>
          </el-form-item>
          <el-form-item label="Sku no:" prop="partNumber">
            <el-input disabled v-model="formDialog.partNumber"></el-input>
          </el-form-item>
          <el-form-item label="Plan Qty:" prop="num">
            <el-input disabled v-model="formDialog.num"></el-input>
          </el-form-item>
          <el-form-item label="ActualQty:" prop="actualQty">
            <el-input v-model="formDialog.actualQty"></el-input>
          </el-form-item>
          <el-form-item label="Reason:" prop="reason">
            <el-input v-model="formDialog.reason"></el-input>
          </el-form-item>
        </el-form>
        <div v-else>
          ASN has mapped Order
          <span style="font-weight: 700; color: #000">{{ cut.join("/") }}</span>. Are you sure to cut off it?
        </div>
        <!-- v-if="permissions.inbound_asn_cutoffSubmit" -->
        <span slot="footer" class="dialog-footer">
          <el-button type="info" @click="centerDialogVisible = false">Cancel</el-button>
          <el-button type="primary" @click="handleButton">Submit</el-button>
        </span>
      </el-dialog>
      <el-dialog title="View Mapping Logs" :visible.sync="mappingVisible" width="30%" style="font-weight: 700">
        <el-timeline class="timeline">
          <el-timeline-item v-for="(activity, index) in activities" :key="index" :icon="activity.icon"
            :type="activity.type" :color="activity.color" size="large">
            <div class="box">
              <div class="boxTop">
                {{ activity.clientCode }}
                <span>{{ activity.createTime }}</span>
              </div>
              <div class="boxBottom">{{ activity.operateContent }}</div>
            </div>
          </el-timeline-item>
        </el-timeline>
      </el-dialog>
    </div>
  </basic-container>
</template>
<script>
import { mapGetters } from "vuex";
import Pagination from "@/components/pagination/pagination.vue";
import {
  getAsnLines,
  getEditAsnline,
  getByASn,
  getCutoffMappedPreview,
  getCutoffMappedSubmit,
  getAsnDetails,
  print,
  addAsnLinePrint,
} from "@/api/inbound/asn";
import { getOrderDetail } from "@/api/inbound/asnOrder";
import { setStore } from "@/util/store";
import store from "@/store";
import request from "@/router/axios";
export default {
  name: "asnDetail",
  data() {
    return {
      form: {
        partNumber: undefined,
        hasDifference: undefined,
        orderNo: undefined,
        hasNoMapped: undefined,
      },
      page: {
        size: 10,
        current: 1,
      },
      total: 0,
      dataListLoading: false,
      rowParams: {},
      differenceList: [
        {
          value: 1,
          label: "Y",
        },
        {
          value: 0,
          label: "N",
        },
      ],
      tableData: [],
      centerDialogVisible: false,
      formDialog: {
        lineNo: "",
        partNumber: "",
        num: "",
        actualQty: 0,
        reason: ""
      },
      title: "",
      rules: {
        lineNo: [{ required: true, message: "请输入lineNo", trigger: "blur" }],
        partNumber: [
          { required: true, message: "请输入skuNo", trigger: "blur" },
        ],
        num: [{ required: true, message: "请输入planQty", trigger: "blur" }],
        actualQty: [
          { required: true, message: "请输入actualQty", trigger: "blur" },
          {
            pattern: /^(\+?[1-9][0-9])*|0$/,
            message: "请输入大于等于0的整数！",
            trigger: "blur",
          },
          {
            validator: (rule, value, callback) => {
              if (value > this.formDialog.planQty) {
                callback("不能大于预收数");
              } else {
                callback();
              }
            },
            trigger: "change",
          },
        ],
        reason: [
          { required: true, message: "请输入原因", trigger: "blur" },
        ],
      },
      cut: [],
      mappingVisible: false,
      activities: [], //日志
      multipleSelection: [],
      asnNo: "",
      asnDetailLoading: false,
      titleLoading: false,
    };
  },
  computed: {
    ...mapGetters(["permissions"]),
    // disabled:function(){
    //   console.log(this.rowParams.status,this.$store.state.common.commandName,this.rowParams.warehouseCode);
    //   if(){
    //     return false
    //   }
    // }
  },
  components: {
    Pagination,
  },
  watch: {
    // 利用watch方法检测路由变化：
    $route: function (to, from) {
      if (to.path == "/asnDetail/index" && to.query.name) {
        if (to.query.name != from.query.name) {
          this.asnNo = to.query.name;
          this.getList();
          this.getDetailInfo();
        }
      }
    },
  },
  created() {
    this.asnNo = this.$route.query.name;
    this.getList();
    this.getDetailInfo();
  },
  mounted() {
    this.exportExcel = this.$btn(this.exportExcel, 500);
    this.clickCopy = this.$btn(this.clickCopy, 500);
    this.handleButton = this.$btn(this.handleButton, 500);
  },
  methods: {
    //复制
    async clickCopy() {
      let content = this.rowParams.asnNo;
      if (this.copy(content) === "文本为空") {
        this.$message.warning("Text is empty and cannot be copied !!!");
        return;
      }
      this.$message.success("copy success");
    },
    //导出
    exportExcel() {
      this.downBlobFile(
        "/inbound/asnline/exportAsnLine",
        { ...this.form, asnNo: this.rowParams.asnNo },
        `${this.$store.state.common.commandName}-Asnline-${this.toDateFormat(
          new Date(),
          true
        )}.xlsx`
      );
    },
    //清空
    getReset() {
      this.form = this.$options.data().form;
      this.getList();
    },
    //查询
    getSearchlist() {
      this.page.current = 1;
      for (let key in this.form) {
        if (this.form[key] === "" || this.form[key] === null) {
          this.form[key] = undefined;
        }
      }
      this.getList();
    },
    //数据列表
    getList() {
      this.dataListLoading = true;
      getAsnLines(
        Object.assign({ ...this.page }, { ...this.form }, { asnNo: this.asnNo })
      )
        .then((res) => {
          console.log(res);
          if (res.data.code == 0) {
            this.tableData = res.data.data.records;
            this.total = res.data.data.total;
            this.dataListLoading = false;
          } else {
            this.$message.error(res.data.msg);
            this.dataListLoading = false;
          }
        })
        .catch(() => {
          this.dataListLoading = false;
        });
    },
    //条数
    handleSizeChange(val) {
      this.page.current = 1;
      this.page.size = val;
      this.getList();
    },
    //当前页数
    handleCurrentChange(val) {
      this.page.current = val;
      this.getList();
    },
    handleSelectionChange(val) {
      this.multipleSelection = val;
    },
    cutOrEdit(type, row, index) {
      this.title = type;
      if (this.title === "Edit Actual qty") {
        if (this.rowParams.status !== "FINISHED") {
          this.$message.warning(`${row.asnNo} status does not support editing`);
          return;
        }
        this.centerDialogVisible = true;
        this.formDialog = Object.assign({ num: row.planQty }, row);
      } else {
        this.centerDialogVisible = true;
        this.title = type;
        getCutoffMappedPreview({ asnNo: this.rowParams.asnNo }).then((res) => {
          console.log(res);
          if (res.data.code === 0) {
            res.data.data.forEach((ite) => {
              this.cut.push(ite);
            });
            this.cut = [...new Set(this.cut)];
          }
        });
      }
    },
    print() {
      this.$confirm(
        "Confirm whether to print. Do you want to continue?",
        "Tips",
        {
          confirmButtonText: "submit",
          cancelButtonText: "cancel",
          type: "warning",
        }
      )
        .then(() => {
          print({
            asnNo: this.asnNo,
            asnLines: this.multipleSelection,
            clientCode: store.getters.commandName,
            warehouseCode: this.rowParams.warehouseCode,
          }).then((res) => {
            if (res.data.code === 0) {
              let dataValue = res.data.data;
              axios({
                url: "http://localhost:9001/print/run",
                method: "post",
                data: dataValue,
              }).then((response) => {
                if (response.data.code !== 0) {
                  this.$message.error("Printing failed");
                } else {
                  this.$message.success("Printing succeeded");
                  addAsnLinePrint(dataValue).then((res) => {
                    if (res.data.code === 0) {
                    } else {
                      this.$message.error(res.data.msg);
                    }
                  });
                }
              });
            } else {
              this.$message.error(response.data.msg);
            }
          });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "Destruction",
          });
        });
    },
    //关闭弹窗
    getClose() {
      if (this.title === "Edit Actual qty") {
        this.formDialog = this.$options.data().formDialog;
        this.$refs.form.resetFields();
      }
    },
    handleButton() {
      if (this.title === "Edit Actual qty") {
        this.$refs.form.validate((valid) => {
          if (!valid) return false;
          getEditAsnline(
            Object.assign(
              { ...this.formDialog },
              { num: this.formDialog.planQty }
            )
          ).then((res) => {
            console.log(res);
            if (res.data.code === 0) {
              this.centerDialogVisible = false;
              this.getList();
              this.$message.success("Edit actual qty succeeded");
            } else {
              this.centerDialogVisible = false;
              this.$message.error(res.data.msg);
            }
          });
        });
      } else {
        this.asnDetailLoading = true;
        this.centerDialogVisible = false;
        getCutoffMappedSubmit({ asnNo: this.rowParams.asnNo })
          .then((res) => {
            console.log(res);
            if (res.data.code === 0) {
              this.getDetailInfo();
              this.$message.success("Cut off Mapped Submit succeeded");
              this.asnDetailLoading = false;
            } else {
              this.$message.error(res.data.msg);
              this.asnDetailLoading = false;
            }
          })
          .catch(() => {
            this.asnDetailLoading = false;
          });
      }
    },
    //打开订单追踪弹窗
    dialogTrue() {
      getByASn({ asnNo: this.rowParams.asnNo }).then((res) => {
        console.log(res);
        if (res.data.data.code === 0) {
          if (res.data.data.data.length) {
            this.mappingVisible = true;
            this.activities = res.data.data.data;
          } else {
            this.$message.warning(
              "Not found temporarily " +
              `${this.rowParams.asnNo}` +
              " PFEP allocation details of the order！"
            );
          }
        } else {
          this.$message.error(res.data.data.msg);
        }
      });
    },
    getDetailInfo() {
      this.titleLoading = true;
      getAsnDetails({ asnNo: this.asnNo })
        .then((res) => {
          console.log(res);
          if (res.data.code === 0) {
            this.titleLoading = false;
            this.rowParams = res.data.data;
          } else {
            this.titleLoading = false;
            this.$message.error(res.data.msg);
          }
        })
        .catch(() => {
          this.titleLoading = false;
        });
    },
    //跳转
    mapping() {
      // if(this.rowParams.status !== "FINISHED") {
      //   this.$message.warning(`${this.rowParams.asnNo} current status does not support mapping`)
      //   return
      // }
      this.$router.push({
        path: `/asnMapping`,
      });
      setStore({ name: "mapParams", content: this.rowParams });
    },
    //asnOrder详情
    clickOrderDetail(val) {
      getOrderDetail({ orderNo: val }).then((res) => {
        console.log(res);
        if (res.data.code === 0) {
          if (res.data.data) {
            let orderDetail = res.data.data;
            this.$router.push({
              path: `/asnOrderDetail`,
              query: {
                name: val,
                row: JSON.stringify(orderDetail),
              },
            });
          } else {
            this.$message.warning("No data for details");
          }
        } else {
          this.$message.error(res.data.msg);
        }
      });
    },
    asnDetail() {
      this.$router.push({
        path: `/asnDetail`,
        query: {
          name: this.rowParams.splitAsn,
        },
      });
    },
  },
};
</script>
<style lang="scss" scoped>
.content {
  width: 100%;
  //   padding: 20px;
  font-size: 13px;
  box-sizing: border-box;

  .title {
    width: 100%;
    height: 30px;
    line-height: 30px;
    display: flex;
    margin-bottom: 10px;

    span {
      width: 3px;
      height: 30px;
      background-color: #000;
      margin-right: 10px;
    }

    label {
      font-weight: 700;
    }
  }

  .containBox {
    border-bottom: 1px solid #999;
    margin-bottom: 20px;
  }

  .contain {
    padding: 10px;
    box-sizing: border-box;
    width: 100%;

    label {
      margin-right: 5px;
      display: inline-block;
      width: 90px;
      text-align: right;
      vertical-align: middle;
    }

    span {
      color: #999;
      vertical-align: middle;
    }
  }

  .down {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
  }

  .timeline {
    padding: 10px;

    .box {
      background-color: #f4f6f7;
      border-radius: 5px;
      padding: 10px 20px;
      box-sizing: border-box;

      .boxTop {
        font-weight: 700;
        margin-bottom: 10px;

        span {
          margin-left: 10px;
        }
      }

      .boxBottom {
        color: #666;
      }
    }
  }

  .copy {
    cursor: pointer;
  }

  ::v-deep .el-dialog {
    border-radius: 8px !important;
  }
}
</style>
