<template>
  <div class="content" v-loading="asnLoading">
    <el-tabs type="border-card" @tab-click="tabClick" v-model="activeName">
      <el-tab-pane label="Overview" name="Overview">
        <el-row style="width:200px;display:flex">
          <el-col>
            <el-button type="primary" icon="el-icon-search" @click="getSearchlist">Query</el-button>
          </el-col>
          <el-col>
            <el-button icon="el-icon-refresh-left" @click="getReset">Reset</el-button>
          </el-col>
        </el-row>
        <el-form ref="form" :model="form" @keyup.enter.native="getSearchlist" style="margin: 20px 0">
          <el-row :gutter="20">
            <el-col :span="4">
              <el-input placeholder="ASN no/Job no/BL no" v-model="form.asnNo">
                <el-select filterable v-model="form.isAccurate" slot="prepend" class="common_select">
                  <el-option label="accurate" value="Y"></el-option>
                  <el-option label="dim" value="N"></el-option>
                </el-select>
              </el-input>
            </el-col>
            <el-col :span="4">
              <el-select v-model="form.warehouseCode" placeholder="Warehouse" filterable clearable>
                <el-option v-for="item in warehouseCode" :key="item.value" :label="item.warehouseName"
                  :value="item.warehouseCode">
                </el-option>
              </el-select>
            </el-col>
            <el-col :span="4">
              <el-select v-model="form.status" placeholder="Status" filterable clearable>
                <el-option v-for="item in asnStatus" :key="item.value" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </el-col>
            <el-col :span="4">
              <el-select v-model="form.shipType" placeholder="Ship Type" filterable clearable>
                <el-option v-for="item in shipType" :key="item.value" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </el-col>
            <el-col :span="4">
              <el-select v-model="form.isSplitASN" placeholder="Is Split ASN" filterable clearable>
                <el-option v-for="item in isSplitASN" :key="item.value" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </el-col>
            <el-col :span="4">
              <el-button style="float:right" type="primary" @click="about"
                :icon="show ? 'el-icon-arrow-up' : 'el-icon-arrow-down'">
                <label for="">{{ show ? "收起" : "更多" }}</label>
              </el-button>
            </el-col>
          </el-row>
          <el-row v-show="show" style="margin-top: 10px" :gutter="20">
            <el-col :span="4">
              <el-date-picker v-model="time.createTime" type="daterange" start-placeholder="CreateTime"
                end-placeholder="CreateEndTime" :default-time="['00:00:00', '23:59:59']"
                value-format="yyyy-MM-dd HH:mm:ss" @change="changeCreateTime" />
            </el-col>
            <el-col :span="4">
              <el-date-picker v-model="time.releaseTime" type="daterange" start-placeholder="ReleaseTime"
                end-placeholder="ReleaseEndTime" :default-time="['00:00:00', '23:59:59']"
                value-format="yyyy-MM-dd HH:mm:ss" @change="changeReleaseTime">
              </el-date-picker>
            </el-col>
            <el-col :span="4">
              <el-date-picker v-model="time.finishTime" type="daterange" start-placeholder="FinishTime"
                end-placeholder="FinishEndTime" :default-time="['00:00:00', '23:59:59']"
                value-format="yyyy-MM-dd HH:mm:ss" @change="changeFinishTime">
              </el-date-picker>
            </el-col>
            <el-col :span="4">
              <el-date-picker v-model="time.closeTime" type="daterange" start-placeholder="CloseTime"
                end-placeholder="CloseEndTime" :default-time="['00:00:00', '23:59:59']" value-format="yyyy-MM-dd HH:mm:ss"
                @change="changeCloseTime">
              </el-date-picker>
            </el-col>
            <el-col :span="4">
              <el-date-picker v-model="time.inboundTime" type="daterange" start-placeholder="InboundTime"
                end-placeholder="InboundEndTime" :default-time="['00:00:00', '23:59:59']"
                value-format="yyyy-MM-dd HH:mm:ss" @change="changeInboundTime">
              </el-date-picker>
            </el-col>
          </el-row>
        </el-form>
        <div class="down">
          <div>
            <el-button type="primary" icon="el-icon-s-promotion" @click="handleRelease('Release')"
              :disabled="dispatchDisabled" v-if="permissions.inbound_asn_release">Release</el-button>
            <el-button icon="el-icon-circle-check" v-if="permissions.inbound_asn_differenceAsnUpdate" type="primary"
              :disabled="multipleSelection.length !== 1 || multipleSelection[0].status !== 'RELEASED' || this.$store.state.common.commandName !== 'NIO'
                || multipleSelection[0].warehouseCode !== 'NIO-Norway-01'" @click="finishClick">Finish</el-button>
            <el-button @click="closeButton" v-if="permissions.inbound_asn_shutdown"
              :disabled="multipleSelection.length !== 1 || multipleSelection[0].status === 'CLOSED'"><i
                class="iconfont icon-guanbi1" style="font-size:12px;margin-right:3px"></i> Close</el-button>
          </div>
          <div>
            <el-button icon="el-icon-upload2" @click="$refs.excelUpload.show()"
              v-if="permissions.inbound_asn_import"></el-button>
            <el-button icon="el-icon-download" @click="exportExcel" v-if="permissions.inbound_asn_export"></el-button>
          </div>
        </div>
        <el-table border ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%"
          @selection-change="handleSelectionChange"
          :header-cell-style="{ background: '#f5f7fa', color: '#606266', 'text-align': 'center' }"
          v-loading="dataListLoading">
          <el-table-column type="selection" min-width="55" align="center"> </el-table-column>
          <el-table-column label="WarehouseName" min-width="120" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.warehouseName || '-' }}</template>
          </el-table-column>
          <el-table-column label="WarehouseCode" min-width="120" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.warehouseCode || '-' }}</template>
          </el-table-column>
          <el-table-column label="Owner" min-width="120" align="center">
            <template slot-scope="scope">{{ scope.row.clientCode || '-' }}</template>
          </el-table-column>
          <el-table-column label="ASN" min-width="160" align="center" show-overflow-tooltip>
            <template slot-scope="scope">
              <div class="underLine" @click="handleDetail(scope.$index, scope.row)"
                v-if="permissions.inbound_asn_getByAsnNo">
                <i
                  :class="(scope.row.status === 'PACKED' || scope.row.status === 'BOOKED' || scope.row.status === 'OUTBOUND' || scope.row.status === 'FINISHED' || scope.row.status === 'CLOSED') ? (scope.row.hasDifference === 'N' ? 'el-icon-check underIcon' : 'el-icon-close underIconA') : ''"></i>
                {{ scope.row.asnNo || '-' }}
              </div>
              <div v-else>
                {{ scope.row.asnNo || '-' }}
              </div>
            </template>
          </el-table-column>
          <el-table-column label="Job no" min-width="160" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.blNo || '-' }}</template>
          </el-table-column>
          <el-table-column label="BL no" min-width="160" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.billLandNum || '-' }}</template>
          </el-table-column>
          <el-table-column label="Ship Type" min-width="120" align="center">
            <template slot-scope="scope">{{ scope.row.shipType || '-' }}</template>
          </el-table-column>
          <el-table-column label="Created" min-width="140" align="center">
            <template slot-scope="scope">{{ scope.row.createTime || '-' }}</template>
          </el-table-column>
          <el-table-column label="Realeased" min-width="140" align="center">
            <template slot-scope="scope">{{ scope.row.releaseTime || '-' }}</template>
          </el-table-column>
          <el-table-column label="Finished" min-width="140" align="center">
            <template slot-scope="scope">{{ scope.row.finishedTime || '-' }}</template>
          </el-table-column>
          <el-table-column label="Closed" min-width="140" align="center">
            <template slot-scope="scope">{{ scope.row.closedTime || '-' }}</template>
          </el-table-column>
          <el-table-column label="Status" min-width="120" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.status || '-' }}</template>
          </el-table-column>
          <el-table-column fixed="right" label="Opearter" min-width="120" align="center"
            v-if="permissions.inbound_asn_edit || permissions.sys_BizRecord_get || permissions.inbound_asn_getOrderNo">
            <template slot-scope="scope">
              <i style="font-size: 18px;cursor: pointer;color:#65BEFF;margin-right:10px" class="el-icon-info"
                @click="handleSee(scope.index, scope.row)" v-if="permissions.sys_BizRecord_get"></i>
              <i style="font-size: 18px;cursor: pointer;color:#65BEFF;margin-right:10px" class="el-icon-edit"
                @click="handleRelease('Edit', scope.row)" v-if="permissions.inbound_asn_edit"></i>
              <el-button :disabled="scope.row.status !== 'FINISHED'"
                style="font-size: 18px;color: #65beff;padding:0;border:0;margin-left:0"
                :style="{ 'color': scope.row.status !== 'FINISHED' ? '' : '#65beff' }" class="iconfont icon-icon--"
                @click="mapping(scope.index, scope.row)" v-if="permissions.inbound_asn_getOrderNo"></el-button>
              <!-- <i style="font-size: 18px;cursor: pointer;color: #65beff"
                class="iconfont icon-icon--"
                v-if="permissions.inbound_asn_getOrderNo"
                @click="mapping(scope.index,scope.row)"
              ></i> -->
            </template>
          </el-table-column>
        </el-table>
        <Pagination @handleSizeChange="handleSizeChange" @handleCurrentChange="handleCurrentChange"
          :pageNum="page.current" :pageSize="page.size" :total="total"></Pagination>
        <el-dialog :title="title" :visible.sync="centerDialogVisible" width="30%" style="font-weight: 700"
          @close="getClose" :close-on-click-modal="title === 'Edit'">
          <el-form :model="formDialog" ref="releaseForm" :rules="rules" label-width="100px">
            <el-form-item label="Remark:" prop="remark">
              <el-input type="textarea" v-model="formDialog.remark" placeholder="请输入..."> </el-input>
            </el-form-item>
            <el-form-item label="Warehouse:" v-if="title === 'Release'" prop="warehouseCode">
              <div style="display:flex;flex-wrap: wrap;">
                <div v-for="(ite, idx) in warehouseCode" class="warehouseCode"
                  @click="!warehouseCodeArr[0] ? changeWarehouse(ite, idx) : ''"
                  :class="formDialog.warehouseCode === ite.warehouseCode ? 'colorClick' : ''" :key="ite">
                  {{ ite.warehouseName }}
                </div>
              </div>
            </el-form-item>
          </el-form>
          <span slot="footer" class="dialog-footer">
            <el-button type="info" @click="centerDialogVisible = false">Cancel</el-button>
            <el-button type="primary" @click="dialogButton">Release</el-button>
          </span>
        </el-dialog>
        <AllDrawer v-if="AllDrawer" :AllDrawer="AllDrawer" @handleClose="handleClose" :AllDrawerObj="AllDrawerObj"
          @AllDrawerDetail="AllDrawerDetail" :AllDrawerRow="AllDrawerRow"></AllDrawer>
        <!--excel 模板导入 -->
        <excel-upload ref="excelUpload" title="Asn upload" url="/inbound/asn/importAns"
          temp-name="asn-upload-template.xlsx" temp-url="/admin/sys-file/local/asn-upload-template.xlsx"
          @refreshDataList="handleRefreshChange"></excel-upload>
      </el-tab-pane>
      <el-tab-pane name="Pending">
        <span slot="label"> Pending <el-badge :value="pendingCount" type="primary"></el-badge></span>
        <AsnPending v-if="pending" @pendingClick='pendingClick'></AsnPending>
      </el-tab-pane>
      <el-tab-pane name="No Mapped">
        <span slot="label"> No Mapped <el-badge :value="noMappedCount" type="primary"></el-badge></span>
        <AsnNoMapped v-if="noMapped" @pendingClick='pendingClick'></AsnNoMapped>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>
<script>
import { mapGetters } from "vuex"
import Pagination from "@/components/pagination/pagination.vue"
import AsnPending from "./asnPending.vue"
import AsnNoMapped from "./asnNoMapped.vue"
import AllDrawer from "@/views/outbound/dn/drawer/allDrawer.vue"
import ExcelUpload from "@/components/upload/excel"
import {
  pageQuerys, getEditQuery, getRelease, getAsnPendingCount, getAsnNoMappedCount,
  getWarehouse, getShutdownAsn, differenceAsnUpdate
} from "@/api/inbound/asn"
import { remote } from "@/api/admin/dict"
import { bizRecordPage } from "@/api/outbound/dn";
import { setStore } from "@/util/store"

let formParams = {
  asnNo: undefined,
  warehouseCode: undefined,
  status: undefined,
  shipType: undefined,
  isSplitASN: undefined,
  isAccurate: "Y"
}
export default {
  name: "ASN",
  data() {
    return {
      activeName: 'Overview',
      form: Object.assign({}, formParams),
      time: {
        createTime: undefined,
        releaseTime: undefined,
        finishTime: undefined,
        closeTime: undefined,
        inboundTime: undefined
      },
      page: {
        size: 10,
        current: 1,
      },
      total: 0,
      formDialog: {
        warehouseCode: "",
        remark: "",
        id: ""
      },
      title: "",
      show: false, //更多
      tableData: [],
      multipleSelection: [],
      centerDialogVisible: false,
      dataListLoading: false,
      warehouseCode: [],//warehouse下拉数据
      asnStatus: [],//status下拉数据
      shipType: [],//asnType下拉数据
      isSplitASN: [
        {
          value: 1,
          label: "Y",
        },
        {
          value: 0,
          label: "N",
        },
      ],
      pending: false,
      noMapped: false,
      pendingCount: 0,//数量
      noMappedCount: 0,
      rules: {
        warehouseCode: [{ required: true, message: '请选择仓库代码', trigger: 'change' }],
        remark: [{ required: true, message: '请输入备注', trigger: 'blur' },
        { max: 255, message: '长度最大 255 个字', trigger: 'blur' }
        ],
      },
      selectStatus: {},
      ids: [],
      status: [],
      warehouseCodeArr: [],
      dispatchDisabled: true,
      AllDrawer: false,
      AllDrawerObj: {},
      AllDrawerRow: {},
      asnLoading: false,
    }
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  components: {
    Pagination,
    AsnPending,
    AllDrawer,
    ExcelUpload,
    AsnNoMapped
  },
  async created() {
    await this.getWarehouseCode()
    await this.getList()
    this.getPending()
  },
  mounted() {
    this.dialogButton = this.$btn(this.dialogButton, 500)
    this.exportExcel = this.$btn(this.exportExcel, 500)
    this.closeButton = this.$btn(this.closeButton, 500)
  },
  methods: {
    changeWarehouse(ite, idx) {
      this.formDialog.warehouseCode = ite.warehouseCode
    },
    //展开
    about() {
      this.show = !this.show
    },
    //切换tab
    tabClick() {
      if (this.activeName === 'Pending') {
        this.pending = true
        this.noMapped = false
      } else if (this.activeName === 'No Mapped') {
        this.noMapped = true
        this.pending = false
      } else {
        this.pending = false
        this.noMapped = false
        this.getReset()
        this.getPending()
      }
    },
    //时间参数
    changeCreateTime(val) {
      if (val !== undefined && val !== null && val !== '' && val.length > 0) {
        this.$set(this.form, 'createStartTime', val[0])
        this.$set(this.form, 'createEndTime', val[1])
      } else {
        this.$set(this.form, 'createStartTime', undefined)
        this.$set(this.form, 'createEndTime', undefined)
      }
    },
    changeReleaseTime(val) {
      if (val !== undefined && val !== null && val !== '' && val.length > 0) {
        this.$set(this.form, 'releaseStartTime', val[0])
        this.$set(this.form, 'releaseEndTime', val[1])
      } else {
        this.$set(this.form, 'releaseStartTime', undefined)
        this.$set(this.form, 'releaseEndTime', undefined)
      }
    },
    changeFinishTime(val) {
      if (val !== undefined && val !== null && val !== '' && val.length > 0) {
        this.$set(this.form, 'finishStartTime', val[0])
        this.$set(this.form, 'finishEndTime', val[1])
      } else {
        this.$set(this.form, 'finishStartTime', undefined)
        this.$set(this.form, 'finishEndTime', undefined)
      }
    },
    changeCloseTime(val) {
      if (val !== undefined && val !== null && val !== '' && val.length > 0) {
        this.$set(this.form, 'closeStartTime', val[0])
        this.$set(this.form, 'closeEndTime', val[1])
      } else {
        this.$set(this.form, 'closeStartTime', undefined)
        this.$set(this.form, 'closeEndTime', undefined)
      }
    },
    changeInboundTime(val) {
      if (val !== undefined && val !== null && val !== '' && val.length > 0) {
        this.$set(this.form, 'feedbackStartTime', val[0])
        this.$set(this.form, 'feedbackEndTime', val[1])
      } else {
        this.$set(this.form, 'feedbackStartTime', undefined)
        this.$set(this.form, 'feedbackEndTime', undefined)
      }
    },
    //导出
    exportExcel() {
      this.asnLoading = true
      this.downBlobFile("/inbound/asn/exportAsn", this.form, `${this.$store.state.common.commandName}-ASN-${this.toDateFormat(new Date(), true)}.xlsx`, () => this.asnLoading = false)
    },
    //上传
    handleRefreshChange(e) {
      console.log(e);
      if (e === 'loading') {
        this.asnLoading = true
        return
      }
      this.asnLoading = false
      this.getList()
    },
    //条数
    handleSizeChange(val) {
      this.page.current = 1
      this.page.size = val
      this.getList(this.form)
    },
    //当前页数
    handleCurrentChange(val) {
      this.page.current = val
      this.getList(this.form)
    },
    //清空
    getReset() {
      this.form = Object.assign({}, formParams)
      this.time = this.$options.data().time
      this.page = this.$options.data().page
      this.getList(this.form)
    },
    //查询
    getSearchlist() {
      this.page.current = 1
      for (let key in this.form) {
        if (this.form[key] === '' || this.form[key] === null) {
          this.form[key] = undefined
        }
      }
      this.getList(this.form)
    },
    //数据列表
    getList(params) {
      // if(this.permissions.inbound_asn_query){
      this.dataListLoading = true
      pageQuerys(Object.assign({ ...this.page }, params)).then(res => {
        console.log(res)
        if (res.data.code === 0) {
          this.tableData = res.data.data.records
          this.tableData.forEach(item => {
            this.warehouseCode.forEach(ite => {
              if (item.warehouseCode === ite.warehouseCode) {
                item.warehouseName = ite.warehouseName
              }
            })
          })
          this.total = res.data.data.total
          this.dataListLoading = false
        } else {
          this.$message.error(res.data.msg)
          this.dataListLoading = false
        }
      }).catch(() => {
        this.$message.error('request was aborted')
        this.dataListLoading = false
      })
      // }else{
      //   this.$message.warning('此页面暂无权限')
      // }
    },
    //多选
    handleSelectionChange(val) {
      this.multipleSelection = val
      console.log(this.multipleSelection);
      this.ids = []
      this.status = []
      this.warehouseCodeArr = []
      this.multipleSelection.forEach(ite => {
        this.ids.push(ite.id)
        this.status.push(ite.status)
        this.warehouseCodeArr.push(ite.warehouseCode)
      })
      if (this.multipleSelection.length !== 0 && (this.status.indexOf('CREATED') !== -1 && new Set(this.status).size === 1) && new Set(this.warehouseCodeArr).size === 1) {
        this.dispatchDisabled = false
      } else {
        this.dispatchDisabled = true
      }
    },
    //打开Release/编辑弹窗
    handleRelease(type, row) {
      this.centerDialogVisible = true
      this.title = type
      if (this.title === "Edit") {
        console.log(row)
        this.formDialog.remark = row.remark
        this.formDialog.id = row.id
        this.$refs.multipleTable.clearSelection()
      } else {
        // if(this.multipleSelection.length === 1){
        this.formDialog.warehouseCode = this.multipleSelection[0].warehouseCode
        // }
      }
    },
    //编辑
    dialogButton() {
      this.$refs.releaseForm.validate((valid) => {
        if (!valid) return false
        if (this.title === "Edit") {
          getEditQuery({ id: this.formDialog.id, remark: this.formDialog.remark }).then(res => {
            console.log(res)
            if (res.data.code === 0) {
              this.$message.success("Edit succeeded")
              this.getList(this.form)
              this.centerDialogVisible = false
            }
          })
        } else {
          this.asnLoading = true
          this.centerDialogVisible = false
          getRelease({ ids: this.ids, ...this.formDialog }).then(res => {
            console.log(res)
            if (res.data.code === 0) {
              this.$message.success('Release succeeded')
              this.getList(this.form)
              this.getPending()
              this.asnLoading = false
            } else {
              this.getList(this.form)
              this.getPending()
              this.$message.error(res.data.msg)
              this.asnLoading = false
            }
          }).catch(err => {
            this.getList(this.form)
            this.getPending()
            this.asnLoading = false
          })
        }
      })
    },
    //
    closeButton() {
      this.$confirm('This operation is irreversible, confirm to continue this operation?', 'Tips', {
        confirmButtonText: 'submit',
        cancelButtonText: 'cancel',
        type: 'warning'
      }).then(() => {
        getShutdownAsn({ asnNo: this.multipleSelection[0].asnNo }).then(res => {
          if (res.data.code === 0) {
            this.getList(this.form);
            this.$emit('pendingClick')
            this.$message.success("Closed succeeded");
          } else {
            this.$message.error(res.data.msg)
          }
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: 'Destruction'
        });
      });
    },
    //强制完成
    finishClick() {
      differenceAsnUpdate({ asnNo: this.multipleSelection[0].asnNo }).then(res => {
        if (res.data.code == 0) {
          this.$message.success('success')
          this.getList(this.form)
        } else {
          this.$message.error(res.data.msg)
        }
      })
    },
    //关闭弹窗
    getClose() {
      this.formDialog = Object.assign({}, { warehouseCode: "", remark: "" })
      this.$refs.releaseForm.resetFields()
    },
    //查看错误详情
    handleSee(index, row) {
      this.AllDrawerRow = { ...row, current: 1, size: 10 }
      bizRecordPage({ type: "ASN", orderNum: row.dnNo, dnNum: row.asnNo, current: row.current || 1, size: row.size || 10, }).then(res => {
        console.log(res);
        if (res.data.code === 0) {
          if (!res.data.data.records.length) {
            this.AllDrawer = false
            this.$message.warning(`单号${row.asnNo}没有错误日志`)
          } else {
            this.AllDrawer = true
            this.AllDrawerObj = res.data.data
          }
        } else {
          this.$message.error(res.data.msg)
        }
      })
    },
    //关闭详情
    handleClose(e) {
      this.AllDrawer = e
    },
    AllDrawerDetail(e) {
      console.log(e.AllDrawerRow,);
      this.handleSee('', e.AllDrawerRow)
    },
    //下拉数据
    getWarehouseCode() {
      //warehouseCode
      getWarehouse().then(res => {
        if (res.data.code === 0) {
          this.warehouseCode = res.data.data
        }
      })
      //status
      remote('asn_status').then(res => {
        if (res.data.code === 0) {
          this.asnStatus = res.data.data
        }
      })
      //shipType
      remote("bl_ship_type").then((res) => {
        if (res.data.code === 0) {
          this.shipType = res.data.data;
        }
      });
    },
    getPending() {
      getAsnPendingCount().then(res => {
        console.log(res)
        if (res.data.code === 0) {
          this.pendingCount = res.data.data
        }
      })
      getAsnNoMappedCount().then(res => {
        console.log(res)
        if (res.data.code === 0) {
          this.noMappedCount = res.data.data
        }
      })
    },
    pendingClick() {
      this.getPending()
    },
    //跳转
    mapping(index, row) {
      // if(row.status !== "FINISHED") {
      //   this.$message.warning(`${row.asnNo} current status does not support mapping`)
      //   return
      // }
      this.$router.push({
        path: `/asnMapping`,
      });
      setStore({ name: "mapParams", content: row })
      // console.log(row,'5555');
    },
    //跳转  
    handleDetail(index, row) {
      this.$router.push({
        path: `/asnDetail`,
        query: {
          name: row.asnNo,
        },
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.content {
  padding: 0 10px;

  // box-sizing: border-box;
  .down {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    border-top: 1px solid #999;
    padding-top: 20px;
    box-sizing: border-box;
  }

  .underLine {
    cursor: pointer;
    color: #599af8;
    text-decoration: underline;

    .underIcon {
      background-color: rgb(137, 234, 137);
      color: #fff;
      border-radius: 50%;
      margin-right: 5px;
    }

    .underIconA {
      background-color: rgb(238, 99, 99);
      color: #fff;
      border-radius: 50%;
      margin-right: 5px;
    }
  }

  .warehouseCode {
    width: 120px;
    height: 55px;
    font-size: 12px;
    display: flex;
    justify-content: center;
    align-items: center;
    font-weight: normal;
    box-shadow: 1px 1px 2px 2px rgb(0 0 0 / 20%);
    border-radius: 3px;
    margin-left: 20px;
    margin-bottom: 20px;
    box-sizing: border-box;
    cursor: pointer;
  }

  .colorClick {
    background-color: #1575C7;
    color: #fff;
    font-weight: 700;
  }

  ::v-deep .el-dialog {
    border-radius: 8px !important;
  }

  ::v-deep .el-select--small {
    display: block;
  }

  ::v-deep .el-date-editor--daterange.el-input,
  ::v-deep .el-date-editor--daterange.el-input__inner,
  ::v-deep .el-date-editor--timerange.el-input,
  ::v-deep .el-date-editor--timerange.el-input__inner {
    width: 100% !important;

  }

  .common_select {
    width: 80px;
  }

  // ::v-deep .el-table__header-wrapper  .el-checkbox{//找到表头那一行，然后把里面的复选框隐藏掉
  //   display:none
  // }
}
</style>
