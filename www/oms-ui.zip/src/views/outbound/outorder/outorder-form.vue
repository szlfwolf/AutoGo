<template>
  <el-dialog
    :title="!dataForm.id ? '新增' : '修改'"
    append-to-body
    :close-on-click-modal="false"
    @close="closeDialog()"
    :visible.sync="visible">
    <el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="dataFormSubmit()" label-width="80px">
    <el-form-item label="主键" prop="id" v-if="dataForm.id">
        <el-input v-model="dataForm.id" placeholder="主键" disabled></el-input>
    </el-form-item>
    <el-form-item label="客户代码" prop="clientCode">
        <el-input v-model="dataForm.clientCode" placeholder="客户代码"></el-input>
    </el-form-item>
    <el-form-item label="订单号" prop="orderNum">
        <el-input v-model="dataForm.orderNum" placeholder="订单号"></el-input>
    </el-form-item>
    <el-form-item label="外部出库单号" prop="outOrderNum">
        <el-input v-model="dataForm.outOrderNum" placeholder="外部出库单号"></el-input>
    </el-form-item>
    <el-form-item label="收货人地址id" prop="addressId">
        <el-input v-model="dataForm.addressId" placeholder="收货人地址id"></el-input>
    </el-form-item>
    <el-form-item label="期望发货时间" prop="expecedDeliveryDate">
        <el-input v-model="dataForm.expecedDeliveryDate" placeholder="期望发货时间"></el-input>
    </el-form-item>
    <el-form-item label="zcck,qtck" prop="orderType">
        <el-input v-model="dataForm.orderType" placeholder="zcck,qtck"></el-input>
    </el-form-item>
    <el-form-item label="紧急单，普通单" prop="urgentLevel">
        <el-input v-model="dataForm.urgentLevel" placeholder="紧急单，普通单"></el-input>
    </el-form-item>
    <el-form-item label="订单状态,创建，部分出库，完成" prop="orderStatus">
        <el-input v-model="dataForm.orderStatus" placeholder="订单状态,创建，部分出库，完成"></el-input>
    </el-form-item>
    <el-form-item label="订单来源方式:api,file" prop="sourceType">
        <el-input v-model="dataForm.sourceType" placeholder="订单来源方式:api,file"></el-input>
    </el-form-item>
    <el-form-item label="来源id: 交易号、文件id" prop="sourceId">
        <el-input v-model="dataForm.sourceId" placeholder="来源id: 交易号、文件id"></el-input>
    </el-form-item>
    <el-form-item label="创建时间" prop="productTime">
        <el-input v-model="dataForm.productTime" placeholder="创建时间"></el-input>
    </el-form-item>
    <el-form-item label="分仓时间" prop="dispatchTime">
        <el-input v-model="dataForm.dispatchTime" placeholder="分仓时间"></el-input>
    </el-form-item>
    <el-form-item label="发送到wms仓库时间" prop="releaseTime">
        <el-input v-model="dataForm.releaseTime" placeholder="发送到wms仓库时间"></el-input>
    </el-form-item>
    <el-form-item label="开始拣货时间" prop="pickingTime">
        <el-input v-model="dataForm.pickingTime" placeholder="开始拣货时间"></el-input>
    </el-form-item>
    <el-form-item label="拣货完成时间" prop="pickedTime">
        <el-input v-model="dataForm.pickedTime" placeholder="拣货完成时间"></el-input>
    </el-form-item>
    <el-form-item label="开始打包" prop="packingTime">
        <el-input v-model="dataForm.packingTime" placeholder="开始打包"></el-input>
    </el-form-item>
    <el-form-item label="打包完成时间" prop="packedTime">
        <el-input v-model="dataForm.packedTime" placeholder="打包完成时间"></el-input>
    </el-form-item>
    <el-form-item label="出库时间" prop="outboundedTime">
        <el-input v-model="dataForm.outboundedTime" placeholder="出库时间"></el-input>
    </el-form-item>
    <el-form-item label="运输出车时间" prop="shippedTime">
        <el-input v-model="dataForm.shippedTime" placeholder="运输出车时间"></el-input>
    </el-form-item>
    <el-form-item label="签收时间" prop="podTime">
        <el-input v-model="dataForm.podTime" placeholder="签收时间"></el-input>
    </el-form-item>
    <el-form-item label="取消时间" prop="cancelTime">
        <el-input v-model="dataForm.cancelTime" placeholder="取消时间"></el-input>
    </el-form-item>
    <el-form-item label="订单状态" prop="status">
        <el-input v-model="dataForm.status" placeholder="订单状态"></el-input>
    </el-form-item>
    <el-form-item label="创建时间" prop="createTime" v-if="dataForm.id">
        <el-input v-model="dataForm.createTime" placeholder="创建时间" disabled></el-input>
    </el-form-item>
    <el-form-item label="创建人" prop="createBy" v-if="dataForm.id">
        <el-input v-model="dataForm.createBy" placeholder="创建人" disabled></el-input>
    </el-form-item>
    <el-form-item label="更新时间" prop="updateTime" v-if="dataForm.id">
        <el-input v-model="dataForm.updateTime" placeholder="更新时间" disabled></el-input>
    </el-form-item>
    <el-form-item label="更新人" prop="updateBy" v-if="dataForm.id">
        <el-input v-model="dataForm.updateBy" placeholder="更新人" disabled></el-input>
    </el-form-item>
    <el-form-item label="删除标识0：未删除，1：已删除" prop="isDelete">
        <el-input v-model="dataForm.isDelete" placeholder="删除标识0：未删除，1：已删除"></el-input>
    </el-form-item>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="visible = false">取消</el-button>
      <el-button type="primary" @click="dataFormSubmit()" v-if="canSubmit">确定</el-button>
    </span>
  </el-dialog>
</template>

<script>
    import {getObj, addObj, putObj} from '@/api/outorder'

    export default {
    data () {
      return {
        visible: false,
        canSubmit: false,
        dataForm: {
          id: '',
          clientCode: '',
          orderNum: '',
          outOrderNum: '',
          addressId: '',
          expecedDeliveryDate: '',
          orderType: '',
          urgentLevel: '',
          orderStatus: '',
          sourceType: '',
          sourceId: '',
          productTime: '',
          dispatchTime: '',
          releaseTime: '',
          pickingTime: '',
          pickedTime: '',
          packingTime: '',
          packedTime: '',
          outboundedTime: '',
          shippedTime: '',
          podTime: '',
          cancelTime: '',
          status: '',
          createTime: '',
          createBy: '',
          updateTime: '',
          updateBy: '',
          isDelete: '',
        },
        dataRule: {
          clientCode: [
            { required: true, message: '客户代码不能为空', trigger: 'blur' }
          ],

          orderNum: [
            { required: true, message: '订单号不能为空', trigger: 'blur' }
          ],

          outOrderNum: [
            { required: true, message: '外部出库单号不能为空', trigger: 'blur' }
          ],

          addressId: [
            { required: true, message: '收货人地址id不能为空', trigger: 'blur' }
          ],

          expecedDeliveryDate: [
            { required: true, message: '期望发货时间不能为空', trigger: 'blur' }
          ],

          orderType: [
            { required: true, message: 'zcck,qtck不能为空', trigger: 'blur' }
          ],

          urgentLevel: [
            { required: true, message: '紧急单，普通单不能为空', trigger: 'blur' }
          ],

          orderStatus: [
            { required: true, message: '订单状态,创建，部分出库，完成不能为空', trigger: 'blur' }
          ],

          sourceType: [
            { required: true, message: '订单来源方式:api,file不能为空', trigger: 'blur' }
          ],

          sourceId: [
            { required: true, message: '来源id: 交易号、文件id不能为空', trigger: 'blur' }
          ],

          productTime: [
            { required: true, message: '创建时间不能为空', trigger: 'blur' }
          ],

          dispatchTime: [
            { required: true, message: '分仓时间不能为空', trigger: 'blur' }
          ],

          releaseTime: [
            { required: true, message: '发送到wms仓库时间不能为空', trigger: 'blur' }
          ],

          pickingTime: [
            { required: true, message: '开始拣货时间不能为空', trigger: 'blur' }
          ],

          pickedTime: [
            { required: true, message: '拣货完成时间不能为空', trigger: 'blur' }
          ],

          packingTime: [
            { required: true, message: '开始打包不能为空', trigger: 'blur' }
          ],

          packedTime: [
            { required: true, message: '打包完成时间不能为空', trigger: 'blur' }
          ],

          outboundedTime: [
            { required: true, message: '出库时间不能为空', trigger: 'blur' }
          ],

          shippedTime: [
            { required: true, message: '运输出车时间不能为空', trigger: 'blur' }
          ],

          podTime: [
            { required: true, message: '签收时间不能为空', trigger: 'blur' }
          ],

          cancelTime: [
            { required: true, message: '取消时间不能为空', trigger: 'blur' }
          ],

          status: [
            { required: true, message: '订单状态不能为空', trigger: 'blur' }
          ],

          isDelete: [
            { required: true, message: '删除标识0：未删除，1：已删除不能为空', trigger: 'blur' }
          ],

        }
      }
    },
    methods: {
      init (id) {
        this.visible = true;
        this.canSubmit = true;
        this.$nextTick(() => {
            this.$refs['dataForm'].resetFields()
            if (id) {
            getObj(id).then(response => {
                this.dataForm = response.data.data
            })
          }
        })
      },
      // 表单提交
      dataFormSubmit () {
        this.$refs['dataForm'].validate((valid) => {
          if (valid) {
            this.canSubmit = false;
            if (this.dataForm.id) {
                putObj(this.dataForm).then(data => {
                    this.$notify.success('修改成功')
                    this.visible = false
                    this.$emit('refreshDataList')
                }).catch(() => {
                    this.canSubmit = true;
                });
            } else {
                addObj(this.dataForm).then(data => {
                    this.$notify.success('添加成功')
                    this.visible = false
                    this.$emit('refreshDataList')
                }).catch(() => {
                    this.canSubmit = true;
                });
            }
          }
        })
      },
      //重置表单
      closeDialog() {
          this.$refs["dataForm"].resetFields()
      }
    }
  }
</script>
