<template>
  <div class="mod-config">
    <basic-container>
      <el-form :inline="true" :model="dataForm" @keyup.enter.native="getDataList()">
        <el-form-item>
          <el-button v-if="permissions.outbound_outorder_add" icon="el-icon-plus" type="primary" @click="addOrUpdateHandle()">新增</el-button>
        </el-form-item>
      </el-form>

      <div class="avue-crud">
        <el-table
                :data="dataList"
                border
                v-loading="dataListLoading">
            <el-table-column
                    prop="id"
                    header-align="center"
                    align="center"
                    label="主键">
            </el-table-column>
            <el-table-column
                    prop="clientCode"
                    header-align="center"
                    align="center"
                    label="客户代码">
            </el-table-column>
            <el-table-column
                    prop="orderNum"
                    header-align="center"
                    align="center"
                    label="订单号">
            </el-table-column>
            <el-table-column
                    prop="outOrderNum"
                    header-align="center"
                    align="center"
                    label="外部出库单号">
            </el-table-column>
            <el-table-column
                    prop="addressId"
                    header-align="center"
                    align="center"
                    label="收货人地址id">
            </el-table-column>
            <el-table-column
                    prop="expecedDeliveryDate"
                    header-align="center"
                    align="center"
                    label="期望发货时间">
            </el-table-column>
            <el-table-column
                    prop="orderType"
                    header-align="center"
                    align="center"
                    label="zcck,qtck">
            </el-table-column>
            <el-table-column
                    prop="urgentLevel"
                    header-align="center"
                    align="center"
                    label="紧急单，普通单">
            </el-table-column>
            <el-table-column
                    prop="orderStatus"
                    header-align="center"
                    align="center"
                    label="订单状态,创建，部分出库，完成">
            </el-table-column>
            <el-table-column
                    prop="sourceType"
                    header-align="center"
                    align="center"
                    label="订单来源方式:api,file">
            </el-table-column>
            <el-table-column
                    prop="sourceId"
                    header-align="center"
                    align="center"
                    label="来源id: 交易号、文件id">
            </el-table-column>
            <el-table-column
                    prop="productTime"
                    header-align="center"
                    align="center"
                    label="创建时间">
            </el-table-column>
            <el-table-column
                    prop="dispatchTime"
                    header-align="center"
                    align="center"
                    label="分仓时间">
            </el-table-column>
            <el-table-column
                    prop="releaseTime"
                    header-align="center"
                    align="center"
                    label="发送到wms仓库时间">
            </el-table-column>
            <el-table-column
                    prop="pickingTime"
                    header-align="center"
                    align="center"
                    label="开始拣货时间">
            </el-table-column>
            <el-table-column
                    prop="pickedTime"
                    header-align="center"
                    align="center"
                    label="拣货完成时间">
            </el-table-column>
            <el-table-column
                    prop="packingTime"
                    header-align="center"
                    align="center"
                    label="开始打包">
            </el-table-column>
            <el-table-column
                    prop="packedTime"
                    header-align="center"
                    align="center"
                    label="打包完成时间">
            </el-table-column>
            <el-table-column
                    prop="outboundedTime"
                    header-align="center"
                    align="center"
                    label="出库时间">
            </el-table-column>
            <el-table-column
                    prop="shippedTime"
                    header-align="center"
                    align="center"
                    label="运输出车时间">
            </el-table-column>
            <el-table-column
                    prop="podTime"
                    header-align="center"
                    align="center"
                    label="签收时间">
            </el-table-column>
            <el-table-column
                    prop="cancelTime"
                    header-align="center"
                    align="center"
                    label="取消时间">
            </el-table-column>
            <el-table-column
                    prop="status"
                    header-align="center"
                    align="center"
                    label="订单状态">
            </el-table-column>
            <el-table-column
                    prop="createTime"
                    header-align="center"
                    align="center"
                    label="创建时间">
            </el-table-column>
            <el-table-column
                    prop="createBy"
                    header-align="center"
                    align="center"
                    label="创建人">
            </el-table-column>
            <el-table-column
                    prop="updateTime"
                    header-align="center"
                    align="center"
                    label="更新时间">
            </el-table-column>
            <el-table-column
                    prop="updateBy"
                    header-align="center"
                    align="center"
                    label="更新人">
            </el-table-column>
            <el-table-column
                    prop="isDelete"
                    header-align="center"
                    align="center"
                    label="删除标识0：未删除，1：已删除">
            </el-table-column>
          <el-table-column
                  header-align="center"
                  align="center"
                  label="操作">
            <template slot-scope="scope">
              <el-button v-if="permissions.outbound_outorder_edit" type="text" size="small" icon="el-icon-edit" @click="addOrUpdateHandle(scope.row.id)">修改</el-button>
              <el-button v-if="permissions.outbound_outorder_del" type="text" size="small" icon="el-icon-delete" @click="deleteHandle(scope.row.id)">删除</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>

      <div class="avue-crud__pagination">
        <el-pagination
                @size-change="sizeChangeHandle"
                @current-change="currentChangeHandle"
                :current-page="pageIndex"
                :page-sizes="[10, 20, 50, 100]"
                :page-size="pageSize"
                :total="totalPage"
                background
                layout="total, sizes, prev, pager, next, jumper">
        </el-pagination>
      </div>
      <!-- 弹窗, 新增 / 修改 -->
      <table-form v-if="addOrUpdateVisible" ref="addOrUpdate" @refreshDataList="getDataList"></table-form>
    </basic-container>
  </div>
</template>

<script>
  import {fetchList, delObj} from '@/api/outorder'
  import TableForm from './outorder-form'
  import {mapGetters} from 'vuex'
  export default {
    data () {
      return {
        dataForm: {
          key: ''
        },
        dataList: [],
        pageIndex: 1,
        pageSize: 10,
        totalPage: 0,
        dataListLoading: false,
        addOrUpdateVisible: false
      }
    },
    components: {
      TableForm
    },
    created () {
      this.getDataList()
    },
    computed: {
      ...mapGetters(['permissions'])
    },
    methods: {
      // 获取数据列表
      getDataList () {
        this.dataListLoading = true
        fetchList(Object.assign({
          current: this.pageIndex,
          size: this.pageSize
        })).then(response => {
          this.dataList = response.data.data.records
          this.totalPage = response.data.data.total
        })
        this.dataListLoading = false
      },
      // 每页数
      sizeChangeHandle (val) {
        this.pageSize = val
        this.pageIndex = 1
        this.getDataList()
      },
      // 当前页
      currentChangeHandle (val) {
        this.pageIndex = val
        this.getDataList()
      },
      // 新增 / 修改
      addOrUpdateHandle (id) {
        this.addOrUpdateVisible = true
        this.$nextTick(() => {
          this.$refs.addOrUpdate.init(id)
        })
      },
      // 删除
      deleteHandle (id) {
        this.$confirm('是否确认删除ID为' + id, '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(function () {
          return delObj(id)
        }).then(data => {
          this.$message.success('删除成功')
          this.getDataList()
        }).catch(() => {})
      }
    }
  }
</script>
