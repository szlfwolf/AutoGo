<template>
  <basic-container>
    <div class="avue-crud content">
      <div>
        <div class="title">
          <span></span>
          <label>Order Info</label>
        </div>
        <div class="contain">
          <el-row >
            <el-col :xs="24" :sm="12" :md="12" :lg="12">
              <label>Tag:</label> 
              <span class="tagStyle" v-for="ite in rowParams.outOrderDto.tags">{{  ite }}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="12">
              <label>Status:</label>
              <span>{{ rowParams.outOrderDto.status }}</span>
            </el-col>
          </el-row>
          <el-row>
            <el-col :xs="24 " :sm="12" :md="12" :lg="6">
              <label>Owner:</label>
              <span>{{ rowParams.outOrderDto.clientCode }}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Order no:</label>
              <span ref="copy">{{ rowParams.outOrderDto.orderNum }}
                <i class="el-icon-document-copy copy" @click="clickCopy"></i>
              </span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>UrgentType:</label>
              <span>{{ rowParams.outOrderDto.urgentLevel }}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Order Type:</label>
              <span>{{ rowParams.outOrderDto.orderType }}</span>
            </el-col>
          </el-row>
          <el-row>
            <el-col :xs="24" :sm="12" :md="12" :lg="12">
              <label>Expected Delivery Date:</label>
              <span>{{ rowParams.outOrderDto.expectedDeliveryDate }}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="12">
              <label>Remark:</label>
              <span>{{ rowParams.outOrderDto.remark }}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>OMS ETA:</label>
              <span>{{ rowParams.outOrderDto.omsEta }}</span>
            </el-col>
          </el-row>
          <el-row>
            <el-col :xs="24" :sm="24" :md="24" :lg="24">
              <label>DN:</label>
              <!-- <span v-for="(ite,index) in rowParams.outOrderDto.shipInfo" class="cursorStyle" :key="index" v-if="permissions.outbound_dn_getDnDetail">
               <el-tag  @click="dnDetailClick(ite,index)" :type="index % 2 === 0? 'success':'warning'" effect="dark">{{ ite.dnNo }} ({{ ite.warehouseName  }})</el-tag>
              </span>
              <span v-for="(ite,index) in rowParams.outOrderDto.shipInfo" class="cursorStyle" :key="index" v-else>
               <el-tag :type="index % 2 === 0? 'success':'warning'" effect="dark">{{ ite.dnNo }} ({{ ite.warehouseName  }})</el-tag>
              </span>
              <span @click="dialogTrue" style="cursor: pointer;color: #599af8;font-size: 14px;text-decoration: underline;" >PFEP分配详情 >></span> -->
              <span v-if="permissions.outbound_dn_getDnDetail" class="cursorStyle">
               <el-tag  @click="dnDetailClick(item)" type="success" effect="dark" v-for="item in rowParams.outOrderDto.dnNo" style="margin-left: 5px;">{{ item }} </el-tag>
              </span>
              <span class="cursorStyle" v-else>
               <el-tag type="success" effect="dark">{{ rowParams.outOrderDto.dnNo }}</el-tag>
              </span>
              <span @click="dialogTrue" style="cursor: pointer;color: #599af8;font-size: 14px;text-decoration: underline;" >PFEP分配详情 >></span>
            </el-col>
          </el-row>
        </div>
      </div>
      <div>
        <div class="title">
          <span></span>
          <label>Address</label>
        </div>
        <div class="contain">
          <el-row>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Customer Number:</label>
              <span>{{rowParams.contactAddress.customerCode}}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Address ID:</label>
              <span>{{rowParams.contactAddress.id}}</span>
            </el-col>
          </el-row>
          <el-row>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>ConsigneeName:</label>
              <span>{{rowParams.contactAddress.contactName}}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>ConsigneeMobile:</label>
              <span>{{rowParams.contactAddress.contactPhone}}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>ConsigneeEmail:</label>
              <span>{{rowParams.contactAddress.contactEmail}}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Zipcode:</label>
              <span>{{rowParams.contactAddress.zipCode}}</span>
            </el-col>
          </el-row>
          <el-row>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Country:</label>
              <span>{{rowParams.contactAddress.countryName || rowParams.contactAddress.countryCode}}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>City:</label>
              <span>{{rowParams.contactAddress.cityName || rowParams.contactAddress.cityCode}}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Address:</label>
              <span>{{rowParams.contactAddress.address}}</span>
            </el-col>
          </el-row>
        </div>
      </div>
      <div>
        <div class="title">
          <span></span>
          <label>Ship Info</label>
        </div>
        <div class="contain">
          <el-row v-for="(ite,idx) in rowParams.outOrderDto.shipInfo" :key="idx">
            <div style="font-weight:500;margin-bottom:10px">dnNo:{{ite.dnNo}}</div>
            <el-col :xs="24" :sm="12" :md="12" :lg="6" >
              <label>ShiperName:</label>
              <span>{{ite.shipName}}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6" >
              <label>ShiperCode:</label>
              <span>{{ite.shipCode}}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>ShiperNo:</label>
              <span>{{ite.shipNo}}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>ShipStatus:</label>
              <span>{{ite.shipStatus}}</span>
            </el-col>
          </el-row>
        </div>
      </div>
      <div>
        <div class="title">
          <span></span>
          <label>Track</label>
        </div>
        <div class="contain">
          <el-row>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Create Time:</label>
              <span>{{rowParams.outOrderDto.productTime}}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Dispatch Time:</label>
              <span>{{rowParams.outOrderDto.dispatchTime}}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Release Time:</label>
              <span>{{rowParams.outOrderDto.releaseTime}}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Picking Time:</label>
              <span>{{rowParams.outOrderDto.pickingTime}}</span>
            </el-col>
          </el-row>
          <el-row>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Picked Time:</label>
              <span>{{rowParams.outOrderDto.pickedTime}}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Packing Time:</label>
              <span>{{rowParams.outOrderDto.packingTime}}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Packed Time:</label>
              <span>{{rowParams.outOrderDto.packedTime}}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Booked Time:</label>
              <span>{{rowParams.outOrderDto.bookedTime}}</span>
            </el-col>
          </el-row>
          <el-row>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Outbounded Time:</label>
              <span>{{rowParams.outOrderDto.outboundedTime}}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Cross dock Time:</label>
              <span></span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Completed Time:</label>
              <span>{{rowParams.outOrderDto.podTime}}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Cancel Time:</label>
              <span>{{rowParams.outOrderDto.cancelTime}}</span>
            </el-col>
          </el-row>
          <el-row>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Pending Time:</label>
              <span>{{rowParams.outOrderDto.pending}}</span>
            </el-col>
          </el-row>
        </div>
      </div>
      <div class="containBox">
        <div class="title">
          <span></span>
          <label>Order Line</label>
        </div>
        <div class="contain">
          <el-row style="width:200px;display:flex">
            <el-col>
              <el-button type="primary" icon="el-icon-search" @click="getSearchlist">Query</el-button>
            </el-col>
            <el-col>
              <el-button icon="el-icon-refresh-left" @click="getReset">Reset</el-button>
            </el-col>
          </el-row>
          <el-row>
            <el-form
              ref="form"
              :model="form"
              @keyup.enter.native="getSearchlist"
              style="margin: 20px 0"
            >
              <el-row :gutter="20">
                <el-col :span="4">
                  <el-input v-model="form.partNumber" placeholder="Sku no" clearable></el-input>
                </el-col>
                <el-col :span="4">
                  <el-select v-model="form.discrepancy" placeholder="Has Difference" filterable clearable>
                    <el-option
                      v-for="item in differenceList"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value"
                    >
                    </el-option>
                  </el-select>
                </el-col>
              </el-row>
            </el-form>
          </el-row>
        </div>
      </div>
      <div class="down">
        <el-button icon="el-icon-download" v-if="permissions.outbound_outorderline_export" @click="exportExcel"></el-button>
      </div>
      <el-table
        border
        ref="multipleTable"
        :data="tableData"
        tooltip-effect="dark"
        style="width: 100%"
        v-loading="dataListLoading"
        :header-cell-style="{ background: '#f5f7fa', color: '#606266', 'text-align':'center' }"
      >
        <el-table-column label="Warehouse" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.warehouseCode || '-' }}</template>
        </el-table-column>
        <el-table-column label="DN" show-overflow-tooltip>
          <template slot-scope="scope">
            <div class="underLine">
                <i :class="scope.row.discrepancy === '0' ? 'el-icon-check underIcon' :'el-icon-close underIconA'"></i>
                {{ scope.row.dnNo || '-' }}
            </div>
          </template>
        </el-table-column>
        <el-table-column label="Line no" align="center">
          <template slot-scope="scope">{{ scope.row.lineNo || '-' }}</template>
        </el-table-column>
        <el-table-column label="Sku no" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.partNumber || '-' }}</template>
        </el-table-column>
        <el-table-column label="Plan Qty" align="center">
          <template slot-scope="scope">{{ scope.row.planQty || '0' }}</template>
        </el-table-column>
        <el-table-column label="Actual Qty" align="center">
          <template slot-scope="scope">{{ scope.row.actualQty || '0' }}</template>
        </el-table-column>
        <el-table-column label="Difference" align="center">
          <template slot-scope="scope">{{ scope.row.planQty - scope.row.actualQty }}</template>
        </el-table-column>
        <el-table-column label="Unit" align="center">
          <template slot-scope="scope">{{ scope.row.unit || '-' }}</template>
        </el-table-column>
        <el-table-column label="Vin" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.vin || '-' }}</template>
        </el-table-column>
        <el-table-column label="Status" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.status || '-' }}</template>
        </el-table-column>
      </el-table>
      <Pagination
        @handleSizeChange="handleSizeChange"
        @handleCurrentChange="handleCurrentChange"
        :pageNum="page.current"
        :pageSize="page.size"
        :total="total"
      ></Pagination>
      <el-dialog
        title="PFEP LOG"
        :visible.sync="centerDialogVisible"
        width="30%"
        style="font-weight: 700"
      >
        <el-timeline class="timeline">
          <el-timeline-item
            v-for="(activity, index) in activities"
            :key="index"
            :icon="activity.icon"
            :type="activity.type"
            :color="activity.color"
            size="large"
          >
            <div class="box">
              <div class="boxTop">
                {{ activity.clientCode }}
                <span>{{ activity.createTime }}</span>
              </div>
              <div class="boxBottom">{{ activity.optionContent }}</div>
            </div>
          </el-timeline-item>
        </el-timeline>
      </el-dialog>
    </div>
  </basic-container>
</template>
<script>
import { mapGetters } from "vuex"
import Pagination from "@/components/pagination/pagination.vue"
import {getByOrderNum,getOutorderline} from "@/api/outbound/order"
import {getDnDetail} from "@/api/outbound/dn"
let formParams = {
  partNumber: undefined,
  discrepancy: undefined,
}
export default {
  name: "OrderDetail",
  data() {
    return {
      rowParams: {},
      form: Object.assign({}, formParams),
      page:{
        size: 10,
        current: 1,
      },
      centerDialogVisible: false,
      dataListLoading:false,
      total: 0,
      options: [],
      tableData: [],
      activities: [],
      differenceList: [
        {
          value:1,
          label:'Y'
        },{
          value:0,
          label:'N'
        }
      ],
      tag:[],
    }
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  components: {
    Pagination,
  },
  watch: {
    // 利用watch方法检测路由变化：
    $route: function(to, from) {
      // if (to.fullPath !== from.fullPath) {
      if(to.path=='/orderDetail/index' && to.query.row){
        if(to.query.row != from.query.row){
          this.rowParams = JSON.parse(to.query.row)
          // console.log(this.rowParams,'444444444');
          this.getList()
          if(this.rowParams.outOrderDto.tags){
            this.rowParams.outOrderDto.tags = this.rowParams.outOrderDto.tags.split(',')
            console.log(this.rowParams.outOrderDto.tags)
          }
        }
      }
      // }
    }
  },
  created() {
    if(this.$route.query.row){
      this.rowParams = JSON.parse(this.$route.query.row)
      this.getList()
      if(this.rowParams.outOrderDto.tags){
        this.rowParams.outOrderDto.tags = this.rowParams.outOrderDto.tags.split(',')
        console.log(this.rowParams.outOrderDto.tags)
      }
    }
  },
  mounted(){
    this.exportExcel = this.$btn(this.exportExcel,500)
    this.clickCopy = this.$btn(this.clickCopy,500)
  },
  methods: {
    //复制
    clickCopy() {
      let content = this.rowParams.outOrderDto.orderNum
      if(this.copy(content) === '文本为空'){
        this.$message.warning("Text is empty and cannot be copied !!!")
        return
      }
      this.$message.success("copy success")
    },
    //导出
    exportExcel() {
      this.downBlobFile("/outbound/outorderline/export", {...this.form,orderNum:this.rowParams.outOrderDto.orderNum}, "orderLine.xlsx")
    },
    //条数
    handleSizeChange(val) {
      this.page.current = 1
      this.page.size = val
      this.getList(this.form)
    },
    //当前页数
    handleCurrentChange(val) {
      this.page.current = val
      this.getList(this.form)
    },
    //清空                        
    getReset() {
      this.form = Object.assign({}, formParams)
      this.page = this.$options.data().page
      this.getSearchlist()
    },
    //查询
    getSearchlist() {
      this.page.current = 1
      for (let key in this.form) {
        if(this.form[key] === '' || this.form[key] === null){
          this.form[key] = undefined
        }
      }
      this.getList(this.form)
    },
    //数据列表
    getList(params){
      this.dataListLoading = true
      getOutorderline(Object.assign({...this.page},params,{orderNum:this.rowParams.outOrderDto.orderNum})).then(res=>{
        console.log(res)
        if(res.data.code === 0){
          this.tableData = res.data.data.records
          this.total = res.data.data.total
          this.dataListLoading = false
        }else{
          this.$message.error(res.data.msg)
          this.dataListLoading = false
        }
      })
    },
    //打开订单追踪弹窗
    dialogTrue() {
      getByOrderNum({clientCode: this.rowParams.outOrderDto.clientCode,orderNum:this.rowParams.outOrderDto.orderNum,type:'DN'}).then(res=>{
        console.log(res)
        if(res.data.code === 0){
          if(res.data.data.length > 0){
            this.centerDialogVisible = true
            this.activities = res.data.data
          }else{
            this.$message.warning('Not found temporarily '+`${this.rowParams.outOrderDto.orderNum}`+' PFEP allocation details of the order！')
          }
        }else{
          this.$message.error(res.data.msg)
        }
      })
    },
    //dn详情页
    dnDetailClick(val,index) {
      getDnDetail({dnNo:val}).then(res=>{
        console.log(res)
        if(res.data.code === 0){
          if(res.data.data.length>0){
            let dnDetail = res.data.data[0]
            this.$router.push({
              path: `/dnDetail`,
              query: {
                name:val,
                row: JSON.stringify(dnDetail)
              }
            })
          }else{
            this.$message.warning('No data for details')
          }
        }else{
          this.$message.warning(res.data.msg)
        }
      })
      // getDnDetail({dnNo:val.dnNo}).then(res=>{
      //   console.log(res)
      //   if(res.data.code === 0){
      //     if(res.data.data.length>0){
      //       let dnDetail = res.data.data[0]
      //       this.$router.push({
      //         path: `/dnDetail`,
      //         query: {
      //           name:val.dnNo,
      //           row: JSON.stringify(dnDetail)
      //         }
      //       })
      //     }else{
      //       this.$message.warning('No data for details')
      //     }
      //   }else{
      //     this.$message.warning(res.data.msg)
      //   }
      // })
    },
  },
}
</script>
<style lang="scss" scoped>
.content {
  width: 100%;
  //   padding: 20px;
  font-size: 13px;
  box-sizing: border-box;
  .title {
    width: 100%;
    height: 30px;
    line-height: 30px;
    display: flex;
    margin-bottom: 10px;
    span {
      width: 3px;
      height: 30px;
      background-color: #000;
      margin-right: 10px;
    }
    label {
      font-weight: 700;
    }
  }
  .containBox {
    border-bottom: 1px solid #999;
    margin-bottom: 20px;
  }
  .contain {
    padding: 10px;
    box-sizing: border-box;
    .tagStyle{
      display: inline-block;
      width: 25px;
      height: 25px;
      line-height: 25px;
      text-align: center;
      background-color: #BBBBBB;
      color: #fff;
      border-radius: 50%;
      margin-right: 5px;
    }
    .cursorStyle{
      margin-right: 10px;
      .el-tag{
        cursor: pointer;
        color: #fff;
      }
    }
    label {
      display: inline-block;
      margin-right: 5px;
      width:140px;
      text-align:right;
      vertical-align: middle;
    }
    span {
      color: #999;
      vertical-align: middle;
    }
  }
  .down {
    float: right;
    margin-bottom: 20px;
  }
  .timeline {
    padding: 10px;
    .box {
      background-color: #f4f6f7;
      border-radius: 5px;
      padding: 10px 20px;
      box-sizing: border-box;
      .boxTop {
        font-weight: 700;
        margin-bottom: 10px;
        span {
          margin-left: 10px;
        }
      }
      .boxBottom {
        color: #666;
        font-weight: normal;
      }
    }
  }
  .copy {
    cursor: pointer;
  }
  .underLine {
    cursor: pointer;
    color: #599af8;
    text-decoration: underline;
    .underIcon {
      background-color: rgb(137, 234, 137);
      color: #fff;
      border-radius: 50%;
      margin-right: 5px;
    }
    .underIconA {
      background-color: rgb(238, 99, 99);
      color: #fff;
      border-radius: 50%;
      margin-right: 5px;
    }
  }
  ::v-deep .el-dialog {
    border-radius: 8px !important;
  }
}
</style>
