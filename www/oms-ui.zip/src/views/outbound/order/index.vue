<template>
  <div class="content">
    <el-tabs type="border-card" @tab-click="tabClick" v-model="activeName">
      <el-tab-pane label="Overview" name="Overview" v-loading="orderLoading">
        <el-row style="width:200px;display:flex">
          <el-col>
            <el-button type="primary" icon="el-icon-search" @click="getSearchlist">Query</el-button>
          </el-col>
          <el-col>
            <el-button icon="el-icon-refresh-left" @click="getReset">Reset</el-button>
          </el-col>
        </el-row>
        <el-form ref="form" :model="form" @keyup.enter.native="getSearchlist" style="margin: 20px 0">
          <el-row :gutter="20">
            <el-col :span="4">
              <el-input placeholder="Order no" v-model="form.orderNum">
                <el-select filterable v-model="form.isAccurate" slot="prepend" class="common_select">
                  <el-option label="accurate" value="Y"></el-option>
                  <el-option label="dim" value="N"></el-option>
                </el-select>
              </el-input>
            </el-col>
            <el-col :span="4">
              <el-select v-model="form.status" placeholder="Status" filterable clearable>
                <el-option v-for="item in select.status" :key="item.value" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </el-col>
            <el-col :span="4">
              <el-select v-model="form.urgentLevel" placeholder="Urgent Type" filterable clearable>
                <el-option v-for="item in select.urgentType" :key="item.value" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </el-col>
            <el-col :span="4">
              <el-select v-model="form.orderType" placeholder="Order Type" filterable clearable>
                <el-option v-for="item in select.orderType" :key="item.value" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </el-col>
            <el-col :span="4">
              <el-select v-model="form.countryCode" placeholder="Country Code" filterable clearable>
                <el-option v-for="item in select.countryCode" :key="item.value" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </el-col>
            <el-col :span="4">
              <el-button style="float:right" type="primary" @click="about"
                :icon="show ? 'el-icon-arrow-up' : 'el-icon-arrow-down'">
                <label>{{ show ? "收起" : "更多" }}</label>
              </el-button>
            </el-col>
          </el-row>
          <transition name="slide-fade">
            <el-row v-show="show" style="margin-top: 10px" :gutter="20">
              <el-col :span="4">
                <el-select v-model="form.noInventoryType" placeholder="NO Inventory Type" filterable clearable>
                  <el-option v-for="item in select.noInventoryType" :key="item.value" :label="item.label"
                    :value="item.value">
                  </el-option>
                </el-select>
              </el-col>
              <el-col :span="4">
                <el-select v-model="form.tags" placeholder="Tags" filterable clearable>
                  <el-option v-for="item in select.tags" :key="item.value" :label="item.label" :value="item.value">
                  </el-option>
                </el-select>
              </el-col>
              <el-col :span="4">
                <el-date-picker v-model="time.createTime" type="daterange" start-placeholder="CreateTime"
                  end-placeholder="CreateEndTime" :default-time="['00:00:00', '23:59:59']"
                  value-format="yyyy-MM-dd HH:mm:ss" @change="changeCreateTime" />
              </el-col>
              <el-col :span="4">
                <el-date-picker v-model="time.releaseTime" type="daterange" start-placeholder="ReleaseTime"
                  end-placeholder="ReleaseEndTime" :default-time="['00:00:00', '23:59:59']"
                  value-format="yyyy-MM-dd HH:mm:ss" @change="changeReleaseTime">
                </el-date-picker>
              </el-col>
              <el-col :span="4">
                <el-date-picker v-model="time.packedTime" type="daterange" start-placeholder="PackedTime"
                  end-placeholder="PackedEndTime" :default-time="['00:00:00', '23:59:59']"
                  value-format="yyyy-MM-dd HH:mm:ss" @change="changePackedTime">
                </el-date-picker>
              </el-col>
            </el-row>
          </transition>
          <transition name="slide-fade">
            <el-row v-show="show" style="margin-top: 10px" :gutter="20">
              <el-col :span="4">
                <el-date-picker v-model="time.outboundedTime" type="daterange" start-placeholder="OutboundTime"
                  end-placeholder="OutboundEndTime" :default-time="['00:00:00', '23:59:59']"
                  value-format="yyyy-MM-dd HH:mm:ss" @change="changeOutboundedTime">
                </el-date-picker>
              </el-col>
              <el-col :span="4">
                <el-date-picker v-model="time.podTime" type="daterange" start-placeholder="PodTime"
                  end-placeholder="PodEndTime" :default-time="['00:00:00', '23:59:59']" value-format="yyyy-MM-dd HH:mm:ss"
                  @change="changePodTime">
                </el-date-picker>
              </el-col>
            </el-row>
          </transition>
        </el-form>
        <div class="down">
          <div>
            <el-button type="primary" icon="el-icon-s-home" @click="handleDispatch" :disabled="dispatchDisabled || releaseDisable"
              v-if="permissions.outorder_dispatch">Dispatch</el-button>
          </div>
          <el-button icon="el-icon-download" @click="exportExcel" v-if="permissions.outorder_export"></el-button>
        </div>
        <el-table border ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%"
          v-loading="dataListLoading" @selection-change="handleSelectionChange"
          :header-cell-style="{ background: '#f5f7fa', color: '#606266', 'text-align': 'center' }">
          <el-table-column type="selection" min-width="55" align="center"> </el-table-column>
          <el-table-column label="Owner" min-width="120" align="center">
            <template slot-scope="scope">{{ scope.row.clientCode || '-' }}</template>
          </el-table-column>
          <el-table-column label="Order no" min-width="160" show-overflow-tooltip>
            <template slot-scope="scope">
              <div class="underLine" @click="handleDetail(scope.$index, scope.row, 'order')"
                v-if="permissions.outbound_outorder_detail">
                <i
                  :class="(scope.row.status === 'PACKED' || scope.row.status === 'BOOKED' || scope.row.status === 'OUTBOUND' || scope.row.status === 'FINISHED') ? (scope.row.mark === '0' ? 'el-icon-check underIcon' : 'el-icon-close underIconA') : ''"></i>
                {{ scope.row.orderNum || '-' }}
              </div>
              <div v-else>
                {{ scope.row.orderNum || '-' }}
              </div>
            </template>
          </el-table-column>
          <el-table-column label="DN" min-width="160" show-overflow-tooltip>
            <template slot-scope="scope">
              <div class="underLine" @click="handleDetail(scope.$
              
              , scope.row, 'dn')"
                v-if="permissions.outbound_dn_getDnDetail">
                <i
                  :class="(scope.row.dnStatus === 'PACKED' || scope.row.dnStatus === 'BOOKED' || scope.row.dnStatus === 'OUTBOUND' || scope.row.dnStatus === 'FINISHED') ? (scope.row.dnMark === '0' ? 'el-icon-check underIcon' : 'el-icon-close underIconA') : ''"></i>
                {{ scope.row.dnNo || '-' }}
              </div>
              <div v-else>
                {{ scope.row.dnNo || '-' }}
              </div>
            </template>
          </el-table-column>
          <el-table-column label="UrgentType" min-width="120" align="center">
            <template slot-scope="scope">{{ scope.row.urgentLevel || '-' }}</template>
          </el-table-column>
          <el-table-column label="OrderType" min-width="120" align="center">
            <template slot-scope="scope">{{ scope.row.orderType || '-' }}</template>
          </el-table-column>
          <el-table-column label="Dispatch" min-width="140" fixed="right" align="center">
            <template slot-scope="scope">{{ scope.row.dispatchTime || '-' }}</template>
          </el-table-column>
          <el-table-column label="Release" min-width="140" fixed="right" align="center">
            <template slot-scope="scope">{{ scope.row.releaseTime || '-' }}</template>
          </el-table-column>
          <el-table-column label="Packed" min-width="140" fixed="right" align="center">
            <template slot-scope="scope">{{ scope.row.packedTime || '-' }}</template>
          </el-table-column>
          <el-table-column label="Booked" min-width="140" fixed="right" align="center">
            <template slot-scope="scope">{{ scope.row.bookedTime || '-' }}</template>
          </el-table-column>
          <el-table-column label="Outbound" min-width="140" fixed="right" align="center">
            <template slot-scope="scope">{{ scope.row.outboundedTime || '-' }}</template>
          </el-table-column>
          <el-table-column label="Pod" min-width="140" fixed="right" align="center">
            <template slot-scope="scope">{{ scope.row.podTime || '-' }}</template>
          </el-table-column>
          <el-table-column label="Ship Company Code" width="140" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.shipCompanyCode || "-" }}</template>
          </el-table-column>
          <el-table-column label="Ship no" min-width="120" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.shipNo || "-" }}</template>
          </el-table-column>
          <el-table-column label="Ship Status" min-width="120" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.shipStatus || "-" }}</template>
          </el-table-column>
          <el-table-column label="No Inventory Type" min-width="160" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ noInventoryType[scope.row.noInventoryType] || "-" }}</template>
          </el-table-column>
          <el-table-column label="Expected Delivery Date" min-width="160" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.expectedDeliveryDate || "-" }}</template>
          </el-table-column>
          <el-table-column label="Virtual Warehouse Code" min-width="160" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.virtualWarehouseCode || "-" }}</template>
          </el-table-column>
          <el-table-column label="Delivery Type" min-width="120" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ deliveryType[scope.row.deliveryType] || "-" }}</template>
          </el-table-column>
          <el-table-column label="Country Code" min-width="120" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.countryCode || "-" }}</template>
          </el-table-column>
          <el-table-column label="City Name" min-width="120" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.cityName || "-" }}</template>
          </el-table-column>
          <el-table-column label="Customer Code" min-width="120" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.customerCode || "-" }}</template>
          </el-table-column>
          <el-table-column label="Contact Name" min-width="120" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.contactName || "-" }}</template>
          </el-table-column>
          <el-table-column label="Contact Phone" min-width="120" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.contactPhone || "-" }}</template>
          </el-table-column>
          <el-table-column label="Contact Email" min-width="120" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.contactEmail || "-" }}</template>
          </el-table-column>
          <el-table-column label="Address" min-width="120" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.address || "-" }}</template>
          </el-table-column>
          <el-table-column label="ZIP Code" min-width="120" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.zipCode || "-" }}</template>
          </el-table-column>
          <el-table-column fixed="right" label="Status" min-width="120" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.status || '-' }}</template>
          </el-table-column>
        </el-table>
        <Pagination @handleSizeChange="handleSizeChange" @handleCurrentChange="handleCurrentChange"
          :pageNum="page.current" :pageSize="page.size" :total="total"></Pagination>
        <el-dialog title="Dispatch" :visible.sync="centerDialogVisible" width="30%" style="font-weight: 700"
          @close="getClose" :close-on-click-modal="false">
          <el-form ref="form" :rules="rules" :model="formDialog" label-width="100px">
            <el-form-item label="Warehouse:" prop="warehouseCode">
              <el-select v-model="formDialog.warehouseCode" placeholder="请选择仓库" filterable clearable>
                <el-option v-for="item in select.warehouseCode" :key="item.warehouseCode" :label="item.warehouseName"
                  :value="item.warehouseCode">
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="Remark:" prop="remark">
              <el-input type="textarea" v-model="formDialog.remark" placeholder="请输入" clearable></el-input>
            </el-form-item>
          </el-form>
          <span slot="footer" class="dialog-footer">
            <el-button type="info" @click="centerDialogVisible = false">Cancel</el-button>
            <el-button type="primary" @click="handleButton">Dispatch</el-button>
          </span>
        </el-dialog>
      </el-tab-pane>
      <el-tab-pane name="Pending">
        <span slot="label">Pending<el-badge :value="count" type="primary"></el-badge></span>
        <OrderPending v-if="pending" @pendingClick='pendingClick'></OrderPending>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>
<script>
import { mapGetters } from "vuex"
import Pagination from "@/components/pagination/pagination.vue"
import OrderPending from "./orderPending.vue"
import { pageQuery, getOrderNum, getDispatch, getPending, getWarehouse ,getWarehouseCode} from "@/api/outbound/order"
import { getDnDetail } from "@/api/outbound/dn"
import { remote } from "@/api/admin/dict"
let formParams = {
  orderNum: undefined,
  status: undefined,
  urgentLevel: undefined,
  orderType: undefined,
  countryCode: undefined,
  noInventoryType: undefined,
  tags: undefined,
  isAccurate: "Y"
}
let timeParams = {
  createTime: undefined,
  releaseTime: undefined,
  packedTime: undefined,
  outboundedTime: undefined,
  podTime: undefined,
}
export default {
  name: "Order",
  data() {
    return {
      activeName: "Overview",
      time: Object.assign({}, timeParams),
      form: Object.assign({}, formParams),
      page: {
        size: 10,
        current: 1,
      },
      total: 0,
      formDialog: {
        warehouseCode: "",
        remark: "",
      },
      dataListLoading: false,
      show: false, //更多
      tableData: [],
      multipleSelection: [],
      centerDialogVisible: false,
      select: {
        status: [],
        urgentType: [],
        orderType: [],
        countryCode: [],
        noInventoryType: [],
        warehouseCode: [],
        tags: []
      },//下拉列表字段
      dateRange: [],
      pending: false,
      count: 0,//pending数量
      orderNo: [],
      status: [],
      rules: {
        warehouseCode: [{ required: true, message: '请选择仓库', trigger: 'change' }],
        remark: [{ required: true, message: '请输入备注', trigger: 'blur' },
        { max: 255, message: '长度最大 255 个字符', trigger: 'blur' }]
      },
      dispatchDisabled: true,
      deliveryType: {
        0: "其他",
        1: "物流配送",
        2: "自提"
      },
      noInventoryType: {
        0: "整单无库存",
        1: "部分无库存",
        2: "无库存",
        3: "客户取消"
      },
      orderLoading: false,
      warehouseCodeList: [],
      releaseDisable: false
    }
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  components: {
    Pagination,
    OrderPending
  },
  created() {
    this.getList()
    this.getRemote()
    this.getPending()
  },
  mounted() {
    this.handleButton = this.$btn(this.handleButton, 500)
    this.exportExcel = this.$btn(this.exportExcel, 500)
  },
  methods: {
    //时间参数
    changeCreateTime(val) {
      if (val !== undefined && val !== null && val !== '' && val.length > 0) {
        this.$set(this.form, 'createStartTime', val[0])
        this.$set(this.form, 'createEndTime', val[1])
        // this.form.createStartTime = val[0]
        // this.form.createEndTime = val[1]
      } else {
        this.$set(this.form, 'createStartTime', undefined)
        this.$set(this.form, 'createEndTime', undefined)
      }
    },
    changeReleaseTime(val) {
      if (val !== undefined && val !== null && val !== '' && val.length > 0) {
        this.$set(this.form, 'releaseStartTime', val[0])
        this.$set(this.form, 'releaseEndTime', val[1])
      } else {
        this.$set(this.form, 'releaseStartTime', undefined)
        this.$set(this.form, 'releaseEndTime', undefined)
      }
    },
    changePackedTime(val) {
      if (val !== undefined && val !== null && val !== '' && val.length > 0) {
        this.$set(this.form, 'packedStartTime', val[0])
        this.$set(this.form, 'packedEndTime', val[1])
      } else {
        this.$set(this.form, 'packedStartTime', undefined)
        this.$set(this.form, 'packedEndTime', undefined)
      }
    },
    changeOutboundedTime(val) {
      if (val !== undefined && val !== null && val !== '' && val.length > 0) {
        this.$set(this.form, 'outboundedStartTime', val[0])
        this.$set(this.form, 'outboundedEndTime', val[1])
      } else {
        this.$set(this.form, 'outboundedStartTime', undefined)
        this.$set(this.form, 'outboundedEndTime', undefined)
      }
    },
    changePodTime(val) {
      if (val !== undefined && val !== null && val !== '' && val.length > 0) {
        this.$set(this.form, 'podStartTime', val[0])
        this.$set(this.form, 'podEndTime', val[1])
      } else {
        this.$set(this.form, 'podStartTime', undefined)
        this.$set(this.form, 'podEndTime', undefined)
      }
    },
    //切换tab
    tabClick() {
      if (this.activeName === 'Pending') {
        this.pending = true
      } else {
        this.pending = false
        this.getReset()//table数据
        this.getPending()
      }
    },
    //展开
    about() {
      this.show = !this.show
    },
    //条数
    handleSizeChange(val) {
      this.page.current = 1
      this.page.size = val
      this.getList(this.form)
    },
    //当前页数
    handleCurrentChange(val) {
      this.page.current = val
      this.getList(this.form)
    },
    //导出
    exportExcel() {
      this.orderLoading = true
      this.downBlobFile("/outbound/outorder/export", this.form, `${this.$store.state.common.commandName}-Order-${this.toDateFormat(new Date(), true)}.xlsx`, () => this.orderLoading = false)
    },
    //清空
    getReset() {
      this.form = Object.assign({}, formParams)
      this.time = Object.assign({}, timeParams)
      this.page = this.$options.data().page
      this.getList()
    },
    //查询
    getSearchlist() {
      this.page.current = 1
      for (let key in this.form) {
        if (this.form[key] === '' || this.form[key] === null) {
          this.form[key] = undefined
        }
      }
      this.getList(this.form)
    },
    //数据列表
    getList(params) {
      this.dataListLoading = true
      pageQuery(Object.assign({ ...this.page }, params)).then(res => {
        console.log(res)
        if (res.data.code == 0) {
          this.tableData = res.data.data.records
          this.total = res.data.data.total
          this.dataListLoading = false
        } else {
          this.$message.error(res.data.msg)
          this.dataListLoading = false
        }
      }).catch(() => {
        this.dataListLoading = false
      })
    },
    //多选
    handleSelectionChange(val) {
      this.multipleSelection = val
      // if(this.multipleSelection.length>1){
      //   this.$message.warning('Only one can be selected')
      // }
      // if (val.length > 1) {
      //   this.$refs.multipleTable.clearSelection()
      //   this.$refs.multipleTable.toggleRowSelection(val.pop())
      // }
      this.orderNo = []
      this.status = []
      this.warehouseCodeList = []
      this.multipleSelection.forEach(ite => {
        this.orderNo.push(ite.dnNo)
        this.status.push(ite.status)
        this.warehouseCodeList.push(ite.warehouseCode)
      })
      if (this.multipleSelection.length !== 0 && (this.status.indexOf('CREATED') !== -1 && new Set(this.status).size === 1)) {
        this.dispatchDisabled = false
      } else {
        this.dispatchDisabled = true
        if (this.multipleSelection.length !== 0) {
          this.$message.warning('The document cannot be dispatch because it is not in CREATED status')
        }
      }
      if(this.multipleSelection.length == 0) {
        this.releaseDisabled=false
      }
      getWarehouseCode({clientCode: this.$store.state.common.commandName,warehouseCodeList: this.warehouseCodeList.join(",")}).then(res => {
        if (res.data.code == 0) {
          this.releaseDisable = false
          this.select.warehouseCode = res.data.data
        }else {
            this.releaseDisable = true
          }
        })
    },
    //dispatch
    handleDispatch() {
      this.centerDialogVisible = true
    },
    handleButton() {
      this.$refs.form.validate((valid) => {
        if (!valid) return false
        getDispatch(Object.assign({ orderNos: this.orderNo }, this.formDialog)).then(res => {
          console.log(res)
          if (res.data.code === 0) {
            this.getList(this.form)
            this.getPending()
            this.$message.success('dispatch release')
            this.centerDialogVisible = false
          } else {
            this.getList(this.form)
            this.getPending()
            this.$message.warning(res.data.msg)
            this.centerDialogVisible = false
          }
        }).catch(err => {
          this.getList(this.form)
          this.getPending()
          this.centerDialogVisible = false
        })
      })
    },
    //关闭弹窗
    getClose() {
      this.formDialog = Object.assign({}, { warehouseCode: "", remark: "" })
      this.$refs.form.resetFields()
    },
    //下拉接口
    getRemote() {
      //status
      remote('dn_status').then(res => {
        if (res.data.code === 0) {
          this.select.status = res.data.data
        }
      })
      //urgentType
      remote('urgent_level').then(res => {
        if (res.data.code === 0) {
          this.select.urgentType = res.data.data
        }
      })
      //dnType
      remote('dn_type').then(res => {
        if (res.data.code === 0) {
          this.select.orderType = res.data.data
        }
      })
      //countryCode
      remote('country_code').then(res => {
        if (res.data.code === 0) {
          this.select.countryCode = res.data.data
        }
      })
      //noInventoryType
      remote('no_inventory_type').then(res => {
        if (res.data.code === 0) {
          this.select.noInventoryType = res.data.data
        }
      })
      //warehouse
      getWarehouse().then(res => {
        if (res.data.code === 0) {
          this.select.warehouseCode = res.data.data
        }
      })
      //tags
      remote('order_tag').then(res => {
        if (res.data.code === 0) {
          this.select.tags = res.data.data
        }
      })
    },
    getPending() {
      //获取pending数量
      getPending().then(res => {
        if (res.data.code === 0) {
          this.count = res.data.data
        }
      })
    },
    //子调父
    pendingClick() {
      this.getPending()
    },
    //跳转
    handleDetail(index, row, type) {
      if (type === "order") {
        getOrderNum({ orderNum: row.orderNum }).then(res => {
          console.log(res)
          if (res.data.code === 0) {
            if (res.data.data) {
              let orderDetail = res.data.data
              this.$router.push({
                path: `/orderDetail`,
                query: {
                  name: row.orderNum,
                  row: JSON.stringify(orderDetail),
                }
              })
            } else {
              this.$message.warning('No data for details')
            }
          } else {
            this.$message.error(res.data.msg)
          }
        })
      } else {
        getDnDetail({ dnNo: row.dnNo }).then(res => {
          console.log(res)
          if (res.data.code === 0) {
            if (res.data.data) {
              let dnDetail = res.data.data[0]
              this.$router.push({
                path: `/dnDetail`,
                query: {
                  name: row.dnNo,
                  row: JSON.stringify(dnDetail),
                }
              })
            } else {
              this.$message.warning('No data for details')
            }
          } else {
            this.$message.error(res.data.msg)
          }
        })
      }
    }
  }
}
</script>
<style lang="scss" scoped>
.content {
  padding: 0 10px;

  // box-sizing: border-box;
  .down {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    border-top: 1px solid #999;
    padding-top: 20px;
    box-sizing: border-box;
  }

  .underLine {
    cursor: pointer;
    color: #599af8;
    text-decoration: underline;

    .underIcon {
      background-color: rgb(137, 234, 137);
      color: #fff;
      border-radius: 50%;
      margin-right: 5px;
    }

    .underIconA {
      background-color: rgb(238, 99, 99);
      color: #fff;
      border-radius: 50%;
      margin-right: 5px;
    }
  }

  ::v-deep .el-dialog {
    border-radius: 8px !important;
  }

  ::v-deep .el-select--small {
    display: block;
  }

  // .slide-fade-enter-active {
  //   transition: all .3s ease;
  // }
  // .slide-fade-leave-active {
  //   transition: all .2s cubic-bezier(1.0, 0.5, 0.8, 1.0);
  // }
  // .slide-fade-enter, .slide-fade-leave-to
  // {
  //   opacity: 0;
  // }
  ::v-deep .el-date-editor--daterange.el-input,
  ::v-deep .el-date-editor--daterange.el-input__inner,
  ::v-deep .el-date-editor--timerange.el-input,
  ::v-deep .el-date-editor--timerange.el-input__inner {
    width: 100% !important;
  }

  // ::v-deep .el-table__header-wrapper  .el-checkbox{//找到表头那一行，然后把里面的复选框隐藏掉
  //   display:none
  // }
  .common_select {
    width: 80px;
  }
}
</style>
