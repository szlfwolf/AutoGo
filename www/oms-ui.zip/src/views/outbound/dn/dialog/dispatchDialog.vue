<template>
  <div>
    <el-dialog
      title="Dispatch"
      :visible="dispatchDialogShow"
      width="30%"
      style="font-weight: 700"
      @close="getClose"
      :close-on-click-modal="false"
    >
      <el-form
        ref="form"
        :rules="rules"
        :model="formDialog"
        label-width="100px"
      >
        <el-form-item label="Warehouse:" prop="warehouseCode">
          <el-select
            v-model="formDialog.warehouseCode"
            placeholder="请选择仓库"
            filterable
            clearable
          >
            <el-option
              v-for="item in warehouseCode"
              :key="item.warehouseCode"
              :label="item.warehouseName"
              :value="item.warehouseCode"
            >
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="Remark:" prop="remark">
          <el-input
            type="textarea"
            v-model="formDialog.remark"
            placeholder="请输入"
            clearable
          ></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button type="info" @click="getClose">Cancel</el-button>
        <el-button type="primary" @click="handleButton">Dispatch</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script>
import { getDispatch, getWarehouseCode } from "@/api/outbound/order"
export default {
  data() {
    return {
      formDialog:{
        warehouseCode:"",
        remark:""
      },
      warehouseCode:[],
      rules:{
        warehouseCode:[{ required: true, message: '请选择仓库', trigger: 'change' }],
        remark: [{ required: true, message: '请输入备注', trigger: 'blur' },
        { max: 255, message: '长度最大 255 个字符', trigger: 'blur' }]
      },
    };
  },
  props:{
    dispatchDialogShow:{
      type: Boolean
    },
    orderNo:{
      type: Array
    },
    warehouseCodeList: {
      type: Array
    }
  },
  created() {
    this.getSelect()
  },
  methods: {
    //关闭弹窗
    getClose() {
      this.$emit('close',false)
      this.formDialog = Object.assign({}, { warehouseCode: "", remark: "" })
      this.$refs.form.resetFields()
    },
    handleButton(){
      console.log(this.orderNo);
      this.$refs.form.validate( (valid) => {
        if (!valid) return false
        getDispatch(Object.assign({orderNos:this.orderNo},this.formDialog)).then(res=>{
          console.log(res)
          if(res.data.code === 0){
            this.$emit('close',false)
            this.$message.success('dispatch release')
          }else{
            this.$emit('close',false)
            this.$message.warning(res.data.msg)
          }
        }).catch(err=>{
          this.$emit('close',false)
        })
      })
    },
    getSelect(){
      //warehouse
      console.log("warehouseCodeList........",this.warehouseCodeList)
      this.warehouseCode = this.warehouseCodeList
      console.log("warehouseCode........",this.warehouseCode)
    }
  },
};
</script>
<style lang="scss" scoped></style>
