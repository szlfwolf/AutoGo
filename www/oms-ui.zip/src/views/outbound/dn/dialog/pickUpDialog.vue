<template>
  <div>
    <el-dialog
      :title="row.batchNo"
      :visible="dialogView"
      width="50%"
      style="font-weight: 700"
      @close="getClose"
    >
      <el-table
        ref="multipleTable"
        :data="row.packInfos"
        tooltip-effect="dark"
        style="width: 100%"
        :header-cell-style="{ background: '#f5f7fa', color: '#606266' }"
        border
      >
        <el-table-column label="Dn No" align="center" min-width="160px" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.dnNo || "-"}}</template>
          </el-table-column>
          <el-table-column label="Line No" min-width="160px" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.lineNo || "-"}}</template>
          </el-table-column>
          <el-table-column label="Package No" min-width="160px" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.packageNo || "-"}}</template>
          </el-table-column>
          <el-table-column label="Sku" min-width="160px" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.partNumber || "-"}}</template>
          </el-table-column>
          <el-table-column label="Num" min-width="120px" align="center">
            <template slot-scope="scope">{{ scope.row.num || "-"}}</template>
          </el-table-column>
      </el-table>

      <!-- <Pagination
        v-if="dialogView"
        @handleSizeChange="handleSizeChange"
        @handleCurrentChange="handleCurrentChange"
        :pageNum="page.current"
        :pageSize="page.size"
        :total="total"
      ></Pagination> -->
    </el-dialog>
  </div>
</template>
<script>
import Pagination from "@/components/pagination/pagination.vue";
export default {
  name: "Dialog",
  data() {
    return {
      page: {
        size: 10,
        current: 1,
      },
      total: 0,
    };
  },
  props: {
    dialogView:{
      type:Boolean
    },
    row:{
      type:Object
    }
  },
  components: {
    Pagination,
  },
  created() {},
  methods: {
    getClose() {  
      this.$emit("close", false);
      this.page.current = 1;
      this.page.size = 10;
    },
    //条数
    handleSizeChange(val) {
      this.page.current = 1;
      this.page.size = val;
      let obj = {
        info: Object.assign(this.info, {
          size: this.page.size,
          current: this.page.current,
        }),
      };
      this.$emit("handleDetail", obj);
    },
    //当前页数
    handleCurrentChange(val) {
      this.page.current = val;
      let obj = {
        info: Object.assign(this.info, {
          size: this.page.size,
          current: this.page.current,
        }),
      };
      this.$emit("handleDetail", obj);
    },
  },
};
</script>
<style lang="scss" scoped></style>
