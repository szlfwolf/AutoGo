<template>
  <basic-container>
    <div class="avue-crud content">
      <div>
        <div class="title">
          <span></span>
          <label>DN Info</label>
        </div>
        <div class="contain">
          <el-row>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Owner:</label>
              <span>{{ rowParams.dn.clientCode }}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>DN no:</label>
              <span>
                {{rowParams.dn.dnNo}}
                <i class="el-icon-document-copy copy" @click="clickCopy('dn_no')"></i>
              </span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Order no:</label>
              <span>
                {{ rowParams.dn.bzOutOrderNo }}
                <i class="el-icon-document-copy copy" @click="clickCopy('order_no')"></i>
              </span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Batch no:</label>
              <span>
                {{ rowParams.dn.batchNo }}
                <i class="el-icon-document-copy copy" @click="clickCopy('batch_no')"></i>
              </span>
            </el-col>
          </el-row>
          <el-row>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Warehouse:</label>
              <span>{{ rowParams.dn.warehouseCode }}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Order Type:</label>
              <span>{{ rowParams.dn.dnType }}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Urgent Type:</label>
              <span style="color: red">{{ rowParams.dn.urgentLevel }}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Remark:</label>
              <span>{{rowParams.dn.remark}}</span>
            </el-col>
          </el-row>
          <el-row>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>OMS ETA:</label>
              <span>{{ rowParams.dn.omsEta }}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Source:</label>
              <span>{{ rowParams.dn.sourceType }}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Status:</label>
              <span>{{ rowParams.dn.status }}</span>
            </el-col>
          </el-row>
          <el-row>
            <el-col :xs="24" :sm="12" :md="12" :lg="12">
              <label>Expected Delivery Date:</label>
              <span>{{rowParams.dn.expectedDeliveryDate}}</span>
            </el-col>
          </el-row>
        </div>
      </div>
      <div>
        <div class="title">
          <span></span>
          <label>Address</label>
        </div>
        <div class="contain">
          <el-row>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Customer Number:</label>
              <span>{{rowParams.contactAddress.customerCode}}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Address ID:</label>
              <span>{{rowParams.contactAddress.id}}</span>
            </el-col>
          </el-row>
          <el-row>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>ConsigneeName:</label>
              <span>{{rowParams.contactAddress.contactName}}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>ConsigneeMobile:</label>
              <span>{{rowParams.contactAddress.contactPhone}}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>ConsigneeEmail:</label>
              <span>{{rowParams.contactAddress.contactEmail}}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Zipcode:</label>
              <span>{{rowParams.contactAddress.zipCode}}</span>
            </el-col>
          </el-row>
          <el-row>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Country:</label>
              <span>{{rowParams.contactAddress.countryName || rowParams.contactAddress.countryCode}}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>City:</label>
              <span>{{rowParams.contactAddress.cityName || rowParams.contactAddress.cityCode}}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="12">
              <label>Address:</label>
              <span>{{rowParams.contactAddress.address}}</span>
            </el-col>
          </el-row>
        </div>
      </div>
      <div>
        <div class="title">
          <span></span>
          <label>Ship Info</label>
        </div>
        <div class="contain">
          <el-row>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>ShiperName:</label>
              <span>{{rowParams.dn.shipCompanyName}}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>ShiperCode:</label>
              <span>{{rowParams.dn.shipCompanyCode}}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>ShiperNo:</label>
              <span>{{rowParams.dn.shipNo}}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Ship Status:</label>
              <span>{{rowParams.dn.shipStatus}}</span>
            </el-col>
          </el-row>
        </div>
      </div>
      <div>
        <div class="title">
          <span></span>
          <label>Track</label>
        </div>
        <div class="contain">
          <el-row>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Create Time:</label>
              <span>{{rowParams.dn.productTime}}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Release Time:</label>
              <span>{{rowParams.dn.releaseTime}}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Picking Time:</label>
              <span>{{rowParams.dn.pickingTime}}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Picked Time:</label>
              <span>{{rowParams.dn.pickedTime}}</span>
            </el-col>
          </el-row>
          <el-row>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Packing Time:</label>
              <span>{{rowParams.dn.packingTime}}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Packed Time:</label>
              <span>{{rowParams.dn.packedTime}}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Booked Time:</label>
              <span>{{rowParams.dn.bookedTime}}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Outbounded Time:</label>
              <span>{{rowParams.dn.outboundedTime}}</span>
            </el-col>
          </el-row>
          <el-row>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Finish Time:</label>
              <span>{{rowParams.dn.podTime}}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Cancel Time:</label>
              <span>{{rowParams.dn.cancelTime}}</span>
            </el-col>
          </el-row>
        </div>
      </div>
      <div class="containBox">
        <div class="title">
          <span></span>
          <label>DN Line</label>
        </div>
        <div class="contain">
          <el-row style="width:200px;display:flex">
            <el-col>
              <el-button type="primary" icon="el-icon-search" @click="getSearchlist">Query</el-button>
            </el-col>
            <el-col>
              <el-button icon="el-icon-refresh-left" @click="getReset">Reset</el-button>
            </el-col>
          </el-row>
          <el-row>
            <el-form ref="form" :model="form" style="margin: 20px 0" @keyup.enter.native="getSearchlist">
              <el-row :gutter="20">
                <el-col :span="4">
                  <el-input v-model="form.partNumber" placeholder="Sku no" clearable></el-input>
                </el-col>
                <el-col :span="4">
                  <el-input v-model="form.packageNo" placeholder="Box no" clearable></el-input>
                </el-col>
                <el-col :span="4">
                  <el-select v-model="form.discrepancy" placeholder="Has Difference" filterable clearable>
                    <el-option
                      v-for="item in differenceList"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value"
                    >
                    </el-option>
                  </el-select>
                </el-col>
              </el-row>
            </el-form>
          </el-row>
        </div>
      </div>
      <div class="down">
        <el-button icon="el-icon-download" v-if="permissions.outbound_dnline_export" @click="exportExcel"></el-button>
      </div>
      <el-table
        border
        ref="multipleTable"
        :data="tableData"
        tooltip-effect="dark"
        style="width: 100%"
        v-loading="dataListLoading"
        :header-cell-style="{ background: '#f5f7fa', color: '#606266' }"
      >
        <el-table-column label="Line no" align="center">
          <template slot-scope="scope">{{ scope.row.lineNo || '-' }}</template>
        </el-table-column>
        <el-table-column label="Sku no" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.partNumber || '-' }}</template>
        </el-table-column>
        <el-table-column label="Plan Qty" align="center">
          <template slot-scope="scope">{{ scope.row.num || '0' }}</template>
        </el-table-column>
        <el-table-column label="Actual Qty" align="center">
          <template slot-scope="scope">{{ scope.row.actualNum || '0' }}</template>
        </el-table-column>
        <el-table-column label="Difference" align="center">
          <template slot-scope="scope">{{ scope.row.num - scope.row.actualNum }}</template>
        </el-table-column>
        <el-table-column label="Unit" align="center">
          <template slot-scope="scope">{{ scope.row.unit || '-' }}</template>
        </el-table-column>
        <el-table-column label="Vin" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.vin || '-' }}</template>
        </el-table-column>
        <el-table-column label="Box no" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.packageNo || '-' }}</template>
        </el-table-column>
      </el-table>
      <Pagination
        @handleSizeChange="handleSizeChange"
        @handleCurrentChange="handleCurrentChange"
        :pageNum="form.current"
        :pageSize="form.size"
        :total="total"
      ></Pagination>
    </div>
  </basic-container>
</template>
<script>
import { mapGetters } from "vuex"
import Pagination from "@/components/pagination/pagination.vue"
import {getDnline} from '@/api/outbound/dn'
export default {
  name: "dnDetail",
  data() {
    return {
      form: {
        partNumber: undefined,
        packageNo: undefined,
        discrepancy: undefined,
        size: 10,
        current: 1,
      },
      rowParams: {},
      total: 0,
      dataListLoading:false,
      differenceList: [
        {
          value:1,
          label:'Y'
        },{
          value:0,
          label:'N'
        }
      ],
      tableData: [],
    }
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  components: {
    Pagination,
  },
  watch: {
    // 利用watch方法检测路由变化：
    $route: function(to, from) {
      // if (to.fullPath !== from.fullPath) {
      //  if(to.query.row){
      //     this.rowParams = JSON.parse(to.query.row)
      //     console.log(this.rowParams,'444444444');
      //     this.getList()
      //  }
      // }
      if(to.path=='/dnDetail/index' && to.query.row){
        if(to.query.row != from.query.row){
          this.rowParams = JSON.parse(to.query.row)
          // console.log(this.rowParams,'444444444');
          this.getList()
        }
      }
    }
  },
  created() {
    if(this.$route.query.row){
      this.rowParams = JSON.parse(this.$route.query.row)
      this.getList()
    }
  },
  mounted(){
    this.exportExcel = this.$btn(this.exportExcel,500)
    this.clickCopy = this.$btn(this.clickCopy,500)
  },
  methods: {
    //复制
     clickCopy(type) {
      if (type === "dn_no") {
        let content = this.rowParams.dn.dnNo
        if(this.copy(content) === '文本为空'){
          this.$message.warning("Text is empty and cannot be copied !!!")
          return
        }
      } else if (type === "order_no") {
        let content = this.rowParams.dn.bzOutOrderNo
        if(this.copy(content) === '文本为空'){
          this.$message.warning("Text is empty and cannot be copied !!!")
          return
        }
      } else {
        let content = this.rowParams.dn.batchNo
        if(this.copy(content) === '文本为空'){
          this.$message.warning("Text is empty and cannot be copied !!!")
          return
        }
      }
      this.$message.success("copy success")
    },
    //导出
    exportExcel() {
      this.downBlobFile("/outbound/dnline/export", {...this.form,dnNo:this.rowParams.dn.dnNo}, "dnline.xlsx")
    },
    //清空
    getReset() {
      this.form = Object.assign({}, {partNumber: undefined, packageNo: undefined,discrepancy: undefined,size: 10,current: 1 })   
      this.getList()
    },
    //查询
    getSearchlist() {
      this.form.current = 1
      for (let key in this.form) {
        if(this.form[key] === '' || this.form[key] === null){
          this.form[key] = undefined
        }
      }
      this.getList()
    },
    //数据列表
    getList(){
      this.dataListLoading = true
      getDnline(Object.assign({...this.form},{dnNo:this.rowParams.dn.dnNo})).then(res=>{
        console.log(res)
        if(res.data.code == 0){
          this.tableData = res.data.data.records
          this.total = res.data.data.total
          this.dataListLoading = false
        }else{
          this.$message.error(res.data.msg)
          this.dataListLoading = false
        }
      })
    },
    //条数
    handleSizeChange(val) {
      this.form.current = 1
      this.form.size = val
      this.getList()
    },
    //当前页数
    handleCurrentChange(val) {
      this.form.current = val
      this.getList()
    },
  },
}
</script>
<style lang="scss" scoped>
.content {
  width: 100%;
  //   padding: 20px;
  font-size: 13px;
  box-sizing: border-box;
  .title {
    width: 100%;
    height: 30px;
    line-height: 30px;
    display: flex;
    margin-bottom: 10px;
    span {
      width: 3px;
      height: 30px;
      background-color: #000;
      margin-right: 10px;
    }
    label {
      font-weight: 700;
    }
  }
  .containBox {
    border-bottom: 1px solid #999;
    margin-bottom: 20px;
  }
  .contain {
    padding: 10px;
    box-sizing: border-box;
    label {
      display: inline-block;
      margin-right: 5px;
      width:135px;
      text-align:right;
      vertical-align: middle;
    }
    span {
      color: #999;
      vertical-align: middle;
    }
  }
  .down {
    float: right;
    margin-bottom: 20px;
  }
  .timeline {
    padding: 10px;
    .box {
      background-color: #f4f6f7;
      border-radius: 5px;
      padding: 10px 20px;
      box-sizing: border-box;
      .boxTop {
        font-weight: 700;
        margin-bottom: 10px;

        span {
          margin-left: 10px;
        }
      }
      .boxBottom {
        color: #666;
      }
    }
  }
  .copy {
    cursor: pointer;
  }
}
</style>
