<template>
  <div class="contentPending" v-loading="pendingLoading">
    <el-row style="width: 200px; display: flex">
      <el-col>
        <el-button type="primary" icon="el-icon-search" @click="getSearchlist">Query</el-button>
      </el-col>
      <el-col>
        <el-button icon="el-icon-refresh-left" @click="getReset">Reset</el-button>
      </el-col>
    </el-row>
    <el-form ref="form" :model="form" @keyup.enter.native="getSearchlist" style="margin: 20px 0">
      <el-row :gutter="20">
        <el-col :span="4">
          <el-input placeholder="DN no/Order no/Batch no" v-model="form.dnNo">
            <el-select v-model="form.isAccurate" slot="prepend" class="common_select">
              <el-option label="accurate" value="Y"></el-option>
              <el-option label="dim" value="N"></el-option>
            </el-select>
          </el-input>
        </el-col>
        <el-col :span="4">
          <el-select v-model="form.warehouseCode" placeholder="Warehouse" filterable clearable>
            <el-option v-for="item in select.warehouseCode" :key="item.value" :label="item.warehouseName"
              :value="item.warehouseCode">
            </el-option>
          </el-select>
        </el-col>
        <!-- <el-col :span="4">
          <el-select v-model="form.status" placeholder="Status" filterable clearable>
            <el-option
              v-for="item in select.status"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            >
            </el-option>
          </el-select>
        </el-col> -->
        <el-col :span="4">
          <el-select v-model="form.urgentLevel" placeholder="Urgent Type" filterable clearable>
            <el-option v-for="item in select.urgentType" :key="item.value" :label="item.label" :value="item.value">
            </el-option>
          </el-select>
        </el-col>
        <el-col :span="4">
          <el-select v-model="form.dnType" placeholder="DN Type" filterable clearable>
            <el-option v-for="item in select.dnType" :key="item.value" :label="item.label" :value="item.value">
            </el-option>
          </el-select>
        </el-col>
        <el-col :span="4">
          <el-select v-model="form.countryCode" placeholder="Country Code" filterable clearable>
            <el-option v-for="item in select.countryCode" :key="item.value" :label="item.label" :value="item.value">
            </el-option>
          </el-select>
        </el-col>
        <el-col :span="4">
          <el-button style="float: right" type="primary" @click="about"
            :icon="show ? 'el-icon-arrow-up' : 'el-icon-arrow-down'">
            <label for="">{{ show ? "收起" : "更多" }}</label>
          </el-button>
        </el-col>
      </el-row>
      <el-row v-show="show" style="margin-top: 10px" :gutter="20">
        <el-col :span="4">
          <el-select v-model="form.noInventoryType" placeholder="NO Inventory Type" filterable clearable>
            <el-option v-for="item in select.noInventoryType" :key="item.value" :label="item.label" :value="item.value">
            </el-option>
          </el-select>
        </el-col>
        <el-col :span="4">
          <el-input v-model="form.shipNo" placeholder="ShipNo" clearable></el-input>
        </el-col>
        <el-col :span="4">
          <el-input v-model="form.contactPhone" placeholder="Consignee Tel" clearable></el-input>
        </el-col>
        <el-col :span="4">
          <el-select v-model="form.sourceType" placeholder="Source" filterable clearable>
            <el-option v-for="item in select.source" :key="item.value" :label="item.label" :value="item.value">
            </el-option>
          </el-select>
        </el-col>
        <el-col :span="4">
          <el-date-picker v-model="time.createTime" type="daterange" start-placeholder="CreateTime"
            end-placeholder="CreateEndTime" :default-time="['00:00:00', '23:59:59']" value-format="yyyy-MM-dd HH:mm:ss"
            @change="changeCreateTime" />
        </el-col>
      </el-row>
      <el-row v-show="show" style="margin-top: 10px" :gutter="20">
        <el-col :span="4">
          <el-date-picker v-model="time.releaseTime" type="daterange" start-placeholder="ReleaseTime"
            end-placeholder="ReleaseEndTime" :default-time="['00:00:00', '23:59:59']" value-format="yyyy-MM-dd HH:mm:ss"
            @change="changeReleaseTime" />
        </el-col>
        <el-col :span="4">
          <el-date-picker v-model="time.packedTime" type="daterange" start-placeholder="PackedTime"
            end-placeholder="PackedEndTime" :default-time="['00:00:00', '23:59:59']" value-format="yyyy-MM-dd HH:mm:ss"
            @change="changePackedTime" />
        </el-col>
        <el-col :span="4">
          <el-date-picker v-model="time.outboundedTime" type="daterange" start-placeholder="OutboundedTime"
            end-placeholder="OutboundedEndTime" :default-time="['00:00:00', '23:59:59']"
            value-format="yyyy-MM-dd HH:mm:ss" @change="changeOutboundedTime" />
        </el-col>
        <el-col :span="4">
          <el-date-picker v-model="time.podTime" type="daterange" start-placeholder="PodTime" end-placeholder="PodEndTime"
            :default-time="['00:00:00', '23:59:59']" value-format="yyyy-MM-dd HH:mm:ss" @change="changePodTime" />
        </el-col>
      </el-row>
    </el-form>
    <div class="down">
      <div>
        <el-button type="primary" icon="el-icon-s-promotion" @click="handleEdit('release')"
          v-if="permissions.outbound_dn_release" :disabled="dispatchDisabled">Release</el-button>
        <el-button type="primary" icon="el-icon-link" @click="handleEdit('combine')"
          v-if="permissions.outbound_dn_combine" :disabled="dispatchDisabled">Combine</el-button>
        <el-button type="primary" icon="el-icon-s-home" @click="handleDispatch" :disabled="dispatchDisabled || releaseDisabled"
          v-if="permissions.outorder_dispatch">Dispatch</el-button>
      </div>
      <el-button icon="el-icon-download" @click="exportExcel" v-if="permissions.outbound_dn_export"></el-button>
    </div>
    <el-table border ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%"
      @selection-change="handleSelectionChange" v-loading="dataListLoading"
      :header-cell-style="{ background: '#f5f7fa', color: '#606266', 'text-align': 'center', }">
      <el-table-column type="selection" min-width="55" align="center"> </el-table-column>
      <el-table-column label="Owner" min-width="120" align="center">
        <template slot-scope="scope">{{ scope.row.clientCode || "-" }}</template>
      </el-table-column>
      <el-table-column label="Warehouse" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.warehouseName || "-" }}</template>
      </el-table-column>
      <el-table-column label="WarehouseCode" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.warehouseCode || "-" }}</template>
      </el-table-column>
      <el-table-column label="DN" min-width="160" show-overflow-tooltip>
        <template slot-scope="scope">
          <div class="underLine" @click="handleDetail(scope.$index, scope.row)"
            v-if="permissions.outbound_dn_getDnDetail">
            <i
              :class="scope.row.status === 'PACKED' || scope.row.status === 'BOOKED' || scope.row.status === 'OUTBOUND' ||
                scope.row.status === 'FINISHED' ? scope.row.mark === '0' ? 'el-icon-check underIcon' : 'el-icon-close underIconA' : ''"></i>
            {{ scope.row.dnNo || "-" }}
          </div>
          <div v-else>
            {{ scope.row.dnNo || "-" }}
          </div>
        </template>
      </el-table-column>
      <el-table-column label="Order no" min-width="160" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.bzOutOrderNo || "-" }}</template>
      </el-table-column>
      <el-table-column label="Batch no" min-width="160" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.batchNo || "-" }}</template>
      </el-table-column>
      <el-table-column label="DnType" min-width="120" align="center">
        <template slot-scope="scope">{{ scope.row.dnType || "-" }}</template>
      </el-table-column>
      <el-table-column label="UrgentType" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.urgentLevel || "-" }}</template>
      </el-table-column>
      <el-table-column label="Release" min-width="140" align="center" fixed="right">
        <template slot-scope="scope">{{ scope.row.releaseTime || "-" }}</template>
      </el-table-column>
      <el-table-column label="Packed" min-width="140" align="center" fixed="right">
        <template slot-scope="scope">{{ scope.row.packedTime || "-" }}</template>
      </el-table-column>
      <el-table-column label="Booked" min-width="140" align="center" fixed="right">
        <template slot-scope="scope">{{ scope.row.bookedTime || "-" }}</template>
      </el-table-column>
      <el-table-column label="Outbound" min-width="140" align="center" fixed="right">
        <template slot-scope="scope">{{ scope.row.outboundedTime || "-" }}</template>
      </el-table-column>
      <el-table-column label="Pod" min-width="140" align="center" fixed="right">
        <template slot-scope="scope">{{ scope.row.podTime || "-" }}</template>
      </el-table-column>
      <el-table-column label="Ship Company Code" width="140" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.shipCompanyCode || "-" }}</template>
      </el-table-column>
      <el-table-column label="Ship no" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.shipNo || "-" }}</template>
      </el-table-column>
      <el-table-column label="Ship Status" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.shipStatus || "-" }}</template>
      </el-table-column>
      <el-table-column label="No Inventory Type" min-width="160" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ noInventoryType[scope.row.noInventoryType] || "-" }}</template>
      </el-table-column>
      <el-table-column label="Expected Delivery Date" min-width="160" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.expectedDeliveryDate || "-" }}</template>
      </el-table-column>
      <el-table-column label="Virtual Warehouse Code" min-width="160" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.virtualWarehouseCode || "-" }}</template>
      </el-table-column>
      <el-table-column label="Delivery Type" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ deliveryType[scope.row.deliveryType] || "-" }}</template>
      </el-table-column>
      <el-table-column label="Country Code" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.countryCode || "-" }}</template>
      </el-table-column>
      <el-table-column label="City Name" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.cityName || "-" }}</template>
      </el-table-column>
      <el-table-column label="Customer Code" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.customerCode || "-" }}</template>
      </el-table-column>
      <el-table-column label="Contact Name" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.contactName || "-" }}</template>
      </el-table-column>
      <el-table-column label="Contact Phone" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.contactPhone || "-" }}</template>
      </el-table-column>
      <el-table-column label="Contact Email" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.contactEmail || "-" }}</template>
      </el-table-column>
      <el-table-column label="Address" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.address || "-" }}</template>
      </el-table-column>
      <el-table-column label="ZIP Code" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.zipCode || "-" }}</template>
      </el-table-column>
      <el-table-column fixed="right" label="Status" min-width="120" align="center">
        <template slot-scope="scope">{{ scope.row.status || "-" }}</template>
      </el-table-column>
      <el-table-column fixed="right" label="Opearter" align="center"
        v-if="permissions.outbound_dn_updateRemark || permissions.sys_BizRecord_get">
        <template slot-scope="scope">
          <i v-if="permissions.sys_BizRecord_get"
            style="font-size: 18px; cursor: pointer; color: #65beff; margin-right: 10px" class="el-icon-info"
            @click="handleSee(scope.$index, scope.row)"></i>
          <i v-if="permissions.outbound_dn_updateRemark" style="font-size: 18px; cursor: pointer; color: #65beff"
            class="el-icon-edit" @click="handleEdit('edit', scope.$index, scope.row)"></i>
        </template>
      </el-table-column>
    </el-table>
    <Pagination @handleSizeChange="handleSizeChange" @handleCurrentChange="handleCurrentChange" :pageNum="page.current"
      :pageSize="page.size" :total="total"></Pagination>
    <el-dialog :title="title" :visible.sync="formDialog.centerDialogVisible" width="35%" style="font-weight: 700"
      @close="getClose" :close-on-click-modal="title === 'Edit'">
      <el-form :model="formDialog" ref="releaseForm" :rules="remarkRules" label-width="100px" v-if="title === 'Edit'">
        <el-form-item label="Remark:" prop="remark">
          <el-input type="textarea" v-model="formDialog.remark" placeholder="请输入..." clearable></el-input>
        </el-form-item>
      </el-form>
      <div v-show="title === 'Release'">
        Are you sure to send selected {{ this.multipleSelection.length }} DNS to warehouse?
      </div>
      <div v-show="title === 'Combine'">
        Are you sure to combine the selected {{ this.multipleSelection.length }} DNS and send them to WMS?
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="info" @click="formDialog.centerDialogVisible = false">Cancel</el-button>
        <el-button type="primary" @click="dialogButton">{{ title === "Edit" ? "Submit" : "Release" }}</el-button>
      </span>
    </el-dialog>
    <AllDrawer v-if="AllDrawer" :AllDrawer="AllDrawer" @handleClose="handleClose" :AllDrawerObj="AllDrawerObj"
      @AllDrawerDetail="AllDrawerDetail" :AllDrawerRow="AllDrawerRow"></AllDrawer>
    <DisptachDialog v-if="dispatchDialogShow" :dispatchDialogShow="dispatchDialogShow"  :warehouseCodeList="warehouseCodeList" @close="close" :orderNo="orderNo">
    </DisptachDialog>
  </div>
</template>
<script>
import { mapGetters } from "vuex";
import Pagination from "@/components/pagination/pagination.vue";
import AllDrawer from "@/views/outbound/dn/drawer/allDrawer.vue";
import { pageQuery, getEditQuery, getDnDetail, getRelease, getCombine, getWarehouse, bizRecordPage, getCheck, } from "@/api/outbound/dn";
import { remote } from "@/api/admin/dict";
import {getWarehouseCode} from "@/api/outbound/order";
import DisptachDialog from "./dialog/dispatchDialog.vue"
let formParams = {
  dnNo: undefined,
  warehouseCode: undefined,
  status: "CREATED",
  urgentLevel: undefined,
  dnType: undefined,
  countryCode: undefined,
  noInventoryType: undefined,
  sourceType: undefined,
  isAccurate: "Y"
};
export default {
  name: "DnPending",
  data() {
    return {
      time: {
        createTime: undefined,
        releaseTime: undefined,
        packedTime: undefined,
        outboundedTime: undefined,
        podTime: undefined,
      },
      activeName: "Overview",
      form: Object.assign({}, formParams),
      page: {
        size: 10,
        current: 1,
        status: "CREATED",
      },
      total: 0,
      formDialog: {
        centerDialogVisible: false,
        remark: "",
        id: "", //打开编辑当前数据id
      },
      title: "",
      show: false, //更多
      tableData: [],
      multipleSelection: [],
      dataListLoading: false,
      select: {
        warehouseCode: [],
        status: [],
        urgentType: [],
        dnType: [],
        countryCode: [],
        noInventoryType: [],
        source: [],
      }, //下拉列表字段
      dnNos: [],
      status: [],
      remarkRules: {
        remark: [
          { required: true, message: "请输入备注", trigger: "blur" },
          { max: 255, message: "长度最大 255 个字符", trigger: "blur" },
        ],
      },
      dispatchDisabled: true,
      AllDrawer: false,
      AllDrawerObj: {},
      AllDrawerRow: {},
      deliveryType: {
        0: "其他",
        1: "物流配送",
        2: "自提"
      },
      noInventoryType: {
        0: "整单无库存",
        1: "部分无库存",
        2: "无库存",
        3: "客户取消"
      },
      dispatchDialogShow: false,
      orderNo: [],
      pendingLoading: false,
      warehouseCodeList: [],
      releaseDisabled: false
    };
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  components: {
    Pagination,
    AllDrawer,
    DisptachDialog
  },
  created() {
    this.getList(); //table数据
    this.getRemote(); //下拉列表数据
  },
  mounted() {
    this.dialogButton = this.$btn(this.dialogButton, 500)
    this.exportExcel = this.$btn(this.exportExcel, 500)
  },
  watch: {
    total: function () {
      this.$emit("pendingClick");
    },
  },
  methods: {
    //时间参数
    changeCreateTime(val) {
      if (val !== undefined && val !== null && val !== "" && val.length > 0) {
        this.$set(this.form, "beginCreateTime", val[0]);
        this.$set(this.form, "endCreateTime", val[1]);
      } else {
        this.$set(this.form, "beginCreateTime", undefined);
        this.$set(this.form, "endCreateTime", undefined);
      }
    },
    changeReleaseTime(val) {
      if (val !== undefined && val !== null && val !== "" && val.length > 0) {
        this.$set(this.form, "beginReleaseTime", val[0]);
        this.$set(this.form, "endReleaseTime", val[1]);
      } else {
        this.$set(this.form, "beginReleaseTime", undefined);
        this.$set(this.form, "endReleaseTime", undefined);
      }
    },
    changePackedTime(val) {
      if (val !== undefined && val !== null && val !== "" && val.length > 0) {
        this.$set(this.form, "beginPackedTime", val[0]);
        this.$set(this.form, "endPackedTime", val[1]);
      } else {
        this.$set(this.form, "beginPackedTime", undefined);
        this.$set(this.form, "endPackedTime", undefined);
      }
    },
    changeOutboundedTime(val) {
      if (val !== undefined && val !== null && val !== "" && val.length > 0) {
        this.$set(this.form, "beginOutboundedTime", val[0]);
        this.$set(this.form, "endOutboundedTime", val[1]);
      } else {
        this.$set(this.form, "beginOutboundedTime", undefined);
        this.$set(this.form, "endOutboundedTime", undefined);
      }
    },
    changePodTime(val) {
      if (val !== undefined && val !== null && val !== "" && val.length > 0) {
        this.$set(this.form, "beginPodTime", val[0]);
        this.$set(this.form, "endPodTime", val[1]);
      } else {
        this.$set(this.form, "beginPodTime", undefined);
        this.$set(this.form, "endPodTime", undefined);
      }
    },
    //展开
    about() {
      this.show = !this.show;
    },
    //条数
    handleSizeChange(val) {
      this.page.current = 1;
      this.page.size = val;
      this.getList(this.form);
    },
    //当前页数
    handleCurrentChange(val) {
      this.page.current = val;
      this.getList(this.form);
    },
    //导出
    exportExcel() {
      this.pendingLoading = true
      this.downBlobFile("/outbound/dn/export", { ...this.form, option: "pending" }, `${this.$store.state.common.commandName}-DnPending-${this.toDateFormat(new Date(), true)}.xlsx`, () => this.pendingLoading = false)
    },
    //清空
    getReset() {
      this.form = Object.assign({}, formParams);
      this.page = this.$options.data().page;
      this.time = {};
      this.getList();
    },
    //查询
    getSearchlist() {
      this.page.current = 1;
      for (let key in this.form) {
        if (this.form[key] === "" || this.form[key] === null) {
          this.form[key] = undefined;
        }
      }
      this.getList(this.form);
    },
    //数据列表
    getList(params) {
      this.dataListLoading = true;
      pageQuery(Object.assign({ ...this.page }, params)).then((res) => {
        console.log(res);
        if (res.data.code === 0) {
          this.tableData = res.data.data.records;
          this.total = res.data.data.total;
          this.dataListLoading = false;
        } else {
          this.$message.error(res.data.msg);
          this.dataListLoading = false;
        }
      }).catch(() => {
        this.$message.error("request was aborted");
        this.dataListLoading = false;
      });
    },

    //多选
    handleSelectionChange(val) {
      this.multipleSelection = val;
      this.dnNos = [];
      this.status = [];
      this.orderNo = [];
      this.warehouseCodeList = [];
      this.multipleSelection.forEach((ite) => {
        this.dnNos.push(ite.dnNo);
        this.status.push(ite.status);
        this.orderNo.push(ite.dnNo);
        this.warehouseCodeList.push(ite.warehouseCode)
      });
      if (this.multipleSelection.length !== 0 && this.status.indexOf("CREATED") !== -1 && new Set(this.status).size === 1) {
        this.dispatchDisabled = false;
      } else {
        this.dispatchDisabled = true;
        if (this.multipleSelection.length !== 0) {
          this.$message.warning("The document cannot be release or combine because it is not in CREATED status");
        }
      }
      if(this.multipleSelection.length == 0) {
        this.releaseDisabled=false
      }
      getWarehouseCode({clientCode: this.$store.state.common.commandName,warehouseCodeList: this.warehouseCodeList.join(",")}).then(res => {
        if (res.data.code == 0) {
          this.warehouseCodeList= res.data.data
          this.releaseDisabled=false
        } else{
          this.releaseDisabled=true
        }
      })
    },
    //打开弹窗
    handleEdit(title, index, row) {
      this.formDialog.centerDialogVisible = true;
      console.log(row);
      if (title === "edit") {
        this.title = "Edit";
        this.formDialog.remark = row.remark;
        this.formDialog.id = row.dnNo;
        this.$refs.multipleTable.clearSelection();
      } else if (title === "release") {
        this.title = "Release";
      } else {
        this.title = "Combine";
      }
    },
    //编辑
    dialogButton() {
      if (this.title === 'Edit') {
        this.$refs.releaseForm.validate((valid) => {
          if (!valid) return false
          getEditQuery({ dnNo: this.formDialog.id, remark: this.formDialog.remark }).then(res => {
            console.log(res)
            if (res.data.code === 0) {
              this.$message.success("Edit succeeded")
              this.getList(this.form)
              this.formDialog.centerDialogVisible = false
            }
          })
        })
      } else if (this.title === 'Release') {
        getCheck(this.dnNos).then(res => {
          if (res.data.code === 0) {
            getRelease(this.dnNos).then(res => {
              if (res.data.code === 0) {
                this.$message.success("Release succeeded")
                this.getList(this.form)
                this.$emit("pendingClick")
                this.formDialog.centerDialogVisible = false
              } else {
                this.getList(this.form)
                this.$emit("pendingClick")
                this.$message.error(res.data.msg)
                this.formDialog.centerDialogVisible = false
              }
            }).catch(err => {
              this.getList(this.form)
              this.$emit("pendingClick")
              this.formDialog.centerDialogVisible = false
            })
          } else {
            this.formDialog.centerDialogVisible = false
            res.data.data = res.data.data.map(item => {
              return item + "<br/>"
            })
            this.$confirm(`${res.data.data}?`, 'Tips', {
              confirmButtonText: 'submit',
              cancelButtonText: 'cancel',
              type: 'warning',
              customClass: 'myClass'
            }).then(() => {
              getRelease(this.dnNos).then(res => {
                if (res.data.code === 0) {
                  this.$message.success("Release succeeded")
                  this.getList(this.form)
                  this.$emit("pendingClick")
                  this.formDialog.centerDialogVisible = false
                } else {
                  this.getList(this.form)
                  this.$emit("pendingClick")
                  this.$message.error(res.data.msg)
                  this.formDialog.centerDialogVisible = false
                }
              }).catch(err => {
                this.getList(this.form)
                this.$emit("pendingClick")
                this.formDialog.centerDialogVisible = false
              })
            }).catch(() => {
              this.$message({ type: "info", message: "Operation canceled", });
            });
          }
        })
      } else {
        getCheck(this.dnNos).then(res => {
          if (res.data.code === 0) {
            getCombine(this.dnNos).then(res => {
              if (res.data.code === 0) {
                this.$message.success("Combine succeeded")
                this.getList(this.form)
                this.$emit("pendingClick")
                this.formDialog.centerDialogVisible = false
              } else {
                this.getList(this.form)
                this.$emit("pendingClick")
                this.$message.error(res.data.msg)
                this.formDialog.centerDialogVisible = false
              }
            }).catch(err => {
              this.getList(this.form)
              this.$emit("pendingClick")
              this.formDialog.centerDialogVisible = false
            })
          } else {
            this.formDialog.centerDialogVisible = false
            res.data.data = res.data.data.map(item => {
              return item + "<br/>"
            })
            this.$confirm(`${res.data.data}?`, 'Tips', {
              confirmButtonText: 'submit',
              cancelButtonText: 'cancel',
              type: 'warning',
              customClass: 'myClass'
            }).then(() => {
              getCombine(this.dnNos).then(res => {
                if (res.data.code === 0) {
                  this.$message.success("Combine succeeded")
                  this.getList(this.form)
                  this.$emit("pendingClick")
                  this.formDialog.centerDialogVisible = false
                } else {
                  this.getList(this.form)
                  this.$emit("pendingClick")
                  this.$message.error(res.data.msg)
                  this.formDialog.centerDialogVisible = false
                }
              }).catch(err => {
                this.getList(this.form)
                this.$emit("pendingClick")
                this.formDialog.centerDialogVisible = false
              })
            }).catch(() => {
              this.$message({ type: "info", message: "Operation canceled", });
            });
          }
        });
      }
    },
    //关闭弹窗
    getClose() {
      if (this.title === "Edit") {
        this.$refs.releaseForm.resetFields();
      }
    },
    //查看错误详情
    handleSee(index, row) {
      this.AllDrawerRow = { ...row, current: 1, size: 10 };
      bizRecordPage({ type: "DN", orderNum: row.dnNo, dnNum: row.dnNo, current: row.current || 1, size: row.size || 10, }).then((res) => {
        console.log(res);
        if (res.data.code === 0) {
          if (!res.data.data.records.length) {
            this.AllDrawer = false;
            this.$message.warning(`单号${row.dnNo}没有错误日志`);
          } else {
            this.AllDrawer = true;
            this.AllDrawerObj = res.data.data;
          }
        } else {
          this.$message.error(res.data.msg);
        }
      });
    },
    //dispatch
    handleDispatch() {
      this.dispatchDialogShow = true
    },
    //关闭dispatch弹窗
    close(e) {
      this.dispatchDialogShow = e
      this.getList()
      this.$emit("pendingClick");
    },
    //关闭详情
    handleClose(e) {
      this.AllDrawer = e;
    },
    AllDrawerDetail(e) {
      console.log(e.AllDrawerRow);
      this.handleSee("", e.AllDrawerRow);
    },
    //跳转
    handleDetail(index, row) {
      console.log(row);
      getDnDetail({ dnNo: row.dnNo }).then((res) => {
        if (res.data.code === 0) {
          if (res.data.data.length > 0) {
            console.log(res);
            let dnDetail = res.data.data[0];
            this.$router.push({
              path: `/dnDetail`,
              query: {
                name: row.dnNo,
                row: JSON.stringify(dnDetail),
              },
            });
          } else {
            this.$message.warning("No data for details");
          }
        } else {
          console.log(res);
          this.$message.error(res.data.msg);
        }
      });
    },
    //下拉接口
    getRemote() {
      //warehouse
      getWarehouse().then((res) => {
        if (res.data.code === 0) {
          this.select.warehouseCode = res.data.data;
        }
      });
      //status
      remote("dn_status").then((res) => {
        if (res.data.code === 0) {
          this.select.status = res.data.data.filter((ite) => ite.value === "CREATED" || ite.value === "DISPATCHED");
        }
      });
      //urgentType
      remote("urgent_level").then((res) => {
        if (res.data.code === 0) {
          this.select.urgentType = res.data.data;
        }
      });
      //dnType
      remote("dn_type").then((res) => {
        if (res.data.code === 0) {
          this.select.dnType = res.data.data;
        }
      });
      //countryCode
      remote("country_code").then((res) => {
        if (res.data.code === 0) {
          this.select.countryCode = res.data.data;
        }
      });
      //noInventoryType
      remote("no_inventory_type").then((res) => {
        if (res.data.code === 0) {
          this.select.noInventoryType = res.data.data;
        }
      });
      //source
      remote("source_type").then((res) => {
        if (res.data.code === 0) {
          this.select.source = res.data.data;
        }
      });
    },
  },
};
</script>
<style lang="scss" scoped>
.contentPending {

  // padding: 0 10px;
  // box-sizing: border-box;
  .down {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    border-top: 1px solid #999;
    padding-top: 20px;
    box-sizing: border-box;
  }

  .underLine {
    cursor: pointer;
    color: #599af8;
    text-decoration: underline;

    .underIcon {
      background-color: rgb(137, 234, 137);
      color: #fff;
      border-radius: 50%;
      margin-right: 5px;
    }

    .underIconA {
      background-color: rgb(238, 99, 99);
      color: #fff;
      border-radius: 50%;
      margin-right: 5px;
    }
  }

  .common_select {
    width: 80px;
  }
}
</style>
