<template>
  <div >
    <el-drawer
      :title="'单号: '+AllDrawerObj.records[0].orderNum"
      :visible.sync="AllDrawer"
      :direction="direction"
      :before-close="handleClose"
      style="font-weight: 700"
      size="50%"
      >
        <el-table
          ref="multipleTable"
          :data="AllDrawerObj.records"
          tooltip-effect="dark"
          style="width: 100%"
          :header-cell-style="{ background: '#f5f7fa', color: '#606266' }"
          border
        >
          <el-table-column label="Type" align="center" min-width="160px" show-overflow-tooltip>
              <template slot-scope="scope">{{ scope.row.type || "-"}}</template>
            </el-table-column>
            <!-- <el-table-column label="OrderNum" min-width="160px" align="center" show-overflow-tooltip>
              <template slot-scope="scope">{{ scope.row.orderNum || "-"}}</template>
            </el-table-column> -->
            <el-table-column label="Body" min-width="160px" align="center" show-overflow-tooltip>
              <template slot-scope="scope">{{ JSON.parse(scope.row.body) || "-"}}</template>
            </el-table-column>
            <el-table-column label="Response" min-width="160px" align="center" show-overflow-tooltip>
              <template slot-scope="scope">{{ scope.row.response || "-"}}</template>
            </el-table-column>
            <el-table-column label="Num" min-width="120px" align="center">
              <template slot-scope="scope">{{ scope.row.num || "0"}}</template>
            </el-table-column>
            <el-table-column label="Url" min-width="120px" align="center" show-overflow-tooltip>
              <template slot-scope="scope">{{ scope.row.url || "-"}}</template>
            </el-table-column>
            <el-table-column label="CreateTime" min-width="120px" align="center" show-overflow-tooltip>
              <template slot-scope="scope">{{ scope.row.createTime || "-"}}</template>
            </el-table-column>
            <el-table-column label="CreateBy" min-width="120px" align="center">
              <template slot-scope="scope">{{ scope.row.createBy || "-"}}</template>
            </el-table-column>
        </el-table>
        <Pagination
        @handleSizeChange="handleSizeChange"
        @handleCurrentChange="handleCurrentChange"
        :pageNum="page.current"
        :pageSize="page.size"
        :total="AllDrawerObj.total"
      ></Pagination>
    </el-drawer>
  </div>
</template>
<script>
import Pagination from "@/components/pagination/pagination.vue";
export default {
  name: "AllDrawer",
  data() {
    return {
      page: {
        size: 10,
        current: 1,
      },
      total: 0,
      direction: 'rtl',
    };
  },
  props: {
    AllDrawer:{
      type:Boolean
    },
    AllDrawerObj:{
      type:Object
    },
    AllDrawerRow:{
      type:Object
    }
  },
  components: {
    Pagination,
  },
  created() {},
  methods: {
    handleClose() {
      this.$emit("handleClose", false);
      this.page.current = 1;
      this.page.size = 10;
    },
    //条数
    handleSizeChange(val) {
      this.page.current = 1;
      this.page.size = val;
      let obj = {
        AllDrawerRow: Object.assign(this.AllDrawerRow, {
          size: this.page.size,
          current: this.page.current,
        }),
      };
      this.$emit("AllDrawerDetail", obj);
      
    },
    //当前页数
    handleCurrentChange(val) {
      this.page.current = val;
      let obj = {
        AllDrawerRow: Object.assign(this.AllDrawerRow, {
          size: this.page.size,
          current: this.page.current,
        }),
      };
      this.$emit("AllDrawerDetail", obj);
    },
    
  },
};
</script>
<style lang="scss" scoped>
::v-deep .el-drawer__body{
  padding: 10px;
}
</style>
