<template>
  <div class="contentPending" v-loading="transferLoading">
    <el-row style="width: 200px; display: flex">
      <el-col>
        <el-button type="primary" icon="el-icon-search" @click="getSearchlist">Query</el-button>
      </el-col>
      <el-col>
        <el-button icon="el-icon-refresh-left" @click="getReset">Reset</el-button>
      </el-col>
    </el-row>
    <el-form ref="form" :model="form" @keyup.enter.native="getSearchlist" style="margin: 20px 0">
      <el-row :gutter="20">
        <el-col :span="4">
          <el-input v-model="form.batchNo" placeholder="Batch no" clearable></el-input>
        </el-col>
        <el-col :span="4">
          <el-select v-model="form.countryCode" placeholder="Country Code" filterable clearable>
            <el-option v-for="item in client" :key="item.value" :label="item.value" :value="item.value">
            </el-option>
          </el-select>
        </el-col>
        <el-col :span="4">
          <el-date-picker v-model="pickUpTime" type="daterange" start-placeholder="Begin Picked Time"
            end-placeholder="End Packed Time" :default-time="['00:00:00', '23:59:59']" value-format="yyyy-MM-dd HH:mm:ss"
            @change="changePickUpTime" />
        </el-col>
      </el-row>
    </el-form>
    <div class="down">
      <div></div>
      <el-button icon="el-icon-download" @click="exportExcel" v-if="permissions.tranfer_dn_pickup_export"></el-button>
    </div>
    <el-table border ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%"
      v-loading="dataListLoading"
      :header-cell-style="{ background: '#f5f7fa', color: '#606266', 'text-align': 'center', }">
      <!-- <el-table-column type="selection" width="55" align="center"> </el-table-column> -->
      <el-table-column label="Batch no" align="center" min-width="160" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.batchNo || "-" }}</template>
      </el-table-column>
      <el-table-column label="Client" min-width="120" align="center">
        <template slot-scope="scope">{{ scope.row.clientCode || "-" }}</template>
      </el-table-column>
      <el-table-column label="Warehouse" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.warehouseCode || "-" }}</template>
      </el-table-column>
      <el-table-column label="Order Type" align="center" min-width="160" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.dnType || "-" }}</template>
      </el-table-column>
      <el-table-column label="Country Code" align="center" min-width="120">
        <template slot-scope="scope">{{ scope.row.countryCode || "-" }}</template>
      </el-table-column>
      <el-table-column label="Dock" align="center" min-width="120">
        <template slot-scope="scope">{{ scope.row.dockNo || "-" }}</template>
      </el-table-column>
      <el-table-column label="PckedTime" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.packedTime || "-" }}</template>
      </el-table-column>
      <el-table-column label="Packed Qty" min-width="120" align="center">
        <template slot-scope="scope">{{ scope.row.packQty || "-" }}</template>
      </el-table-column>
      <el-table-column label="Ship Company Code" min-width="140" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.shipCompanyCode || "-" }}</template>
      </el-table-column>
      <el-table-column label="Ship no" width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.shipNo || "-" }}</template>
      </el-table-column>
      <el-table-column label="Ship Status" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.shipStatus || "-" }}</template>
      </el-table-column>
      <el-table-column label="No Inventory Type" min-width="140" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ noInventoryType[scope.row.noInventoryType] || "-" }}</template>
      </el-table-column>
      <el-table-column label="Expected Delivery Date" min-width="160" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.expectedDeliveryDate || "-" }}</template>
      </el-table-column>
      <el-table-column label="Virtual Warehouse Code" min-width="160" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.virtualWarehouseCode || "-" }}</template>
      </el-table-column>
      <el-table-column label="Delivery Type" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ deliveryType[scope.row.deliveryType] || "-" }}</template>
      </el-table-column>
      <el-table-column label="Country Code" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.countryCode || "-" }}</template>
      </el-table-column>
      <el-table-column label="City Name" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.cityName || "-" }}</template>
      </el-table-column>
      <el-table-column label="Customer Code" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.customerCode || "-" }}</template>
      </el-table-column>
      <el-table-column label="Contact Name" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.contactName || "-" }}</template>
      </el-table-column>
      <el-table-column label="Contact Phone" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.contactPhone || "-" }}</template>
      </el-table-column>
      <el-table-column label="Contact Email" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.contactEmail || "-" }}</template>
      </el-table-column>
      <el-table-column label="Address" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.address || "-" }}</template>
      </el-table-column>
      <el-table-column label="ZIP Code" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.zipCode || "-" }}</template>
      </el-table-column>
      <el-table-column fixed="right" label="Order Status" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.status || "-" }}</template>
      </el-table-column>
      <!-- v-if="permissions.tranfer_dn_pickup" -->
      <el-table-column fixed="right" label="Opearter" align="center" min-width="140px">
        <template slot-scope="scope">
          <i v-if="permissions.sys_BizRecord_get"
            style="font-size: 18px; cursor: pointer; color: #65beff; margin-right: 10px" class="el-icon-info"
            @click="handleSee(scope.$index, scope.row)"></i>
          <i style="font-size: 18px; cursor: pointer; color: #65beff; margin-right: 10px" class="el-icon-view"
            @click="handleEdit('see', scope.$index, scope.row)"></i>
          <i v-if="permissions.tranfer_dn_pickup" style="font-size: 18px; cursor: pointer; color: #65beff"
            class="el-icon-wallet" @click="handleEdit('edit', scope.$index, scope.row)"></i>
        </template>
      </el-table-column>
    </el-table>
    <Pagination @handleSizeChange="handleSizeChange" @handleCurrentChange="handleCurrentChange" :pageNum="page.current"
      :pageSize="page.size" :total="total"></Pagination>
    <el-dialog title="Pick Up" :visible.sync="formDialog.centerDialogVisible" width="35%" style="font-weight: 700"
      @close="getClose" :close-on-click-modal="false">
      <el-form :model="formDialog" ref="releaseForm" :rules="remarkRules" label-width="120">
        <el-form-item label="Batch no:">
          <el-input v-model="formDialog.batchNo" disabled></el-input>
        </el-form-item>
        <el-form-item label="Pick Up Time:" prop="outboundedTime">
          <el-date-picker type="datetime" v-model="formDialog.outboundedTime" placeholder="Pick Up Time"
            value-format="yyyy-MM-dd HH:mm:ss" />
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button type="info" @click="formDialog.centerDialogVisible = false">Cancel</el-button>
        <el-button type="primary" @click="dialogButton">Confirm</el-button>
      </span>
    </el-dialog>
    <PickUpDialog :dialogView="dialogView" :row="row" @close="close"></PickUpDialog>
    <AllDrawer v-if="AllDrawer" :AllDrawer="AllDrawer" @handleClose="handleClose" :AllDrawerObj="AllDrawerObj"
      @AllDrawerDetail="AllDrawerDetail" :AllDrawerRow="AllDrawerRow"></AllDrawer>
  </div>
</template>
<script>
import { mapGetters } from "vuex";
import Pagination from "@/components/pagination/pagination.vue";
import PickUpDialog from "./dialog/pickUpDialog.vue";
import AllDrawer from "@/views/outbound/dn/drawer/allDrawer.vue";
import { pageQuery, pickUpPage, pickUpUpdate, bizRecordPage } from "@/api/outbound/dn";
import { remote } from "@/api/admin/dict";

let formParams = {
  batchNo: undefined,
  countryCode: undefined,
};
export default {
  name: "DnTransfer",
  data() {
    return {
      form: Object.assign({}, formParams),
      page: {
        size: 10,
        current: 1,
      },
      total: 0,
      formDialog: {
        centerDialogVisible: false,
        batchNo: "",
        outboundedTime: "",
      },
      tableData: [],
      multipleSelection: [],
      dataListLoading: false,
      client: [],
      dnNos: [],
      status: [],
      remarkRules: {
        outboundedTime: [
          { required: true, message: "请选择outboundedTime", trigger: "blur" },
        ],
      },
      dispatchDisabled: true,
      row: {},
      pickUpTime: "",
      dialogView: false,
      AllDrawer: false,
      AllDrawerObj: {},
      AllDrawerRow: {},
      deliveryType: {
        0: "其他",
        1: "物流配送",
        2: "自提"
      },
      noInventoryType: {
        0: "整单无库存",
        1: "部分无库存",
        2: "无库存",
        3: "客户取消"
      },
      transferLoading: false
    };
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  components: {
    Pagination,
    PickUpDialog,
    AllDrawer,
  },
  created() {
    this.getList(); //table数据
    this.getRemote(); //下拉列表数据
  },
  mounted() {
    this.dialogButton = this.$btn(this.dialogButton, 500);
    this.exportExcel = this.$btn(this.exportExcel, 500);
  },
  watch: {
    total: function () {
      this.$emit("transferClick");
      console.log("total发生了改变");
    },
  },
  methods: {
    //时间参数
    changePickUpTime(val) {
      if (val !== undefined && val !== null && val !== "" && val.length > 0) {
        this.$set(this.form, "beginPickedTime", val[0]);
        this.$set(this.form, "endPickedTime", val[1]);
      } else {
        this.$set(this.form, "beginPickedTime", undefined);
        this.$set(this.form, "endPickedTime", undefined);
      }
    },
    //条数
    handleSizeChange(val) {
      this.page.current = 1;
      this.page.size = val;
      this.getList(this.form);
    },
    //当前页数
    handleCurrentChange(val) {
      this.page.current = val;
      this.getList(this.form);
    },
    //导出
    exportExcel() {
      this.transferLoading = true
      this.downBlobFile("/outbound/dn/pickUpExport", { ...this.form }, `${this.$store.state.common.commandName}-TR Picked Up-${this.toDateFormat(new Date(), true)}.xlsx`, () => this.transferLoading = false);
    },
    //清空
    getReset() {
      this.form = Object.assign({}, formParams);
      this.page = this.$options.data().page
      this.pickUpTime = "";
      this.getList();
    },
    //查询
    getSearchlist() {
      this.page.current = 1;
      for (let key in this.form) {
        if (this.form[key] === "" || this.form[key] === null) {
          this.form[key] = undefined;
        }
      }
      this.getList(this.form);
    },
    //数据列表
    getList(params) {
      this.dataListLoading = true;
      pickUpPage(Object.assign({ ...this.page }, params)).then((res) => {
        console.log(res);
        if (res.data.code === 0) {
          let qty = 0
          res.data.data.records.forEach(ite => {
            ite.packInfos.forEach((item, idx) => {
              if (item.num) {
                ite.packQty = Number(item.num) + qty
              }
            })
          })
          this.tableData = res.data.data.records;
          this.total = res.data.data.total;
          this.dataListLoading = false;
        } else {
          this.$message.error(res.data.msg);
          this.dataListLoading = false;
        }
      }).catch(() => {
        this.dataListLoading = false;
      });
    },
    //打开弹窗
    handleEdit(type, index, row) {
      this.row = row;
      if (type === "see") {
        this.dialogView = true;
      } else {
        this.formDialog.centerDialogVisible = true;
        this.formDialog.batchNo = row.batchNo;
        // this.$set(this.formDialog,'pickUpTime',row.outboundedTime)
        this.formDialog.outboundedTime = row.outboundedTime;
        console.log(this.formDialog.pickUpTime);
      }
    },
    //编辑
    dialogButton() {
      this.$refs.releaseForm.validate((valid) => {
        if (!valid) return false;
        pickUpUpdate({ ...this.row, ...this.formDialog })
          .then((res) => {
            console.log(res);
            if (res.data.code === 0) {
              this.$message.success("Signed in successfully");
              this.getList(this.form);
              this.formDialog.centerDialogVisible = false;
              this.$emit('transferClick');
            } else {
              this.$message.error(res.data.msg);
              this.formDialog.centerDialogVisible = false;
            }
          })
          .catch((err) => {
            this.formDialog.centerDialogVisible = false;
          });
      });
    },
    //关闭弹窗
    getClose() {
      this.$refs.releaseForm.resetFields();
    },
    //子传父
    close(e) {
      this.dialogView = e;
    },
    //查看错误详情
    handleSee(index, row) {
      this.AllDrawerRow = { ...row, current: 1, size: 10 };
      bizRecordPage({ type: "DN", orderNum: row.dnNo, dnNum: row.dnNo, current: row.current || 1, size: row.size || 10, }).then((res) => {
        console.log(res);
        if (res.data.code === 0) {
          if (!res.data.data.records.length) {
            this.AllDrawer = false;
            this.$message.warning(`单号${row.dnNo}没有错误日志`);
          } else {
            this.AllDrawer = true;
            this.AllDrawerObj = res.data.data;
          }
        } else {
          this.$message.error(res.data.msg);
        }
      });
    },
    //关闭详情
    handleClose(e) {
      this.AllDrawer = e;
    },
    AllDrawerDetail(e) {
      console.log(e.AllDrawerRow);
      this.handleSee("", e.AllDrawerRow);
    },
    //下拉接口
    getRemote() {
      remote("country_code").then((res) => {
        if (res.data.code === 0) {
          this.client = res.data.data;
        }
      });
    },
  },
};
</script>
<style lang="scss" scoped>
.contentPending {

  // padding: 0 10px;
  // box-sizing: border-box;
  .down {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    border-top: 1px solid #999;
    padding-top: 20px;
    box-sizing: border-box;
  }

  .underLine {
    cursor: pointer;
    color: #599af8;
    text-decoration: underline;

    .underIcon {
      background-color: rgb(137, 234, 137);
      color: #fff;
      border-radius: 50%;
      margin-right: 5px;
    }

    .underIconA {
      background-color: rgb(238, 99, 99);
      color: #fff;
      border-radius: 50%;
      margin-right: 5px;
    }
  }

  ::v-deep .el-date-editor.el-input,
  ::v-deep .el-date-editor.el-input__inner {
    width: 100% !important;
  }
}
</style>
