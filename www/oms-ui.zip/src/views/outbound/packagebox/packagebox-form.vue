<template>
  <el-dialog
    :title="!dataForm.id ? '新增' : '修改'"
    append-to-body
    :close-on-click-modal="false"
    @close="closeDialog()"
    :visible.sync="visible">
    <el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="dataFormSubmit()" label-width="80px">
    <el-form-item label="主键" prop="id" v-if="dataForm.id">
        <el-input v-model="dataForm.id" placeholder="主键" disabled></el-input>
    </el-form-item>
    <el-form-item label="客户代码" prop="clientCode">
        <el-input v-model="dataForm.clientCode" placeholder="客户代码"></el-input>
    </el-form-item>
    <el-form-item label="仓库代码" prop="warehouseCode">
        <el-input v-model="dataForm.warehouseCode" placeholder="仓库代码"></el-input>
    </el-form-item>
    <el-form-item label="合单号/dn号" prop="batchNo">
        <el-input v-model="dataForm.batchNo" placeholder="合单号/dn号"></el-input>
    </el-form-item>
    <el-form-item label="箱号" prop="packageNo">
        <el-input v-model="dataForm.packageNo" placeholder="箱号"></el-input>
    </el-form-item>
    <el-form-item label="箱子净重（公斤）" prop="netWeight">
        <el-input v-model="dataForm.netWeight" placeholder="箱子净重（公斤）"></el-input>
    </el-form-item>
    <el-form-item label="箱子毛重（公斤）" prop="grossWeight">
        <el-input v-model="dataForm.grossWeight" placeholder="箱子毛重（公斤）"></el-input>
    </el-form-item>
    <el-form-item label="箱子长度（米）" prop="lenght">
        <el-input v-model="dataForm.lenght" placeholder="箱子长度（米）"></el-input>
    </el-form-item>
    <el-form-item label="箱子宽度（米）" prop="width">
        <el-input v-model="dataForm.width" placeholder="箱子宽度（米）"></el-input>
    </el-form-item>
    <el-form-item label="箱子高度（米）" prop="height">
        <el-input v-model="dataForm.height" placeholder="箱子高度（米）"></el-input>
    </el-form-item>
    <el-form-item label="箱子的体积（立方米）" prop="cbm">
        <el-input v-model="dataForm.cbm" placeholder="箱子的体积（立方米）"></el-input>
    </el-form-item>
    <el-form-item label="打包时间" prop="packageTime">
        <el-input v-model="dataForm.packageTime" placeholder="打包时间"></el-input>
    </el-form-item>
    <el-form-item label="包装类型 包裹：pacl 托盘：plt 超级托盘：splt" prop="packageType">
        <el-input v-model="dataForm.packageType" placeholder="包装类型 包裹：pacl 托盘：plt 超级托盘：splt"></el-input>
    </el-form-item>
    <el-form-item label="创建时间" prop="createTime" v-if="dataForm.id">
        <el-input v-model="dataForm.createTime" placeholder="创建时间" disabled></el-input>
    </el-form-item>
    <el-form-item label="创建人" prop="createBy" v-if="dataForm.id">
        <el-input v-model="dataForm.createBy" placeholder="创建人" disabled></el-input>
    </el-form-item>
    <el-form-item label="更新时间" prop="updateTime" v-if="dataForm.id">
        <el-input v-model="dataForm.updateTime" placeholder="更新时间" disabled></el-input>
    </el-form-item>
    <el-form-item label="更新人" prop="updateBy" v-if="dataForm.id">
        <el-input v-model="dataForm.updateBy" placeholder="更新人" disabled></el-input>
    </el-form-item>
    <el-form-item label="删除标识0：未删除，1：已删除" prop="isDelete">
        <el-input v-model="dataForm.isDelete" placeholder="删除标识0：未删除，1：已删除"></el-input>
    </el-form-item>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="visible = false">取消</el-button>
      <el-button type="primary" @click="dataFormSubmit()" v-if="canSubmit">确定</el-button>
    </span>
  </el-dialog>
</template>

<script>
    import {getObj, addObj, putObj} from '@/api/packagebox'

    export default {
    data () {
      return {
        visible: false,
        canSubmit: false,
        dataForm: {
          id: '',
          clientCode: '',
          warehouseCode: '',
          batchNo: '',
          packageNo: '',
          netWeight: '',
          grossWeight: '',
          lenght: '',
          width: '',
          height: '',
          cbm: '',
          packageTime: '',
          packageType: '',
          createTime: '',
          createBy: '',
          updateTime: '',
          updateBy: '',
          isDelete: '',
        },
        dataRule: {
          clientCode: [
            { required: true, message: '客户代码不能为空', trigger: 'blur' }
          ],

          warehouseCode: [
            { required: true, message: '仓库代码不能为空', trigger: 'blur' }
          ],

          batchNo: [
            { required: true, message: '合单号/dn号不能为空', trigger: 'blur' }
          ],

          packageNo: [
            { required: true, message: '箱号不能为空', trigger: 'blur' }
          ],

          netWeight: [
            { required: true, message: '箱子净重（公斤）不能为空', trigger: 'blur' }
          ],

          grossWeight: [
            { required: true, message: '箱子毛重（公斤）不能为空', trigger: 'blur' }
          ],

          lenght: [
            { required: true, message: '箱子长度（米）不能为空', trigger: 'blur' }
          ],

          width: [
            { required: true, message: '箱子宽度（米）不能为空', trigger: 'blur' }
          ],

          height: [
            { required: true, message: '箱子高度（米）不能为空', trigger: 'blur' }
          ],

          cbm: [
            { required: true, message: '箱子的体积（立方米）不能为空', trigger: 'blur' }
          ],

          packageTime: [
            { required: true, message: '打包时间不能为空', trigger: 'blur' }
          ],

          packageType: [
            { required: true, message: '包装类型 包裹：pacl 托盘：plt 超级托盘：splt不能为空', trigger: 'blur' }
          ],

          isDelete: [
            { required: true, message: '删除标识0：未删除，1：已删除不能为空', trigger: 'blur' }
          ],

        }
      }
    },
    methods: {
      init (id) {
        this.visible = true;
        this.canSubmit = true;
        this.$nextTick(() => {
            this.$refs['dataForm'].resetFields()
            if (id) {
            getObj(id).then(response => {
                this.dataForm = response.data.data
            })
          }
        })
      },
      // 表单提交
      dataFormSubmit () {
        this.$refs['dataForm'].validate((valid) => {
          if (valid) {
            this.canSubmit = false;
            if (this.dataForm.id) {
                putObj(this.dataForm).then(data => {
                    this.$notify.success('修改成功')
                    this.visible = false
                    this.$emit('refreshDataList')
                }).catch(() => {
                    this.canSubmit = true;
                });
            } else {
                addObj(this.dataForm).then(data => {
                    this.$notify.success('添加成功')
                    this.visible = false
                    this.$emit('refreshDataList')
                }).catch(() => {
                    this.canSubmit = true;
                });
            }
          }
        })
      },
      //重置表单
      closeDialog() {
          this.$refs["dataForm"].resetFields()
      }
    }
  }
</script>
