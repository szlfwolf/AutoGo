<template>
  <basic-container>
    <div class="avue-crud content">
      <div v-loading="skuLoading">
        <div class="title">
          <span></span>
          <label for="">Storage Type Info</label>
        </div>
        <div class="contain">
          <el-form ref="rowParams" :rules="rules" :model="rowParams" label-width="150px">
            <el-row>
              <el-col :span="8">
                <el-form-item label="Name:" prop="name">
                  <el-input :disabled="btnType != 'add'" v-model.trim="rowParams.name"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="16">
                <el-form-item label="Desc:" prop="obDesc">
                  <el-input v-model.trim="rowParams.obDesc"></el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="8">
                <el-form-item label="Width(mm):" prop="width">
                  <el-input maxlength="6" v-model.trim="rowParams.width"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="8">
                <el-form-item label="Height(mm):" prop="high">
                  <el-input maxlength="6" v-model.trim="rowParams.high"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="8">
                <el-form-item label="Depth(mm):" prop="length">
                  <el-input maxlength="6" v-model.trim="rowParams.length"></el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="8">
                <el-form-item label="Corridor(mm):" prop="corridor">
                  <el-input maxlength="6" v-model.trim="rowParams.corridor"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="8">
                <el-form-item label="Level:" prop="level">
                  <el-input maxlength="12" v-model.trim="rowParams.level"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="8">
                <el-form-item label="Storage Space(㎡):" prop="storageSpace">
                  <el-input maxlength="6" v-model.trim="rowParams.storageSpace"></el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="8">
                <el-form-item label="Floor Space(㎡):" prop="floorSpace">
                  <el-input maxlength="6" v-model.trim="rowParams.floorSpace"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="8">
                <el-form-item label="Volume(m³):" prop="volume">
                  <el-input maxlength="6" v-model.trim="rowParams.volume"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="8">
                <el-form-item label="Big Or Small:" prop="bigOrSmall">
                  <el-select filterable v-model="rowParams.bigOrSmall" placeholder="">
                    <el-option label="BIG" value="BIG">
                    </el-option>
                    <el-option label="SMALL" value="SMALL">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-row>
            <div class="dialog-footer-box">
              <span slot="footer">
                <el-button @click="cancelClo" style="margin-right: 20px; padding: 10px 40px" type="info">Cancel
                </el-button>
                <el-button type="primary" @click="updateSub" style="padding: 10px 40px">Save</el-button>
              </span>
            </div>
          </el-form>
        </div>
      </div>
    </div>
  </basic-container>
</template>
<script>
import { addObj, update } from '@/api/storageType'
import { remote } from '@/api/admin/dict'
import { deepClone } from '@/util/util';
import { mapGetters } from "vuex"
import { btnAntiShake } from '@/util/btnAntiShake';
export default {
  name: "adDetail",
  data() {
    return {
      skuLoading: false,
      btnType: '',
      rowParams: {
        name: '',
        obDesc: '',
        width: '',
        high: '',
        level: '',
        length: '',
        floorSpace: '',
        volume: '',
        storageSpace: '',
        corridor: '',
        bigOrSmall: '',
      },
      options: {
        wmsArr: [],
        codeArr: [],
      },
      rules: {
        name: [
          { required: true, message: "此区域为必填项", trigger: "change" },
        ],
        high: [
          { required: true, message: "此区域为必填项", trigger: "change" },
          { pattern: /^[0-9]+([.]{1}[0-9]+){0,1}$/, message: '请输入大于等于0的整数或小数', trigger: 'change' },
        ],
        width: [
          { required: true, message: "此区域为必填项", trigger: "change" },
          { pattern: /^[0-9]+([.]{1}[0-9]+){0,1}$/, message: '请输入大于等于0的整数或小数', trigger: 'change' },
        ],
        level: [
          { required: true, message: "此区域为必填项", trigger: "change" },
          { pattern: /^(0|[1-9][0-9]*)$/, message: '请输入大于等于0的整数', trigger: 'change' },
        ],
        length: [
          { required: true, message: "此区域为必填项", trigger: "change" },
          { pattern: /^[0-9]+([.]{1}[0-9]+){0,1}$/, message: '请输入大于等于0的整数或小数', trigger: 'change' },
        ],
        floorSpace: [
          { required: true, message: "此区域为必填项", trigger: "change" },
          { pattern: /^[0-9]+([.]{1}[0-9]+){0,1}$/, message: '请输入大于等于0的整数或小数', trigger: 'change' },
        ],
        volume: [
          { required: true, message: "此区域为必填项", trigger: "change" },
          { pattern: /^[0-9]+([.]{1}[0-9]+){0,1}$/, message: '请输入大于等于0的整数或小数', trigger: 'change' },
        ],
        bigOrSmall: [
          { required: true, message: "此区域为必填项", trigger: "change" },
        ],
        corridor: [
          { required: true, message: "此区域为必填项", trigger: "change" },
          { pattern: /^[0-9]+([.]{1}[0-9]+){0,1}$/, message: '请输入大于等于0的整数或小数', trigger: 'change' },
        ],
        storageSpace: [
          { required: true, message: "此区域为必填项", trigger: "change" },
          { pattern: /^[0-9]+([.]{1}[0-9]+){0,1}$/, message: '请输入大于等于0的整数或小数', trigger: 'change' },
        ],
      },
    };
  },
  created() {
    this.btnType = this.$route.query.btnType
    this.getSelect()
    // console.log('这个页面的数据', JSON.parse(JSON.stringify(this.rowParams)))
  },
  mounted() {
    this.updateSub = btnAntiShake(this.updateSub, 500)
  },

  watch: {
    // 利用watch方法检测路由变化：
    $route: function (to, from) {
      if (to.path == '/storageTypeAdd/index' && this.$route.query.row) {
        // 编辑
        if (to.query.row !== from.query.row) {
          this.rowParams = JSON.parse(this.$route.query.row)
          this.btnType = this.$route.query.btnType
        } else {
          this.btnType = this.$route.query.btnType
        }
      } else {
        // 添加
        this.btnType = this.$route.query.btnType
        // this.rowParams = this.$options.data().rowParams
        this.rowParams = {}
        this.$refs.rowParams.resetFields()
      }
    }
  },

  computed: {
    ...mapGetters(["permissions", "tagList"]),
  },
  methods: {
    async getSelect() {
      if (this.btnType == 'change' && this.$route.query.row != undefined) {
        this.rowParams = JSON.parse(this.$route.query.row)
      }
    },
    // 关闭当前页面
    findTag(value) {
      let tag, key;
      this.tagList.map((item, index) => {
        if (item.value.includes(value)) {
          tag = item;
          key = index;
        }
      });
      return { tag: tag, key: key };
    },
    //清除表单
    cancelClo() {
      this.$refs.rowParams.resetFields()
      let { tag, key } = this.findTag(this.$route.fullPath);
      this.$store.commit('DEL_TAG', tag)
      this.$router.push({
        path: `/pfep/storageType/index`,
      });
      this.eventBus.$emit('query')
    },
    //新增/修改表单
    updateSub() {
      this.$refs.rowParams.validate(async (valid) => {
        if (!valid) return false;
        if (this.btnType == 'add') {
          console.log('新增数据携带的参数', JSON.parse(JSON.stringify(this.rowParams)))
          let { data } = await addObj(this.rowParams)
          console.log('提交后返回的参数', JSON.parse(JSON.stringify(data)))
          if (data.code == 0) {
            this.$message.success(data.msg)
            // this.eventBus.$emit('updateSub')
            this.getSelect()
            this.cancelClo()
          } else {
            return this.$message.error(data.msg)
          }
        } else {
          console.log('修改数据携带的参数', JSON.parse(JSON.stringify(this.rowParams)))
          let { data } = await update(this.rowParams)
          console.log('提交后返回的参数', JSON.parse(JSON.stringify(data)))
          if (data.code == 0) {
            this.$message.success(data.msg)
            // this.eventBus.$emit('updateSub')
            this.getSelect()
            this.cancelClo()
          } else {
            return this.$message.error(data.msg)
          }
        }
      });

    },
  },
};
</script>
<style lang="scss" scoped>
/* 去掉中间数据的分割线 */
::v-deep .el-table__row>td {
  border: none;
}

/* 去掉上面的线 */
::v-deep .el-table th.is-leaf {
  border: none;
}

/* 去掉最下面的那一条线 */
::v-deep .el-table::before {
  height: 0px;
}

.underLine {
  color: #599af8;
  text-decoration: underline;
}

.content {
  width: 100%;
  padding: 20px;
  box-sizing: border-box;

  .title {
    width: 100%;
    height: 30px;
    line-height: 30px;
    display: flex;
    margin-bottom: 10px;

    span {
      width: 3px;
      height: 30px;
      background-color: #000;
      margin-right: 10px;
    }

    label {
      font-weight: 700;
    }
  }

  .containBox {
    border-bottom: 1px solid #999;
    margin-bottom: 10px;
  }

  .contain {
    padding: 10px;
    box-sizing: border-box;

    label {
      display: inline;
      margin-right: 30px;
    }
  }

  .el-col {
    margin-top: 15px !important;
  }

  .down {
    float: right;
    margin-bottom: 20px;
  }

  .timeline {
    padding: 10px;

    .box {
      background-color: #f4f6f7;
      border-radius: 5px;
      padding: 10px 20px;
      box-sizing: border-box;

      .boxTop {
        font-weight: 700;
        margin-bottom: 10px;

        span {
          margin-left: 10px;
        }
      }

      .boxBottom {
        color: #666;
      }
    }
  }

  .contain-box {
    display: flex;
    column-gap: 20px;
  }

  .eplacement-parts-text {
    width: 100px;
    height: 30px;
    background-color: #000000;
    display: flex;
    justify-content: center;
    align-items: center;
    color: #fff;
    font-size: 12px;
    border-radius: 5px;
  }

  .dialog-footer-box {
    display: flex;
    justify-content: center;
    margin-top: 100px;
  }

  .confrim-bgc {
    background-color: #1376c7;
    color: #fff;
  }
}
</style>
