<template>
  <div class="content">
    <el-tabs type="border-card">
      <el-tabs class="detail-tab" v-loading="skuLoading">
        <el-tab-pane label="Out">
          <!-- PFEP Info -->
          <div>
            <div class="title">
              <span></span>
              <label>PFEP Info</label>
            </div>
            <div class="contain">
              <el-row>
                <el-col :span="6">
                  <label class="contain-label" for="">Owner:</label>
                  <span>{{ pfepData.clientCode }}</span>
                </el-col>
                <el-col :span="6">
                  <label class="contain-label" for="">Status:</label>
                  <el-switch :disabled="!permissions.pfep_pfepconfig_edit" @change="switchChange" v-model="value"
                    active-color="#13ce66" inactive-color="#949494">
                  </el-switch>
                </el-col>
              </el-row>
            </div>
          </div>
          <!-- Params -->
          <div style="margin-top: 30px">
            <div class="title">
              <span></span>
              <label>Params</label>
            </div>
            <div class="contain">
              <el-row>
                <el-col :span="12">
                  <label class="contain-label" for="">Rule:</label>
                  <span>C --> B --> A</span>
                </el-col>
              </el-row>
            </div>
          </div>
          <!-- add -->
          <div style="margin-top: 30px">
            <el-button v-if="permissions.pfep_warehousearea_add" type="primary"
              style="margin-bottom: 10px; padding: 5px 20px; color: #fff; " @click="priceOn({}, 'add')">
              <span style="display: flex; align-items: center">
                <i class="el-icon-circle-plus-outline" style="margin-right: 10px; font-size: 20px"></i>Add
              </span>
            </el-button>
            <!-- tabel -->
            <el-table border tooltip-effect="dark" stripe :data="pfepDetail" style="width: 100%"
              :header-cell-style="{ background: '#f5f7fa', color: '#606266', 'text-align': 'center' }" row-key="id"
              :tree-props="{ children: 'childList' }" default-expand-all :span-method="objectSpanMethod">
              <el-table-column :show-overflow-tooltip="true" align="left" label="Warehouse" min-width="180">
                <template slot-scope="scope"><i class="el-icon-discount"
                    style="margin-right:10px;font-weight: 600;color: #001529;"
                    :style="scope.row.colorNum ? 'font-weight: 400;' : ''"></i>{{ scope.row.warehouseCode }}</template>
              </el-table-column>
              <el-table-column :show-overflow-tooltip="true" align="center" label="Type" min-width="150">
                <template slot-scope="scope">{{ scope.row.typeLabel }}</template>
              </el-table-column>
              <el-table-column :show-overflow-tooltip="true" align="center" label="Level" min-width="120">
                <template slot-scope="scope">{{ scope.row.levelLabel }}</template>
              </el-table-column>
              <el-table-column :show-overflow-tooltip="true" align="center" label="Country" min-width="120">
                <template slot-scope="scope">{{ scope.row.countryCode }}</template>
              </el-table-column>

              <el-table-column :show-overflow-tooltip="true" align="center" label="Zipcode" min-width="220">
                <template slot-scope="scope">{{ scope.row.zipCodes }}</template>
              </el-table-column>
              <el-table-column v-if="permissions.pfep_warehousearea_edit" label="Opearte" align="center" min-width="100">
                <template slot-scope="scope">
                  <i style="font-size:18px;  color: #65BEFF;" class="el-icon-edit operate-icon-box"
                    @click="priceOn(scope.row, 'change')"></i>
                </template>
              </el-table-column>
            </el-table>
          </div>
          <!-- 弹框 -->
          <el-dialog :before-close="cancel" :title="dialogTitle" :visible.sync="detailAdd" width="65%"
            style="font-weight: 700" :close-on-click-modal='btnType != "add"'>
            <!-- 内容 -->
            <!--add、change -->
            <el-form ref="newPfepAdd" :rules="rules" :model="newPfepAdd" label-width="180px">
              <el-row>
                <el-col :span="12">
                  <el-form-item label="Owner:">
                    <span>{{ pfepData.clientCode }}</span>
                  </el-form-item>
                </el-col>
                <el-col :span="12">
                  <el-form-item label="Warehouse Type:" prop="warehouseType">
                    <el-select filterable placeholder="" clearable v-model="newPfepAdd.warehouseType">
                      <el-option v-for="item in  allWarehouseCodeArr " :key="item.value" :label="item.label"
                        :value="item.value">
                      </el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
              </el-row>
              <template>
                <el-row>
                  <el-col :span="12">
                    <el-form-item label="Warehouse:" prop="warehouseCode">
                      <el-select filterable :disabled="this.btnType == 'change'" placeholder="" clearable
                        v-model="newPfepAdd.warehouseCode">
                        <el-option v-for="item in  warehouseNameArr " :key="item.value" :label="item.label"
                          :value="item.value">
                        </el-option>
                      </el-select>
                    </el-form-item>
                  </el-col>
                  <el-col :span="12">
                    <el-form-item label="Warehouse Level:" prop="warehouseLevel">
                      <el-select filterable placeholder="" clearable v-model="newPfepAdd.warehouseLevel">
                        <el-option v-for="item in  levelArr" :key="item.value" :label="item.label" :value="item.value">
                        </el-option>
                      </el-select>
                    </el-form-item>
                  </el-col>
                </el-row>
              </template>
              <template v-if="newPfepAdd.warehouseLevel != '1'">
                <el-row v-for="(item, index ) in newPfepAdd.details" :key="index">
                  <el-col :span="12">
                    <el-form-item label="Country:" :rules="rules.countryCode" :prop="`details.${index}.countryCode`">
                      <el-select filterable @change="changeCountryCode" placeholder="" clearable
                        v-model="item.countryCode">
                        <el-option v-for="item in clientCodeArr" :key="item.value" :label="item.label"
                          :value="item.value">
                        </el-option>
                      </el-select>
                    </el-form-item>
                  </el-col>
                  <el-col :span="12">
                    <el-form-item label="Zipcode:" :rules="rules.zipCodes" :prop="`details.${index}.zipCodes`">
                      <el-input v-model.trim="item.zipCodes" rows="4" type="textarea">
                      </el-input>
                    </el-form-item>
                  </el-col>
                  <!-- 删除 -->
                  <el-col align="center">
                    <i v-if="newPfepAdd.details.length > 1" class="el-icon-delete cursor-on" @click="kitDel(index)"></i>
                  </el-col>
                </el-row>
              </template>

              <!-- 添加 -->
              <el-row v-if="newPfepAdd.warehouseLevel != '1'" class="dialog-footer-add ">
                <el-col align="center">
                  <i @click="kitAdd" class="el-icon-circle-plus-outline cursor-on"></i>
                </el-col>
              </el-row>
            </el-form>

            <div class="dialog-footer-box">
              <span slot="footer">
                <el-button @click="cancel" style="margin-right: 20px; padding: 10px 40px" type="info">Cancel
                </el-button>
                <el-button type="primary" @click="addSave" style="padding: 10px 40px">Confirm</el-button>
              </span>
            </div>
          </el-dialog>
        </el-tab-pane>
        <el-tab-pane label="In">暂无数据.......</el-tab-pane>
        <el-tab-pane label="Stock Transfer">暂无数据.......</el-tab-pane>
      </el-tabs>
    </el-tabs>
  </div>
</template>
<script>
let formParams = {
  order_no: null,
  status: null,
  urgent_type: null,
  order_type: null,
  country_code: null,
  no_inventory_type: null,
  tags: "",
  create_time: "",
  release_time: "",
  packed_time: "",
  outbound_time: "",
  pod_time: "",
};
import { mapGetters } from "vuex"
import { deepClone } from '../../../util/util'
import { addSaveObj, putUpdate, getPfepCountryCode } from '../../../api/warehousearea'
import { getNameAndType, getWarehouseLevel } from '@/api/warehouse'
import { remote } from '@/api/admin/dict'
import { update, warehousearea, pageGet } from '@/api/pfepconfig'
import { getStore, setStore } from '@/util/store'
import { btnAntiShake } from '@/util/btnAntiShake'
export default {
  name: "Order",
  data() {
    const required = [
      { required: true, message: "此区域为必填项", trigger: "change" },
    ]
    return {
      levelArr: [],
      btnType: '',
      dialogTitle: '',
      skuLoading: false,
      clientCodeArr: [],
      countrySelectLength: 0,
      allWarehouseCodeArr: [],
      warehouseNameArr: [],
      detailAdd: false, //控制弹框
      value: null,
      form: Object.assign({}, formParams),
      pfepData: {
      },
      // add数据
      newPfepAdd: {
        clientCode: '',
        warehouseCode: '',
        warehouseType: '',
        details: [
          {
            countryCode: '',
            zipCodes: ''
          },
        ]
      },
      rules: {
        warehouseType: required,
        warehouseCode: required,
        warehouseName: required,
        // parentWarehouseCode: required,
        warehouseLevel: required,
        type: required,
        countryCode: required,
        zipCodes: [
          { required: true, message: "此区域为必填项", trigger: "change" },
          { pattern: /^([0-9]{1}[0-9*]{1})(,[0-9]{1}[0-9*]{1})*$|^\*$/, message: '请用单独的*号或者两位数字、一位数字和*，中间用英文逗号隔开！', trigger: 'change' },
        ],
      },
      pfepDetail: [],
      pfepRt: {},
    };
  },
  async created() {
    // 路由传值过来的
    this.pfepRt = getStore({ name: 'rowData' })
    // status 按钮
    this.value = this.pfepRt.isDn == 'Y' ? true : false
    this.pfepData = this.pfepRt
    let { data: levelArr } = await getWarehouseLevel()
    this.levelArr = levelArr.map(i => Object.assign(i, { value: i.value + '' }))
    this.clientCode() // // 表格数据
  },
  mounted() {
    // 按钮防抖
    this.switchChange = btnAntiShake(this.switchChange, 500, true)
    this.addSave = btnAntiShake(this.addSave, 500)
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  methods: {
    // status状态的修改  btnAntiShake
    async switchChange(type) {
      let status = type ? 'Y' : 'N'
      let obj = deepClone(this.pfepData)
      obj.isDn = status
      setStore({ name: 'rowData', content: obj })
      let { data } = await update(obj)
      if (data.code != 0) return this.$message.error(data.msg)
      this.$message.success(data.msg)
      this.eventBus.$emit('query')
    },
    // 获取  Country  下拉数据 
    async countrySelect() {
      let { data } = await remote('country_code')
      this.clientCodeArr = data.data
      this.countrySelectLength = data.data.length
    },

    // 表格数据
    async clientCode() {
      this.skuLoading = true //开启loading
      // 获取名字类型合集
      let { data } = await getNameAndType({ clientCode: this.pfepRt.clientCode })
      this.allWarehouseCodeArr = data.data.warehouseType
      this.warehouseNameArr = data.data.warehouseName
      console.log('获取名字类型合集', JSON.parse(JSON.stringify(data.data)))
      let { data: pfepDetail } = await warehousearea({ clientCode: this.pfepRt.clientCode })
      console.log('请求到的数据', JSON.parse(JSON.stringify(pfepDetail)))
      if (pfepDetail.code != 0) {
        this.skuLoading = false //关loading
        this.$message.error('request was aborted')
        return
      }
      this.skuLoading = false //关loading

      //循环映射！！！！
      const listData = this.checkMerge(pfepDetail.data)
      this.nameFor(listData)
      this.pfepDetail = listData
      console.log('🚀 ~ 表格', JSON.parse(JSON.stringify(this.pfepDetail)))
    },
    // =======映射
    nameFor(data) {
      data.forEach((i, v) => {
        // 给子节点添加rowSpan
        if (i.childList && i.childList.length > 0) {
          this.checkMerge(i.childList)
        }
        this.allWarehouseCodeArr.forEach((item) => {
          if (i.type == item.value) {
            i.typeLabel = item.label
          }
        })
        // 递归映射等级
        this.levelArr.forEach((item) => {
          if (i.warehouseLevel == item.value) {
            i.levelLabel = item.label
          }
        })
      })
    },

    // 给节点添加rowSpan
    /*合并算法参考： https://blog.csdn.net/qq_29468573/article/details/80742646?ops_request_misc=%257B%2522request%255Fid%2522%253A%2522166676387316800180632175%2522%252C%2522scm%2522%253A%252220140713.130102334..%2522%257D&request_id=166676387316800180632175&biz_id=0&utm_medium=distribute.pc_search_result.none-task-blog-2~all~baidu_landing_v2~default-3-80742646-null-null.142^v59^control,201^v3^add_ask,213^v1^control&utm_term=span-method&spm=1018.2226.3001.4187
    */
    checkMerge(data) {
      let pos = 0;
      for (var i = 0; i < data.length; i++) {
        data[i].details = [{ countryCode: data[i].countryCode, zipCodes: data[i].zipCodes }]
        if (i === 0) {
          data[i].rowSpan = 1
          pos = 0
        } else {
          // 判断当前元素与上一个元素是否相同
          if (data[i].warehouseCode === data[i - 1].warehouseCode && data[i].warehouseLevel === data[i - 1].warehouseLevel) {
            data[i - 1].details.push({ countryCode: data[i].countryCode, zipCodes: data[i].zipCodes })
            data[i].details = data[i - 1].details
            data[pos].rowSpan += 1;
            data[i].rowSpan = 0;
          } else {
            data[i].rowSpan = 1;
            pos = i;
          }
        }
      }
      return data
    },
    // checkMerge(data) {
    //   console.log("🚀→→→→→ ~ data:", data)
    //   let pos = 0;
    //   for (var i = 0; i < data.length; i++) {
    //     if (i === 0) {
    //       data[i].rowSpan = 1
    //       pos = 0
    //     } else {
    //       // 判断当前元素与上一个元素是否相同
    //       if (data[i].warehouseCode === data[i - 1].warehouseCode && data[i].warehouseName === data[i - 1].warehouseName && data[i].type === data[i - 1].type) {
    //         if (data[i].childList.length && data[i - 1].childList.length) {
    //           // data[pos].rowSpan += 1;
    //           // data[i].rowSpan = 0;
    //           // data[i].childList = []
    //         } else {
    //           data[pos].rowSpan += 1;
    //           data[i].rowSpan = 0;
    //         }
    //       } else {
    //         data[i].rowSpan = 1;
    //         pos = i;
    //       }
    //     }
    //   }
    //   return data
    // },

    // 添加/ 编辑按钮
    async priceOn(row, type) {
      this.cancel()
      this.btnType = type
      if (type == 'add') {
        // 添加按钮
        this.countrySelect() //国家代码下拉框
        this.dialogTitle = 'Add'
        this.detailAdd = true
      } else {
        // 编辑按钮
        this.changeCountryCode()
        this.dialogTitle = 'Edit'
        let { warehouseCode, type, warehouseLevel } = row
        let { data } = await pageGet({ warehouseCode: warehouseCode, clientCode: this.pfepData.clientCode, warehouseLevel: warehouseLevel })
        this.newPfepAdd = deepClone(data.data)
        // 集合数据list 
        console.log('编辑回显数据', JSON.parse(JSON.stringify(this.newPfepAdd)))
        this.detailAdd = true
      }
    },
    // 确认添加或者编辑按钮按钮
    async addSave() {
      this.$refs.newPfepAdd.validate(async (valid) => {
        if (!valid) return false;
        let newPostData = deepClone(this.newPfepAdd) //克隆一份要提交的数据
        newPostData['status'] = this.value ? 'Y' : 'N'
        if (newPostData.warehouseLevel == '1') newPostData.details = null
        if (this.btnType == 'add') {
          newPostData.clientCode = this.pfepRt.clientCode
          // 新增确认
          console.log('add携带的参数', JSON.parse(JSON.stringify(newPostData)))
          let { data: addData } = await addSaveObj(newPostData)
          if (addData.code != 0) return this.$message.error(addData.msg)
          this.$message.success(addData.msg)
          this.clientCode()
          this.cancel()
        } else {
          // 修改确认
          console.log('change携带的参数', JSON.parse(JSON.stringify(newPostData)))
          let { data } = await putUpdate(newPostData)
          if (data.code != 0) return this.$message.error(data.msg)
          this.$message.success(data.msg)
          this.clientCode()
          this.cancel()
        }
      })
    },

    // 配置table列并列
    objectSpanMethod({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0 || columnIndex === 1 || columnIndex === 2) {
        return {
          rowspan: row.rowSpan === undefined ? 1 : row.rowSpan,
          colspan: 1
        }
      } else {
        return {
          rowspan: 1,
          colspan: 1
        };
      }
    },
    // 重置并关闭弹框
    cancel() {
      this.detailAdd = false
      if (this.$refs.newPfepAdd != undefined) this.$refs.newPfepAdd.resetFields()
      this.newPfepAdd = {
        details: [{ countryCode: '', zipCodes: '' },]
      }
    },
    // 国家代码i 添加
    kitAdd() {
      this.newPfepAdd.details.push({ countryCode: '', zipCodes: '', })
    },
    // 国家代码i 删除
    kitDel(index) {
      this.newPfepAdd.details.splice(index, 1)
      this.$nextTick(() => {
        this.$refs.newPfepAdd.clearValidate()
      })
      this.getVountryCodeList()
    },
    // 国家代码input改动触发
    changeCountryCode() {
      this.getVountryCodeList()
    },
    // 下拉框的方法
    async getVountryCodeList() {
      await this.countrySelect()
      this.newPfepAdd.details.forEach((i) => {
        let newArr = this.clientCodeArr.filter(item => {
          if (i.countryCode !== item.value) return item
        })
        this.clientCodeArr = newArr
      })
    },

  },
};
</script>
<style lang="scss" scoped>
.dialog-footer-box {
  display: flex;
  justify-content: center;
  margin-top: 40px;
}

.title {
  display: flex;
  align-items: center;

  &>span {
    width: 3px;
    height: 30px;
    background-color: #000;
    margin-right: 10px;
    display: inline-block;
  }

  &>label {
    font-weight: bold;
  }
}

.contain {
  padding: 30px 10px 10px 60px;
  box-sizing: border-box;
}

.contain-label {
  margin-right: 30px;
}

.content {
  padding: 0 10px;

  // box-sizing: border-box;
  .down {
    display: flex;
    //   justify-content: space-between;
    justify-content: end;
    margin-bottom: 20px;
    border-top: 1px solid #999;
    padding-top: 20px;
    box-sizing: border-box;
  }

  .underLine {
    color: #599af8;
    text-decoration: underline;

    .underIcon {
      background-color: green;
      color: #fff;
      border-radius: 50%;
      margin-right: 5px;
    }
  }

  .grey {
    background-color: #bbbbbb;
    color: #fff;
    border-radius: 50%;
    margin-right: 5px;
  }

  .operate-icon-box {
    cursor: pointer;
    color: #4095e5;
  }

  .confrim-bgc {
    background-color: #1376c7;
    color: #fff;
  }
}

::v-deep .el-dialog__wrapper .el-dialog {
  border-radius: 8px;
}

::v-deep .el-select--small {
  display: block;
}

.cursor-on {
  cursor: pointer;
  color: #4095e5;
  font-size: 20px
}

.fd {
  padding: 0 5px;
  margin-right: 5px;
  background-color: skyblue;
  border: 1px solid #d9ecff;
  border-radius: 5px;
  background-color: #ecf5ff;
  color: #409EFF;
}

// 将el-table的展开图标替换为其他图标
// 设置展开或者收起时，不发生旋转
// ::v-deep .el-table__expand-icon {
//   -webkit-transform: rotate(0deg);
//   transform: rotate(0deg);
// }

// ::v-deep .el-table__expand-icon .el-icon-arrow-right:before {
//   content: "\e723";
//   font-size: 16px;
// }

// ::v-deep .el-table__expand-icon--expanded .el-icon-arrow-right:before {
//   content: "\e722";
//   font-size: 16px;
// }
</style>
