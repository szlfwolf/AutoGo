<template>
  <div class="content">
    <el-tabs type="border-card" v-loading="skuLoading">
      <el-row style="width:200px;display:flex">
        <el-col>
          <el-button type="primary" icon="el-icon-search" @click="getFetchList()">Query
          </el-button>
        </el-col>
        <el-col>
          <el-button @click="resetForm('PfepData')" type="info" plain icon="el-icon-refresh-left">Reset</el-button>
        </el-col>
      </el-row>
      <el-form ref="PfepData" :model="PfepData">
        <el-row style="margin-top: 20px">
          <el-col :span="4">
            <el-form-item prop="clientCode">
              <el-select filterable clearable placeholder="Owner" v-model="PfepData.clientCode">
                <el-option v-for="item in clientCodeArr" :key="item" :label="item" :value="item"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <excel-upload ref="pfepUp" title="Pfep upload" url="/pfep/pfepconfig/import" temp-name="pfep-template.xlsx"
        temp-url="/admin/sys-file/local/pfep-template.xlsx" @refreshDataList="handleRefreshChange">
      </excel-upload>
      <div class="down">
        <el-button v-if="permissions.pfep_pfepconfig_import" icon="el-icon-upload2" @click="$refs.pfepUp.show()">
        </el-button>
        <el-button v-if="permissions.pfep_pfepconfig_export" icon="el-icon-download" @click="exportExcel"></el-button>
      </div>
      <!-- 表格 -->
      <el-table border tooltip-effect="dark" stripe :data="pfepConfig.records" style="width: 100%"
        :header-cell-style="{ background: '#f5f7fa', color: '#606266' }">
        <el-table-column align="center" label="Owner" min-width="80">
          <template slot-scope="scope">{{ scope.row.clientCode }}</template>
        </el-table-column>

        <el-table-column align="center" label="Out Order Route">
          <template slot-scope="scope">
            <div class="underLine">
              <i :class="
                              scope.row.isDn == 'Y'
                                ? 'el-icon-check underIcon'
                                : 'el-icon-close grey'
                            "></i>
            </div>
          </template>
        </el-table-column>

        <el-table-column align="center" label="In Order Route">
          <template slot-scope="scope">
            <div class="underLine">
              <i :class="
                              scope.row.isAsn == 'Y'
                                ? 'el-icon-check underIcon'
                                : 'el-icon-close grey'
                            "></i>
            </div>
          </template>
        </el-table-column>
        <el-table-column align="center" label="Stock Tranfer Route">
          <template slot-scope="scope">
            <div class="underLine">
              <i :class="
                              scope.row.isStock == 'Y'
                                ? 'el-icon-check underIcon'
                                : 'el-icon-close grey'
                            "></i>
            </div>
          </template>
        </el-table-column>
        <!-- 预览 -->
        <el-table-column v-if="permissions.pfep_warehousearea_get" align="center" label="Operate" min-width="80">
          <template slot-scope="scope"><i class="el-icon-view" @click="preview(scope.$index, scope.row)"
              style="font-size:18px;  color: #65BEFF; cursor: pointer"></i></template>
        </el-table-column>
      </el-table>
      <Pagination @handleSizeChange="handleSizeChange" @handleCurrentChange="handleCurrentChange"
        :pageNum="pfepConfig.current" :pageSize="pfepConfig.size" :total="pfepConfig.total"></Pagination>
    </el-tabs>
  </div>
</template>
<script>
let formParams = {
  order_no: null,
  status: null,
  urgent_type: null,
  order_type: null,
  country_code: null,
  no_inventory_type: null,
  tags: "",
  create_time: "",
  release_time: "",
  packed_time: "",
  outbound_time: "",
  pod_time: "",
};
import Pagination from "@/components/pagination/pagination.vue"
import { fetchList, warehousearea, getClientCode } from '../../../api/pfepconfig'
import ExcelUpload from "@/components/upload/excel"
import { mapGetters } from "vuex"
import { setStore } from '@/util/store'
import { btnAntiShake } from '@/util/btnAntiShake'
export default {
  name: "Order",
  data() {
    return {
      skuLoading: false,
      pageCurrent: '1',
      pageSize: '',
      detailAdd: false,
      value: true,
      form: Object.assign({}, formParams),
      PfepData: {
        clientCode: "",
      },
      // rules: {
      //   clientCode: [
      //     { required: true, message: "请选择活动区域", trigger: "change" },
      //   ],
      // },
      // 分页数据 出库路径-->isDn 入库路径-->isAsn  库存分配路径-->isStock
      pfepConfig: {},
      multipleSelection: [],
      centerDialogVisible: false,
      clientCodeArr: []//下拉数据
    };
  },
  created() {
    this.getFetchList()
    this.clientCode()
    this.eventBus.$on('query', () => this.getFetchList())
  },
  mounted() {
    this.exportExcel = btnAntiShake(this.exportExcel, 500)
  },
  components: {
    ExcelUpload,
    Pagination
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  methods: {
    // 下拉框数据   /pfep/pfepconfig/getClientCode
    async clientCode() {
      let { data } = await getClientCode()
      this.clientCodeArr = data.data
      console.log('下拉数据', data.data);
    },
    // 分页查询pfep
    async getFetchList(query) {
      if (!query) {
        this.pageCurrent = 1
        this.pageSize = 10
        query = { current: this.pageCurrent, size: this.pageSize }
      }
      let queryObj = Object.assign(this.PfepData, query)
      this.skuLoading = true //开启loading
      let { data } = await fetchList(queryObj)
      if (!data.data) {
        this.skuLoading = false //关loading
        this.$message.error(data.msg)
        return
      }
      this.skuLoading = false //关loading
      this.pfepConfig = data.data
      console.log('"🚀 ~ 分页查询pfep"', JSON.parse(JSON.stringify(data.data)))
    },

    // 重置
    resetForm(rule) {
      this.$refs[rule].resetFields();
      this.getFetchList()
    },

    //条数
    handleSizeChange(val) {
      this.pageSize = val
      let query = { current: this.pageCurrent, size: val }
      this.getFetchList(query)
      console.log(`每页 ${val} 条`);
    },
    //当前页数
    handleCurrentChange(val) {
      this.pageCurrent = val
      let query = { current: val, size: this.pageSize }
      this.getFetchList(query)
      console.log(`当前页: ${val}`);
    },
    // 小眼睛请求数据
    async preview(index, row) {
      this.$router.push({
        path: `/pfepDetail`,
        // query: {
        //   row: JSON.stringify(row),
        // },
      });
      setStore({ name: 'rowData', content: row })
    },
    //导出
    exportExcel() {
      this.skuLoading = true
      // console.log('导出', JSON.parse(JSON.stringify(this.pfepConfig.records)))
      console.log('导出', JSON.parse(JSON.stringify(this.PfepData)))
      this.downBlobFile("/pfep/pfepconfig/export", this.PfepData, `${this.$store.state.common.commandName}-pfep-${this.toDateFormat(new Date(), true)}.xlsx`, () => this.skuLoading = false);
    },

    // 上传
    handleRefreshChange(response) {
      if (response == 'loading') {
        this.skuLoading = true
        return
      }
      if (!!response && response.code == 0) {
        this.skuLoading = false
      } else {
        this.skuLoading = false
      }
      this.getFetchList()
    },
  },

};
</script>
<style lang="scss" scoped>
::v-deep .el-select--small {
  display: block;
}

// /* 去掉中间数据的分割线 */
// ::v-deep .el-table__row>td {
//   border: none;
// }

// /* 去掉上面的线 */
// ::v-deep .el-table th.is-leaf {
//   border: none;
// }

// /* 去掉最下面的那一条线 */
// ::v-deep .el-table::before {
//   height: 0px;
// }

.dialog-footer-box {
  display: flex;
  justify-content: center;
  margin-top: 40px;
}

.title {
  display: flex;
  align-items: center;

  &>span {
    width: 3px;
    height: 30px;
    background-color: #000;
    margin-right: 10px;
    display: inline-block;
  }

  &>label {
    font-weight: bold;
  }
}

.contain {
  padding: 30px 10px 10px 60px;
  box-sizing: border-box;
}

.contain-label {
  margin-right: 30px;
}

.content {
  padding: 0 10px;

  // box-sizing: border-box;
  .down {
    display: flex;
    //   justify-content: space-between;
    justify-content: flex-end;
    margin-bottom: 20px;
    border-top: 1px solid #999;
    padding-top: 20px;
    box-sizing: border-box;
  }

  .underLine {
    color: #599af8;
    text-decoration: underline;

    .underIcon {
      background-color: green;
      color: #fff;
      border-radius: 50%;
      margin-right: 5px;
    }
  }

  .grey {
    background-color: #bbbbbb;
    color: #fff;
    border-radius: 50%;
    margin-right: 5px;
  }
}
</style>
