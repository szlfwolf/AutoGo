<template>
  <div class="content">
    <el-tabs type="border-card" v-loading="skuLoading">
      <el-row style="width:200px;display:flex">
        <el-col>
          <el-button type="primary" icon="el-icon-search" @click="Query()">Query</el-button>
        </el-col>
        <el-col>
          <el-button @click="resetForm('form')" type="info" plain icon="el-icon-refresh-left">Reset</el-button>
        </el-col>
      </el-row>
      <el-form ref="form" :model="form">
        <el-row style="margin-top: 20px" :gutter="20">
          <el-col :span="4">
            <el-form-item prop="dataType">
              <el-select filterable clearable v-model="form.dataType" placeholder="DataType">
                <el-option v-for="item in dataTypeArr" :label="item.label" :value="item.value" :key="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="4">
            <el-form-item prop="name">
              <el-input v-model="form.name" placeholder="Name"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="4">
            <el-form-item prop="code">
              <el-input v-model="form.code" placeholder="Code"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div class="down">
        <!-- Add按钮 -->
        <el-button v-if="permissions.pfep_pfepData_add" type="primary" style="  padding: 5px 20px;   color: #fff; "
          @click="modifyBtn('', 'add')">
          <span style="display: flex; align-items: center">
            <i class="el-icon-circle-plus-outline" style="margin-right: 10px; font-size: 20px"></i>Add
          </span>
        </el-button>
        <span v-else></span>
        <div>
          <!-- 上传 -->
          <excel-upload ref="BackUpRef" title="PfepData upload" url="/pfep/pfepData/uploadPfepDataByExcel"
            temp-name="pfepData-upload.xlsx" temp-url="/admin/sys-file/local/pfepData-upload.xlsx"
            @refreshDataList="uploadHsCode">
          </excel-upload>
          <el-button v-if="permissions.pfep_pfepData_upload" icon="el-icon-upload2" @click="$refs.BackUpRef.show()">
          </el-button>
          <el-button v-if="permissions.pfep_pfepData_export" icon="el-icon-download" @click="exportExcel">
          </el-button>
        </div>
      </div>
      <!-- 数据表 -->
      <el-table tooltip-effect="dark" stripe border ref="multipleTable" :data="tableData.records" style="width: 100%"
        header-cell-class-name="header-cell-class" :header-cell-style="{ background: '#f5f7fa', color: '#606266' }">
        <el-table-column :show-overflow-tooltip="true" label="Type" min-width="150" align="center">
          <template slot-scope="scope">{{ scope.row.type }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Name" min-width="150" align="center">
          <template slot-scope="scope">{{ scope.row.name }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Code" min-width="150" align="center">
          <template slot-scope="scope">{{ scope.row.code }}</template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="Desc" min-width="180" align="center">
          <template slot-scope="scope">{{ scope.row.obDesc }}</template>
        </el-table-column>
        <el-table-column v-if="permissions.pfep_pfepData_edit || permissions.pfep_pfepData_del"
          :show-overflow-tooltip="true" label="Opearte" min-width="120" align="center">
          <template slot-scope="scope">
            <el-button v-if="permissions.pfep_pfepData_edit" type="text" style="font-size:18px;  color: #65BEFF;"
              icon="el-icon-edit" @click="modifyBtn(scope.row, 'modify')">
            </el-button>
            <el-button v-if="permissions.pfep_pfepData_del" type="text" style="font-size:18px;  color: #65BEFF;"
              icon="el-icon-delete" @click="deleteBtn(scope.$index, scope.row)">
            </el-button>
          </template>
        </el-table-column>
      </el-table>

      <Pagination @handleSizeChange="handleSizeChange" @handleCurrentChange="handleCurrentChange"
        :pageNum="tableData.current" :pageSize="tableData.size" :total="tableData.total"></Pagination>

      <!-- Add弹框 -->
      <el-dialog :title="dialogTitle" :visible.sync="detailAdd" width="30%" :before-close="cancelClo"
        style="font-weight: 700" :close-on-click-modal='btnType != "add"'>
        <!-- 内容 -->
        <el-form ref="updateObj" :rules="rules" :model="updateObj" label-width="100px">
          <el-row>
            <el-form-item label="Data Type:" prop="type">
              <el-select filterable :disabled="btnType != 'add'" placeholder="" clearable v-model="updateObj.type">
                <el-option v-for="item in dataTypeArr" :key="item.value" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-row>
          <el-form-item label="Name:" prop="name">
            <el-input v-model.trim="updateObj.name"></el-input>
          </el-form-item>
          <el-form-item label="Code:" prop="code">
            <el-input :disabled="btnType != 'add'" v-model.trim="updateObj.code"></el-input>
          </el-form-item>
          <el-form-item label="Desc:" prop="obDesc">
            <el-input type="textarea" rows="6" v-model.trim="updateObj.obDesc"></el-input>
          </el-form-item>

        </el-form>
        <div class="dialog-footer-box">
          <span slot="footer">
            <el-button @click="cancelClo" style="margin-right: 20px; padding: 10px 40px" type="info">Cancel
            </el-button>
            <el-button type="primary" @click="updateSub" style="padding: 10px 40px">Confirm</el-button>
          </span>
        </div>
      </el-dialog>
    </el-tabs>
  </div>
</template>
<script>
let formParams = {
  dataType: '',
  name: '',
  code: '',
};
import { mapGetters } from "vuex"
import Pagination from "@/components/pagination/pagination.vue"
import { deepClone } from '@/util/util';
import { remote } from '@/api/admin/dict'
import { btnAntiShake } from '@/util/btnAntiShake'
import ExcelUpload from "@/components/upload/excel"
import { fetchList, getPfepDataByQuery, addObj, update, delObj } from '@/api/pfepData'
export default {
  name: "ASN",
  data() {
    return {
      dialogTitle: '',
      btnType: '',
      skuLoading: false,
      pageSize: '',
      pageCurrent: '1',
      detailAdd: false,
      isBackUp: false,
      isPrice: false,
      isPackageInfo: false,
      form: Object.assign({}, formParams),
      options: [
      ],
      // 基本数据
      dataTypeArr: [],
      tableData: [],
      multipleSelection: [],
      //   修改表单
      updateObj: {
      },
      // add表单
      addUpdateObj: {},
      rules: {
        name: [
          { required: true, message: '此区域为必填项', trigger: "change" },
        ],
        code: [
          { required: true, message: '此区域为必填项', trigger: "change" },
        ],
        type: [
          { required: true, message: '此区域为必填项', trigger: "change" },
        ],
        // obDesc: [
        //   { required: true, message: '此区域为必填项', trigger: "change" },
        //   { pattern: /^[0-9]*$/, message: '请输入纯数字', trigger: 'change' },
        // ],
      }
    }
  },
  // ============
  created() {
    this.Query()

  },
  components: {
    Pagination,
    ExcelUpload,
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  mounted() {
    this.exportExcel = btnAntiShake(this.exportExcel, 500)
    this.updateSub = btnAntiShake(this.updateSub, 500)
  },
  methods: {
    // 获取基本数据
    // async clientData() {
    //   this.pfepDataType()
    //   this.skuLoading = true //开启loading
    //   let { data } = await fetchList()
    //   if (data.code != 0) {
    //     this.skuLoading = false //关loading
    //     this.$message.error(data.msg);
    //     return;
    //   }
    //   this.skuLoading = false //关loading
    //   this.tableData = deepClone(data.data)
    //   console.log('页面基本数据', JSON.parse(JSON.stringify(this.tableData)))
    // },
    // 按条件查询
    async Query(query) {
      this.pfepDataType()
      if (!query) {
        this.pageCurrent = 1
        this.pageSize = 10
        query = { current: this.pageCurrent, size: this.pageSize }
      }
      this.skuLoading = true //开启loading
      let queryObj = Object.assign(this.form, query)
      let { data } = await getPfepDataByQuery(queryObj)
      if (data.code != 0) {
        this.skuLoading = false //关loading
        this.$message.error(data.msg);
        return;
      }
      this.skuLoading = false //关loading
      this.tableData = deepClone(data.data)
      console.log('页面基本数据', JSON.parse(JSON.stringify(this.tableData)))
    },
    // 下拉框数据  
    async pfepDataType() {
      // let { data } = await getPfepDataType()
      let { data } = await remote('pfep_data_type')
      this.dataTypeArr = data.data
      console.log('pfepDataType下拉框查询', data.data);
    },

    // 重置
    resetForm(rule) {
      this.$refs[rule].resetFields();
      this.Query()
    },
    //导出
    exportExcel() {
      this.skuLoading = true
      this.downBlobFile("/pfep/pfepData/export", this.form, `${this.$store.state.common.commandName}-PfepData-${this.toDateFormat(new Date(), true)}.xlsx`, () => this.skuLoading = false);
    },

    // 上传
    uploadHsCode(response) {
      if (response == 'loading') {
        this.skuLoading = true
        return
      }
      if (!!response && response.code == 0) {
        this.skuLoading = false
      } else {
        this.skuLoading = false
      }
      this.Query()
    },
    //条数
    handleSizeChange(val) {
      this.pageSize = val
      let query = { current: this.pageCurrent, size: val }
      this.Query(query)
      console.log(`每页 ${val} 条`);
    },
    //当前页数
    handleCurrentChange(val) {
      this.pageCurrent = val
      let query = { current: val, size: this.pageSize }
      this.Query(query)
      console.log(`当前页: ${val}`);
    },
    //  新增数据   修改数据
    async modifyBtn(row, type) {
      this.btnType = type
      if (type == 'add') {
        this.dialogTitle = 'Add'
        //  新增数据 
        this.updateObj = {
          name: '',
          type: '',
          code: '',
          obDesc: '',
        }
        this.detailAdd = true
        if (this.$refs.updateObj !== undefined) {
          this.$refs.updateObj.resetFields();
        }
      } else {
        this.dialogTitle = 'Edit'
        // 修改数据
        this.updateObj = deepClone(row)
        this.detailAdd = true
        console.log('这一行的数据', JSON.parse(JSON.stringify(this.updateObj)))
      }
    },

    // 删除数据
    deleteBtn(index, row) {
      console.log('要删除的这一行数据', JSON.parse(JSON.stringify(row)))
      this.$confirm("This operation will permanently delete this data. Do you want to continue?", "Tips", {
        confirmButtonText: "submit",
        cancelButtonText: "cancel",
        type: "warning",
      })
        .then(async () => {
          let { data } = await delObj(row.id)
          if (data.code != 0) return this.$message.error(data.msg)
          this.$message.success(data.msg)
          this.Query()
        })
        .catch(() => {
        });
    },
    // add/修改数据提交按钮
    updateSub() {
      if (this.btnType == 'add') {
        // 添加数据 addObj
        this.$refs.updateObj.validate(async (valid) => {
          if (!valid) return false
          let { data } = await addObj(this.updateObj)
          console.log('添加后的数据返回', JSON.parse(JSON.stringify(data)))
          if (data.code != 0) return this.$message.error(data.msg);
          this.$message.success(data.msg);
          this.detailAdd = false
          this.Query()
        });

      } else {
        // 修改数据
        this.$refs.updateObj.validate(async (valid) => {
          if (!valid) return false
          let { data } = await update(this.updateObj)
          console.log('修改后的数据返回', JSON.parse(JSON.stringify(data)))
          if (data.code != 0) return this.$message.error(data.msg);
          this.$message.success(data.msg);
          this.detailAdd = false
          this.Query()
        });
      }
    },

    // 添加删除弹框的关闭按钮
    cancelClo() {
      this.detailAdd = false
    },
  },
};
</script>
<style lang="scss" scoped>
::v-deep .el-select--small {
  display: block;
}

// /* 去掉中间数据的分割线 */
// ::v-deep .el-table__row>td {
//   border: none;
// }

// /* 去掉上面的线 */
// ::v-deep .el-table th.is-leaf {
//   border: none;
// }

// /* 去掉最下面的那一条线 */
// ::v-deep .el-table::before {
//   height: 0px;
// }

.dialog-footer-add {
  display: flex;
  justify-content: center;
  color: rgb(64, 149, 229);
  font-size: 25px;
  margin: 20px 0;
}

.dialog-footer-box {
  display: flex;
  justify-content: center;
  margin-top: 100px;
}

.content {
  padding: 0 10px;

  // box-sizing: border-box;
  .down {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    border-top: 1px solid #999;
    padding-top: 20px;
    box-sizing: border-box;
  }

  .underLine {
    color: #599af8;
    text-decoration: underline;

    .underIcon {
      background-color: green;
      color: #fff;
      border-radius: 50%;
      margin-right: 5px;
    }
  }
}

.operate-icon-wrap {
  display: flex;
  column-gap: 15px;
}

.operate-icon-box {
  display: flex;
  align-items: center;
  cursor: pointer;
  color: #4095e5;
}

.header-cell-class {
  background-color: #ccc;
}

.foot {
  display: flex;
  justify-content: flex-end;
  margin-top: 20px;
}

.btn-bgc {
  background-color: rgb(31, 99, 255);
  color: #fff;
}

.confrim-bgc {
  background-color: #1376c7;
  color: #fff;
}

.cursor-on {
  cursor: pointer;
}

::v-deep .el-dialog__wrapper .el-dialog {
  border-radius: 8px;
}
</style>