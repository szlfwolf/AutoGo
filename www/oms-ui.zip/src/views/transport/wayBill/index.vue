<template>
  <div class="content" v-loading="wayBillLoading">
    <el-card class="box-card">
      <el-row style="width:200px;display:flex">
        <el-col>
          <el-button type="primary" icon="el-icon-search" @click="getSearchlist">Query</el-button>
        </el-col>
        <el-col>
          <el-button icon="el-icon-refresh-left" @click="getReset">Reset</el-button>
        </el-col>
      </el-row>
      <el-form ref="form" :model="form" style="margin: 20px 0" @keyup.enter.native="getSearchlist">
        <el-row :gutter="20">
          <el-col :span="4">
            <el-input v-model="form.order" placeholder="Track no/Batch no"></el-input>
          </el-col>
          <el-col :span="4">
            <el-select filterable v-model="form.warehouseCode" placeholder="Warehouse" filterable clearable>
              <el-option v-for="item in warehouseCode" :key="item.value" :label="item.warehouseName"
                :value="item.warehouseCode">
              </el-option>
            </el-select>
          </el-col>
          <el-col :span="4">
            <el-select filterable v-model="form.shipStatus" placeholder="status" filterable clearable>
              <el-option v-for="item in status" :key="item.value" :label="item.label" :value="item.value">
              </el-option>
            </el-select>
          </el-col>
          <el-col :span="4">
            <el-select filterable v-model="form.shipType" placeholder="Ship Type" filterable clearable>
              <el-option v-for="item in shipType" :key="item.value" :label="item.label" :value="item.value">
              </el-option>
            </el-select>
          </el-col>
          <el-col :span="4">
            <el-select filterable v-model="form.countryCode" placeholder="Country Code" filterable clearable>
              <el-option v-for="item in countryCode" :key="item.value" :label="item.label" :value="item.value">
              </el-option>
            </el-select>
          </el-col>
          <el-col :span="4">
            <el-button style="float:right" type="primary" @click="about"
              :icon="show?'el-icon-arrow-up': 'el-icon-arrow-down'">
              <label for="">{{show?'收起':'更多'}}</label>
            </el-button>
          </el-col>
        </el-row>
        <el-row v-show="show" style="margin-top: 10px" :gutter="20">
          <el-col :span="4">
            <el-date-picker v-model="time.createTime" type="daterange" start-placeholder="CreateTime"
              end-placeholder="CreateEndTime" :default-time="['00:00:00', '23:59:59']" value-format="yyyy-MM-dd HH:mm:ss"
              @change="changeCreateTime" />
          </el-col>
        </el-row>
      </el-form>
      <div class="down">
        <div></div>
        <el-button icon="el-icon-download" v-if="permissions.waybill_export" @click="exportExcel"></el-button>
      </div>
      <el-table border ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%"
        v-loading="dataListLoading" @selection-change="handleSelectionChange"
        :header-cell-style="{ background: '#f5f7fa', color: '#606266' }">
        <el-table-column type="selection" min-width="55" align="center"> </el-table-column>
        <el-table-column label="Owner" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.clientCode || '-' }}</template>
        </el-table-column>
        <el-table-column label="WarehouseCode" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.warehouseCode || '-' }}</template>
        </el-table-column>
        <el-table-column label="Batch no" min-width="180" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.batchNo || '-' }}</template>
        </el-table-column>
        <el-table-column label="Ship Type" min-width="120" align="center">
          <template slot-scope="scope">{{ wayBillType[scope.row.shipType] || '-' }}</template>
        </el-table-column>
        <el-table-column label="Track no" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.shipNo || '-' }}</template>
        </el-table-column>
        <el-table-column label="Country Code" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.countryCode || '-' }}</template>
        </el-table-column>
        <el-table-column label="Status" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.shipStatus || '-' }}</template>
        </el-table-column>
        <el-table-column label="Opearte" min-width="100" align="center" v-if="permissions.package_info_get">
          <template slot-scope="scope">
            <i style="font-size: 18px;cursor: pointer;color:#65BEFF;margin-right:10px" class="el-icon-view"
              @click="handleDetail(scope.row,scope.$index)" v-if="permissions.package_info_get"></i>
          </template>
        </el-table-column>
      </el-table>
      <Pagination @handleSizeChange="handleSizeChange" @handleCurrentChange="handleCurrentChange" :pageNum="page.current"
        :pageSize="page.size" :total="total"></Pagination>
      <Dialog :dialogView="dialogView" @handleClose="handleClose" :batchInfo="batchInfo"></Dialog>
    </el-card>
  </div>
</template>
<script>
import Pagination from "@/components/pagination/pagination.vue"
import { mapGetters } from "vuex"
import Dialog from "../booking/components/dialog.vue"
import { getWarehouse } from "@/api/stock/analysis"
import { pageQuery, getPackageInfoByBatchNo } from "@/api/transport/wayBill"
import { remote } from "@/api/admin/dict"

let formParams = {
  order: undefined,
  warehouseCode: undefined,
  shipStatus: undefined,
  shipType:undefined,
  countryCode:undefined
}
export default {
  name: "WayBill",
  data() {
    return {
      form: Object.assign({}, formParams),
      total: 0,
      page:{
        size: 10,
        current: 1,
      },
      formDialog: {
        warehouse: "",
        remark: "",
      },
      dataListLoading: false,
      tableData: [],
      warehouseCode:[],
      status:[],
      shipType:[],
      multipleSelection:[],
      time:{
        createTime:undefined
      },
      dialogView:false,
      batchInfo:[],
      show:false,
      countryCode:[],
      wayBillType:{
        1:"Express",
        2:"Tray",
        3:"Special Car"
      },
      wayBillLoading:false
    }
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  components: {
    Pagination,
    Dialog
  },
  async created() {
    await this.getWarehouseByClient()
    await this.getList()
  },
  methods: {
    //时间参数
    changeCreateTime(val){
      if (val !== undefined && val !== null && val !== '' && val.length > 0) {
        this.$set(this.form, 'startTime', val[0])
        this.$set(this.form, 'endTime', val[1])
      } else {
        this.$set(this.form, 'startTime', undefined)
        this.$set(this.form, 'endTime', undefined)
      }
    },
    //导出
    exportExcel() {
      this.wayBillLoading = true
      this.downBlobFilePost("/tms-bate/waybill/exportWaybillInfoByWhere", this.form , `${this.$store.state.common.commandName}-wayBill-${this.toDateFormat(new Date(), true)}.xlsx`,()=>this.wayBillLoading = false)
    },
    //展开
    about() {
      this.show = !this.show
    },
    //多选
    handleSelectionChange(val) {
      this.multipleSelection = val
      this.multipleSelection.forEach(ite=>{
      })
    },
    //条数
    handleSizeChange(val) {
      this.page.current = 1
      this.page.size = val
      this.getList(this.form)
    },
    //当前页数
    handleCurrentChange(val) {
      this.page.current = val
      this.getList(this.form)
    },
    //清空
    getReset() {
      this.form = Object.assign({}, formParams)
      this.page = this.$options.data().page
      this.getList()
    },
    //查询
    getSearchlist() {
      this.page.current = 1
      for (let key in this.form) {
        if(this.form[key] === '' || this.form[key] === null){
          this.form[key] = undefined
        }
      }
      this.getList(this.form)
    },
    //数据列表
    getList(params){
      this.dataListLoading = true
      pageQuery(Object.assign({...this.page},params)).then(res=>{
        console.log(res)
        if(res.data.code === 0){
          this.tableData = res.data.data.records
          this.tableData.forEach(item=>{
            this.warehouseCode.forEach(i=>{
              if(item.warehouseCode === i.warehouseCode){
                item.warehouseName = i.warehouseName           
              }
            })
          })
          this.total = res.data.data.total
          
          this.dataListLoading = false
        }else{
          this.$message.error(res.data.msg)
          this.dataListLoading = false
        }
      }).catch(()=>{
        this.$message.error('request was aborted')
        this.dataListLoading = false
      })
    },
    //详情
    handleDetail(row,index){
      getPackageInfoByBatchNo(row.batchNo).then(res=>{
        if(res.data.code === 0){
          this.dialogView = true
          this.batchInfo = res.data.data
        }else{
          this.$message.error(res.data.msg)
        }
      })
    },
    //子传父关闭详情dialog
    handleClose(e){
      this.dialogView = e
    },
    //warehouseCode下拉数据
    getWarehouseByClient(){
      getWarehouse().then(res=>{
        console.log(res) 
        if(res.data.code === 0){
         this.warehouseCode = res.data.data
        }
      })
      remote("wayBil_ship_type").then((res) => {
        if (res.data.code === 0) {
          this.shipType = res.data.data;
        }
      });
      remote("wayBill_ship_status").then((res) => {
        if (res.data.code === 0) {
          this.status = res.data.data;
        }
      });
      //countryCode
      remote('country_code').then(res=>{
        if(res.data.code === 0){
          this.countryCode = res.data.data
        }
      });
    },
  },
} 
</script>
<style lang="scss" scoped>
.content {
  padding: 0 10px;

  // box-sizing: border-box;
  .text {
    font-size: 14px;
  }

  .item {
    padding: 18px 0;
  }

  .box-card {
    width: 100%;
  }

  .down {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    border-top: 1px solid #999;
    padding-top: 20px;
    box-sizing: border-box;
  }

  .underLine {
    color: #599af8;
    text-decoration: underline;
  }

  ::v-deep .el-select--small {
    display: block;
  }

  ::v-deep .el-select--small {
    display: block;
  }

  ::v-deep .el-date-editor--daterange.el-input,
  ::v-deep .el-date-editor--daterange.el-input__inner,
  ::v-deep .el-date-editor--timerange.el-input,
  ::v-deep .el-date-editor--timerange.el-input__inner {
    width: 100% !important;
  }
}
</style>
