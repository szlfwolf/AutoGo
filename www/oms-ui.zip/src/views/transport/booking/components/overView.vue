<template>
  <div class="overView" v-loading="overViewLoading">
    <el-row style="width:200px;display:flex">
      <el-col>
        <el-button type="primary" icon="el-icon-search" @click="getSearchlist">Query</el-button>
      </el-col>
      <el-col>
        <el-button icon="el-icon-refresh-left" @click="getReset">Reset</el-button>
      </el-col>
    </el-row>
    <el-form ref="form" :model="form" style="margin: 20px 0" @keyup.enter.native="getSearchlist">
      <el-row :gutter="20">
        <el-col :span="4">
          <el-input v-model="form.batchNo" placeholder="Batch no"></el-input>
        </el-col>
        <el-col :span="4">
          <el-select filterable v-model="form.status" placeholder="Order Status" filterable clearable>
            <el-option v-for="item in status" :key="item.value" :label="item.label" :value="item.value">
            </el-option>
          </el-select>
        </el-col>
        <el-col :span="4">
          <el-select filterable v-model="form.countryCode" placeholder="Country Code" filterable clearable>
            <el-option v-for="item in countryCode" :key="item.value" :label="item.label" :value="item.value">
            </el-option>
          </el-select>
        </el-col>
        <el-col :span="4">
          <el-select filterable v-model="form.warehouseCode" placeholder="Warehouse" filterable clearable>
            <el-option v-for="item in warehouseCode" :key="item.value" :label="item.warehouseName"
              :value="item.warehouseCode">
            </el-option>
          </el-select>
        </el-col>
        <el-col :span="4">
          <el-date-picker v-model="form.startTime" type="datetime" default-time="12:00:00"
            value-format="yyyy-MM-dd HH:mm:ss" placeholder="Begin Picked">
          </el-date-picker>
        </el-col>
        <el-col :span="4">
          <el-button style="float:right" type="primary" @click="about"
            :icon="show?'el-icon-arrow-up': 'el-icon-arrow-down'">
            <label for="">{{show?'收起':'更多'}}</label>
          </el-button>
        </el-col>
      </el-row>
      <el-row v-show="show" style="margin-top: 10px" :gutter="20">
        <el-col :span="4">
          <el-date-picker v-model="form.endTime" type="datetime" default-time="12:00:00"
            value-format="yyyy-MM-dd HH:mm:ss" placeholder="End Picked">
          </el-date-picker>
        </el-col>
      </el-row>
    </el-form>
    <div class="down">
      <div></div>
      <div>
        <el-button icon="el-icon-download" @click="exportExcel" v-if="permissions.package_info_export"></el-button>
      </div>
    </div>
    <el-table border ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%"
      v-loading="dataListLoading" @selection-change="handleSelectionChange"
      :header-cell-style="{ background: '#f5f7fa', color: '#606266', 'text-align': 'center',}">
      <el-table-column type="selection" min-width="55" align="center"></el-table-column>
      <el-table-column label="Batch no" min-width="160" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.batchNo || "-" }}</template>
      </el-table-column>
      <el-table-column label="Client" min-width="120" align="center">
        <template slot-scope="scope">{{ scope.row.clientCode || "-" }}</template>
      </el-table-column>
      <el-table-column label="Warehouse" min-width="120" align="center">
        <template slot-scope="scope">{{ scope.row.warehouseCode || "-" }}</template>
      </el-table-column>
      <el-table-column label="Order Type" min-width="120" align="center">
        <template slot-scope="scope">{{ scope.row.dnType || "-" }}</template>
      </el-table-column>
      <el-table-column label="Country Code" min-width="120" align="center">
        <template slot-scope="scope">{{ scope.row.countryCode || "-" }}</template>
      </el-table-column>
      <el-table-column label="Dock" min-width="120" align="center">
        <template slot-scope="scope">{{ scope.row.dockNo || "-" }}</template>
      </el-table-column>
      <el-table-column label="Packed Time" min-width="140" align="center">
        <template slot-scope="scope">{{ scope.row.packedTime || "-" }}</template>
      </el-table-column>
      <el-table-column label="Packed Qty" min-width="120" align="center">
        <template slot-scope="scope">{{ scope.row.quantity || "-" }}</template>
      </el-table-column>
      <el-table-column label="Label" min-width="120" align="center" v-if="permissions.track_document_get">
        <template slot-scope="scope">
            <i
              style="font-size: 18px; cursor: pointer; margin-right: 10px; "
              :class="{
                'el-icon-document': true,
                'disabled': scope.row.document == null || scope.row.document === ''
              }"
              @click="scope.row.document != null && scope.row.document !== '' ? labelDownload(scope.row, scope.index) : null"
              :style="{ color: scope.row.document != null && scope.row.document !== '' ? '#65beff' : '#ccc',
                        pointerEvents: scope.row.document != null && scope.row.document !== '' ? 'auto' : 'none' }"
            ></i>
        </template>
      </el-table-column>
      <el-table-column label="Order Status" min-width="120" align="center" show-overflow-tooltip>
        <template slot-scope="scope">{{ scope.row.status || "-" }}</template>
      </el-table-column>
      <el-table-column label="Opearter" align="center" min-width="200"
        v-if="permissions.package_info_get || permissions.box_info_get || permissions.book_operation || permissions.pickUp_operation || permissions.pod_operation || permissions.package_info_export">
        <template slot-scope="scope">
          <i style="font-size: 18px;cursor: pointer;color: #65beff;margin-right: 10px;" class="el-icon-view"
            @click="seeBtn(scope.row,scope.$index)" v-if="permissions.package_info_get"></i>
          <i style="font-size: 18px; cursor: pointer; color: #65beff;margin-right: 10px;" class="el-icon-download"
            @click="downloadRow(scope.row,scope.$index)" v-if="permissions.package_info_export"></i>
          <el-button :disabled="scope.row.status !== 'PACKED'" style="font-size: 18px;padding:0;border:0"
            :style="{'color':scope.row.status !== 'PACKED'? '' :'#65beff'}" class="el-icon-edit"
            @click="handleEdit(scope.row,scope.$index)" v-if="permissions.box_info_get"></el-button>
          <el-button :disabled="scope.row.status !== 'PACKED'" style="font-size: 18px;padding:0;border:0"
            :style="{'color':scope.row.status !== 'PACKED'? '' :'#65beff'}" class="iconfont icon-fache"
            @click="startBtn(scope.row,scope.$index)" v-if="permissions.book_operation"></el-button>
          <el-button :disabled="scope.row.status !== 'BOOKED'"
            style="font-size: 18px;margin-right: 10px;padding:0;border:0"
            :style="{'color':scope.row.status !== 'BOOKED'? '' :'#65beff'}" class="iconfont icon-a-fahuodaifahuo"
            @click="deliverGoods(scope.row,scope.index)" v-if="permissions.pickUp_operation"></el-button>
          <el-button :disabled="scope.row.status !== 'OUTBOUND'"
            style="font-size: 18px;color: #65beff;padding:0;border:0;margin-left:0"
            :style="{'color':scope.row.status !== 'OUTBOUND'? '' :'#65beff'}" class="iconfont icon-shouhuoicon"
            @click="receiptGoods(scope.row,scope.index)" v-if="permissions.pod_operation"></el-button>
        </template>
      </el-table-column>
    </el-table>
    <Pagination @handleSizeChange="handleSizeChange" @handleCurrentChange="handleCurrentChange" :pageNum="page.current"
      :pageSize="page.size" :total="total"></Pagination>
    <Dialog :dialogView="dialogView" @handleClose="handleClose" :batchInfo="batchInfo"></Dialog>
    <OperatorDialog v-if="operateShow" :operatorDialogView="operatorDialogView" @getClose="getClose" :type="type"
      :title="title" :operateParams="operateParams"></OperatorDialog>
    <EditDialog v-if="editDialogView" :editDialogView="editDialogView" @handleEditClose="handleEditClose"
      :editDialogArr="editDialogArr"></EditDialog>
  </div>
</template>
<script>
import { mapGetters } from "vuex"
import Pagination from "@/components/pagination/pagination.vue"
import Dialog from "./dialog.vue"
import OperatorDialog from "./operatorDialog.vue"
import EditDialog from "./editDialog.vue"
import { pageQuery, geBatchNoInfo, getDocumentByBatchNo, getBoxInfoByBatchNo } from "@/api/transport/book"
import { getWarehouse } from "@/api/stock/analysis";
import { remote } from "@/api/admin/dict";
import { dateFormat } from "@/util/date"
let formParams = {
  batchNo: undefined,
  status:undefined,
  countryCode: undefined,
  warehouseCode:undefined,
  startTime:undefined,
  endTime:undefined
}
export default {
  name: "OverView",
  data() {
    return {
      form: Object.assign({}, formParams),
      total: 0,
      page:{
        size: 10,
        current: 1,  
      },
      dataListLoading: false,
      tableData: [],
      countryCode:[],
      status:[],
      dialogView:false,
      operatorDialogView:false,
      type:"",
      title:"",
      batchInfo:[],
      operateShow:false,
      operateParams:{},
      batchNos:[],
      multipleSelection:[],
      warehouseCode:[],
      show:false,
      editDialogView:false,//包装信息dialog
      editDialogArr:[],
      overViewLoading:false
    }
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  mounted(){
    this.exportExcel = this.$btn(this.exportExcel,500)
  },
  components: {
    Pagination,
    Dialog,
    OperatorDialog,
    EditDialog
  },
  created() {
    this.getList()
    this.getRemote()
  },
  methods: {
    //导出
    exportExcel() {
      this.overViewLoading = true
      this.downBlobFilePost("/tms-bate/dn/operate/exportPackageInfoByWhere", {batchNos:this.batchNos,...this.form}, `Package_Info_${dateFormat(new Date())}.xlsx`,()=>this.overViewLoading = false)
    },
    //展开
    about() {
      this.show = !this.show
    },
    //多选
    handleSelectionChange(val){
      this.multipleSelection = val
      this.batchNos = []
      this.multipleSelection.forEach(ite=>{
        this.batchNos.push(ite.batchNo)
      })
    },
    //条数
    handleSizeChange(val) {
      this.page.current = 1
      this.page.size = val
      this.getList(this.form)
    },
    //当前页数
    handleCurrentChange(val) {
      this.page.current = val
      this.getList(this.form)
    },
    //清空
    getReset() {
      this.form = Object.assign({}, formParams)
      this.page = this.$options.data().page
      this.getList()
    },
    //查询
    getSearchlist() {
      this.page.current = 1
      for (let key in this.form) {
        if(this.form[key] === '' || this.form[key] === null){
          this.form[key] = undefined
        }
      }
      this.getList(this.form)
    },
    //数据列表
    getList(params){
      this.dataListLoading = true
      pageQuery(Object.assign({...this.page},params)).then(res=>{
        console.log(res)
        if(res.data.code === 0){
          this.tableData = res.data.data.records
          this.total = res.data.data.total
          this.dataListLoading = false
        }else{
          this.$message.error(res.data.msg)
          this.dataListLoading = false
        }
      }).catch(()=>{
        this.$message.error('request was aborted')
        this.dataListLoading = false
      })
    },
    //导出
    downloadRow(row,index){
      this.downBlobFile(`/tms-bate/dn/operate/exportPackageInfoByBatchNo/${row.batchNo}`, {}, `Package_Info_${row.batchNo}_${dateFormat(new Date())}.xlsx`)
    },
    labelDownload(row,index){
      getDocumentByBatchNo(row).then(res=>{
        if(res.data.code === 0){
          const link = document.createElement('a');
          // 这里是将链接地址url转成blob地址，
          link.href = res.data.data
          link.target = "_blank"
          // 下载文件的名称及文件类型后缀
          link.download = `${row.batchNo}.xlsx`;
          document.body.appendChild(link)
          link.click()
          //在资源下载完成后 清除 占用的缓存资源
          window.URL.revokeObjectURL(link.href);
          document.body.removeChild(link);
        }
      })
    },
    //查看详情
    seeBtn(row,index){
      geBatchNoInfo(row.batchNo).then(res=>{
        console.log(res);
        if(res.data.code === 0){
          this.dialogView = true
          this.batchInfo = res.data.data
        }else{
          this.$message.error(res.data.msg)
        }
      })
    },
    //子传父关闭详情dialog
    handleClose(e){
      this.dialogView = e
    },
    //发车
    startBtn(row,index){
      this.title = `Shipments————Batch No:${row.batchNo}`
      this.type = 'book'
      this.operatorDialogView = true
      this.operateShow = true
      this.operateParams = row
    },
    //发货
    deliverGoods(row,index){
      this.title = "Pick Up"
      this.type = 'pickUp'
      this.operatorDialogView = true
      this.operateShow = true
      this.operateParams = row
    },
    //收货
    receiptGoods(row,index){
      this.title = "Delivered"
      this.type = 'pod'
      this.operatorDialogView = true
      this.operateShow = true
      this.operateParams = row
    },
    //子传父关闭发车dialog
    getClose(e,type){
      this.operatorDialogView = e
      this.operateShow = e
      if(type){
        this.getList()
      }
    },
    //获取包装信息
    handleEdit(row,index){
      getBoxInfoByBatchNo(row.batchNo).then(res=>{
        console.log(res);
        if(res.data.code === 0){
          this.editDialogView = true
          this.editDialogArr = res.data.data
        }else{
          this.$message.error(res.data.msg)
        }
      })
    },
    //关闭包装信息
    handleEditClose(e){
      this.editDialogView = e
    },
    getRemote(){
      remote("book_ship_status").then((res) => {
        if (res.data.code === 0) {
          this.status = res.data.data;
        }
      });
      //countryCode
      remote("country_code").then((res) => {
        if (res.data.code === 0) {
          this.countryCode = res.data.data;
        }
      });
      //warehouse
      getWarehouse().then((res) => {    
        if (res.data.code === 0) {
          this.warehouseCode = res.data.data;
        }
      });
    }
  },
} 
</script>
<style lang="scss" scoped>
.overView {
  .down {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    border-top: 1px solid #999;
    padding-top: 20px;
    box-sizing: border-box;
  }

  .underLine {
    cursor: pointer;
    color: #599af8;
    text-decoration: underline;
  }

  .success {
    color: rgb(137, 234, 137);
    font-size: 18px;
  }

  .error {
    color: rgb(238, 99, 99);
    font-size: 18px;
  }

  ::v-deep .el-dialog {
    border-radius: 8px !important;
  }

  ::v-deep .el-select--small {
    display: block;
  }

  ::v-deep .el-date-editor.el-input,
  ::v-deep .el-date-editor.el-input__inner {
    width: 100% !important;
  }

  .disabled {
  color: #ccc; /* 修改成禁用状态的颜色 */
  cursor: not-allowed; /* 改变鼠标样式 */
  /* 其他你想要修改的禁用状态样式 */
  }

}
</style>
