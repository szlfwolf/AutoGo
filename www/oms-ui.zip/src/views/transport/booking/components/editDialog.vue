<template>
  <div >
    <el-dialog
      title="Package Box Info"
      :visible="editDialogView"
      @close="handleClose"
      width="60%" 
      style="font-weight: 700" 
      >
      <el-form ref="formDialog" :model="formDialog" label-width="100px" :rules="rules">
        <el-table
          ref="multipleTable"
          :data="formDialog.tableDate"
          tooltip-effect="dark"
          style="width: 100%"
          :header-cell-style="{ background: '#f5f7fa', color: '#606266' }"
          border
        >
          <el-table-column label="Package No" align="center" min-width="120">
              <template slot-scope="scope">{{scope.row.packageNo}}</template>
          </el-table-column>
          <el-table-column label="Package Type" align="center" min-width="120">
              <template slot-scope="scope">{{scope.row.packageType}}</template>
          </el-table-column>
          <el-table-column label="Net Weight (kg)" align="center" min-width="120">
            <template slot-scope="scope">
              <el-form-item 
                style="margin-bottom: 0;margin-left:-100px" 
                :prop="'tableDate.' + scope.$index + '.netWeight'" 
                :rules="rules.netWeight">
                <el-input v-model="scope.row.netWeight"></el-input>
              </el-form-item>
            </template>
          </el-table-column>
          <el-table-column label="Gross Weight (kg)" min-width="140" align="center">
            <template slot-scope="scope">
              <el-form-item 
                style="margin-bottom: 0;margin-left:-100px" 
                :prop="'tableDate.' + scope.$index + '.grossWeight'" 
                :rules="rules.grossWeight">
                <el-input v-model="scope.row.grossWeight"></el-input>
              </el-form-item>
            </template>
          </el-table-column>
          <el-table-column label="Length (m)" min-width="120" align="center">
            <template slot-scope="scope">
              <el-form-item 
                style="margin-bottom: 0;margin-left:-100px" 
                :prop="'tableDate.' + scope.$index + '.length'" 
                :rules="rules.length">
                <el-input v-model="scope.row.length" @blur="recalculate(scope.row)"></el-input>
              </el-form-item>
            </template>
          </el-table-column>
          <el-table-column label="Width (m)" min-width="120" align="center">
            <template slot-scope="scope">
              <el-form-item 
                style="margin-bottom: 0;margin-left:-100px" 
                :prop="'tableDate.' + scope.$index + '.width'" 
                :rules="rules.width">
                <el-input v-model="scope.row.width" @blur="recalculate(scope.row)"></el-input>
              </el-form-item>
            </template>
          </el-table-column>
          <el-table-column label="Height (m)" min-width="120" align="center">
            <template slot-scope="scope">
              <el-form-item 
                style="margin-bottom: 0;margin-left:-100px" 
                :prop="'tableDate.' + scope.$index + '.height'" 
                :rules="rules.height">
                <el-input v-model="scope.row.height" @blur="recalculate(scope.row)"></el-input>
              </el-form-item>
            </template>
          </el-table-column>
          <el-table-column label="CBM (m³)" min-width="120" align="center">
            <template slot-scope="scope">
              <el-form-item 
                style="margin-bottom: 0;margin-left:-100px" 
                :prop="'tableDate.' + scope.$index + '.cbm'" 
                :rules="rules.cbm">
                <el-input v-model="scope.row.cbm" disabled></el-input>
              </el-form-item>
            </template>
          </el-table-column>
        </el-table>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button type="info" @click="handleClose">Cancel</el-button>
        <el-button type="primary" @click="dialogButton" v-if="permissions.box_info_edit">Confirm</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script>
import { mapGetters } from "vuex"
import { updateBoxInfoByBatchNo } from "@/api/transport/book"
export default {
  name: "Dialog",
  data() {
    var valdator = (rule, value, callback) => {
      console.log(value.length);
      if(value.length == 1 && value == 0 ){
        callback(new Error('请输入正确的正数'));
      }else{
        callback()
      }
    }
    return {
      formDialog:{
        tableDate:[]
      },
      rules:{
        netWeight: [{ required: true, message: "请选择type", trigger: "blur" },
        { pattern: /^[0-9]+([.]{1}[0-9]+){0,1}$/, message: '请输入正确的正数', trigger: 'blur' },
        { validator: valdator,trigger:'blur'}],
        grossWeight: [{ required: true, message: "请选择type", trigger: "blur" },
        { pattern: /^[0-9]+([.]{1}[0-9]+){0,1}$/, message: '请输入正确的正数', trigger: 'blur' },
        { validator: valdator,trigger:'blur'}],
        length: [{ required: true, message: "请选择type", trigger: "blur" },
        { pattern: /^[0-9]+([.]{1}[0-9]+){0,1}$/, message: '请输入正确的正数', trigger: 'blur' },
        { validator: valdator,trigger:'blur'}],
        width: [{ required: true, message: "请选择type", trigger: "blur" },
        { pattern: /^[0-9]+([.]{1}[0-9]+){0,1}$/, message: '请输入正确的正数', trigger: 'blur' },
        { validator: valdator,trigger:'blur'}],
        height: [{ required: true, message: "请选择type", trigger: "blur" },
        { pattern: /^[0-9]+([.]{1}[0-9]+){0,1}$/, message: '请输入正确的正数', trigger: 'blur' },
        { validator: valdator,trigger:'blur'}],
        cbm: [{ required: true, message: "请选择type", trigger: "blur" },
        { pattern: /^[0-9]+([.]{1}[0-9]+){0,1}$/, message: '请输入正确的正数', trigger: 'blur' },],
      }
    };
  },
  props: {
    editDialogView:{
      type:Boolean
    },
    editDialogArr:{
      type:Array
    },
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  created() {
    this.formDialog.tableDate = this.editDialogArr 
  },
  methods: {
    recalculate(row){
      console.log(row);
      let productValue = parseFloat(row.length * row.width * row.height).toFixed(4)
      console.log(productValue);
      this.$set(row,'cbm',productValue)
    },
    handleClose() {
      this.$emit("handleEditClose", false);
    },
    dialogButton(){
      console.log(this.formDialog.tableDate);
      this.$refs.formDialog.validate((valid)=>{
          if(!valid) return false
          updateBoxInfoByBatchNo(Object.assign({batchNo:this.editDialogArr[0].batchNo, packageBoxUpdateItem:this.formDialog.tableDate })).then(res=>{
            if(res.data.code === 0){
              this.$message.success('Package information modified successfully')
              this.$emit("handleEditClose", false);
            }else{
              this.$message.error(res.data.msg)
              this.$emit("handleEditClose", false);
            }
          }).catch(()=>{
            this.$emit("handleEditClose", false);
          })
      })
    }
  },
};
</script>
<style lang="scss" scoped>
::v-deep .el-drawer__body{
  padding: 10px;
}
</style>
