<template>
  <div>
    <el-dialog :title="title" :visible="operatorDialogView" :width="form.shipCompanyCode !== 'DHL(AUTO)' ? '35%' : '50%' "
      @close="close" style="font-weight: 700" v-loading="operatorDialog">
      <el-form :model="form" ref="form" :rules="rules" label-width="200px" v-if="type === 'book'">
        <el-form-item label="Type:" prop="shipType">
          <el-select filterable v-model="form.shipType" @change="typeChange" filterable clearable>
            <el-option v-for="item in operateType" :key="item.value" :label="item.label" :value="item.value">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="Fleet:" prop="shipCompanyCode">
          <el-select filterable v-model="form.shipCompanyCode" @change="selectChange" filterable clearable>
            <el-option v-for="item in fleetType" :key="item.supplierCode" :label="item.supplierName"
              :value="item.supplierCode">
            </el-option>
          </el-select>
        </el-form-item>
        <div v-if="form.shipType == 3">
          <el-form-item label="Special Car Price:" prop="specialCarPrice">
            <el-input v-model="form.specialCarPrice"></el-input>
          </el-form-item>
          <el-form-item label="Special Car Price Unit:" prop="specialCarPriceUnit">
            <el-select filterable v-model="form.specialCarPriceUnit" @change="selectChange" filterable clearable>
              <el-option v-for="item in monetaryUnit" :key="item.value" :label="item.label" :value="item.value">
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="Special Car Floating Rater:" prop="specialCarFloatingRate">
            <el-input v-model="form.specialCarFloatingRate">
              <template slot="append">%</template>
            </el-input>
          </el-form-item>
        </div>
        <div v-if="form.shipCompanyCode !== 'DHL(AUTO)'">
          <el-form-item label="Tracking Number:" prop="shipNo">
            <el-input v-model="form.shipNo"></el-input>
          </el-form-item>
          <el-form-item label="Truck Number:" prop="waybillNo">
            <el-input v-model="form.waybillNo"></el-input>
          </el-form-item>
        </div>
        <el-row v-else>
          <el-form-item label="Service Type:" prop="serviceType">
            <el-select filterable v-model="form.serviceType" @change="serviceSelect" filterable clearable>
              <el-option v-for="item in serviceType" :key="item.key" :label="item.key" :value="item.key">
                <el-tooltip class="item" effect="dark" :content="item.value" placement="top-start">
                  <span style="float: left;width:100%">{{ item.key }}</span>
                </el-tooltip>
              </el-option>
            </el-select>
          </el-form-item>
          <el-col :span="12">
            <el-form-item label="Docks:">
              <el-input v-model="form.warehouse.dockNos" disabled autocomplete="off"></el-input>
            </el-form-item>
            <el-form-item label="Addresser:" prop="warehouse.contactName">
              <el-input v-model="form.warehouse.contactName" disabled></el-input>
            </el-form-item>
            <el-form-item label="Addresser Number:" prop="warehouse.contactPhone">
              <el-input v-model="form.warehouse.contactPhone" disabled></el-input>
            </el-form-item>
            <el-form-item label="Addresser Email:" prop="warehouse.contactEmail">
              <el-input v-model="form.warehouse.contactEmail" disabled></el-input>
            </el-form-item>
            <el-form-item label="Addresser Address:" prop="warehouse.address">
              <el-input v-model="form.warehouse.address" disabled></el-input>
            </el-form-item>
            <el-form-item label="Addresser Zip Code:" prop="warehouse.zipCode">
              <el-input v-model="form.warehouse.zipCode" disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="Consignee:" prop="consignee.contactName">
              <el-input v-model="form.consignee.contactName" disabled></el-input>
            </el-form-item>
            <el-form-item label="Consignee Number:" prop="consignee.contactPhone">
              <el-input v-model="form.consignee.contactPhone" disabled></el-input>
            </el-form-item>
            <el-form-item label="Consignee Email:" prop="consignee.contactEmail">
              <el-input v-model="form.consignee.contactEmail" disabled></el-input>
            </el-form-item>
            <el-form-item label="Consignee Address:" prop="consignee.address">
              <el-input v-model="form.consignee.address" disabled></el-input>
            </el-form-item>
            <el-form-item label="Consignee Zip Code:" prop="consignee.zipCode">
              <el-input v-model="form.consignee.zipCode" disabled></el-input>
            </el-form-item>
            <el-form-item label="Consignee Country Code:">
              <el-input v-model="form.consignee.countryCode" disabled></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <el-form :model="formDialog" ref="formDialog" :rules="formDialogRules" label-width="120px"
        v-else-if="type === 'pickUp'">
        <el-form-item label="Batch No:">
          <el-input v-model="formDialog.batchNo" disabled></el-input>
        </el-form-item>
        <el-form-item label="Pick Up Time:" prop="operateTime">
          <el-date-picker v-model="formDialog.operateTime" type="datetime" value-format="yyyy-MM-dd HH:mm:ss">
          </el-date-picker>
        </el-form-item>
      </el-form>
      <el-form :model="deliverForm" ref="deliverForm" :rules="deliverRules" label-width="140px" v-else>
        <el-form-item label="Batch No:">
          <el-input v-model="deliverForm.batchNo" disabled></el-input>
        </el-form-item>
        <el-form-item label="Delivered Time:" prop="operateTime">
          <el-date-picker v-model="deliverForm.operateTime" type="datetime" value-format="yyyy-MM-dd HH:mm:ss"
            default-value>
          </el-date-picker>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button type="info" @click="close">Cancel</el-button>
        <el-button type="primary" @click="dialogButton">Confirm</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script>
import { remote } from "@/api/admin/dict";
import { dateFormat } from "@/util/date"
import { getAllSupplierInfo, getBook, getPickUp, getPod, getDhlServiceTypeList, getBatchAddressInfo,getNotification } from "@/api/transport/book";
export default {
  name: "OperatorDialog",
  data() {
    return {
      form: {
        shipType: undefined,
        shipCompanyCode: undefined,
        shipNo: undefined,
        waybillNo: undefined,
        serviceType: undefined,
        serviceTypeRates: undefined,
        specialCarPrice:undefined,
        specialCarPriceUnit:undefined,
        specialCarFloatingRate:undefined,
        warehouse:{
          dockNos:undefined,
          contactName:undefined,
          contactPhone:undefined,
          contactEmail:undefined,
          address:undefined,
          zipCode:undefined,
        },
        consignee:{
          contactName:undefined,
          contactPhone:undefined,
          contactEmail:undefined,
          address:undefined,
          zipCode:undefined,
          countryCode:undefined
        }
      },
      formDialog: {
        batchNo: "",
        operateTime: "",
      },
      deliverForm: {
        batchNo: "",
        operateTime: "",
      },
      rules: {
        shipType: [{ required: true, message: "请选择type", trigger: "change" }],
        shipCompanyCode: [{ required: true, message: "请选择fleet", trigger: "change" }],
        shipNo: [{ required: true, message: "请输入trackingNumber", trigger: "blur" }],
        waybillNo: [{ required: true, message: "请输入truckNumber", trigger: "blur" }],
        serviceType: [{ required: true, message: "请输入serviceType", trigger: "blur" }],
        specialCarFloatingRate: [{ required: true, message: "请输入specialCarFloatingRate", trigger: "blur" },
        { pattern: /^[0-9]+([.]{1}[0-9]+){0,1}$/, message: '请输入正确的正数', trigger: 'blur' },],
        specialCarPrice: [{ required: true, message: "请输入specialCarPrice", trigger: "blur" },
        { pattern: /^[0-9]+([.]{1}[0-9]+){0,1}$/, message: '请输入正确的正数', trigger: 'blur' },
        ],
        specialCarPriceUnit:[{ required: true, message: "请输入specialCarPriceUnit", trigger: "change" }],
        warehouse:{
          contactName: [{ required: true, message: "请输入contactName", trigger: "blur" }],
          contactPhone: [{ required: true, message: "请输入contactPhone", trigger: "blur" }],
          contactEmail: [{ required: true, message: "请输入contactEmail", trigger: "blur" }],
          address: [{ required: true, message: "请输入address", trigger: "blur" }],
          zipCode: [{ required: true, message: "请输入zipCode", trigger: "blur" }],
        },
        consignee:{
          contactName: [{ required: true, message: "请输入contactName", trigger: "blur" }],
          contactPhone: [{ required: true, message: "请输入contactPhone", trigger: "blur" }],
          contactEmail: [{ required: true, message: "请输入contactEmail", trigger: "blur" }],
          address: [{ required: true, message: "请输入address", trigger: "blur" }],
          zipCode: [{ required: true, message: "请输入zipCode", trigger: "blur" }],
          countryCode: [{ required: true, message: "请输入countryCode", trigger: "blur" }],
        },
      },
      formDialogRules: {
        operateTime: [{ required: true, message: "请输入pickUpTime", trigger: "blur" }],
      },
      deliverRules: {
        operateTime: [{ required: true, message: "请输入操作时间", trigger: "blur" }],
      },
      fleetType: [],
      monetaryUnit:[],
      operateType: [
       
      ],
      serviceType:[],
      operatorDialog:false,
    };
  },
  props: {
    operatorDialogView: {
      type: Boolean,
    },
    title: {
      type: String,
    },
    type: {
      type: String,
    },
    operateParams: {
      type: Object,
    },
  },
  created() {
    console.log(this.operateParams);
    if (this.type === "pickUp") {
      this.formDialog = this.operateParams;
    } else if (this.type === "pod") {
      this.deliverForm = this.operateParams;
    }
    this.getRemote()

    //获取当前时间
    this.$set(this.deliverForm,'operateTime',dateFormat(new Date()))
    this.$set(this.formDialog,'operateTime',dateFormat(new Date()))
  },
  methods: {
    //关闭
    close() {
      this.$emit("getClose", false);
      if (this.type === "pickUp") {
        this.$refs.formDialog.resetFields()
      } else if (this.type === "pod") {
        this.$refs.deliverForm.resetFields()
      }
    },
    //下拉选择触发
    typeChange(e) {
      console.log(e);
      if(e){
        getAllSupplierInfo(e).then((res) => {
          if(res.data.code === 0){
            this.fleetType = res.data.data;
          }
        });
      }else{
        this.fleetType = []
      }
      this.form.shipCompanyCode = undefined
    },
    selectChange(e) {
      console.log(e);
      if(e === 'DHL(AUTO)'){
        this.getSelect()
        // this.form = this.$options.data().form
        this.operatorDialog = true
      }
    },
    serviceSelect(e){
      this.serviceType.forEach(ite=>{
        if(ite.key === this.form.serviceType){
          this.form.serviceTypeRates = ite.value
        }
      })
    },
    //操作确认
    dialogButton() {
      if (this.type === "book") {
        this.$refs.form.validate((valid)=>{
          if(!valid) return false
          if(this.form.shipCompanyCode !== 'DHL(AUTO)'){
            this.operatorDialog = true
            getBook(Object.assign({...this.form},{batchNo:this.operateParams.batchNo})).then(res=>{
              if(res.data.code === 0){
                this.$message.success('Successfully ordered the car')
                this.$emit("getClose", false,'refresh');
                this.operatorDialog = false
              }else{
                this.$message.error(res.data.msg)
                this.$emit("getClose", false);
                this.operatorDialog = false
              }
            }).catch(()=>{
              this.$emit("getClose", false);
              this.operatorDialog = false
            })
          }else{
            this.operatorDialog = true
            getNotification(Object.assign({...this.form},{batchNo:this.operateParams.batchNo})).then(res=>{
              if(res.data.code === 0){
                this.$message.success('Successfully ordered the car')
                this.$emit("getClose", false,'refresh');
                this.operatorDialog = false
              }else{
                this.$message.error(res.data.msg)
                this.$emit("getClose", false);
                this.operatorDialog = false
              }
            }).catch(()=>{
              this.$emit("getClose", false);
              this.operatorDialog = false
            })
          }
        })
      } else if (this.type === "pickUp") {
        this.$refs.formDialog.validate((valid)=>{
          if(!valid) return false
          this.operatorDialog = true
          getPickUp(Object.assign({ ...this.formDialog }, { operateType: "PickUp" })).then((res) => {
            console.log(res);
            if (res.data.code === 0) {
              this.$message.success(`${this.formDialog.batchNo} Succeeded in soliciting parts`);
              this.$emit("getClose", false,'refresh');
              this.operatorDialog = false
            } else {
              this.$message.error(res.data.msg);
              this.$emit("getClose", false);
              this.operatorDialog = false
            }
          }).catch(() => {
            this.$emit("getClose", false);
            this.operatorDialog = false
          });
        })
      } else {
        this.$refs.deliverForm.validate((valid)=>{
          if(!valid) return false
          this.operatorDialog = true
          getPod(Object.assign({ ...this.deliverForm }, { operateType: "POD" })).then((res) => {
            console.log(res);
            if (res.data.code === 0) {
              this.$message.success(`${this.deliverForm.batchNo} Goods received successfully`);
              this.$emit("getClose", false,'refresh');
              this.operatorDialog = false
            } else {
              this.$message.error(res.data.msg);
              this.$emit("getClose", false);
              this.operatorDialog = false
            }
          }).catch(() => {
            this.$emit("getClose", false);
            this.operatorDialog = false
          });
        })
      }
    },
    getSelect(){
      getDhlServiceTypeList(this.operateParams).then(res=>{
        console.log(res);
        if(res.data.code === 0){
          this.serviceType = res.data.data
          this.operatorDialog = false
        }else{
          this.operatorDialog = false
        }
      }).catch(()=>{
        this.operatorDialog = false
      })
      getBatchAddressInfo(this.operateParams).then(res=>{
        console.log(res); 
        if(res.data.code === 0){
          this.form.warehouse = res.data.data.dnWarehouseAddressInfoVo
          this.form.consignee = res.data.data.dnConsigneeAddressInfoVo
        }
      })
    },
    getRemote(){
      remote("monetary_unit").then((res) => {
        if (res.data.code === 0) {
          this.monetaryUnit = res.data.data;
        }
      });
      remote("wayBil_ship_type").then((res) => {
        if (res.data.code === 0) {
          this.operateType = res.data.data;
        }
      });
    }
  },
};
</script>
<style lang="scss" scoped>
::v-deep .el-drawer__body {
  padding: 10px;
}
</style>
