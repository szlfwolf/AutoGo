<template>
  <div >
    <el-dialog
      title="Package Info"
      :visible="dialogView"
      @close="handleClose"
      width="60%" 
      style="font-weight: 700" 
      >
        <el-table
          ref="multipleTable"
          :data="batchInfo"
          tooltip-effect="dark"
          style="width: 100%"
          :header-cell-style="{ background: '#f5f7fa', color: '#606266' }"
          border
        >
          <el-table-column label="No" align="center" min-width="80" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.$index + 1 }}</template>
          </el-table-column>
          <el-table-column label="Batch no" min-width="160" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.batchNo || "-"}}</template>
          </el-table-column>
          <el-table-column label="Package Number" min-width="160" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.packageNo || "-"}}</template>
          </el-table-column>
          <el-table-column label="Part Number" min-width="160" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.partNumber || "0"}}</template>
          </el-table-column>
          <el-table-column label="Outbound Dispatch Position" min-width="200" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.lineNo || "-"}}</template>
          </el-table-column>
          <el-table-column label="Quantity" min-width="160" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.num || "-"}}</template>
          </el-table-column>
        </el-table>
    </el-dialog>
  </div>
</template>
<script>
export default {
  name: "Dialog",
  data() {
    return {
      
    };
  },
  props: {
    dialogView:{
      type:Boolean
    },
    batchInfo:{
      type:Array
    },
    AllDrawerObj:{
      type:Object
    },
    AllDrawerRow:{
      type:Object
    }
  },
  created() {},
  methods: {
    handleClose() {
      this.$emit("handleClose", false);
    }
  },
};
</script>
<style lang="scss" scoped>
::v-deep .el-drawer__body{
  padding: 10px;
}
</style>
