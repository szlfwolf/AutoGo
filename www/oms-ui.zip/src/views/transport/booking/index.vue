<template>
  <div class="content" v-loading="bookingLoading">
    <el-tabs type="border-card" v-model="activeName" @tab-click="handleClick">
      <el-tab-pane label="Book" name="Book" v-if="permissions.stock_skuwarehousestock_part">
        <el-row style="width:200px;display:flex">
          <el-col>
            <el-button type="primary" icon="el-icon-search" @click="getSearchlist">Query</el-button>
          </el-col>
          <el-col>
            <el-button icon="el-icon-refresh-left" @click="getReset">Reset</el-button>
          </el-col>
        </el-row>
        <el-form ref="form" :model="form" style="margin: 20px 0" @keyup.enter.native="getSearchlist">
          <el-row :gutter="20">
            <el-col :span="4">
              <el-input v-model="form.batchNo" placeholder="Batch no"></el-input>
            </el-col>
            <el-col :span="4">
              <el-select filterable v-model="form.countryCode" placeholder="Country Code" filterable clearable
                role="tooltip">
                <el-option v-for="item in countryCode" :key="item.value" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </el-col>
            <el-col :span="4">
              <el-select filterable v-model="form.warehouseCode" placeholder="Warehouse" filterable clearable>
                <el-option v-for="item in warehouseCode" :key="item.value" :label="item.warehouseName"
                  :value="item.warehouseCode">
                </el-option>
              </el-select>
            </el-col>
            <el-col :span="4">
              <el-date-picker v-model="form.startTime" type="datetime" value-format="yyyy-MM-dd HH:mm:ss"
                placeholder="Begin Picked">
              </el-date-picker>
            </el-col>
            <el-col :span="4">
              <el-date-picker v-model="form.endTime" type="datetime" value-format="yyyy-MM-dd HH:mm:ss"
                placeholder="End Picked">
              </el-date-picker>
            </el-col>
          </el-row>
        </el-form>
        <div class="down">
          <div></div>
          <div>
            <el-button icon="el-icon-download" @click="exportExcel" v-if="permissions.package_info_export"></el-button>
          </div>
        </div>
        <el-table border ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%"
          v-loading="dataListLoading" @selection-change="handleSelectionChange"
          :header-cell-style="{ background: '#f5f7fa', color: '#606266', 'text-align': 'center',}">
          <el-table-column type="selection" min-width="55" align="center"></el-table-column>
          <el-table-column label="Batch no" min-width="160" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.batchNo || "-" }}</template>
          </el-table-column>
          <el-table-column label="Client" min-width="120" align="center">
            <template slot-scope="scope">{{ scope.row.clientCode || "-" }}</template>
          </el-table-column>
          <el-table-column label="Warehouse" min-width="120" align="center">
            <template slot-scope="scope">{{ scope.row.warehouseCode || "-" }}</template>
          </el-table-column>
          <el-table-column label="Order Type" min-width="120" align="center">
            <template slot-scope="scope">{{ scope.row.dnType || "-" }}</template>
          </el-table-column>
          <el-table-column label="Country Code" min-width="120" align="center">
            <template slot-scope="scope">{{ scope.row.countryCode || "-" }}</template>
          </el-table-column>
          <el-table-column label="Dock" min-width="120" align="center">
            <template slot-scope="scope">{{ scope.row.dockNo || "-" }}</template>
          </el-table-column>
          <el-table-column label="Packed Time" min-width="140" align="center">
            <template slot-scope="scope">{{ scope.row.packedTime || "-" }}</template>
          </el-table-column>
          <el-table-column label="Packed Qty" min-width="120" align="center">
            <template slot-scope="scope">{{ scope.row.quantity || "-" }}</template>
          </el-table-column>
          <el-table-column label="Order Status" min-width="120" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.status || "-" }}</template>
          </el-table-column>
          <el-table-column label="Opearter" align="center" min-width="140"
            v-if="permissions.package_info_get || permissions.box_info_get || permissions.book_operation || permissions.package_info_export">
            <template slot-scope="scope">
              <i style="font-size: 18px;cursor: pointer;color: #65beff;margin-right: 10px;" class="el-icon-view"
                @click="seeBtn(scope.row,scope.$index)" v-if="permissions.package_info_get"></i>
              <i style="font-size: 18px;cursor: pointer;color:#65BEFF;margin-right: 10px;" class="el-icon-edit"
                @click="handleEdit(scope.row,scope.$index)" v-if="permissions.box_info_get"></i>
              <i style="font-size: 18px; cursor: pointer; color: #65beff;margin-right: 10px;" class="el-icon-download"
                @click="downloadRow(scope.row,scope.$index)" v-if="permissions.package_info_export"></i>
              <i style="font-size: 18px; cursor: pointer; color: #65beff" class="iconfont icon-fache"
                @click="startBtn(scope.row,scope.$index)" v-if="permissions.book_operation"></i>
            </template>
          </el-table-column>
        </el-table>
        <Pagination @handleSizeChange="handleSizeChange" @handleCurrentChange="handleCurrentChange"
          :pageNum="page.current" :pageSize="page.size" :total="total"></Pagination>
        <Dialog :dialogView="dialogView" @handleClose="handleClose" :batchInfo="batchInfo"></Dialog>
        <OperatorDialog v-if="operateShow" :operatorDialogView="operatorDialogView" @getClose="getClose" :type="type"
          :title="title" :operateParams="operateParams"></OperatorDialog>
        <EditDialog v-if="editDialogView" :editDialogView="editDialogView" @handleEditClose="handleEditClose"
          :editDialogArr="editDialogArr"></EditDialog>
      </el-tab-pane>
      <el-tab-pane label="PickUp" name="PickUp">
        <PickUp v-if="pickUp"></PickUp>
      </el-tab-pane>
      <el-tab-pane label="POD" name="PodPage">
        <PodPage v-if="podPage"></PodPage>
      </el-tab-pane>
      <el-tab-pane label="OverView" name="OverView">
        <OverView v-if="overView"></OverView>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>
<script>
import { mapGetters } from "vuex"
import Pagination from "@/components/pagination/pagination.vue"
import PickUp from "./components/pickUp.vue"
import PodPage from "./components/podPage.vue"
import OverView from "./components/overView.vue"
import Dialog from "./components/dialog.vue"
import OperatorDialog from "./components/operatorDialog.vue"
import EditDialog from "./components/editDialog.vue"
import { pageQuery, geBatchNoInfo, getBoxInfoByBatchNo } from "@/api/transport/book"
import { getWarehouse } from "@/api/stock/analysis";
import { remote } from "@/api/admin/dict";
import { dateFormat } from "@/util/date"
let formParams = {
  batchNo: undefined,
  countryCode: undefined,
  warehouseCode:undefined,
  startTime:undefined,
  endTime:undefined
}
export default {
  name: "Order",
  data() {
    return {
      form: Object.assign({}, formParams),
      total: 0,
      page:{
        size: 10,
        current: 1,  
        status:"PACKED"
      },
      dataListLoading: false,
      activeName:"Book",
      countryCode: [],
      tableData: [],
      show:false,
      pickUp:false,
      podPage:false,
      overView:false,
      dialogView:false,//dialog
      operatorDialogView:false,//operatorDialog
      title:"",
      type:'',
      batchInfo:[],
      operateShow:false,
      operateParams:{},
      batchNos:[],
      multipleSelection:[],
      warehouseCode:[],
      bookingLoading:false,
      editDialogView:false,//包装信息dialog
      editDialogArr:[]
    }
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  mounted(){
    this.exportExcel = this.$btn(this.exportExcel,500)
  },
  components: {
    Pagination,
    PickUp,
    PodPage,
    OverView,
    Dialog,
    OperatorDialog,
    EditDialog
  },
  created() {
    this.getList()
    this.getRemote()
  },
  methods: {
    //切换
    handleClick() {
      if(this.activeName === 'PickUp'){
        this.pickUp = true
        this.podPage = false
        this.overView = false
      }else if(this.activeName === 'PodPage'){
        this.pickUp = false
        this.podPage = true
        this.overView = false
      }else if(this.activeName === 'OverView'){
        this.pickUp = false
        this.podPage = false
        this.overView = true
      }else{
        this.pickUp = false
        this.podPage = false
        this.overView = false
        this.getReset()//table数据
      }
    },
    //导出
    exportExcel() {
      this.bookingLoading = true
      this.downBlobFilePost("/tms-bate/dn/operate/exportPackageInfoByWhere", {batchNos:this.batchNos,...this.form,status:"PACKED"}, `Package_Info_${dateFormat(new Date())}.xlsx`,()=> this.bookingLoading = false)
    },
    //多选
    handleSelectionChange(val){
      this.multipleSelection = val
      this.batchNos = []
      this.multipleSelection.forEach(ite=>{
        this.batchNos.push(ite.batchNo)
      })
    },
    //条数
    handleSizeChange(val) {
      this.page.current = 1
      this.page.size = val
      this.getList(this.form)
    },
    //当前页数
    handleCurrentChange(val) {
      this.page.current = val
      this.getList(this.form)
    },
    //清空
    getReset() {
      this.form = Object.assign({}, formParams)
      this.page = this.$options.data().page
      this.getList()
    },
    //查询
    getSearchlist() {
      this.page.current = 1
      for (let key in this.form) {
        if(this.form[key] === '' || this.form[key] === null){
          this.form[key] = undefined
        }
      }
      this.getList(this.form)
    },
    //数据列表
    getList(params){
      this.dataListLoading = true
      pageQuery(Object.assign({...this.page},params)).then(res=>{
        console.log(res)
        if(res.data.code === 0){
          this.tableData = res.data.data.records
          this.total = res.data.data.total
          this.dataListLoading = false
        }else{
          this.$message.error(res.data.msg)
          this.dataListLoading = false
        }
      }).catch(()=>{
        this.$message.error('request was aborted')
        this.dataListLoading = false
      })
    },
    //导出
    downloadRow(row,index){
      this.downBlobFile(`/tms-bate/dn/operate/exportPackageInfoByBatchNo/${row.batchNo}`, {}, `Package_Info_${row.batchNo}_${dateFormat(new Date())}.xlsx`)
    },
    //查看详情
    seeBtn(row,index){
      geBatchNoInfo(row.batchNo).then(res=>{
        console.log(res);
        if(res.data.code === 0){
          this.dialogView = true
          this.batchInfo = res.data.data
        }else{
          this.$message.error(res.data.msg)
        }
      })
    },
    //子传父关闭详情dialog
    handleClose(e){
      this.dialogView = e
    },
    //发车
    startBtn(row,index){
      this.title = `Shipments————Batch No:${row.batchNo}`
      this.type = 'book'
      this.operatorDialogView = true
      this.operateShow = true
      this.operateParams = row
    },
    //子传父关闭发车dialog
    getClose(e,type){
      this.operatorDialogView = e
      this.operateShow = e
      if(type){
        this.getList()
      }
    },
    //获取包装信息
    handleEdit(row,index){
      getBoxInfoByBatchNo(row.batchNo).then(res=>{
        console.log(res);
        if(res.data.code === 0){
          this.editDialogView = true
          this.editDialogArr = res.data.data
        }else{
          this.$message.error(res.data.msg)
        }
      })
    },
    //关闭包装信息
    handleEditClose(e){
      this.editDialogView = e
    },
    getRemote(){
      remote("country_code").then((res) => {
        if (res.data.code === 0) {
          this.countryCode = res.data.data;
        }
      });
      //warehouse
      getWarehouse().then((res) => {
        if (res.data.code === 0) {
          this.warehouseCode = res.data.data;
        }
      });
    }
  },
} 
</script>
<style lang="scss" scoped>
.content {
  padding: 0 10px;

  // box-sizing: border-box;
  .down {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    border-top: 1px solid #999;
    padding-top: 20px;
    box-sizing: border-box;
  }

  .underLine {
    cursor: pointer;
    color: #599af8;
    text-decoration: underline;
  }

  .success {
    color: rgb(137, 234, 137);
    font-size: 18px;
  }

  .error {
    color: rgb(238, 99, 99);
    font-size: 18px;
  }

  ::v-deep .el-dialog {
    border-radius: 8px !important;
  }

  ::v-deep .el-select--small {
    display: block;
  }

  // ::v-deep .el-table__header-wrapper  .el-checkbox{//找到表头那一行，然后把里面的复选框隐藏掉
  //   display:none
  // } 
  ::v-deep .el-date-editor.el-input,
  ::v-deep .el-date-editor.el-input__inner {
    width: 100% !important;
  }
}
</style>
