<template>
  <div class="content">
    <el-card class="box-card" v-loading="sapReturnOrderLoading">
      <el-row style="width: 200px; display: flex">
        <el-col>
          <el-button type="primary" icon="el-icon-search" @click="getSearchlist">Query</el-button>
        </el-col>
        <el-col>
          <el-button icon="el-icon-refresh-left" @click="getReset">Reset</el-button>
        </el-col>
      </el-row>
      <el-form ref="form" :model="form" style="margin: 20px 0" @keyup.enter.native="getSearchlist">
        <el-row :gutter="20">
          <el-col :span="4">
            <el-input v-model="form.orderNum" placeholder="Order no"></el-input>
          </el-col>
          <el-col :span="4">
            <el-input v-model="form.remark" placeholder="Remark"></el-input>
          </el-col>
          <el-col :span="4">
            <el-select v-model="form.warehouseCode" placeholder="Warehouse" filterable clearable>
              <el-option v-for="item in warehouseCode" :key="item.value" :label="item.label" :value="item.value">
              </el-option>
            </el-select>
          </el-col>
          <el-col :span="4">
            <el-select v-model="form.status" placeholder="status" filterable clearable>
              <el-option v-for="item in status" :key="item.value" :label="item.label" :value="item.value">
              </el-option>
            </el-select>
          </el-col>
          <el-col :span="4">
            <el-date-picker v-model="time.createTime" type="daterange" start-placeholder="CreateTime"
              end-placeholder="CreateEndTime" :default-time="['00:00:00', '23:59:59']" value-format="yyyy-MM-dd HH:mm:ss"
              @change="changeCreateTime" />
          </el-col>
          <el-col :span="4">
            <el-button style="float: right" type="primary" @click="about"
              :icon="show ? 'el-icon-arrow-up' : 'el-icon-arrow-down'">
              <label>{{ show ? "收起" : "更多" }}</label>
            </el-button>
          </el-col>
        </el-row>
        <el-row v-show="show" style="margin-top: 10px" :gutter="20">
          <el-col :span="4">
            <el-date-picker v-model="time.finishedTime" type="daterange" start-placeholder="FinishTime"
              end-placeholder="FinishEndTime" :default-time="['00:00:00', '23:59:59']" value-format="yyyy-MM-dd HH:mm:ss"
              @change="changeFinishTime">
            </el-date-picker>
          </el-col>
          <el-col :span="4">
            <el-date-picker v-model="time.closeTime" type="daterange" start-placeholder="closeTime"
              end-placeholder="closeEndTime" :default-time="['00:00:00', '23:59:59']" value-format="yyyy-MM-dd HH:mm:ss"
              @change="changeCloseTime">
            </el-date-picker>
          </el-col>
        </el-row>
      </el-form>
      <div class="down">
        <div></div>
        <div>
          <el-button icon="el-icon-upload2" @click="$refs.excelUpload.show()"
            v-if="permissions.stock_skuwarehousestock_uploadYearAndReportByExcel"></el-button>
          <el-button icon="el-icon-download" @click="exportExcel"
            v-if="permissions.return_returnorder_export"></el-button>
        </div>
      </div>
      <el-table border ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%"
        v-loading="dataListLoading" :header-cell-style="{ background: '#f5f7fa', color: '#606266' }">
        <el-table-column label="Warehouse" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.warehouseCode || "-" }}</template>
        </el-table-column>
        <el-table-column label="Owner" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.clientCode || "-" }}</template>
        </el-table-column>
        <el-table-column label="Order no" min-width="180" align="center" show-overflow-tooltip>
          <template slot-scope="scope">
            <div class="underLine" @click="handleDetail(scope.$index, scope.row)"
              v-if="permissions.returnorder_retrunorderline_get">
              <i :class="scope.row.status === 'FINISH' ? 'el-icon-check underIcon' : ''"></i>
              <!-- el-icon-close underIconA -->
              {{ scope.row.orderNum || "-" }}
            </div>
            <div v-else>
              {{ scope.row.orderNum || "-" }}
            </div>
          </template>
        </el-table-column>
        <el-table-column label="Type" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.orderType || "-" }}</template>
        </el-table-column>
        <el-table-column label="Source Type" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.sourceType || "-" }}</template>
        </el-table-column>
        <el-table-column label="Return Order Type" min-width="140" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.returnOrderType || "-" }}</template>
        </el-table-column>
        <el-table-column label="Source Order Num" min-width="140" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.sourceOrderNum || "-" }}</template>
        </el-table-column>
        <el-table-column label="Remark" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.remark || "-" }}</template>
        </el-table-column>
        <el-table-column label="Created" min-width="140" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.productTime || "-" }}</template>
        </el-table-column>
        <el-table-column label="Responded" min-width="140" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.finishedTime || "-" }}</template>
        </el-table-column>
        <el-table-column label="Closed" min-width="140" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.cancelTime || "-" }}</template>
        </el-table-column>
        <el-table-column label="Status" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.status || "-" }}</template>
        </el-table-column>
      </el-table>
      <Pagination @handleSizeChange="handleSizeChange" @handleCurrentChange="handleCurrentChange" :pageNum="page.current"
        :pageSize="page.size" :total="total"></Pagination>
      <!--excel 模板导入 -->
      <excel-upload ref="excelUpload" title="upload" url="/returnorder/returnorder/import"
        temp-name="returnOrderImport.xlsx" temp-url="/admin/sys-file/local/returnOrderImport.xlsx"
        @refreshDataList="handleRefreshChange"></excel-upload>
    </el-card>
  </div>
</template>
<script>
import Pagination from "@/components/pagination/pagination.vue";
import ExcelUpload from "@/components/upload/excel";
import { mapGetters } from "vuex";
import { pageQuery, returnOrderGetData } from "@/api/sap/sapReturnOrder";
import { remote } from "@/api/admin/dict";

let formParams = {
  orderNum: undefined,
  remark: undefined,
  warehouseCode: undefined,
  status: undefined,
};
export default {
  name: "SapReturnOrder",
  data() {
    return {
      form: Object.assign({}, formParams),
      total: 0,
      page: {
        size: 10,
        current: 1,
      },
      dataListLoading: false,
      tableData: [],
      warehouseCode: [],
      status: [],
      time: {
        createTime: undefined,
        finishedTime: undefined,
        closeTime: undefined,
      },
      show: false,
      sapReturnOrderLoading: false
    };
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  components: {
    Pagination,
    ExcelUpload,
  },
  async created() {
    await this.getWarehouseByClient();
    await this.getList();
  },
  mounted() {
    this.exportExcel = this.$btn(this.exportExcel, 500)
  },
  methods: {
    //时间参数
    changeCreateTime(val) {
      if (val !== undefined && val !== null && val !== "" && val.length > 0) {
        this.$set(this.form, "productStartTime", val[0]);
        this.$set(this.form, "productEndTime", val[1]);
      } else {
        this.$set(this.form, "productStartTime", undefined);
        this.$set(this.form, "productEndTime", undefined);
      }
    },
    changeFinishTime(val) {
      if (val !== undefined && val !== null && val !== "" && val.length > 0) {
        this.$set(this.form, "finishedStartTime", val[0]);
        this.$set(this.form, "finishedEndTime", val[1]);
      } else {
        this.$set(this.form, "finishedStartTime", undefined);
        this.$set(this.form, "finishedEndTime", undefined);
      }
    },
    changeCloseTime(val) {
      if (val !== undefined && val !== null && val !== "" && val.length > 0) {
        this.$set(this.form, "cancelStartTime", val[0]);
        this.$set(this.form, "cancelEndTime", val[1]);
      } else {
        this.$set(this.form, "cancelStartTime", undefined);
        this.$set(this.form, "cancelEndTime", undefined);
      }
    },
    //导入
    handleRefreshChange(e) {
      if (e === "loading") {
        this.sapReturnOrderLoading = true;
        return;
      }
      this.sapReturnOrderLoading = false;
      this.getList()
    },
    //导出
    exportExcel() {
      this.sapReturnOrderLoading = true
      this.downBlobFile("/returnorder/returnorder/export", this.form, `${this.$store.state.common.commandName}-SapReturnOrder-${this.toDateFormat(new Date(), true)}.xlsx`, () => this.sapReturnOrderLoading = false);
    },
    //展开
    about() {
      this.show = !this.show;
    },
    //条数
    handleSizeChange(val) {
      this.page.current = 1;
      this.page.size = val;
      this.getList(this.form);
    },
    //当前页数
    handleCurrentChange(val) {
      this.page.current = val;
      this.getList(this.form);
    },
    //清空
    getReset() {
      this.form = Object.assign({}, formParams);
      this.time = this.$options.data().time
      this.page = this.$options.data().page
      this.getList();
    },
    //查询
    getSearchlist() {
      this.page.current = 1;
      for (let key in this.form) {
        if (this.form[key] === "" || this.form[key] === null) {
          this.form[key] = undefined;
        }
      }
      this.getList(this.form);
    },
    //数据列表
    getList(params) {
      this.dataListLoading = true;
      pageQuery(Object.assign({ ...this.page }, params)).then((res) => {
        console.log(res);
        if (res.data.code === 0) {
          this.tableData = res.data.data.records;
          this.total = res.data.data.total;
          this.dataListLoading = false;
        } else {
          this.$message.error(res.data.msg);
          this.dataListLoading = false;
        }
      }).catch(() => {
        this.$message.error("request was aborted");
        this.dataListLoading = false;
      });
    },
    //跳转
    handleDetail(index, row) {
      this.$router.push({
        path: "/sapReturnOrderDetail",
        query: {
          name: row.orderNum,
        },
      });
    },
    //warehouseCode下拉数据
    getWarehouseByClient() {
      returnOrderGetData().then((res) => {
        if (res.data.code === 0) {
          this.status = res.data.data.statusList;
          this.warehouseCode = res.data.data.warehouseCodeList;
        }
      });
    },
  },
};
</script>
<style lang="scss" scoped>
.content {
  padding: 0 10px;

  // box-sizing: border-box;
  .text {
    font-size: 14px;
  }

  .item {
    padding: 18px 0;
  }

  .box-card {
    width: 100%;
  }

  .down {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    border-top: 1px solid #999;
    padding-top: 20px;
    box-sizing: border-box;
  }

  .underLine {
    cursor: pointer;
    color: #599af8;
    text-decoration: underline;

    .underIcon {
      background-color: rgb(137, 234, 137);
      color: #fff;
      border-radius: 50%;
      margin-right: 5px;
    }

    .underIconA {
      background-color: rgb(238, 99, 99);
      color: #fff;
      border-radius: 50%;
      margin-right: 5px;
    }
  }

  ::v-deep .el-select--small {
    display: block;
  }

  ::v-deep .el-select--small {
    display: block;
  }

  ::v-deep .el-date-editor--daterange.el-input,
  ::v-deep .el-date-editor--daterange.el-input__inner,
  ::v-deep .el-date-editor--timerange.el-input,
  ::v-deep .el-date-editor--timerange.el-input__inner {
    width: 100% !important;
  }
}
</style>
