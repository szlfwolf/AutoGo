<template>
  <basic-container>
    <div class="avue-crud content" v-loading="sapOrderLoading">
      <div>
        <div class="title">
          <span></span>
          <label>Return Order</label>
        </div>
        <div class="contain">
          <el-row>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Owner:</label>
              <span>{{ returnOrderDetail.clientCode }}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Order no:</label>
              <span>{{ returnOrderDetail.orderNum }}
                <i class="el-icon-document-copy copy" @click="clickCopy('asn_no')"></i>
              </span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Warehouse:</label>
              <span>{{ returnOrderDetail.warehouseCode }}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Order Type:</label>
              <span>{{ returnOrderDetail.orderType }}</span>
            </el-col>
          </el-row>
          <el-row>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Bill of Landing:</label>
              <span>{{ returnOrderDetail.billOfLanding }}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Invoice:</label>
              <span>{{ returnOrderDetail.invoice }}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Supplier:</label>
              <span style="color: rgb(238, 99, 99)">{{ returnOrderDetail.supplier }}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Source:</label>
              <span>{{ returnOrderDetail.source }}</span>
            </el-col>
          </el-row>
          <el-row>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Status:</label>
              <span>{{ returnOrderDetail.status }}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Return Order Type:</label>
              <span>{{ returnOrderDetail.returnOrderType }}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="12">
              <label>Source Order Num:</label>
              <span>{{ returnOrderDetail.sourceOrderNum }}</span>
            </el-col>
          </el-row>
          <el-row>
            <el-col :xs="24" :sm="24" :md="24" :lg="24">
              <label>Remark:</label>
              <span>{{ returnOrderDetail.remark }}</span>
            </el-col>
          </el-row>
        </div>
        <div>
          <div class="title">
            <span></span>
            <label>Track</label>
          </div>
          <div class="contain">
            <el-row>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>Create Time:</label>
                <span>{{ track.createTime }}</span>
              </el-col>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>Cancel Time:</label>
                <span>{{ track.cancelTime }}</span>
              </el-col>
              <el-col :xs="24" :sm="12" :md="12" :lg="6">
                <label>Finish Time:</label>
                <span>{{ track.finishTime }}</span>
              </el-col>
            </el-row>
          </div>
        </div>
      </div>
      <div class="containBox">
        <div class="title">
          <span></span>
          <label>Return Order Lines</label>
        </div>
        <div class="contain">
          <el-row style="width: 200px; display: flex">
            <el-col>
              <el-button type="primary" icon="el-icon-search" @click="getSearchlist">Query</el-button>
            </el-col>
            <el-col>
              <el-button icon="el-icon-refresh-left" @click="getReset">Reset</el-button>
            </el-col>
          </el-row>
          <el-row>
            <el-form ref="form" :model="form" style="margin: 20px 0" @keyup.enter.native="getSearchlist">
              <el-row :gutter="20">
                <el-col :span="4">
                  <el-input v-model="form.partNumber" placeholder="Sku no"></el-input>
                </el-col>
              </el-row>
            </el-form>
          </el-row>
        </div>
      </div>
      <div class="down">
        <div>
          <el-button type="primary" :disabled="returnOrderDetail.status !== 'CREATE'"
            v-if="permissions.return_returnorder_confirm" @click="operateType('confirm')">
            Confirm
          </el-button>
          <el-button type="primary" :disabled="returnOrderDetail.status !== 'CREATE'"
            v-if="permissions.return_returnorder_cancel" @click="operateType('cancel')">
            Cancel
          </el-button>
        </div>
        <el-button icon="el-icon-download" v-if="permissions.returnorder_returnorderline_export"
          @click="exportExcel"></el-button>
      </div>
      <el-table border ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%"
        v-loading="dataListLoading" :header-cell-style="{ background: '#f5f7fa', color: '#606266' }">
        <el-table-column label="Line no" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.lineNo || "-" }}</template>
        </el-table-column>
        <el-table-column label="Sku no" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.partNumber || "-" }}</template>
        </el-table-column>
        <el-table-column label="Qty" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.num || "0" }}</template>
        </el-table-column>
        <el-table-column label="Unit" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.unit || "-" }}</template>
        </el-table-column>
      </el-table>
      <Pagination @handleSizeChange="handleSizeChange" @handleCurrentChange="handleCurrentChange" :pageNum="page.current"
        :pageSize="page.size" :total="total"></Pagination>
    </div>
  </basic-container>
</template>
<script>
import { mapGetters } from "vuex";
import Pagination from "@/components/pagination/pagination.vue";
import { pageDetailQuery, returnOrderConfirm, returnOrderCancel } from "@/api/sap/sapReturnOrder";
import { setStore } from "@/util/store";
import store from "@/store";
export default {
  name: "returnOrderDetail",
  data() {
    return {
      form: {
        partNumber: undefined,
      },
      page: {
        size: 10,
        current: 1,
      },
      total: 0,
      dataListLoading: false,
      paramsDetail: {},
      returnOrderDetail: {},
      track: {},
      differenceList: [
        {
          value: 1,
          label: "Y",
        },
        {
          value: 0,
          label: "N",
        },
      ],
      tableData: [],
      centerDialogVisible: false,
      formDialog: {
        lineNo: "",
        partNumber: "",
        num: "",
        actualQty: 0,
      },
      orderNum: "",
      sapOrderLoading: false,
    };
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  components: {
    Pagination,
  },
  watch: {
    // 利用watch方法检测路由变化：
    $route: function (to, from) {
      console.log(to);
      if (to.path == "/sapReturnOrderDetail/index" && to.query.name) {
        if (to.query.name != from.query.name) {
          this.orderNum = to.query.name;
          this.getList();
        }
      }
    },
  },
  created() {
    this.orderNum = this.$route.query.name;
    this.getList();
  },
  mounted() {
    this.exportExcel = this.$btn(this.exportExcel, 500);
    this.clickCopy = this.$btn(this.clickCopy, 500);
  },
  methods: {
    //复制
    async clickCopy() {
      let content = this.returnOrderDetail.orderNum;
      if (this.copy(content) === "文本为空") {
        this.$message.warning("Text is empty and cannot be copied !!!");
        return;
      }
      this.$message.success("copy success");
    },
    //导出
    exportExcel() {
      this.downBlobFile("/returnorder/returnorderline/export", { ...this.form, orderNum: this.orderNum }, `${this.$store.state.common.commandName}-ReturnOrderLine-${this.toDateFormat(new Date(), true)}.xlsx`);
    },
    //清空
    getReset() {
      this.form = this.$options.data().form;
      this.page = this.$options.data().page;
      this.getList();
    },
    //查询
    getSearchlist() {
      this.page.current = 1;
      for (let key in this.form) {
        if (this.form[key] === "" || this.form[key] === null) {
          this.form[key] = undefined;
        }
      }
      this.getList();
    },
    //数据列表
    getList() {
      // this.dataListLoading = true;
      this.sapOrderLoading = true;
      pageDetailQuery(Object.assign({ ...this.page }, { ...this.form }, { orderNum: this.orderNum })).then((res) => {
        console.log(res);
        if (res.data.code == 0) {
          this.paramsDetail = res.data.data
          this.tableData = res.data.data.returnOrderLineVoList;
          this.returnOrderDetail = res.data.data.returnOrderDetail
          this.track = res.data.data.track
          this.total = res.data.data.total;
          this.sapOrderLoading = false;
        } else {
          this.$message.error(res.data.msg);
          this.sapOrderLoading = false;
        }
      }).catch(() => {
        this.sapOrderLoading = false;
      });
    },
    //条数
    handleSizeChange(val) {
      this.page.current = 1;
      this.page.size = val;
      this.getList();
    },
    //当前页数
    handleCurrentChange(val) {
      this.page.current = val;
      this.getList();
    },
    operateType(type) {
      if (type === "confirm") {
        this.$confirm('Confirm whether to return this order?', 'Tips', {
          confirmButtonText: 'submit',
          cancelButtonText: 'cancel',
          type: 'warning'
        }).then(() => {
          returnOrderConfirm(this.paramsDetail).then(res => {
            console.log(res);
            if (res.data.code === 0) {
              this.$message.success(res.data.data);
              this.getList();
            } else {
              this.$message.error(res.data.msg);
            }
          })
        }).catch(() => {
          this.$message({
            type: 'info',
            message: 'Destruction'
          });
        });
      } else {
        this.$confirm('Are you sure to cancel the return order?', 'Tips', {
          confirmButtonText: 'submit',
          cancelButtonText: 'cancel',
          type: 'warning'
        }).then(() => {
          returnOrderCancel(this.paramsDetail).then(res => {
            if (res.data.code === 0) {
              this.$message.success(res.data.data);
              this.getList();
            } else {
              this.$message.error(res.data.msg);
            }
          })
        }).catch(() => {
          this.$message({
            type: 'info',
            message: 'Destruction'
          });
        });
      }
    },
  },
};
</script>
<style lang="scss" scoped>
.content {
  width: 100%;
  //   padding: 20px;
  font-size: 14px;
  box-sizing: border-box;

  .title {
    width: 100%;
    height: 30px;
    line-height: 30px;
    display: flex;
    margin-bottom: 10px;

    span {
      width: 3px;
      height: 30px;
      background-color: #000;
      margin-right: 10px;
    }

    label {
      font-weight: 700;
    }
  }

  .containBox {
    border-bottom: 1px solid #999;
    margin-bottom: 20px;
  }

  .contain {
    padding: 10px;
    box-sizing: border-box;
    width: 100%;

    label {
      margin-right: 5px;
      display: inline-block;
      width: 120px;
      text-align: right;
      vertical-align: middle;
    }

    span {
      color: #999;
      vertical-align: middle;
    }
  }

  .down {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
  }

  .copy {
    cursor: pointer;
  }

  ::v-deep .el-dialog {
    border-radius: 8px !important;
  }
}
</style>
