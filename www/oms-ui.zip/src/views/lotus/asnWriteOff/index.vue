<template>
  <div class="content" v-loading="asnLoading">
    <el-card class="box-card">
      <el-row style="width:200px;display:flex">
        <el-col>
          <el-button type="primary" icon="el-icon-search" @click="getSearchlist">Query</el-button>
        </el-col>
        <el-col>
          <el-button icon="el-icon-refresh-left" @click="getReset">Reset</el-button>
        </el-col>
      </el-row>
      <el-form ref="form" :model="form" style="margin: 20px 0" @keyup.enter.native="getSearchlist">
        <el-row :gutter="20">
          <el-col :span="4">
            <el-input v-model="form.voucherNo" placeholder="Asn no"></el-input>
          </el-col>
          <el-col :span="4">
            <el-select v-model="form.warehouseCode" placeholder="Warehouse" filterable clearable>
              <el-option
                v-for="item in warehouseCode"
                :key="item.value"
                :label="item.warehouseName"
                :value="item.warehouseCode"
              >
              </el-option>
            </el-select>
          </el-col>
        </el-row>
      </el-form>
      <div class="down">
        <div></div>
        <div>
          <el-button
            icon="el-icon-upload2"
            @click="$refs.excelUpload.show()"
            v-if="permissions.upload_voucher_send"
          ></el-button>
        </div>
      </div>
      <el-table
        border
        ref="multipleTable"
        :data="tableData"
        tooltip-effect="dark"
        style="width: 100%"
        v-loading="dataListLoading"
        :header-cell-style="{ background: '#f5f7fa', color: '#606266' }"
      >
        <el-table-column label="Owner" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.clientCode || '-' }}</template>
        </el-table-column>
        <el-table-column label="Warehouse" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.warehouseCode || '-' }}</template>
        </el-table-column>
        <el-table-column label="Asn no" min-width="120" align="center" v-if="permissions.asn_writeOff_get" show-overflow-tooltip>
          <template slot-scope="scope">
            <div @click="getDetail(scope.row,scope.$index)" class="underLine">
              {{ scope.row.voucherNo || '-' }}
            </div>
          </template>
        </el-table-column>
        <el-table-column label="Sap Stock Order no" min-width="140" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.sapStockOrderNo || '-' }}</template>
        </el-table-column>
        <el-table-column label="Create Time" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.createTime || '-' }}</template>
        </el-table-column>
        <el-table-column label="status" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.statusName || '-'  }}</template>
        </el-table-column>
      </el-table>
      <Pagination 
        @handleSizeChange="handleSizeChange"
        @handleCurrentChange="handleCurrentChange"
        :pageNum="page.current" 
        :pageSize="page.size" 
        :total="total"
      ></Pagination>
      <!--excel 模板导入 -->
      <excel-upload
        ref="excelUpload"
        title="ASN Write Off Upload"
        url="/adapter-lotus/skuVoucher/asnWriteOff/uploadAsnWriteOffByExcel"
        temp-name="asn-write-off.xlsx"
        temp-url="/admin/sys-file/local/asn-write-off.xlsx"
        type="confirm"
        @refreshDataList="handleRefreshChange"
      ></excel-upload>
    </el-card>
  </div>
</template>
<script>
import { mapGetters } from "vuex"
import Pagination from "@/components/pagination/pagination.vue"
import ExcelUpload from "@/components/upload/excel"
import { pageQuery, getWriteOffInfo } from "@/api/inbound/asnWriteOff"
import { getWarehouse } from "@/api/stock/analysis";
let formParams = {
  voucherNo: undefined,
  warehouseCode:undefined
}
export default {
  name: "WeeklyVolumeRate",
  data() {
    return {
      form: Object.assign({}, formParams),
      total: 0,
      page:{
        size: 10,
        current: 1,  
      },
      dataListLoading: false,
      tableData: [],
      warehouseCode:[],
      asnLoading:false
    }
  },
  computed: {
    ...mapGetters(["permissions"]),
  },
  components: {
    Pagination,
    ExcelUpload
  },
  created() {
    this.getList()
    this.getSelect()
  },
  methods: {
    //导入
    handleRefreshChange(e){
      if(e === 'loading'){
        this.asnLoading = true
        return
      }
      this.asnLoading = false
      this.getList(this.form)
    },
    //条数
    handleSizeChange(val) {
      this.page.current = 1
      this.page.size = val
      this.getList(this.form)
    },
    //当前页数
    handleCurrentChange(val) {
      this.page.current = val
      this.getList(this.form)
    },
    //清空
    getReset() {
      this.form = Object.assign({}, formParams)
      this.page = this.$options.data().page
      this.getList()
    },
    //查询
    getSearchlist() {
      this.page.current = 1
      for (let key in this.form) {
        if (this.form[key] === "" || this.form[key] === null) {
          this.form[key] = undefined;
        }
      }
      this.getList(this.form)
    },
    //数据列表
    getList(params){
      this.dataListLoading = true
      pageQuery(Object.assign({...this.page},params)).then(res=>{
        console.log(res)
        if(res.data.code === 0){
          this.tableData = res.data.data.records
          this.total = res.data.data.total
          this.dataListLoading = false
        }else{
          this.$message.error(res.data.msg)
          this.dataListLoading = false
        }
      }).catch(()=>{
        this.$message.error('request was aborted')
        this.dataListLoading = false
      })
    },
    //下拉数据
    getSelect(){
      //warehouse
      getWarehouse().then((res) => {
        if (res.data.code === 0) {
          this.warehouseCode = res.data.data;
        }
      });
    },
    //跳转详情
    getDetail(row,index){
      getWriteOffInfo(row.id).then(res=>{
        if(res.data.code === 0){
          let detail = res.data.data
          this.$router.push({
            path:"/asnWriteOffDetail",
            query:{
              name:row.voucherNo,
              row: JSON.stringify(detail)
            }
          })
        }
      })
    },
  },
} 
</script>
<style lang="scss" scoped>
.content {
  padding: 0 10px;
  .text {
    font-size: 14px;
  }
  .item {
    padding: 18px 0;
  }
  .box-card {
    width: 100%;
  }
  .down {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    border-top: 1px solid #999;
    padding-top: 20px;
    box-sizing: border-box;
  }
  .underLine {
    cursor: pointer;
    color: #599af8;
    text-decoration: underline;
  }
  ::v-deep .el-dialog {
    border-radius: 8px !important;
  }
  ::v-deep .el-select--small {
    display: block;
  }
}
</style>
