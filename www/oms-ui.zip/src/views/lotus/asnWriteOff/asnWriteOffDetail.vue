<template>
  <basic-container>
    <div class="avue-crud content">
      <div>
        <div class="title">
          <span></span>
          <label>SkuVocher Info</label>
        </div>
        <div class="contain">
          <el-row>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>WarehouseCode:</label>
              <span>{{ rowParams.warehouseCode }}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Client:</label>
              <span>{{rowParams.clientCode}}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>SapStockOrderNo:</label>
              <span>{{rowParams.sapStockOrderNo}}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Send Time:</label>
              <span>{{ rowParams.sendWriteOffTime }}</span>
            </el-col>
          </el-row>
          <el-row>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>Status:</label>
              <span>{{ rowParams.statusName }}</span>
            </el-col>
            <el-col :xs="24" :sm="12" :md="12" :lg="6">
              <label>ASN No:</label>
              <span>{{ rowParams.voucherNo }}</span>
            </el-col>
          </el-row>
        </div>
      </div>
      <div class="containBox">
        <div class="title">
          <span></span>
          <label>SkuVoucher Line</label>
        </div>
        <div class="contain">
          <el-row style="width:200px;display:flex">
            <el-col>
              <el-button type="primary" icon="el-icon-search" @click="getSearchlist">Query</el-button>
            </el-col>
            <el-col>
              <el-button icon="el-icon-refresh-left" @click="getReset">Reset</el-button>
            </el-col>
          </el-row>
          <el-row>
            <el-form ref="form" :model="form" style="margin: 20px 0" @keyup.enter.native="getSearchlist">
              <el-row :gutter="20">
                <el-col :span="4">
                  <el-input v-model="form.partNumber" placeholder="PartNumber"></el-input> 
                </el-col>
              </el-row>
            </el-form>
          </el-row>
        </div>
      </div>
      <!-- <div class="down">
        <div></div>
        <el-button icon="el-icon-download" v-if="permissions.inbound_asnline_export" @click="exportExcel"></el-button>
      </div> -->
      <el-table
        border
        ref="multipleTable"
        :data="tableData"
        tooltip-effect="dark"
        style="width: 100%"
        v-loading="dataListLoading"
        :header-cell-style="{background:'#f5f7fa',color:'#606266'}"
      >
        <el-table-column label="Line no" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.lineNo || '-'}}</template>
        </el-table-column>
        <el-table-column label="PartNumber" min-width="120" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.partNumber || '-' }}</template>
        </el-table-column>
        <el-table-column label="Actual Qty" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.actualQty }}</template>
        </el-table-column>
        <el-table-column label="Write Off Qty" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.writeOffQty || '-'  }}</template>
        </el-table-column>
        <el-table-column label="Unit" min-width="120" align="center">
          <template slot-scope="scope">{{ scope.row.unit || '-' }}</template>
        </el-table-column>
      </el-table>
      <Pagination 
        @handleSizeChange="handleSizeChange"
        @handleCurrentChange="handleCurrentChange"
        :pageNum="page.current" 
        :pageSize="page.size" 
        :total="total"
      ></Pagination>
    </div>
  </basic-container>
</template>
<script>
import { mapGetters } from "vuex"
import Pagination from "@/components/pagination/pagination.vue"
import { getAsnLines, getEditAsnline, getByASn, getCutoffMappedPreview, getCutoffMappedSubmit, getAsnDetails } from "@/api/inbound/asn"
import { pageQueryLine } from "@/api/inbound/asnWriteOff";
import { setStore } from "@/util/store"
export default {
  name: "asnDetail",
  data() {
    return {
      form: {
        partNumber: undefined,
      },
      page:{
        size:10,
        current:1,
      },
      total:0,
      dataListLoading:false,
      rowParams: {},
      tableData: [],
      titleLoading:false
    } 
  },
  computed: {
    ...mapGetters(["permissions"])
  },
  components:{
    Pagination
  },
  watch: {
    // 利用watch方法检测路由变化：
    $route: function(to, from) {
      if(to.path=='/asnWriteOffDetail/index' && to.query.row){
        if(to.query.name != from.query.name){
          this.rowParams = JSON.parse(this.$route.query.row)
          this.getList()
        }
      }
    }
  },
  created() {
    this.rowParams = JSON.parse(this.$route.query.row)
    this.getList()
  },
  methods: {
    // //导出
    // exportExcel() {
    //   this.downBlobFile("/inbound/asnline/exportAsnLine", {...this.form,asnNo:this.rowParams.asnNo}, "asnline.xlsx")
    // },
    //清空
    getReset(){
      this.form = this.$options.data().form
      this.page = this.$options.data().page
      this.getList()
    },
    //查询
    getSearchlist(){
      this.page.current = 1
      for (let key in this.form) {
        if(this.form[key] === '' || this.form[key] === null){
          this.form[key] = undefined
        }
      }
      this.getList()
    },
    //数据列表
    getList(){
      this.dataListLoading = true
      pageQueryLine(Object.assign({...this.page},{...this.form},{voucherWriteOffId:this.rowParams.id})).then(res=>{
        console.log(res)
        if(res.data.code == 0){
          this.tableData = res.data.data.records
          this.total = res.data.data.total
          this.dataListLoading = false
        }else{
          this.$message.error(res.data.msg)
          this.dataListLoading = false
        }
      }).catch(()=>{
        this.dataListLoading = false
      })
    },
    //条数
    handleSizeChange(val) {
      this.page.current = 1
      this.page.size = val
      this.getList()
    },
    //当前页数
    handleCurrentChange(val) {
      this.page.current = val
      this.getList()
    },
  },
}
</script>
<style lang="scss" scoped>
.content {
  width: 100%;
  //   padding: 20px;
  font-size: 13px;
  box-sizing: border-box;
  .title {
    width: 100%;
    height: 30px;
    line-height: 30px;
    display: flex;
    margin-bottom: 10px;
    span {
      width: 3px;
      height: 30px;
      background-color: #000;
      margin-right: 10px;
    }
    label {
      font-weight: 700;
    }
  }
  .containBox {
    border-bottom: 1px solid #999;
    margin-bottom: 20px;
  }
  .contain {
    padding: 10px;
    box-sizing: border-box;
    label {
      margin-right: 5px;
      display: inline-block;
      width:110px;
      text-align:right;
      vertical-align: middle;
    }
    span{
      color: #999;
      vertical-align: middle;
    }
  }
  .down {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
  }
}
</style>
