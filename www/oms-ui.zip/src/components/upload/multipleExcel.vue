<template>
  <div>
    <el-upload
      ref="upload"
      :limit="limit"
      :multiple="multiple"
      :headers="headers"
      :action="url"
      :disabled="upload.isUploading"
      :on-progress="handleFileUploadProgress"
      :on-success="handleFileSuccess"
      :on-error="handleFileError"
      :on-remove="handleRemove"
      :auto-upload="true"
      :before-upload="handleBeforeUpload"
      drag
      style="display: flex; flex-direction: column; align-items: center"
      :timeout="300 * 1000"
    >
    <!-- v-loading="uploadLoading" -->
      <!-- :file-list="fileList" -->
      <i class="el-icon-upload"></i>
      <div class="el-upload__text">
        将文件拖到此处，或
        <em>点击上传</em>
      </div>
      <div class="el-upload__tip text-center" slot="tip">
        <span v-if="accept === '.pdf'">仅允许导入pdf格式文件,且不超过50MB</span>
        <span v-else>仅允许导入xls/xlsx格式文件,且不超过5MB,可上传多个</span>
        <el-link type="primary" :underline="false" style="font-size:12px;vertical-align: baseline;margin-left:10px"
          @click="downExcelTemp" v-if="tempUrl && isCurrency === 'Y'">下载模板
        </el-link>
      </div>
      <!-- <div class="el-upload__tip text-center" slot="tip">
        <span v-if="accept === '.pdf'">仅允许导入pdf格式文件,且不超过50MB</span>
        <span v-else>仅允许导入xls/xlsx格式文件,且不超过5MB,可上传多个</span>
      </div> -->
    </el-upload>
  </div>
</template>

<script>
import store from "@/store";
import { setStore, getStore } from "@/util/store";
import { mapState } from "vuex";
import { deleteUuid } from "@/api/inbound/bl";
export default {
  name: "multipleExcelUpload",
  components: {},
  props: {
    url: {
      type: String,
    },
    limit: {
      type: Number,
    },
    multiple: {
      type: Boolean,
    },
    accept: {
      type: String,
    },
    type: {
      type: String,
    },
    tempUrl: {
      type: String
    },
    tempName: {
      type: String
    },
    isCurrency:{
      type:String
    }
  },
  data() {
    return {
      upload: {
        isUploading: false,
      },
      fileList: [],
      ci:[],
      pl:[],
      // uploadLoading:false
    };
  },
  computed: {
    ...mapState({
      uuid: (state) => state.common.uuid,
    }),
    headers: function () {
      return {
        Authorization: "Bearer " + store.getters.access_token,
        clientCode: store.getters.commandName,
        // uuid: getStore({name:'uuid'}) || store.getters.uuid,
        uuid: store.getters.uuid,
      };
    },
  },
  created() {
    console.log(this.type);
    // this.$refs.upload.uploader.options.timeout = 300 * 1000 
  },
  methods: {
    downExcelTemp() {
      this.downBlobFile(this.tempUrl, {}, this.tempName);
    },
    handleBeforeUpload(file) {
      console.log(this.fileList, "handleBeforeUpload");
      this.ci.forEach((item) => {
        this.pl.forEach((ite) => {
          if (item.name === ite.name) {
            this.$message.error("CI与PL存在相同文件");
          }
        });
      });
      // if (this.accept !== ".pdf") {
        const value = this.fileList.filter((ite) => {
          if (ite.name === file.name) {
            setTimeout(() => {
              this.$message.error(`上传存在重复文件${file.name}`);
            });
            return ite;
          }
        });
        console.log(value, "value");
        if (value.length) {
          return false;
        }
      // }
      if (this.accept === ".pdf") {
        if (50 < file.size / 1024 / 1024) {
          this.$message.error("上传的pdf文件不能大于50MB");
          return false;
        }
        const index = file.name.lastIndexOf(".");
        let reg = file.name.substring(index);
        if (reg !== ".pdf" && reg !== ".PDF") {
          this.$message.error("上传文件格式不正确");
          return false;
        }
      } else {
        if (10 < file.size / 1024 / 1024) {
          this.$message.error("上传的xls/xlsx文件不能大于5MB");
          return false;
        }
        const index = file.name.lastIndexOf(".");
        let reg = file.name.substring(index);
        if (
          reg !== ".xls" &&
          reg !== ".xlsx" &&
          reg !== ".XLS" &&
          reg !== ".XLSX"
        ) {
          this.$message.error("上传文件格式不正确");
          return false;
        }
      }
    },
    handleRemove(file, fileList) {
      // fileList = fileList.splice(file,1)
      if(file && file.status === 'success'){
        if (this.accept !== ".pdf") {
          fileList = fileList.filter((ite, idx) => {
            if (ite.name !== file.name) {
              return ite;
            }
          });
          console.log(8888);
          this.$emit("refreshDataList", fileList);
          this.fileList = fileList;
          deleteUuid(file.response.data[0].uuid).then((res) => {
            if (res.data.code === 0) {
              this.$message.success("Deletion succeeded");
            } else {
              this.$message.error(res.data.msg);
            }
          });
        }else{
          fileList = fileList.filter((ite, idx) => {
            if (ite.name !== file.name) {
              return ite;
            }
          });
          console.log(8888);
          this.$emit("refreshDataList", fileList);
          this.fileList = fileList;
          deleteUuid(file.response.data.uuid).then((res) => {
            if (res.data.code === 0) {
              this.$message.success("Deletion succeeded");
            } else {
              this.$message.error(res.data.msg);
            }
          });
        }
      }
    },
    handleFileUploadProgress() {
      this.upload.isUploading = true;
      // this.uploadLoading = true
      // this.$emit('uploadLoading',true)
    },
    handleFileError(err,files,fileList) {
      // this.$refs.upload.clearFiles();
      this.$message.error("上传失败,请重新上传!");
      // this.$emit('uploadLoading',false)
    },
    handleFileSuccess(response, files, fileList) {
      // this.$emit('uploadLoading',false)
      this.fileList = Array.from(new Set(this.fileList.concat(fileList)));
      this.upload.isUploading = false;
      if (response.data !== null && Array.isArray(response.data))
        response.msg = response.data.join("<br/>");
      // 校验失败
      if (response.code === 1) {
        this.$message({
          dangerouslyUseHTMLString: true, //重点代码
          message: response.msg,
          type: "error",
        });
      } else if (response.code === 0) {
        // console.log(this.headers,'44444');
        this.$message.success("导入成功");
        if (this.type === "CI") {
          this.ci = this.fileList;
        } else if (this.type === "PL") {
          this.pl = this.fileList;
        }else{
          this.bl = this.fileList;
        }
        // 刷新表格
        if (this.accept !== ".pdf") {
          console.log(this.type);
          if (!this.uuid && this.fileList[0].response) {
            this.$store.commit( "SET_UUID", this.fileList[0].response.data[0].uuid);
          }
          console.log(getStore({ name: "uuid" }), "55555555555555");
        }else{
          if (!this.uuid && this.fileList[0].response) {
            this.$store.commit( "SET_UUID", this.fileList[0].response.data.uuid);
          }
        }
        this.$emit("refreshDataList", fileList);
      } else {
        this.$message.error(response.msg);
      }
    },
    submitFileForm() {
      this.fileList = this.$options.data().fileList;
      this.$refs.upload.clearFiles();
    },
  },
};
</script>
