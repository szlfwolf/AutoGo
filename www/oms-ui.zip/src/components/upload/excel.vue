<template>
  <div>
    <!-- 导入对话框 -->

    <el-dialog :title="title" :visible.sync="upload.open" width="400px" append-to-body>
      <el-form ref="form" :model="paramsData" v-if="timeDateStatus"
        style="display:flex;justify-content:center;margin-bottom:10px">
        <el-date-picker v-model="paramsData.stockSnapshootDate" type="date"
          placeholder="Select Difference Comparison Date" value-format="yyyy-MM-dd">
        </el-date-picker>
      </el-form>
      <el-upload ref="upload" :limit="1" accept=".xlsx, .xls" :headers="headers" :action="url"
        :disabled="upload.isUploading" :on-progress="handleFileUploadProgress" :on-success="handleFileSuccess"
        :on-change="handleChange" :on-error="handleFileError" :auto-upload="false" drag :data="paramsData"
        :timeout="300 * 1000">
        <i class="el-icon-upload"></i>
        <div class="el-upload__text">
          将文件拖到此处，或
          <em>点击上传</em>
        </div>
        <div class="el-upload__tip text-center" slot="tip">
          <span>仅允许导入xls、xlsx格式文件。</span>
          <el-link type="primary" :underline="false" style="font-size:12px;vertical-align: baseline;"
            @click="downExcelTemp" v-if="tempUrl">下载模板
          </el-link>
        </div>
      </el-upload>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitFileForm">确 定</el-button>
        <el-button @click="upload.open = false">取 消</el-button>
      </div>
    </el-dialog>

    <!--校验失败错误数据-->
    <el-dialog title="校验失败数据" :visible.sync="errorVisible">
      <el-table :data="errorData">
        <el-table-column property="x`" label="行号" width="50"></el-table-column>
        <el-table-column property="errors" label="错误描述" show-overflow-tooltip>
          <template slot-scope="scope">
            <el-tag type="danger" v-for="error in scope.row.errors" :key="error">{{ error }}
            </el-tag>
          </template>
        </el-table-column>
      </el-table>
    </el-dialog>
  </div>
</template>

<script>
import store from "@/store";

export default {
  name: "ExcelUpload",
  components: {},
  props: {
    url: {
      type: String
    },
    title: {
      type: String
    },
    tempUrl: {
      type: String
    },
    tempName: {
      type: String
    },
    type: {
      type: String
    },
    timeDateStatus: {
      type: Boolean
    }
  },
  data() {
    return {
      upload: {
        open: false,
        isUploading: false
      },
      errorVisible: false,
      errorData: [],
      fileList: [],
      paramsData: {
        stockSnapshootDate: ""
      }
    };
  },
  computed: {
    headers: function () {
      return {
        Authorization: "Bearer " + store.getters.access_token,
        clientCode: store.getters.commandName
      };
    }
  },
  created() {
  },
  methods: {
    downExcelTemp() {
      this.downBlobFile(this.tempUrl, {}, this.tempName);
    },
    handleFileUploadProgress() {
      this.upload.isUploading = true;

    },
    handleFileError(err) {
      console.log(err);
      this.$message.error('上传失败,请重新上传!')
      this.upload.open = true;
    },
    handleFileSuccess(response) {
      this.upload.isUploading = false;
      this.$refs.upload.clearFiles();
      // 处理上传错误返回的data信息以做提示
      if (response.data !== null && Array.isArray(response.data)) {
        let errorText = []
        response.data.forEach(i => {
          if (i.constructor == Object) {
            if (i.lineNum && i.errors) {
              errorText.push(`第${i.lineNum}行,${i.errors.join()}`)
              response.msg = errorText.join('<br/>')
            }
          } else if (i.constructor == String) {
            errorText = i.split(',')
            response.msg = errorText.join('<br/>')
          } else {
            response.msg = response.data.join('<br/>')
          }
        })
      }
      // 校验失败
      if (response.code === 1) {
        this.upload.open = false;
        this.$message({
          dangerouslyUseHTMLString: true,//重点代码
          message: response.msg,
          type: 'error',
        })
        // this.$message.error(response.msg);
        this.errorVisible = false;
        // this.errorVisible = true;
        this.errorData = response.data;
        this.$refs.upload.clearFiles();
        this.$emit("refreshDataList", response);
      } else if (response.code === 0) {
        this.upload.open = false;
        if (response.msg) {
          this.$message.success(response.msg);
        } else {
          this.$message.success("导入成功");
        }
        // 刷新表格
        this.$emit("refreshDataList", response);
      } else {
        this.upload.open = false;
        this.$message.error(response.msg);
        this.$refs.upload.clearFiles();
        this.$emit("refreshDataList", response);
      }
    },
    handleChange(file, fileList) {
      this.fileList = fileList
      //  console.log(this.fileList);
    },
    submitFileForm() {
      // console.log(this.fileList);
      if (!this.fileList.length) {
        return
      }
      if (this.type) {
        this.$confirm('Confirm to upload. Do you want to continue?', 'Tips', {
          confirmButtonText: 'submit',
          cancelButtonText: 'cancel',
          type: 'warning'
        }).then(() => {
          this.$emit("refreshDataList", 'loading');
          this.upload.open = false;
          this.$refs.upload.submit();
        }).catch(() => {
          this.$message({
            type: 'info',
            message: 'Destruction'
          });
        });
        return
      }
      if (!this.paramsData.stockSnapshootDate && this.timeDateStatus) {
        this.$message.warning('Please select a difference comparison date')
        return
      }
      // console.log(this.type);
      this.$emit("refreshDataList", 'loading');
      this.upload.open = false;
      this.$refs.upload.submit();
    },
    show() {
      this.upload.isUploading = false;
      this.upload.open = true;
      this.paramsData.stockSnapshootDate = ''
    },
  }
};
</script>
