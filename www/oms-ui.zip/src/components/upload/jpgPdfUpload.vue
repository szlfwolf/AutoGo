<template>
  <div>
    <!-- 导入对话框 -->
    <el-dialog :title="title" :visible.sync="upload.open" width="400px" append-to-body @close="getClose">
      <el-upload ref="upload" :limit="limit" :multiple="multiple" :accept="accept" :headers="headers" :action="url" :data="data"
        :disabled="upload.isUploading" :on-progress="handleFileUploadProgress" :on-success="handleFileSuccess"
        :on-error="handleFileError" :auto-upload="false" :before-upload="handleBeforeUpload" drag>
        <i class="el-icon-upload"></i>
        <div class="el-upload__text">
          将文件拖到此处，或
          <em>点击上传</em>
        </div>
        <div class="el-upload__tip text-center" slot="tip">
          <!-- <span v-if="accept === '.pdf'"
            >仅允许导入pdf格式文件,且不超过50MB</span
          >
          <span v-else>仅允许导入xls/xlsx格式文件,且不超过5MB,可上传多个</span> -->
          <span>可导入jpg, jpeg, png, pdf, docx, doc, xlsx, xls, ppt, pptx格式文件。</span>
          <!-- <el-link
            type="primary"
            :underline="false"
            style="font-size: 12px; vertical-align: baseline"
            @click="downExcelTemp"
            v-if="tempUrl"
            >下载模板
          </el-link> -->
        </div>
      </el-upload>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitFileForm">确 定</el-button>
        <el-button @click="upload.open = false">取 消</el-button>
      </div>
    </el-dialog>

    <!--校验失败错误数据-->
    <el-dialog title="校验失败数据" :visible.sync="errorVisible">
      <el-table :data="errorData">
        <el-table-column property="x`" label="行号" width="50"></el-table-column>
        <el-table-column property="errors" label="错误描述" show-overflow-tooltip>
          <template slot-scope="scope">
            <el-tag type="danger" v-for="error in scope.row.errors" :key="error">{{ error }}
            </el-tag>
          </template>
        </el-table-column>
      </el-table>
    </el-dialog>
  </div>
</template>

<script>
import store from "@/store";
import { setStore, getStore } from "@/util/store"
export default {
  name: "ExcelUpload",
  components: {},
  props: {
    url: {
      type: String,
    },
    data: {
      type: Object,
    },
    title: {
      type: String,
    },
    // tempUrl: {
    //   type: String,
    // },
    // tempName: {
    //   type: String,
    // },
    limit: {
      type: Number,
    },
    multiple: {
      type: Boolean,
    },
    accept: {
      //  .docx, .DOCX, .doc, .DOC, .xlsx, .XLSX, .xls, .XLS, .ppt, .PPT, .pptx, .PPTX
      type: String,
    },
  },
  data() {
    return {
      upload: {
        open: false,
        isUploading: false,
      },
      errorVisible: false,
      errorData: [],
      fileList: [],
    };
  },
  computed: {
    headers: function () {
      return {
        Authorization: "Bearer " + store.getters.access_token,
        clientCode: store.getters.commandName,
        uuid: getStore({ name: 'uuid' })
      };
    },
  },
  created() { },
  methods: {
    //上传前
    handleBeforeUpload(file) {
      // const value = this.fileList.filter((ite) => {
      //   if (ite.name === file.name) {
      //     setTimeout(() => {
      //       this.$message.error(`上传存在重复文件${file.name}`);
      //     });
      //     return ite;
      //   }
      // });
      // if (value.length) {
      //   return false;
      // }
      // if (this.accept === ".pdf") {
      //   if (50 < file.size / 1024 / 1024) {
      //     this.$message.error("上传的pdf文件不能大于50MB");
      //     return false;
      //   }
      // const index = file.name.lastIndexOf(".");
      // let reg = file.name.substring(index);
      // if (reg !== ".pdf" && reg !== ".PDF") {
      //   this.$message.error("上传文件格式不正确");
      //   return false;
      // }
      // } else {
      if (5 < file.size / 1024 / 1024) {
        this.$message.error("上传的文件不能大于5MB");
        return false;
      }
      const index = file.name.lastIndexOf(".");
      let reg = file.name.substring(index);
      //  .docx, .DOCX, .doc, .DOC, .xlsx, .XLSX, .xls, .XLS, .ppt, .PPT, .pptx, .PPTX
      if (reg !== ".docx" && reg !== ".DOCX" && reg !== ".doc" && reg !== ".DOC" && reg !== ".xlsx" && reg !== ".XLSX" && reg !== ".xls" && reg !== ".XLS" && reg !== ".ppt" && reg !== ".PPT" && reg !== ".pptx" && reg !== ".PPTX" && reg !== ".jpg" && reg !== ".jpeg" && reg !== ".png" && reg !== ".JPG" && reg !== ".JPEG" && reg !== ".PNG" && reg !== ".pdf" && reg !== ".PDF") {
        this.$message.error("上传文件格式不正确");
        console.log("🚀→→→→→ ~ reg", reg)
        return false;
      }
      // }
    },
    // downExcelTemp() {
    //   this.downBlobFile(this.tempUrl, {}, this.tempName);
    // },
    handleFileUploadProgress() {
      this.upload.isUploading = true;
    },
    handleFileError() {
      this.$message.error("上传失败,请重新上传!");
      this.upload.open = true;
    },
    handleFileSuccess(response, file, fileList) {
      this.fileList = Array.from(new Set(this.fileList.concat(fileList)));
      this.upload.isUploading = false;
      this.upload.open = true;
      setTimeout(() => {
        this.$refs.upload.clearFiles();
      }, 200);
      // if (response.data !== null && Array.isArray(response.data))
      //   response.msg = response.data.join("<br/>");
      // 校验失败
      if (response.code === 1) {
        this.$message({
          dangerouslyUseHTMLString: true, //重点代码
          message: response.msg,
          type: "error",
        });
        // this.$message.error(response.msg);
        this.errorVisible = false;
        // this.errorVisible = true;
        this.errorData = response.data;
      } else if (response.code === 0) {
        this.upload.open = false;
        this.$message.success(response.msg);
        // 刷新表格
        // if (this.accept !== '.pdf') {
        //   let list = []
        //   fileList.forEach(ite => {
        //     if (ite.response) {
        //       if (ite.response.code === 0) {
        //         list.push(ite)
        //       }
        //     }
        //   })
        //   setStore({ name: 'uuid', content: list[0].response.data[0].uuid })
        // }
        this.$emit("refreshDataList", response);
      } else {
        this.$message.error(response.msg);
      }
    },
    submitFileForm() {
      this.$refs.upload.submit();
    },
    show() {
      this.upload.isUploading = false;
      this.upload.open = true;
    },
    getClose() {
      setTimeout(() => {
        this.$refs.upload.clearFiles();
      });
    },
  },
};
</script>
