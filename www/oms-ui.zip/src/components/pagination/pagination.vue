<template>
  <div class="pagination">
    <el-pagination
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="pageNum"
      :page-sizes="[10, 20, 30, 40, 50]"
      :page-size="pageSize"
      layout="total, sizes"
      :total="total"
    >
    </el-pagination>
    <el-pagination
      background
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="pageNum"
      :page-sizes="[10, 20, 30, 40, 50]"
      :page-size="pageSize"
      layout="prev, pager, next, jumper"
      :total="total"
    >
    </el-pagination>
  </div>
</template>
<script>
export default {
  name: "pagination",
  data() {
    return {};
  },
  props: {
    pageNum: {
      type: Number,
    },
    pageSize: {
      type: Number,
    },
    total: {
      type: Number,
    },
  },
  created() {},
  methods: {
    //每页个数
    handleSizeChange(val) {
      console.log(val);
      this.$emit("handleSizeChange", val);
    },
    //当前页数
    handleCurrentChange(val) {
      console.log(val);
      this.$emit("handleCurrentChange", val);
    },
  },
};
</script>
<style lang="scss" scoped>
.pagination {
  display: flex;
  justify-content: space-between;
  padding-top: 20px;
  box-sizing: border-box;
}
</style>
