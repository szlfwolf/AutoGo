import request from "@/router/axios";

//分页查询
export function pageQuery(query) {
  return request({
    url: "/returnorder/returnorder/page",
    method: "get",
    params: query,
  });
}


//分页详情查询
export function pageDetailQuery(query) {
  return request({
    url: "/returnorder/returnorderline/page",
    method: "get",
    params: query,
  });
}

//人工退货单处理
export function returnOrderConfirm(obj) {
  return request({
    url: "/returnorder/returnorder/returnOrderConfirm",
    method: "post",
    data: obj,
  });
}

//退货单取消
export function returnOrderCancel(obj) {
  return request({
    url: "/returnorder/returnorder/returnOrderCancel",
    method: "post",
    data: obj,
  });
}

//下拉接口
export function returnOrderGetData(query) {
  return request({
    url: "/returnorder/returnorder/returnOrderGetData",
    method: "get",
    params: query,
  });
}
