import request from "@/router/axios";

export function fetchList(query) {
  return request({
    url: "/logs/msg/page",
    method: "get",
    params: query,
  });
}

export function getMsgDetail(obj) {
  return request({
    url: "/logs/msg-detail/getMsgDetail",
    method: "get",
    params: obj
  });
}

export function retry(obj) {
  return request({
    url: "/logs/msg/recall",
    method: "get",
    params: obj
  });
}

export function distinctDictList(typeName) {
  return request({
    url: "/logs/config/list",
    method: "get",
    params: { type: typeName },
  });
}
