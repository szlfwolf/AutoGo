/*
 *    Copyright (c) 2018-2025, lengleng All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * Neither the name of the oms4cloud.com developer nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 * Author: lengleng (wangiegie@gmail.com)
 */

import request from '@/router/axios'
export function list(query) {
  return request({
    url: '/master/client/list',
    method: 'get',
    params: query
  })
}
// 查询
export function getClientData(query) {
  return request({
    url: '/master/client/page',
    method: 'get',
    params: query
  })
}
// 下拉框PackageType
export function getPackageType(query) {
  return request({
    url: '/master/client/getPackageType',
    method: 'get',
    params: query
  })
}
export function getClient(query) {
  return request({
    url: '/master/client/getAllParentClientCodes',
    method: 'get',
    params: query
  })
}
// add下拉框父级clientCode
export function getAllParentClientCodes(query) {
  return request({
    url: '/master/client/getAllParentClientCodes',
    method: 'get',
    params: query
  })
}
// change下拉框父级clientCode
export function changeAllParentClientCodes(query) {
  return request({
    url: '/master/client/getParentClient',
    method: 'get',
    params: query
  })
}
export function getWeightAndCutOffTime(query) {
  return request({
    url: '/master/client/getWeightAndCutOffTime',
    method: 'get',
    params: query
  })
}
export function getUrgent_level(query) {
  return request({
    url: '/admin/dict/type/urgent_level',
    method: 'get',
    params: query
  })
}
export function getCountry_code(query) {
  return request({
    url: '/admin/dict/type/country_code',
    method: 'get',
    params: query
  })
}
export function getClient_package_type(query) {
  return request({
    url: '/admin/dict/type/client_package_type',
    method: 'get',
    params: query
  })
}
export function getShip_type(query) {
  return request({
    url: '/admin/dict/type/bl_ship_type',
    method: 'get',
    params: query
  })
}
// 新增
export function addSave(obj) {
  return request({
    url: '/master/client/save',
    method: 'post',
    data: obj
  })
}

export function getClientId(id) {
  return request({
    url: '/master/client/query?'+'id=' + id,
    method: 'get'
  })
}

export function delObj(id) {
  return request({
    url: '/master/client/delete/' + id,
    method: 'delete'
  })
}

export function update(obj) {
  return request({
    url: '/master/client/update',
    method: 'put',
    data: obj
  })
}
