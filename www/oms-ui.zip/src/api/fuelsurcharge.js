/*
 *    Copyright (c) 2018-2025, lengleng All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * Neither the name of the oms4cloud.com developer nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 * Author: lengleng (wangiegie@gmail.com)
 */

import request from "@/router/axios";

// 按条件query查询
export function queryHscode(query) {
  return request({
    url: "/master/fuelsurcharge/page",
    method: "get",
    params: query,
  });
}

// 新增
export function addSave(obj) {
  return request({
    url: "/master/fuelsurcharge/add",
    method: "post",
    data: obj,
  });
}
// 删除
export function delObj(id) {
  return request({
    url: "/master/fuelsurcharge/" + id,
    method: "delete",
  });
}
// 修改
export function update(obj) {
  return request({
    url: "/master/fuelsurcharge/update",
    method: "put",
    data: obj,
  });
}
