/*
 *    Copyright (c) 2018-2025, lengleng All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * Neither the name of the oms4cloud.com developer nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 * Author: lengleng (wangiegie@gmail.com)
 */

import request from "@/router/axios";
// 查询
export function getData(query) {
  return request({
    url: "/bill/quotation/page",
    method: "get",
    params: query,
  });
}
// 查询详情
export function getQuotationDetails(id) {
  return request({
    url: "/bill/quotation/getQuotationDetails/" + id,
    method: "get",
  });
}
// 查询运输
export function getTransportDetails(id) {
  return request({
    url: "/bill/quotation/getTransportDetails/" + id,
    method: "get",
  });
}
// 按条件query查询
export function queryData(query) {
  return request({
    url: "/bill/quotation/getQuotationByQuery",
    method: "get",
    params: query,
  });
}
// 查询仓库
export function AddParentWarehouseCodes(query) {
  return request({
    url: "/master/warehouse/getWarehouse", 
    method: "get",
    params: query,
  });
}
// 获取同一客户下非主库仓库
export function getWarehouseNoMW(query) {
  return request({
    url: "/master/warehouse/getWarehouseNoMW",
    method: "get",
    params: query,
  });
}
// 查询amount
export function getAmountType(query) {
  return request({
    url: "/bill/billingDetails/getAmountType",
    method: "get",
    params: query,
  });
}
// 新增
export function addSave(obj) {
  return request({
    url: "/bill/quotation/save",
    method: "post",
    data: obj,
  });
}
// 校验运输或者托盘数据是否正确
export function checkTransports(obj) {
  return request({
    url: "/bill/quotation/checkTransports",
    method: "post",
    data: obj,
  });
}
// 删除
export function delObj(id) {
  return request({
    url: "/bill/quotation/delete/" + id,
    method: "delete",
  });
}
// 修改
export function update(obj) {
  return request({
    url: "/bill/quotation/update",
    method: "put",
    data: obj,
  });
}
