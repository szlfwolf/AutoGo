import request from '@/router/axios'

//分页查询
export function pageQuery(query) {
  return request({
    url: '/outbound/dn/page',
    method: 'get',
    params: query
  })
}

//编辑
export function getEditQuery(obj) {
  return request({
    url: '/outbound/dn/updateRemark',
    method: 'put',
    data: obj
  })
}

//详情
export function getDnDetail(query) {
  return request({
    url: '/outbound/dn/getDnDetail',
    method: 'get',
    params: query
  })
}

//详细信息查询接口table
export function getDnline(query) {
  return request({
    url: '/outbound/dnline/page',
    method: 'get',
    params: query
  })
} 

//release
export function getRelease(obj) {
  return request({
    url: '/outbound/dn/release',
    method: 'post',
    data: obj
  })
} 

//combine
export function getCombine(obj) {
  return request({
    url: '/outbound/dn/combine',
    method: 'post',
    data: obj
  })
}
//通过id
export function Query(query) {
  return request({
    url: '/outbound/dn/{id}',
    method: 'get',
    params: query
  })
}

//warehouse
export function getWarehouse(query) {
  return request({
    url: '/master/warehouse/getWarehouse',
    method: 'get',
    params: query
  })
}

//PendingCount
export function getPending(query) {
  return request({
    url: '/outbound/dn/canPendingCount',
    method: 'get',
    params: query
  })
}

//CombineCount
export function getCombineCount(query) {
  return request({
    url: '/outbound/dn/canCombineDnCountUI',
    method: 'get',
    params: query
  })
}

//pickUpPage分页
export function pickUpPage(query) {
  return request({
    url: "/outbound/dn/pickUpPage",
    method: "get",
    params: query,
  });
}

//pickUpPage编辑
export function pickUpUpdate(obj) {
  return request({
    url: "/outbound/dn/pickUpUpdate",
    method: "put",
    data: obj,
  });
}

//canPickUpCount
export function getcanPickUpCount(query) {
  return request({
    url: "/outbound/dn/canPickUpCount",
    method: "get",
    params: query,
  });
}

//获取错误日志
export function bizRecordPage(query) {
  return request({
    url: "/master/bizRecord/page",
    method: "get",
    params: query,
  });
}


//校检零件库存是否满足
export function getCheck(obj) {
  return request({
    url: "/outbound/dn/check",
    method: "post",
    data: obj,
  });
}