import request from '@/router/axios'

//分页查询
export function pageQuery(query) {
  return request({
    url: '/outbound/outorder/page',
    method: 'get',
    params: query
  })
}

//dispatch批量
export function getDispatch(obj) {
  return request({
    url: "/outbound/outorder/batchDispatch",
    method: "post",
    data: obj,
  });
}

//通过订单号Order详细信息查询接口
export function getOrderNum(query) {
  return request({
    url: '/outbound/outorder/orderNum',
    method: 'get',
    params: query
  })
} 

//追踪订单
export function getByOrderNum(obj) {
  return request({
    url: '/pfep/pfeplog/getPfepLog',
    method: 'post',
    data: obj
  })
}

//通过订单号Order详细信息查询接口table
export function getOutorderline(query) {
  return request({
    url: '/outbound/outorderline/page',
    method: 'get',
    params: query
  })
} 

//获取pending数量
export function getPending(query) {
  return request({
    url: '/outbound/outorder/getPending',
    method: 'get',
    params: query
  })
}

//warehouse
export function getWarehouse(query) {
  return request({
    url: '/master/warehouse/getWarehouse',
    method: 'get',
    params: query
  })
}

//warehouse
export function getWarehouseCode(query) {
  return request({
    url: '/master/warehouse/getWarehouseCode',
    method: 'get',
    params: query
  })
}
