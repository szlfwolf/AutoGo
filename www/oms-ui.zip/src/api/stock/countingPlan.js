import request from "@/router/axios";

//分页查询 
export function pageQuery(query) {
  return request({
    url: "/stock/countingplan/page",
    method: "get",
    params: query,
  });
}

export function getSku(query) {
  return request({
    url: "/stock/countingplan/getSku",
    method: "get",
    params: query,
  });
}

export function countPlanSubmit(obj) {
  return request({
    url: "/stock/countingplan/countPlanSubmit",
    method: "post",
    data: obj,
  });
}

//修改
export function updateCountingPlan(obj) {
  return request({
    url: "/stock/countingplan/updateCountingPlan",
    method: "put",
    data: obj,
  });
}

//修改
export function deleteCountingPlan(id) {
  return request({
    url: `/stock/countingplan/${id}`,
    method: "delete",
  });
}

