import request from '@/router/axios'

//分页查询
export function pageQuery(query) {
  return request({
    url: '/stock/skubatch/page',
    method: 'get',
    params: query
  })
}

//warehouse
export function getWarehouse(query) {
  return request({
    url: '/master/warehouse/getWarehouse',
    method: 'get',
    params: query
  })
}