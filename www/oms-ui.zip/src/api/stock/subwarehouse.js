import request from '@/router/axios'

//分仓库
//查询仓库
export function getWarehouseByClient(query) {
  return request({
    url: '/stock/skuwarehousestock/getWarehouseByClient',
    method: 'get',
    params: query
  })
}
//分页查询
export function getStockByQuery(query) {
  return request({
    url: '/stock/skuwarehousestock/getStockByQuery',
    method: 'get',
    params: query,
    timeout: 120 * 1000
  })
}
//库存批次total 
export function getBatchByQuery(query) {
  return request({
    url: '/stock/skubatch/getBatchByQuery',
    method: 'get',
    params: query
  })
}
//Booked
export function getBookedDNByQuery(query) {
  return request({
    url: '/stock/skuwarehousestock/getBookedDNByQuery',
    method: 'get',
    params: query
  })
} 

//getIntransitDetail
export function getIntransitDetail(query) {
  return request({
    url: "/stock/skuwarehousestock/getIntransitDetail",
    method: "get",
    params: query,
  });
}

//合包/拆包kit 
export function skuKitBaleOrUnpacking(obj) {
  return request({
    url: '/stock/skuwarehousestock/skuKitBaleOrUnpacking',
    method: 'put',
    data: obj
  })
}
//合包/拆包表格
export function getKitByPartNumber(query) {
  return request({
    url: '/master/skukitmapping/getKitByPartNumber',
    method: 'get',
    params: query
  })
}
//Transfer调拨
export function skuStockTransfer(obj) {
  return request({
    url: '/stock/skuwarehousestock/skuStockTransfer',
    method: 'post',
    data: obj
  })
}
//属性转换
export function updateSkuQtyByType(obj) {
  return request({
    url: '/stock/skuwarehousestock/updateSkuQtyByType',
    method: 'put',
    data: obj
  })
}
//根据条件获取sku可用库存
export function getSkuAvailableQtyQuery(query) {
  return request({
    url: '/stock/skuwarehousestock/getSkuAvailableQtyQuery',
    method: 'get',
    params: query
  })
}
//销毁
export function skuStockDestroy(obj) {
  return request({
    url: '/stock/skuwarehousestock/skuStockDestroy',
    method: 'post',
    data: obj
  })
}

//汇总仓库
export function getSummaryStockByQuery(query) {
  return request({
    url: '/stock/skuwarehousestock/getSummaryStockByQuery',
    method: 'get',
    params: query
  })
}

//汇总仓库
export function updateTotalStock(query) {
  return request({
    url: "/stock/skuwarehousestock/updateTotalStock",
    method: "put",
    data: query,
  });
}

//Transfer Lost List
export function getTransferLogs(query) {
  return request({
    url: "/stock/skutransferlog/getTransferLogs",
    method: "get",
    params: query,
  });
}