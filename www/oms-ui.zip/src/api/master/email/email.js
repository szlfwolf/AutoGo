import request from "@/router/axios";

//分页查询
export function pageQuery(query) {
  return request({
    url: "master/emailconfig/page",
    method: "get",
    params: query,
  });
}

//新增
export function getSave(obj) {
  return request({
    url: "master/emailconfig/save",
    method: "post",
    data: obj,
  });
} 

//编辑
export function getUpdate(obj) {
  return request({
    url: "master/emailconfig/update",
    method: "put",
    data: obj,
  });
} 

//删除
export function delEmail(id) {
  return request({
    url: `master/emailconfig/${id}`,
    method: "delete",
  });
}