import request from "@/router/axios";

//分页查询
export function fetch(query) {
  return request({
    url: "/tms-bate/supplier/page",
    method: "get",
    params: query,
  });
}

//新增
export function save(obj) {
  return request({
    url: "/tms-bate/supplier/save",
    method: "post",
    data: obj,
  });
}

//编辑
export function updateById(obj) {
  return request({
    url: "/tms-bate/supplier/updateById",
    method: "put",
    data: obj,
  });
}

//删除
export function deleteById(id) {
  return request({
    url: `/tms-bate/supplier/${id}`,
    method: "delete",
  });
}
