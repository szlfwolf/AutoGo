/*
 *    Copyright (c) 2018-2025, lengleng All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * Neither the name of the oms4cloud.com developer nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 * Author: lengleng (wangiegie@gmail.com)
 */

import request from '@/router/axios'
// /pfep/warehousearea/page?current=1&size=10&clientCode=CC
export function warehousearea(query) {
  return request({
    url: '/pfep/warehousearea/page',
    method: 'get',
    params: query
  })
}
export function fetchList(query) {
  return request({
    url: '/pfep/pfepconfig/page',
    method: 'get',
    params: query
  })
}
export function getClientCode(query) {
  return request({
    url: '/pfep/pfepconfig/getClientCode',
    method: 'get',
    params: query
  })
}
//  请求数据
export function pageGet(query) {
  return request({
    url: '/pfep/warehousearea/pageGet',
    method: 'get',
    params: query
  })
}

export function addObj(obj) {
  return request({
    url: '/pfep/pfepconfig',
    method: 'post',
    data: obj
  })
}

export function getObj(id) {
  return request({
    url: '/pfep/pfepconfig/' + id,
    method: 'get'
  })
}

export function delObj(id) {
  return request({
    url: '/pfep/pfepconfig/' + id,
    method: 'delete'
  })
}

export function update(obj) {
  return request({
    url: '/pfep/pfepconfig/update',
    method: 'put',
    data: obj
  })
}
