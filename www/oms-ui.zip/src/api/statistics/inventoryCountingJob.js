import request from "@/router/axios";

//分页查询
export function pageQuery(query) {
  return request({
    url: "/statistics/stockSnapShoot/getInventoryCountingPage",
    method: "get",
    params: query,
  });
}
