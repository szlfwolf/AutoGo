import request from "@/router/axios";

//分页查询
export function pageQuery(query) {
  return request({
    url: "/statistics/asnHead/asnPunctuality",
    method: "get",
    params: query,
  });
}


export function asnPunctualityImportPage(query) {
  return request({
    url: "/statistics/asnHead/asnPunctualityImportPage",
    method: "get",
    params: query,
  });
}

//dn
export function dnPageQuery(query) {
  return request({
    url: "/statistics/dnHead/dnPunctuality",
    method: "get",
    params: query,
  });
}

//更新备注
export function punctualRemark(obj) {
  return request({
    url: `/statistics/asnHead/asnPunctualityUpdate`,
    method: "put",
    data: obj,
  });
}
 
export function asnPunctualityImportUpdate(obj) {
  return request({
    url: `/statistics/asnHead/asnPunctualityImportUpdate`,
    method: "put",
    data: obj,
  });
}

//dn
export function dnPunctualRemark(obj) {
  return request({
    url: `/statistics/dnHead/dnPunctualityUpdate`,
    method: "put",
    data: obj,
  });
}

//import OverView页面
export function importOverView(query) {
  return request({
    url: '/statistics/asnHead/asnPunctualityImportOverview',
    method: "get",
    params: query,
  });
}

//inbound OverView页面
export function inboundOverView(query) {
  return request({
    url: "/statistics/asnHead/asnPunctualityInboundOverview",
    method: "get",
    params: query,
  });
}

//packing OverView页面
export function packingOverView(query) {
  return request({
    url: "/statistics/dnHead/dnPackPunctualityOverview",
    method: "get",
    params: query,
  });
}

//shipOut OverView页面
export function shipOutOverView(query) {
  return request({
    url: "/statistics/dnHead/dnOutboundPunctualityOverview",
    method: "get",
    params: query,
  });
}

//delivery OverView页面
export function deliveryOverView(query) {
  return request({
    url: "/statistics/dnHead/dnDeliveryPunctualityOverview",
    method: "get",
    params: query,
  });
}