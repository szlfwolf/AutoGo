import request from "@/router/axios";

//分页查询
export function pageQuery(query) {
  return request({
    url: "/statistics/dnHead/page",
    method: "get",
    params: query,
  });
}

export function pageQueryDetail(obj) {
  return request({
    url: "/statistics/dnHead/detail",
    method: "get",
    params: obj,
  });
}
