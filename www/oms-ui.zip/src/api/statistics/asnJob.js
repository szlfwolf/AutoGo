import request from "@/router/axios";

//分页查询
export function pageQuery(query) {
  return request({
    url: "/statistics/asnHead/page",
    method: "get",
    params: query,
  });
}

export function pageQueryDetail(query) {
  return request({
    url: "/statistics/asnHead/detail",
    method: "get",
    params: query,
  });
}
