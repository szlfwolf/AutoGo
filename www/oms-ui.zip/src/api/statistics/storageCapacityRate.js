import request from "@/router/axios";

//分页查询
export function pageQuery(query) {
  return request({
    url: '/statistics/warehouseEfficiency/page',
    method: 'get',
    params: query
  })
}

//overview分页查询


export function pageQueryOverView(query) {
  return request({
    url: "/statistics/warehouseEfficiency/overview",
    method: "get",
    params: query,
  });
}