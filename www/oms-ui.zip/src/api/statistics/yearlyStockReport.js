import request from "@/router/axios";

//分页查询
export function pageQuery(query) {
  return request({
    url: "/statistics/yearlyStock/page",
    method: "get",
    params: query,
  });
}

//查询单条数据
export function getYearlyStockDetail(obj) {
  return request({
    url: "/statistics/yearlyStock/getYearlyStockDetail",
    method: "post",
    data: obj,
  });
}

//审核数据
export function getUpDateCheck(obj) {
  return request({
    url: "/statistics/yearlyStock/updateCheck",
    method: "post",
    data: obj,
  });
}

//更新oms调整数量
export function getUpdateQty(obj) {
  return request({
    url: "/statistics/yearlyStock/updateQty",
    method: "post",
    data: obj,
  });
}

//审核status
export function getYearlyStockEnum(query) {
  return request({
    url: "/statistics/yearlyStock/getYearlyStockEnum",
    method: "get",
    params: query,
  });
}
