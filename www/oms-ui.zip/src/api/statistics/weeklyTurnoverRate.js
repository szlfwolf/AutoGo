import request from "@/router/axios";

//分页查询
export function pageQuery(query) {
  return request({
    url: "/statistics/warehouseTurnoverEfficiency/page",
    method: "get",
    params: query,
  });
}
