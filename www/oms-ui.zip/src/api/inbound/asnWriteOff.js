import request from "@/router/axios";

//分页查询
export function pageQuery(query) {
  return request({
    url: "/adapter-lotus/skuVoucher/asnWriteOff/page",
    method: "get",
    params: query,
  });
}

//详情
export function getWriteOffInfo(id) {
  return request({
    url: `/adapter-lotus/skuVoucher/asnWriteOff/${id}`,
    method: "get",
  });
}

//详情列表数据
export function pageQueryLine(query) {
  return request({
    url: "/adapter-lotus/skuVoucher/asnWriteOffLine/page",
    method: "get",
    params: query,
  });
}