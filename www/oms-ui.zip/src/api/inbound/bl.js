import request from "@/router/axios";

//分页查询
export function pageQuery(query) {
  return request({
    url: "/inbound/bl/page",
    method: "get",
    params: query,
  });
}

//verify
export function getVerifyDataByBlNo(obj) {
  return request({
    url: "/inbound/bl/verifyDataByBlNo",
    method: "post",
    data: obj,
  });
}
//arrive 
export function getBlArriveAddOrUpdate(obj) {
  return request({
    url: "/inbound/bl/blArriveAddOrUpdate",
    method: "post",
    data: obj,
  });
}

//allocate
export function getAllocateAsnByBlNo(obj) {
  return request({
    url: "/inbound/bl/allocateAsnByBlNo",
    method: "post",
    data: obj,
  });
}

//分页批量删除
export function getDeleteBl(obj) {
  return request({
    url: "/inbound/bl/deleteBl",
    method: "put",
    data: obj,
  });
}


//分页Add

//提交
export function getAddBL(obj) {
  return request({
    url: "/inbound/bl/addBL",
    method: "post",
    timeout:  300*1000,
    data: obj,
  });
}

//分页详情
export function getBlDetail(query) {
  return request({
    url: "/inbound/bl/getBlDetail",
    method: "get",
    params: query,
  });
}

//分页详情blEdit
export function getBlEdit(obj) {
  return request({
    url: "/inbound/bl",
    method: "put",
    data: obj,
  });
}

//分页详情blFile
export function getBlFile(query) {
  return request({
    url: `/inbound/blFile/blNo`,
    method: "get",
    params: query,
  });
}

//分页详情blFile删除
export function getDeleteBlFileById(query) {
  return request({
    url: `/inbound/blFile/deleteBlFileById`,
    method: "delete",
    params: query,
  });
}

//分页详情blLine
export function getBlLine(query) {
  return request({
    url: `/inbound/blLine/page`,
    method: "get",
    params: query,
  });
}

// 下载
export function downloadCustomsFile(query) {
  return request({
    url: `/inbound/blFile/downloadCustomsFile`,
    method: "get",
    params: query,
  });
}


//删除上传file

export function deleteUuid(uuid) {
  return request({
    url: `/inbound/bl/del/${uuid}`,
    method: "delete",
  });
}

//下载

export function exportNonSkuList(obj) {
  return request({
    url: "/inbound/blLine/exportNonSkuList",
    method: "post",
    data: obj,
  });
}