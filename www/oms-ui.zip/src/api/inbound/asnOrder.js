import request from "@/router/axios";

//分页查询
export function pageQuery(query) {
  return request({
    url: "/inbound/inOrder/page",
    method: "get",
    params: query,
  });
}

//分页详情
export function getOrderDetail(query) {
  return request({
    url: "/inbound/inOrder/getOrderDetail",
    method: "get",
    params: query,
  });
}

//详情日志
export function getByOrderNo(query) {
  return request({
    url: "/inbound/orderoperatelog/getByOrderNo",
    method: "get",
    params: query,
  });
}

//详情orderLine
export function getInOrderLine(query) {
  return request({
    url: "/inbound/inOrderLine/page",
    method: "get",
    params: query,
  });
}

//noMappedCount数量
export function getNoMappedCount(query) {
  return request({
    url: "/inbound/inOrder/noMappedCount",
    method: "get",
    params: query,
  });
}

//noPendingCount数量 
export function getNoRespondedCount(query) {
  return request({
    url: "/inbound/inOrder/noRespondedCount",
    method: "get",
    params: query,
  });
}

//回传预览
export function getInOrderResponsePreview(query) {
  return request({
    url: "/inbound/inOrder/inOrderResponsePreview",
    method: "get",
    params: query,
  });
}

//回传提交
export function getInOrderResponseSubmit(query) {
  return request({
    url: "/inbound/inOrder/inOrderResponseSubmit",
    method: "get",
    params: query,
  });
}

//订单关闭
export function getClosedOrder(body) {
  return request({
    url: "/inbound/inOrder/closedOrder",
    method: "post",
    data: body,
  });
}