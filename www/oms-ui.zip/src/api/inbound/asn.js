import request from '@/router/axios'

//一期
//分页查询
export function pageQuery(query) {
  return request({
    url: '/inbound/asn/page',
    method: 'get',
    params: query
  })
}

//分页详情
export function getAsnDetail(query) {
  return request({
    url: `/inbound/asn/${query.id}`,
    method: 'get'
  })
}

//分页详情table asnLine
export function getAsnLine(query) {
  return request({
    url: `/inbound/asnline/page`,
    method: 'get',
    params:query
  })
}

//编辑
export function getEditQuery(obj) {
  return request({
    url: '/inbound/asn/updateById',
    method: 'put',
    data: obj
  })
}

//推送WMS-release批量
export function getRelease(obj) {
  return request({
    url: "/inbound/asn/batchRelease",
    method: "put",
    data: obj,
  });
}

//获取pending数量
export function getCount(query) {
  return request({
    url: `/inbound/asn/pending/count`,
    method: 'get',
    params:query
  })
}

//warehouse
export function getWarehouse(query) {
  return request({
    url: '/master/warehouse/getWarehouse',
    method: 'get',
    params: query
  })
}

//二期
//分页查询
export function pageQuerys(query) {
  return request({
    url: '/inbound/asn/pages',
    method: 'get',
    params: query
  })
}

//分页详情
export function getAsnDetails(query) {
  return request({
    url: "/inbound/asn/getAsnDetail/",
    method: 'get',
    params:query
  })
}

//分页详情table asnLine
export function getAsnLines(query) {
  return request({
    url: "/inbound/asnline/pages",
    method: 'get',
    params:query
  })
}

//AsnLine编辑
export function getEditAsnline(obj) {
  return request({
    url: "/inbound/asnline",
    method: "put",
    data: obj,
  });
}

//详情日志
export function getByASn(query) {
  return request({
    url: "/inbound/asnoperatelog/getByAsn",
    method: "get",
    params: query,
  });
}

//close 
export function getShutdownAsn(query) {
  return request({
    url: "/inbound/asn/shutdownAsn",
    method: "get",
    params: query,
  });
}

//查询能匹配的OrderNo
export function getOrderNoByAsnNo(query) {
  return request({
    url: "/inbound/asn/getOrderNoByAsnNo",
    method: "get",
    params: query,
  });
}

// map预览
export function getMappingOrderPreview(query) {
  return request({
    url: "/inbound/asn/mappingOrderPreview",
    method: "get",
    params: query,
  });
}

// map提交
export function getMappingOrderSubmit(obj) {
  return request({
    url: "/inbound/asn/mappingOrderSubmit",
    method: "post",
    data: obj,
  });
}

// 解除ASN匹配 预览
export function getCutoffMappedPreview(query) {
  return request({
    url: "/inbound/asn/cutoffMappedPreview",
    method: "get",
    params: query,
  });
}
// 解除ASN匹配 提交
export function getCutoffMappedSubmit(query) {
  return request({
    url: "/inbound/asn/cutoffMappedSubmit",
    method: "get",
    params: query,
  });
}

// 获取pending数量
export function getAsnPendingCount(query) {
  return request({
    url: `/inbound/asn/asnPendingCount`,
    method: "get",
    params: query,
  });
}

// 获取noMapped数量
export function getAsnNoMappedCount(query) {
  return request({
    url: `/inbound/asn/asnNoMappedCount`,
    method: "get",
    params: query,
  });
}

// 打印 
export function print(obj) {
  return request({
    url: `/inbound/asnline/print`,
    method: "post",
    data: obj,
  });
}


// 打印零件号标签入库
export function addAsnLinePrint(obj) {
  return request({
    url: `/inbound/asnlineprint/addAsnLinePrint`,
    method: "post",
    data: obj,
  });
}
 
export function run(obj) {
  return request({
    url: `/print/run`,
    method: "post",
  });
}

//默认操作
export function createAsnOrder(query) {
  return request({
    url: `/inbound/asn/createAsnOrder`,
    method: "get",
    params: query,
  });
}

//强制完成
export function differenceAsnUpdate(query) {
  return request({
    url: `/inbound/asn/differenceAsnUpdate`,
    method: "get",
    params: query,
  });
}

//ASN 待办数据查询
export function getAsnTodoQuantity(query) {
  return request({
    url: `/inbound/asn/getAsnTodoQuantity`,
    method: "get",
    params: query,
  });
}
