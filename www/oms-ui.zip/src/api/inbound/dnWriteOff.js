import request from "@/router/axios";

//分页查询
export function pageQuery(query) {
  return request({
    url: "/adapter-lotus/skuVoucher/dnWriteOff/recordPage",
    method: "get",
    params: query,
  });
}

//dn冲销
export function dnWriteOff(obj) {
  return request({
    url: "/adapter-lotus/skuVoucher/dnWriteOff/dnWriteOff",
    method: "post",
    data: obj,
  });
}