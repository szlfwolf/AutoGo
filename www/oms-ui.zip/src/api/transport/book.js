import request from "@/router/axios";

//分页查询
export function pageQuery(query) {
  return request({
    url: "/tms-bate/dn/operate/getTrackBookByPage",
    method: "get",
    params: query,
  });
}

//详情
export function geBatchNoInfo(batchNo) {
  return request({
    url: `/tms-bate/dn/operate/getPackageInfoByBatchNo/${batchNo}`,
    method: "get",
  });
}

//根据合单单号获取包装信息
export function getBoxInfoByBatchNo(batchNo) {
  return request({
    url: `/tms-bate/dn/operate/getBoxInfoByBatchNo/${batchNo}`,
    method: "get",
  });
}

//修改包装信息
export function updateBoxInfoByBatchNo(obj) {
  return request({
    url: "/tms-bate/dn/operate/updateBoxInfoByBatchNo",
    method: "put",
    data: obj,
  });
}

//车队列表
export function getAllSupplierInfo(query) {
  return request({
    url: `/tms-bate/supplier/getAllSupplierInfo/${query}`,
    method: "get",
  });
}

//订车
export function getBook(obj) {
  return request({
    url: "/tms-bate/dn/operate/book",
    method: "post",
    data: obj,
  });
}

//订车通知
export function getNotification(obj) {
  return request({
    url: "/tms-bate/dn/operate/dnDhlNotification",
    method: "post",
    data: obj,
  });
}

//label导出
export function getDocumentByBatchNo(row) {
  return request({
    url: `/tms-bate/waybill/getDocumentByBatchNo/${row.batchNo}`,
    method: "get",
  });
}

//pod 收货
export function getPod(obj) {
  return request({
    url: "/tms-bate/dn/operate/pod",
    method: "post",
    data: obj,
  });
}

//pickUp 揽件
export function getPickUp(obj) {
  return request({
    url: "/tms-bate/dn/operate/pickUp",
    method: "post",
    data: obj,
  });
}

//获取车队Dhl选择类型
export function getDhlServiceTypeList(row) {
  return request({
    url: `/tms-bate/dn/operate/getDhlServiceTypeList/${row.batchNo}`,
    method: "get",
  });
}

//获取批次号地址信息
export function getBatchAddressInfo(row) {
  return request({
    url: `/tms-bate/dn/operate/getBatchAddressInfo/${row.batchNo}`,
    method: "get",
  });
}