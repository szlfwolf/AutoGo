import request from "@/router/axios";

//分页查询
export function pageQuery(query) {
  return request({
    url: "/tms-bate/waybill/page",
    method: "get",
    params: query,
  });
}

//详情
export function getPackageInfoByBatchNo(batchNo) {
  return request({
    url: `/tms-bate/waybill/getPackageInfoByBatchNo/${batchNo}`,
    method: "get",
  });
}