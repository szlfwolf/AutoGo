/*
 *    Copyright (c) 2018-2025, lengleng All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * Neither the name of the oms4cloud.com developer nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 * Author: lengleng (wangiegie@gmail.com)
 */

import request from "@/router/axios";

export function fetchList(query) {
  return request({
    url: "/master/warehouse/page",
    method: "get",
    params: query,
  });
}
export function getWms(query) {
  return request({
    url: "/master/warehouse/getWms",
    method: "get",
    params: query,
  });
}
// add打开 父仓库code
export function AddParentWarehouseCodes(query) {
  return request({
    url: "/master/warehousetype/getParentWarehouseCodes",
    method: "get",
    params: query,
  });
}
// 编辑打开 父仓库code
export function ChangeParentWarehouseCodes(query) {
  return request({
    url: "/master/warehouse/getParentWarehouse",
    method: "get",
    params: query,
  });
}
// 获取仓库类型
export function getAllWarehouseCode(query) {
  return request({
    url: "/master/warehousetype/getAllWarehouseCode",
    method: "get",
    params: query,
  });
}
// 获取仓库名称
export function getWarehouseName(query) {
  return request({
    url: "/master/warehousetype/getWarehouseName",
    method: "get",
    params: query,
  });
}
// 获取Country code
export function getCountryCode(query) {
  return request({
    url: "/master/contactaddress/getCountryCode",
    method: "get",
    params: query,
  });
}

export function addObj(obj) {
  return request({
    url: "/master/warehouse/save",
    method: "post",
    data: obj,
  });
}
export function removeByWarehouseCode(obj) {
  return request({
    url: "/master/warehouse/removeByWarehouseCode",
    method: "put",
    params: obj,
  });
}

export function getObj(id) {
  return request({
    url: "/master/warehouse/" + id,
    method: "get",
  });
}
//根据客户查询仓库名称和仓库类型集合
export function getNameAndType(query) {
  return request({
    url: "/master/warehouse/getWarehouseNameAndWarehouseTypeByClientCode",
    method: "get",
    params: query,
  });
}

// 合单配置表的客户下拉框接口：master/client/getClient
export function getClient(query) {
  return request({
    url: "/master/client/getClient",
    method: "get",
    params: query,
  });
}
// 合单配置表的仓库code下拉框接口：master/warehouse/getAllWarehouseCode
export function getWarehouseCode(query) {
  return request({
    url: "/master/warehouse/getAllWarehouseCode",
    method: "get",
    params: query,
  });
}

//warehouse
export function getWarehouse(query) {
  return request({
    url: "/master/warehouse/getSynthesisConfigWarehouseCode",
    method: "get",
    params: query,
  });
}
//getWarehouseLevel
export function getWarehouseLevel(query) {
  return request({
    url: "/master/warehousearea/getWarehouseLevel",
    method: "get",
    params: query,
  });
}
//根据clientCode,warehouseType查询仓库名称
export function getWareHouseName(query) {
  return request({
    url: "/master/warehouse/getWarehouseNameByClientCodeAndWarehouseType",
    method: "get",
    params: query,
  });
}
//根据clientCode,warehouseName查询仓库类型
export function getWareHouseType(query) {
  return request({
    url: "/master/warehouse/getWarehouseNameByClientCodeAndWarehouseName",
    method: "get",
    params: query,
  });
}

export function delObj(id) {
  return request({
    url: "/master/warehouse/" + id,
    method: "delete",
  });
}

export function updateByWarehouseCode(obj) {
  return request({
    url: "/master/warehouse/updateByWarehouseCode",
    method: "put",
    data: obj,
  });
}
