/**
 * @param {function} fn 传入的函数
 * @param {number} delay  延时时间
 * @param {boolean} onDelay 最后一次点击要不要执行 true 执行最后一次 false  不执行
 * @returns
 */
export function btnAntiShake(fn, delay, onDelay) {
  let flag = null;
  let flag1 = null;
  let sign = true;
  return function () {
    if (flag !== null) clearTimeout(flag);
    if (flag1 !== null) clearTimeout(flag1);
    if (sign) {
      fn.apply(this, arguments);
      sign = false;
      flag1 = setTimeout(() => {
        sign = true;
      }, delay);
    } else {
      flag = setTimeout(() => {
        if (onDelay) fn.apply(this, arguments);
        sign = true;
      }, delay);
    }
  };
}
