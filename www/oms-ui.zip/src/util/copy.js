export function copy(content) {
  if(content === '' || content === null || content === undefined){
    return '文本为空'
  }
  let aux = document.createElement("input");
  aux.setAttribute("value", content);
  document.body.appendChild(aux);
  aux.select();
  document.execCommand("copy");
  document.body.removeChild(aux);
  return "复制成功"
}
