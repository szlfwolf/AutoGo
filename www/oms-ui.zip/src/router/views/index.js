import Layout from "@/page/index/";
export default [
  {
    path: "/wel",
    component: Layout,
    redirect: "/wel/index",
    children: [
      {
        path: "index",
        name: "首页",
        component: () => import(/* webpackChunkName: "views" */ "@/page/wel"),
      },
    ],
  },
  {
    path: "/info",
    component: Layout,
    redirect: "/info/index",
    children: [
      {
        path: "index",
        name: "个人信息",
        component: () =>
          import(/* webpackChunkName: "page" */ "@/views/admin/user/info"),
      },
    ],
  },
  {
    path: "/orderDetail",
    component: Layout,
    redirect: "/orderDetail/index",
    children: [
      {
        path: "index",
        name: `order详情`,
        component: () =>
          import(
            /* webpackChunkName: "page" */ "@/views/outbound/order/orderDetail"
          ),
      },
    ],
  },
  {
    path: "/dnDetail",
    component: Layout,
    redirect: "/dnDetail/index",
    children: [
      {
        path: "index",
        name: "dn详情",
        component: () =>
          import(/* webpackChunkName: "page" */ "@/views/outbound/dn/dnDetail"),
      },
    ],
  },
  {
    path: "/asnDetail",
    component: Layout,
    redirect: "/asnDetail/index",
    children: [
      {
        path: "index",
        name: "asn详情",
        component: () =>
          import(
            /* webpackChunkName: "page" */ "@/views/inbound/asn/asnDetail"
          ),
      },
    ],
  },
  {
    path: "/skuAsnDetail",
    component: Layout,
    redirect: "/skuAsnDetail/index",
    children: [
      {
        path: "index",
        name: "sku详情",
        component: () =>
          import(
            /* webpackChunkName: "page" */ "@/views/master/sku/skuAsnDetail"
          ),
      },
    ],
  },
  {
    path: "/WarehouseDetail",
    component: Layout,
    redirect: "/WarehouseDetail/index",
    children: [
      {
        path: "index",
        name: "WarehouseDetail",
        component: () =>
          import(
            /* webpackChunkName: "page" */ "@/views/master/warehouse/WarehouseDetail"
          ),
      },
    ],
  },
  {
    path: "/skuAddEdit",
    component: Layout,
    redirect: "/skuAddEdit/index",
    children: [
      {
        path: "index",
        name: "Add Warehouse",
        component: () =>
          import(
            /* webpackChunkName: "page" */ "@/views/master/warehouse/skuAddEdit"
          ),
      },
    ],
  },
  {
    path: "/warehouse",
    component: Layout,
    redirect: "/warehouse/index",
    children: [
      {
        path: "index",
        name: "Warehouse",
        component: () =>
          import(
            /* webpackChunkName: "page" */ "@/views/master/warehouse/index"
          ),
      },
    ],
  },
  {
    path: "/pfepDetail",
    component: Layout,
    redirect: "/pfepDetail/index",
    children: [
      {
        path: "index",
        name: "PFEP Detail",
        component: () =>
          import(
            /* webpackChunkName: "page" */ "@/views/pfep/pfep-Detail/pfepDetail"
          ),
      },
    ],
  },
  {
    path: "/storageType",
    component: Layout,
    redirect: "/storageType/index",
    children: [
      {
        path: "index",
        name: "Storage Type",
        component: () =>
          import(
            /* webpackChunkName: "page" */ "@/views/pfep/storageType/index"
          ),
      },
    ],
  },
  {
    path: "/storageTypeAdd",
    component: Layout,
    redirect: "/storageTypeAdd/index",
    children: [
      {
        path: "index",
        name: "storageTypeAdd",
        component: () =>
          import(
            /* webpackChunkName: "page" */ "@/views/pfep/storageType/storageTypeAdd"
          ),
      },
    ],
  },
  {
    path: "/blAdd",
    component: Layout,
    redirect: "/blAdd/index",
    children: [
      {
        path: "index",
        name: "BL Add",
        meta: {
          keepAlive: true,
        },
        component: () =>
          import(/* webpackChunkName: "page" */ "@/views/inbound/bl/blAdd"),
      },
    ],
  },
  {
    path: "/blDetail",
    component: Layout,
    redirect: "/blDetail/index",
    children: [
      {
        path: "index",
        name: "BL Detail",
        component: () =>
          import(/* webpackChunkName: "page" */ "@/views/inbound/bl/blDetail"),
      },
    ],
  },
  {
    path: "/asnOrderDetail",
    component: Layout,
    redirect: "/asnOrderDetail/index",
    children: [
      {
        path: "index",
        meta: {},
        component: () =>
          import(
            /* webpackChunkName: "page" */ "@/views/inbound/order/asnOrderDetail"
          ),
      },
    ],
  },
  {
    path: "/asnMapping",
    component: Layout,
    redirect: "/asnMapping/index",
    children: [
      {
        path: "index",
        name: `Mapping ASN`,
        meta: {
          keepAlive: true,
        },
        component: () =>
          import(
            /* webpackChunkName: "page" */ "@/views/inbound/order/asnMapping"
          ),
      },
    ],
  },
  {
    path: "/VoucherDetail",
    component: Layout,
    redirect: "/VoucherDetail/index",
    children: [
      {
        path: "index",
        name: "VoucherDetail",
        component: () =>
          import(
            /* webpackChunkName: "page" */ "@/views/master/voucher/VoucherDetail.vue"
          ),
      },
    ],
  },
  {
    path: "/importAmountDetails",
    component: Layout,
    redirect: "/importAmountDetails/index",
    children: [
      {
        path: "index",
        name: "Import Amount",
        component: () =>
          import(
            /* webpackChunkName: "page" */ "@/views/bill/importAmountDetails"
          ),
      },
    ],
  },
  {
    path: "/importAmountAdd",
    component: Layout,
    redirect: "/importAmountAdd/index",
    children: [
      {
        path: "index",
        name: "ImportAmountAdd",
        component: () =>
          import(
            /* webpackChunkName: "page" */ "@/views/bill/importAmountDetails/importAmountAdd.vue"
          ),
      },
    ],
  },
  {
    path: "/response",
    component: Layout,
    redirect: "/response/index",
    children: [
      {
        path: "index",
        name: "response",
        component: () =>
          import(
            /* webpackChunkName: "page" */ "@/views/inbound/order/response.vue"
          ),
      },
    ],
  },
  {
    path: "/client",
    component: Layout,
    redirect: "/client/index",
    children: [
      {
        path: "index",
        name: "Client",
        component: () =>
          import(/* webpackChunkName: "page" */ "@/views/master/client"),
      },
    ],
  },
  {
    path: "/clientEdit",
    component: Layout,
    redirect: "/clientEdit/index",
    children: [
      {
        path: "index",
        name: "ClientEdit",
        component: () =>
          import(
            /* webpackChunkName: "page" */ "@/views/master/client/clientEdit.vue"
          ),
      },
    ],
  },
  {
    path: "/addQuotation",
    component: Layout,
    redirect: "/addQuotation/index",
    children: [
      {
        path: "index",
        name: "AddQuotation",
        component: () =>
          import(
            /* webpackChunkName: "page" */ "@/views/bill/quotation/addQuotation.vue"
          ),
      },
    ],
  },
  {
    path: "/previewQuotation",
    component: Layout,
    redirect: "/previewQuotation/index",
    children: [
      {
        path: "index",
        name: "Quotation",
        component: () =>
          import(
            /* webpackChunkName: "page" */ "@/views/bill/quotation/previewQuotation.vue"
          ),
      },
    ],
  },
  {
    path: "/asnWriteOffDetail",
    component: Layout,
    redirect: "/asnWriteOffDetail/index",
    children: [
      {
        path: "index",
        name: "asnWriteOffDetail",
        component: () =>
          import(
            /* webpackChunkName: "page" */ "@/views/lotus/asnWriteOff/asnWriteOffDetail.vue"
          ),
      },
    ],
  },
  {
    path: "/sapReturnOrderDetail",
    component: Layout,
    redirect: "/sapReturnOrderDetail/index",
    children: [
      {
        path: "index",
        name: "sapReturnOrderDetail",
        component: () =>
          import(
            /* webpackChunkName: "page" */ "@/views/sap/sapReturnOrder/returnOrderDetail.vue"
          ),
      },
    ],
  },

];
