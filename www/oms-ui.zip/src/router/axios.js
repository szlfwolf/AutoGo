import axios from "axios";
import { serialize } from "@/util/util";
import NProgress from "nprogress"; // progress bar
import errorCode from "@/const/errorCode";
import { Message, MessageBox } from "element-ui";
import "nprogress/nprogress.css";
import qs from "qs";
import store from "@/store"; // progress bar style
axios.defaults.timeout = 30000;
// axios.defaults.timeout = 120000;
// 返回其他状态吗
axios.defaults.validateStatus = function (status) {
  return status >= 200 && status <= 500; // 默认的
};
// 跨域请求，允许保存cookie
axios.defaults.withCredentials = false;
// NProgress Configuration
NProgress.configure({
  showSpinner: false,
});

// HTTPrequest拦截
axios.interceptors.request.use(
  (config) => {
    NProgress.start(); // start progress bar
    const isToken = (config.headers || {}).isToken === false;
    let token = store.getters.access_token;
    let clientCode = store.getters.commandName;
    if (token && !isToken) {
      config.headers["Authorization"] = "Bearer " + token; // token
    }
    if (
      config.url.includes("master") ||
      config.url.includes("pfep") ||
      config.url.includes("stock") ||
      config.url.includes("inbound") ||
      config.url.includes("outbound") ||
      config.url.includes("adapter-lotus") ||
      config.url.includes("tms-bate") ||
      config.url.includes("statistics") ||
      config.url.includes("bill") ||
      config.url.includes("returnorder")
    ) {
      config.headers["clientCode"] = clientCode;
    }
    // headers中配置serialize为true开启序列化
    if (config.methods === "post" && config.headers.serialize) {
      config.data = serialize(config.data);
      delete config.data.serialize;
    }

    // 处理get 请求的数组 springmvc 可以处理
    if (config.method === "get") {
      config.paramsSerializer = function (params) {
        return qs.stringify(params, { arrayFormat: "repeat" });
      };
    }

    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// HTTPresponse拦截
axios.interceptors.response.use(
  (res) => {
    NProgress.done();
    const status = Number(res.status) || 200;
    const message = res.data.msg || errorCode[status] || errorCode["default"];

    // 后台定义 424 针对令牌过去的特殊响应码
    if (status === 424) {
      MessageBox.confirm("令牌状态已过期，请点击重新登录", "系统提示", {
        confirmButtonText: "重新登录",
        cancelButtonText: "取消",
        type: "warning",
      })
        .then(() => {
          store.dispatch("LogOut").then(() => {
            // 刷新登录页面，避免多次弹框
            window.location.reload();
          });
        })
        .catch(() => {});
      return;
    }
    if (status !== 200 || res.data.code == 1) {
      if (res.data.data != null && typeof res.data.data == "object") {
        let errorText = [];
        let meg = "";
        errorText = Object.values(res.data.data);
        meg = errorText.join("<br/>");
        Message({
          dangerouslyUseHTMLString: true, //重点代码
          message: meg,
          type: "error",
          duration: 5000,
        });
        return Promise.reject(new Error(message));
      } else {
        Message({
          message: message,
          type: "error",
          duration: 5000,
        });
        return Promise.reject(new Error(message));
      }
    }

    return res;
  },
  (error) => {
    NProgress.done();
    return Promise.reject(new Error(error));
  }
);

export default axios;
